module.exports = require('./lib/sessionstore');
