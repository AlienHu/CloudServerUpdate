/**
 * DAO for smsOffer
 * Author : Linto thomas
 * Created : 28-Mar-18
 */

import * as crypto from '../controllers/libraries/crypto';
import * as couchDBUtils from '../controllers/common/CouchDBUtils.js';
import * as logger from '../common/Logger';
import { SMSOffer, SMSInfo } from '../TSControllers/interfaces/sms';
const licenceDBInstance = couchDBUtils.getLicenceDB();
export const SMS_INFO_DOC_NAME = 'smsOffer';

export async function save(doc: SMSInfo) { // only runs firstime
    logger.info("*** smsDAO.save");
    let smsOffer: SMSOffer = {
        _id: doc._id,
        encrypt: crypto.encrypt(doc)
    }
    await couchDBUtils.create(smsOffer, licenceDBInstance);
}
export async function get() {
    logger.info("*** smsDAO.get");
    try {
        let smsOffer: SMSOffer = await couchDBUtils.getDocEx(SMS_INFO_DOC_NAME, licenceDBInstance);
        let smsInfo: SMSInfo = crypto.decrypt(smsOffer.encrypt);
        return smsInfo;
    } catch (e) {
        if (!(e.reason === 'missing' || e.reason === 'deleted')) {
            logger.error("error from smsDAO" + JSON.stringify(e));
        }
        throw e;
    }
}

export function decrypt(smsOffer:SMSOffer) {
    let plain: SMSInfo = crypto.decrypt(smsOffer.encrypt);
    return plain;
}