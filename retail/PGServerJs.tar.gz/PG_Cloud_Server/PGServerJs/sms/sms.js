'use strict';
/*
 * 0. enableSMS (serverId, noSMS, pgsettings, profiles)
 * 1. sendSMS(to, body, senderId) -> (fail: (nointernet, balance over)
 * 2. getSMSStats(senderId) -> (fail: noInternet) (balance, pack1000)
 *      send apiurl where the delivery report can be called. have some logic to count based on senderid -> serverID
 * 
 * 1. User settings - multiple, smstype(promo/trans)
 * 2. PG Settings - apiURl, apiKey,promolinkadd
 * 3. user form 
 * 
 * OTP
 * 1. sendOTP(to) -> (fail: nointernet)(success)
 * 2. validateOTP(otp) -> (success, fail)
 * 3. resendOTP(to) -> (fail: nointernet)
 * 4. getSMSStats(): NOT STARTED
 */

const couchMain = require('../couchDb/couchDBMain.js');
let couchDBUtils = require('../controllers/common/CouchDBUtils.js');
let coreDBInstance = couchDBUtils.getCoreCouchDB();
const mainDBInstance = couchDBUtils.getMainCouchDB();
let request = require('request');
const httpUtils = require('../common/httpUtils');
const logger = require('../common/Logger');
const follow = require('follow');
const smsDAO = require('./smsDAO');
const SMS_INFO_DOC_NAME = smsDAO.SMS_INFO_DOC_NAME;
const smsCountItrObj = require('./smsCount');
const textMaxLengthKeys = Object.keys(smsCountItrObj.TEXT);
const unicodeMaxLengthKeys = Object.keys(smsCountItrObj.Unicode_Text);

//TODO: read from db
let apiUrl = '';
let apiKey = '';
let promoLinkAdd = '';
let sender = 'ALNTST';
let linkAddOn = '';
const customerId = '';
const smsDb = 'pg_seller_sms';
let sms_setting_seller_doc = 'sms_settings_seller';
let sms_setting_pg_doc = 'sms_settings_pg';
let otpDb = '';

const getApplicationSettings = require('../common/configState').getApplicationSettings;

/**
 * 
 * @param {*} params 
 * throws in the following cases
 * 1. smsConfig not set
 * 2. smsConfig is not valid
 * 3. msg is empty
 * 4. Multiple is false but To has multiple phone numbers
 * 5. Quota crossed
 * 6. Internet or some other error
 */
let sendSMS = async function(params) {
    let app = params.app;
    let response = {};
    var msgCount = 1;
    var toCount = 1;
    let applicationSettings = getApplicationSettings();
    let transLinkAdd;
    let promoLinkAdd;

    // await couchDBUtils.update(applicationSettings, nanoCore, 2);
    /*
     * params={
     *      To:'9572362138',
     *      Msg: 'sms message'
     *      Multiple: true [OPTIONAL],
     *      Type: 'PROMO' [OPTIONAL],
     *      From: 'ALNHPG' [OPTIONAL]
     * }
     *
     */
    if (!smsConfig) {
        logger.error('sms config not set');
        var resp = {};
        resp.msg = 'sms config json not set';
        resp.status = 'error';
        throw resp;
    }
    if (!smsConfig.apiUrl || !smsConfig.apiKey || !smsConfig.promoLinkAdd || smsConfig.promoQuota === undefined || smsConfig.transQuota === undefined) {
        logger.error('sms config not set or empty transQuota/promoQuota');
        // if (!params.isListening) {
        //     await listenToChanges();
        //     params.isListening = true;
        //     return sendSMS(params);
        // }
        let resp = {};
        resp.msg = 'sms config json not set';
        resp.status = 'error';
        throw resp;
    } else {
        apiUrl = smsConfig.apiUrl;
        apiKey = smsConfig.apiKey;
        transLinkAdd = smsConfig.transLinkAdd;
        promoLinkAdd = smsConfig.promoLinkAdd;
    }
    if (!params.Type) {
        params.Type = 'PROMO';
    }
    if (!params.From) {
        params.From = sender;
    }
    if (smsConfig.sender) {
        params.From = smsConfig.sender;
    }
    if (!params.Msg) {
        response.msg = 'empty msg';
        throw response;
    }

    if (!params.Multiple) {
        params.Multiple = true;
    }
    if (!params.To) {
        response.msg = 'No phone number is given';
        throw response;
    }
    if (params.Multiple == false && params.To.length > 13) {
        response.msg = 'trying to send sms to multiple users';
        throw response;

    }

    if (params.Type == 'TRANS') {
        linkAddOn = transLinkAdd;
    } else {
        linkAddOn = promoLinkAdd;
    }

    let requestBuilder;
    let viaGupshup = false;
    let msgType = 'TEXT';
    if (smsConfig.gupshup && smsConfig.gupshup.value && smsConfig.gupshup.query.override_dnd) {
        logger.info("Send sms using gupshup");
        viaGupshup = true;
        msgType = smsConfig.gupshup.query.msg_type;
        if (params.bWelcome) {
            params.Msg += " To opt out SMS " + smsConfig.sender + " to 9220092200";
        }
        if (params.Type == 'PROMO') {
            logger.info("Checking dnd numbers.." + params.To);
            let numberArr = params.To.split(',');
            logger.info("DND numbers " + DND_CUS_ARR);
            let nonDNDNos = numberArr.filter(function(num) { //find the non dnd no's
                if (num.length <= 10) {
                    num = '91' + num;
                }
                return !DND_CUS_ARR.includes(num);
            });
            params.To = nonDNDNos.toString();
            logger.info("Non DND number(s) : " + params.To);
            if (nonDNDNos.length === 0) {
                response.msg = 'Found a dnd numner';
                throw 'Found a dnd numner';
            }
        }
        let q1 = {
            send_to: params.To,
            msg: params.Msg,
            mask: smsConfig.sender
        }
        let query = Object.assign(smsConfig.gupshup.query, q1);
        requestBuilder = {
            url: smsConfig.gupshup.url,
            method: "GET",
            json: true,
            qs: query,
            headers: {
                "Content-Type": "application/json"
            }
        }
    } else {
        requestBuilder = {
            url: apiUrl + '/' + apiKey + '/' + linkAddOn,
            method: "POST",
            json: true,
            body: params,
            headers: {
                "Content-Type": "application/json"
            }
        }
    }
    try {
        toCount = params.To.split(',').length;
    } catch (err) { // error when params.To is an integer
        // toCount = ((params.To.length - 1) % 10) + 1; // don't understand what is this - Deepak?
        toCount = 1;
        logger.error("params.To.split caught error, now toCount is " + toCount);
    }

    msgCount = getSMSCount(params.Msg.length, msgType);
    let totalSMSCount = parseInt(msgCount * toCount);

    if (params.Type == 'PROMO' && smsConfig.promoQuota && smsConfig.promoQuota < (applicationSettings.smsCounter.promoCounter + totalSMSCount)) {
        response.msg = 'promo sms quota reached';
        throw response;
    } else if (params.Type == 'TRANS' && smsConfig.transQuota < (applicationSettings.smsCounter.transCounter + totalSMSCount)) {
        response.msg = 'trans sms quota reached';
        throw response;
    }
    try {
        response = await httpUtils.http(requestBuilder); // sending sms to 2factor or gupshup
    } catch (error) {
        logger.error(error);
        logger.error("smsjs -> send sms failed may be due to internet!");
        response.err = error;
        response.msg = 'failed due to internet';
        throw response;
    }

    if (viaGupshup && response && response.body && response.body.response && response.body.response.status === 'error') { // Send sms failed from gupshup
        logger.error('gupshup api returned error.');
        logger.error(response.body.response.details);
    }

    if (!applicationSettings.smsCounter.promoCounter) applicationSettings.smsCounter.promoCounter = 0;
    if (!applicationSettings.smsCounter.transCounter) applicationSettings.smsCounter.transCounter = 0;
    if (params.Type == 'PROMO') applicationSettings.smsCounter.promoCounter += totalSMSCount;
    else applicationSettings.smsCounter.transCounter += totalSMSCount;
    response.msg = 'Success' // for gupshup
    try {
        if (!params.dontUpdate) {
            await couchDBUtils.update(applicationSettings, coreDBInstance);
        }
    } catch (err) {
        err.msg = 'couldnt update counter';
        logger.error(err);
    }

    return response;

}

function getSMSCount(msgLength, msgType) {
    let msgCountIndex = 0;
    let maxLengthKeys = textMaxLengthKeys;
    let tempSMSCountItrObj = smsCountItrObj.TEXT;
    if (msgType === 'Unicode_Text') {
        maxLengthKeys = unicodeMaxLengthKeys;
        tempSMSCountItrObj = smsCountItrObj.Unicode_Text;
    }

    for (let i = 0; i < maxLengthKeys.length; i++) {
        msgCountIndex = maxLengthKeys[i];
        if (msgLength < maxLengthKeys[i]) {
            break;
        }
    }

    return tempSMSCountItrObj[msgCountIndex];
}

let getSMSStats = async function(customerId) {
    if (!customerId) {
        response.msg = 'empty customer Id';
        throw response;
    }
    try {
        let resp = couchBDUtils.getDoc(customerId, 'pg_seller_sms');
        response = resp;
        response.msg = 'permitted';
        // console.log(response);
        return response;
    } catch (err) {
        response.msg('Failed to check your quota.');
        throw response;
    }
}
let setSMSSettingsforSeller = async function(params) {
    let response = {};
    if (!params.type) {
        params.type = 'PROMO';
    }
    if (!params.multiple) {
        params.multiple = false;
    }
    let jsonDOC = {
        serverId: params.serverId,
        senderId: params.senderId,
        type: params.type,
        multiple: params.multiple,
    }
    try {
        //update if already exists
        await couchBDUtils.update(jsonDOC, smsDb, 1);
        response.msg = 'updated settings';
        return response;
    } catch (err) {
        try {
            // insert new doc 
            await couchBDUtils.create(jsonDOC, smsDb, 1, 'failed to set the settings');
            response.msg = 'created settings for sms';
            return response;
        } catch (err) {
            response.msg = 'failed to update settings';
            throw response;
        }

    }
}
let setSMSSettingsforPG = async function(params) {
    if (!params.apiUrl || !params.apiKey || !params.packLinkAddOn) {
        response.msg = 'empty settings';
        throw response;
    }
    let jsonDOC = {
        _id: sms_setting_pg_doc,
        apiUrl: params.apiUrl,
        apiKey: params.apiKe,
        packLinkAddOn: params.packLinkAddOn
    }
    // should be in sync from cloud
    try {
        //update ifalready exists
        await couchBDUtils.update(jsonDOC, smsDb, 1);
    } catch (err) {
        try {
            // insert new doc 
            await couchBDUtils.create(jsonDOC, smsDb, 1, 'failed to set the settings');
        } catch (err) {
            response.msg = 'failed to update settings';
            throw response;
        }

    }
}
let enableSMS = async function(params) {
    if (!params.sellerId || !params.noOfSMS) {
        response.msg = 'insufficient inputs';
        throw response;
    }
    // TODO: check maximum number of noOfSMS...10000?
    if (!params.type) params.type = 'PROMO';
    if (!params.multiple) params.multiple = false;
    try {
        await setSMSSettingsforSeller(params);
    } catch (err) {
        response.msg = 'failed to enable sms feature';
        response.err = err;
        throw response;
    }

}
let sendOTP = async function(to) {
    let options = {
        method: 'GET',
        url: apiUrl + '/' + apiKey + '/' + '/SMS/' + to + '/AUTOGEN',
        headers: {
            'content-type': 'application/x-www-form-urlencoded'
        },
        form: {}
    };
    try {
        let resp = await request(options);
        let sessionID = resp.Details;
        // TODO: push sessionID on cloud for verification
        let now = new Date();
        let jsonDOC = {
            _id: now + '_' + sessionID,
            sessionID: sessionID,
            user: to,
            timestamp: now
        }
        // TODO: remove db 
        resp = couchBDUtils.create(jsonDOC, otpDb, 1, 'failed to store otp to cloud');
        response.msg = 'otp pushed to cloud';
        response.docId = now + '_' + sessionID;
        return response;
    } catch (error) {
        response.msg = 'failed while pushing otp to cloud';
        response.err = error;
        throw response;
    }
}

let reSendOTP = async function(sessionDoc) {
    let to = '';
    try {
        let resp = await couchBDUtils.getDoc(sessionDoc, otpDb, 'propagate');
        to = resp.user;
    } catch (err) {
        response.msg = 'failed to get sessionId';
        response.err = err;
        throw response;
    }
    try {
        couchBDUtils.delete({
            _id: sessionDoc
        }, otpDb);
    } catch (err) {}
    return (await sendOTP(to));
}
let validateOTP = async function(sessionDoc, otp) {
    let sessionId = '';
    try {
        let resp = await couchBDUtils.getDoc(sessionDoc, otpDb, 'propagate');
        sessionID = resp.sessionID;
    } catch (err) {
        response.msg = 'failed to get otp from sessionDoc';
        response.err = err;
        throw response;
    }

    let options = {
        method: 'GET',
        url: apiUrl + '/' + apiKey + '/' + '/SMS/' + to + '/' + otp,
        headers: {
            'content-type': 'application/x-www-form-urlencoded'
        },
        form: {}
    };
    try {
        let resp = await request(options);
        if (resp.Details == 'OTP Matched' && resp.Status == 'Success') {
            response.msg = 'success';
            return response;
        } else {
            response = resp;
            response.msg = 'session expired';
            throw response;
        }
    } catch (err) {
        response = err;
        response.msg = 'otp not verified';
        throw response;
    }
}

async function listenToChanges() {
    try {
        logger.info("*** listenToChanges.sms.js")
        let smsOffer = await smsDAO.get();
        logger.info('smsOffer found');
        setSMSConfig(smsOffer);
    } catch (error) {
        logger.error('unable to listen SMSConfig');
    }

    let count = 0;
    follow({
        db: couchMain.getLicencedbUrl(),
        include_docs: true,
        // doc_ids: [SMS_INFO_DOC_NAME],
        filter: function(doc, req) {
            if (doc._id != SMS_INFO_DOC_NAME) {
                return false;
            }
            return true;
        },
        since: 'now'
    }, function(error, change) {
        if (!error) {
            count++;
            setTimeout(function() {
                count--;
                if (count === 0) {
                    //handle delete
                    if (change.deleted) {
                        smsConfig = undefined;
                    } else {
                        listenToDecrypt(change.doc);
                    }
                }
            }, 1000);

        }
    });
}
let SENDERID;
let DND_CUS_ARR = [];
async function listenToDNDCus() {
    try {
        logger.info("*** listenToDNDCus.sms.js SENDERID : " + SENDERID);
        let doc = await couchDBUtils.getDoc(SENDERID, mainDBInstance, 'propagate');
        logger.info('DND_CUS_ARR found');
        updateDNDNums(doc);
    } catch (error) {
        logger.info("DND customers are not exists");
    }

    let count = 0;
    follow({
        db: couchMain.getMaindbUrl(),
        include_docs: true,
        // doc_ids: [SENDERID],
        filter: function(doc, req) {
            if (doc._id === SENDERID) {
                return true;
            }
            return false;
        },
        since: 'now'
    }, function(error, change) {
        if (!error) {
            count++;
            setTimeout(function() {
                count--;
                if (count === 0) {
                    //handle delete
                    if (change.deleted) {
                        DND_CUS_ARR = [];
                    } else {
                        updateDNDNums(change.doc);
                    }
                }
            }, 1000);

        }
    });
}

function updateDNDNums(customerArr) {
    if (!customerArr.numberArr) {
        return;
    }
    DND_CUS_ARR = customerArr.numberArr;
    logger.info("updated DND numbers new DND_CUS_ARR is " + DND_CUS_ARR);
}
let smsConfig;

function listenToDecrypt(smsOffer) {
    logger.info("*** listenToDecrypt");
    let config = smsDAO.decrypt(smsOffer);
    setSMSConfig(config);
}

function setSMSConfig(smsOffer) {
    if (!smsOffer) {
        logger.error("SMS config is not undefined, Canceling setSMSConfig");
        return;
    }
    logger.info('new config found');
    smsConfig = {
        "apiUrl": smsOffer.apiUrl,
        "apiKey": smsOffer.apiKey,
        "transLinkAdd": smsOffer.transLinkAdd,
        "promoLinkAdd": smsOffer.promoLinkAdd,
        "sender": smsOffer.sender,
        "transQuota": 0,
        "promoQuota": 0,
        "gupshup": smsOffer.gupshup
    };
    SENDERID = 'senderId_' + smsOffer.sender;
    for (let i = 0; i < smsOffer.transQuotaList.length; i++) {
        smsConfig.transQuota += smsOffer.transQuotaList[i].count;
    }

    for (let i = 0; i < smsOffer.promoQuotaList.length; i++) {
        smsConfig.promoQuota += smsOffer.promoQuotaList[i].count;
    }
    listenToDNDCus();
    // logger.info(smsConfig);
}

listenToChanges();
module.exports = function(params) {
    return sendSMS(params);
};