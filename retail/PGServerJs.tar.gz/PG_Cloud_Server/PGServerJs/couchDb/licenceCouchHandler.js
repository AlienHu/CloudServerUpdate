/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */
var q = require('q');
var couchMain = require('./couchDBMain.js');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const follow = require('follow');
var liceceGenerator = require('../licencer/licenceGenerator.js');
var _self;
var licenceCouchHandler = function() {
    _self = this;
    var couchLicenceDbClientsJson;

    function getCouchClient(appType) {
        if (!couchLicenceDbClientsJson) {
            couchLicenceDbClientsJson = couchMain.getProfitGuruCouchLicenceDbClientsJson();
        }
        return couchLicenceDbClientsJson[appType];
    }

    //couchDbLicenceClients = couchMain.getLicenceDbClients();
    this.getAppliedLicenceInfo4thisClient = function(appType, clientId) {
        var defered = q.defer();
        getCouchClient(appType).get('licenceapply_' + clientId, function(err, data) {
            if (!err) {
                defered.resolve(data);
            } else {
                defered.reject(err);
            }
        });

        return defered.promise;
    };

    this.getAuthorizedLicenceInfo4thisClient = function(appType, clientId) {
        var defered = q.defer();
        getCouchClient(appType).get('licence_' + clientId, function(err, data) {
            if (!err) {
                defered.resolve(data);
            } else {
                defered.reject(err);
            }
        });

        return defered.promise;
    };

    this.prepareAuthorizedClientMap = function() {
        var defer = q.defer();

        var licencedClinetsList = [];
        couchDBUtils.getView('all_provisnd_licences', 'all_provisnd_licences', {}, getCouchClient(process.env.APP_TYPE)).then(function(clientList) {
            clientList.forEach(function(client) {
                licencedClinetsList.push(client);
            });
            defer.resolve(licencedClinetsList);
        });

        return defer.promise;
    };

    let bListeningToChanges = false;
    this.listenToChanges = async function(callBack) {
        if (bListeningToChanges) {
            return;
        }

        bListeningToChanges = true;

        let resp = await couchDBUtils.getUpdateSeq('licencedb');
        let seqNo = parseInt(resp);
        let count = 0;
        follow({
            db: couchMain.getLicencedbUrl(),
            include_docs: false
        }, function(error, change) {
            if (!error) {
                let newSeqNo = parseInt(change.seq);
                if (newSeqNo > seqNo) {
                    seqNo = newSeqNo;
                    count++;
                    setTimeout(function() {
                        count--;
                        if (count === 0) {
                            callBack();
                        }
                    }, 1000);
                }
            }
        });
    };

    this.prepareAppliedClientMap = function(callBack) {

        var defer = q.defer();

        var licenceAppliedClinetsList = [];
        couchDBUtils.getView('all_applied_licences', 'all_applied_licences', {}, getCouchClient(process.env.APP_TYPE)).then(function(clientList) {

            clientList.forEach(function(client) {
                licenceAppliedClinetsList.push(client);
            });

            defer.resolve(licenceAppliedClinetsList);
        });

        return defer.promise;
    };

    this.hasClientApplied4Licence = function(appType, candClientId, callBack) {
        getCouchClient(appType).get('licenceapply_' + candClientId, function(err, appliedLicence) {
            if (!err)
                callBack(true);
            else {
                callBack(false);
            }
        });
    };
    this.licenceApplyCouchInsert = function(appType, licenceJson, callBack) {
        var defered = q.defer();
        var result = {
            isApplied: false,
            hasAlreadyApplied: false
        };

        //console.log(getCouchClient(appType));
        getCouchClient(appType).get('licenceapply_' + licenceJson.candClientId, function(err, appliedLicence) {
            if (!err) {
                //callBack(true);
                result.hasAlreadyApplied = true;
                defered.resolve(result);
            } else {
                getCouchClient(appType).insert(licenceJson, 'licenceapply_' + licenceJson.candClientId, function(err, res) {
                    if (err) {
                        console.log("New Licence Insert failed");
                        result.error = err;
                        defered.reject(result);
                    } else {
                        console.log('Successfully inserted new Licence');
                        result.isApplied = true;
                        defered.resolve(result);
                    }
                });
            }
        });

        return defered.promise;
    };

    this.licenceActiveRequestInsert = function(appType, licenceJson) {
        var defered = q.defer();
        result = {};
        getCouchClient(appType).insert(licenceJson, 'licenceapply_' + licenceJson.candClientId, function(err, res) {
            if (err) {
                console.log("Licance Activation Request Insert Failed");
                result.error = err;
                defered.reject(result);
            } else {
                console.log('Successfully inserted Licance Activation Request');
                result.success = true;
                defered.resolve(result);
            }
        });

        return defered.promise;
    };

    this.licenceProvisionCouchInsert = function(appType, licence) {
        var defered = q.defer();
        delete licence._id;
        delete licence._rev;
        var licProvsnResult = {
            hasAlreadyProvisioned: false,
            isProvisioned: false
        };

        licence._id = licence.clientId;

        getCouchClient(appType).get('licence_' + licence.clientId, function(err) {
            if (!err) {
                //callBack(true);
                licProvsnResult.hasAlreadyProvisioned = true;
                defered.resolve(licProvsnResult);
            } else {
                getCouchClient(appType).insert(licence, 'licence_' + licence.clientId, function(err, res) {
                    if (err) {
                        console.log("New Licence Insert failed");
                        licProvsnResult.hasAlreadyProvisioned = true;
                        licProvsnResult.error = err;
                        defered.reject(licProvsnResult);
                    } else {
                        console.log('Successfully inserted new Licence');
                        licProvsnResult.isProvisioned = true;
                        defered.resolve(licProvsnResult);
                    }
                });
            }
        });

        return defered.promise;

    };
    this.grantClientAccessCouchInsert = function(appType, licence) {
        var defered = q.defer();
        var grantAccessResult = {
            isAccessAllowed: false
        };
        try {
            // delete licence._id;
            // delete licence._rev;
            licence._id = licence.clientId;
            getCouchClient(appType).head('licence_' + licence.clientId, function(err, _, header) {
                    if (!err) {
                        licence._id = 'licence_' + licence.clientId;
                        licence._rev = JSON.parse(header.etag);
                        getCouchClient(appType).insert(licence, 'licence_' + licence.clientId, function(err, res) {
                            if (err) {
                                console.log("Failed to Grant Access");
                                grantAccessResult.error = err;
                                defered.reject(grantAccessResult);
                            } else {
                                console.log('Access Granted Successfully');
                                grantAccessResult.isAccessAllowed = true;
                                defered.resolve(grantAccessResult);
                            }
                        });
                    } else
                        console.log("Failed to Grant Access");
                },
                function(err) {
                    console.log("Failed to get access infomation");
                    grantAccessResult.isAccessAllowed = false;
                    defered.resolve(grantAccessResult);
                });

        } catch (ex) {
            console.log('Failed to get licence details' + ex);
            defered.resolve(grantAccessResult);
        }
        return defered.promise;
    };

    this.revokeClientAccessCouchInsert = function(appType, licence) {
        var defered = q.defer();
        var grantAccessResult = {
            isAccessAllowed: false
        };
        try {
            // delete licence._id;
            // delete licence._rev;
            licence._id = licence.clientId;
            getCouchClient(appType).head('licence_' + licence.clientId, function(err, _, header) {
                    if (!err) {
                        licence._id = 'licence_' + licence.clientId;
                        licence._rev = JSON.parse(header.etag);
                        //licence.allowAccess = false;
                        getCouchClient(appType).insert(licence, function(err, res) {
                            if (err) {
                                console.log("Failed to revoke Access");
                                grantAccessResult.error = err;
                                defered.reject(grantAccessResult);
                            } else {
                                console.log('Access Revoked Successfully');
                                grantAccessResult.isAccessAllowed = false;
                                defered.resolve(grantAccessResult);
                            }
                        });

                    } else
                        console.log("Failed to revoke Access");
                },
                function(err) {
                    console.log("Failed to get access infomation");
                    grantAccessResult.isAccessAllowed = true;
                    defered.resolve(grantAccessResult);
                });

        } catch (ex) {
            console.log('Failed to get licence details' + ex);
            defered.resolve(grantAccessResult);
        }
        return defered.promise;
    };

    this.licenceProvisionCouchUpdate = function(appType, licenceStr) {
        var jsonDoc = JSON.parse(licenceStr);
        getCouchClient(appType).head('licence_' + jsonDoc.client_id, function(err, _, header) {
            if (!err) {
                jsonDoc._id = 'licence_' + jsonDoc.client_id;
                jsonDoc._rev = JSON.parse(header.etag);
                getCouchClient(appType).insert(jsonDoc, 'licence_' + jsonDoc.client_id,
                    function(err) {
                        if (err) {
                            console.log("Update failed", err);
                        } else {
                            console.log('Successfully Updated Licence');
                        }
                    });
            } else
                console.log('Item Update Error');
        });

    };

    this.licenceDelete = function(appType, client_id) {
        getCouchClient(appType).head('licence_' + client_id, function(err, _, header) {
            if (!err) {
                getCouchClient(appType).destroy('licence_' + client_id, JSON.parse(header.etag), function(err) {
                    if (err)
                        console.log("Delete failed", err);
                    else {
                        console.log('Successfully deleted Item:' + 'licence_' + client_id);
                    }
                });
            } else
                console.log('Item Delete Error');
        });
    };

};

module.exports = new licenceCouchHandler();