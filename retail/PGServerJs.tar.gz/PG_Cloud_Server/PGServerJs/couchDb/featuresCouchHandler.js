var _self;
var profitGuruStatusEvents = require('../common/profitGuruStatusEvents.js');

function featuresCouchHandler(couchMain) {

    couchMain = couchMain ? couchMain : require('./couchDBMain.js');
    _self = this;

    this.getAllowedApplicationFeatures = function(appName) {
        return new Promise(function(resolve, reject) {
            //Directly accessing the document not view, to use view use .view propery of nano
            couchMain.getProfitGuruCouchCoreDbClientsJson(appName).get('profitGuruAllowedFeatures_', function(err, data) {
                if (!err) {
                    resolve(data);
                } else {
                    console.log('Could not get the profitGuru Features');
                    reject(err);
                }
            });
        })
    };

    this.updateAllowedApplicationFeatures = function(appName, nonLocalPrivatelyAuthentcatedFeatures4Update) {

        var fatureDiff = require('deep-diff');

        return new Promise(function(resolve, reject) {
            return _self.getAllowedApplicationFeatures(appName).then(function(features4Update) {
                function prefilter(path, key) {
                    return (['_id', '_rev'].indexOf(key) >= 0);
                }
                var featuresDiffResultBeforeMerge = fatureDiff(features4Update, nonLocalPrivatelyAuthentcatedFeatures4Update, prefilter);
                if (!featuresDiffResultBeforeMerge) {
                    reject('Nothing to update');
                }

                featuresDiffResultBeforeMerge.forEach(function(feature4Update) {
                    if (feature4Update.kind === 'E') {
                        if (['_id', '_rev'].indexOf(feature4Update.path[0]) < 0) {
                            console.log('Changingn ' + feature4Update.path[0], ' Feature from ' + feature4Update.lhs, 'to', feature4Update.rhs);
                            features4Update[feature4Update.path[0]][feature4Update.path[1]] = feature4Update.rhs;
                        }
                    } else if (feature4Update.kind === 'D') {
                        console.log('Fine Update documents has sent few properties only');
                    } else if (feature4Update.kind === 'N') {
                        features4Update[feature4Update.path[0]] = feature4Update.rhs;
                        console.log('Warning: Seems update document has a extra property=' + JSON.stringify(feature4Update) + ' which would be ignored!!');
                    } else {
                        console.log(feature4Update);
                        throw new Error(' Error while updating Features, Something wiered happened: Reason Feature Value=' + JSON.stringify(feature4Update));

                    }

                });

                var featuresDiffResultrAfteMerge = fatureDiff(features4Update, nonLocalPrivatelyAuthentcatedFeatures4Update, prefilter);
                if (!featuresDiffResultrAfteMerge) {
                    return couchMain.getProfitGuruCouchCoreDbClientsJson(appName).head('profitGuruAllowedFeatures_', function(err, _, header) {
                        if (!err) {
                            features4Update._id = 'profitGuruAllowedFeatures_';
                            features4Update._rev = JSON.parse(header.etag);
                            return couchMain.getProfitGuruCouchCoreDbClientsJson(appName).insert(features4Update, 'profitGuruAllowedFeatures_',
                                function(err) {
                                    if (err) {
                                        throw new Error(" profitGuruAllowedFeatures_ Update failed" + err);
                                    } else {
                                        console.log('Successfully Updated profitGuruAllowedFeatures');
                                        profitGuruStatusEvents.emit('featuresUpdate', features4Update);
                                        resolve(features4Update);
                                    }
                                });
                        } else {

                            throw new Error('profitGuruAllowedFeatures  Update Error' + err);
                        }
                    });
                } else {
                    throw new Error("profitGuruAllowedFeatures_ Update failed(Merge failed) ");
                }
            });
        });
    };
    return this;

}

module.exports = function(couchMain) {
    return featuresCouchHandler(couchMain);
};