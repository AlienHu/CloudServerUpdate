/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */
var createSingleton = require('create-singleton');
var q = require('q');
var logger = require('../common/Logger');
const configState = require('../common/configState');
var feedbackUtils = require("./feedbackUtils");
var backupAndRestore = require("../controllers/backUpAndRestore")

require('shelljs/global');
//var couchNanoWithPrms = require('nano-blue');

var profitGuruStatusEvents = require('../common/profitGuruStatusEvents.js');
var _self;
var APP_TYPE = process.env.APP_TYPE;

var couchDbMain = createSingleton(function couchDbCommon() {
    _self = this;
    var iConfig;
    let bInitDone = false;
    var localCouchUrl;
    var couchdbPGClients;
    var coreDBList;
    var couchDBUtils2 = require('./couchDBUtils2');
    var platform = /^win/.test(process.platform) ? "windows" : "linux";
    var couchParams;
    const migrationHandler = require('./migrationHandler');

    this.getprofitGuruNodeServerConfig = function() {
        return _self.iConfig;
    };

    this.getMainDbCouchClient = function() {

        return _self.couchdbPGClients[APP_TYPE].maindb;
    };

    this.getCoreDBClient = function() {
        return _self.couchdbPGClients[APP_TYPE].coredb;
    };

    this.getCoreDbCouchClient = function() {

        return _self.couchdbPGClients[APP_TYPE].coredb;
    };

    this.getLicenceDBClient = function() {
        return _self.couchdbPGClients[APP_TYPE].licencedb;
    };

    this.getCouchClient = function(dbSuffix) {

        return _self.couchdbPGClients[APP_TYPE][dbSuffix];
    };

    this.getLicencedbUrl = function() {
        let dbSuffix = 'licencedb';
        let dbName = couchDBUtils2.getDBName(_self.iConfig.localCouch.DBPrefix, APP_TYPE, dbSuffix, _self.iConfig.localCouch.DBs[dbSuffix].appSpecific);
        return _self.iConfig.localCouch.dbUrl + '/' + dbName;
    };
    this.getMaindbUrl = function() {
        let dbSuffix = 'maindb';
        let dbName = couchDBUtils2.getDBName(_self.iConfig.localCouch.DBPrefix, APP_TYPE, dbSuffix, _self.iConfig.localCouch.DBs[dbSuffix].appSpecific);
        return _self.iConfig.localCouch.dbUrl + '/' + dbName;
    };

    this.getProfitGuruCouchLicenceDbClientsJson = function() {
        var licenceDBList = {};
        _self.iConfig.localCouch.profitGuruDBsApps.forEach(function(appName) {
            licenceDBList[appName] = _self.couchdbPGClients[appName].licencedb;
        });
        return licenceDBList;
    };

    this.getUsersDbCouchClient = function() {
        return _self.couchdbPGClients[APP_TYPE]._users;
    }

    this.getProfitGuruCouchCoreDbClientsJson = function(appName) {

        //TODO change the above two functions as below
        if (!coreDBList) {
            coreDBList = {};
            _self.iConfig.localCouch.profitGuruDBsApps.forEach(function(appName) {
                coreDBList[appName] = _self.couchdbPGClients[appName].coredb;
            });

        }
        if (!appName) {
            return coreDBList;
        } else {
            return coreDBList[appName];
        }

    };

    function getCouchUrl(dbInfo) {
        return couchDBUtils2.getCouchUrl(dbInfo);
    }

    this.getApplicationConfig = function() {
        return _self.iConfig;
    };

    this.isInitDone = function() {
        return bInitDone;
    };

    this.dropAllCouchDBs = async function(sId, bTrial, applicationSettings, backUpLocation) {
        try {
            if (!sId) {
                const couchDBUtils = require('../controllers/common/CouchDBUtils')
                const licenceDB = couchDBUtils.getLicenceDB();
                let serverDoc = await couchDBUtils.getDoc('profitGuruServerLicence_', licenceDB);
                sId = serverDoc.clientId;
                console.log(sId);
                const coredb = couchDBUtils.getCoreCouchDB();
                let settings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coredb);
                let platform = 'windows';
                if (!(/^win/.test(process.platform))) {
                    platform = 'linux';
                }
                backUpLocation = settings.backUpLocation[platform];
            }
            var backupController = require('../controllers/backUpAndRestore');
            var backUpConfig = {
                reason: 'casual',
                backUpBaseLocationDir: backUpLocation
            }
            console.log(backUpConfig);
            await backupController.takeBackUp(backUpConfig);
            let dbPrefix;
            let cloudDBUrl = '';
            let cloudIpResponse = await getCloudCouchSyncDetails(sId).catch(function(error) {
                //some error. May be internet.
            });

            if (cloudIpResponse) {
                cloudIpResponse.serverSerilaNumber = sId;
                cloudDBUrl = getCouchUrl(cloudIpResponse);
            }

            console.log('CLOUD URL : ' + cloudDBUrl);
            await prepareLocalCouchDbClients();
            var dbUrl = getCouchUrl(_self.iConfig.localCouch);
            dbPrefix = _self.iConfig.localCouch.DBPrefix;

            let dbConfig = _self.iConfig.localCouch.DBs;

            let promisesArray = [];
            for (let dbSuffix in dbConfig) {
                let config = dbConfig[dbSuffix];
                let dbName = couchDBUtils2.getDBName(dbPrefix, APP_TYPE, dbSuffix, config.appSpecific);
                if (dbName !== '_users') {
                    promisesArray.push(couchDBUtils2.deleteDb(dbUrl, dbName));
                } else {
                    promisesArray.push(couchDBUtils2.deleteAllUsersByAppType(dbUrl, dbName, APP_TYPE));
                }
                let feedbackdb = 'pg_collection_cloud_' + APP_TYPE + '_feedback_' + sId;
                promisesArray.push(couchDBUtils2.deleteDb(cloudDBUrl, feedbackdb));
                // const marketdb = 'pg_collection_cloud_' + APP_TYPE + '_market_' + sId;
                // promisesArray.push(couchDBUtils2.deleteDb(cloudDBUrl, marketdb));
                if (cloudDBUrl) {
                    let cloudDBName = 'pg_collection_cloud_' + APP_TYPE + '_' + dbSuffix + '_' + sId;
                    // if (dbSuffix !== 'licencedb') {
                    promisesArray.push(couchDBUtils2.deleteDb(cloudDBUrl, cloudDBName));
                }
                // }
            }

            let umzugStoragePath = configState.getUmzugStoragePath(_self.iConfig.umzugStoragePath[platform], APP_TYPE);
            if (!(/^win/.test(process.platform))) {
                umzugStoragePath = process.env['HOME'] + umzugStoragePath;
            }
            configState.deleteFile(umzugStoragePath);

            await Promise.all(promisesArray);

            var sessionDbName = dbPrefix + '_' + _self.iConfig.sessionDbName;
            await couchDBUtils2.deleteDb(dbUrl, sessionDbName);
        } catch (err) {
            logger.error(err);
            throw err;
        }
    };
    this.getSessionDB = function() {
        let dbPrefix = _self.iConfig.localCouch.DBPrefix;
        let dbConfig = _self.iConfig.localCouch;
        let dbUrl = getCouchUrl(dbConfig);
        let sessionDbName = couchDBUtils2.getDBName(dbPrefix, false, _self.iConfig.sessionDbName);
        let nanoBlueClient = require('nano-blue')(dbUrl);
        let sessionnDB = nanoBlueClient.db.use(sessionDbName);
        return sessionnDB;
    }

    this.initAllCouchDBs = async function(bForce, sId, bTrial, backUpLocation) {
        process.env.bCouch2 = await couchDBUtils2.isCouch2();
        try {
            if (bForce) {
                await _self.dropAllCouchDBs(sId, bTrial, backUpLocation);
            }
            await migrationHandler.migrate();

            //if databases are not created.. it gets created and the instances are loaded 
            await prepareLocalCouchDbClients();
            let dbConfig = _self.iConfig.localCouch;
            let dbUrl = getCouchUrl(dbConfig);
            let dbPrefix = _self.iConfig.localCouch.DBPrefix;

            let promisesArray = [];
            for (let dbSuffix in dbConfig.DBs) {
                let config = dbConfig.DBs[dbSuffix];
                promisesArray.push(couchDBUtils2.createCouchDbAndViews(_self.couchdbPGClients[APP_TYPE][dbSuffix], dbSuffix));
            }
            await Promise.all(promisesArray);

            let sessionDbName = couchDBUtils2.getDBName(dbPrefix, false, _self.iConfig.sessionDbName);
            await couchDBUtils2.createDb(dbUrl, sessionDbName);
            await couchDBUtils2.createCouchDbAndViews(_self.getSessionDB(), 'sessionDB')

            let firstTimeCouchInit = require('./firstTimeCouchInitHandler.js');
            let applicationSettings = await firstTimeCouchInit.doFirstTimeCouchDBInit(_self);
            backupAndRestore.initAutoBackup();
            bInitDone = true;
            return {
                sessionDbName: sessionDbName,
                applicationSettings: applicationSettings
            };

        } catch (reason) {
            throw reason;
        }

    };

    async function prepareLocalCouchDbClients() {
        try {
            _self.iConfig = await configState.getAppConfig();
            _self.iConfig.localCouch.dbUrl = getCouchUrl(_self.iConfig.localCouch);
            _self.couchdbPGClients = await couchDBUtils2.createAndKeepCouchDbClient(_self.iConfig.localCouch);
            return true;
        } catch (err) {
            let errMsg = 'Failed to get the App config';
            logger.error(err);
            logger.error(errMsg);
            throw errMsg;
        }
    }

    profitGuruStatusEvents.on('ServerUUID_Available', function(serverSerilaNumber) {
        _self.iConfig.serverSerilaNumber = serverSerilaNumber;
    });

    profitGuruStatusEvents.on('profitGuruOnline', function(serverSerilaNumber) {
        logger.silly('Received ServerUUID_Available  ', serverSerilaNumber, ' and server is Online So starting Replication');
        startReplication(serverSerilaNumber);
    });
    var cloudSyncDetailsCount = 0;

    async function getCloudCouchSyncDetails(serverSerilaNumber) {
        var WebRequest = require("../common/webRequest.js");
        let licenceHelper = require('../licencer/licenceHelper');
        let cloudCouchParams = (await configState.getAppConfig()).cloudCouch;

        return new Promise(function(resolve, reject) {

            var webRequest = new WebRequest(cloudCouchParams.host, {
                    "Content-Type": "application/json",
                    "x-api-key": cloudCouchParams.apiKey
                },
                cloudCouchParams.ssl);
            cloudSyncDetailsCount++;
            console.log("cloudSyncDetails call count" + cloudSyncDetailsCount);
            webRequest.get(cloudCouchParams.api.cloudSyncDetails + '?ServerId=' + serverSerilaNumber + '&AppType=' + process.env.APP_TYPE, function(err, data) {
                if (err) {
                    reject(err);
                    return;
                }

                if (data.statusCode < 200 || data.statusCode > 299) {
                    reject({
                        error: "Request Failed",
                        trace: data
                    });
                    return;
                }

                var parsedData;
                try {
                    parsedData = JSON.parse(data.data.toString());
                    if (parsedData.timeStamp) {
                        licenceHelper.setCloudTime(parsedData.timeStamp);
                    }
                    resolve(parsedData);
                    return;
                } catch (e) {
                    reject({
                        error: "Failed to parse json",
                        trace: e
                    });
                }
            });
        });
    }

    function startReplication(serverSerilaNumber) {
        return Promise.resolve().then(function() {
            if (couchParams && couchParams.Host) {
                return Promise.resolve(couchParams);
            } else {
                return getCloudCouchSyncDetails(serverSerilaNumber);
            }
        }).then(function(response) {
            couchParams = response;
            couchParams.serverSerilaNumber = serverSerilaNumber;
            logger.silly(couchParams);
            var promiseArray = [];
            promiseArray.push(startCloudCouchReplication(couchParams));
            return Promise.all(promiseArray);
        }).catch(function(reason) {
            logger.error('Could not start Replication beccause of ' + JSON.stringify(reason));
        });
    }

    async function startCloudCouchReplication(cloudCouchParams) {
        var replicatePromises = [];
        var cloudCouchUrl = getCouchUrl(cloudCouchParams);
        for (let j = 0; j < _self.iConfig.localCouch.profitGuruDBsApps.length; j++) {
            let appName = _self.iConfig.localCouch.profitGuruDBsApps[j];
            if (!cloudCouchParams.DBs) {
                logger.error("cloudCouchParams.DBs: " + cloudCouchParams.DBs);
                return Promise.resolve();
            }
            for (let i = 0; i < cloudCouchParams.DBs.length; i++) {
                let dbSuffix = cloudCouchParams.DBs[i];
                //   if (_self.iConfig.isReplcateToCloud[dbSuffix]) {
                var dbPrefix = _self.iConfig.localCouch.DBPrefix;
                var cloudDbPrefix = cloudCouchParams.DBPrefix;
                var syncCloudCouchUrl = cloudCouchUrl + '/' + cloudDbPrefix + '_' + appName + '_' + dbSuffix + '_' + cloudCouchParams.serverSerilaNumber;
                var localDBName = couchDBUtils2.getDBName(dbPrefix, appName, dbSuffix, _self.iConfig.localCouch.DBs[dbSuffix].appSpecific);
                var localCouchUrl = getCouchUrl(_self.iConfig.localCouch);

                replicatePromises.push(replicateDB(localCouchUrl, localDBName, syncCloudCouchUrl, dbSuffix === 'licencedb'));

                if (dbSuffix === "maindb") {
                    /**replacting specific doc type from one db to other db, from feedbackDb to mainDb */
                    try {
                        await feedbackUtils.initilizeDb({
                            cloudCouchUrl: cloudCouchUrl,
                            dbName: cloudDbPrefix + '_' + appName + '_' + "feedback" + '_' + cloudCouchParams.serverSerilaNumber
                        });
                    } catch (ex) {
                        logger.error("Not throwing " + ex)
                    }
                    syncCloudCouchUrl = cloudCouchUrl + '/' + cloudDbPrefix + '_' + appName + '_' + "feedback" + '_' + cloudCouchParams.serverSerilaNumber;
                    replicatePromises.push(replicateDB(localCouchUrl, syncCloudCouchUrl, localCouchUrl + '/' + localDBName, false, "all_feedback_data/feedback_data"));
                }
            }
        };
        return q.all(replicatePromises);
    };

    async function replicateDB(localCouchUrl, localDBName, cloudDBUrl, bLicenceDB, filter) {
        var localDBInstance = require('nano-blue')(localCouchUrl);

        var params = {
            create_target: true,
            continuous: true
        };
        if (filter) {
            params.filter = filter;
        }

        if (bLicenceDB) {
            //it is not working don't know why
            //           params.filter = 'general/item_import';
        }

        try {
            await localDBInstance.db.replicate(localDBName, cloudDBUrl, params);
            if (bLicenceDB) {
                //delete params.filter;
                return localDBInstance.db.replicate(cloudDBUrl, localDBName, params);
            }
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

});

module.exports = new couchDbMain();