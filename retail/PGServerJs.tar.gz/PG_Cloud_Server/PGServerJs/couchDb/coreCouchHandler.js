var couchMain = require('./couchDBMain.js');
var validator = require('validator');

var coreCouchHandler = function () {

    this.getProfitGuruRestApis = function (appName, req) {
        return new Promise(function (resolve, reject) {

            couchMain.getProfitGuruCouchCoreDbClientsJson(appName).get('profitGuruRestApis_', function (err, data) {
                if (!err) {
                    data.serverConfig = couchMain.getprofitGuruNodeServerConfig();
                    //TODO get this location name from settings
                    data.serverConfig.applicationSettings = req.app.locals.applicationSettings;
                    if (validator.isEmpty(data.serverConfig.applicationSettings.locationName.value)) {
                        data.serverConfig.applicationSettings.locationName.value = require('os').hostname() + ' ' + process.env.APP_TYPE;
                    }

                    resolve(data);
                } else {
                    console.log('Could not get the profitGuruRestApis_');
                    reject(err);
                }
            });
        });
    };
    this.getProfitGuruElements = function (appName) {
        return new Promise(function (resolve, reject) {

            couchMain.getProfitGuruCouchCoreDbClientsJson(appName).get('profitGuruElements_', function (err, data) {
                if (!err) {
                    resolve(data);
                } else {
                    console.log('Could not get the profitGuru Elements');
                    reject(err);
                }
            });
        });
    };

    this.getProfitGuruProfiles = function (appName) {
        return new Promise(function (resolve, reject) {

            couchMain.getProfitGuruCouchCoreDbClientsJson(appName).get('profitGuruProfiles_', function (err, data) {
                if (!err) {
                    resolve(data);
                } else {
                    console.log('Could not get the profitGuru Profiles');
                    reject(err);
                }
            });
        });
    };

    this.getAllUserOrEmployeeEntitlements = function (appName) {
        return new Promise(function (resolve, reject) {

            couchMain.getProfitGuruCouchCoreDbClientsJson(appName).get('profitGuruUsersAllEntitlements_', function (err, data) {
                if (!err) {
                    resolve(data);
                } else {
                    console.log('Could not get the Entitlements');
                    reject(err);
                }
            });
        });
    };
};

module.exports = new coreCouchHandler();