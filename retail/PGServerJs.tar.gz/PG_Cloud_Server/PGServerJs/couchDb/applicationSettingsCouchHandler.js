var _self;
const logger = require('../common/Logger');

// This seems an overkill, but safe way. 
// kind A is ignored. 
// https://www.npmjs.com/package/deep-diff

function applicationSettingsCouchHandler(couchMain) {

    couchMain = couchMain ? couchMain : require('./couchDBMain.js');
    _self = this;

    this.getApplicationSettings = function (appName) {
        return couchMain.getProfitGuruCouchCoreDbClientsJson(appName).get('profitGuruApplicationSettings_').then(function (resp) {
            return resp[0]; //resp[0] is the body
        });
    };

    function updateAppLocalsSettingsAfterUpdate(app, updatedSettings) {
        //Globally accross the application we are using this locals app settings, so need to keep them updated
        app.locals.applicationSettings = updatedSettings;
        require('../common/configState').setApplicationSettings(updatedSettings);
    }

    function updateValue(settingJson, path, rhs, mode) {
        let temp = settingJson;
        for (let i = 0; i < path.length - 1; i++) {
            temp = temp[path[i]];
        }
        if (mode === 'A')
            temp[path[path.length - 1]].push(rhs);
        else
            temp[path[path.length - 1]] = rhs;
    }

    const deepCheckExcludedField = ['barcode', 'kotPrinter', 'invoiceCheckpointValue', 'CustomInput'];
    function excludeFromDeepCheck(path) {
        if (!path || !path.length) return false;
        if (deepCheckExcludedField.includes(path[0])) return true;
        else if (path[0] == "terminals" && path[2] && deepCheckExcludedField.includes(path[2])) {
            return true;
        }
        return false;
    }

    this.updateApplicationSettings = function (req, appName) {
        var userApplicationSettings4Update = req.body;

        var fatureDiff = require('deep-diff');

        return new Promise(function (resolve, reject) {
            return _self.getApplicationSettings(appName).then(function (applictionSettings4Update) {
                function prefilter(path, key) {
                    return (['_id', '_rev'].indexOf(key) >= 0);
                }
                var applicationSettingsDiffResultBeforeMerge = fatureDiff(applictionSettings4Update, userApplicationSettings4Update, prefilter);
                if (!applicationSettingsDiffResultBeforeMerge) {
                    resolve('Nothing to update');
                    return;
                }
                let skipDeepCheck = false;
                let path0 = "";
                applicationSettingsDiffResultBeforeMerge.forEach(function (feature4Update) {
                    /**
                     *  todo handeling multiple taxes
                     */
                    path0 = feature4Update.path[0];
                    if (excludeFromDeepCheck(feature4Update.path)) {
                        skipDeepCheck = true;
                    }
                    if (!skipDeepCheck) {
                        if (feature4Update.kind === 'E') {
                            if (['_id', '_rev'].indexOf(feature4Update.path[0]) < 0) {
                                logger.info('Changingn ' + feature4Update.path[0], ' setting from ' + feature4Update.lhs, 'to', feature4Update.rhs);
                                updateValue(applictionSettings4Update, feature4Update.path, feature4Update.rhs, feature4Update.kind);
                            }
                        } else if (feature4Update.kind === 'D') {
                            logger.error('Fine Update documents has sent few properties only');
                        } else if (feature4Update.kind === 'N') {
                            if (['terminals'].indexOf(feature4Update.path[0]) === 0 && feature4Update.path.length === 2) {
                                logger.info('Changingn ' + feature4Update.path[0], ' setting from ' + feature4Update.lhs, 'to', feature4Update.rhs);

                                //updating default values to terminal settings
                                let appSettingsDoc = require('../config/profitguruCoreConfig/profitGuruApplicationSettings.json');
                                for (let i = 0; i < appSettingsDoc.terminalConfigs.length; i++) {
                                    feature4Update.rhs[appSettingsDoc.terminalConfigs[i]] = appSettingsDoc[appSettingsDoc.terminalConfigs[i]];
                                }
                                updateValue(applictionSettings4Update, feature4Update.path, feature4Update.rhs, feature4Update.kind);
                            } else {
                                applictionSettings4Update[feature4Update.path[0]] = feature4Update.rhs;
                                logger.error('Warning: Seems update document has a extra property=' + JSON.stringify(feature4Update) + ' which would be ignored!!');
                            }
                        } else if (feature4Update.kind === 'A') {
                            if (['_id', '_rev'].indexOf(feature4Update.path[0]) < 0) {
                                logger.info('Changingn ' + feature4Update.path[0], ' setting from ' + feature4Update.lhs, 'to', feature4Update.rhs);
                                updateValue(applictionSettings4Update, feature4Update.path, feature4Update.item.rhs, feature4Update.kind);
                            }

                        } else {
                            logger.error(feature4Update);
                            reject(' Error while updating Settings, Something wiered happened: Reason Settings Value=' + JSON.stringify(feature4Update));

                        }
                    }

                });

                // if (skipDeepCheck) applictionSettings4Update[path0] = userApplicationSettings4Update[path0];
                if (skipDeepCheck) applictionSettings4Update = userApplicationSettings4Update;
                var applicationSettingsDiffResultrAfteMerge = fatureDiff(applictionSettings4Update, userApplicationSettings4Update, prefilter);
                if (!applicationSettingsDiffResultrAfteMerge) {
                    return couchMain.getProfitGuruCouchCoreDbClientsJson(appName).head('profitGuruApplicationSettings_', function (err, _, header) {
                        if (!err) {
                            applictionSettings4Update._id = 'profitGuruApplicationSettings_';
                            applictionSettings4Update._rev = JSON.parse(header.etag);
                            return couchMain.getProfitGuruCouchCoreDbClientsJson(appName).insert(applictionSettings4Update, 'profitGuruApplicationSettings_',
                                function (err) {
                                    if (err) {
                                        reject(" profitGuruApplicationSettings_ Update failed" + err);
                                    } else {
                                        logger.info('Successfully Updated profitGuruApplicationSettings');
                                        updateAppLocalsSettingsAfterUpdate(req.app, applictionSettings4Update)
                                        resolve(applictionSettings4Update);
                                    }
                                });
                        } else {

                            reject('profitGuruApplicationSettings  Update Error' + err);
                        }
                    });
                } else {
                    logger.error(applicationSettingsDiffResultrAfteMerge);
                    reject("profitGuruApplicationSettings_ Update failed(Merge failed) ");
                }
            });
        });
    };

    return this;
}

module.exports = function (couchMain) {
    return applicationSettingsCouchHandler(couchMain);
};