require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});
require('shelljs/global');
var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .alias('s', 'serverId')
    .default('s', '')
    .alias('a', 'app')
    .default('a', 'retail')
    .help('h')
    .alias('h', 'help')
    .argv;
run();
async function run() {
    await compareAllDBs();
    // await compareCouchAndPouchDB();
}
async function compareAllDBs() {
    var couchDbManager = require('./couchDbManager');
    console.log('Incase of module not found error , run following command');
    console.log('npm install -g couchdiff');
    couchDbManager.compareDBs(argv.s)
        .then(function(resp) {
            console.log('Done!!');
            process.exit(0);
        }).catch(function(reason) {
            console.log(reason);
        });
}

async function compareCouchAndPouchDB() {
    try {

        console.log("====COMPARING " + "local to remote : couch -pouch main" + ' STARTED======');
        let localDbName = 'local2remote';
        let couchdbUrl = 'http://couchadmin:test@' + 'localhost' + ':5984';

        let remoteDBName = 'pg_collection_' + argv.a + '_maindb';
        let localDB = couchdbUrl + '/' + localDbName;
        let cloudDB = couchdbUrl + '/' + remoteDBName;
        let compareCmd = 'couchdiff ' + localDB + ' ' + cloudDB;
        console.log(compareCmd);
        exec(compareCmd);
        console.log('======DONE ' + "local to remote : couch -pouch main" + ' =====');
        process.exit(0);

    } catch (err) {
        console.log(err);
        logger.error(err);
        process.exit(1);
    }
};