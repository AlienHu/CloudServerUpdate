//http://couchadmin:test@51.15.133.206:5984/pg_collection_cloud_retail_maindb_54-53-ed-23-c4-ef
var appRoot = require('app-root-path');
var moment = require('moment');
var fs = require('fs');

var noSales = [];
var noPurchases = [];
var noCmps = [];
var results = [];
var cmp2Old = [];
var salesOlerThan2Months = [];
var purchasesOlderThan2Months = [];
async function iterateIps() {
    let ipsJson = require(appRoot + '/dbManagers/ips.json');
    let ips = ipsJson.ips;
    //ips.length
    // ips excludes    TITO-production:"51.15.206.208",<deleted>old production: 51.15.200.57,163.172.166.242,51.15.254.39
    for (let i = 0; i < ips.length; i++) {
        await getLatestTransDoc(ips[i]);
    }

    var myDate = new Date();
    var hours = myDate.getHours();
    var minutes = myDate.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;

    let time = myDate.getDate() + "-" + (myDate.getMonth() + 1) + "-" + myDate.getFullYear() + "_" + strTime;
    console.log("No sales");
    console.log(noSales);
    fs.writeFile('noSales_' + time + '.txt', noSales, function(err, data) {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });
    // console.table(noSales);
    console.log("no Purchases_");
    // console.table(noPurchases);
    fs.writeFile('noPurchases_' + time + '.txt', noPurchases, function(err, data) {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });
    // console.log(noPurchases);
    console.log("Result: ");
    // console.table(results);
    fs.writeFile('allResults_' + time + '.txt', results, function(err, data) {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });
    console.log(results);
    fs.writeFile('oldCampaigns_' + time + '.txt', cmp2Old, function(err, data) {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });
    fs.writeFile('oldSales_' + time + '.txt', salesOlerThan2Months, function(err, data) {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });
    fs.writeFile('oldPurchase_' + time + '.txt', purchasesOlderThan2Months, function(err, data) {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });
    //noCmps
    fs.writeFile('nocampaign_' + time + '.txt', noCmps, function(err, data) {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });
}

async function getLatestTransDoc(ip) {
    try {
        // ip = '51.15.244.231';
        let db = require('nano-blue')("http://couchadmin:test@" + ip + ":5984");
        // let saleDoc = await db.view('all_sales_info', "all_time", {
        //     limit: 1,
        //     descending: true
        // });
        let getlist = await db.db.list();
        let dbList = getlist[0];
        for (let j = 0; j < dbList.length; j++) {
            if (dbList[j].indexOf('maindb') > -1) {
                let maindb = db.use(dbList[j]);
                await db_calls(maindb, ip, dbList[j]);
            } else {
                continue;
            }
        }
    } catch (err) {
        console.log(err);

        console.log("No sales");
        console.table(noSales);
        console.log(noSales);
        console.log("no Purchases");
        console.table(noPurchases);
        console.log(noPurchases);
    }

    // return db.view(designDocName, viewName, params).spread(function(body, header) {
    //     return body.rows;
    //     console.log(body.rows);
    // }).catch(function(err) {
    //     console.log(err);
    //     return [];
    // });

}
async function db_calls(maindb, ip, dbName) {
    let designDocName = 'all_sales_info';
    let viewName = "all_time";
    let params = {
        limit: 1,
        descending: true
    };
    try {
        console.log("STARTING >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        console.log('IP: ' + ip + ' dbName: ' + dbName);
        if (dbName.indexOf('crm') > -1) {
            params = {
                startkey: 'cmp_',
                endkey: 'cmp_z'
            };
            // params.startkey = 'cmp_';
            // params.endkey = 'cmp_z';
            let crmDocs = await maindb.fetch({}, params);
            let lastDoc = crmDocs[0].rows[crmDocs[0].rows.length - 1];
            if (crmDocs[0].rows.length) {
                var timestamp = lastDoc.id.substr(lastDoc.id.indexOf('_') + 1, lastDoc.id.length);
                let time = moment(parseInt(timestamp));
                results.push(
                    "ip : " + ip +
                    "- dbName: " + dbName +
                    "- id: " + lastDoc.id +
                    "-time: " + time.format('MMMM Do YYYY, h:mm:ss a') + '\r\n'
                );

                if (time.month() < (moment().month() - 2)) {
                    console.log('Month: ' + moment(timestamp).month());
                    cmp2Old.push(
                        "ip : " + ip +
                        "- dbName: " + dbName +
                        "- id: " + lastDoc.id +
                        "-time: " + time.format('MMMM Do YYYY, h:mm:ss a') + '\r\n'
                    );
                }

                console.log('CAMPAIGN >> ID : ' + lastDoc.id + ' TIME : ' + moment(timestamp).format('MMMM Do YYYY, h:mm:ss a'));
            } else {
                noCmps.push(
                    "ip: " + ip +
                    "- dbName: " + dbName + '\n\r'
                );
                console.log('No Sales')
            }
        } else {
            let saleDoc = await maindb.view(designDocName, viewName, params);
            if (saleDoc[0].rows.length) {
                results.push(
                    "ip: " + ip +
                    "- dbName: " + dbName +
                    "- id: " + saleDoc[0].rows[0].id +
                    "- time: " + moment(saleDoc[0].rows[0].key).format('MMMM Do YYYY, h:mm:ss a') + '\n\r'
                );
                if (moment(saleDoc[0].rows[0].key).month() < (moment().month() - 2)) {

                    salesOlerThan2Months.push(
                        "ip: " + ip +
                        "- dbName: " + dbName +
                        "- id: " + saleDoc[0].rows[0].id +
                        "- time: " + moment(saleDoc[0].rows[0].key).format('MMMM Do YYYY, h:mm:ss a') + '\n\r'
                    );
                }
                console.log('Month: ' + moment(saleDoc[0].rows[0].key).month());
                console.log('SALE >> ID : ' + saleDoc[0].rows[0].id + ' TIME : ' + moment(saleDoc[0].rows[0].key).format('MMMM Do YYYY, h:mm:ss a'));
            } else {
                noSales.push(
                    "ip: " + ip +
                    "- dbName: " + dbName + '\n\r'
                );
                console.log('No Sales')
            }
            let purchaseDoc = await maindb.view('all_receivings_info', 'all_time', params);
            if (purchaseDoc[0].rows.length) {
                results.push(
                    "ip: " + ip +
                    "- dbName: " + dbName +
                    "- id: " + purchaseDoc[0].rows[0].id +
                    "- time: " + moment(purchaseDoc[0].rows[0].key).format('MMMM Do YYYY, h:mm:ss a') + '\n\r'
                );
                if (moment(purchaseDoc[0].rows[0].key).month() < (moment().month() - 2)) {
                    purchasesOlderThan2Months.push(
                        "ip: " + ip +
                        "- dbName: " + dbName +
                        "- id: " + purchaseDoc[0].rows[0].id +
                        "- time: " + moment(purchaseDoc[0].rows[0].key).format('MMMM Do YYYY, h:mm:ss a') + '\n\r'
                    );
                }
                console.log('Month: ' + moment(purchaseDoc[0].rows[0].key).month);
                console.log('PURCHASE >> ID : ' + purchaseDoc[0].rows[0].id + ' TIME : ' + moment(purchaseDoc[0].rows[0].key).format('MMMM Do YYYY, h:mm:ss a'));

            } else {
                noPurchases.push(
                    "ip: " + ip +
                    "- dbName: " + dbName + '\n\r'
                );
                console.log('No Purchases')
            }
            console.log("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<END\n")
        }
    } catch (err) {
        console.log(err);
    }
}
return iterateIps();