require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDBUtils = require('../controllers/common/CouchDBUtils');
const getCouchAuthInfo = require('../common/getCouchAuthInfo').getCouchAuthInfo;

const mainDBInstance = couchDBUtils.getMainCouchDB();
async function getAllItemsByNameArr() {
    const docsToUpdate = [];
    const itemNameArr = [
        "Akshyakalpa Amruth Milk",
        "Akshyakalpa Butter",
        "Akshyakalpa Curd",
        "Akshyakalpa Ghee - 200ml",
        "Akshyakalpa Ghee - 500ml",
        "Akshyakalpa Paneer",
        "Akshyakalpa Raw Milk",
        "Bio Fresh Egg",
        "exc"
    ]
    await getCouchAuthInfo();
    let docsArr = await couchDBUtils.getTransView('all_items_data', 'all_purchase_order_items', { include_docs: true }, mainDBInstance);
    for (let i = 0; i < docsArr.length; i++) {
        let bFlag = false;
        const thisItemInfo = docsArr[i].info;
        for (let j = 0; j < itemNameArr.length; j++) {
            if (thisItemInfo.name.toLowerCase() == itemNameArr[j].toLowerCase()) {
                bFlag = true;
                break;
            }
        }
        if (bFlag) {
            console.log('true: ' + thisItemInfo.name);
            thisItemInfo.bAvailableForPurchaseOrder = true;
            docsToUpdate.push(docsArr[i])
        } else {
            console.log('false: ' + thisItemInfo.name);
            thisItemInfo.bAvailableForPurchaseOrder = false;
            docsToUpdate.push(docsArr[i])
        }
    }
    if (docsToUpdate.length > 0) {
        await couchDBUtils.bulkInsert(mainDBInstance, docsToUpdate);
    }
}


getAllItemsByNameArr().then(() => {
    console.log('Done');
    process.exit(0);
});