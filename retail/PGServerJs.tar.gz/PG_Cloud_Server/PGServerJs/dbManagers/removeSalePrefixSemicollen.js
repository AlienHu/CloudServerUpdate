'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDbManager = require('./couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const coreDBInstance = couchDBUtils.getCoreCouchDB();
const utils = require('../controllers/common/Utils');
const CLONE = utils.clone;

runTask();
async function runTask() {

    await correctSales();
    process.exit(0);
}

async function correctSales() {
    let resp = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
    console.log('<' + resp.length + '>');
    let newDocs = [];

    for (let i = 0; i < resp.length; i++) {
        // console.log(resp[i].doc.sales_info.split(';').length);
        let info = resp[i].doc.sales_info;
        if (info.split(';').length === 39) {
            const whereIsPrefix = 2; //['_id', 'num', 'invoicePrefix',....
            let tempIndex = 0;
            for (let i = 0; i < whereIsPrefix; i++) {
                tempIndex++;
                tempIndex = info.indexOf(';', tempIndex);
            }
            resp[i].doc.sales_info = info.slice(0, tempIndex) + ':' + info.slice(++tempIndex, info.length);

            // console.log("removed prefix semicollen, now total collens are : " + resp[i].doc.sales_info.split(';').length);
            // console.log(info, '\n*************************\n', resp[i].doc.sales_info);
            newDocs.push(resp[i].doc);
        }
    }
    console.log('Total documents to be updated : ' + newDocs.length);
    await couchDBUtils.bulkDocs(newDocs, mainDBInstance);

}
