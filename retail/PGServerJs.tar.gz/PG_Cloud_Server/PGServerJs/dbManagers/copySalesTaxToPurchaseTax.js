'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDbManager = require('./couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const utils = require('../controllers/common/Utils');
const CLONE = utils.clone;

removeItemTaxes();
async function removeItemTaxes() {
    // await correctSaleIds();
    await removeAllTaxes();
    process.exit(0);
}

async function removeAllTaxes() {
    let allIems = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
    let docsToUpdate = [];
    for (var i = 0; i < allIems.length; i++) {
        allIems[i].doc.info.purchaseTaxes = allIems[i].doc.info.salesTaxes;
        docsToUpdate.push(allIems[i].doc);
    }

    await couchDBUtils.bulkInsert(mainDBInstance, docsToUpdate);
}