/*
THIS CODE IS WRITTEN FOR SPECIFIC PROBLEM

ISSUE:
undefined_undefined in item and inventory docs for attributes

IP http://51.15.230.175:5984/pg_collection_retail_maindb
ASSUMPTIONS:
- only one variant, variant_1 is hardcoded here
- item docs are having one stockkeys to change
*/

const couchDBUtils = require('../controllers/common/CouchDBUtils');
const Utils = require('../controllers/common/Utils');
const CLONE = Utils.clone;
let db;
const nano = require('nano-blue')('http://couchadmin:test@localhost:5984');
db = nano.db.use('pg_collection_retail_maindb');
const usersdb = nano.db.use('_users');
var fs = require('fs');

const readFile = (path, opts = 'utf8') =>
    new Promise((res, rej) => {
        fs.readFile(path, opts, (err, data) => {
            if (err) rej(err)
            else res(data)
        })
    })

const writeFile = (path, data, opts = 'utf8') =>
    new Promise((res, rej) => {
        fs.writeFile(path, data, opts, (err) => {
            if (err) rej(err)
            else res()
        })
    })


console.log('modules imported!')

const getVariantDocs = async function () {
    console.log('will fetch variants...');
    // let variantsDoc = [];
    // let promise = [];
    let promiseResp = [];
    try {
        // promise.push(db.get('variant_1'));
        // promise.push(db.get('variant_2'));
        // promise.push(db.get('variant_3'));

        let params = {
            include_docs: true
        };
        let variants = await couchDBUtils.getView('all_variants_data', 'all_variants_unique_data', params, db);


        promiseResp = variants.map(v => v.doc);


        // promiseResp = await Promise.all(promise);
    } catch (err) {
        throw 'Variant query failed';
    }
    // console.log(promiseResp);
    return promiseResp;
}

const getItems = async function () {
    console.log('will fetch items...');
    let items = [];
    try {
        items = await couchDBUtils.getView('all_items_data', 'item-hash', {
            include_docs: true
        }, db);
    } catch (err) {
        throw 'Item query failed';
    }
    return items;
}

const getSales = async function () {
    console.log('will fetch sales...');
    let sales = [];
    try {
        sales = await couchDBUtils.getView('all_sales_info', 'sales_info', {
            include_docs: true
        }, db);
    } catch (err) {
        throw 'sales query failed';
    }
    return sales;
}

const getSalesReturn = async function () {
    console.log('will fetch salesReturn...');
    let sales = [];
    try {
        sales = await couchDBUtils.getView('all_sales_info', 'sales_return_info', {
            include_docs: true
        }, db);
    } catch (err) {
        throw 'salesReturn query failed';
    }
    return sales;
}

const fixKeys = async function () {
    console.log('starting fixing...');
    let allVariants = await getVariantDocs();
    let items = await getItems();
    let ctr = 0;
    let notThere = [];
    let updatedItems = [];
    let allV = '';
    let wItems = [];
    for (let i = 0; i < items.length; i++) {
        let item = items[i].doc;
        let forInventory = {};
        let timeStampForInventory = {};

        if (!item.batches || !item.info.attributes.length) {
            continue;
        }
        item.info.attributes = [];
        /*
            THIS CODE IS WRITTEN FOR SPECIFIC PROBLEM
    
            ISSUE:
            undefined_undefined in item and inventory docs for attributes
    
            IP http://51.15.230.175:5984/pg_collection_retail_maindb
            ASSUMPTIONS:
            - only one variant, variant_1 is hardcoded here
            - item docs are having one stockkeys to change
            */
        let batchKeys = Object.keys(item.batches);
        if (!batchKeys.length) continue;
        let bDirty = false;
        for (let j = 0; j < batchKeys.length; j++) {
            let thisBatchKey = batchKeys[j];

            if (thisBatchKey.indexOf('undefined') == -1) {
                continue;
            }
            // split
            let skuNameArray = item.batches[thisBatchKey].skuName.split("/");
            // if (skuNameArray.length > 3) {
            //     console.log("four var==" + item._id + skuNameArray.length);
            //     // continue;
            // }

            //find the index of batch
            let indexOfBatchToSlice = '';
            // let s1 = '';
            // if (item.batches[thisBatchKey].batchId) {
            //     indexOfBatchToSlice = thisBatchKey.indexOf(item.batches[thisBatchKey].batchId);
            //     s1 = item.batches[thisBatchKey].batchId;
            // } else if (item.batches[thisBatchKey].timeStamp) {
            //     indexOfBatchToSlice = thisBatchKey.indexOf(item.batches[thisBatchKey].timeStamp);
            //     s1 = item.batches[thisBatchKey].timeStamp;
            // } else {
            //     continue;
            // }

            let f1Array = thisBatchKey.split("_");

            indexOfBatchToSlice = thisBatchKey.indexOf(f1Array[3]);
            indexOfBatchToSlice = indexOfBatchToSlice + f1Array[3].length;

            // indexOfBatchToSlice = indexOfBatchToSlice + s1.length;
            let slicedthisBatchKey = thisBatchKey.slice(0, indexOfBatchToSlice);

            let thisBatch = CLONE(item.batches[thisBatchKey]);
            let objectKeys = [];
            let valueKeys = [];

            for (let e = 0; e < skuNameArray.length; e++) {
                // if (e === 0) {
                //     continue;
                // }
                let bTrue = false;
                for (let i = 0; i < allVariants.length; i++) {
                    let variantKeys = Object.keys(allVariants[i].values);

                    for (let j = 0; j < variantKeys.length; j++) {
                        if (allVariants[i].values[variantKeys[j]].name.trim().toUpperCase() === skuNameArray[e].trim().toUpperCase()) {

                            if (objectKeys.indexOf(allVariants[i].id) == -1) {
                                valueKeys.push(variantKeys[j]);
                                objectKeys.push(allVariants[i].id);
                                item.info.attributes.push(allVariants[i].id);
                            }
                            bTrue = true
                            break;
                        }
                    }

                }

                // uncomment the code to check which atribuite is not exist in the db
                if (!bTrue) {
                    if (notThere.indexOf(skuNameArray[e]) == -1) {
                        notThere.push(skuNameArray[e]);
                    }
                    if (wItems.indexOf(item._id) === -1) {
                        wItems.push(item._id);
                        console.error(item._id);
                    }
                    // console.log(notThere);
                }

            }


            thisBatch.attributeInfo = {};
            let keyForInventory = '';
            for (let t = 0; t < objectKeys.length; t++) {
                slicedthisBatchKey = slicedthisBatchKey + '_' + objectKeys[t] + '_' + valueKeys[t];
                thisBatch.attributeInfo[objectKeys[t]] = valueKeys[t];
                keyForInventory = keyForInventory + '_' + objectKeys[t] + '_' + valueKeys[t];
            }

            thisBatch.stockKey = slicedthisBatchKey;
            item.batches[slicedthisBatchKey] = thisBatch;
            forInventory[item.batches[slicedthisBatchKey].skuName] = keyForInventory;
            timeStampForInventory[item.batches[slicedthisBatchKey].skuName] = f1Array[3];
            delete (item.batches[thisBatchKey]);
            bDirty = true;
            ctr++;
            // if (wItems.indexOf(item._id) === -1) {
            //     wItems.push(item._id);
            //     console.error(item._id);
            // }
        }
        let inventoryDoc = {};
        if (bDirty) {
            updatedItems.push(item); // push item is modified
            inventoryDoc = await couchDBUtils.getDoc('inventory_' + item.item_id, db);

            let transactions = Object.keys(inventoryDoc.transactions);

            for (let k = 0; k < transactions.length; k++) {
                let thisTransactionKey = transactions[k];
                if (thisTransactionKey.indexOf('undefined') == -1) {
                    continue;
                }
                let transDoc = CLONE(inventoryDoc.transactions[thisTransactionKey]);

                let timeStampIndex = thisTransactionKey.lastIndexOf(timeStampForInventory[transDoc.trans_skuName])
                timeStampIndex = timeStampIndex + timeStampForInventory[transDoc.trans_skuName].length
                let newTransKey = thisTransactionKey.slice(0, timeStampIndex);

                newTransKey = newTransKey.concat(forInventory[transDoc.trans_skuName]);

                inventoryDoc.transactions[newTransKey] = transDoc;
                delete (inventoryDoc.transactions[thisTransactionKey]);
                // console.log('Fixed ' + thisTransactionKey + ' --> ' + newTransKey);
            }
        } else {
            // console.error(item._id);
            // console.error('not expected to come here');
            continue;
        }

        let updatedTransactions = Object.keys(inventoryDoc.transactions);

        const getMatchedKey = function (key) {
            for (m = 0; m < updatedTransactions.length; m++) {
                if (updatedTransactions[m].indexOf(key) > -1) {
                    return updatedTransactions[m];
                }
            }
            return '';
        }

        let inventoryStockKeys = Object.keys(inventoryDoc.stock);
        for (let k = 0; k < inventoryStockKeys.length; k++) {
            let thisInventoryKey = inventoryStockKeys[k];
            // if it manuvally created
            if (thisInventoryKey.indexOf('undefined') == -1) {
                continue;
            }

            let firstUndefinedPositionArray = thisInventoryKey.split("_");

            let firstUndefinedPosition = thisInventoryKey.indexOf(firstUndefinedPositionArray[3]);
            firstUndefinedPosition = firstUndefinedPosition + firstUndefinedPositionArray[3].length;

            let keyToCheck = thisInventoryKey.substr(0, firstUndefinedPosition);
            let newKey = getMatchedKey(keyToCheck);
            newKey = newKey.substr(newKey.indexOf('id_'))
            if (newKey) {
                let invStock = CLONE(inventoryDoc.stock[thisInventoryKey]);
                inventoryDoc.stock[newKey] = invStock;
                delete (inventoryDoc.stock[thisInventoryKey]);
            }
        }

        updatedItems.push(inventoryDoc);
    }
    for (let i = 0; i < allVariants.length; i++) {
        let variantKeys = Object.keys(allVariants[i].values);
        allV += '\n-----------------------------' + allVariants[i].id + '--------------------';
        for (let j = 0; j < variantKeys.length; j++) {
            allV += '\n' + allVariants[i].values[variantKeys[j]].name;
        }

    }
    allV += '\n************** attributes are not exists **************\n' + notThere.toString();
    allV += '\n ---------- items (' + wItems.length + ')-----------\n';
    allV += wItems.toString();
    // await writeFile("/tmp/test", allV);
    // }
    // console.log('fixed: ' + ctr);
    return updatedItems;
}

// console.log('Script will start now...');
// fixKeys().then(function(items) {
//     console.log('...will update to db');
//     console.log(items);
//     couchDBUtils.bulkDocs(items, db).then(function(resp) {
//         console.log('Variants are fixed');
//         process.exit(0);
//     }).catch(function(err) {
//         console.error(err);
//     })
// }).catch(function(err) {
//     console.error(err);
//     confirm.error('Some error occured');
//     process.exit(1);
// });
async function run1() {
    console.log('Script will start now for items...');
    try {
        let items = await fixKeys();
        console.log('...will update to db');
        console.log(items, items.length);
        await couchDBUtils.bulkDocs(items, db);
        console.log(' items Variants are fixed');
        // process.exit(0);
    } catch (err) {
        console.error(err);
        confirm.error('Some error occured');
        process.exit(1);
    };
};

var commonFields = ['discount'];
var intFields = ['item_id', 'line', 'imeiCount', 'categoryId', 'num', 'invoiceCheckpoint', 'sale_time', 'receiving_time', 'time', 'supplier_id', 'customer_id', 'tableNo', 'pProfileId', 'parentId'];
var floatFields = ['price', 'baseUnitPrice', 'sellingPriceExcludingTax', 'totalTaxPercent', 'totalPurchaseTaxPercent', 'purchasePrice', 'mrp', 'reorder_level', 'total', 'subTotal', 'subtotal', 'cost', 'profit', 'quantity', 'deliveryCharge', 'pending_amount', 'discount', 'discount_percent', 'quantity_purchased', 'sellingPrice', 'gDiscountPercent', 'loyaltyEarned', 'rmPnts'];
var objFields = ['wcInfo', 'slab', 'taxes', 'taxDetailed', 'shippingDetails', 'globalDiscountInfo', 'imeiNumbers', 'unitDocs', 'chargesList', 'chargesTaxList', 'unitsInfo', 'itemTaxList', 'uniqueDetails'];
var boolFields = ['isNew', 'interState', 'is_serialized', 'hasBatchNumber', 'bOTG', 'hasExpiryDate', 'bSPTaxInclusive', 'bPPTaxInclusive', 'isWarranty'];

function converValue(val, key) {
    // var val = itemVals[iF];
    if (commonFields.indexOf(key) !== -1 && _self.bStringifiedJSON(val)) {
        val = JSON.parse(val);
    } else if (intFields.indexOf(key) !== -1) {
        val = val ? parseInt(val) : 0;
    } else if (floatFields.indexOf(key) !== -1) {
        val = val ? parseFloat(val) : 0;
    } else if (objFields.indexOf(key) !== -1) {
        val = val ? JSON.parse(val) : (key === 'wcInfo' ? undefined : {});
    } else if (boolFields.indexOf(key) !== -1) {
        if (val && (val.toLowerCase() === 'yes' || val.toLowerCase() === 'true')) {
            val = true;
        } else {
            val = false;
        }
    }
    return val;
}
const transformSaleDoc = function (doc, type) {
    var infoKey = 'sales_info';
    var itemsKey = 'sale_items';
    var idKey = 'sale_id';
    let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts'];
    let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
    if (type === 'saleReturn') {
        idKey = 'id';
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts'];
    } else if (type === 'purchaseReturn') {
        idKey = 'id';
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    } else if (type === 'purchase') {
        idKey = 'receiving_id';
        infoKey = 'receivings_info';
        itemsKey = 'receiving_items';
        infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    }

    var items = doc[itemsKey];
    var info = doc[infoKey];
    var itemsArray = [];

    for (var q = 0; q < items.length; q++) {
        var itemVals = items[q].split(';');
        var itemInfo = {};
        for (var iF = 0; iF < itemFields.length; iF++) {
            var val = converValue(itemVals[iF], itemFields[iF]);

            itemInfo[itemFields[iF]] = val;
        }
        itemsArray.push(itemInfo);
    }
    items = itemsArray;
    var salesInfoVals = info.split(';');
    var salesInfo = {};
    salesInfo._id = salesInfoVals[0];
    for (var s = 0; s < infoFields.length; s++) {
        var infoVal = converValue(salesInfoVals[s + 1], infoFields[s]);
        salesInfo[infoFields[s]] = infoVal;
    }
    info = salesInfo;
    info[idKey] = doc[idKey];
    doc[infoKey] = info;
    doc[itemsKey] = items;
    // var paymentVals = doc.payments.split(';');
    // var payTypes = [];
    // for (var q = 0; q < paymentVals.length; q++) {
    //     if (!paymentVals[q]) {
    //         continue;
    //     } else {
    //         var payType = {
    //             payment_type: paymentVals[q],
    //             payment_amount: parseFloat(paymentVals[q + 1]),
    //             returnAmt: parseFloat(paymentVals[q + 2])
    //         }
    //         payTypes.push(payType);
    //     }
    //     q += 2;
    // }
    doc.payments = JSON.parse(doc.payments); //payTypes;
    return doc

}
function getValString(val) {
    if (val === undefined || val === null) {
        val = ""
    } else if (typeof val === "object") {
        val = JSON.stringify(val);
    }
    return val;
}
const encodeTransDoc = async function (doc, type) {
    var infoKey = 'sales_info';
    var itemsKey = 'sale_items';
    /**
     * whene you change the fields array or encodeTransDoc or transformSalesDoc change in the following places as well
     * 1.commolib (currentfile)
     * 2. maindbViews (2 places ) : update_customer view and delta_pending_amount 
     * 3. computeUtils in profitGuruCore/Services/Reports/
     */
    let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts'];
    let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
    if (type === 'saleReturn') {
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts'];
    } else if (type === 'purchaseReturn') {
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    } else if (type === 'purchase') {
        infoKey = 'receivings_info';
        itemsKey = 'receiving_items';
        infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    }
    if (doc[infoKey].customer_id) {
        var customerInfo = await couchDBUtils.getDoc('customer_' + doc[infoKey].customer_id, db);
        var checkCompanyName = customerInfo.company_name ? customerInfo.company_name : '';
        var checkLastName = customerInfo.last_name ? customerInfo.last_name : '';
        doc[infoKey].customer = checkCompanyName + ' ' + customerInfo.first_name + ' ' + checkLastName;
    }
    if (doc[infoKey].employee_id) {
        var empInfo = await couchDBUtils.getDoc('org.couchdb.user:' + doc[infoKey].employee_id, usersdb);
        doc[infoKey].employee = empInfo.first_name ? empInfo.first_name + ' ' + empInfo.last_name : doc[infoKey].employee_id;
    }
    if (doc[infoKey].supplier_id) {
        var supInfo = await couchDBUtils.getDoc('supplier_' + doc[infoKey].supplier_id, db);
        var checkCompanyName = supInfo.company_name ? supInfo.company_name : '';
        var checkLastName = supInfo.last_name ? supInfo.last_name : '';
        doc[infoKey].supplier = checkCompanyName + ' ' + supInfo.first_name + ' ' + checkLastName;
    }
    let info = doc[infoKey];
    if (type === 'saleReturn') {
        info.num = doc.id;
    }
    let items = doc[itemsKey];
    let transInfo = doc._id + ';';
    for (let i = 0; i < infoFields.length; i++) {
        let val = getValString(info[infoFields[i]])
        transInfo += val + ';';
    }
    let itemsList = [];
    for (var j = 0; j < items.length; j++) {
        let itemString = "";
        for (let k = 0; k < itemFields.length; k++) {
            let fieldVal = getValString(items[j][itemFields[k]])
            itemString += fieldVal + ';';
        }
        itemsList.push(itemString);
    }
    let payments = JSON.stringify(doc.payments);
    // let payments = "";
    // for (let l = 0; l < doc.payments.length; l++) {
    //     payments += doc.payments[l].payment_type + ';' + doc.payments[l].payment_amount + ';' + (doc.payments[l].returnAmt ? doc.payments[l].returnAmt : 0) + ';';
    // }
    doc.payments = payments;
    doc[infoKey] = transInfo;
    doc[itemsKey] = itemsList;
    return doc;

}
const fixKeysForSale = async function () {
    console.log('starting fixing sales...');

    let items = await getItems();
    let sales = await getSales();
    let updatedSale = [];
    for (let i = 0; i < sales.length; i++) {

        if (sales[i].doc.sale_items.toString().indexOf('undefined') === -1) continue;

        let sale = transformSaleDoc(sales[i].doc);
        //if necessary because in some sale 'sale items are not there'
        // if(sale.sales_info.type === 3){
        //     continue;
        // }
        // let saleItems = sale.sale_items;

        for (let j = 0; j < sale.sale_items.length; j++) {
            let saleItems = sale.sale_items[j];
            // console.log(saleItems);
            bfoundSale = true;
            if (!saleItems.skuName) {
                continue;
            }
            let gotItem = false;
            for (let k = 0; k < items.length; k++) {
                let item = items[k].doc;
                if (gotItem) {
                    gotItem = false;
                    break;
                }
                if (saleItems.item_id === item.item_id) {

                    //batches
                    let batchKeys = Object.keys(item.batches);
                    if (!batchKeys.length) continue;
                    for (let j = 0; j < batchKeys.length; j++) {
                        let thisBatchKey = batchKeys[j];
                        let thisBatch = CLONE(item.batches[thisBatchKey]);
                        if (saleItems.skuName === thisBatch.skuName) {
                            saleItems.attributeInfo = {}
                            saleItems.stockKey = thisBatch.stockKey;
                            saleItems.attributeInfo = thisBatch.attributeInfo;
                            gotItem = true;
                            break;
                        }
                    }
                    //batch end
                }
            }
        }
        let enSale = await encodeTransDoc(sale);
        updatedSale.push(enSale);
    }
    return updatedSale;
};

// //for sale
async function run2() {
    console.log('Script will start now for sale...');
    try {
        let sales = await fixKeysForSale();
        console.log('...will update to db');
        console.log(sales, sales.length);
        await couchDBUtils.bulkDocs(sales, db);
        console.log(' sales Variants are fixed');
        // process.exit(0);
    } catch (err) {
        console.error(err);
        confirm.error('Some error occured');
        process.exit(1);
    };
};

const fixKeysForSaleReturn = async function () {
    console.log('starting fixing salesReturn...');

    let items = await getItems();
    let salesReturn = await getSalesReturn();

    let updatedSaleReturn = [];
    for (let i = 0; i < salesReturn.length; i++) {
        if (salesReturn[i].doc.sale_items.toString().indexOf('undefined') === -1) continue;

        let sale = transformSaleDoc(salesReturn[i].doc, 'saleReturn');
        // let saleItems = sale.items;
        for (let j = 0; j < sale.items.length; j++) {
            let saleItems = sale.items[j];
            if (!saleItems.skuName) {
                continue;
            }
            let gotItem = false;
            for (let k = 0; k < items.length; k++) {
                let item = items[k].doc;
                if (gotItem) {
                    gotItem = false;
                    break;
                }
                if (saleItems.item_id === item.item_id) {

                    //batches
                    let batchKeys = Object.keys(item.batches);
                    if (!batchKeys.length) continue;
                    for (let j = 0; j < batchKeys.length; j++) {
                        let thisBatchKey = batchKeys[j];
                        let thisBatch = CLONE(item.batches[thisBatchKey]);
                        if (saleItems.skuName === thisBatch.skuName) {
                            saleItems.attributeInfo = {}
                            saleItems.stockKey = thisBatch.stockKey;
                            saleItems.attributeInfo = thisBatch.attributeInfo;
                            gotItem = true;
                            break;
                        }
                    }
                    //batch end
                }
            }
        }
        let enSale = await encodeTransDoc(sale, 'saleReturn');
        updatedSaleReturn.push(enSale);
    }
    return updatedSaleReturn;
};

// //for saleReturn
// console.log('Script will start now for salesReturn...');
// fixKeysForSaleReturn().then(function(salesReturn) {
//     console.log('...will update to db');
//     console.log(salesReturn);
//     couchDBUtils.bulkDocs(salesReturn, db).then(function(resp) {
//         console.log(' salesReturn Variants are fixed');
//         process.exit(0);
//     }).catch(function(err) {
//         console.error(err);
//     })
// }).catch(function(err) {
//     console.error(err);
//     confirm.error('Some error occured');
//     process.exit(1);
// });
async function run3() {
    console.log('Script will start now for saleReturn...');
    try {
        let saleReturn = await fixKeysForSaleReturn();
        console.log('...will update to db');
        console.log(saleReturn, saleReturn.length);
        // await couchDBUtils.bulkDocs(saleReturn, db);
        console.log(' saleReturn Variants are fixed');
        // process.exit(0);
    } catch (err) {
        console.error(err);
        confirm.error('Some error occured');
        process.exit(1);
    };
};

async function mainRun() {
    await run1();
    await run2();
    await run3();
    process.exit(0);
}
mainRun();