require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .alias('s', 'cleanSalesInfo')
    .default('s', false)
    .alias('p', 'cleanPurchaseInfo')
    .default('p', false)
    .help('h')
    .alias('h', 'help')
    .argv;

var curSession = {};
var applicationSettings = {};
const logger = require('../common/Logger');
var couchDBUtils = require('../controllers/common/CouchDBUtils');

var mainDBInstance = couchDBUtils.getMainCouchDB();
async function editItems() {
    let allItems = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
    let docsToUpdate = [];
    for (let i = 0; i < allItems.length; i++) {
        allItems[i].doc.info.bPPTaxInclusive = true;
        allItems[i].doc.info.bSPTaxInclusive = true;
        console.log("Updating" + (i + 1));
        docsToUpdate.push(allItems[i].doc);
    }

    await couchDBUtils.bulkInsert(mainDBInstance, docsToUpdate);
}



editItems().then(() => {
    console.log('Done');
    process.exit(0);
});