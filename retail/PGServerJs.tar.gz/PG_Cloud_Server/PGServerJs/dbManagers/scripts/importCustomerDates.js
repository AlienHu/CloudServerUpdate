(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../.env',
        sample: __dirname + '/../env.example'
    });

    const couchDbManager = require('./couchDbManager');
    const couchDBUtils = require('../controllers/common/CouchDBUtils');
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const globalConfigController = require('../controllers/GlobalConfigurations');

    var csv = require('csvtojson');
    const moment = require('moment');
    var custArray = [];
    csv()
        .fromFile(__dirname + '/Santosh Jewellers.xlsx - Sheet1.csv')
        .on('json', (jsonObj) => {
            custArray.push(jsonObj);
        })
        .on('done', (error) => {
            console.log('found rows: ' + custArray.length)
            if (error) {
                console.log('error in reading csv');
                console.log(error);
                return;
            }
            return run();
        });

    // cell mapping 
    let address_1 = 'address_1';
    let agency_name = 'agency_name';
    let city = 'city';
    let company_name = 'company_name';
    let country = 'country';
    let credit_limit = 'credit_limit';
    let first_name = 'Name';
    let last_name = 'Last Name';
    let email = 'email';
    let gender = 'gender';
    let pan_number = 'pan_number';
    let phone_number = 'Mobile N;.';
    let state = 'state';
    let zip = 'ip';
    let credit_balance = 'credit_balance';
    let birth_date = 'Birthday';
    let anniversary = 'Anniversary';

    var bulkArray = [];
    async function createItemArray() {
        console.log('customer import started...')
        for (let i = 0; i < custArray.length; i++) {
            let momentNow = moment().format('x');
            momentNow += '' + i;
            let customer = {
                _id: 'customer_' + momentNow,
                id: momentNow,
                address_1: filterNAData(custArray[i][address_1]),
                agency_name: filterNAData(custArray[i][agency_name]),
                city: filterNAData(custArray[i][city]),
                company_name: filterNAData(custArray[i][company_name]),
                country: filterNAData(custArray[i][country]),
                credit_limit: filterNAData(custArray[i][credit_limit]),
                first_name: filterFname(custArray[i][first_name], custArray[i][phone_number]),
                last_name: filterNAData(custArray[i][last_name]),
                email: filterNAData(custArray[i][email]),
                gender: filterGender(custArray[i][gender]),
                pan_number: filterNAData(custArray[i][pan_number]),
                phone_number: getPhoneNumber(custArray[i][phone_number], i),
                state: filterNAData(custArray[i][state]),
                zip: filterNAData(custArray[i][zip]),
                credit_balance: 0,
                birth_date: formatDate(filterNAData(custArray[i][birth_date])),
                anniversary: formatDate(filterNAData(custArray[i][anniversary]))
            }

            customer.person_id = customer.id;

            bulkArray.push(customer);
        }
        try {
            await couchDBUtils.bulkInsert(mainDBInstance, bulkArray);
        } catch (error) {
            console.log(error);
        }
    }

    function formatDate(date) {
        if (!date) return undefined;
        let d = new Date(moment(date, 'MM/DD/YYYY'))
        return d;
    }

    function getPhoneNumber(phone_number, i) {
        let LENGTH = 10;
        if (!phone_number || phone_number == 'N/A') phone_number = "";
        let idLength = i.toString().length;
        let prefixCount = LENGTH - phone_number.length - idLength;
        if (prefixCount <= 0) return phone_number;
        for (let i = 0; i < prefixCount; i++) {
            phone_number += '5';
        }
        phone_number += i;
        return phone_number;
    }

    function filterNAData(data) {
        data = (data == 'N/A' || data === undefined || data === null) ? "" : data;
        return data;
    }

    function filterGender(data) {
        data = (data == 'M' || !data || data == "N/A" || data.toString().trim()) ? 0 : 1;
        return data;
    }

    function filterFname(fname, number) {
        fname = (fname === undefined || fname == "N/A" || fname === null) ? number : fname;
        return fname;
    }

    async function deleteType(type) {
        console.log('cleaning old ' + type);
        let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
        console.log(type + '<' + resp.length + '>');
        let bulkDocs = [];
        for (let i = 0; i < resp.length; i++) {
            resp[i].doc._deleted = true;
            bulkDocs.push(resp[i].doc);
        }

        if (bulkDocs.length) {
            await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
        }
    }

    async function deleteHandler() {
        // await deleteType('customer');
        // console.log('cleanup done');
    }

    async function run() {
        await couchDbManager.initCouchDb(false);
        await deleteHandler(); // not doing for customer
        await createItemArray();
        console.log('customer import done.');
        process.exit(0);
    }
})();