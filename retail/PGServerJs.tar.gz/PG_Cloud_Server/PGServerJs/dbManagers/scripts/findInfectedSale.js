'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const fs = require('fs');
const moment = require('moment');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const userdb = couchDBUtils.getUserCouchDB();
const logger = require('../common/Logger');
const utils = require('../controllers/common/Utils');
const CLONE = utils.clone;
let saleItemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
let purchaseItemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
let allItems, allCategories, allCustomers, allEmployees, allSales, allSalesReturns, allPurchase, allRecivingReturns;
let updateItems, updateCategories, updateCustomers, updateEmployees, allUpdatedSale, allUpdatedSaleReturn, allUpdatedPurchase, allUpdatedRecivingReturns;
let errorsArray = [];
let errorsPurArray = [];
let ParseAllSalesErrorsArray = [];
let ParseAllPurErrorArray = [];

printInfectedIds();
async function printInfectedIds() {
    await getAlldocs();
    //await iterateSales();
    //await iteratePurchases();
    await getAndParseAllSales();
    await getAndParseAllSalesReturn();
    await getAndParseAllPurchase();
    await getAndParseAllPurchaseReturn();
    await writeAllInfectedIds();
    await updateDocs();
    process.exit(0);
};

async function getAlldocs() {
    allItems = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
    allCategories = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
    allCustomers = await couchDBUtils.getAllDocsByType('customer', mainDBInstance);
    allEmployees = await couchDBUtils.getAllDocsByType('org.couchdb.user:', userdb);
    allSales = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
    allSalesReturns = await couchDBUtils.getAllDocsByType('saleReturn', mainDBInstance);
    allPurchase = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance);
    allRecivingReturns = await couchDBUtils.getAllDocsByType('receivingReturn', mainDBInstance);
    //    console.log(allItems, allCategories, allCustomers, allEmployees)
};

async function iterateSales() {
    allSales.forEach(function(sale, index) {
        let tempItems = sale.doc.sale_items;
        tempItems.forEach(function(item, index) {
            let splitedArray = item.split(';');
            if ((saleItemFields.length + 1) !== splitedArray.length) {
                errorsArray.push('<sale  id:' + sale.doc._id + '> <index:' + index + '>');
            }
        });
    });
    allSalesReturns.forEach(function(sale, index) {
        let tempItems = sale.doc.items;
        tempItems.forEach(function(item, index) {
            let splitedArray = item.split(';');
            if ((saleItemFields.length + 1) != splitedArray.length) {
                errorsArray.push('<Sale return  id:' + sale.doc._id + '> <index:' + index + '>');
            }
        });
    });
};

async function iteratePurchases() {
    allPurchase.forEach(function(purchase, index) {
        let tempPurItem = purchase.doc.receiving_items;
        tempPurItem.forEach(function(item, index) {
            let splitedPurArray = item.split(';');
            if ((purchaseItemFields.length + 1) != splitedPurArray.length) {
                errorsPurArray.push('<Purchase  id:' + purchase.doc._id + '> <index:' + index + '>');

            }
        });
    });
    allRecivingReturns.forEach(function(purchase, index) {
        let tempPurItem = purchase.doc.items;
        tempPurItem.forEach(function(item, index) {
            let splitedPurArray = item.split(';');
            if ((purchaseItemFields.length + 1) != splitedPurArray.length) {
                errorsPurArray.push('<Purchase return  id:' + purchase.doc._id + '> <index:' + index + '>');
            }
        });
    });
};
async function getAndParseAllSales() {
    allSales.forEach(function(sale, i) {
        let tempItems = sale.doc.sale_items;
        let updatedCustomer = await findSemicolonInCustomer(sale.doc.info);
        if (updatedCustomer.isEdited) {
            allSales[i].doc.info = updatedItem.item;
            allUpdatedSale.push(allSales[i])
        }
        await findSemicolonInEmployee(sale.doc.sales_info);
        tempItems.forEach(function(item, index) {
            let updatedItem = await findSemicolonInItem(item);
            if (updatedItem.isEdited) {
                allSales[i].doc.sale_items[index] = updatedItem.item;
                allUpdatedSale.push(allSales[i])
            }
            let updatedCatagory = await findSemicolonInCategory(item);
            if (updatedCatagory.isEdited) {
                allSales[i].doc.sale_items[index] = updatedCatagory.item;
                allUpdatedSale.push(allSales[i]);
            }
            let splitedArray = item.split(';');
            if ((saleItemFields.length + 1) != splitedArray.length) {
                ParseAllSalesErrorsArray.push(sale);
            }

        });
    });
};
async function getAndParseAllSalesReturn() {
    let getAndParseAllSalesReturnErrorsArray = [];
    allSalesReturns.forEach(function(sale, i) {
        let tempItems = sale.doc.items;
        let updatedCustomer = await findSemicolonInCustomer(sale.doc.sales_info);
        if (updatedCustomer.isEdited) {
            allSalesReturns[i].doc.sales_info = updatedItem.item;
            allUpdatedSaleReturn.push(allSalesReturns[i])
        }
        await findSemicolonInEmployee(sale.doc.sales_info);
        tempItems.forEach(function(item, index) {
            let updatedItem = await findSemicolonInItem(item);
            if (updatedItem.isEdited) {
                allSalesReturns[i].doc.sale_items[index] = updatedItem.item;
                allUpdatedSaleReturn.push(allSalesReturns[i])
            }
            let updatedCatagory = await findSemicolonInCategory(item);
            if (updatedCatagory.isEdited) {
                allSalesReturns[i].doc.sale_items[index] = updatedCatagory.item;
                allUpdatedSaleReturn.push(allSales[i]);
            }
            let splitedArray = item.split(';');
            if ((saleItemFields.length + 1) != splitedArray.length) {
                getAndParseAllSalesReturnErrorsArray.push(sale);
            }

        });
    });

};
async function getAndParseAllPurchase() {
    allPurchase.forEach(function(purchase, i) {
        let tempPurItem = purchase.doc.receiving_items;
        let updatedCustomer = await findSemicolonInCustomer(purchase.doc.receivings_info);
        if (updatedCustomer.isEdited) {
            allPurchase[i].doc.receivings_info = updatedItem.item;
            allUpdatedPurchase.push(allPurchase[i])
        }
        await findSemicolonInEmployee(purchase.doc.receivings_info);
        tempPurItem.forEach(function(item, index) {
            let updatedItem = await findSemicolonInItem(item);
            if (updatedItem.isEdited) {
                allPurchase[i].doc.receiving_items[index] = updatedItem.item;
                allUpdatedPurchase.push(allPurchase[i])
            }
            let updatedCatagory = await findSemicolonInCategory(item);
            if (updatedCatagory.isEdited) {
                allSales[i].doc.sale_items[index] = updatedCatagory.item;
                allUpdatedPurchase.push(allSales[i]);
            }
            let splitedPurArray = item.split(';');
            if ((purchaseItemFields.length + 1) != splitedPurArray.length) {
                ParseAllPurErrorArray.push(purchase);
            }

        });
    });

};
async function getAndParseAllPurchaseReturn() {

    let allRecivingReturns = await couchDBUtils.getAllDocsByType('receivingReturn', mainDBInstance);

    let purchaseItemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    allRecivingReturns.forEach(function(purchase, i) {
        let tempPurItem = purchase.doc.items;
        let updatedCustomer = await findSemicolonInCustomer(purchase.doc.info);
        if (updatedCustomer.isEdited) {
            allPurchase[i].doc.info = updatedItem.item;
            allUpdatedRecivingReturns.push(allPurchase[i])
        }
        await findSemicolonInEmployee(item);
        tempPurItem.forEach(function(item, index) {
            let updatedItem = await findSemicolonInItem(item);
            if (updatedItem.isEdited) {
                allPurchase[i].doc.items[index] = updatedItem.item;
                allUpdatedPurchase.push(allPurchase[i])
            }
            let updatedCatagory = await findSemicolonInCategory(item);
            if (updatedCatagory.isEdited) {
                allSales[i].doc.items[index] = updatedCatagory.item;
                allUpdatedPurchase.push(allSales[i]);
            }
            let splitedPurArray = item.split(';');
            if ((purchaseItemFields.length + 1) != splitedPurArray.length) {
                ParseAllPurErrorArray.push(purchase);
            }

        });

    });

};

async function findSemicolonInItem(itemString) {
    allItems.forEach(function(item, index) {
        let itemIndex = itemString.indexOf(item.doc.info.name);
        let Data = {
            isEdited = false
        }
        if (itemIndex > -1) {
            let itemName = item.doc.info.name;
            if (itemName.indexOf(';') > -1) {
                itemName = itemName.replace(';', "");
                Data.isEdited = true;
                itemString = itemString.replace(item.doc.info.name, itemName);
                Data.item = itemString;
                // itemName = itemwithoutSemiColon.join(' ');
                allItems[index].doc.info.name = itemName;
                let isAvailable = false;
                updateItems.forEach(function(temp, index) {
                    if (temp.doc.info.name === item.doc.info.name) {
                        isAvailable = true;
                    }
                });
                if (!isAvailable) {
                    updateItems.push(allItems[index]);
                }
            }
            return Data;
        }
    });
};

async function findSemicolonInCategory(itemString) {
    allCategories.forEach(function(category, index) {

        if (itemString.indexOf(category.doc.name) > -1) {
            let categoryName = category.doc.name;
            if (categoryName.indexOf(';') != -1) {
                categoryName = categoryName.replace(';', "");
                Data.isEdited = true;
                itemString = itemString.replace(category.doc.name, categoryName);
                Data.item = itemString;
                allCategories[index].doc.info.name = categoryName;
                updateCategories.push(allCategories[index]);
            }
            return Data;
        }
    });
};

async function findSemicolonInCustomer(salesInfo) {
    allCustomers.forEach(function(customer, index) {
        let customerInfo = customer.doc;
        let checkCompanyName = customerInfo.company_name ? customerInfo.company_name : '';
        let checkLastName = customerInfo.last_name ? customerInfo.last_name : '';
        let custinfo = checkCompanyName + ' ' + customerInfo.first_name + ' ' + checkLastName;
        let Data = {
            isEdited = false
        }
        if ((custinfo.indexOf(';') > -1)) {
            Data.isEdited = true;
            let revCustInfo = custinfo.replace(';', '');
            salesInfo = salesInfo.replace(custinfo, revCustInfo);
            Data.item = salesInfo;
            return Data;
        }
        // if (salesInfo.indexOf(customer.doc.first_name) > -1) {

        //     let customerFName = category.doc.first_name;
        //     if (customerFName.indexOf(';') != -1) {
        //         customerFName = customerFName.replace(';', '');
        //         allCustomers[index].doc.info.name = customerFName;
        //     }
        //     Data.isEdited = true;
        //     salesInfo = salesInfo.replace(item.doc.first_name, customerFName);
        //     Data.item = salesInfo;
        // }
        // if (salesInfo.indexOf(customer.doc.last_name) > -1) {
        //     let customerLastName = category.doc.last_name;
        //     if (customerLastName.indexOf(';') != -1) {
        //         let customerLastNameWithoutSemiColon = itemName.split(';')
        //         customerLastName = customerLastNameWithoutSemiColon.join(' ');
        //         allCustomers[index].doc.info.name = customerLastName;
        //     }
        //     Data.isEdited = true;
        //     salesInfo = salesInfo.replace(item.doc.last_name, categoryName);
        //     Data.item = salesInfo;
        //     updateCustomers.push(allCustomers[index]);
        // }

    });
};

async function findSemicolonInEmployee(salesInfo) {
    allEmployees.forEach(function(employee, index) {
        if (salesInfo.indexOf(employee.doc.first_name)) {
            let employeeFName = category.doc.first_name;
            let employeeFNameWithoutSemiColon = itemName.split(';')
            employeeFName = employeeFNameWithoutSemiColon.join(' ');
            allEmployees[index].doc.info.name = employeeFName;
        }
        if (salesInfo.indexOf(employee.doc.last_name)) {
            let employeeLastName = category.doc.last_name;
            if (categoryName.indexOf(';') != -1) {
                let employeeLastNameWithoutSemiColon = itemName.split(';')
                employeeLastName = employeeLastNameWithoutSemiColon.join(' ');
                allEmployees[index].doc.info.name = employeeLastName;
            }
            updateEmployees.push(allEmployees[index]);
        }
    });
};
async function updateDocs() {
    if (updateItems.length > 0) {
        try {
            let resp = await couchDBUtils.bulkDocs(updateItems, mainDBInstance);
            if (resp) {
                console.log('Item Update Success:' + resp);
            }
        } catch (err) {
            console.log('Item Update Fail:' + err)
            console.log(updateItems);
        }
    };
    if (updateCategories.length > 0) {
        try {
            let resp = await couchDBUtils.bulkDocs(updateCategories, mainDBInstance);
            if (resp) {
                console.log('Category Update Success:' + resp);
            }
        } catch (err) {
            console.log('Category Update Fail:' + err)
            console.log(updateCategories);
        }
    };
    if (updateCustomers.length > 0) {
        try {
            let resp = await couchDBUtils.bulkDocs(updateCustomers, mainDBInstance);
            if (resp) {
                console.log('Customer Update Success:' + resp);
            }
        } catch (err) {
            console.log('Customer Update Fail:' + err)
            console.log(updateCustomers);
        }
    };
    if (updateEmployees.length > 0) {
        try {
            let resp = await couchDBUtils.bulkDocs(updateEmployees, userdb);
            if (resp) {
                console.log('Employee Update Success:' + resp);
            }
        } catch (err) {
            console.log('Employee Update Fail:' + err)
            console.log(updateEmployees);
        }
    };
};

async function writeAllInfectedIds() {
    let errorString;
    let filename = __dirname + '\\..\\logs\\infcteded' + moment().unix() + '.txt';
    console.log(filename);
    errorsArray.forEach(function(item) {
        errorString += item
    });
    errorsPurArray.forEach(function(item) {
        errorString += item
    });
    fs.writeFileSync(filename, errorString);
    console.log("success");

}