let source = "163.172.179.174";
// let source = "192.168.31.162";
let target = '127.0.0.1';
let appName = 'retail'; //retail
let dbSufix = 'coredb';
let dbName = 'pg_collection_' + appName + '_' + dbSufix;

function run() {
    return sync();
}
run();
async function sync() {
    let targetDbClient = require('nano-blue')("http://couchadmin:test@" + target + ":5984");
    try {
        await targetDbClient.db.destroy(dbName);
    } catch (error) {
        console.log('Failed to delete local db');
    }
    let sourceUrl = 'http://couchadmin:test@' + source + ':5984/' + dbName;
    let targetUrl = 'http://couchadmin:test@' + target + ':5984/' + dbName;

    await replicateDB(targetDbClient, sourceUrl, targetUrl);
}

function replicateDB(targetDbClient, sourceDBUrl, targetDBUrl) {
    return new Promise((resolve, reject) => {
        targetDbClient.db.replicate(sourceDBUrl, targetDBUrl, {
                create_target: true
            },
            function(err, resp) {
                if (!err) {
                    console.log('couchDb', resp);
                    resolve(resp);
                } else {
                    console.log('Replcaition to cloud failed ', err);
                    reject(err);
                }
            });
    });
}