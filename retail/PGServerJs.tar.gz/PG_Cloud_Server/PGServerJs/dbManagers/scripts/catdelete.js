// 'use strict';
// require('dotenv-safe').load({
//     path: __dirname + '/../.env',
//     sample: __dirname + '/../env.example'
// });

// const couchDbManager = require('./couchDbManager');
// const couchDBUtils = require('../controllers/common/CouchDBUtils');
// const mainDBInstance = couchDBUtils.getMainCouchDB();
// const fs = require('fs');

// async function run() {
//     //false -- no db reset
//     //true -- db reset
//     await couchDbManager.initCouchDb(false);

//     let resp = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
//     for (let i = 0; i < resp.length; i++) {
//         await couchDBUtils.delete(resp[i].doc, mainDBInstance);
//     }
// }

// run().then(() => {
//     process.exit(0);
// });