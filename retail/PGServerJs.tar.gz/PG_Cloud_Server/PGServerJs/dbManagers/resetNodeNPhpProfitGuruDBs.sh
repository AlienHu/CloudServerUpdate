#!/bin/bash -x
SCRIPT_PATH=$(dirname `which $0`)
cd ${SCRIPT_PATH}

./resetDB.js -d 1
./dropAndRecreateMysqlDBs.sh