'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const limit = 500;

let ctr = 0;

const runFixer = async function() {
    try {
        await couchDBUtils.batchProcess(couchDBUtils.getView, ['all_items_data', 'item-hash',
                {
                    include_docs: true,
                    limit: limit
                },
                mainDBInstance
            ],
            processItemsData);

        console.log('fixed items ' + ctr);
        return 'success';
    } catch (err) {
        throw err;
    }

}

const processItemsData = async function(items) {
    let updatedItems = [];
    for (let i = 0; i < items.length; i++) {
        let thisItem = items[i].doc;
        if (thisItem.batches.length > 1 && !thisItem.hasBatchNumber) {
            thisItem.hasBatchNumber = true;
            updatedItems.push(thisItem);
            ctr++;
        }
    }
    if (updatedItems.length) {
        try {
            let resp = await couchDbUtils.bulkUpdate(updatedItems);
            console.log(resp);
            console.log('done this batch');
        } catch (err) {
            console.error(err);
            console.error('some error');
        }
    }

}

runFixer().then(function(resp) {
    console.log(resp);
    console.log('script done');
}).catch(function(err) {
    console.error('script failed');
    console.error(err);
})