pm2 stop 0
systemctl stop couchdb.service
rm -rf /home/couchdb/data_
mv /home/couchdb/data /home/couchdb/data_
mkdir /home/couchdb/data
chown -R couchdb:couchdb /home/couchdb        
find /home/couchdb -type d -exec chmod 0770 {} \;
chmod 0644 /home/couchdb/etc/*
systemctl start couchdb.service
pm2 start 0