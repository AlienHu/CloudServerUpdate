var loginAuthorizer = require('./loginAuthorizer.js');
var licenceAuthorizer = require('./licenceAuthorizer.js');
var featureAuthorizer = require('./featureAuthorizer.js');
var entitlementsAuthorizer = require('./entitlementAuthorizer.js');

var authorizer = function() {
    this.loginAuthorizer = function() {
        return loginAuthorizer();
    };
    this.licenceAuthorizer = function() {
        return licenceAuthorizer();
    };
    this.featuresAuthorizer = function(allowedProfitGuruFeaturesDoc) {
        return featureAuthorizer(allowedProfitGuruFeaturesDoc);
    };
    this.entitlementsAuthorizer = function() {
        return entitlementsAuthorizer();
    }
};
module.exports = new authorizer();