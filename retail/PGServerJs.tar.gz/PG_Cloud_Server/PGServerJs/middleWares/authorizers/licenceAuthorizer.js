 //This middleWare validates client licence

 var urlParser = require('url');
 var licenceCommon = require('../../licencer/licenceCommon.js');
 var path = require('path');
 var MobileDetect = require('mobile-detect');

 var serverConfig = require(path.join(__dirname, '../../config', 'config.json'));
 //var defaultWhiteListApiList = ['/user/signin', '/user/signout', '/user/signup', '/core/profitGuruRestApis', '/core/profitGuruElements', '/licence/amiauthorized2connect'];
 var whiteListApis = [];
 serverConfig.defaultWhiteListApis.forEach(function(api) {
     whiteListApis.push(api.toLowerCase());
 });

 var whiteListModules = [];
 serverConfig.defaultWhiteListModules.forEach(function(api) {
     whiteListModules.push(api.toLowerCase());
 });

 function licenceAuthorizer(whiteListApiList) {

     if (whiteListApiList) {
         whiteListApis.push(whiteListApiList);
     }

     return function licenceAuthorizer(req, res, next) {

         var urlPath = urlParser.parse(req.url).pathname.toLowerCase();
         //to Remove / at the end of url, to get the match properly
         urlPath = urlPath.replace(/\/\s*$/, "");

         var moduleName = urlPath.split('/');
         moduleName = moduleName[1].toLowerCase();

         //TODO if its DeskTop app , provide it with trial licence if its not has been in the past
         if (req.session.user !== undefined) {
             if (whiteListApis.indexOf(urlPath) >= 0 || whiteListModules.indexOf(moduleName) >= 0) {
                 return next(); //whitelisted Apis, No authentication needed
             } else {
                 var requestDevice = new MobileDetect(req.headers['user-agent']);
                 var clientType = requestDevice.phone() ? 'MobileApp' : 'DeskTopApp';

                 licenceCommon.isLicencedProfitGuruClient(req, clientType).then(function(licenceStatus) {

                     if (licenceStatus.isLicenced) {
                         return next();
                     } else {
                         res.send(new Error('Licence Error: This client does not carry valid licence, Please contact you Admin/ProfitGuru Team'));
                         res.end();
                     }
                 });

             }

         } else {
             //Passing whiteListApiList Api before signin
             return next();
         }
     };
 }

 module.exports = licenceAuthorizer;