/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */
var createSessionDBCouchViews = function() {

    this.ddocs = [{
        _id: '_design/all_user_sessions',
        version: 1,
        views: {
            all_user_sessions: {
                map: function(doc) {
                    if (doc._id) {
                        emit(doc.user.name + '::' + doc.user.clientId, doc.user.clientId);
                    }
                }
            }
        }
    }];

};

module.exports = new createSessionDBCouchViews();