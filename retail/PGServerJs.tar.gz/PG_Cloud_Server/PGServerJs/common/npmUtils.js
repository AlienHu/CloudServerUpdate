var npmUtils = function () {
    'use strict';

    var _self = this;

    var lockFile = require('lockfile');
    var shelljs = require('shelljs');
    var logger = require('./Logger');
    var fs = require('fs');

    this.checkMissingNodeModules = function (foldersArray) {
        for (var i = 0; i < foldersArray.length; i++) {
            var folder = foldersArray[i];
            var bMissing = false;

            shelljs.pushd(folder);
            var consoleOut = shelljs.exec('npm ls > abc.log');

            const errArr = consoleOut.stderr.split('\n');
            let errMsg = '';
            for (let i = 0; i < errArr.length; i++) {
                let moduleName = getMissingModuleName(errArr[i]);
                if (canMissModulesArr.indexOf(moduleName) > -1) {
                    continue;
                }

                errMsg += errArr[i] + '\n';
            }

            shelljs.rm('abc.log');
            var indexMissing = errMsg.indexOf('missing');
            var indexInvalid = errMsg.indexOf('invalid');
            if (indexMissing !== -1 || indexInvalid !== -1) {
                bMissing = true;
                shelljs.popd();
                break;
            }
            shelljs.popd();
        }

        return bMissing;
    };

    /**
     * bProduction
     * npm version before after
     */
    function npmInstall(env, isDemoApp, baseDir, bNodeVersion8) {
        var npmCmd = 'npm install';
        var bInstallAllPackages = false;
        bInstallAllPackages = (env === 'development' || isDemoApp.toLowerCase() === 'yes');
        if (!bInstallAllPackages) {
            npmCmd += ' --production';
        }

        var nmCachepath = baseDir + '/nmCache/';
        nmCachepath += bInstallAllPackages ? 'development' : 'production';
        shelljs.mkdir('-p', nmCachepath);
        shelljs.cd(nmCachepath);
        shelljs.cp(baseDir + '/package.json', '.');
        if (bNodeVersion8) {
            shelljs.exec('nvm use 10.15.3');
        }
        console.log('Running npm install');
        shelljs.exec(npmCmd);
        shelljs.exec('npm prune')
        console.log('Checking if all node modules are working');
        var bMissing = _self.checkMissingNodeModules([nmCachepath]);
        if (bMissing) {
            console.log('npm install failed');
            shelljs.rm('./package.json');
            console.log("Exiting process npm install failed . Deleting package.json");
            process.exit(1);
        }
        console.log('Finished npm install');
        if (bNodeVersion8) {
            shelljs.exec('nvm use 10.15.3');
        }
        shelljs.cd('../..');

        return !bMissing;
    };

    this.copyNPM = function (env, isDemoApp, baseDir, bNodeVersion8, buildDir) {
        var COMPARE = require('../test/common/Utils').compareObject;

        var bDevelopment = env === 'development' || isDemoApp === 'yes';
        var npmCachePath = baseDir + '/nmCache/';
        if (bDevelopment) {
            npmCachePath += 'development';
        } else {
            npmCachePath += 'production';
        }

        var npmCachePackageJson = npmCachePath + '/package.json';

        npmCachePath += '/node_modules';
        var bPackagesEqual = false;

        if (shelljs.test('-f', npmCachePackageJson)) {
            var refPackage = JSON.parse(fs.readFileSync(baseDir + '/package.json', 'utf8'));
            var npmCachePackage = JSON.parse(fs.readFileSync(npmCachePackageJson, 'utf8'));

            bPackagesEqual = COMPARE(refPackage.dependencies, npmCachePackage.dependencies);
            if (bPackagesEqual) {
                bPackagesEqual = COMPARE(npmCachePackage.dependencies, refPackage.dependencies);
            }
            if (bPackagesEqual && bDevelopment) {
                bPackagesEqual = COMPARE(refPackage.devDependencies, npmCachePackage.devDependencies);
            }
        }

        if (!shelljs.test('-d', npmCachePath) || !bPackagesEqual) {
            var bInstalled = npmInstall(env, isDemoApp, baseDir, bNodeVersion8);
            if (!bInstalled) {
                console.log('package.json got updated. Install node_modules first');
                shelljs.rm('-r', buildDir)
                process.exit(1);
            } else {
                console.log('successfully installed node modules');
            }
        }

        shelljs.cp('-r', npmCachePath, buildDir);
    };

    //C:\Program Files (x86)\Apache Software Foundation\CouchDB\
    //"C:\Program Files (x86)\Apache Software Foundation\CouchDB\unins000.exe"
    this.getWinCouchInstDir = function () {
        var regedit = require('regedit');

        var path = 'HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\ApacheCouchDB_is1';
        if (process.arch === 'x64') {
            path = 'HKLM\\SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\ApacheCouchDB_is1'
        } else if (process.arch === 'arm') {
            logger.error('ARM ARCHITECTURE DANGER');
        }

        return new Promise(function (resolve, reject) {
            try {
                regedit.list(path, function (err, result) {
                    if (err) {
                        // logger.error(err);
                        logger.error("Not able to Find the Rigistry");
                        reject("");
                    }
                    if (result) {
                        var InstallLocation = result[path].values.InstallLocation.value;
                        var UninstallString = result[path].values.UninstallString.value;
                        if (false && UninstallString.indexOf(InstallLocation) !== 0) {
                            logger.error(InstallLocation);
                            logger.error(UninstallString);
                            logger.error('Not Expected to come here. couch path');
                        }
                        resolve(InstallLocation);
                    }
                });
            } catch (error) {
                reject('CouchDB Path Not Found');
            }
        });
    };

    const canMissModulesArr = [
        "mkdirp",
        "minimist",
        "minimatch",
        "brace-expansion",
        "balanced-match",
        "concat-map",
        "console-control-strings",
        "inherits",
        "safe-buffer",
        "safe-buffer",
        "console-control-strings",
        "string-width",
        "strip-ansi",
        "code-point-at",
        "is-fullwidth-code-point",
        "strip-ansi",
        "number-is-nan",
        "ansi-regex",
        "string-width",
        "inherits",
        "minimatch",
        "once",
        "once",
        "wrappy",
        "wrappy",
        "minipass",
        "mkdirp",
        "safe-buffer",
        "yallist",
        "minipass",
        "safe-buffer",
        "yallist",
        "minipass"
    ]

    function getMissingModuleName(errStr) {
        if (errStr.indexOf('npm ERR! missing') !== 0) {
            return errStr;
        }
        return errStr.substr(18).split("@")[0]
    }

};

module.exports = new npmUtils();