import * as httpUtils from '../common/httpUtils'
import * as logger from '../common/Logger';
import { Auth } from '../TSControllers/interfaces/common';
import { getAppConfig } from '../common/configState';

export const changeCouchPassword = async (curAuth: Auth, updateAuth: Auth, bCouch2: boolean): Promise<void> => {

    try {
        await updateAuthHelper(curAuth, updateAuth, bCouch2);
    } catch (error) {
        logger.error('killing application');
        process.exit(1);
    }
    try {
        await deleteAuthHelper(curAuth, updateAuth, bCouch2);
    } catch (error) {
        logger.error('killing application');
        process.exit(1);
    }

}

export const checkPassword = async (): Promise<void> => {
    let params = getAppConfig().localCouch;

    let response = await httpUtils.httpGet('http://' + params.UserName + ':' + params.Password + '@' + params.Host + ':' + params.Port);
    if (response.body.error) {
        throw response.body;
    }
    return response.body;
    //cases
    // ip or port is wrong exception comes
    // password or username is wrong exception comes
}

async function updateAuthHelper(curAuth: Auth, updateAuth: Auth, bCouch2: boolean): Promise<void> {
    let url: string = getUrlForAdminOp(curAuth, updateAuth, bCouch2);

    let reqInfo: reqInfo = {
        url: url,
        method: "PUT",
        json: true,
        body: updateAuth.password,
        headers: {
            "Content-Type": "application/json"
        }
    };

    try {
        let resp = await httpUtils.http(reqInfo);
        logger.silly(resp);
    } catch (error) {
        logger.error(error);
        logger.error('User information have been deleted manually Please Contact ProfitGuru Team');
        throw 'Failed.'
    }
}

async function deleteAuthHelper(curAuth: Auth, updateAuth: Auth, bCouch2: boolean): Promise<void> {
    let url: string = getUrlForAdminOp(updateAuth, curAuth, bCouch2);

    let reqInfo: reqInfo = {
        url: url,
        method: "DELETE",
        json: true,
        body: '',
        headers: {
            "Content-Type": "application/json"
        }
    }
    try {
        await httpUtils.http(reqInfo);
    } catch (error) {
        logger.error(error);
        logger.error('User information have been deleted manually Please Contact ProfitGuru Team');
        throw 'Failed.'
    }

}

function getUrlForAdminOp(curAuth: Auth, updateAuth: Auth, bCouch2: boolean): string {
    let config = getAppConfig();
    let url: string = 'http://' + curAuth.username + ':' + curAuth.password + '@' + config.localCouch.Host + ':' + config.localCouch.Port + '/';
    if (bCouch2) {
        url += '_node/couchdb@127.0.0.1/';
    }
    url += '_config/admins/' + updateAuth.username;

    return url;
}

interface reqInfo {
    url: string,
    method: string,
    json: boolean,
    body: string,
    headers: object
}