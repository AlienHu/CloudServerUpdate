"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const moment = require("moment");
const crypto = require("../controllers/libraries/crypto");
const fs = require("fs");
const couchAuthApi = require("./couchAuthChanger");
const couchDBUtils2 = require("../couchDb/couchDBUtils2");
const configState_1 = require("../common/configState");
const logger = require("./Logger");
const path = require("path");
const cryptoPassword = 'helloworld';
const platform = configState_1.getPlatform();
const configJson = JSON.parse(fs.readFileSync(__dirname + '/../config/config.json').toString());
const authFilePath = configJson.couchAuthFilePath[platform];
let couchAuthPathDir = path.dirname(authFilePath);
if (configState_1.isWindowsPlatform() && !fs.existsSync(couchAuthPathDir)) {
    fs.mkdirSync(couchAuthPathDir);
}
exports.getCouchAuthInfo = () => __awaiter(this, void 0, void 0, function* () {
    return;
    if (!configState_1.isWindowsPlatform()) {
        return;
    }
    try {
        const test = JSON.parse(fs.readFileSync(authFilePath).toString());
        let couchKey = test.keys;
        const decrUsername = crypto.decrypt(couchKey.username, cryptoPassword);
        const decrpasscode = crypto.decrypt(couchKey.passcode, cryptoPassword);
        yield setPassword({ username: decrUsername, password: decrpasscode });
    }
    catch (_a) {
        let newinfo = {
            username: moment().format('x'),
            password: moment().format('x')
        };
        let OldInfo = {
            username: process.env.COUCHDB_USERNAME,
            password: process.env.COUCHDB_PASSWORD
        };
        let bCouch2 = yield couchDBUtils2.isCouch2();
        yield couchAuthApi.changeCouchPassword(OldInfo, newinfo, bCouch2);
        yield setPassword(newinfo);
        let encUserName = crypto.encrypt(newinfo.username, cryptoPassword);
        const encpasscode = crypto.encrypt(newinfo.password, cryptoPassword);
        const info = {
            keys: {
                username: encUserName,
                passcode: encpasscode
            }
        };
        fs.writeFileSync(authFilePath, JSON.stringify(info));
    }
});
const setPassword = (auth) => __awaiter(this, void 0, void 0, function* () {
    process.env.COUCHDB_USERNAME = auth.username;
    process.env.COUCHDB_PASSWORD = auth.password;
    configState_1.setAuth(auth);
    try {
        yield couchAuthApi.checkPassword();
    }
    catch (error) {
        logger.error('Contact Support Team.');
        process.exit(1);
    }
});
//# sourceMappingURL=getCouchAuthInfo.js.map