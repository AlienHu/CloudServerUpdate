var responseJson = function() {
    'use strict';

    this.get = function(statusCode) {
        if (statusCode === undefined) {
            statusCode = -1;
        }

        return {
            statusCode: -1,
            msg: '',
            err: {
                msg: '',
                errObj: null
            },
            data: {}
        };
    };

    this.get2 = function() {
        return {
            message: '',
            error: null,
            data: {}
        };
    }

};

module.exports = new responseJson();