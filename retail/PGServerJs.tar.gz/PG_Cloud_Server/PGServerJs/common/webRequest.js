var UpdaterDir = process.env.UpdaterDir ? process.env.UpdaterDir : __dirname;
var http = require("http");
var https = require("https");
var queryString = require('querystring');
var cmCode = require("./updateUtil.js");

var WebRequest = function(baseURL, header, ssl, port) {
    var self = this;
    this.m_baseURL = baseURL;
    this.m_header = header ? header : {};
    this.m_client = null;
    this.m_ssl = ssl;
    this.bodyMethod = [
        "post",
        "delete"
    ]
    this.m_options = {
        host: this.m_baseURL
    }
    if (ssl) {
        this.m_client = https;
        this.m_header.accept = this.m_header.accept ? this.m_header.accept : "*/*";
        this.m_options.port = port ? port : 443;
    } else {
        this.m_client = http;
        this.m_options.port = port ? port : 80;
    }

    this.httpClient = function() {
        return http;
    }

    this.httpsClient = function() {
        return https;
    }

    var request = function(inpData, cb) {
        try {
            this.isAborted = false;
            var query = "",
                _self = this;
            if (cmCode.isDataValid(inpData.query, "object")) {
                query = "?" + queryString.stringify(inpData.query);
            }

            var options = JSON.parse(JSON.stringify(self.m_options));
            options.path = (inpData.path ? inpData.path : "") + query;
            options.method = inpData.type ? inpData.type : 'GET';
            options.headers = JSON.parse(JSON.stringify(self.m_header));
            options.rejectUnauthorized = (typeof(inpData.rejectUnauthorized) == "boolean" ? inpData.rejectUnauthorized : false);
            if (inpData.auth) {
                options.auth = inpData.auth.user + ":" + inpData.auth.pass;
            }
            if (cmCode.isDataValid(inpData.headers, "object")) {
                for (var i in inpData.headers) {
                    options.headers[i] = inpData.headers[i]
                }
            }
            if (cmCode.isDataValid(inpData.tout, "number")) {
                if (inpData.tout > 0) {
                    options.timeout = inpData.tout;
                }
            }

            var req = self.m_client.request(options, function(res) {
                var data = [];
                res.on('data', function(chunk) {
                    data.push(chunk);
                });
                res.on('end', function() {
                    if (this.isAborted) {
                        cb({
                            message: "Request timeout"
                        });
                        return;
                    }
                    cb(null, {
                        statusCode: res.statusCode,
                        headers: res.headers,
                        data: Buffer.concat(data)
                    });
                }.bind(_self));
            });

            var tout = 30000;
            if (cmCode.isDataValid(inpData.tout, "number")) {
                if (inpData.tout > 0) {
                    tout = inpData.tout;
                }
            }
            req.setTimeout(tout, function() {
                this.isAborted = true;
                req.abort();
            }.bind(this));

            req.on('error', function(e) {
                cb({
                    message: "Request error",
                    trace: e
                });
            });

            if ((self.bodyMethod.indexOf(inpData.type.toLowerCase()) > -1) && cmCode.isDataValid(inpData.data)) {
                if (cmCode.isDataValid(inpData.data, "object")) {
                    req.write(JSON.stringify(inpData.data));
                } else {
                    req.write(inpData.data);
                }
            }
            req.end();
        } catch (ex) {
            cb({
                message: "HTTP request exception",
                trace: ex
            });
        }
    }

    function requestWithBody(method, path, data, cb) {
        var config = {
            type: method
        };
        if (cmCode.isDataValid(path, "object")) {
            if (!cmCode.isDataValid(path.path, "string", true)) {
                throw "url is not specified";
            }
            config.path = path.path;
            if (cmCode.isDataValid(path.query, "object")) {
                config.query = path.query;
            }
            if (cmCode.isDataValid(path.header, "object")) {
                config.headers = path.header;
            }
            if (cmCode.isDataValid(path.auth, "object")) {
                config.auth = path.auth;
            }
            if (cmCode.isDataValid(path.tout, "number")) {
                config.tout = path.tout;
            }
        } else if (cmCode.isDataValid(path, "string", true)) {
            config.path = path;
        } else {
            throw "url is not specified";
        }

        var callback = null;
        if (cmCode.isDataValid(data, "function")) {
            callback = data;
        } else if (cmCode.isDataValid(cb, "function")) {
            callback = cb;
            if (cmCode.isDataValid(data)) {
                config.data = data;
            }
        } else {
            throw "callback function not defined"
        }

        request(config, callback);
    }

    this.get = function(path, cb) {
        var config = {
            type: "GET"
        };

        if (cmCode.isDataValid(path, "object")) {
            if (!cmCode.isDataValid(path.path, "string", true)) {
                throw "url is not specified";
            }
            config.path = path.path;
            if (cmCode.isDataValid(path.query, "object")) {
                config.query = path.query;
            }
            if (cmCode.isDataValid(path.header, "object")) {
                config.headers = path.header;
            }
            if (cmCode.isDataValid(path.auth, "object")) {
                config.auth = path.auth;
            }
            if (cmCode.isDataValid(path.tout, "number")) {
                config.tout = path.tout;
            }
        } else if (cmCode.isDataValid(path, "string", true)) {
            config.path = path;
        } else {
            throw "url is not specified";
        }
        request(config, cb);
    };

    this.post = function(path, data, cb) {
        requestWithBody("POST", path, data, cb)
    };

    this.delete = function(path, data, cb) {
        requestWithBody("DELETE", path, data, cb)
    };
}

module.exports = WebRequest;