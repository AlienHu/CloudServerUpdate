//https: //github.com/sequelize/umzug

function umzugUtils(params) {
    'use strict';

    const Umzug = require('umzug');
    const logger = require('./Logger');
    const shelljs = require('shelljs');
    const path = require('path');

    let umzug;
    if (params) {
        umzug = new Umzug(params);
        shelljs.mkdir('-p', path.dirname(params.storageOptions.path));
        let events = ['migrating', 'migrated', 'reverting', 'reverted'];
        for (let i = 0; i < events; i++) {
            umzug.on(events[i], function(name, migrations) {
                logger.info(events[i] + '<' + name + '>');
            });
        }
    }

    let foo = {};
    let _self = foo;

    /** 
     * execute migrations including migrationName
     */
    function createDatabase(migrationName) {
        let upParams = {};
        if (migrationName) {
            upParams.to = migrationName;
        }

        return umzug.up(upParams).then(function(resp) {
            return 'Migration complete!';
        }).catch(function(err) {
            logger.error(err);
            logger.error('umzug error');
            return Promise.reject(err);
        });
    }

    foo.getPendingMigrations = function() {
        return umzug.pending().then(function(resp) {
            return resp;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.getExecutedMigrations = function() {
        return umzug.executed().then(function(migrations) {
            return migrations;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.deleteDatabase = function() {
        return umzug.down({
            to: 0
        }).then(function(resp) {
            return resp;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    }

    //reverts including the migrationName
    foo.revertDatabase = function(migrationName) {
        return umzug.down({
            to: migrationName
        }).then(function(resp) {
            return resp;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    //syncs the database till migrationName 
    foo.syncDatabase = async function(migrationName, bForce) {
        try {

            if (!migrationName) {
                migrationName = foo.getLatestMigrationName();
            }

            if (bForce) {
                await _self.deleteDatabase();
            }

            let pendingMigrations = await foo.getPendingMigrations();
            let executedMigrations = await foo.getExecutedMigrations();
            let executedMigrationIndex = executedMigrations.findIndex(i => i.file === migrationName);

            if (!migrationName || pendingMigrations.findIndex(i => i.file === migrationName) >= 0) {
                //migrationName is pending
                logger.info('executing migrations');
                await createDatabase(migrationName);
            } else if (executedMigrationIndex >= 0) {
                let revertMigrationIndex = executedMigrationIndex + 1;
                if (executedMigrations.length > (revertMigrationIndex)) {
                    //Example 1, 2, 3, 4 are database version and we want to revert to 2nd version, then the revertMigrationName is 3
                    logger.info('reverting migrations');
                    let revertMigrationName = executedMigrations[revertMigrationIndex].file;
                    await foo.revertDatabase(revertMigrationName);
                } else {
                    logger.info('database up to date');
                }
            } else {
                logger.error('Check Migration Name. Input<' + migrationName + '> Expected Format<201708090000000-applicationSettingsAndUserPermissions.js>');
            }

        } catch (err) {
            logger.error(err);
            logger.error('Migration <' + migrationName + '> failed.');
            throw err;
        };
    };

    foo.isRunMigrations = async function(migrationName) {
        if (!migrationName) {
            migrationName = foo.getLatestMigrationName();
        }

        let pendingMigrations = await foo.getPendingMigrations();
        if (!migrationName && pendingMigrations.length > 0) {
            return 1;
        }

        if (migrationName) {
            let pendingMigrationIndex = pendingMigrations.findIndex(i => i.file === migrationName);
            if (pendingMigrationIndex >= 0) {
                return 1;
            }

            let executedMigrations = await foo.getExecutedMigrations();
            let executedMigrationIndex = executedMigrations.findIndex(i => i.file === migrationName);
            if (executedMigrationIndex !== (executedMigrations.length - 1)) {
                //migrationName should be the last on the array, if not we have to revert
                return -1;
            }
        }

        return 0;
    };

    foo.isFreshPC = async function(migrationName) {
        if (migrationName) {
            //for fresh pc.. migrationName is expected to be empty
            return false;
        }

        return (await _self.getExecutedMigrations()).length === 0;
    };

    foo.writeDummyEntry = async function() {
        let fs = require('fs');
        let resp = await foo.getPendingMigrations();
        let allMigrations = [];
        for (let i = 0; i < resp.length; i++) {
            allMigrations.push(resp[i].file);
        }
        fs.writeFileSync(params.storageOptions.path, JSON.stringify(allMigrations));
    };

    foo.getLatestMigrationName = function(migrationPath) {
        if (!migrationPath) {
            migrationPath = params.migrations.path;
        }

        let migrations = shelljs.ls(migrationPath + '/*.js');
        var length = migrations.length;
        if (length) {
            return path.basename(migrations[length - 1]);
        }

        return '';
    };

    return foo;
};

module.exports = function(params) {
    return new umzugUtils(params);
};