import * as moment from 'moment';
import * as crypto from '../controllers/libraries/crypto';
import * as fs from 'fs';
import * as couchAuthApi from './couchAuthChanger';
import * as couchDBUtils2 from '../couchDb/couchDBUtils2';
import { getPlatform, isWindowsPlatform, setAuth } from '../common/configState';
import { Auth } from '../TSControllers/interfaces/common';
import * as logger from './Logger';
import * as path from 'path';

const cryptoPassword: string = 'helloworld';

const platform: string = getPlatform();
const configJson = JSON.parse(fs.readFileSync(__dirname + '/../config/config.json').toString())

const authFilePath = configJson.couchAuthFilePath[platform];
let couchAuthPathDir = path.dirname(authFilePath);

if (isWindowsPlatform() && !fs.existsSync(couchAuthPathDir)) {
    fs.mkdirSync(couchAuthPathDir);
}


export let getCouchAuthInfo = async (): Promise<void> => {
    if (!isWindowsPlatform()) {
        return;
    }

    try {
        const test = JSON.parse(fs.readFileSync(authFilePath).toString());
        let couchKey = test.keys;
        const decrUsername = crypto.decrypt(couchKey.username, cryptoPassword);
        const decrpasscode = crypto.decrypt(couchKey.passcode, cryptoPassword);
        await setPassword({ username: decrUsername, password: decrpasscode });
    } catch{
        let newinfo: Auth = {
            username: moment().format('x'),
            password: moment().format('x')
        };
        let OldInfo: Auth = {
            username: process.env.COUCHDB_USERNAME,
            password: process.env.COUCHDB_PASSWORD
        };

        let bCouch2: boolean = await couchDBUtils2.isCouch2();
        await couchAuthApi.changeCouchPassword(OldInfo, newinfo, bCouch2);
        await setPassword(newinfo);
        let encUserName = crypto.encrypt(newinfo.username, cryptoPassword);
        const encpasscode = crypto.encrypt(newinfo.password, cryptoPassword);
        const info = {
            keys: {
                username: encUserName,
                passcode: encpasscode
            }
        }

        fs.writeFileSync(authFilePath, JSON.stringify(info));
    }
};

const setPassword = async (auth: Auth): Promise<void> => {
    process.env.COUCHDB_USERNAME = auth.username;
    process.env.COUCHDB_PASSWORD = auth.password;
    setAuth(auth);

    try {
        await couchAuthApi.checkPassword();
    } catch (error) {
        logger.error('Contact Support Team.');
        process.exit(1);
    }
}