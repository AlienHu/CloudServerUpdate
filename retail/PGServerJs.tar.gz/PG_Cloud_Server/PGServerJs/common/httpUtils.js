var Utils = function() {
    'use strict';
    var request = require('request');
    let _self = this;

    this.httpGet = function(url) {

        return new Promise(function(resolve, reject) {
            request(url, {
                headers: {
                    'user-Agent': 'request'
                }
            }, function(error, response, body) {
                if (!error) {
                    var parsedData;
                    try {
                        parsedData = JSON.parse(body.toString());
                    } catch (e) {
                        reject({
                            error: "Failed to parse json",
                            trace: e
                        });
                    };
                    resolve({
                        response: response,
                        body: parsedData
                    });
                } else {
                    reject({
                        response: response,
                        error: error
                    })
                }
            });
        });

    };

    this.httpPut = function(url, body) {

        return new Promise(function(resolve, reject) {
            let params = {
                method: 'PUT'
            };
            if (body) {
                params.body = body;
            }

            request(url, params, function(error, response, body) {
                if (!error) {
                    var parsedData;
                    try {
                        parsedData = JSON.parse(body.toString());
                    } catch (e) {
                        reject({
                            error: "Failed to parse json",
                            trace: e
                        });
                    };
                    resolve({
                        response: response,
                        body: parsedData
                    });
                } else {
                    reject({
                        response: response,
                        error: error
                    })
                }
            });
        });

    };

    this.http = function(requestBuilder) {
        return new Promise((resolve, reject) => {
            request(requestBuilder, function(err, res, body) {

                if (!err) {
                    var response = {};
                    response.body = body;
                    response.res = res;
                    response.msg = body.Status;
                    resolve(response);
                } else {
                    err.msg = 'error';
                    err.err = Object.assign({}, err);
                    // err.err = err;
                    reject(err);
                }
            });
        });
    };

    this.httpPost = function(url, req) {
        let requestBuilder = {
            url: url,
            method: "POST",
            json: true,
            body: req,
            headers: {
                "Content-Type": "application/json"
            }
        }
        return _self.http(requestBuilder);
    }

};
module.exports = new Utils();