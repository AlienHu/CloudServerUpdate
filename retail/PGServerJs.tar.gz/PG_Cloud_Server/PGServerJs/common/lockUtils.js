var lockUtils = function() {
    'use strict';

    var lockFile = require('lockfile');
    var shelljs = require('shelljs');
    var logger = require('./Logger');

    this.createLockDir = function(path) {
        shelljs.mkdir('-p', path);
    };

    this.lockAsync = function(path, opts, errMsg) {
        if (!errMsg) {
            errMsg = 'Server Busy Try Again';
        }

        return new Promise(function(resolve, reject) {
            lockFile.lock(path, opts, function(error) {
                if (error) {
                    logger.error('Lock Failed <' + path + '>');
                    logger.error(error);
                    reject(errMsg);
                    return;
                }
                resolve(true);
                return;
            });
        });
    };

    //This function doesn't reject
    this.unlockAsync = function(path) {
        return new Promise(function(resolve, reject) {
            lockFile.unlock(path, function(error) {
                if (error) {
                    logger.error('UnLock Failed <' + path + '>');
                    logger.error(error);
                    resolve(false); //It's not critical. We don't need to reject it
                    return;
                }
                resolve(true);
                return;
            });
        });
    };

    this.lockOptions = function() {
        return {
            stale: 5000,
            retries: 5,
            retryWait: 1000
        };
    };

};

module.exports = new lockUtils();