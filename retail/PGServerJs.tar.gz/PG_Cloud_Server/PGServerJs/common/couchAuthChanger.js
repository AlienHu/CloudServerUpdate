"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const httpUtils = require("../common/httpUtils");
const logger = require("../common/Logger");
const configState_1 = require("../common/configState");
exports.changeCouchPassword = (curAuth, updateAuth, bCouch2) => __awaiter(this, void 0, void 0, function* () {
    try {
        yield updateAuthHelper(curAuth, updateAuth, bCouch2);
    }
    catch (error) {
        logger.error('killing application');
        process.exit(1);
    }
    try {
        yield deleteAuthHelper(curAuth, updateAuth, bCouch2);
    }
    catch (error) {
        logger.error('killing application');
        process.exit(1);
    }
});
exports.checkPassword = () => __awaiter(this, void 0, void 0, function* () {
    let params = configState_1.getAppConfig().localCouch;
    let response = yield httpUtils.httpGet('http://' + params.UserName + ':' + params.Password + '@' + params.Host + ':' + params.Port);
    if (response.body.error) {
        throw response.body;
    }
    return response.body;
    //cases
    // ip or port is wrong exception comes
    // password or username is wrong exception comes
});
function updateAuthHelper(curAuth, updateAuth, bCouch2) {
    return __awaiter(this, void 0, void 0, function* () {
        let url = getUrlForAdminOp(curAuth, updateAuth, bCouch2);
        let reqInfo = {
            url: url,
            method: "PUT",
            json: true,
            body: updateAuth.password,
            headers: {
                "Content-Type": "application/json"
            }
        };
        try {
            let resp = yield httpUtils.http(reqInfo);
            logger.silly(resp);
        }
        catch (error) {
            logger.error(error);
            logger.error('User information have been deleted manually Please Contact ProfitGuru Team');
            throw 'Failed.';
        }
    });
}
function deleteAuthHelper(curAuth, updateAuth, bCouch2) {
    return __awaiter(this, void 0, void 0, function* () {
        let url = getUrlForAdminOp(updateAuth, curAuth, bCouch2);
        let reqInfo = {
            url: url,
            method: "DELETE",
            json: true,
            body: '',
            headers: {
                "Content-Type": "application/json"
            }
        };
        try {
            yield httpUtils.http(reqInfo);
        }
        catch (error) {
            logger.error(error);
            logger.error('User information have been deleted manually Please Contact ProfitGuru Team');
            throw 'Failed.';
        }
    });
}
function getUrlForAdminOp(curAuth, updateAuth, bCouch2) {
    let config = configState_1.getAppConfig();
    let url = 'http://' + curAuth.username + ':' + curAuth.password + '@' + config.localCouch.Host + ':' + config.localCouch.Port + '/';
    if (bCouch2) {
        url += '_node/couchdb@127.0.0.1/';
    }
    url += '_config/admins/' + updateAuth.username;
    return url;
}
//# sourceMappingURL=couchAuthChanger.js.map