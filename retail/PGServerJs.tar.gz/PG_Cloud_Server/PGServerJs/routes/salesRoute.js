var express = require('express');
var router = express.Router();
var logger = require('../common/Logger');

/*
#Imp Notes
1) need to seperate giftcards and Loyality, difference:
2) loyality amount can be found from sales cart customer
3) customer discounts and credits can be implemented in same manner
4) Gift card value would be fetched directly from the number that is passed on

#Node and PHP Apis, renaming is not done
"sales": {
 #implemented
    "additemRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/additemRestApi",
    "editItemRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/editItemRestApi",
    "cancel_saleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/cancel_saleRestApi",
    "add_paymentRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/add_paymentRestApi",
    "completeSaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/completeSaleRestApi",  
    "removeitemRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/removeitemRestApi",
    //TODO Check whether this Api is needed as it looks very simillar to addItem Api and deosn;t exists in the old code
    //I think we need to make use of editItemRestApi for this functionality
                    
    "suspendSaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/suspendSaleRestApi",
    "changeModeRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/changeModeRestApi",
    "allSuspendedSalesRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/allSuspendedSalesRestApi",
    "unsuspendSaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/unsuspendSaleRestApi", 
    "getEditRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/getEditRestApi",
    "saveEditSalesRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/saveEditSalesRestApi",
    "getSalesRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/getSalesRestApi",
    "addCustomer2SaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/addCustomer2SaleRestApi",
    "deleteSaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/deleteSaleRestApi",
    "getItemDiscountRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/getItemDiscountRestApi",
    "DeleteItemFromCartRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/DeleteItemFromCartRestApi",
    "getItemsRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/getItemsRestApi",
        
    "manageRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/manageRestApi", 
    "receiptRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/receiptRestApi",
    "printReceiptApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/printReceiptApi",
    "setPrintAfterSaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/setPrintAfterSaleRestApi",
    "setInvoiceNumberEnabledRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/setInvoiceNumberEnabledRestApi",
    "setInvoiceNumberRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/setInvoiceNumberRestApi",
    "getAllItemsIdRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/tables/getKOTItemRestApi",
    "invoiceRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/invoiceRestApi",

    "saveTableOrderRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/saveTableOrderRestApi",
    "loadAllOrderItemBeforeCheckOutRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/loadAllOrderItemBeforeCheckOutRestApi",
    "unsuspendSaleRestaurantRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/unsuspendSaleRestaurantRestApi",
    "unsuspendDeliveryRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/unsuspendDeliveryRestApi",
    "splitBillRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/splitBillRestApi",
    "get_max_order_numberRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/get_max_order_numberRestApi",
    "saveDeliveryRetailRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/saveDeliveryRetailRestApi",
    "completeDeliverySaleApiRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/completeDeliverySaleApiRestApi",
    "completeTakeOrderRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/completeTakeOrderRestApi",

    "getCartTaxes": "http://localhost:4080/profitGuruRestSvc/index.php/sales/getCartTaxes",
    "loadKotToCartRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/loadKotToCartRestApi",
    "editSaveKOTRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/editSaveKOTRestApi",
    "addCustomer2OrdersRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/addCustomer2OrdersRestApi",
    "deleteWholeSaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/deleteWholeSaleRestApi",
    "delete_paymentRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/delete_paymentRestApi",
    "saveTwoTerminalOdersRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/saveTwoTerminalOdersRestApi",
    "unsuspendOrders4TwoTerminalRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/unsuspendOrders4TwoTerminalRestApi",
    "completeSale4TwoTerminalRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/completeSale4TwoTerminalRestApi"
    },
    */

/**
 *      Pending Apis
 *      1. saleshistory
 *      2. splitBillRestApi
 *      3. setInvoiceNumberApi
 */

router.post('/additemRestApi', function (req, res) {

    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.additemRestApi(req.body).then(function (resp) {
        //  logger.silly('Successfully added Item to cart', resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error(reason);
        res.send(reason);
        res.end();
    });

});

router.post('/addItemById', function (req, res) {

    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.addItemById(req.body).then(function (resp) {
        //  logger.silly('Successfully added Item to cart', resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error(reason);
        res.send(reason);
        res.end();
    });

});

router.post('/editItemRestApi', function (req, res) {

    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.editItemRestApi(req.body).then(function (resp) {
        logger.silly('Successfully Edited Item to cart', resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error(reason);
        res.send(reason);
        res.end();
    });

});

router.post('/updateUnit', function (req, res) {

    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.updateUnit(req.body).then(function (resp) {
        logger.silly('Successfully Edited Item to cart', resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error(reason);
        res.send(reason);
        res.end();
    });

});

router.post('/cancel_saleRestApi', function (req, res) {

    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.cancel_saleRestApi().then(function (resp) {
        // logger.silly('Successfully Cancelded sales cart', resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error(reason);
        res.send(reason);
        res.end();
    });

});

router.post('/add_paymentRestApi', function (req, res) {

    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.add_paymentRestApi(req.body).then(function (resp) {
        //   logger.silly('Successfully made sales payment', resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error(JSON.stringify(reason.message));
        var error = new Error(JSON.stringify(reason.message));
        res.send(error);
        res.end();
    });

});

router.post('/completeSaleRestApi', function (req, res) {

    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.completeSaleRestApi(req.body).then(function (resp) {
        logger.silly('Successfully made sales payment', resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error(reason);
        res.send(reason);
        res.end();
    });

});
router.post('/quickSaleRestApi', function (req, res) {

    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.quickSale(req.body).then(function (resp) {
        logger.silly('Successfully made quick sales payment', resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error(reason);
        res.send(reason);
        res.end();
    });

});

router.post('/removeitemRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.removeItem(req.body).then(function (resp) {
        logger.silly('success: removeitemRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('removeitemRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/addCustomer2SaleRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.addCustomer2Sale(req.body).then(function (resp) {
        logger.silly('success: addCustomer2SaleRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('addCustomer2SaleRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/addEmployee2SaleRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.addEmployee2Sale(req.body).then(function (resp) {
        logger.silly('success: addEmployee2SaleRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('addEmployee2SaleRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.get('/getSalesRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.getSales().then(function (resp) {
        logger.silly('success: getSalesRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('getSalesRestApi');
        logger.error(reason);
        var error = new Error(reason);
        res.send(error);
        res.end();
    });
});

router.get('/allSuspendedSalesRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.allSuspendedSales().then(function (resp) {
        logger.silly('success: allSuspendedSalesRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('allSuspendedSalesRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.get('/delete_paymentRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);

    salesController.deletePayment(req.query).then(function (resp) {
        logger.silly('success: delete_paymentRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('delete_paymentRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/setPrintAfterSaleRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.setPrintAfterSale(req.body).then(function (resp) {
        logger.silly('success: setPrintAfterSaleRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('setPrintAfterSaleRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/setInvoiceNumberEnabledRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.setInvoiceNumberEnabled(req.body).then(function (resp) {
        logger.silly('success: setInvoiceNumberEnabledRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('setInvoiceNumberEnabledRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/DeleteItemFromCartRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.delteItemFromCart(req.body).then(function (resp) {
        logger.silly('success: DeleteItemFromCartRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('DeleteItemFromCartRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.put('/suspendSaleRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.suspendSale().then(function (resp) {
        logger.silly('success: suspendSaleRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('suspendSaleRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/unsuspendSaleRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.unsuspendSale(req.body).then(function (resp) {
        logger.silly('success: unsuspendSaleRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('unsuspendSaleRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.put('/changeModeRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.changeMode(req.body).then(function (resp) {
        logger.silly('success: changeModeRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('changeModeRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

/**
 *      Alias: deleteCustomer4OrderRestApi
 */
router.post('/addCustomer2OrdersRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.addCustomer2Order(req.body).then(function (resp) {
        logger.silly('success: addCustomer2OrdersRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('addCustomer2OrdersRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.get('/deleteCustomer4OrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.removeCustomer().then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/saveTableOrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.saveTableOrder(req.body).then(function (resp) {
        logger.silly('success: saveTableOrderRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('saveTableOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/saveHDOrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.saveHDOrder(req.body).then(function (resp) {
        logger.silly('success: saveHDOrderRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('saveHDOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/completeHDOrder', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.completeHDOrder(req.body).then(function (resp) {
        logger.silly('success: completeHDOrder');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('completeHDOrder');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/quickHDOrder', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.quickHDOrder(req.body).then(function (resp) {
        logger.silly('success: quickHDOrder');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('quickHDOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/loadHDOrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.loadHDOrder(req.body).then(function (resp) {
        logger.silly('success: loadHDOrderRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('loadHDOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/printHDOrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.printHDOrder(req.body).then(function (resp) {
        logger.silly('success: printHDOrderRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('printHDOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/saveSOOrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.saveSOOrder(req.body).then(function (resp) {
        logger.silly('success: saveSOOrderRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('saveSOOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/loadSOOrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.loadSOOrder(req.body).then(function (resp) {
        logger.silly('success: loadSOOrderRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('loadSOOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/printSOOrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.printSOOrder(req.body).then(function (resp) {
        logger.silly('success: printSOOrderRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        logger.error('printSOOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/completeSOOrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.completeSOOrder(req.body).then(function (resp) {
        logger.silly('success: completeSOOrderRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('completeSOOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/quickSOOrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.quickSOOrder(req.body).then(function (resp) {
        logger.silly('success: quickSOOrderRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('quickSOOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/saveSQRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.saveSaleQuotation(req.body).then(function (resp) {
        logger.silly('success: saveSQRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('saveSQRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/getItemsForTableOrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.getItemsForTableOrder(req.body).then(function (resp) {
        logger.silly('success: getItemsForTableOrderRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('getItemsForTableOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/loadAllOrderItemBeforeCheckOutRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.loadAllOrdersToCart(req.body).then(function (resp) {
        logger.silly('success: loadAllOrderItemBeforeCheckOutRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('loadAllOrderItemBeforeCheckOutRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/completeTakeOrderRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.completeTakeOrder(req.body).then(function (resp) {
        logger.silly('success: completeTakeOrderRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('completeTakeOrderRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/loadKotToCartRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.loadKotToCart(req.body).then(function (resp) {
        logger.silly('success: loadKotToCartRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('loadKotToCartRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/deleteOrdersOfTableRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.cancelOrder(req.body).then(function (resp) {
        logger.silly('success: deleteOrdersOfTableRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('deleteOrdersOfTableRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.get('/get_max_order_numberRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.getMaxOrderNo(req.query).then(function (resp) {
        logger.silly('success: get_max_order_numberRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('get_max_order_numberRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.get('/getDateRangesRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.getDateRanges().then(function (resp) {
        logger.silly('success: getDateRangesRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('getDateRangesRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.get('/loadSaleRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.loadSale(req.query).then(function (resp) {
        logger.silly('success: loadSaleRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('loadSaleRestApi');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

/**
 *      {
 *          saleId: 12
 *      }
 */
router.get('/printSaleRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.rePrint(req.query).then(function (resp) {
        logger.silly('success: loadSaleRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('printSaleRestApi');
        logger.error(reason);

        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    });
});

router.get('/printMultipleSaleRestApi', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.multipleReprint(req.query).then(function (resp) {
        logger.silly('success: loadSaleRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('multiplePrintSaleRestApi');
        logger.error(reason);

        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    });
});

router.post('/makeCustomerCreditPayment', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.makeCustomerCreditPayment(req.body).then(function (resp) {
        logger.silly('success: makeCustomerCreditPayment');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('makeCustomerCreditPayment');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.post('/setLocalTax', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.setLocalTax(req.body).then(function (resp) {
        logger.silly('success: setLocalTax');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('setLocalTax');
        logger.error(reason);
        res.send(new Error(reason));
        res.end();
    });
});

router.post('/setGlobalDiscount', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.setGlobalDiscount(req.body).then(function (resp) {
        logger.silly('success: setGlobalDiscount');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('setGlobalDiscount');
        logger.error(reason);
        res.send(new Error(reason));
        res.end();
    });
});

router.post('/saveGlobalDiscount', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.saveGlobalDiscount(req.body).then(function (resp) {
        logger.silly('success: saveGlobalDiscount');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('setGlobalDiscount');
        logger.error(reason);
        res.status(500).send(new Error(reason));
        res.end();
    });
});

router.delete('/deleteSuspendedSale', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.deleteSuspendedSale(req.body).then(function (resp) {
        console.log('Successfully Deleted Suspended Sale', resp);
        res.send(resp[0]);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        res.send(error);
        res.end();
    });
});

router.delete('/deleteSale', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    var saleId = req.body.sale_id;

    salesController.deleteSaleById(saleId).then(function (resp) {
        console.log('Successfully Delete Sale', resp);
        res.send(saleId);
        res.end();
    }).catch(function (reason) {
        //res.sendStatus(300);
        res.send(reason);
        res.end();
    });
});

router.put('/rejectSale', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    var params = req.body;

    salesController.rejectSale(params).then(function (resp) {
        console.log('Sale Rejected Successfully', resp);
        res.send("Sale Rejected Successfully " + params.saleOrRecId);
        res.end();
    }).catch(function (reason) {
        //res.sendStatus(300);
        res.send(reason);
        res.end();
    });
});

router.post('/completeReturn', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);

    salesController.completeReturn(req.body).then(function (resp) {
        console.log('Sales return successfull', resp);
        logger.silly('Sales return successfull');
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        logger.error('completeReturn');
        logger.error(reason);
        res.send(reason);
        res.end();
    });
});

router.get('/getSaleDocByID', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.getSalesDocById(req.query.saleId).then(function (resp) {
        logger.silly('success: get sales doc by id');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('get sales doc by id');
        logger.error(reason);

        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    });
});

router.put('/initSalesEdit', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.initEditSalesSession(req.body).then(function (resp) {
        logger.silly('success: get sales doc by id');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('get sales doc by id');
        logger.error(reason);

        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    });
});
router.get('/getOrderBill', function (req, res) {
    var salesController = require('../controllers/Sales')(req.session, req.app.locals.applicationSettings);
    salesController.getOrderBill(req.query).then(function (resp) {
        logger.silly('success: get bill for table order');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('get bill for table order');
        logger.error(reason);

        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    });
});

router.get('/getAlienPendingSales', function (req, res) {
    var alienController = require('../controllers/Alien');
    alienController.getAlienPendingSales(req.query).then(function (resp) {
        logger.silly('success: get alien pending sale');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('get alien pending sale failed');
        logger.error(reason);
        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    });
});

module.exports = router;