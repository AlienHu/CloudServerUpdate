var express = require('express');
var router = express.Router();
var controller1 = require('../TSControllers/tally/convertJson2XML');
var controller2 = require('../TSControllers/tally/convertXML2Json');

router.post('/convertAlienhuToTally', async function(req, res, next) {
    try {
        // let resp = await controller1.convertCustomerJSON2XML(req.query);
        let resp = await controller1.convertJSON2XML(req.body.params, req.app.locals.applicationSettings);
        res.send(resp);
        res.end();
    } catch (reason) {
        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    }
});

router.get('/getAllTallyDownloads', function(req, res, next) {

    const resp = controller1.getAllTallyDownloads();
    res.send(resp);
    res.end();

});

router.get('/getTallyFile', function(req, res, next) {

    const fullFilePath = controller1.getTallyFile(req.query.name);
    if (!fullFilePath) {
        //file doesnt' exist send error
        res.send('File Doesnt existed or Deleted. Please export again.');
        res.end();
        return;
    }

    res.download(fullFilePath);
});

router.post('/convertCustomerT2AH', async function(req, res, next) {
    try {
        let resp = await controller2.convertCustomerXML2JSON(req.body);
        res.send(resp);
        res.end();
    } catch (reason) {
        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    }
});

router.post('/convertItemT2AH', async function(req, res, next) {
    try {
        let resp = await controller2.convertItemXML2JSON(req.body, req.app.locals.applicationSettings);
        res.send(resp);
        res.end();
    } catch (reason) {
        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    }
});

module.exports = router;