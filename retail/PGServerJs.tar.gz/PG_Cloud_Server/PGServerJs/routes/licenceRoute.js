/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */
var express = require('express');

var requestIp = require('request-ip');
var licenceRouter = express.Router();
var bodyParser = require('body-parser');
var licenceController = require('../controllers/licence');

licenceRouter.use(bodyParser.json());
licenceRouter.use(bodyParser.urlencoded({
    extended: false
}));

licenceRouter.use(requestIp.mw());

licenceRouter.get('/amILicenced', licenceController.amILicenced);
licenceRouter.get('/pingtestApi', licenceController.pingtestApi);
licenceRouter.post('/requestTrialLicence', licenceController.requestTrialLicence);

//TODO BK delete amIAuthorized2Connect / it should renamed to requestTrialLicence, we dont need this api
//after renaming the Apis at client side close/delete this api
licenceRouter.all('/amIAuthorized2Connect', licenceController.amIAuthorized2Connect);
licenceRouter.post('/grantClientAccess', licenceController.grantClientAccess);

licenceRouter.post('/apply4Licence', licenceController.apply4Licence);

licenceRouter.post('/provisionClientAccess', licenceController.provisionClientAccess);

licenceRouter.get('/signAndPermitProfitGuruLicense', licenceController.signAndPermitProfitGuruLicense);
licenceRouter.get('/getAllClientsList', licenceController.getAllClientsList);

module.exports = licenceRouter;