require('errors');

var coreCouchHandler = require('../couchDb/coreCouchHandler.js');
var bodyParser = require('body-parser');
var CoresRouter = require('express').Router();
CoresRouter.use(bodyParser.urlencoded({
    extended: true
}));
CoresRouter.use(bodyParser.json());

CoresRouter.get('/profitGuruRestApis', function(req, res, next) {
    //Get The App Name
    var appName = req.query.appName === undefined ? process.env.APP_TYPE : req.query.appName.toLowerCase();
    //var appName = req.query.appName.toLowerCase();
    coreCouchHandler.getProfitGuruRestApis(appName, req).then(function(RestApis) {
        res.send(RestApis);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

CoresRouter.get('/profitGuruElements', function(req, res, next) {
    //Get The App Name
    var appName = req.query.appName === undefined ? process.env.APP_TYPE : req.query.appName.toLowerCase();
    //var appName = req.query.appName.toLowerCase();
    coreCouchHandler.getProfitGuruElements(appName).then(function(PGElements) {
        res.send(PGElements);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

CoresRouter.get('/profitGuruProfiles', function(req, res, next) {
    //Get The App Name
    var appName = req.query.appName === undefined ? process.env.APP_TYPE : req.query.appName.toLowerCase();
    //var appName = req.query.appName.toLowerCase();
    coreCouchHandler.getProfitGuruProfiles(appName).then(function(PGProfiles) {
        res.send(PGProfiles);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

module.exports = CoresRouter;