var cutomersLoyalityController = require('../controllers/customersLoyality.js');
var bodyParser = require('body-parser');
require('errors');
var router = require('express').Router();
router.use(bodyParser.urlencoded({
    extended: true
}));
router.use(bodyParser.json());

router.post('/createOrUpdateCustomersLoyality', function(req, res, next) {

    cutomersLoyalityController.createOrUpdateCustomersLoyality(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.put('/update', function(req, res, next) {

    cutomersLoyalityController.createOrUpdateCustomersLoyality(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.delete('/delete', function(req, res, next) {

    cutomersLoyalityController.delete(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

/* BK commentted out
router.get('/getGiftCardsRestApi', function(req, res, next) {

    cutomersLoyalityController.getAllGiftCards().then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
    });
});*/

/**
 * 		Todo: gfCardsOfCustomer is same as the below. Modify the below if required
 */
router.get('/customersLoyalityValue', function(req, res, next) {

    cutomersLoyalityController.customersLoyalityValue(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

/**
 *configsettings4giftcardrestapi will not be implemented get it from applicationSettings
 */

module.exports = router;