var express = require('express');
var router = express.Router();
var logger = require('../common/Logger');
/**
 * todo :pending APi: DeleteItemFromCartRestApi
 */
router.get('/getReceivingsRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.getReceivings().then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.put('/changeModeRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.changeMode(req.body).then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.put('/addSupplier2RecRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.addSupplier(req.body).then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

/**
 *  Todo: 
 *  {
 *    item: 2,
 *    batchId: 'dfaslk123aa',   //force user to enter 
 *    description: 'Hello World',
 *    purchasePrice; 500,
 *    sellingPrice: 200,
 *    mrp: 400,
 *    quantity; 300,
 *    expiry; '20-12-2020', 
 *    discountId: 3
 *  }
 */
router.put('/additem2ReceivingsRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.additem(req.body).then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.put('/additem2RecByIdRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.additemById(req.body).then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.put('/removeItemfromReceivingsRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.removeItem(req.body).then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.post('/DeleteItemFromCart', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.delteItemFromCart(req.body).then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.put('/completeReceiveRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.completeReceivings(req.body).then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.post('/completeReturn', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.completeReturn(req.body).then(function (resp) {
        console.log('Receivings return successfull', resp);
        logger.silly('Receivings return successfull');
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        logger.error('Receivings completeReturn');
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.post('/cancelReceivingsRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.cancelReceivings().then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.post('/saveRecvEditRestApi', function (req, res) {
    res.send(new Error('Not Implemented'));
    res.end();
    // var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    // receivingsController.saveRecvEdit(req.body).then(function(resp) {
    //     logger.silly(resp);
    //     res.send(resp);
    //     res.end();
    // }).catch(function(reason) {
    //     logger.error(reason);
    //     res.send(reason);
    //     res.end();
    // });
});

router.post('/getEditRestApi', function (req, res) {
    res.send(new Error('Not Implemented'));
    res.end();
    // var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    // receivingsController.getEdit(req.body).then(function(resp) {
    //     logger.silly(resp);
    //     res.send(resp);
    //     res.end();
    // }).catch(function(reason) {
    //     logger.error(reason);
    //     res.send(reason);
    //     res.end();
    // });
});

/**
 *   {
 *     line: 2,
 *     description: 'Hello World',
 *     purchasePrice; 500,
 *     sellingPrice: 200,
 *     mrp: 400,
 *     quantity; 300,
 *     expiry; '20-12-2020', 
 *     batchId: 'ABC-99xx',
 *     discountId: 3
 *   }
 *     
 */
router.put('/editRecvItemRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.editItem(req.body).then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.post('/deleteRecvRestApi', function (req, res) {
    res.send(new Error('Not Implemented'));
    res.end();
    // var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    // receivingsController.deleteRecv(req.body).then(function(resp) {
    //     logger.silly(resp);
    //     res.send(resp);
    //     res.end();
    // }).catch(function(reason) {
    //     logger.error(reason);
    //     res.send(reason);
    //     res.end();
    // });
});

router.post('/set_invoice_number_enabledRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.setInvoiceNumberEnabled(req.body).then(function (resp) {
        logger.silly(resp);
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.post('/setInvoiceNumber4RecevingsRestApi', function (req, res) {
    res.send(new Error('Not Implemented'));
    res.end();
    // var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    // receivingsController.setInvoiceNumber(req.body).then(function(resp) {
    //     logger.silly(resp);
    //     res.send(resp);
    //     res.end();
    // }).catch(function(reason) {
    //     logger.error(reason);
    //     res.send(reason);
    //     res.end();
    // });
});

router.post('/add_paymentRestApi', function (req, res) {

    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.add_paymentRestApi(req.body).then(function (resp) {
        //  console.log('Successfully made sales payment', resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });

});

router.post('/setGlobalDiscount', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.setGlobalDiscount(req.body.params).then(function (resp) {
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });

});

router.get('/delete_paymentRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);

    receivingsController.deletePayment(req.query).then(function (resp) {
        logger.silly('success: delete_paymentRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('delete_paymentRestApi');
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.post('/makeCreditPaymentForSupplierApi', function (req, res) {
    console.log("call not reaching here" + req.app.locals.applicationSettings);
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.makeCreditPaymentForSupplier(req.body).then(function (resp) {
        logger.silly('success: makeCreditPaymentForSupplier');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('makeCreditPaymentForSupplier');
        var error = new Error(reason);
        logger.error(error);
        res.send(error);
        res.end();
    });
});
router.delete('/deletePurchase', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    var purchaseId = req.body.receivings_id;

    receivingsController.deletePurchaseById(purchaseId).then(function (resp) {
        console.log('Successfully Deleted Purchase', resp);
        res.send("Successfully deleted Purchase " + purchaseId);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason);
        logger.error(error);
        res.send(reason);
        res.end();
    });
});

router.put('/rejectPurchase', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    var params = req.body;

    receivingsController.rejectPurchase(params).then(function (resp) {
        console.log('Purchase Rejected Successfully', resp);
        res.send("Purchase Rejected Successfully " + params.saleOrRecId);
        res.end();
    }).catch(function (reason) {
        var error = new Error(reason.error);
        logger.error(error);
        res.send(error);
        res.end();
    });
});

router.get('/printPurchaseRestApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.rePrint(req.query).then(function (resp) {
        logger.silly('success: printPurchaseRestApi');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('printPurchaseRestApi');
        logger.error(reason);

        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    });
});

router.post('/setLocalTax', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.setLocalTax(req.body).then(function (resp) {
        logger.silly('success: purchase set bLocalTax');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('error: purchase set bLocalTax');
        logger.error(reason);
        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    });
});
router.put('/initPurchaseEditApi', function (req, res) {
    var receivingsController = require('../controllers/Receivings')(req.session, req.app.locals.applicationSettings);
    receivingsController.initEditPurchaseSession(req.body).then(function (resp) {
        logger.silly('success: load purchase cart for edit');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function (reason) {
        logger.error('load purchase cart for edit');
        logger.error(reason);

        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    });
});
module.exports = router;