var express = require('express');
var router = express.Router();
var controller = require('../Reports/gstr1.js');
const reportController = require('../TSControllers/Reports');

router.post('/gstr1_12', function(req, res) {
    var requestData = req.body;

    controller.head_12(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.post('/gstr2', function(req, res) {
    let controller2 = require('../Reports/gstr2.js');
    var requestData = req.body;

    controller2.getReports(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.get('/getGSTSummaryByHSN', function(req, res) {
    var requestData = req.query;

    controller.head_12(requestData).then(function(resp) {
        res.send(resp.head_12);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.get('/generateReport', async function(req, res) {
    let queryParam = req.query
    try {
        const resp = await reportController.generateReport(queryParam);
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.get('/getAllReports', async function(req, res) {
    var requestData = req.query;
    try {
        const resp = await reportController.getAllReports(requestData);
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.get('/deleteReport', async function(req, res) {
    var requestData = req.query;
    try {
        const resp = await reportController.deleteReport(requestData);
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});
router.get('/deleteAllReports', async function(req, res) {
    var requestData = req.query;
    try {
        const resp = await reportController.deleteAllReports(requestData);
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.get('/downloadReport', function(req, res, next) {
    try {
        const fullFilePath = reportController.downloadReport(req.query);
        res.download(fullFilePath);
    } catch (error) {
        //file doesnt' exist send error
        res.send(error);
        res.end();
        return;
    }
});

module.exports = router;