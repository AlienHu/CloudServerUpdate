let express = require('express');
let router = express.Router();
const feedbackCtrl = require("../controllers/Feedback");
router.post('/addFeedback', function (req, res) {
    var requestData = req.body;
    console.log('requestData', requestData);
    feedbackCtrl.add_feedback(requestData).then(function (resp) {
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});
router.get('/getFeedBackForm', function (req, res) {
    feedbackCtrl.getFeedBackForm(req).then(function (resp) {
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});
router.post('/deleteFeedBackForm', function (req, res) {
    feedbackCtrl.deleteFeedBackForm(req).then(function (resp) {
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});
router.post('/getRepliesForForm', function (req, res) {
    feedbackCtrl.getRepliesForForm(req.body).then(function (resp) {
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        res.status(500).send(new Error(reason.msg));
        res.end();
    });
});
module.exports = router;
//# sourceMappingURL=feedbackRoutes.js.map