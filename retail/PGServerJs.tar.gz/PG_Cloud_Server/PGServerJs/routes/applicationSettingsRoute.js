('errors');

var bodyParser = require('body-parser');
var applicationSettingsRouter = require('express').Router();
var path = require('path');
var platform = /^win/.test(process.platform) ? "windows" : "linux";
var env = process.env.ENVIRONMENT || "development";
var config = require(path.join(__dirname, '..', 'config', 'config.json'))[env];
var shelljs = require('shelljs');
var lockFile = require('lockfile');

var logger = require('../common/Logger');
applicationSettingsRouter.use(bodyParser.urlencoded({
    extended: true
}));
applicationSettingsRouter.use(bodyParser.json());
/**
 * TODO Pending : Reset Sales Data ; Backup Database
 */
applicationSettingsRouter.get('/getApplicationSettings', function(req, res, next) {
    var applicationSettingsCouchHandler = require('../couchDb/applicationSettingsCouchHandler')();

    var appName = req.query.appName === undefined ? process.env.APP_TYPE : req.query.appName.toLowerCase();
    applicationSettingsCouchHandler.getApplicationSettings(appName).then(function(RestApis) {
        res.send(RestApis);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

applicationSettingsRouter.put('/updateApplicationSettings', function(req, res, next) {
    var applicationSettingsCouchHandler = require('../couchDb/applicationSettingsCouchHandler')();

    var appName = req.query.appName === undefined ? process.env.APP_TYPE : req.query.appName.toLowerCase();
    applicationSettingsCouchHandler.updateApplicationSettings(req, appName).then(function(RestApis) {
        res.send(RestApis);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

applicationSettingsRouter.use(bodyParser.json());

applicationSettingsRouter.post('/takeBackUp', function(req, res, next) {
    var backUpController = require('../controllers/backUpAndRestore.js');
    var locationBaseDir4Backup = req.body.backUpLocation ? req.body.backUpLocation : req.app.locals.applicationSettings.backUpLocation[platform];
    //prepare backUp Config
    var backUpConfig = {
        reason4Backup: req.body.reason,
        backUpBaseLocationDir: locationBaseDir4Backup,
        couchConnectUrl: 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT
    };
    try {
        //#Lock the Application
        logger.info('Locking backupStarted');
        lockFile.lockSync('locks/backupStarted.lock');

        backUpController.takeBackUp(backUpConfig).then(function(results) {
            //UnLock the Application
            logger.info('unLocking backupStarted');
            lockFile.unlockSync('locks/backupStarted.lock');
            res.send(results);
            res.end();
        }).catch(function(reason) {
            //UnLock the Application
            logger.info('unLocking backupStarted as ' + reason);
            lockFile.unlockSync('locks/backupStarted.lock');
            res.send(new Error(reason));
            res.end();
        });
    } catch (exception) {
        logger.info('unLocking backupStarted as Exception occured' + exception);
        lockFile.unlockSync('locks/backupStarted.lock');
    }
});

applicationSettingsRouter.get('/listBackUps', function(req, res, next) {
    var backUpController = require('../controllers/backUpAndRestore.js');
    var locationBaseDir4Backup = req.query.backUpLocation ? req.query.backUpLocation : req.app.locals.applicationSettings.backUpLocation[platform];
    backUpController.getBackUpsList(locationBaseDir4Backup).then(function(results) {
        res.send(results);
        res.end();
    }).catch(function(reason) {
        //UnLock the Application
        req.app.locals.lock.status = false;
        res.send(new Error(reason));
        res.end();
    });
});

applicationSettingsRouter.post('/restoreBackUp', function(req, res, next) {
    var backUpController = require('../controllers/backUpAndRestore.js');
    //prepare backUp Config
    var locationBaseDir4Backup = req.body.backUpLocation ? req.body.backUpLocation : req.app.locals.applicationSettings.backUpLocation[platform];
    var restoreConfig = {
        reason4Backup: 'b4_restore',
        backUpBaseLocationDir: locationBaseDir4Backup,
        backUpLocation2Restore: req.body.restoreLocation,
        couchConnectUrl: 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT
    };

    if (!req.body.restoreLocation || !shelljs.test('-d', req.body.restoreLocation)) {

        res.send(new Error('BackUp Asked to Restore=' + req.body.restoreLocation + ' Does not Exists'));
        res.end();
    }
    try {
        //#Lock the Application
        logger.info('locking restoreBackUpStarted');
        lockFile.lockSync('locks/restoreBackUpStarted.lock');
        backUpController.restoreFromBackUp(restoreConfig).then(function(results) {
            //UnLock the Application            
            lockFile.unlockSync('locks/restoreBackUpStarted.lock');
            logger.info('unlocking restoreBackUpStarted');

            res.send(results);
            res.end();
        }).catch(function(reason) {
            //UnLock the Application            
            lockFile.unlockSync('locks/restoreBackUpStarted.lock');
            logger.info('unlocking restoreBackUpStarted as ' + reason);

            res.send(new Error(reason));
            res.end();
        });
    } catch (exception) {
        lockFile.unlockSync('locks/restoreBackUpStarted.lock');
        logger.info('unlocking restoreBackUpStarted as Exception' + exception);
        logger.error('not expected to come to 2nd catch block backuproute');
        res.send(new Error(exception));
        res.end();
    }
});

applicationSettingsRouter.post('/changeDatabaseLocation', function(req, res, next) {
    var backUpController = require('../controllers/backUpAndRestore.js');

    try {
        //#Lock the Application
        logger.info('locking restoreBackUpStarted for changingdatabasedir');
        lockFile.lockSync('locks/restoreBackUpStarted.lock');
        backUpController.changeDatabaseDir(req).then(function(results) {
            //UnLock the Application            
            lockFile.unlockSync('locks/restoreBackUpStarted.lock');
            logger.info('unlocking restoreBackUpStarted');

            res.send(results);
            res.end();
        }).catch(function(reason) {
            //UnLock the Application            
            lockFile.unlockSync('locks/restoreBackUpStarted.lock');
            logger.info('unlocking restoreBackUpStarted as ' + reason);

            res.send(new Error(reason));
            res.end();
        });
    } catch (exception) {
        lockFile.unlockSync('locks/restoreBackUpStarted.lock');
        logger.info('unlocking restoreBackUpStarted as Exception' + exception);
        logger.error('not expected to come to 2nd catch block backuproute');
        res.send(new Error(exception));
        res.end();
    }
});

applicationSettingsRouter.post('/updateReceiptSequence', function(req, res, next) {
    var autoIncrementHelper = require('../controllers/common/autoIncrementHelper.js');

    try {
        //#Lock the Application
        logger.info('locking updateReceiptSequence');
        lockFile.lockSync('locks/updateReceiptSequence.lock');
        autoIncrementHelper.setSalesId().then(function(results) {
            //UnLock the Application            
            lockFile.unlockSync('locks/updateReceiptSequence.lock');
            logger.info('unlocking updateReceiptSequence');

            res.send();
            res.end();
        }).catch(function(reason) {
            //UnLock the Application            
            lockFile.unlockSync('locks/updateReceiptSequence.lock');
            logger.info('unlocking updateReceiptSequence as ' + reason);
            res.send(new Error(reason));
            res.end();
        });
    } catch (exception) {
        lockFile.unlockSync('locks/updateReceiptSequence.lock');
        logger.info('unlocking updateReceiptSequence as Exception' + exception);
        logger.error('not expected to come to 2nd catch block updateReceiptSequence');
        res.send(new Error(exception));
        res.end();
    }
});
applicationSettingsRouter.post('/appLogo', function(req, res, next) {
    logger.info('*** applicationSettingsRoute');
    var appLogo = require('../controllers/appLogo.js');
    var body = req.body;
    if (!body.base64) {
        logger.error('a null base64 found in the request');
        res.send(new Error('a null path found in the request'));
        res.end();
    }
    appLogo.save(body.base64).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });
});

//TODO BK , implement configsettings4giftcardrestapi used in sales
module.exports = applicationSettingsRouter;