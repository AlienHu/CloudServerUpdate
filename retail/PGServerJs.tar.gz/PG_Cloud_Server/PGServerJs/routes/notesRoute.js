require('errors');

var controller = require('../controllers/Notes.js');
var bodyParser = require('body-parser');
var router = require('express').Router();
router.use(bodyParser.urlencoded({
    extended: true
}));
router.use(bodyParser.json());

//http://racksburg.com/choosing-an-http-status-code/

router.post('/saveNotes', function(req, res, next) {
    controller.saveNotes(req.body.data).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.get('/getNotes', function(req, res, next) {
    controller.getNotes(req.body.data).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

module.exports = router;