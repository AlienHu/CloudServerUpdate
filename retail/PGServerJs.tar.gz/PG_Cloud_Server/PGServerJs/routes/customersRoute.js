var customersController = require('../controllers/Elements.js');
var bodyParser = require('body-parser');
require('errors');
var router = require('express').Router();
router.use(bodyParser.urlencoded({
    extended: true
}));
router.use(bodyParser.json());

//http://racksburg.com/choosing-an-http-status-code/

router.post('/create', function(req, res, next) {
    var customerData = req.body.customer;
    customerData.type = "customer_";
    customersController.create(req.body.customer).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

router.put('/update', function(req, res, next) {
    var customerData = req.body.customer;
    customerData.type = "customer_";
    customersController.update(customerData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

router.delete('/delete', function(req, res, next) {
    var customerData = req.body.customer;
    customerData.type = "customer_";
    customersController.delete(customerData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

router.post('/import', function(req, res, next) {
    var body = req.body.data;
    customersController.import(body, 'customer').then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

// router.post('/export', function(req, res, next) {

//     customersController.exportCustomers(req.body.customer).then(function(resp) {
//         res.send(resp);
//         res.end();
//     }).catch(function(reason) {
//         //Todo: Reason is already an error. Can't we just use it? res.send(reason);
//         res.send(reason);
//         res.end();
//     });

// });

module.exports = router;