//var serialNumber = require('serial-number');
var q = require('q');
var os = require('os');
const uuid = require('uuid');
const fs = require('fs');
let macUtilsPath = __dirname + '/../common/macUtils.js';
if (!fs.existsSync(macUtilsPath)) {
    macUtilsPath = __dirname + '/../../common/macUtils.js';
}
const macUtils = require(macUtilsPath);

var _self;
var LiceceGenerator = function () {
    _self = this;
    var licenceSeed = {};
    licenceSeed.clientType = "DeskTopApp";
    licenceSeed.isTrial = true;
    licenceSeed.hostName = require("os").hostname();
    var macs = [];

    // Fetch the computer's mac address 
    function getThisMachineDetails() {
        var machineDetails = {};
        machineDetails.cpus = os.cpus();
        machineDetails.tmpDir = os.tmpdir();
        machineDetails.arch = os.arch();
        machineDetails.totalmemInMB = os.totalmem() / 1048576;
        machineDetails.type = os.type();
        machineDetails.platform = os.platform();
        machineDetails.hostname = os.hostname();
        machineDetails.homedir = os.homedir();
        machineDetails.endianness = os.endianness();
        machineDetails.release = os.release();

        return machineDetails;
    };

    this.genLicence = function (bServerLicence) {
        licenceSeed.macs = macUtils.getMacAddressArray();
        let macAddress = macUtils.getMacAddress();
        macAddress = macAddress.replace(/:/gi, '-');
        macAddress = macAddress.toLowerCase();
        licenceSeed.serialNumber = macAddress;
        licenceSeed.clientId = licenceSeed.serialNumber;

        licenceSeed.machineDetails = getThisMachineDetails();

        if (bServerLicence) {
            let configState = require('../common/configState');
            let config = configState.getAppConfig();
            licenceSeed.cloudCouch = config.cloudCouch;
        }

        return encryptAndPrepareLic();
    };

    function encryptAndPrepareLic() {

        var encryptedLicence = encrypt(JSON.stringify(licenceSeed));

        return {
            'clientId': licenceSeed.clientId,
            'enlicence': encryptedLicence
        };

    };

    function encrypt(text) {
        var crypto = require('crypto'),
            algorithm = 'aes-256-ctr',
            password = licenceSeed.clientId;

        var cipher = crypto.createCipher(algorithm, password);
        var crypted = cipher.update(text, 'utf8', 'hex');
        crypted += cipher.final('hex');
        return crypted;
    }
};

module.exports = new LiceceGenerator();