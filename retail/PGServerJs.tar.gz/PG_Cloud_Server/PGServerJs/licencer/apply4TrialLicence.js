/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */

//var request = require('superagent-bluebird-promise');
var request = require('superagent');
require('superagent-as-promised')(request);

var LicenceGenerator = require('./licenceGenerator.js');

var _self;
var apply4TrialLicence = function () {
    _self = this;
    var thisServerUrl;

    // this.applylicence = function(licenceObj) {
    //     apply4Licence(licenceObj, giveTrialAccess2ThisClinet);
    // };

    this.genAndProvideTrialLicence = async function (appType, serverPort, bDistributor) {

        thisServerUrl = 'http://127.0.0.1' + ':' + serverPort;
        let trialLicence2Apply = LicenceGenerator.genLicence();
        try {
            let lic4TrialPermit = await _self.apply4Licence(appType, trialLicence2Apply);
            let isPermited = await _self.giveTrialAccess2ThisClinet(appType, lic4TrialPermit, bDistributor);
            if (!isPermited) {
                throw isPermited;
            }
            return isPermited
        } catch (err) {
            throw err;
        }
    };

    this.apply4Licence = function (appType, licenceObj) {

        licenceObj.clientType = "DeskTopApp";
        licenceObj.appType = appType;

        return request.post(thisServerUrl + '/licence/apply4Licence').send({
            params: licenceObj
        }).then(function (resp) {
            return Promise.resolve(licenceObj);
        });
    };

    this.giveTrialAccess2ThisClinet = function (appType, licenceObj, bDistributor) {
        var accessDetails = {};
        accessDetails.clientId = licenceObj.clientId;
        accessDetails.validity = bDistributor ? 15 : 7;
        accessDetails.appType = appType;

        return request.post(thisServerUrl + '/licence/provisionClientAccess').send(accessDetails);

    };

};

module.exports = new apply4TrialLicence();