/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */

var createSingleton = require('create-singleton');
var q = require('q');
var arp = require('node-arp');
var profitGuruServerConfig = require('../config/configProfitGuruNodeServer.js');
const profitGuruStatusEvents = require('../common/profitGuruStatusEvents.js');
var licenceHelper = require('../licencer/licenceHelper.js');
var MobileDetect = require('mobile-detect');
var logger = require('../common/Logger');
const configState = require('../common/configState');
const macUtils = require('../common/macUtils');

var _self;
var PGUtilsSingleton = createSingleton(function profitGuruUtils() {
    _self = this;

    profitGuruStatusEvents.on('ServerUUID_Available', function (serverSerilaNumberParam) {
        _self.serverSerilaNumber = serverSerilaNumberParam;
    });

    this.isValidClientType = function (clientType) {
        return profitGuruServerConfig.isValidClientType(clientType);
    };
    this.isValidAppName = function (appName) {
        return configState.isValidAppName(appName);
    };

    this.isValidClientAppName = function (appName) {
        return configState.isValidAppName(appName); // && profitGuruServerConfig.isValidClientType(clientType);
    };

    this.isLocalHostClient = function (req) {
        var requestDevice = new MobileDetect(req.headers['user-agent']);
        var clientType = requestDevice.phone() ? 'MobileApp' : 'DeskTopApp';

        var requestingClinetIp = req.clientIp;
        requestingClinetIp = requestingClinetIp.replace('::ffff:', '');
        return ((requestingClinetIp == '127.0.0.1' || requestingClinetIp == '::1') || requestingClinetIp === licenceHelper.getHostIp()) && clientType === "DeskTopApp";
    };

    this.hasThisClientBeenGivenTrialLicence = function () {

    }
    this.isLicencedProfitGuruClient = function (req, clientType) {
        return new Promise(function (resolve, reject) {

            _self.getClientMacAddress(req, clientType).then(function (clientMac) {
                req.session.clientId = clientMac;
                resolve(licenceHelper.isLicencedProfitGuruClient(clientMac));
            }).catch(function (reason) {
                console.log(reason);
                reject(reason);
            });
        });

    };

    this.getClientMacAddress = function (req, clientType) {
        return new Promise(function (resolve, reject) {
            if (_self.isLocalHostClient(req, clientType)) {
                try {
                    //it is localhost.. getting mac address is very slow .. 500ms on my pc
                    let macAddress = _self.serverSerilaNumber;
                    if (!macUtils.isValidMacAddress(_self.serverSerilaNumber))
                        macAddress = macUtils.getMacAddress(true);
                    resolve(macAddress);
                } catch (error) {
                    reject(error);
                }
            } else {
                var requestingClinetIp = req.clientIp;
                requestingClinetIp = requestingClinetIp.replace('::ffff:', '');
                var clientIpElements = requestingClinetIp.split('.');
                var hostIp = licenceHelper.getHostIp();
                var hostIpElements = hostIp.split('.');
                if (clientIpElements[0] === hostIpElements[0] && clientIpElements[1] === hostIpElements[1] && clientIpElements[2] === hostIpElements[2]) {
                    arp.getMAC(requestingClinetIp, function (err, macAddress) {
                        if (err) {
                            logger.error('arp.getMAC failed');
                            logger.error(err);
                            reject(err);
                        } else {
                            resolve(macAddress);
                        }
                    });
                } else {
                    resolve(_self.serverSerilaNumber);
                }

            }
        });
    };

});
module.exports = new PGUtilsSingleton();