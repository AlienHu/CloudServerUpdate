var argv = require('yargs')
    .usage('Usage: $0 -e <envirnment> -app <AppName> -p <platform> ')
    .alias('e', 'env')
    .describe('e', 'environment(development/production)')
    .choices('e', ['development', 'production'])
    .alias('a', 'app')
    .describe('a', 'Apptype to run (combo/retail/restaurant)')
    .default('a', 'retail')
    .alias('u', 'selfUpdate')
    .describe('u', 'software update')
    .alias('m', 'myself')
    .describe('m', 'Source Name')
    .default('m', 'PGServerJs')
    .help('h')
    .alias('h', 'help')
    .argv;

var shelljs = require('shelljs');

console.log('Env Apptype=', process.env.APP_TYPE);
process.env.APP_TYPE = argv.app;
//}
if (argv.selfUpdate) {
    process.env.enableSelfUpdate = argv.selfUpdate;
}
if (!process.env.MYSELF) {
    process.env.MYSELF = argv.myself;
}

var isWin = /^win/.test(process.platform);
var PM2 = './node_modules/pm2/bin/pm2';
var startPM2;

if (process.env.enableSelfUpdate) {
    console.log('Staring with SelfUpdate Feature.');
    startPM2 = PM2 + ' start -f ' + __dirname + '/../profitGuruUpdater/index.js';
} else {
    startPM2 = PM2 + ' start -f ' + __dirname + '/bin/PGServerJs.js';
}

var log = console.log;
var retailPGserverJs = 'IS_DEMO_APP=yes ENVIRONMENT=development APP_TYPE=retail PROFITGURU_SERVER_PORT=3000 COUCHDB_USERNAME=couchadmin COUCHDB_PASSWORD=test COUCH_PORT=5984 ' + startPM2 + ' --name PG_Retail';
var restaurantPGserverJs = 'IS_DEMO_APP=yes  ENVIRONMENT=development APP_TYPE=restaurant PROFITGURU_SERVER_PORT=3001 COUCHDB_USERNAME=couchadmin COUCHDB_PASSWORD=test COUCH_PORT=5984 ' + startPM2 + ' --name PG_Restaurant';;

if (isWin) {
    PM2 = 'node_modules\\pm2\\bin\\pm2';

    if (process.env.enableSelfUpdate) {
        startPM2 = PM2 + ' start -f ' + __dirname + '/../profitGuruUpdater/index.js';
        startPM2 = PM2 + ' start -f ../profitGuruUpdater/index.js';
    } else {
        startPM2 = PM2 + ' start -f bin/PGServerJs.js';
    }

    retailPGserverJs = 'SET IS_DEMO_APP=yes&& SET ENVIRONMENT=development&& SET APP_TYPE=retail&& SET PROFITGURU_SERVER_PORT=3000&& SET COUCHDB_USERNAME=couchadmin&& SET COUCHDB_PASSWORD=test&& SET COUCH_PORT=5984&& ' + startPM2;
    restaurantPGserverJs = 'SET IS_DEMO_APP=yes&& SET ENVIRONMENT=development&& SET APP_TYPE=restaurant&& SET PROFITGURU_SERVER_PORT=3001&& SET COUCHDB_USERNAME=couchadmin&& SET COUCHDB_PASSWORD=test&& SET COUCH_PORT=5984&& ' + startPM2;
}

shelljs.exec(PM2 + ' delete PGServerJs');
shelljs.exec(PM2 + ' update');

log(retailPGserverJs);

if (shelljs.exec(retailPGserverJs).code !== 0) {
    log('Error while starting retailPGserverJs');
    process.exit(1);
}
//exec('./node_modules/.bin/pm2  save')
log(restaurantPGserverJs);
if (shelljs.exec(restaurantPGserverJs).code !== 0) {
    log('Error while starting restaurantPGserverJs');
    process.exit(1);
}
shelljs.exec(PM2 + ' save ');