//To Do: Add email-template and nodemailer in package.json

var EmailTemplate = require('email-templates').EmailTemplate;
var nodemailer = require('nodemailer');
var path = require('path');
var fs = require('fs');
var templateDir = path.resolve(__dirname, '../templates');
var template = new EmailTemplate(path.join(templateDir, 'e-mailTemplate'));

//function to send email to customer
var sendMailToCustomer = function(requestData, response) {
    return new Promise(function(resolve, reject) {
        //3. sender's credentials -- This should also come from app config file
        var credentials = {
            service: 'gmail',
            auth: {
                user: 'profitguruhelpdesk@gmail.com',
                pass: 'wearethebest'
            }
        };

        //define nodemailer transporter with the credentials
        var transporter = nodemailer.createTransport(credentials);

        //variable to store emailId
        var custEmailId = requestData.email;

        // ToDo:
        // This data will come in requestData argument. Need to read data and populate it template.
        // Template needs to be finalized.
        var locals = {
            item: {
                name: 'Apple',
                price: '120.0'
            },
            total: '120.0',
            date: '25/03/2017'
        };

        template.render(locals, function(err, results) {
            if (err) {
                console.log(err);
                reject(err);
            }

            console.log(results.html.toString());
            console.log(results.text.toString());
            // https://nodemailer.com/about/
            //https://nodemailer.com/message/attachments/

            //CommitTodo :: This was written for completesale. Either make the code common or write new function/file
            var json2csv = require('json2csv');
            var csv = json2csv({
                data: requestData.data
            });

            // ToDo : This mail options needs to be read from app config file
            //CommitTodo: From Body should be changed
            var mailOptions = {
                from: '"Invoice ProfitGuru POS" <profitguruhelpdesk@gmail.com>', // sender address
                to: custEmailId, // list of receivers
                subject: requestData.subject,
                html: results.html,
                text: results.text,
                attachments: [{ // utf-8 string as an attachment
                        filename: requestData.title,
                        content: csv
                    }
                    // { // binary buffer as an attachment
                    //     filename: 'results.text',
                    //     content: new Buffer('hello world!', 'utf-8')
                    // },
                    // {   // file on disk as an attachment
                    //     filename: 'text3.txt',
                    //     path: '/path/to/file.txt' // stream this file
                    // },
                    // {   // filename and content type is derived from path
                    //     path: '/path/to/file.txt'
                    // },
                    // { // stream as an attachment
                    //     filename: 'results.text',
                    //     content: fs.createReadStream('emailtest.txt')
                    // },
                    // { // define custom content type for the attachment
                    //     filename: 'text.bin',
                    //     content: 'hello world!',
                    //     contentType: 'text/plain'
                    // },
                    // { // use URL as an attachment
                    //     filename: 'report.csv',
                    //     path: requestData.path
                    // },
                    // { // encoded string as an attachment
                    //     filename: 'text1.txt',
                    //     content: 'aGVsbG8gd29ybGQh',
                    //     encoding: 'base64'
                    // },
                    // { // data uri as an attachment
                    //     path: 'data:text/plain;base64,aGVsbG8gd29ybGQ='
                    // },
                    // {
                    //     // use pregenerated MIME node
                    //     raw: 'Content-Type: text/plain\r\n' +
                    //         'Content-Disposition: attachment;\r\n' +
                    //         '\r\n' +
                    //         'Hello world!'
                    // }
                ]
            };
            setTimeout(() => {
                console.log('1 seconds Timer expired!!!');
                resolve();
            }, 1000);

            transporter.sendMail(mailOptions, function(err, responseStatus) {
                if (err) {
                    console.error(err);
                    reject(err);
                };
                console.log(responseStatus);
                resolve(responseStatus);
            })

            console.log(err);
        });
    });
}

module.exports = function(requestData, resposne) {
    return sendMailToCustomer(requestData, resposne);
};