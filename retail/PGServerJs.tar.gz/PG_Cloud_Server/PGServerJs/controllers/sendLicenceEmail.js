//To Do: Add email-template and nodemailer in package.json

var EmailTemplate = require('email-templates').EmailTemplate;
var nodemailer = require('nodemailer');
var path = require('path');
var templateDir = path.resolve(__dirname, '../templates');
var template = new EmailTemplate(path.join(templateDir, 'licenceEmailTemplate'));
var env = process.env.ENVIRONMENT || "development";
var config = require(path.join(__dirname, '..', 'config', 'config.json'))[env];

//function to send email to customer
var sendReportEmail = function(requestData, response) {
    return new Promise(function(resolve, reject) {

        var credentials = {
            service: 'gmail',
            auth: {
                user: config.pgFromEmail, //'profitguruhelpdesk@gmail.com',
                pass: config.pgFromEmailPassword //'wearethebest'
            }
        };

        //define nodemailer transporter with the credentials
        var transporter = nodemailer.createTransport(credentials);

        //variable to store emailId
        var profitGuruEmailId = config.pgEmail; // 'admin@alienhu.com';

        // ToDo:
        // This data will come in requestData argument. Need to read data and populate it template.
        // Template needs to be finalized.
        var locals = {

            userInfo: {
                name: requestData.ownerInfo.name,
                phone: requestData.ownerInfo.phone,
                address: requestData.ownerInfo.address,
                email: requestData.ownerInfo.email,
                website: requestData.ownerInfo.website,
                fax: requestData.ownerInfo.fax,
                location: requestData.ownerInfo.location,
                distributorEmail: requestData.ownerInfo.distributorEmail
            },
            licenceDetails: {
                clientId: requestData.data.clientId,
                licenceInfo: requestData.data.licenceInfo
            }
        };

        template.render(locals, function(err, results) {
            if (err) {
                console.log(err);
                reject(err);
            }

            // https://nodemailer.com/about/
            //https://nodemailer.com/message/attachments/

            // ToDo : This mail options needs to be read from app config file
            //CommitTodo: From Body should be changed
            var mailOptions = {
                from: '"Licence Activation Request" <' + config.pgFromEmail + '>', // sender address
                to: profitGuruEmailId, // list of receivers
                subject: 'Activate Licence',
                html: results.html,
                text: results.text
            };

            transporter.sendMail(mailOptions, function(err, responseStatus) {
                if (err) {
                    console.error(err);
                    reject(err);
                };
                console.log(responseStatus);
                resolve(responseStatus);
            })

            console.log(err);
        });

    });
}

module.exports = function(requestData, resposne) {
    return sendReportEmail(requestData, resposne);
};