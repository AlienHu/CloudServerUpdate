const xml2js = require('xml2js-es6-promise');
const mapCustomerTally2Ah  = require('./../TSControllers/tally/mapTally2Ahu/mapCustomerTally2Ahu');
const mapItemTally2Ahu  = require('./../TSControllers/tally/mapTally2Ahu/mapItemTally2Ahu');
const jsonfile = require('jsonfile');


const feedCtrl1 = async function (data,type) { 
     return xml2js(data).then(async function (xmlJson) {
        await jsonfile.writeFileSync('./item.json', xmlJson);
        let parent = xmlJson.ENVELOPE.BODY[0].IMPORTDATA[0].REQUESTDATA[0].TALLYMESSAGE;
        let ledgerArrResp = [];
        if(type === 'CUSTOMER'){
            let customerConverstion = mapCustomerTally2Ah.default;
            ledgerArrResp = await customerConverstion(parent);
        }else{
            let itemConverstion = mapItemTally2Ahu.default;
            ledgerArrResp = await itemConverstion(parent);
        }
        return ledgerArrResp;
    }).catch(function (err) {
        console.log(err);
    });
}

module.exports = feedCtrl1;
