var Notes = function() {

    require('errors');

    //NOSQLTodo move to nosql
    // var notesModel = require('../models').profitGuru_Notes;

    this.saveNotes = function(requestData) {
        //Todo : get logged in employee
        var response = {};
        var loggedInEmployeeId = 1;
        return notesModel.findById(loggedInEmployeeId).then(function(resp) {
            if (resp) {
                var query = {
                    where: {
                        user_id: loggedInEmployeeId
                    }
                };
                return notesModel.update(requestData, query);
            } else {
                var data = {};
                data.notes = requestData.notes;
                data.user_id = loggedInEmployeeId;
                return notesModel.create(data);
            }
        }).then(function() {
            response.status = 'success';
            return response;
        }).catch(function(err) {
            response.status = 'failure';
            response.err = err;
            return response;
        });
    };

    this.getNotes = function() {
        //Todo : get logged in employee        
        var loggedInEmployeeId = 1;
        var response = {};
        response.status = 'no data found';

        return notesModel.findById(loggedInEmployeeId).then(function(resp) {
            if (resp) {
                response.status = 'success';
                response.data = resp.get();
            }
            return response;
        }).catch(function(err) {
            response.err = err;
            return response;
        });
    };

};
module.exports = new Notes();