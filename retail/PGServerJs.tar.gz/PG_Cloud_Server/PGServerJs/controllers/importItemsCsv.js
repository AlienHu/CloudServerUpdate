'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDbManager = require('../dbManagers/couchDbManager');
const couchDBUtils = require('./common/CouchDBUtils');
const googleDrive = require('../common/googleDrive');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const globalConfigController = require('./GlobalConfigurations');
const roomCntrlr = require("../controllers/Rooms");
const logger = require("../common/Logger");
const varientCtrl = require("../controllers/Variants");
const Utils = require('../common/Utils');
const refItem = require('./libraries/refItem');
const utils = require('./common/Utils')
const CLONE = utils.clone;
const itemsValidator = require('./validatiors/Items');

// some of the functions are wrote in this file.
const importHelperCtrl = require('./libraries/importCsvHelper');
let formattedItemsArray = [];
let formattedInvArray = [];

var itemsArray = [];
let defaultUnit = {};
let successCount = 0;
let failedItems = [];
let excelColumns = {};
let csvDataErrorsArray = [];
var platform = /^win/.test(process.platform) ? "windows" : "linux";
var lockFile = require('lockfile');

//to check column exist or not in csv file.
let sheetColumns = {
    "Number Of Batches": 0,
    "Item Code": 0,
    "Name": 0,
    "Barcode": 0,
    "Description": 0,
    "Supplier Name": 0,
    "Category Name": 0,
    "Sub Category": 0,
    "GST Purchase Taxes%": 0,
    "GST Sales Taxes%": 0,
    "CESS Purchase Taxes%": 0,
    "CESS Sales Taxes%": 0,
    "Slab": 0,
    "PP Tax Inclusive": 0,
    "SP Tax Inclusive": 0,
    "Reorder Level": 0,
    "Reorder Quantity": 0,
    "OTG": 0,
    "Attributes": 0,
    "HSN": 0,
    "Unit Name": 0,
    "Selling Unit Name": 0,
    "Purchase Unit Name": 0,
    "Quantity": 0,
    "Batch Id": 0,
    "Expiry Date": 0,
    "Purchase Price": 0,
    "MRP": 0,
    "Selling Price": 0,
    "SKU Name": 0,
    "Discount%": 0
};

/**
 * 
 * @param {*check column exist or not in csv file} columns 
 */
async function excelSheetColumns(columns) {

    console.log("columns:" + columns);
    for (let i = 0; i < columns.length; i++) {
        excelColumns[columns[i]] = 1;
    }
    console.log("JSON.stringify(defaultColumns:" + JSON.stringify(excelColumns));
    console.log("\n\n");
}

// this.importCsvFile = function() {

var csv = require('csvtojson')
console.log("Hello ");
var itemsArray = [];
let appSettings = {};
var catObj = {};
this.runImport = async function (data, settings) {
    var backUpConfig = {
        reason4Backup: "Backup Before Import Items",
        backUpBaseLocationDir: settings.backUpLocation[platform],
        couchConnectUrl: 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT
    };
    try {
        var backUpController = require('../controllers/backUpAndRestore.js');
        //#Lock the Application
        logger.info('Locking backupStarted');
        lockFile.lockSync('locks/backupStarted.lock');

        let backupRes = await backUpController.takeBackUp(backUpConfig);
        logger.info('unLocking backupStarted');
        lockFile.unlockSync('locks/backupStarted.lock');
        appSettings = settings;
        itemsArray = data;
        successCount = itemsArray.length;
        excelColumns = CLONE(sheetColumns);
        failedItems = [];
        csvDataErrorsArray = [];
        excelSheetColumns(Object.keys(itemsArray[0]));
        return run();
    } catch (err) {
        logger.info('unLocking backupStarted as ' + err);
        lockFile.unlockSync('locks/backupStarted.lock');
        throw err;
    }
}

let salesTaxesHeaderNameArr = [];
let purchaseTaxesHeaderNameArr = [];

async function createConfig(key) {

    //check column existing or not in sheet
    if (excelColumns[key] === 0) {

        return;
    }

    let foo = '';
    let categoryName2DocMap = {};
    if (key === 'Category Name') {
        let allOldCategoryList = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
        for (let c = 0; c < allOldCategoryList.length; c++) {
            categoryName2DocMap[allOldCategoryList[c].doc.name.toLowerCase()] = allOldCategoryList[c].doc;
        }
        foo = 'createCategory';
    } else if (key === 'Discount%') {
        foo = 'createDiscount';
    } else if (key.indexOf("Purchase Taxes%") != -1) {
        purchaseTaxesHeaderNameArr.push(key);
        foo = 'createTax';
    } else if (key.indexOf("Sales Taxes%") != -1) {
        salesTaxesHeaderNameArr.push(key);
        foo = 'createTax';
    } else if (key.indexOf("Unit Name") != -1) {
        foo = 'createUnit';
    } else if (key === "Sub Category") {
        foo = 'createSubCategory';
    }

    //process is to get unique config names
    let count = {};
    for (let i = 0; i < itemsArray.length; i++) {

        let configName = itemsArray[i][key] ? itemsArray[i][key] : "";

        if (!configName) {
            // To ignore empty category / subCategory
            continue;
        }
        console.log("configName:" + configName);
        count[configName] = 1;
    }

    let subCategoryArray1 = await couchDBUtils.getAllDocsByType('subCategory', mainDBInstance);

    function getNameID() {
        var tempDirtyObj = {};
        for (var i = 0; i < subCategoryArray1.length; i++) {
            tempDirtyObj[subCategoryArray1[i].doc.name] = subCategoryArray1[i].doc.id;
        };
        return tempDirtyObj;
    }

    //here creating config
    let namesArray = Object.keys(count);
    for (let i = 0; i < namesArray.length; i++) {

        let info;
        if (key === 'Category Name') {
            var subCatIdList = [];
            if (catObj[namesArray[i]]) {
                var idObj = getNameID(subCategoryArray1);
                var subCatNameList = catObj[namesArray[i]];

                for (var k = 0; k < subCatNameList.length; k++) {
                    subCatIdList.push(idObj[subCatNameList[k].toLowerCase()]);
                }
            }

            info = {
                name: namesArray[i],
                description: "Default Categories",
                subCat: subCatIdList
            };
        } else if (key === 'Unit Name' || key === 'Selling Unit Name' || key === 'Purchase Unit Name') {
            info = {
                name: namesArray[i],
                description: "Default Unit"
            }
        } else if (key === 'Discount%') {
            info = {
                name: "discount",
                discount: parseFloat(namesArray[i]),
                description: "Default Discount",

            };
        } else if (key.indexOf("Purchase Taxes%") != -1 || key.indexOf("Sales Taxes%") != -1) {

            let spacePosition = key.indexOf(' ');
            let tempName = key.substr(0, spacePosition);
            // var tax = parseFloat(namesArray[i]) ? parseFloat(namesArray[i]) : 0;
            if (isNaN(parseFloat(namesArray[i]))) {
                continue;
            }
            info = {
                name: tempName,
                percent: parseFloat(namesArray[i]),
                description: tempName + " Tax",

            };
        } else if (key === 'Sub Category') {
            for (let n = 0; n < namesArray.length; n++) {
                let subCat = namesArray[n].split('|');
                for (let m = 0; m < subCat.length; m++) {
                    info = {
                        name: subCat[m].toLowerCase(),
                        description: "Default  Sub Categories"
                    };
                    try {
                        await globalConfigController[foo](info);

                    } catch (error) {
                        console.log(subCat[m] + ' already exist' + " error:");
                    }
                }
            }
            return;
        }
        try {
            if (key == "Category Name" && categoryName2DocMap[info.name.toLowerCase()]) {
                let categoryobjForUpdate;
                if (categoryName2DocMap[info.name.toLowerCase()]) {
                    categoryobjForUpdate = categoryName2DocMap[info.name.toLowerCase()];
                }

                for (var s = 0; s < info.subCat.length; s++) {
                    if (categoryobjForUpdate.subCat.indexOf(info.subCat[s]) === -1) {
                        categoryobjForUpdate.subCat.push(info.subCat[s]);
                    }
                }
                if (!categoryobjForUpdate.description || info.description !== 'Default Categories') {
                    categoryobjForUpdate.description = info.description
                }

                await globalConfigController["updateCategory"](categoryobjForUpdate);
            } else {
                await globalConfigController[foo](info);
            }
        } catch (error) {
            console.log(namesArray[i] + ' already exist' + " error:");
        }
    }
}

async function createVariants() {

    //check columns are existing or not
    if (excelColumns["Attributes"] === 0 && excelColumns["SKU Name"] === 0) {
        return;
    }
    let variantObjects = {};

    let index = 0;
    for (let i = 0; i < itemsArray.length; i += index) {
        let size = parseInt(itemsArray[i]["Number Of Batches"]) ? parseInt(itemsArray[i]["Number Of Batches"]) : 1;
        let initialQty = parseInt(itemsArray[i]["Initial Quantity"]) ? parseInt(itemsArray[i]["Initial Quantity"]) : 1;
        index = size;
        if (itemsArray[i]["Attributes"] === '-' || itemsArray[i]["Attributes"] === ' ') {
            continue;
        }
        console.log("itemsArray[" + i + "]:" + itemsArray[i]["Attributes"]);
        let VariantsNamesArray = itemsArray[i]["Attributes"] ? itemsArray[i]["Attributes"].split('/') : [];

        for (let k = i; k < (i + size); k += initialQty) {
            let variantsValuesArray = itemsArray[k]["SKU Name"] ? itemsArray[k]["SKU Name"].split("/") : [];
            //write condition that valuesarray length and namesarray length is same
            for (let j = 0; j < VariantsNamesArray.length; j++) {
                let variantName = VariantsNamesArray[j];
                if (!variantObjects[variantName]) {
                    variantObjects[variantName] = [];
                }

                let variantValue = variantsValuesArray[j];
                // while importing it will filter the duplicate Attributes in an variant
                let dupValue = false;
                for (var l = 0; l < variantObjects[variantName].length; l++) {
                    if (variantObjects[variantName][l].toLowerCase() == variantValue.toLowerCase()) {
                        dupValue = true;
                        break;
                    }
                }
                if (!dupValue) {
                    variantObjects[variantName].push(variantValue);
                }
            }
        }
    }

    //convert to required    
    for (let variantName in variantObjects) {
        let doc = {
            name: variantName,
            values: []
        };
        for (let i = 0; i < variantObjects[variantName].length; i++) {
            if (variantObjects[variantName][i] !== '-' && variantObjects[variantName][i] !== ' ') {
                doc.values.push({
                    name: variantObjects[variantName][i]
                });
            }
        }
        await varientCtrl.create(doc)
            .then(function (response) {
                console.log("response:" + JSON.stringify(response));
            }).catch(function (error) {
                console.log("error:" + JSON.stringify(error));
            });

    }
}

async function createSlab() {

    //check if column existing or not
    if (excelColumns["Garments"] === 0) {
        return;
    }

    let slabObj = {
        name: "Garments",
        taxName: "GST",
        rates: [{
            min: 10,
            max: 10000,
            percent: 10
        }]
    };

    try {
        await globalConfigController["createSlab"](slabObj);
    } catch (error) {
        console.log("creating Slab error:" + error);
    }

}

async function createSupplier() {
    var faker = require('faker');
    faker.locale = 'en_IND';
    //check column existing or not
    if (excelColumns["Supplier Name"] === 0) {
        return;
    }
    let elementsCtrl = require("./Elements");
    let count = {};
    for (let i = 0; i < itemsArray.length; i++) {

        let configName = itemsArray[i]["Supplier Name"];

        if (!configName) {
            // To ignore empty category / subCategory
            continue;
        }
        console.log("configName:" + configName);
        count[configName] = 1;
    }

    //here creating config
    let namesArray = Object.keys(count);
    for (let j = 0; j < namesArray.length; j++) {
        var nameComps = namesArray[j].split(' ');

        let supplier = {
            type: "supplier_",
            company_name: namesArray[j] + ' Company',
            first_name: nameComps[0],
            last_name: nameComps[1] ? nameComps[1] : nameComps[0],
            email: namesArray[j].replace(/\s/g, '') + "@gmail.com",
            gender: "0",
            phone_number: faker.phone.phoneNumber()
        };
        try {
            let response = await elementsCtrl.create(supplier);
            console.log("Supplier response:" + JSON.stringify(response));
        } catch (error) {
            console.log("Supplier err:" + JSON.stringify(error));
        }

    }

}

async function createGeneralCategory() {

    //check if column existing or not
    if (excelColumns["Category Name"] === 1) {
        return;
    }
    // if column doesn't exist, create General Category
    let info = {
        name: "General",
        description: "Default Categories",
        subCat: []
    };

    try {

        await globalConfigController["createCategory"](info);
        console.log("try block of createGeneralCategory");
    } catch (error) {
        console.log("General" + ' already exist' + " error:");
    }

}
async function getDefaultConfigs() {
    defaultUnit = await couchDBUtils.getDoc('unit_' + appSettings.defaultUnitSettings.id, mainDBInstance);

}

async function addSubCategoriesToCAtegory() {
    for (var x in itemsArray) {
        var categoryName = itemsArray[x]['Category Name'];
        if (itemsArray[x]['Sub Category']) {
            var categorySubcategoryList = itemsArray[x]['Sub Category'].split('|');

            if (categoryName in catObj) {

                for (var z in categorySubcategoryList) {

                    if (catObj[categoryName].indexOf(categorySubcategoryList[z]) === -1) {
                        catObj[categoryName].push(categorySubcategoryList[z]);
                    }
                }

            } else {
                catObj[categoryName] = categorySubcategoryList;
            }
        }
    }

}

async function prepare() {
    console.log("calling prepare method");

    if (excelColumns['Sub Category'] === 1) {
        await createConfig('Sub Category')
    }

    //create Categories config
    if (excelColumns['Category Name'] === 1) {
        await createConfig('Category Name');
    }

    //create Discount config
    if (excelColumns['Discount%'] === 1) {
        await createConfig('Discount%');
    }

    if (excelColumns['Unit Name'] === 1) {
        await createConfig('Unit Name');
    }
    if (excelColumns['Selling Unit Name'] === 1) {
        await createConfig('Selling Unit Name');
    }
    if (excelColumns['Purchase Unit Name'] === 1) {
        await createConfig('Purchase Unit Name');
    }
    //create variants
    await createVariants();

    //create tax config
    let headers = Object.keys(itemsArray[0]);
    for (let i = 0; i < headers.length; i++) {

        if (headers[i].indexOf("Purchase Taxes%") != -1 || headers[i].indexOf("Sales Taxes%") != -1) {
            await createConfig(headers[i]);
        }

    }

    console.log("calling create supplier method");
    //create supplier
    await createSupplier();

    console.log("calling create slab method");

    await createSlab();

    console.log("calling createGeneralCategory method");

    await createGeneralCategory();

    console.log("\n\n")
}

let categoryObj = {};
let taxObj = {};
let variantObj = {};
let supplierObj = {};
let slabObj = {};
let unitObj = {};
let pprofileObj = {};
let discountObj = {};
let subCategoryobj = {};

async function getIds() {
    console.log("calling getIds");
    //tax, category, saleUnit, purchaseUnit
    let categoryArray = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
    let taxArray = await couchDBUtils.getAllDocsByType('tax', mainDBInstance);
    let variantArray = await couchDBUtils.getAllDocsByType('variant', mainDBInstance);
    let supplierArray = await couchDBUtils.getAllDocsByType('supplier', mainDBInstance);
    let slabArray = await couchDBUtils.getAllDocsByType('slab', mainDBInstance);
    let unitArray = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);
    let pprofileArray = await couchDBUtils.getAllDocsByType('pProfile', mainDBInstance);
    let discountArray = await couchDBUtils.getAllDocsByType('discount', mainDBInstance);
    let subCategoryArray = await couchDBUtils.getAllDocsByType('subCategory', mainDBInstance);
    //Initialize category array
    for (let i = 0; i < categoryArray.length; i++) {
        categoryObj[categoryArray[i].doc.name.toLowerCase()] = categoryArray[i].doc.id;
    }

    //Initialize Tax array
    for (let i = 0; i < taxArray.length; i++) {
        let salesKey = taxArray[i].doc.name + ' Sales Taxes% ' + taxArray[i].doc.percent;
        let purchaseKey = taxArray[i].doc.name + ' Purchase Taxes% ' + taxArray[i].doc.percent;
        taxObj[salesKey.toLowerCase()] = taxArray[i].doc.id;
        taxObj[purchaseKey.toLowerCase()] = taxArray[i].doc.id;
    }

    console.log(" variantArray.length:" + variantArray.length);
    //Initialize variant array
    for (let i = 0; i < variantArray.length; i++) {
        variantObj[variantArray[i].doc.name.toLowerCase()] = variantArray[i].doc.id;
        let valueKeys = Object.keys(variantArray[i].doc.values);
        let valueValues = Object.values(variantArray[i].doc.values);

        for (let j = 0; j < valueValues.length; j++) {
            variantObj[variantArray[i].doc.name.toLowerCase() + " " + valueValues[j]["name"].toLowerCase()] = valueKeys[j];
        }
    }

    for (let i = 0; i < supplierArray.length; i++) {
        supplierObj[(supplierArray[i].doc.first_name + ' ' + supplierArray[i].doc.last_name).toLowerCase()] = supplierArray[i].doc.person_id;
    }

    //Initialize slab array
    for (let i = 0; i < slabArray.length; i++) {
        slabObj[slabArray[i].doc.name.toLowerCase()] = slabArray[i].doc.id;
    }

    //Initialize unit array
    for (let i = 0; i < unitArray.length; i++) {
        unitObj[unitArray[i].doc.name.toLowerCase()] = unitArray[i].doc.id;
    }

    //Initialize profile array
    for (let i = 0; i < pprofileArray.length; i++) {
        pprofileObj[pprofileArray[i].doc.name.toLowerCase()] = pprofileArray[i].doc.id;
    }

    //Initialize discount array
    for (let i = 0; i < discountArray.length; i++) {
        discountObj[discountArray[i].doc.discount] = discountArray[i].doc.id;
    }
    for (let i = 0; i < subCategoryArray.length; i++) {
        subCategoryobj[subCategoryArray[i].doc.name.toLowerCase()] = subCategoryArray[i].doc.id;
    }
}

function checkBooleanType(data) {

    if (data.toLowerCase() === "true" || data.toLowerCase() === "false" ||
        data.toLowerCase() === "no" || data.toLowerCase() === "yes") {
        return true;
    }
    return false;
}

function formsUnitInfo(item, unitName, index) {
    let ptemp = {};

    //selling price
    if (excelColumns["Selling Price"] === 0) {
        ptemp["sellingPrice"] = 0;
    } else if (!(isNaN(parseInt(item["Selling Price"]))) && !(importHelperCtrl.checkBlankOrHypen(item["Selling Price"])) &&
        !(importHelperCtrl.checkBlankOrHypen(item["Selling Price"]))) {
        ptemp["sellingPrice"] = parseFloat(item["Selling Price"]);
    } else if (excelColumns["Selling Price"] === 1) {
        ptemp["sellingPrice"] = 0;
        let error = importHelperCtrl.checkErrorType(item["Selling Price"]);

        if (!importHelperCtrl.checkNumberType(item["Selling Price"])) {
            error = "is not type of Number";
        }
        error = "at line:" + (index + 2) + " Selling Price " + error;
        csvDataErrorsArray.push(error);
    }

    //
    if (excelColumns["Discount%"] === 0) {
        ptemp["discountId"] = "";
    } else if (excelColumns["Discount%"] === 1 && !(isNaN(parseInt(item["Discount%"]))) && !(importHelperCtrl.checkBlankOrHypen(item["Discount%"])) &&
        !(importHelperCtrl.checkBlankOrHypen(item["Discount%"]))) {
        let discount = item["Discount%"];
        if (!isNaN(discount)) {
            ptemp["discountId"] = discountObj[discount];
        }
    } else if (excelColumns["Discount%"] === 1) {
        item["Discount%"] = item["Discount%"] ? item["Discount%"] : "";
        let error = importHelperCtrl.checkErrorType(item["Discount%"]);

        if (!importHelperCtrl.checkNumberType(item["Discount%"])) {
            error = "is not type of Number, please enter number only";
        }
        error = "at line:" + (index + 2) + " Discount% " + error;
        csvDataErrorsArray.push(error);
    }

    let pProfilesData = {};
    let profile1 = pprofileObj["default profile"];
    pProfilesData[profile1] = ptemp;

    let unitInfo = {};
    let sellingId = unitObj[item.sellingUnit.toLowerCase()];
    let purUID = unitObj[item.purchaseUnit.toLowerCase()];

    let tempObj = {};
    tempObj["refUnitId"] = sellingId;
    tempObj["factor"] = (item.hasOwnProperty('Conversion Factor') && item['Conversion Factor']) ? parseFloat(item['Conversion Factor']) : 1;

    //purchase price
    if (excelColumns["Purchase Price"] === 0) {
        tempObj["purchasePrice"] = 0;
    } else if (excelColumns["Purchase Price"] === 1 && !(isNaN(parseInt(item["Purchase Price"]))) && !(importHelperCtrl.checkBlankOrHypen(item["Purchase Price"])) &&
        !(importHelperCtrl.checkBlankOrHypen(item["Purchase Price"]))) {
        tempObj["purchasePrice"] = parseFloat(item["Purchase Price"]);
    } else if (excelColumns["Purchase Price"] === 1) {
        tempObj["purchasePrice"] = 0;
        let error = importHelperCtrl.checkErrorType(item["Purchase Price"]);

        if (!importHelperCtrl.checkNumberType(item["Purchase Price"])) {
            error = "is not type of Number";
        }
        error = "at line:" + (index + 2) + " Purchase Price " + error;
        csvDataErrorsArray.push(error);
    }

    if (excelColumns["MRP"] === 0) {
        tempObj["mrp"] = 0;
    } else if (excelColumns["MRP"] === 1 && !(isNaN(parseInt(item["MRP"]))) && !(importHelperCtrl.checkBlankOrHypen(item["MRP"])) &&
        !(importHelperCtrl.checkBlankOrHypen(item["MRP"]))) {
        tempObj["mrp"] = parseFloat(item["MRP"]);
    } else if (excelColumns["MRP"] === 1) {
        tempObj["mrp"] = 0;
        let error = importHelperCtrl.checkErrorType(item["MRP"]);

        if (!importHelperCtrl.checkNumberType(item["MRP"])) {
            error = "is not type of Number";
        }
        error = "at line:" + (index + 2) + " MRP " + error;
        csvDataErrorsArray.push(error);
    }

    if (tempObj.factor > 1 || sellingId !== purUID) {
        var purUnitObj = CLONE(tempObj);
        var saleUnitObj = CLONE(tempObj);
        //purchase unit
        var purProfile = CLONE(pProfilesData);
        purProfile[profile1].sellingPrice *= purUnitObj.factor;
        purUnitObj.mrp *= purUnitObj.factor;
        purUnitObj["pProfilesData"] = purProfile;
        unitInfo[purUID] = purUnitObj;
        //selling Unit
        saleUnitObj.purchasePrice = tempObj.purchasePrice / tempObj.factor;
        saleUnitObj.factor = 1;
        saleUnitObj["pProfilesData"] = pProfilesData;
        unitInfo[sellingId] = saleUnitObj;
    } else {
        tempObj.factor = 1;
        tempObj["pProfilesData"] = pProfilesData;
        unitInfo[purUID] = tempObj;
    }

    return unitInfo;
}

let globalAttributesName = "";

async function formsInitialStock(item, index) {
    let initStock = {};

    //quantity, set default values and check values
    if (excelColumns["Quantity"] === 0) {
        initStock["quantity"] = 0;
    } else if (excelColumns["Quantity"] === 1 && !isNaN(parseFloat(item["Quantity"])) && !(importHelperCtrl.checkBooleanType(item["Quantity"])) &&
        !(importHelperCtrl.checkBlankOrHypen(item["Quantity"]))) {
        initStock["quantity"] = parseFloat(item["Quantity"]);
    } else if (excelColumns["Quantity"] === 1) {
        initStock["quantity"] = 0;
        let error = importHelperCtrl.checkErrorType(item["Quantity"]);

        if (!importHelperCtrl.checkNumberType(item["Quantity"])) {
            error = "is not type of Number";
        }
        error = "at line:" + (index + 2) + " Quantity " + error;
        csvDataErrorsArray.push(error);
    }

    // batch ID
    if (excelColumns["Batch Id"] === 1 && !(importHelperCtrl.checkBooleanType(item["Batch Id"]))) {
        if (!(importHelperCtrl.checkBlankOrHypen(item["Batch Id"]))) {
            initStock["batchId"] = item["Batch Id"];
        }
    } else if (excelColumns["Batch Id"] === 1) {
        let error = importHelperCtrl.checkErrorType(item["Batch Id"]);
        error = "at line:" + (index + 2) + "Batch Id " + error;
        csvDataErrorsArray.push(error);
    }

    //expiry Date, check column, and type validation
    if (excelColumns["Expiry Date"] === 0) {
        initStock["expiry"] = null;
    } else {
        if (!(importHelperCtrl.checkBlankOrHypen(item["Expiry Date"])) &&
            !(importHelperCtrl.checkBooleanType(item["Expiry Date"]))) {
            initStock["expiry"] = new Date(item["Expiry Date"]);
        }
    }
    let unit = item["Unit Name"] ? item["Unit Name"] : defaultUnit.name;
    //initiliazing the unitInfo
    await fillUnitsData(item);
    initStock["unitsInfo"] = formsUnitInfo(item, unit, index);

    if (item.uniqueDetails) {
        initStock["uniqueDetails"] = item.uniqueDetails;

    }
    initStock["quantity"] = item.uniqueDetails.length ? item.uniqueDetails.length : initStock["quantity"];

    if (excelColumns["SKU Name"] === 1) {

        let attributeInfo = {};

        if (!(importHelperCtrl.checkBlankOrHypen(globalAttributesName)) && !(importHelperCtrl.checkBlankOrHypen(item["SKU Name"]))) {
            console.log("\ninside condition:");
            initStock["skuName"] = item["SKU Name"];
            let AttributeNames = globalAttributesName ? globalAttributesName.split("/") : [];
            let AttributeValues = initStock["skuName"] ? initStock["skuName"].split("/") : [];
            for (let i = 0; i < AttributeNames.length; i++) {
                attributeInfo[String(variantObj[AttributeNames[i].toLocaleLowerCase()])] = String(variantObj[AttributeNames[i].toLocaleLowerCase() + " " + AttributeValues[i].toLocaleLowerCase()]);
            }
            initStock["attributeInfo"] = attributeInfo;
        }

    }

    return initStock;

}

let firstLevelFields = {
    "uniqueItemCode": "Item Code",
    "name": "Name",
    "item_number": "Barcode",
    "description": "Description",
    "bPPTaxInclusive": "PP Tax Inclusive",
    "bSPTaxInclusive": "SP Tax Inclusive",
    "reorderLevel": "Reorder Level",
    "reorderQuantity": "Reorder Quantity",
    "bOTG": "OTG",
    "hsn": "HSN",
    "is_serialized": "Has Serial No"
};

async function fillUnitsData(itemJson, pgItem) {
    var unitName = "";
    var puchaseUnit = "";
    if (itemJson.hasOwnProperty('Purchase Unit Name') && itemJson.hasOwnProperty('Selling Unit Name') && itemJson.hasOwnProperty('Conversion Factor')) {
        unitName = itemJson["Selling Unit Name"] ? itemJson["Selling Unit Name"] : defaultUnit.name;

        // defaultPurchaseUnitId 
        puchaseUnit = itemJson["Purchase Unit Name"] ? itemJson["Purchase Unit Name"] : defaultUnit.name;

        itemJson.sellingUnit = unitName.toLowerCase();
        itemJson.purchaseUnit = puchaseUnit.toLowerCase();
        if (pgItem) {
            pgItem.baseUnitId = parseInt(unitObj[unitName.toLowerCase()]);
            pgItem.defaultSellingUnitId = parseInt(unitObj[unitName.toLowerCase()]);
            pgItem.defaultPurchaseUnitId = parseInt(unitObj[puchaseUnit.toLowerCase()]);
        }
    } else {
        unitName = itemJson["Unit Name"] ? itemJson["Unit Name"] : defaultUnit.name;

        itemJson.sellingUnit = unitName.toLowerCase();
        itemJson.purchaseUnit = unitName.toLowerCase();
        if (pgItem) {
            pgItem.baseUnitId = parseInt(unitObj[unitName.toLowerCase()]);
            pgItem.defaultSellingUnitId = parseInt(unitObj[unitName.toLowerCase()]);
            pgItem.defaultPurchaseUnitId = parseInt(unitObj[unitName.toLowerCase()]);
        }
    }
}

function capitalize(str) {
    return str.replace(/\w\S*/g, function (txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    });
}
async function createItemArray() {
    let itemController = require('./Items');
    const fs = require('fs');
    const applicationResourceSettings = appSettings.resources;
    const imageConfig = applicationResourceSettings.images;
    const originalImageOption = imageConfig.original;
    const thumbnailImageOption = imageConfig.thumbnail;
    const bLocalImageEnabled = imageConfig.enable;
    const bGoogleDriveEnabled = imageConfig.googleDriveIntegration.enable;
    const googelDriveFolderId = imageConfig.googleDriveIntegration.itemImageFolderId;
    let dependencyDataAvailable = false;
    const appFolderName = process.env.APP_TYPE.toUpperCase() + "/";
    const tokenPath = applicationResourceSettings.directory + applicationResourceSettings.rootFolder + applicationResourceSettings.resourceFolder + appFolderName + applicationResourceSettings.infoFolder + imageConfig.googleDriveIntegration.tokenFile;
    const credentialPath = applicationResourceSettings.directory + applicationResourceSettings.rootFolder + applicationResourceSettings.resourceFolder + appFolderName + applicationResourceSettings.infoFolder + imageConfig.googleDriveIntegration.credentialFile;
    const localImageFolder = applicationResourceSettings.directory + applicationResourceSettings.rootFolder + applicationResourceSettings.resourceFolder + appFolderName + applicationResourceSettings.itemImageFolder;
    try {
        fs.readFileSync(tokenPath);
        if (googelDriveFolderId) {
            dependencyDataAvailable = true;
        }
    } catch (err) {
        logger.error(err);
    }

    let prevCategory = "";
    let index = 0;
    let bMobile = false;

    for (let i = 0; i < itemsArray.length; i += index) {
        let size = parseInt(itemsArray[i]["Number Of Batches"]) ? parseInt(itemsArray[i]["Number Of Batches"]) : 1;;
        index = size;
        if (!itemsArray[i]['Name']) {
            csvDataErrorsArray.push("at line:" + (i + 2) + "Name is Empty");
            continue;
        } else if (!itemsArray[i]['Category Name']) {
            csvDataErrorsArray.push("at line:" + (i + 2) + "Category is Empty");
            continue;
        }
        if ((itemsArray[i]['Slab'] && itemsArray[i]['PP Tax Inclusive'].toLowerCase() === 'yes') || (itemsArray[i]['Slab'] && itemsArray[i]['SP Tax Inclusive'].toLowerCase() === 'yes')) {
            csvDataErrorsArray.push("at line:" + (i + 2) + "Slab and Tax Inclusive doesn't works together");
            continue;
        }
        let pgItem = {
            initialStock: []
        };
        pgItem.ItemType = itemsArray[i]['Item Type'] ? itemsArray[i]['Item Type'] : "Normal";
        pgItem.ItemType = capitalize(pgItem.ItemType);

        if (!itemsArray[i]['Has Serial No']) {
            itemsArray[i]['Has Serial No'] = 'no';
        }

        // keys
        let firstLevelKeys = Object.keys(firstLevelFields);

        //values
        let firstLevelValues = Object.values(firstLevelFields);

        //first level fields of csv file
        for (let k = 0; k < firstLevelKeys.length; k++) {

            //checking column exist or not and if not assign default value
            if (excelColumns[firstLevelValues[k]] === 0) {
                if (firstLevelValues[k] === "Item Code" || firstLevelValues[k] === "Barcode" ||
                    firstLevelValues[k] === "Description" || firstLevelValues[k] === "Reorder Level" ||
                    firstLevelValues[k] === "Reorder Quantity" || firstLevelValues[k] === "HSN") {
                    pgItem[firstLevelKeys[k]] = "";
                } else if (firstLevelValues[k] === "PP Tax Inclusive" || firstLevelValues[k] === "SP Tax Inclusive" ||
                    firstLevelValues[k] === "OTG" || firstLevelValues[k] === "Has Serial No") {
                    pgItem[firstLevelKeys[k]] = false;
                }
                continue;
            } else if ((firstLevelValues[k] === "PP Tax Inclusive" || firstLevelValues[k] === "SP Tax Inclusive" ||
                firstLevelValues[k] === "OTG" || firstLevelValues[k] === "Has Serial No") && itemsArray[i][firstLevelValues[k]] === '') {
                pgItem[firstLevelKeys[k]] = false;
                continue;
            }

            console.log(itemsArray[i][firstLevelValues[k]]);
            if (itemsArray[i][firstLevelValues[k]].toLowerCase() === 'no') {
                //bPP taxInclusive,bSP taxInclusive,bOTG
                pgItem[firstLevelKeys[k]] = false;
                continue;
            } else if (itemsArray[i][firstLevelValues[k]].toLowerCase() === 'yes') {
                //bPP taxInclusive,bSP taxInclusive,bOTG
                pgItem[firstLevelKeys[k]] = true;
                continue;
            } else if (!isNaN(parseInt(itemsArray[i][firstLevelValues[k]])) && firstLevelValues[k] !== "HSN" && firstLevelValues[k] !== "Item Code" && firstLevelValues[k] !== "Barcode" && firstLevelValues[k] !== "Name" && firstLevelValues[k] !== "Description") {
                //selling price, purchase price, mrp
                pgItem[firstLevelKeys[k]] = parseInt(itemsArray[i][firstLevelValues[k]]);
                continue;
            }

            // if values are right, will assign to item; 
            pgItem[firstLevelKeys[k]] = itemsArray[i][firstLevelValues[k]];

        }

        //Supplier id, column check , type validation
        if (excelColumns["Supplier Name"] === 1 && isNaN(parseInt(itemsArray[i]["Supplier Name"])) && !(importHelperCtrl.checkBooleanType(itemsArray[i]["Supplier Name"])) &&
            !(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["Supplier Name"]))) {
            var nameComps = itemsArray[i]["Supplier Name"].split(' ');
            var supName = nameComps[1] ? itemsArray[i]["Supplier Name"] : nameComps[0] + ' ' + nameComps[0];
            pgItem.supplier_id = supplierObj[supName.toLowerCase()];
        } else if (excelColumns["Supplier Name"] === 1) {
            let error = importHelperCtrl.checkErrorType(itemsArray[i]["Supplier Name"]);
            if (importHelperCtrl.checkNumberType(itemsArray[i]["Supplier Name"])) {
                error = "is type of Number";
            }
            error = "at line:" + (i + 2) + " Supplier Name " + error;
            csvDataErrorsArray.push(error);
        }

        //Category id,  column check , type validation
        if (excelColumns["Category Name"] === 1 && !(importHelperCtrl.checkBooleanType(itemsArray[i]["Category Name"])) &&
            !(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["Category Name"]))) {
            pgItem.categoryId = categoryObj[itemsArray[i]["Category Name"].toLowerCase()];
        } else if (excelColumns["Category Name"] === 0) {
            pgItem.categoryId = categoryObj["general"];
        } else if (excelColumns["Category Name"] === 1) {
            let error = importHelperCtrl.checkErrorType(itemsArray[i]["Category Name"]);
            if (importHelperCtrl.checkNumberType(itemsArray[i]["Category Name"])) {
                error = "is type of Number";
            }

            error = "at line:" + (i + 2) + " Category Name " + error;
            csvDataErrorsArray.push(error);
        }

        //purchase Slab id,  column check , type validation
        if (excelColumns["Slab"] === 1 && isNaN(parseInt(itemsArray[i]["Slab"])) && !(importHelperCtrl.checkBooleanType(itemsArray[i]["Slab"])) &&
            !(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["Slab"]))) {
            if (itemsArray[i]["Slab"].toLowerCase() in slabObj) {
                pgItem.purchaseSlab = slabObj[itemsArray[i]["Slab"].toLowerCase()];
            } else {
                csvDataErrorsArray.push("line #" + (i + 2) + ": Please create" + itemsArray[i]["Slab"] + " slab first");
                successCount -= 1;
                continue;
            }
        } else if (excelColumns["Slab"] === 1) {
            let error = importHelperCtrl.checkErrorType(itemsArray[i]["Slab"]);
            if (importHelperCtrl.checkNumberType(itemsArray[i]["Slab"])) {
                error = "is type of Number";
            }
            error = "at line:" + (i + 2) + " Slab " + error;
            csvDataErrorsArray.push(error);
        }

        //sales Slab Id,  column check , type validation
        if (excelColumns["Slab"] === 1 && isNaN(parseInt(itemsArray[i]["Slab"])) && !(importHelperCtrl.checkBooleanType(itemsArray[i]["Slab"])) &&
            !(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["Slab"]))) {
            if (itemsArray[i]["Slab"].toLowerCase() in slabObj) {
                pgItem.salesSlab = slabObj[itemsArray[i]["Slab"].toLowerCase()];
            } else {
                csvDataErrorsArray.push("line #" + (i + 2) + ": Please create" + itemsArray[i]["Slab"] + " slab first");
                successCount -= 1;
                continue;
            }
        } else if (excelColumns["Slab"] === 1) {
            let error = importHelperCtrl.checkErrorType(itemsArray[i]["Slab"]);
            if (importHelperCtrl.checkNumberType(itemsArray[i]["Slab"])) {
                error = "is type of Number";
            }

            error = "at line:" + (i + 2) + " Slab " + error;
            csvDataErrorsArray.push(error);
        }

        // some of the fields are necessary but don't use anywhere, so they have been filled in this function
        importHelperCtrl.setDefaultFields(pgItem);

        await fillUnitsData(itemsArray[i], pgItem);

        //sales Tax
        pgItem.salesTaxes = [];

        for (let j = 0; j < salesTaxesHeaderNameArr.length; j++) {
            let headerName = salesTaxesHeaderNameArr[j];
            let taxPercent = parseFloat(itemsArray[i][headerName]);
            if (isNaN(taxPercent)) {
                continue;
            }
            let taxId = taxObj[(salesTaxesHeaderNameArr[j] + " " + taxPercent).toLowerCase()];
            if (pgItem.salesTaxes.indexOf(taxId) === -1) {
                pgItem.salesTaxes.push(taxId);
            }
        }

        //purchase tax
        pgItem.purchaseTaxes = [];
        for (let j = 0; j < purchaseTaxesHeaderNameArr.length; j++) {
            let headerName = purchaseTaxesHeaderNameArr[j];
            let taxPercent = parseFloat(itemsArray[i][headerName]);
            if (isNaN(taxPercent)) {
                continue;
            }
            let taxId = taxObj[(purchaseTaxesHeaderNameArr[j] + " " + taxPercent).toLowerCase()];
            if (pgItem.purchaseTaxes.indexOf(taxId) === -1) {
                pgItem.purchaseTaxes.push(taxId);
            }
        }

        let attributes = [];

        //has variants default value false 
        pgItem.hasVariants = false;

        if (excelColumns["Attributes"] === 1) {
            //globalAttributeName 
            globalAttributesName = itemsArray[i]["Attributes"];
            if (!(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["Attributes"]))) {
                // Attributes
                let attributesArray = itemsArray[i]["Attributes"] ? itemsArray[i]["Attributes"].split("/") : [];
                for (let j = 0; j < attributesArray.length; j++) {
                    attributes.push(variantObj[attributesArray[j].toLowerCase()]);
                }
                if (attributesArray.length > 0) {
                    //has variants value true 
                    pgItem.hasVariants = true;
                }
            }

        }
        pgItem.attributes = attributes;

        pgItem.hasBatchNumber = false;
        pgItem.hasExpiryDate = false;

        let bValidItem = true;
        for (let q = i; q < (i + size); q++) {
            if ((q + 1) < (i + size)) {

                if (itemsArray[i].hasOwnProperty("Purchase Unit Name")) {
                    itemsArray[q + 1]["Purchase Unit Name"] = itemsArray[q + 1]["Purchase Unit Name"] ? itemsArray[q + 1]["Purchase Unit Name"] : itemsArray[i]["Purchase Unit Name"];
                    itemsArray[q + 1]["Conversion Factor"] = itemsArray[q + 1]["Conversion Factor"] ? itemsArray[q + 1]["Conversion Factor"] : itemsArray[i]["Conversion Factor"];
                    itemsArray[q + 1]["Selling Unit Name"] = itemsArray[q + 1]["Selling Unit Name"] ? itemsArray[q + 1]["Selling Unit Name"] : itemsArray[i]["Selling Unit Name"];
                } else {
                    itemsArray[q + 1]["Unit Name"] = itemsArray[q + 1]["Unit Name"] ? itemsArray[q + 1]["Unit Name"] : itemsArray[i]["Unit Name"];
                }
            }
            let uIds = [];
            var qty = isNaN(parseInt(itemsArray[q]['Initial Quantity'])) ? 0 : parseInt(itemsArray[q]['Initial Quantity']);

            if (qty) {
                size += qty - 1;
            }
            index = size;
            for (var l = 0; l < qty; l++) {
                var imeiNumbers = itemsArray[q + l]['IMEI NO'] ? itemsArray[q + l]['IMEI NO'].split(',') : [];
                for (var im = 0; im < imeiNumbers.length; im++) {
                    let imeiNumber = imeiNumbers[im].trim();
                    if (imeiNumber.length !== 15) {
                        error = "at line:" + (i + 2) + " IMEI Number length should be equal to 15 " + error;
                        csvDataErrorsArray.push(error);
                        bValidItem = false;
                        break;
                    }
                    imeiNumbers[im] = parseInt(imeiNumber);
                }
                if (!bValidItem) {
                    break;
                }
                let uniqueDetails = {
                    serialnumber: itemsArray[q + l]['SERIAL NO'] ? itemsArray[q + l]['SERIAL NO'] : "",
                    imeiNumbers: imeiNumbers
                }

                uIds.push(uniqueDetails);

            }
            let resp;
            try {
                resp = await itemsValidator.validateBulkUniqueNumbers({
                    uids: CLONE(uIds),
                    bIncludeSold: false
                });
                if (resp !== true) {
                    error = "at line:" + (i + 2) + " UniqueDetails are not Valid : " + resp;
                    csvDataErrorsArray.push(error);
                    bValidItem = false;
                }
            } catch (err) {
                error = "at line:" + (i + 2) + " UniqueDetails are not Valid : " + err;
                csvDataErrorsArray.push(error);
                bValidItem = false;
            }

            itemsArray[q].uniqueDetails = uIds;
            let initObj = await formsInitialStock(itemsArray[q], q);
            if (initObj.expiry) {
                // assign has expiry Date true
                pgItem.hasExpiryDate = true;

            }
            if (initObj.batchId) {
                // assign Has batch Number true
                pgItem.hasBatchNumber = true;

            }
            pgItem.initialStock.push(initObj);

            //check SP,MP,PP price condition 
            if (!importHelperCtrl.priceCondition(itemsArray[q])) {
                let error = " please check SP, PP and MRP values";
                error = "at line:" + (q + 2) + error;
                csvDataErrorsArray.push(error);
            }

            //gst And Slab Condition
            if (!importHelperCtrl.gstAndSlabCondition(itemsArray[q])) {
                let error = " GST or Slab anyone be there, but not both";
                error = "at line:" + (q + 2) + error;
                csvDataErrorsArray.push(error);
            }

            //inclusive Price And Slab Condition Condition
            if (!importHelperCtrl.inclusivePriceAndSlabCondition(itemsArray[q])) {
                let error = " Inclusive Price or Slab anyone be there, but not both";
                error = "at line:" + (q + 2) + error;
                csvDataErrorsArray.push(error);
            }
            if (qty) {
                q += qty - 1;
            }

            if (!bValidItem) {
                break;
            }

        }
        if (!bValidItem) {
            successCount -= 1;
            for (let x = i; x < (i + size); x++) {
                failedItems.push(itemsArray[i]);
            }
            continue;
        }

        pgItem.subCategories = [];
        if (itemsArray[i]['Sub Category']) {
            let subCate = itemsArray[i]['Sub Category'].split('|');
            for (let x = 0; x < subCate.length; x++) {
                let subCategoryObj = {
                    id: subCategoryobj[subCate[x].toLowerCase()],
                    name: subCate[x].toLowerCase()
                };
                pgItem.subCategories.push(subCategoryObj);
            }
        }
        pgItem.bReadQtyFromWeighingMachine = false;
        const weighingMachineHeader = "Read from Weighing Machine";
        if (itemsArray[i][weighingMachineHeader] && itemsArray[i][weighingMachineHeader].trim().toLowerCase() == "yes") {
            pgItem.bReadQtyFromWeighingMachine = true;
        }
        pgItem.bAvailableForPurchaseOrder = true;
        if (itemsArray[i]['AlienHu Market'] && itemsArray[i]['AlienHu Market'].trim().toLowerCase() == "no") {
            pgItem.bAvailableForPurchaseOrder = false;
        }
        pgItem.images = [];
        let imageFileName = itemsArray[i]['Images'];
        let imageObjToPush;
        if (imageFileName && imageFileName.length) {
            let driveInstance;
            try {
                driveInstance = await googleDrive.initDriveInstance(credentialPath, tokenPath);
            } catch (err) {
                const error = "drive instance failed";
                logger.error(error);
                csvDataErrorsArray.push(error);
                continue;
            }
            const thumbnailName = 'thumbnail_' + imageFileName;
            const imagePath = localImageFolder + imageFileName;
            const thumbnailPath = localImageFolder + thumbnailName;
            if (bLocalImageEnabled || bGoogleDriveEnabled) {
                // expecting image file name is already available in specified folder from settings
                // and drive target folder is also created 
                // this can be done using App once when settings are enabled, it will do the preprocess

                if (fs.existsSync(imagePath)) {
                    try {
                        // compress file for thumbnail
                        // copy the thumbnail to localImageFolder
                        let imageOptions = {
                            width: originalImageOption.width,
                            height: originalImageOption.height
                        }
                        await googleDrive.saveCompressedImage(imagePath, imagePath, imageOptions);
                        // image option for thumbnail
                        imageOptions = {
                            width: thumbnailImageOption.width,
                            height: thumbnailImageOption.height
                        }
                        await googleDrive.saveCompressedImage(imagePath, thumbnailPath, imageOptions);
                    } catch (err) {
                        const error = "compression failed, invalid file: " + imagePath;
                        logger.error(error);
                        csvDataErrorsArray.push(error);
                        continue;
                    }
                } else {
                    const error = "no file: " + imagePath;
                    logger.error(error);
                    csvDataErrorsArray.push(error);
                    continue;
                }
                imageObjToPush = {
                    localThumbnail: thumbnailName,
                    localImage: imageFileName,
                    created: true
                }
            }
            if (bGoogleDriveEnabled) {
                if (!dependencyDataAvailable) {
                    // token not there, authentication needed and see credentials.json also
                    const error = "token not there, authentication needed and ensure credentials.json also";
                    logger.error(error);
                    csvDataErrorsArray.push(error);
                    continue;
                }
                try {
                    imageObjToPush.driveThumbnail = await googleDrive.createFile(driveInstance, thumbnailPath, googelDriveFolderId, thumbnailName);
                    // await googleDrive.shareFile(driveInstance, imageObjToPush.driveThumbnail); // now folder is only shared
                    imageObjToPush.driveImage = await googleDrive.createFile(driveInstance, imagePath, googelDriveFolderId, imageFileName);
                    // await googleDrive.shareFile(driveInstance, imageObjToPush.driveImage); // now folder is shared directly
                    imageObjToPush.uploaded = true;
                } catch (err) {
                    const error = "creating or sharing drive file failed: " + imageObjToPush;
                    console.error(error);
                    logger.error(err);
                    csvDataErrorsArray.push(error);
                    continue;
                }
            }
        }
        if (imageFileName && imageFileName.length) {
            pgItem.images.push(imageObjToPush);
        }

        if (itemsArray[i].hasOwnProperty('IMEI COUNT')) {
            if (!itemsArray[i]['IMEI COUNT']) {
                pgItem.imeiCount = 0;
            } else {
                pgItem.imeiCount = parseInt(itemsArray[i]['IMEI COUNT']);

            }
        }
        // pgItem.is_serialized = 
        await fillUnitsData(itemsArray[(i + size - 1)], pgItem);
        pgItem.unitsInfo = formsUnitInfo(itemsArray[i]);

        if (false) {
            let errorsArray = [];
            Utils.findStructDiffAndCopy(refItem, pgItem, [], errorsArray, true);
            logger.error(errorsArray);
            logger.error('Errors Array Length<' + errorsArray.length + '>');
        }
        switch (pgItem.ItemType) {
            case 'Prepared':
                pgItem.isprepared = true;
                pgItem.issellable = true;
                pgItem.isbought = false;
                break;
            case 'Ingrediant':
                pgItem.isprepared = false;
                pgItem.issellable = false;
                pgItem.isbought = true;
                break;
            case 'Liquor':
                pgItem.isprepared = false;
                pgItem.issellable = true;
                pgItem.isbought = true;
                break;
            default:
                pgItem.isprepared = false;
                pgItem.issellable = true;
                pgItem.isbought = true;
                break;
        };

        try {
            let resp = await itemController.createItemHelper(pgItem);
            formattedItemsArray.push(resp[0]);
            formattedInvArray.push(resp[1]);
        } catch (error) {
            console.log(error);
            successCount -= 1;
            for (let x = i; x < (i + size); x++) {
                failedItems.push(itemsArray[i]);
            }
            let errorMsg = error.error ? (error.error.error ? error.error.error : error.error) : error;
            csvDataErrorsArray.push('line #' + (i + 2) + ' ' + errorMsg);
        }
    }

    let endCount = 0;
    while (true) {
        let size = 1000;
        if (formattedItemsArray.length - endCount < 1000) {
            size = formattedItemsArray.length - endCount;
        }
        await couchDBUtils.bulkDocs(formattedItemsArray.slice(endCount, endCount + size), mainDBInstance);
        await couchDBUtils.bulkDocs(formattedInvArray.slice(endCount, endCount + size), mainDBInstance);
        endCount = endCount + 1000;
        if (formattedItemsArray.length <= endCount) {
            break;
        }
    }
}

async function run() {

    //mandatory to initialize the server -> equivalent to node bin/PGServerJs.js
    console.log("calling run method");
    console.log("calling initCouchDb method");
    await couchDbManager.initCouchDb(false);

    console.log("calling prepare method");
    await addSubCategoriesToCAtegory();
    await prepare();
    await getDefaultConfigs();

    console.log("calling getIds method");
    await getIds();

    console.log("calling item Array  method");
    await createItemArray();

    let failCount = itemsArray.length - successCount;
    let resp = [
        csvDataErrorsArray, failCount, failedItems
    ];
    return resp;
}