/*jshint sub:true*/

var moment = require('moment');
var validator = require('validator');
var BPromise = require('bluebird');
var utils = require('./common/Utils');
var logger = require('../common/Logger');
var status = require('../common/StatusCode');
var math = require('mathjs');
var sendSMS = require('../sms/sms');

function receivingsController(requestSession, applicationSettings) {

    var receivingsLib = new require('./libraries/receivingsLib')(requestSession, applicationSettings);
    const receivingsLib2 = new require('./libraries/receivingsLib2');
    var commonLib = new require('./libraries/commonLib');
    var creditPaymentsLib = require('./libraries/creditPaymentsLib');
    var receivingsValidator = require('./validatiors/Receivings');
    receivingsLib.applicationSettings = applicationSettings; // still required ??
    receivingsLib2.setAppSettings(applicationSettings);
    var couchDBUtils = require('./common/CouchDBUtils');
    const taxLib = require('../TSControllers/libraries/taxDetailsCommon');
    const getTaxesByPercentageDetailed = taxLib.getTaxesByPercentageDetailed;
    var mainDBInstance = couchDBUtils.getMainCouchDB();
    let foo = {};
    var _self = foo;

    /**
     *      addSupplier2RecRestApi
     */
    foo.addSupplier = async function (requestData) {
        var supplier_id = requestData.supplier_id;
        var response = {
            succs_supplier_id: null
        };
        if (supplier_id == null) { // supplier removed
            try {
                await receivingsLib.removeSupplier();
                response.succs_supplier_id = await receivingsLib.get_supplier();
                return response;
            } catch (err) {
                logger.error(err);
                response.succs_supplier_id = await receivingsLib.get_supplier();
                return response;
            }
        }
        return receivingsLib.set_supplier(supplier_id).then(function (resp) {
            response.succs_supplier_id = receivingsLib.get_supplier();

            return response;
        }).catch(function (err) {
            logger.error(err);
            response.succs_supplier_id = receivingsLib.get_supplier();
            return response;
        });
    };

    foo.additemById = async function (item) {
        let itemDoc = {};
        let response = {};
        try {
            itemDoc = await couchDBUtils.getDoc('item_' + item.item_id, mainDBInstance);

            if (itemDoc.info.hasVariants) {
                response.err = 'Item has Variants, Please add it manually to the cart';
                return response;
            } else if (itemDoc.info.imeiCount) {
                response.err = 'Item has multiple IMEI count, Please add it manually to the cart';
                return response;
            } else if (itemDoc.info.ItemType == 'Prepared') {
                response.err = 'Item is type Prepared,it will not add to cart';
                return response;
            }
        } catch (res) {
            logger.error(res);
            response.err = 'Server Error';
            return response;
        }

        let uniqueDetails = [];


        let itemObj = {
            discount: 0,
            discountBy: applicationSettings.salesConfig.defaultDiscountByMethod,
            item: itemDoc.item_id,
            quantity: 0, // test this
            uniqueDetails: uniqueDetails,
            unitId: itemDoc.info.defaultPurchaseUnitId
        };

        return _self.additem(itemObj);
    };

    /**
     *      additem2ReceivingsRestApi
     *      Todo:
     *          validate itemkit usecase
     */
    foo.additem = async function (requestData, bRemoveItem) {
        var response = {};

        try {
            var reverseQuantitySign = 1;
            if (!utils.isUndefinedOrNull(bRemoveItem)) {
                reverseQuantitySign = -1;
            }
            var UIDLength = requestData.uniqueDetails ? requestData.uniqueDetails.length : 1;
            requestData.quantity = requestData.quantity ? requestData.quantity : UIDLength;
            var idx2Remove = requestData.line ? requestData.line : '';
            var uniqueDetails = requestData.uniqueDetails;
            var itemLocation = receivingsLib.get_stock_source();
            if (!requestData.quantity) {
                requestData.quantity = 1;
            }
            requestData.quantity *= reverseQuantitySign;

            requestData.item_id = requestData.item;
            let resp = await receivingsLib.addItem2Cart(requestData);
            //have logic inside the lib iteself
            var params = {
                uniqueDetails: uniqueDetails
            };
            if (reverseQuantitySign !== -1) {
                params.line = resp.line;

                receivingsLib._updateUniqueDetailsBulk(params);
            } else {

                params.line = idx2Remove;
                receivingsLib._updateUniqueDetailsBulk4RemovedItem(params);
            }

        } catch (err) {
            logger.error(err);
            response.error = err;
        }

        return prepareAndDispatchResponse(response);

    };

    foo.updateUnit = async function (requestData) {
        receivingsLib.updateUnit(requestData);
        return prepareAndDispatchResponse();
    };

    /**
     *      editRecvItemRestApi
     *      Todo: price edit should be disabled
     */
    foo.editItem = function (requestData) {
        var response = {};
        return Promise.resolve().then(function () {
            let validationResp = receivingsValidator.editItem(requestData);
            if (!validationResp.bIsValid) {
                response.error = validationResp.errMsg;
                return response;
            } else {
                var discountMethod = requestData.discountBy;
                var line = requestData.line;
                var description = requestData.description;
                var price = requestData.purchasePrice;
                var sellingPrice = requestData.sellingPrice;
                var mrp = requestData.mrp;
                var quantity = requestData.quantity;
                var expiry = requestData.expiry;
                var itemLocation = requestData.item_location;
                //Editing attributeinfo is not supported
                return receivingsLib.edit_item(line, quantity, expiry, requestData.unitsInfo, requestData.batchId, requestData.bPPTempTaxInclusive, requestData.discount, discountMethod);
            }
        }).then(function (resp) {
            if (resp && resp.error) {
                response.error = resp.error;
            }
            if (resp && resp.warning) {
                response.warning = resp.warning;
            }

            return prepareAndDispatchResponse(response);
        }).catch(function (err) {
            response.error = err;
            logger.error(response);
            return prepareAndDispatchResponse(response);
        });
    };

    foo.setGlobalDiscount = async function (discountParam) {
        var resp = {};
        if (!discountParam) {
            resp.errMsg = "Param undefined";
            logger.error(resp);
            throw resp;
        }
        try {
            resp = await receivingsLib.setGlobalDiscount(discountParam);
            resp.msg = "Global discount success";
            return prepareAndDispatchResponse(resp);
        } catch (err) {
            resp.msg = "Failed to apply discount";
            logger.error(err);
            throw resp;
        }

    }
    /**
     *      removeItemfromReceivingsRestApi
     *      item and line both are expected and uniquedetails are those which has to be removed
     */
    foo.removeItem = function (requestData) {
        return _self.additem(requestData, 1);
    };

    /**
     *      DeleteItemFromCartRestApi
     *      Todo 
     *          requestData.item is actually line number. Please validate
     */
    foo.delteItemFromCart = function (requestData) {
        var response = {};
        response.status = receivingsLib.deleteItemByLine(requestData.item);
        return prepareAndDispatchResponse(response);
    };

    function ROUNDOFFNUMBER(number) {
        var result = +utils.roundOffNumber(number, applicationSettings);
        return result;
    }
    /**
     *      Todo
     *          stock_locations
     */
    function prepareAndDispatchResponse(response) {
        receivingsLib.compute();
        response = response || {};
        response.cart = receivingsLib.get_cart();
        response.bReadyForCheckout = receivingsLib.isCartReadyForCheckout();
        response.totalNoTaxNoDiscount = receivingsLib.gettotalNoTaxNoDiscount();
        response.taxes = receivingsLib.getTaxes();
        response.modes = {
            receive: 'Receive',
            return: 'Return'
        };
        response.mode = receivingsLib.get_mode();
        response.payments = commonLib.get_payments(requestSession);
        response.purchaseOnCreditAmt = receivingsLib.getPurchaseOnCreditAmt();

        response.total = receivingsLib.getTotal();
        response.discount = receivingsLib.getGlobalDiscount();
        response.total = ROUNDOFFNUMBER(response.total); //.toFixed(2);
        var amountDue = +commonLib.get_amount_due(requestSession, response.total);

        response.amountDue = amountDue;

        //Todo
        //$data.items_module_allowed=$foo->Employee->has_grant('items',$person_info->person_id);
        response.items_module_allowed = [];

        response.comment = receivingsLib.get_comment();
        //TODO might have to create new table with payment options and its names

        response.payment_options = {};
        for (let i = 0; i < applicationSettings.paymentTerms.value.length; i++) {
            response.payment_options[applicationSettings.paymentTerms.value[i]] = applicationSettings.paymentTerms.value[i];
        }
        response.payment_options['Purchase On Credit'] = 'Purchase On Credit';

        var supp_info = receivingsLib.getCartSupplierDetails();
        if (supp_info.person_id !== null) {
            response.supplier_id = supp_info.person_id;
            response.supplier = supp_info.company_name;
            response.supplier_email = supp_info.email;
            response.supplier_phone = supp_info.phone_number;
            response.supplier_isCreditAllowed = supp_info.allow_credit;
            response.supplier_credit_limit = supp_info.credit_limit;
        }

        //TODO invoice generation
        // response.invoice_number = foo._substitute_invoice_number(cust_info);
        response.invoice_number_enabled = receivingsLib.is_invoice_number_enabled();
        // response.print_after_sale = receivingsLib.is_print_after_sale();
        response.payments_cover_total = doesPaymentsCoverTotal(response.total);

        receivingsLib.getTempDetails(response);
        response.totalNoTaxWithDiscount = parseFloat(receivingsLib.gettotalNoTaxWithDiscount());
        response.totalNoGlobalDiscount = parseFloat(receivingsLib.gettotalNoGlobalDiscount());
        response.bLocalTax = receivingsLib.getLocalTax();
        return Promise.resolve(response);
    }

    function doesPaymentsCoverTotal(purchaseTotal) {

        var total_payments = 0;
        var payments = commonLib.get_payments(requestSession);
        for (var index in payments) {
            var payment = payments[index];
            total_payments += payment.payment_amount;
        }
        if (receivingsLib.get_mode() == 'receive' && (purchaseTotal - total_payments) > 1.0E-6) {
            return false;
        }
        return true;
    }

    /**
     * addPayments
     */

    foo.add_paymentRestApi = function (requestData) {

        var response = {};
        var payment_type;
        var payments;
        var payment_amount;
        var ref_no;

        return Promise.resolve().then(function () {
            payment_type = requestData.payment_type;
            ref_no = requestData.ref_no;
            //TODO need to verify the credibility of this algo

            return Promise.resolve(requestData.amount_tendered);

        }).then(function (thePaymentAmount) {
            if (!commonLib.add_payment(payment_type, thePaymentAmount, requestSession, ref_no)) {
                response.error = 'Unable to Add Payment! Please try again!';
            }
            return prepareAndDispatchResponse(response);
        });

    };

    /**
     * delete payments
     */

    foo.deletePayment = function (requestData) {
        commonLib.delete_payment(requestData.payment_id, requestSession);
        return Promise.resolve(prepareAndDispatchResponse());
    };

    /**
     *      cancelReceivingsRestApi
     */
    foo.cancelReceivings = function () {
        receivingsLib.clear_all();
        return prepareAndDispatchResponse();
    };

    foo.setLocalTax = async function (requestData) {
        receivingsLib.setLocalTax(requestData.params.bLocalTax);
        return prepareAndDispatchResponse();
    };

    function addChangeDue(response, amount_change) {
        bCashPaymentExists = false;
        cashPIndex = -1;
        amount_change = amount_change ? amount_change : 0;
        for (var p = 0; p < response.payments.length; p++) {
            if (response.payments[p].payment_type === 'Cash') {
                bCashPaymentExists = true;
                cashPIndex = p;
            }
        }
        if (bCashPaymentExists) {
            response.payments[cashPIndex].returnAmt = amount_change;
        } else {
            if (response.payments.length > 1) {
                if (response.payments[0].payment_type !== 'Purchase On Credit') {
                    response.payments[0].returnAmt = amount_change;

                } else {
                    response.payments[1].returnAmt = amount_change;

                }
            } else if (response.payments.length === 1) {
                if (response.payments[0].payment_type !== 'Purchase On Credit') {
                    response.payments[0].returnAmt = amount_change;

                } else {
                    response.payments[0].payment_amount -= amount_change;
                    response.pending_amount -= amount_change;
                }
            }
        }
    }

    foo.completeReturn = function (requestData) {
        if (!requestData.employee_id) {
            requestData.employee_id = requestSession.user.name;
        }
        requestData.taxDetailed = {};
        requestData.taxNames = {};
        requestData.hsnTaxes = {};
        // get taxDetailed and taxNames
        getTaxesByPercentageDetailed(requestData.items, requestData.taxDetailed, requestData.taxNames, requestData.hsnTaxes);
        let paymentsTotal = commonLib.getPaymentsTotal(requestData.payments);
        let changeDue = paymentsTotal - requestData.total;
        addChangeDue(requestData, changeDue);
        return receivingsLib2.commitReturn(requestData);
    };

    /**
     *      completeReceiveRestApi
     *      Todo: There is a problem with amount change and customer details
     *      Todo: session should have id of user also along with name
     */
    foo.completeReceivings = function (requestData) {

        var editPurchaseId = requestData.purchaseIdToEdit ? requestData.purchaseIdToEdit : null;
        receivingsLib.set_comment(requestData.comment);
        receivingsLib.set_invoice_number(requestData.invoice_number);
        var response = {};
        response.discount = receivingsLib.getGlobalDiscount();
        response.interState = !requestData.bLocalTax;
        receivingsLib.compute();
        response.cart = receivingsLib.get_cart();
        response.total = receivingsLib.getTotal();
        response.addedRoundOffValue = ROUNDOFFNUMBER(response.total) - response.total;
        response.totalNoTaxNoDiscount = receivingsLib.gettotalNoTaxNoDiscount();
        response.totalNoTaxNoDiscount = parseFloat(response.totalNoTaxNoDiscount);
        response.taxes = receivingsLib.getTaxes();
        response.receipt_title = 'Purchase Receipt';
        response.totalQuantity = receivingsLib.computeQuantity(response.cart)

        response.mode = receivingsLib.get_mode();
        response.comment = requestData.comment || receivingsLib.get_comment();
        response.invoiceNumber = requestData.invoice_number || receivingsLib.get_invoiceNumber();
        response.stock_location = receivingsLib.get_stock_source();

        response.payments = commonLib.get_payments(requestSession);

        response.total = ROUNDOFFNUMBER(response.total);
        var amountDue = commonLib.get_amount_due(requestSession, response.total);
        response.amountDue = amountDue;
        let paymentsTotal = commonLib.getPaymentsTotal(response.payments);
        response.amount_change = paymentsTotal - response.total;
        response.employee = requestSession.user.first_name + ' ' + requestSession.user.last_name;
        var amountTendered = requestData.amount_tendered;
        if (!utils.isUndefinedOrNull(amountTendered)) {
            response.amount_tendered = amountTendered;
            response.amount_change = +math.subtract(amountTendered, response.total);
        }

        var supplierInfo = receivingsLib.getCartSupplierDetails();
        if (supplierInfo.person_id !== null) {
            response.supplier = supplierInfo.company_name;
            response.supplierGSTIN = supplierInfo.gstin_number;
            response.supplier_phone = supplierInfo.phone_number;
            response.supplierPAN = supplierInfo.pan_number
        }
        response.supplier_id = supplierInfo.person_id;

        let timeStamp = requestData.timeStamp;
        if (timeStamp) {
            var curTime = new Date();
            timeStamp = new Date(timeStamp);
            timeStamp.setSeconds(curTime.getSeconds());
            timeStamp = timeStamp.toISOString();
        }
        response.quantity = commonLib.get_quantity(response.cart);

        //Todo: invoicenumber
        response.payment_type = requestData.payment_type;

        response.purchaseOnCreditAmt = receivingsLib.getPurchaseOnCreditAmt();
        response.subtotal = receivingsLib.gettotalNoTaxWithDiscount();
        response.taxDetailed = {};
        response.taxNames = {};
        response.hsnTaxes = {};
        response.taxes.Total = commonLib.getTaxAmt(response.taxes);
        // get taxDetailed and taxNames
        addChangeDue(response, response.amount_change);
        getTaxesByPercentageDetailed(response.cart, response.taxDetailed, response.taxNames, response.hsnTaxes);
        return receivingsLib.save(response.cart, editPurchaseId, supplierInfo.person_id, requestSession.user.name, response.comment, response.invoiceNumber, response.payments, response.payment_type, response.total, response.purchaseOnCreditAmt, response.stock_location, timeStamp, requestData.checkNo, applicationSettings.numberFormat.roundOffMethod, response.amount_tendered, response.supplierGSTIN, supplierInfo.state_name, response.discount, response.interState, response.subtotal, response.taxes, response.quantity, response.taxDetailed).then(function (receivingsResp) {

            response.receiving_id = 'RECV ' + receivingsResp.receivingId;
            response.transaction_time = moment(receivingsResp.timeStamp).format(applicationSettings.dateTime.dateformat +
                ' ' + applicationSettings.dateTime.timeformat);
            response.print_after_sale = requestData.print_after_sale; //receivingsLib.is_print_after_sale();
            response.totalNoTaxWithDiscount = receivingsLib.gettotalNoTaxWithDiscount();
            response.totalNoGlobalDiscount = receivingsLib.gettotalNoGlobalDiscount();
            receivingsLib.clear_all();
            //Todo: response.barcode = 0;

            if (receivingsResp.receivingId === -1) {
                response.error_message = 'Receivings Transactions Failed';
                return Promise.reject(response);
            }
            if (applicationSettings.enableSMS.value && applicationSettings.enableSMS.afterPurchase) {
                var jsonParam = {
                    amount: ROUNDOFFNUMBER(response.total),
                    saleId: response.sale_id,
                    company: response.company_name,
                    date: response.transaction_time,
                    customer: response.customer != undefined ? response.customer.substr(0, response.customer.indexOf(' ')) : 'Consumer'
                };
                var params = {
                    To: '',
                    Type: 'TRANS',
                    Msg: utils.getSMSMessage(applicationSettings.enableSMS.saleSMS, jsonParam)
                };

                if (applicationSettings.ownersInfo.phone != '' && applicationSettings.enableSMS.toOwner) {
                    params.To = applicationSettings.ownersInfo.phone;
                }

                if (response.supplier_phone && applicationSettings.enableSMS.toCustomer) {
                    if (params.To == '') params.To = response.supplier_phone;
                    else params.To += ',' + response.supplier_phone;
                }
                if (params.To == '') {
                    console.log('no number given');
                } else {
                    var smsResp = "";
                    try {
                        smsResp = sendSMS(params);
                        logger.info(smsResp);

                    } catch (err) {
                        logger.error(err);
                    }
                }
            } else {
                logger.silly('SMS functionality not enabled for ' + applicationSettings.ownersInfo.company);
            }

            if (!requestData.item_id && requestData.print_after_sale) {
                //Petrol Bunk
                response.print_after_sale = requestData.print_after_sale;
                if (requestSession.clientType === 'MobileApp') {
                    utils.sendSocketEvent('printPurchaseReceipt', response);
                }
            }
            delete response.taxes.Total;
            return response;

        }).catch(function (err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    /**
     *      getReceivingsRestApi
     */
    foo.getReceivings = function () {
        return prepareAndDispatchResponse();
    };

    /**
     *      set_invoice_number_enabledRestApi
     */
    foo.setInvoiceNumberEnabled = function (requestData) {
        receivingsLib.set_invoice_number_enabled(requestData.sales_invoice_number_enabled);
        return Promise.resolve({
            status: status.SUCCESS
        });
    };

    /**
     *      changeModeRestApi
     *      Todo: handle different sales locations
     */
    foo.changeMode = function (requestData) {
        receivingsLib.set_mode(requestData.mode);
        return prepareAndDispatchResponse();
    };

    /**
     *      Todo
     *      saveRecvEditRestApi
     */
    foo.saveRecvEdit = function (requestData) {

    };

    /**
     * delete purchase by id
     */

    foo.deletePurchaseById = async function (docId) {
        let respArry = [];
        for (let i = 0; i < docId.length; i++) {
            respArry.push(await commonLib.reverseTransaction(docId[i], undefined, undefined, applicationSettings.bUpdateStockOnPurchaseDelete));
        }
        return respArry;
    }

    foo.rejectPurchase = function (params) {
        return commonLib.reverseTransaction(params.id, params.breject, params.reason, applicationSettings.bUpdateStockOnPurchaseDelete);
    }
    /**
     *      Todo
     *      deleteRecvRestApi
     */
    foo.deleteRecv = function (requestData) {

    };

    /**
     *      Todo
     *      setInvoiceNumber4RecevingsRestApi
     */
    foo.setInvoiceNumber = function (requestData) {

    };

    /**
     *      Todo    
     *      getEditRestApi
     */
    foo.getEdit = function (requestData) {

    };

    //CommitTodo use async
    foo.makeCreditPaymentForSupplier = function (requestData) {
        requestData.employeeId = requestSession.user.name;
        return creditPaymentsLib.makeCreditPaymentForSupplier(requestData).then(function (response) {
            if (requestData.print_after_sale) {
                response.print_after_sale = requestData.print_after_sale;
                if (requestSession.clientType === 'MobileApp') {
                    utils.sendSocketEvent('printCreditReceipt', response);
                }
            }
            return response;
        }).catch(function (error) {
            logger.error(error);
            return Promise.reject(error);
        });
    };

    foo.resetPurchaseInfo = async function (type) {

        try {
            await commonLib.cleanTxnsByType(type);
            return;
        } catch (error) {
            logger.error(error);
            throw 'Reset Purchase Failed';
        }
    }

    foo.rePrint = function (requestData) {
        var response = {
            data: {},
            message: ''
        };
        return receivingsLib.getJsonForReprint(requestData, applicationSettings).then(function (resp) {
            response = resp;
            return response;
        }).catch(function (err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.initEditPurchaseSession = async function (requestData) {
        try {
            let purchaseDoc = await commonLib.getTansDocument(requestData.receivingId);
            if (purchaseDoc.status.status) {
                throw {
                    'message': 'Not ready for Edit'
                };
            }

            await _self.cancelReceivings();

            let temParamFields = ['wcInfo', 'receiving_time', 'shippingDetails', 'checkNo', 'comment', 'state_name', 'invoice_number', 'print_after_sale'];
            let tempParams = {};
            for (let i = 0; i < temParamFields.length; i++) {
                tempParams[temParamFields[i]] = purchaseDoc.receivings_info[temParamFields[i]];
            }

            receivingsLib.setTempDetails(tempParams);
            if (purchaseDoc.receivings_info.discount && Object.keys(purchaseDoc.receivings_info.discount).length) {
                await receivingsLib.setGlobalDiscount(purchaseDoc.receivings_info.discount);
            } else {
                await receivingsLib.setGlobalDiscount(receivingsLib.getZeroGlobalDiscount());
            }
            var promisesArray = [];
            for (var i = 0; i < purchaseDoc.receiving_items.length; i++) {
                let taxList = commonLib.convertToGSTTaxes(purchaseDoc.receiving_items[i].itemTaxList);
                var params = {
                    item: purchaseDoc.receiving_items[i].item_id,
                    batchId: purchaseDoc.receiving_items[i].batchId,
                    uniqueDetails: purchaseDoc.receiving_items[i].uniqueDetails,
                    unitsInfo: purchaseDoc.receiving_items[i].unitsInfo,
                    baseUnitId: purchaseDoc.receiving_items[i].baseUnitId,
                    unitId: purchaseDoc.receiving_items[i].unitId,
                    quantity: purchaseDoc.receiving_items[i].quantity_purchased,
                    pItemTaxList: taxList,
                    pBPPTaxInclusive: purchaseDoc.receiving_items[i].bPPTaxInclusive,
                    slab: purchaseDoc.receiving_items[i].slab,
                    discount: purchaseDoc.receiving_items[i].discount
                }
                if (purchaseDoc.receiving_items[i].hasVariants) {
                    params.skuName = purchaseDoc.receiving_items[i].skuName;
                    params.attributeInfo = {};
                    let stockKey = purchaseDoc.receiving_items[i].stockKey;
                    let stockKeySplit = stockKey.split('_');
                    for (let i = 4; i < stockKeySplit.length; i = i + 2) {
                        params.attributeInfo[stockKeySplit[i]] = stockKeySplit[i + 1];
                    }
                }
                if (purchaseDoc.receiving_items[i].hasExpiryDate) {
                    params.expiry = purchaseDoc.receiving_items[i].expiry;
                }
                await _self.additem(params);
            }
            if (purchaseDoc.receivings_info.supplier_id) {
                await _self.addSupplier({
                    'supplier_id': purchaseDoc.receivings_info.supplier_id
                });
            }

            let resp = await commonLib.addPaymentsForEdit(purchaseDoc.payments, _self.add_paymentRestApi);

            resp.receiving_time = moment(purchaseDoc.receivings_info.receiving_time).local().format();
            // resp.discount = receivingsLib.getGlobalDiscount();
            return resp;
        } catch (error) {
            await _self.cancelReceivings();
            throw error;
        }

    }

    return foo;

}

module.exports = function (requestSession, applicationSettings) {
    return receivingsController(requestSession, applicationSettings);
};