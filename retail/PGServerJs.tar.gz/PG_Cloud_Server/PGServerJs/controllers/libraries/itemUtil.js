let itemUtil = function() {

    let _self = this;
    const logger = require('../../common/Logger');
    const utils = require('../common/Utils');
    const CLONE = utils.clone;

    this.enSalesTax = 1;
    this.enPurchaseTax = 2;

    this.formatItemDocId = function(id) {
        return 'item_' + id;
    };

    function formatTax(doc) {
        return {
            taxId: doc.id,
            taxInfo: doc
        };
    }

    this.getThisItemInfo = async function(itemQueryParams, couchDBUtils, mainDBInstance) {
        let item_id = itemQueryParams.item_id;
        let stockKey = itemQueryParams.stockKey; //RelaxClientTodo batchId -> stockKey
        let taxType = itemQueryParams.taxType ? itemQueryParams.taxType : 0;

        if (!item_id) {
            logger.error('Item ID is compulsory');
            throw 'Internal Error';
        }

        try {
            let item = await couchDBUtils.getDoc(_self.formatItemDocId(item_id), mainDBInstance, "Item Not Found");
            /**
             * Get the below information
             * 1. sales and purchase tax
             * 2. discount
             * 3. units              
             */
            let requiredDocs = [];
            if (!taxType || taxType === _self.enSalesTax) {
                for (let i = 0; i < item.info.salesTaxes.length; i++) {
                    requiredDocs.push('tax_' + item.info.salesTaxes[i]);
                }
                if (item.info.salesSlab) {
                    requiredDocs.push('slab_' + item.info.salesSlab);
                }
            }
            if (!taxType || taxType === _self.enPurchaseTax) {
                for (let i = 0; i < item.info.purchaseTaxes.length; i++) {
                    requiredDocs.push('tax_' + item.info.purchaseTaxes[i]);
                }
                if (item.info.purchaseSlab) {
                    requiredDocs.push('slab_' + item.info.purchaseSlab);
                }
            }

            let unitsArray = [];
            if (!stockKey) {
                unitsArray = Object.keys(item.info.unitsInfo);
            }
            let discountIdArray = [];
            let locationId;
            if (stockKey) {
                unitsArray = Object.keys(item.batches[stockKey].unitsInfo);
                for (let i = 0; i < unitsArray.length; i++) {
                    let pProfilesData = item.batches[stockKey].unitsInfo[unitsArray[i]].pProfilesData;
                    for (let key in pProfilesData) {
                        if (pProfilesData[key].discountId) {
                            discountIdArray.push(pProfilesData[key].discountId);
                            requiredDocs.push('discount_' + pProfilesData[key].discountId);
                        }
                    }
                }

                locationId = item.batches[stockKey].locationId;
                if (locationId) {
                    requiredDocs.push('location_' + locationId);
                }
            }

            for (let i = 0; i < unitsArray.length; i++) {
                requiredDocs.push('unit_' + unitsArray[i]);
            }

            // requiredDocs = Array.from(new Set(requiredDocs)); //RelaxTodo repeated docs can be avoided using this. Make the datastructure proper

            let queryResponse = await couchDBUtils.getAllDocs(requiredDocs, mainDBInstance);
            for (let i = 0; i < queryResponse.length; i++) {
                if (queryResponse[i].error) {
                    logger.error(queryResponse[i]);
                    throw "Internal Error";
                }
            }

            //search errors in each of the row
            //format to the previous version
            //RelaxThink _id, _rev will be extra in all the queries
            let queryCount = 0;
            let response = CLONE(item.info);
            response.item_id = item.item_id;
            if (stockKey) {
                response.batches = [CLONE(item.batches[stockKey])];
            } else {
                response.batches = Object.values(item.batches);
            }

            if (!taxType) {
                response.salesTaxes = [];
                for (let i = 0; i < item.info.salesTaxes.length; i++) {
                    response.salesTaxes.push(formatTax(queryResponse[queryCount++].doc));
                }
                if (item.info.salesSlab) {
                    response.salesSlab = queryResponse[queryCount++].doc;
                }

                response.purchaseTaxes = [];
                for (let i = 0; i < item.info.purchaseTaxes.length; i++) {
                    response.purchaseTaxes.push(formatTax(queryResponse[queryCount++].doc));
                }
                if (item.info.purchaseSlab) {
                    response.purchaseSlab = queryResponse[queryCount++].doc;
                }
            } else {
                response.taxes = [];
                let taxes = taxType === _self.enSalesTax ? item.info.salesTaxes : item.info.purchaseTaxes;
                for (let i = 0; i < taxes.length; i++) {
                    response.taxes.push(formatTax(queryResponse[queryCount++].doc));
                }
                if (queryResponse[queryCount].doc._id.indexOf('slab_') === 0) {
                    response.slab = queryResponse[queryCount++].doc;
                }
            }

            if (discountIdArray.length) {
                for (let i = 0; i < unitsArray.length; i++) {
                    let pProfilesData = response.batches[0].unitsInfo[unitsArray[i]].pProfilesData;
                    for (let key in pProfilesData) {
                        if (pProfilesData[key].discountId) {
                            pProfilesData[key].discount = queryResponse[queryCount++].doc;
                        }
                    }
                }
            }

            if (locationId) {
                response.batches[0].stockLocation = queryResponse[queryCount++].doc;
            }

            response.unitDocs = {};
            for (let i = 0; i < unitsArray.length; i++) {
                response.unitDocs[unitsArray[i]] = queryResponse[queryCount++].doc;
            }

            return response;
        } catch (error) {
            throw error;
        }

    };
};

module.exports = new itemUtil();