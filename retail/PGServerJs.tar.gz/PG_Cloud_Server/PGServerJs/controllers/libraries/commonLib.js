const math = require('mathjs');
const moment = require('moment');
const logger = require('../../common/Logger');
const couchDBUtils = require('../common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const coreDBInstance = couchDBUtils.getCoreCouchDB();
const usersdb = couchDBUtils.getUserCouchDB();
const utils = require('../common/Utils');
var computeUtils = require('../common/computeUtils');
const ARRAY_LENGTH = utils.getArrayLength;
const IS_EMPTY_OBJECT = utils.isEmptyObject;

let commonLib = function() {

    let _self = this;

    this.formatSaleId = function(id) {
        return 'sale_' + id;
    };

    this.formatSaleCreditId = function(id) {
        return 'saleCredit_' + id;
    };

    this.formatReceivingCreditId = function(id) {
        return 'receivingCredit_' + id;
    };

    this.formatRoomSaleId = function(id) {
        return 'roomSale_' + id;
    };

    this.formatReceivingId = function(id) {
        return 'receiving_' + id;
    };

    this.formatSaleReturnId = function(id) {
        return 'saleReturn_' + id;
    };

    this.formatReceivingReturnId = function(id) {
        return 'receivingReturn_' + id;
    };

    this.getParamsForGettingInvTrans = function(cartItem, timeStamp, employeeId, comment, bSale, bReturn) {
        let params = {
            item_id: cartItem.item_id,
            batchId: cartItem.batchId,
            stockKey: cartItem.stockKey,
            newQuantity: cartItem.quantity,
            comment: comment,
            employeeId: employeeId,
            locationId: cartItem.item_location,
            timeStamp: timeStamp,
            skuName: cartItem.skuName,
            uUnit: cartItem.unitId
        };

        params.newQuantity *= _self.getFactor(cartItem.unitsInfo, cartItem.unitId, cartItem.baseUnitId);
        if (bSale) {
            params.newQuantity *= -1;
        }
        if (bReturn) {
            params.newQuantity *= -1;
        }

        params.uniqueDetails = cartItem.uniqueDetails;

        return params;
    };

    this.add_payment = function(paymentType, paymentAmount, session, ref_no) {
        let payments = this.get_payments(session);
        let thisPayment = payments.filter(function(payment) {
            return payment.payment_type === paymentType;
        });

        if (thisPayment.length > 0) {
            //payment_method already exists, add to payment_amount            
            thisPayment = thisPayment[0];
            thisPayment.payment_amount = +math.add(thisPayment.payment_amount, paymentAmount).toFixed(2);
        } else {
            //add to existing array
            let payment = {
                'payment_type': paymentType,
                'payment_amount': +paymentAmount.toFixed(2),
                'ref_no': ref_no
            };

            payments.push(payment);
        }
        // this.set_payments(payments);
        return true;
    };

    this.get_payments = function(session) {
        if (!session.recvPayments) {
            session.recvPayments = [];
        }
        return session.recvPayments;
    };

    this.get_payments_total = function(session) {

        let subtotal = 0;
        let payments = this.get_payments(session);
        for (let index in payments) {
            let payment = payments[index];
            subtotal = math.add(payment.payment_amount, subtotal);
        }
        //TODO
        //return to_currency_no_money(subtotal);

        return subtotal;
    };

    this.get_amount_due = function(session, total) {

        let amount_due = 0;
        let payment_total = this.get_payments_total(session);
        amount_due = math.subtract(total, payment_total);
        return amount_due;

    };

    this.set_payments = function(payments_data, session) {
        session.recvPayments = payments_data;
    };

    this.delete_payment = function(paymentType, session) {
        let payments = this.get_payments(session);

        payments = payments.filter(function(aPayment) {
            return aPayment.payment_type !== paymentType;
        });

        this.set_payments(payments, session);
    };

    function getReturnPrefix(bPurchase) {
        let prefix = 'suspendSaleReturn';
        if (bPurchase) {
            prefix = 'suspendReceivingReturn';
        }

        return prefix;
    }
    this.getApplicationSettings = async function() {
        return await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstance);

    }
    this.getCurrentCheckpoint = function(applicationSettings) {
        let invoiceCheckpoint = applicationSettings.invoiceCurrentCheckpoint;
        if (invoiceCheckpoint == applicationSettings.invoiceDefaultCheckpoint.value || !applicationSettings.invoiceCheckpointValue.length)
            return applicationSettings.invoiceDefaultCheckpoint;

        for (var i = 0; i < applicationSettings.invoiceCheckpointValue.length; i++) {
            if (invoiceCheckpoint == applicationSettings.invoiceCheckpointValue[i].value)
                return applicationSettings.invoiceCheckpointValue[i];
        }

    }

    this.suspendReturn = async function(data, bPurchase) {
        data._id = getReturnPrefix(bPurchase) + '_' + moment().format('x');
        try {
            await couchDBUtils.create(data, mainDBInstance, 2, 'Suspend Return Failed. Try Again');
            return {
                message: 'Suspend Return Success'
            }
        } catch (error) {
            logger.error(error);
            throw {
                error: error
            };
        }
    };

    this.unsuspendReturn = async function(data) {
        try {
            let errMsg = 'Unsuspend Return Failed. Try Again';
            let resp = await couchDBUtils.getDoc(data._id, mainDBInstance, errMsg);
            await couchDBUtils.delete(data, mainDBInstance, 2, errMsg);
            return {
                message: 'Unsuspend Return Success',
                data: resp
            }
        } catch (error) {
            logger.error(error);
            throw {
                error: error
            };
        }
    };

    this.getUnitName = function(unitDocs, unitId) {
        let name = unitDocs[unitId].shortName;
        if (!name) {
            name = unitDocs[unitId].name;
        }

        return name;
    };

    this.getPPFromUInfo = function(unitsInfo, unitId) {
        return unitsInfo[unitId].purchasePrice;
    };

    this.getFactor = function(unitsInfo, srcUnitId, baseUnitId) {
        let factor = 1;
        let count = 0;

        while (true) {
            if (count > 100) {
                factor = 1;
                break;
            }

            factor *= unitsInfo[srcUnitId].factor;
            if (srcUnitId.toString() === baseUnitId.toString()) {
                break;
            }
            if (srcUnitId.toString() === unitsInfo[srcUnitId].refUnitId.toString()) {
                factor = 1;
                break;
            }
            srcUnitId = unitsInfo[srcUnitId].refUnitId;
            count++;
        }

        return factor;
    };

    //used in UT also
    /**
     * unitsInfo is used only to get factor
     * price is sellingPrice/purchasePrice
     */
    this.getBaseUnitPrice = function(price, unitId, baseUnitId, unitsInfo) {

        return (price / _self.getFactor(unitsInfo, unitId, baseUnitId));
    }

    this.getAllSuspendedReturns = async function(bPurchase) {
        try {
            return {
                message: 'All Suspended Returns Success',
                data: await couchDBUtils.getAllDocsByType(getReturnPrefix(bPurchase), mainDBInstance, undefined, true)
            };
        } catch (error) {
            throw {
                error: 'Unable to fetch suspended returns'
            };
        }
    };

    /**
     * return
     */
    function getReverseStatusJson(doc, bReject, reason) {
        const itemLib = require('./itemsControllerLib');
        let status = {
            status: 4,
            reverseInvTrans: {}
        };

        if (bReject) {
            status.bReject = true;
            status.reason = reason;
        } else {
            status.bReverse = true;
        }

        let formatDocFun;
        let elementPrefix = 'customer';
        let reverseSign = -1;
        let itemsKey = 'items';
        let infoKey = 'info';
        let timeStampKey = 'time';
        let itemAvailable;
        let sold;
        if (doc._id.indexOf('sale_') === 0) {
            itemsKey = 'sale_items';
            infoKey = 'sales_info';
            timeStampKey = 'sale_time';
            sold = false;
            // itemAvailable = true;
            formatDocFun = _self.formatSaleId;
        } else if (doc._id.indexOf('receiving_') === 0) {
            itemsKey = 'receiving_items';
            infoKey = 'receivings_info';
            timeStampKey = 'receiving_time';
            itemAvailable = false;
            elementPrefix = 'supplier';
            formatDocFun = _self.formatReceivingId;
        } else if (doc._id.indexOf('saleReturn_') === 0) {
            sold = true;
            reverseSign = 1;
            formatDocFun = _self.formatSaleId;
        } else if (doc._id.indexOf('receivingReturn_') === 0) {
            itemAvailable = true;
            elementPrefix = 'supplier';
            reverseSign = 1;
            formatDocFun = _self.formatReceivingId;
        }

        let timeStamp = doc[infoKey][timeStampKey];

        for (let i = 0; i < doc[itemsKey].length; i++) {
            let item = doc[itemsKey][i];
            let invDocId = itemLib.formatInvDocId(item.item_id);

            let uniqueDetails = [];
            if (ARRAY_LENGTH(item.uniqueDetails)) {
                //purchase and purchase return
                uniqueDetails = item.uniqueDetails;
            } else if (item.serialnumber || ARRAY_LENGTH(item.imeiNumbers)) {
                // sale and sale return
                uniqueDetails = [{
                    serialnumber: item.serialnumber,
                    imeiNumbers: item.imeiNumbers
                }];
            }

            if (!status.reverseInvTrans[invDocId]) {
                status.reverseInvTrans[invDocId] = {
                    status: 4,
                    doc: {
                        bReverse: true,
                        _id: invDocId,
                        stock: {},
                        transactions: {}
                    }
                };
            }

            let stockKey = item.stockKey;
            if (!status.reverseInvTrans[invDocId].doc.stock[stockKey]) {
                status.reverseInvTrans[invDocId].doc.stock[stockKey] = {
                    uniqueDetails: {}
                };
            }

            status.reverseInvTrans[invDocId].doc.transactions[timeStamp + '_' + item.stockKey] = 1;
            if (ARRAY_LENGTH(uniqueDetails)) {
                itemLib.getUniqueDetailsJson(uniqueDetails, itemAvailable, sold, status.reverseInvTrans[invDocId].doc.stock[stockKey].uniqueDetails);
            }
        }

        let elementId = doc[infoKey][elementPrefix + '_id'];
        if (elementId) {
            status[elementPrefix + 's'] = {};
            let elementDocId = elementPrefix + '_' + elementId;
            status[elementPrefix + 's'][elementDocId] = {
                status: 4,
                doc: {
                    _id: elementDocId,
                    total: reverseSign * parseFloat(doc[infoKey].total), //RelaxDanger This is rounded off total. get total without manipulation
                    balance: reverseSign * doc[infoKey].pending_amount,
                    timestamp: doc[infoKey][timeStampKey]
                }
            }
            if (elementPrefix === 'customer') {
                let loyalty = 0;
                let v = 0;
                if (doc[infoKey] && doc[infoKey].loyaltyEarned) {
                    loyalty -= doc[infoKey].loyaltyEarned;
                }
                if (doc[infoKey] && doc[infoKey].rmPnts) {
                    loyalty += doc[infoKey].rmPnts
                }
                v = doc.status[elementPrefix + 's'][elementDocId].v + 1;
                status[elementPrefix + 's'][elementDocId].v = v;
                status[elementPrefix + 's'][elementDocId].doc.v = v;
                status[elementPrefix + 's'][elementDocId].doc.loyaltyPnts = loyalty;
                status[elementPrefix + 's'][elementDocId].doc.timeStamp = doc[infoKey][timeStampKey];
            }
        };

        if (doc[infoKey].parentId) {
            let parentDocId = formatDocFun(doc[infoKey].parentId);
            status.parentDoc = {};
            status.parentDoc[parentDocId] = {
                status: 4,
                doc: {
                    _id: parentDocId,
                    returnDocId: doc[infoKey].id,
                    bReverse: true
                }
            };
        }

        return status;
    }
    /**
         delete checkout order doc
           */

    async function checkoutOrderDocDelete(doc) {
        try {
            let tableNo;
            let sale_id;
            if (!doc.sales_info.tableNo) {
                return;
            }
            tableNo = doc.sales_info.tableNo;
            _id = doc.sales_info.sale_id;
            let id = 't_table_' + tableNo + '_' + _id;
            let checkoutOrder = await couchDBUtils.getDoc(id, mainDBInstance);
            await couchDBUtils.delete(checkoutOrder, mainDBInstance);
        } catch (err) {
            logger.info('Checkout Order Doc Delete Fail');
        }
    }

    this.reverseTransaction = async function(docId, bReject, reason, bUpdateStockOnDelete) {
        if (bUpdateStockOnDelete === undefined) {
            bUpdateStockOnDelete = true;
        }

        let commonWorker = require('../workers/commonWorker');
        try {
            let doc = await couchDBUtils.getTransDoc(docId, mainDBInstance, 'Transaction Doesnot exist');
            let type = _self.getTransType(doc._id);
            if (doc.bRejected) {
                if (bReject) {
                    throw 'Already Rejected.'
                }
                await couchDBUtils.delete(doc, mainDBInstance, 1, 'Delete Failed');
                await checkoutOrderDocDelete(doc);
                return {
                    message: 'Success'
                };
            }

            if (ARRAY_LENGTH(doc.mods)) {
                throw 'Please Delete Child Transactions First';

            }
            if (doc.status.status) {
                logger.error('Reversing with pending transaction<' + doc._id + '>');
                throw 'Please try after some time';

            }

            let statusJson = getReverseStatusJson(doc, bReject, reason);
            doc.status = statusJson;
            if (!bUpdateStockOnDelete) {
                delete statusJson.reverseInvTrans;
                /*
                * customer doc shoulp get updated for each sale or purchase reject for any value of bUpdateStockOnDelete 
                if (statusJson.customers) {
                    delete statusJson.customers;
                }
                if (statusJson.suppliers) {
                    delete statusJson.suppliers;
                }*/
                if (!statusJson.parentDoc) {
                    //Sale And Purchase the below flags have to be set here.
                    //For returns no problem.. in status it is set
                    if (bReject) {
                        doc.bRejected = true;
                    } else {
                        doc._deleted = true;
                    }
                }
            }

            commonWorker.setFreeze(true);
            doc = await _self.encodeTransDoc(doc, type);
            await couchDBUtils.create(doc, mainDBInstance, 2, 'Reverse Transaction Failed');

            let params = {
                parentDocId: doc._id
            };
            if (statusJson.reverseInvTrans) {
                //If stock update is false .. it doesn't come here
                params.reverseTransactions = statusJson.reverseInvTrans
            }
            if (statusJson.customers) {
                params.elementUpdates = statusJson.customers;
            } else if (statusJson.suppliers) {
                params.elementUpdates = statusJson.suppliers;
            }
            if (statusJson.parentDoc) {
                //Sale Return And Purchase Return
                params.returnUpdates = statusJson.parentDoc;
            }
            // if (doc.sales_info.loyaltyEarned || doc.sales_info.rmPnts) {
            //     let customer = await couchDBUtils.getDoc('customer_' + doc.sales_info.customer_id, mainDBInstance, 'Customer Doesnot exist');
            //     if (customer.loyaltyPnts) {
            //         if (doc.sales_info.loyaltyEarned) {
            //             logger.info("Deducting loyalty point :" + doc.sales_info.loyaltyEarned);
            //             customer.loyaltyPnts -= doc.sales_info.loyaltyEarned;
            //         }
            //         if (doc.sales_info.rmPnts) {
            //             logger.info("Adding loyalty point :" + doc.sales_info.rmPnts);
            //             customer.loyaltyPnts += doc.sales_info.rmPnts;
            //         }
            //         logger.info("Balance pnts :" + customer.loyaltyPnts);
            //         await couchDBUtils.update(customer, mainDBInstance, 1, 'Customer Update failed');
            //     }
            // }

            commonWorker.insertTrans(params);
            commonWorker.setFreeze(false);
            await checkoutOrderDocDelete(doc);
            return {
                message: 'Success'
            };
        } catch (error) {
            commonWorker.setFreeze(false);
            throw {
                error: error
            }
        }
    };

    this.getTransType = function(id) {
        let type = 'sale';
        if (id.indexOf('saleReturn') === 0) {
            type = 'saleReturn';
        } else if (id.indexOf('receivingReturn') === 0) {
            type = 'purchaseReturn';
        } else if (id.indexOf('receiving') === 0) {
            type = 'purchase';
        }
        return type;
    }

    this.cleanTxnsByType = async function(type) {
        try {
            let docs = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
            console.log(docs);
            for (let j = 0; j < docs.length; j++) {
                console.log(docs[j].id);
                await _self.reverseTransaction(docs[j].id);
            }
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
    this.getTaxAmt = function(taxArray) {
        let taxAmt = 0;
        for (let tax in taxArray) {
            taxAmt += taxArray[tax];
        }
        return taxAmt;
    }

    this.getTansDocument = async function(docId) {
        try {
            let doc = await couchDBUtils.getTransDoc(docId, mainDBInstance, 'Transaction Doesnot exist');
            return doc;
        } catch (error) {
            logger.error(error);
            throw error;
        }
    };

    this.bStringifiedJSON = function(value) {
        if (!value) {
            return false;
        }
        if (value.indexOf('{') > -1 &&
            value.indexOf('}') > -1 &&
            value.indexOf('":"') > -1 &&
            Object.keys(JSON.parse(value)).length
        ) {
            return true;
        }
        return false;
    }

    var commonFields = ['discount'];
    var intFields = ['item_id', 'line', 'imeiCount', 'categoryId', 'num', 'invoiceCheckpoint', 'sale_time', 'receiving_time', 'time', 'supplier_id', 'customer_id', 'tableNo', 'pProfileId', 'parentId'];
    var floatFields = ['price', 'baseUnitPrice', 'sellingPriceExcludingTax', 'totalTaxPercent', 'totalPurchaseTaxPercent', 'purchasePrice', 'mrp', 'reorder_level', 'total', 'subTotal', 'subtotal', 'cost', 'profit', 'quantity', 'deliveryCharge', 'pending_amount', 'discount', 'discount_percent', 'quantity_purchased', 'sellingPrice', 'gDiscountPercent', 'loyaltyEarned', 'rmPnts'];
    var objFields = ['wcInfo', 'slab', 'taxes', 'taxDetailed', 'shippingDetails', 'globalDiscountInfo', 'imeiNumbers', 'unitDocs', 'chargesList', 'chargesTaxList', 'unitsInfo', 'itemTaxList', 'uniqueDetails'];
    var boolFields = ['isNew', 'interState', 'is_serialized', 'hasBatchNumber', 'bOTG', 'hasExpiryDate', 'bSPTaxInclusive', 'bPPTaxInclusive', 'isWarranty'];

    function converValue(val, key) {
        // var val = itemVals[iF];
        if (commonFields.indexOf(key) !== -1 && _self.bStringifiedJSON(val)) {
            val = JSON.parse(val);
        } else if (intFields.indexOf(key) !== -1) {
            val = val ? parseInt(val) : 0;
        } else if (floatFields.indexOf(key) !== -1) {
            val = val ? parseFloat(val) : 0;
        } else if (objFields.indexOf(key) !== -1) {
            val = val ? JSON.parse(val) : (key === 'wcInfo' ? undefined : {});
        } else if (boolFields.indexOf(key) !== -1) {
            if (val && (val.toLowerCase() === 'yes' || val.toLowerCase() === 'true')) {
                val = true;
            } else {
                val = false;
            }
        }
        return val;
    }

    this.transformSaleDoc = function(doc, type) {
        var infoKey = 'sales_info';
        var itemsKey = 'sale_items';
        var idKey = 'sale_id';
        let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts', 'discount', 't_no', 'purchaseOrderDocId'];
        let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
        if (type === 'saleReturn') {
            idKey = 'id';
            infoKey = 'info';
            itemsKey = 'items';
            infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts', 'discount', 't_no', 'purchaseOrderDocId'];
        } else if (type === 'purchaseReturn') {
            idKey = 'id';
            infoKey = 'info';
            itemsKey = 'items';
            infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
            itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
        } else if (type === 'purchase') {
            idKey = 'receiving_id';
            infoKey = 'receivings_info';
            itemsKey = 'receiving_items';
            infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
            itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
        }

        var items = doc[itemsKey];
        var info = doc[infoKey];
        var itemsArray = [];

        for (var q = 0; q < items.length; q++) {
            var itemVals = items[q].split(';');
            var itemInfo = {};
            for (var iF = 0; iF < itemFields.length; iF++) {
                var val = converValue(itemVals[iF], itemFields[iF]);

                itemInfo[itemFields[iF]] = val;
            }
            itemsArray.push(itemInfo);
        }
        items = itemsArray;
        var salesInfoVals = info.split(';');
        var salesInfo = {};
        salesInfo._id = salesInfoVals[0];
        for (var s = 0; s < infoFields.length; s++) {
            var infoVal = converValue(salesInfoVals[s + 1], infoFields[s]);
            salesInfo[infoFields[s]] = infoVal;
        }
        info = salesInfo;
        info[idKey] = doc[idKey];
        doc[infoKey] = info;
        doc[itemsKey] = items;
        doc.payments = JSON.parse(doc.payments); //payTypes;
        return doc

    }

    function getValString(val) {
        if (val === undefined || val === null) {
            val = ""
        } else if (typeof val === "object") {
            val = JSON.stringify(val);
        }
        if (typeof val === 'string' && val.indexOf(';') > -1) {
            val = val.replace(';', '');
        }
        return val;
    }

    this.encodeTransDoc = async function(doc, type) {
        var infoKey = 'sales_info';
        var itemsKey = 'sale_items';
        /**
         * whene you change the fields array or encodeTransDoc or transformSalesDoc change in the following places as well
         * 1.commolib (currentfile)
         * 2. maindbViews (2 places ) : update_customer view and delta_pending_amount 
         * 3. computeUtils in profitGuruCore/Services/Reports/
         */
        let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts', 'discount', 't_no', 'purchaseOrderDocId'];
        let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
        if (type === 'saleReturn') {
            infoKey = 'info';
            itemsKey = 'items';
            infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts', 'discount', 't_no', 'purchaseOrderDocId'];
        } else if (type === 'purchaseReturn') {
            infoKey = 'info';
            itemsKey = 'items';
            infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
            itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
        } else if (type === 'purchase') {
            infoKey = 'receivings_info';
            itemsKey = 'receiving_items';
            infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
            itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
        }
        if (doc[infoKey].customer_id) {
            var customerInfo = await couchDBUtils.getDoc('customer_' + doc[infoKey].customer_id, mainDBInstance);
            var checkCompanyName = customerInfo.company_name ? customerInfo.company_name : '';
            var checkLastName = customerInfo.last_name ? customerInfo.last_name : '';
            doc[infoKey].customer = checkCompanyName + ' ' + customerInfo.first_name + ' ' + checkLastName;
        }
        if (doc[infoKey].employee_id) {
            var empInfo = await couchDBUtils.getDoc('org.couchdb.user:' + doc[infoKey].employee_id, usersdb);
            doc[infoKey].employee = empInfo.first_name ? empInfo.first_name + ' ' + empInfo.last_name : doc[infoKey].employee_id;
        }
        if (doc[infoKey].supplier_id) {
            var supInfo = await couchDBUtils.getDoc('supplier_' + doc[infoKey].supplier_id, mainDBInstance);
            var checkCompanyName = supInfo.company_name ? supInfo.company_name : '';
            var checkLastName = supInfo.last_name ? supInfo.last_name : '';
            doc[infoKey].supplier = checkCompanyName + ' ' + supInfo.first_name + ' ' + checkLastName;
        }
        let info = doc[infoKey];
        if (type === 'saleReturn') {
            info.num = doc.id;
        }
        let items = doc[itemsKey];
        let transInfo = doc._id + ';';
        for (let i = 0; i < infoFields.length; i++) {
            let val = getValString(info[infoFields[i]])
            transInfo += val + ';';
        }
        let itemsList = [];
        for (var j = 0; j < items.length; j++) {
            if (!items[j].category) {
                let itemInfo = await couchDBUtils.getDoc('item_' + items[j].item_id, mainDBInstance);
                let categoryInfo = await couchDBUtils.getDoc('category_' + itemInfo.info.categoryId, mainDBInstance);
                items[j].category = categoryInfo.name;
            }
            let itemString = "";
            for (let k = 0; k < itemFields.length; k++) {
                let fieldVal = getValString(items[j][itemFields[k]])
                itemString += fieldVal + ';';
            }
            itemsList.push(itemString);
        }
        let payments = JSON.stringify(doc.payments);
        // let payments = "";
        // for (let l = 0; l < doc.payments.length; l++) {
        //     payments += doc.payments[l].payment_type + ';' + doc.payments[l].payment_amount + ';' + (doc.payments[l].returnAmt ? doc.payments[l].returnAmt : 0) + ';';
        // }
        doc.payments = payments;
        doc[infoKey] = transInfo;
        doc[itemsKey] = itemsList;
        return doc;

    }
    this.getPaymentsTotal = function(payments) {
        var total = 0;
        for (var i = 0; i < payments.length; i++) {
            if (payments[i].dp) {
                continue;
            }
            total += payments[i].payment_amount;
        }
        return total;
    }

    this.mergeStatus = function(status, oldDoc, newTimeStamp, bSale) {
        let itemsLib = require('./itemsControllerLib');

        let timeStampKey = 'sale_time';
        let itemsKey = 'sale_items';
        let infoKey = 'sales_info';
        let elementKey = 'customer_id';
        let element = 'customer';
        let mulSign = 1;
        let itemAvailable;
        let sold;

        if (!bSale) {
            itemAvailable = true;
            mulSign = -1;
            timeStampKey = 'receiving_time';
            itemsKey = 'receiving_items';
            infoKey = 'receivings_info';
            elementKey = 'supplier_id';
            element = 'supplier';
        } else {
            sold = true;
        }

        let oldTimeStamp = oldDoc[infoKey][timeStampKey];
        let bTimeStampChanged = oldTimeStamp != newTimeStamp;

        let inventoryStatus = status.inventoryTrans;

        let items = oldDoc[itemsKey];
        for (let i = 0; i < items.length; i++) {
            let invDocId = itemsLib.formatInvDocId(items[i].item_id);
            let stockKey = items[i].stockKey;
            let transKey = itemsLib.formatInvTransKey(oldTimeStamp, stockKey);

            if (!inventoryStatus[invDocId]) {
                inventoryStatus[invDocId] = {
                    status: 4,
                    doc: {
                        _id: invDocId,
                        stock: {}
                    }
                }
            }
            let invStatusDoc = inventoryStatus[invDocId].doc;
            if (!invStatusDoc.transactions2Delete) {
                invStatusDoc.transactions2Delete = {};
            }

            if (bTimeStampChanged || !invStatusDoc.transactions || !invStatusDoc.transactions[transKey]) {
                //If timestamp changes we have to delete all the previous keys
                //If timestamp is same but the stock is not present in the edit
                invStatusDoc.transactions2Delete[transKey] = {
                    trans_stockKey: stockKey
                };
            }

            //Merging
            if (!invStatusDoc.stock[stockKey]) {
                //stock got removed while editing
                invStatusDoc.stock[stockKey] = {
                    quantity: 0,
                    bDeleted: true,
                    uniqueDetails: {}
                }
            }

            let factor = _self.getFactor(items[i].unitsInfo, items[i].unitId, items[i].baseUnitId);

            invStatusDoc.stock[stockKey].quantity = invStatusDoc.stock[stockKey].quantity + (mulSign * factor * items[i].quantity_purchased);
            let unqDet = items[i].uniqueDetails;
            if (bSale) {
                unqDet = [];
                if (items[i].serialnumber || items[i].imeiNumbers.length) {
                    unqDet.push({});
                    if (items[i].serialnumber) {
                        unqDet[0].serialnumber = items[i].serialnumber;
                    } else {
                        unqDet[0].serialnumber = "";
                    }
                    if (items[i].imeiNumbers.length) {
                        unqDet[0].imeiNumbers = items[i].imeiNumbers;
                    } else {
                        unqDet[0].imeiNumbers = [];
                    }
                }
            }

            itemsLib.uniqueDetailsJsonForEdit(unqDet, itemAvailable, sold, invStatusDoc.stock[stockKey].uniqueDetails);
        }

        let oldInventoryStatus = oldDoc.status.inventoryTrans;
        for (let invDocId in inventoryStatus) {
            let nextV = 0;
            if (oldInventoryStatus[invDocId]) {
                if (oldInventoryStatus[invDocId].v) {
                    nextV = oldInventoryStatus[invDocId].v;
                } else {
                    nextV = 2; //This is to cover the initial mistake which caused bug #2250
                }
            }
            nextV++;
            for (let transKey in inventoryStatus[invDocId].doc.transactions) {
                inventoryStatus[invDocId].doc.transactions[transKey].v = nextV;
            }
            inventoryStatus[invDocId].v = nextV;
        }

        let elementId = oldDoc[infoKey][elementKey];
        if (elementId) {
            let elementDocId = element + '_' + elementId;
            let v = 0;
            let loyalty = 0;
            if (element === 'customer') {
                v = oldDoc.status[element + 's'][elementDocId].v + 1;
                if (oldDoc[infoKey] && oldDoc[infoKey].loyaltyEarned) {
                    loyalty -= oldDoc[infoKey].loyaltyEarned;
                }
                if (oldDoc[infoKey] && oldDoc[infoKey].rmPnts) {
                    loyalty += oldDoc[infoKey].rmPnts
                }
            }
            if (!status[element + 's'][elementDocId]) {
                //customer or suppliler has changed between orignal sale and edit sale
                logger.info("Customer changed, deducting the old loyalty " + loyalty);
                status[element + 's'][elementDocId] = {
                    status: 4,
                    doc: {
                        _id: elementDocId,
                        total: 0,
                        balance: 0,
                        v: v
                    },
                    v: v
                };
                if (element === 'customer') {
                    status[element + 's'][elementDocId].doc.loyaltyPnts = loyalty;
                    // status[element + 's'][elementDocId].doc.timeStamp = oldDoc[infoKey].sale_time;// doing in down
                }
            }
            status[element + 's'][elementDocId].doc.timeStamp = oldDoc[infoKey][timeStampKey];
            status[element + 's'][elementDocId].doc.balance += -1 * oldDoc[infoKey].pending_amount;
            status[element + 's'][elementDocId].doc.total += -1 * oldDoc[infoKey].total;
            status[element + 's'][elementDocId].doc.v = v;

        }

    };

    this.getTotalPaidForReprint = function(payments, bSale) {
        let creditType = 'Purchase On Credit';
        let paymentIdKey = 'payment_receiving_id';
        if (bSale) {
            creditType = 'Sale on credit';
            paymentIdKey = 'payment_sale_id';
        }
        let totalPaid = 0;
        let creditIndex = -1;
        let creditClearedAmt = 0;
        for (let i = 0; i < payments.length; i++) {
            if (payments[i].payment_type === creditType) {
                creditIndex = i;
                continue;
            }
            totalPaid += payments[i].payment_amount;
            if (payments[i][paymentIdKey]) {
                creditClearedAmt += payments[i].payment_amount;
            }
        }

        let creditAmt = 0;
        if (creditIndex !== -1) {
            creditAmt = payments[creditIndex].payment_amount - creditClearedAmt;
            if (creditAmt <= 0) {
                creditAmt = 0;
                payments.splice(creditIndex, 1);
            } else {
                payments[creditIndex].payment_amount = creditAmt;
            }
        }
        totalPaid += creditAmt;

        return totalPaid;
    };

    this.getCreditPayment = function(arrPayments) {
        let amt = 0;
        arrPayments.some(function(payment) { // .some breaks when atleast one true returned or till last
            let bCredit = payment.payment_type.toLowerCase() == 'sale on credit';
            if (bCredit) amt = payment.payment_amount;
            return bCredit;
        })
        return amt;
    }

    this.convertToGSTTaxes = function(itemTaxList) {
        let taxList = [];
        let gstIndex = -1;
        for (let j = 0; j < itemTaxList.length; j++) {
            if (itemTaxList[j].name.indexOf('GST') > -1) {
                if (gstIndex > -1) {
                    taxList[gstIndex].percent += itemTaxList[j].percent;
                } else {
                    gstIndex = taxList.length;
                    taxList.push(itemTaxList[j]);
                    taxList[gstIndex].name = 'GST';
                }
            } else {
                taxList.push(itemTaxList[j]);
            }
        }

        return taxList;
    }

    this.get_quantity = function(cartData) {
        let qty = 0;
        for (let i = 0; i < cartData.length; i++) {
            qty += parseFloat(cartData[i].quantity);
        }

        return qty;

    }

    this.addPaymentsForEdit = async function(payments, addPaymentRestApi, bSale) {
        let bEdit = true;
        let creditType = 'Purchase On Credit';
        let paymentIdKey = 'payment_receiving_id';
        if (bSale) {
            creditType = 'Sale on credit';
            paymentIdKey = 'payment_sale_id';
        }

        let resp;
        let creditIndex = -1;
        let creditPaidAmt = 0;
        for (var j = 0; j < payments.length; j++) {
            if (payments[j].payment_type === creditType) {
                creditIndex = j;
                continue;
            }
            if (payments[j][paymentIdKey]) {
                creditPaidAmt += payments[j].payment_amount;
            }

            payments[j].amount_tendered = payments[j].payment_amount;
            resp = await addPaymentRestApi(payments[j], bEdit);
        }
        if (creditIndex !== -1) {
            payments[creditIndex].amount_tendered = payments[creditIndex].payment_amount - creditPaidAmt;
            if (payments[creditIndex].amount_tendered > 0) {
                resp = await addPaymentRestApi(payments[creditIndex], bEdit);
            }
        }

        return resp;
    };

    this.getTaxesForItem = function(bLocalTax, taxes, slab, formattedTaxes, price, bPPTaxInclusive) {
        if (!IS_EMPTY_OBJECT(slab) && bPPTaxInclusive) {
            logger.error('tax slab and tax inclusive is not implemented');
            throw 'Internal Error';
        }

        let totalTaxPercent = 0;
        formattedTaxes.length = 0;
        let formattedTaxesCount = {};
        if (!IS_EMPTY_OBJECT(slab)) {
            let taxFromSlab = computeUtils.getTaxFromSlab(slab, price);

            if (taxFromSlab.percent !== -1) {
                formattedTaxes.push(taxFromSlab);
                formattedTaxesCount[taxFromSlab.name] = 1;
                totalTaxPercent += taxFromSlab.percent;
            }
        }
        let totalTaxWithoutSlab = 0
        for (let taxIdx in taxes) {
            let tax = taxes[taxIdx].taxInfo;
            if (!formattedTaxesCount[tax.name]) {
                let itemTaxInfo = {};
                itemTaxInfo.name = tax.name;
                itemTaxInfo.percent = tax.percent;
                totalTaxPercent += tax.percent;
                formattedTaxes.push(itemTaxInfo);
                formattedTaxesCount[tax.name] = 1;
                totalTaxWithoutSlab += tax.percent;
            }
        }

        computeUtils.formatGSTTaxes(formattedTaxes, bLocalTax);

        return totalTaxPercent;
    }

    return this;

};

module.exports = new commonLib();