"use strict";
/// <reference path="../../types/itemsControllerLib.d.ts" />
Object.defineProperty(exports, "__esModule", { value: true });
const itemsControllerLib = require("./itemsControllerLib");
const commonLib = require("./commonLib");
exports.getInventoryTransaction = function (params) {
    let { items, timeStamp, employee_id, comment, bDecrement } = params;
    let inventoryStatus = {};
    for (let i = 0; i < items.length; i++) {
        let item = items[i];
        let itemAvailable; //undefined so that we don't modify this variable in stock                    
        let docId = itemsControllerLib.formatInvDocId(item.item_id);
        let invTrans = {};
        if (inventoryStatus[docId] && inventoryStatus[docId].doc) {
            invTrans = inventoryStatus[docId].doc;
        }
        let uniqueDetail = {
            serialnumber: item.serialnumber,
            imeiNumbers: item.imeiNumbers
        };
        if (item.is_serialized || item.imeiCount) {
            item.uniqueDetails = [uniqueDetail];
        }
        let itemForInvTrans = commonLib.getParamsForGettingInvTrans(item, timeStamp, employee_id, comment, bDecrement);
        itemsControllerLib.updateStockHelper(itemForInvTrans, invTrans, itemAvailable, bDecrement);
        inventoryStatus[invTrans._id] = {
            status: 4,
            doc: invTrans
        };
    }
    return inventoryStatus;
};
//# sourceMappingURL=inventoryTransactionHelper.js.map