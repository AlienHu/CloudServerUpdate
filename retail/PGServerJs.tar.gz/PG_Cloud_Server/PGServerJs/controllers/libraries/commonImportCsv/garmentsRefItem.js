let jsonObj = {
    "uniqueItemCode": "",
    "name": "cream roll 50gm",
    "item_number": "",
    "receiving_quantity": 0,
    "reorder_level": 0,
    "description": "clothes",
    "expiry_date": "",
    "allow_alt_description": "0",
    "ItemType": "",
    "categoryId": 1518184574486,
    "purchasePrice": "",
    "sellingPrice": "",
    "mrp": "",
    "hasMeasurementUnit": false,
    "is_serialized": false,
    "hasExpiryDate": false,
    "purchaseTaxes": [
        1518183575402
    ],
    "salesTaxes": [
        1518183575402
    ],
    "reorderLevel": "",
    "reorderQuantity": "",
    "isNewBatch": false,
    "hasBatchNumber": false,
    "bOTG": false,
    "bPPTaxInclusive": true,
    "bSPTaxInclusive": true,
    "imeiCount": 0,
    "imeNumbers": [],
    "initialStock": [{
        "quantity": 0,
        "expiry": null,
        "uniqueDetails": [],
        "unitsInfo": {
            "1518183574427": {
                "refUnitId": 1518183574427,
                "factor": 1,
                "purchasePrice": 20,
                "mrp": 25,
                "pProfilesData": {
                    "1518183576279": {
                        "sellingPrice": 25,
                        "discountId": ""
                    }
                }
            }
        }
    }],
    "unitsInfo": {
        "1518183574427": {
            "refUnitId": 1518183574427,
            "factor": 1,
            "purchasePrice": 20,
            "mrp": 25,
            "pProfilesData": {
                "1518183576279": {
                    "sellingPrice": 25,
                    "discountId": ""
                }
            }
        }
    },
    "hasVariants": false,
    "density": 0,
    "pricingProfiles": false,
    "multipleUnits": false,
    "itemNprice": 0,
    "baseUnitId": 1518183574427,
    "convPurchasePrice": "",
    "defaultSellingUnitId": 1518183574427,
    "defaultPurchaseUnitId": 1518183574427,
    "purchaseUnitId": 0,
    "sellingUnitId": 0,
    "attributes": [],
    "isprepared": false,
    "issellable": false,
    "isbought": false,
    "is_deleted": "",
    "discount_expiry": null,
    "employeeId": "admin"
};

module.exports = jsonObj;