let jsonObj = {
    "uniqueItemCode": "77677JNMJHB",
    "name": "samsung j7 prime",
    "item_number": "678687JHKBKASD",
    "receiving_quantity": 0,
    "reorder_level": 0,
    "description": "Mobile",
    "supplier_id": 1517919503859,
    "expiry_date": "",
    "allow_alt_description": "0",
    "ItemType": "",
    "categoryId": 1517919850180,
    "purchasePrice": "",
    "sellingPrice": "",
    "mrp": "",
    "hasMeasurementUnit": false,
    "is_serialized": true,
    "hasExpiryDate": true,
    "purchaseTaxes": [
        1517919503646
    ],
    "salesTaxes": [
        1517919503646
    ],
    "reorderLevel": 1,
    "reorderQuantity": 2,
    "isNewBatch": false,
    "hasBatchNumber": true,
    "bOTG": true,
    "bPPTaxInclusive": false,
    "bSPTaxInclusive": false,
    "imeiCount": 2,
    "imeNumbers": [],
    "initialStock": [{
        "batchId": "batch103",
        "quantity": 3,
        "expiry": "2018-02-27T18:30:00.000Z",
        "uniqueDetails": [{
                "imeiNumbers": [
                    785785767655774,
                    576596986986698
                ],
                "serialnumber": "7678"
            },
            {
                "imeiNumbers": [
                    97907423740079,
                    678320039999999
                ],
                "serialnumber": "784230009890"
            },
            {
                "imeiNumbers": [
                    765765765764442,
                    422229099877997
                ],
                "serialnumber": "762889999ybhujj"
            }
        ],
        "unitsInfo": {
            "1517919248164": {
                "refUnitId": 1517919248164,
                "factor": 1,
                "purchasePrice": 10000,
                "mrp": 10000,
                "pProfilesData": {
                    "1517919246064": {
                        "sellingPrice": 10000,
                        "discountId": 1517919503165
                    }
                }
            }
        }
    }],
    "unitsInfo": {
        "1517919248164": {
            "refUnitId": 1517919248164,
            "factor": 1,
            "purchasePrice": 10000,
            "mrp": 10000,
            "pProfilesData": {
                "1517919246064": {
                    "sellingPrice": 10000,
                    "discountId": 1517919503165
                }
            }
        }
    },
    "hasVariants": false,
    "density": 0,
    "pricingProfiles": false,
    "multipleUnits": false,
    "itemNprice": 0,
    "baseUnitId": 1517919248164,
    "convPurchasePrice": "",
    "salesSlab": 1517919972567,
    "isWarranty": true,
    "warrantyTerms": "Y",
    "warranty": 1,
    "imei": true,
    "hsn": "HSN13689",
    "defaultSellingUnitId": 1517919248164,
    "defaultPurchaseUnitId": 1517919248164,
    "purchaseSlab": 1517919972567,
    "purchaseUnitId": 0,
    "sellingUnitId": 0,
    "attributes": [],
    "isprepared": false,
    "issellable": false,
    "isbought": false,
    "is_deleted": "",
    "discount_expiry": null,
    "employeeId": "admin"
}

module.exports = jsonObj;