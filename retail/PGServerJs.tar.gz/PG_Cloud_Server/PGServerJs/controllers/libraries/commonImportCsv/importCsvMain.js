'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

// let itemsCtrl = function() {

const couchDbManager = require('../../../dbManagers/couchDbManager');
const couchDBUtils = require('../../common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const globalConfigController = require('../../GlobalConfigurations');
const roomCntrlr = require("../../../controllers/Rooms");
const logger = require("../../../common/Logger");
const varientCtrl = require("../../../controllers/Variants");

// some of the functions are wrote in this file.
const importHelperCtrl = require('./importCsvHelper');

var itemsArray = [];

//to check column exist or not in csv file.
var excelColumns = {
    "Initial Stock Size": 0,
    "Number Of Batches": 0,
    "IMEI Count": 0,
    "IMEI Number": 0,
    "Serial Number": 0,
    "Item Code": 0,
    "Name": 0,
    "Barcode": 0,
    "Description": 0,
    "Supplier Name": 0,
    "Category Name": 0,
    "GST Purchase Taxes%": 0,
    "GST Sales Taxes%": 0,
    "CESS Purchase Taxes%": 0,
    "CESS Sales Taxes%": 0,
    "Slab": 0,
    "Item Type": 0,
    "PP Tax Inclusive": 0,
    "SP Tax Inclusive": 0,
    "Reorder Level": 0,
    "Reorder Quantity": 0,
    "OTG": 0,
    "Attributes": 0,
    "HSN": 0,
    "Unit Name": 0,
    "Quantity": 0,
    "Batch Id": 0,
    "Expiry Date": 0,
    "Purchase Price": 0,
    "MRP": 0,
    "Selling Price": 0,
    "SKU Name": 0,
    "Discount %": 0,
    "Warranty": 0,
    "Warranty Terms": 0
};

/**
 * 
 * @param {*check column exist or not in csv file} columns 
 */
async function excelSheetColumns(columns) {

    console.log("columns:" + columns);
    for (let i = 0; i < columns.length; i++) {
        excelColumns[columns[i]] = 1;
    }
    console.log("JSON.stringify(defaultColumns:" + JSON.stringify(excelColumns));
    console.log("\n\n");
}

// this.importCsvFile = function() {

var csv = require('csvtojson')
console.log("Hello ");
csv()
    .fromFile(__dirname + '/importTemplate.csv')
    .on('json', (jsonObj) => {
        itemsArray.push(jsonObj);
    })
    .on('done', (error) => {
        console.log(itemsArray.length);
        console.log("item Name" + itemsArray[0].Name);
        console.log("item Code" + itemsArray[0]["Item Code"]);
        console.log('end');
        console.log("error:" + error);
        excelSheetColumns(Object.keys(itemsArray[0]));
        console.log(JSON.stringify(excelColumns));
        console.log("\n\n");
        return run();
    });

// }

let salesTaxesHeaderNameArr = [];
let purchaseTaxesHeaderNameArr = [];

async function prepare() {

    const configObj = require("./createConfig");

    console.log("calling prepare method");

    //create Categories config
    if (excelColumns['Category Name'] === 1) {
        await configObj.createConfig('Category Name', itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr);
    }

    //create Discount config
    if (excelColumns['Discount %'] === 1) {
        await configObj.createConfig('Discount %', itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr);
    }

    //check Attributes,SKU Name columns are existing or not
    if (excelColumns["Attributes"] === 1 && excelColumns["SKU Name"] === 1) {
        //create variants
        await configObj.createVariants(itemsArray);
    }

    //create tax config
    let headers = Object.keys(itemsArray[0]);
    for (let i = 0; i < headers.length; i++) {

        if (headers[i].indexOf("Purchase Taxes%") != -1 || headers[i].indexOf("Sales Taxes%") != -1) {
            await configObj.createConfig(headers[i], itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr);
        }

    }

    console.log("calling create supplier method");
    //create supplier
    if (excelColumns["Supplier Name"] === 1) {
        await configObj.createSupplier();
    }

    console.log("calling create slab method");

    //check if column existing or not
    if (excelColumns["Slab"] === 1) {
        await configObj.createSlab();
    }

    console.log("calling createGeneralCategory method");

    //check if column existing or not
    if (excelColumns["Category Name"] === 0) {
        await configObj.createGeneralCategory();

    }

    console.log("\n\n")
}

let categoryObj = {};
let variantObj = {};
let taxObj = {};
let slabObj = {};
let supplierObj = {};
let unitObj = {};
let pprofileObj = {};
let discountObj = {};

async function getIds() {

    let idsObj = require("./getIds");

    categoryObj = await idsObj.getCategoriesObj();
    variantObj = await idsObj.getVariantsObj();
    taxObj = await idsObj.getTaxIdsObj();
    slabObj = await idsObj.getSlabsObj();
    supplierObj = await idsObj.getSuppliersObj();
    unitObj = await idsObj.getUnitsObj();
    pprofileObj = await idsObj.getPprofilesObj();
    discountObj = await idsObj.getdiscountsObj();

    console.log("\n\ncategoryObj:" + JSON.stringify(categoryObj));
    console.log("\n\nvariantObj:" + JSON.stringify(variantObj));
    console.log("\n\ntaxObj:" + JSON.stringify(taxObj));
    console.log("\n\nslabObj:" + JSON.stringify(slabObj));
    console.log("\n\nsupplierObj:" + JSON.stringify(supplierObj));
    console.log("\n\npprofileObj:" + JSON.stringify(pprofileObj));
    console.log("\n\nunitObj:" + JSON.stringify(unitObj));
    console.log("\n\ndiscountObj:" + JSON.stringify(discountObj));
    console.log("\n\n");
}

async function run() {

    //garments or grocery import
    const garmentCtrl = require("./garmentsImport");

    //mobileStore import 
    const mobileStoreCtrl = require("./mobileStoreImport");

    console.log("calling run method");
    console.log("calling initCouchDb method");
    await couchDbManager.initCouchDb(true);

    console.log("calling prepare method");
    await prepare();

    console.log("calling getIds method");
    await getIds();

    console.log("calling item Array  method");
    // slab createItem Array
    if (excelColumns["Initial Stock Size"] === 1) {
        console.log("calling garmentCtrl.createItemArray");
        await garmentCtrl.createItemArray(excelColumns, itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr,
            categoryObj, variantObj, taxObj, slabObj, supplierObj, unitObj, pprofileObj, discountObj);
    } else if (excelColumns["Serial Number"] === 1 || excelColumns["IMEI Number"] === 1) {
        console.log("calling mobileStoreCtrl.createItemArray");
        await mobileStoreCtrl.createItemArray(excelColumns, itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr,
            categoryObj, variantObj, taxObj, slabObj, supplierObj, unitObj, pprofileObj, discountObj);
    }

    console.log('done');
    // return "success";
}

// }