import * as couchDBUtils from '../common/CouchDBUtils'
const mainDBInstance = couchDBUtils.getMainCouchDB();
const userdb = couchDBUtils.getUserCouchDB();
export async function getReport(docName: string, startTime: string, endTime: string, view: string): Promise<void> {
    let params = {
        startKey: startTime,
        endKey: endTime,
        include_docs: true
    }
    try {
        let reportData = await couchDBUtils.getView(docName, view, params, mainDBInstance);
        let formatedData: any = await querySuccess(reportData);

        // console.log(reportData);
        return formatedData;
    } catch (error) {

        console.log(error);
        throw error;
    }

}

var queryItems = true;
var queryEmployees = true;
var queryCustomers = true;
var queryCategories = false;

async function querySuccess(resp) {
    if (resp.length === 0)
        return [];

    var docs = [];
    var item_ids = [];
    var employee_ids = [];
    var customer_ids = [];
    //not doing any checks assuming all the expected js elements are present
    for (var j = 0; j < resp.length; j++) {
        var doc = resp[j].doc ? resp[j].doc : resp[j];

        if (doc.bRejected) { //Discarding rejected doc for other and Adding rejected doc for detail report 
            continue;
        }


        docs.push(doc);

        var sale_items = doc.sale_items;
        var sales_info = doc.sales_info;
        if (!sale_items) {
            sale_items = doc.items ? doc.items : [];

        }
        if (!sales_info) {
            sales_info = doc.info;
        }

        if (queryItems) {
            for (var i = 0; i < sale_items.length; i++) {
                item_ids.push(sale_items[i].item_id);
            }
        }
        if (queryEmployees) {
            employee_ids.push(sales_info.employee_id);
        }
        if (queryCustomers) {
            var customer_id = sales_info.customer_id;
            if (customer_id)
                customer_ids.push(customer_id);
        }
    }

    //Get it from ItemsDataSvc, EmpDataSvc, CustomerDataSvc 
    // Use PouchQuerySvc
    var queryInfoArray = {
        docs: docs,
        employees: [],
        customers: [],
        items: [],
        categories: {}
    };
    if (employee_ids.length !== 0) {
        employee_ids = Array.from(new Set(employee_ids));
        let empKeys = [];
        for (var q = 0; q < employee_ids.length; q++) {
            // let empInfo = await couchDBUtils.getDoc('org.couchdb.user:' + employee_ids[q], mainDBInstance, 2, 'Failed to fetch the employee doc ' + employee_ids[q]);
            // queryInfoArray.employees.push(empInfo);
            empKeys.push('org.couchdb.user:' + employee_ids[q]);
        }
        // queryInfoArray.push(getInfo('org.couchdb.user:', employee_ids, userdb));
        queryInfoArray.employees = await couchDBUtils.getAllDocsInBulk(empKeys, userdb, 'employee', true);
    }
    // getAllDocs
    //Combine items, categories, customers and query once. They belong to the same db

    if (item_ids.length !== 0) {
        item_ids = Array.from(new Set(item_ids)); //Unique Values
        let itemKeys = [];
        // queryInfoArray.push(getInfo('item_', item_ids, mainDBInstance));
        let itemsDictionary = [];
        for (var p = 0; p < item_ids.length; p++) {
            // let itemInfo = await couchDBUtils.getDoc('item_' + item_ids[p], mainDBInstance, 2, 'Failed to fetch the employee doc ' + item_ids[p]);
            // queryInfoArray.items.push(itemInfo);
            itemKeys.push('item_' + item_ids[p]);
        }
        queryInfoArray.items = await couchDBUtils.getAllDocsInBulk(itemKeys, mainDBInstance, 'item', true);
    }
    // if (queryCategories) {
    //BMTodo error, if you keep checking reports, sometimes categories is not found, may be because of promises?
    // queryInfoArray.push(couchDBUtils.queryAllDocsByType(mainDBInstance, 'category'));
    let catList = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
    var categories = {};
    for (var c = 0; c < catList.length; c++) {
        var catDoc = catList[c].doc;
        categories[catDoc.id] = catDoc.name;
    }
    queryInfoArray.categories = categories
    // }
    if (customer_ids.length !== 0) {
        customer_ids = Array.from(new Set(customer_ids));
        // queryInfoArray.push(getInfo('customer_', customer_ids, mainDBInstance));
        let custKeys = [];
        let customerDictionary = [];
        for (var n = 0; n < customer_ids.length; n++) {
            // let custInfo = await couchDBUtils.getDoc('customer_' + customer_ids[n], mainDBInstance, 2, 'Failed to fetch the employee doc ' + customer_ids[n]);
            // queryInfoArray.customers.push(custInfo);
            custKeys.push('customer_' + customer_ids[n]);
        }
        queryInfoArray.customers = await couchDBUtils.getAllDocsInBulk(custKeys, mainDBInstance, 'customer', true);
    }

    return queryInfoArray;


}