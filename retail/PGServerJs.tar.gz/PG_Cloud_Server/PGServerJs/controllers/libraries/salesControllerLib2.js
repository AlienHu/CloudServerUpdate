/*jshint sub:true*/
const logger = require('../../common/Logger');
const utils = require('../common/Utils');
const CLONE = utils.clone;
const IS_UNDEFINED_OR_NULL = utils.isUndefinedOrNull2;
const ARRAY_LENGTH = utils.getArrayLength;
const ASSIGN_IF_TRUE = utils.assignIfTrue;
const couchDBUtils = require('../common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const moment = require('moment');
const itemsLib = require('./itemsControllerLib');
const workerProcess = require('../workers/commonWorker');
const commonLib = require('./commonLib');
const autoIncrementHelper = require('../common/autoIncrementHelper');
let maxReturnId = autoIncrementHelper.getMaxSaleReturnId();
const saleEx = require('../../TSControllers/SalesEx');
const lockUtils = require('../../common/lockUtils');
lockUtils.createLockDir('locks/sales');
const lockPath = 'locks/sales/sales.lock';
const lockOptions = lockUtils.lockOptions();
let maxTokenNumber = require('../common/autoIncrementHelper').getMaxTokenNum();

let salesControllerLib2 = function () {

    function getItemJson(cartItem) {
        cartItem.gDiscountPercent = ASSIGN_IF_TRUE(cartItem.gDiscountPercent, 0);

        let json = {
            name: cartItem.name,
            category: cartItem.category,
            hsn: cartItem.hsn,
            item_id: cartItem.item_id,
            uniqueItemCode: cartItem.uniqueItemCode,
            ItemType: cartItem.ItemType,
            hsn: cartItem.hsn,
            stockKey: cartItem.stockKey,
            batchId: cartItem.batchId,
            skuName: cartItem.skuName,
            unit: cartItem.unit,
            unitId: cartItem.unitId,
            baseUnitId: cartItem.baseUnitId,
            unitsInfo: cartItem.unitsInfo,
            line: cartItem.line,
            description: cartItem.description,
            quantity_purchased: cartItem.quantity,
            discount_percent: cartItem.discount,
            gDiscountPercent: cartItem.gDiscountPercent,
            purchasePrice: cartItem.purchasePrice,
            sellingPrice: cartItem.price,
            mrp: cartItem.mrp,
            item_location: cartItem.item_location,
            bSPTaxInclusive: cartItem.bSPTaxInclusive,
            bPPTaxInclusive: cartItem.bPPTaxInclusive,
            itemTaxList: [],
            slab: cartItem.slab,
            expiry: cartItem.expiry,
            stock_name: cartItem.stock_name,
            chargesList: [],
            chargesTaxList: [],
            warranty: cartItem.warranty,
            warrantyTerms: cartItem.warrantyTerms,
            total: cartItem.totalWithTax,
            subTotal: cartItem.totalAfterDisAndCharges,
            cost: cartItem.cost,
            profit: cartItem.profit
        };

        // Not assigning directly because, Amt is not required, it can be computed
        // directly
        let totalTax = 0;
        for (let i = 0; i < ARRAY_LENGTH(cartItem.chargesList); i++) {
            totalTax += cartItem.chargesList[i].Amt;
            json
                .chargesList
                .push({
                    name: cartItem.chargesList[i].name,
                    percent: cartItem.chargesList[i].percent
                });
        }
        for (let i = 0; i < ARRAY_LENGTH(cartItem.chargesTaxList); i++) {
            totalTax += cartItem.chargesTaxList[i].Amt;
            json
                .chargesTaxList
                .push({
                    name: cartItem.chargesTaxList[i].name,
                    percent: cartItem.chargesTaxList[i].percent
                });
        }
        json.taxes = {};
        for (let i = 0; i < ARRAY_LENGTH(cartItem.itemTaxList); i++) {
            totalTax += cartItem.itemTaxList[i].Amt;
            json.itemTaxList
                .push({
                    name: cartItem.itemTaxList[i].name,
                    percent: cartItem.itemTaxList[i].percent
                });
            json.taxes[cartItem.itemTaxList[i].name] = cartItem.itemTaxList[i].Amt;
        }
        json.taxes.Total = totalTax;

        if (cartItem.serialnumber) {
            json.serialnumber = cartItem.serialnumber;
        } else {
            json.serialnumber = "";
        }

        json.imeiNumbers = [];
        if (cartItem.imeiNumbers && cartItem.imeiNumbers.length !== 0) {
            json.imeiNumbers = cartItem.imeiNumbers;
        }

        if (cartItem.attributeInfo) {
            json.attributeInfo = cartItem.attributeInfo;
        }

        return json;
    }

    /**
     * maxSaleId
     * write a document
     *  info
     *  taxes
     *  payment
     *  items
     *  status
     */
    //RelaxClientTodo inv and sales timestamp format changed

    this.commitSale = async function (params) {
        let localMemberNames = [
            "items",
            "editSaleId",
            "customer_id",
            "employee_id",
            "refBookingId",
            "salesEmployeeName",
            "comment",
            "payments",
            "total",
            "subtotal",
            "taxes",
            "taxDetailed",
            "cost",
            "profit",
            "quantity",
            "saleOnCreditAmt",
            "timeStamp",
            "checkNo",
            "state_name",
            "roundOffMethod",
            "wcInfo",
            "GSTIN",
            "shippingAddress",
            "globalDiscountInfo",
            "tableNo",
            "invoiceCheckpoint",
            "iPrefix",
            "saleNum",
            "deliveryCharge",
            "deliveryBoy",
            "bHomeDelivery",
            "order_no",
            "vehicle_phNo",
            "vehicleNo",
            "invoice_no",
            "discount",
            't_no',
            'purchaseOrderDocId'
        ];
        for (let i = 0; i < localMemberNames.length; i++) {
            eval("var " + localMemberNames[i] + " = " + JSON.stringify(params[localMemberNames[i]]) + ";");
        }

        try {
            await lockUtils.lockAsync(lockPath, CLONE(lockOptions));
            let maxCouchSquence = autoIncrementHelper.getMaxCouchSquenceId() + 1;
            let sale_id = editSaleId ?
                parseInt(editSaleId.substring(5, editSaleId.length)) :
                maxCouchSquence;
            let num = invoice_no ? invoice_no : editSaleId ?
                saleNum :
                autoIncrementHelper.getMaxSaleId() + 1;
            let invoicePrefix = iPrefix;
            if (!timeStamp) {
                timeStamp = parseInt(moment().format('x'));
            } else {
                timeStamp = parseInt(moment(timeStamp).format('x'));
            }

            function getSalesInfo() {
                return {
                    sale_id: sale_id, //Redundant. Remove if no one is using
                    num: num,
                    invoicePrefix: invoicePrefix,
                    invoiceCheckpoint: invoiceCheckpoint,
                    sale_time: timeStamp,
                    refBookingId: refBookingId,
                    checkNo: checkNo,
                    wcInfo: wcInfo,
                    customer_id: customer_id,
                    employee_id: salesEmployeeName,
                    comment: comment,
                    vehicle_phNo: vehicle_phNo,
                    vehicleNo: vehicleNo,
                    total: parseFloat(total),
                    subtotal: parseFloat(subtotal),
                    taxes: taxes,
                    taxDetailed: taxDetailed,
                    cost: parseFloat(cost),
                    profit: parseFloat(profit),
                    quantity: quantity,
                    deliveryCharge: parseFloat(deliveryCharge),
                    deliveryBoy: deliveryBoy,
                    bHomeDelivery: bHomeDelivery,
                    pending_amount: saleOnCreditAmt,
                    type: 1, //sale = 1 return = 2
                    state_name: state_name,
                    GSTIN: GSTIN,
                    round_off_method: roundOffMethod,
                    shippingDetails: shippingAddress,
                    globalDiscountInfo: globalDiscountInfo,
                    tableNo: tableNo,
                    pProfileId: params.pProfileId,
                    order_no: order_no,
                    discount: discount,
                    t_no: t_no,
                    purchaseOrderDocId: purchaseOrderDocId
                };
            }

            // Input
            // [{key:{quantity:-4}},{key:{quantity:23}},{key:{quantity:4}},{key:{quantity:6}
            // } ,{key:{quantity:0}},{key:{quantity:-2}}], 30 Output
            // [{key:{quantity:23}},{key:{quantity:4}},{key:{quantity:3}}]; Input
            // [{key:{quantity:-4}},{key:{quantity:2}},{key:{quantity:4}},{key:{quantity:6}}
            // , {key:{quantity:0}},{key:{quantity:44}}], 30 Output
            // [{key:{quantity:2}},{key:{quantity:4}},{key:{quantity:6}},{key:{quantity:18}}
            // ] ; Input
            // [{key:{quantity:-4}},{key:{quantity:-2}},{key:{quantity:4}},{key:{quantity:6}
            // } ,{key:{quantity:0}},{key:{quantity:19}}], 30 Output
            // [{key:{quantity:23}},{key:{quantity:4}},{key:{quantity:3}}];

            function getBatachId(batchesInfo, bacthes, key) {
                batchesInfo.locationId = bacthes[key].locationId;
                batchesInfo.batchId = bacthes[key].batchId;
                return batchesInfo;
            }

            /**
             * Checking max token number.
             * If new day started reset to 0.
             * Foe the same day increment by 1;
             * work for TakeAway (Restaurant) | Can be implement for Retail also (if Need)
             */

            /**
             * condition to rest t_no : 0
             * if maxTokenNumber = 0 or undefined it means : no sell
             * if current sale time is > reset time and reset time > last sale time && last sale time > 0 and maxtokennumber > 0
             */
            getSaleTokenNumber = (sale_time) => {
                let lastSaleTime = autoIncrementHelper.getLastSaleTime();
                let resetTime = params.resetTime;
                let lastSTimMls = getMilliSecDuration(lastSaleTime); //last sale time in millisecond from start day i.e today 12:00am
                let currentSTimMls = getMilliSecDuration(sale_time); //current sale time in millisecond from start day i.e today 12:00am

                if ((currentSTimMls >= resetTime && resetTime > lastSTimMls && lastSTimMls && maxTokenNumber) || !maxTokenNumber) {
                    autoIncrementHelper.setMaxTokenNum(0);
                    maxTokenNumber = 0;
                }
                autoIncrementHelper.setLastSaleTime(sale_time);

                maxTokenNumber = ++maxTokenNumber;
                return maxTokenNumber;
            };

            getMilliSecDuration = (paramTime) => {
                let today = new Date();
                if (!paramTime) {
                    paramTime = moment(today).startOf('day').valueOf();
                }
                let startDay = moment(today).startOf('day').valueOf();
                return paramTime - startDay;
            }

            function getStockKeyByItemId(stockKeyArr, quantity, batches) {
                let tempStockKeyArr = stockKeyArr.stock;
                let batchesArr = [];
                let len = Object
                    .keys(stockKeyArr.stock)
                    .length;
                if (Object.keys(stockKeyArr.stock).length === 0) {
                    return;
                }
                let tempQuantity = quantity;

                for (var key in tempStockKeyArr) {
                    var batchesInfo = {};
                    batchesInfo.stockKey = key;
                    if (tempStockKeyArr[key].quantity <= 0) {
                        continue;
                    }

                    delta = tempStockKeyArr[key].quantity - tempQuantity;
                    if (delta < 0) {
                        batchesInfo.quantity = tempStockKeyArr[key].quantity
                    } else {
                        batchesInfo.quantity = tempQuantity;
                    }
                    tempQuantity = tempQuantity - batchesInfo.quantity;
                    getBatachId(batchesInfo, batches, key);
                    batchesArr.push(batchesInfo);
                    if (tempQuantity === 0) {
                        break;
                    };
                };

                if (tempQuantity > 0) {
                    batchesInfo = {};
                    batchesInfo.stockKey = Object.keys(tempStockKeyArr)[0];
                    batchesInfo.quantity = quantity;
                    batchesArr.length = 0;
                    getBatachId(batchesInfo, batches, key);
                    batchesArr.push(batchesInfo);
                };

                return batchesArr;

            };

            function getBomQuantity(itemQ, ingQ, bomFactor) {
                if (!bomFactor || bomFactor <= 0) {
                    bomFactor = 1
                }
                actualBomQuantity = (itemQ * ingQ) / bomFactor;

                return actualBomQuantity;
            }

            let bomInventoryArr = [];
            let bomSaleItems = [];
            async function updateStockOfBomIngredient(cartParamData, saleItemStatus, sale_items) {
                let ingData = cartParamData.bomIngredient_info;
                for (let key in ingData) {
                    let ingCartItem = ingData[key];
                    let item_id = +ingCartItem
                        .ingredientsId
                        .substr(5);
                    var itemQueryParams = {
                        item_id: item_id,
                        stockKey: ''
                    };

                    // ingCartItem = await itemsLib.getThisItemInfo(itemQueryParams);
                    let itemDoc = await couchDBUtils.getDoc('item_' + item_id, mainDBInstance, 'Failed to get  sales Doc. Try Again');
                    ingCartItem = itemDoc.info;
                    ingCartItem.item_id = itemDoc.item_id;
                    // ingCartItem = itemDoc.batches
                    ingCartItem.quantity = getBomQuantity(cartParamData.quantity, ingData[key].orderQuantity, cartParamData.bomFactor);

                    let stockKeyArr = await couchDBUtils.getDoc('inventory_' + item_id, mainDBInstance, 'Failed to get  sales Doc. Try Again');
                    bomInventoryArr.push(stockKeyArr);
                    ingCartItem.unitId = ingData[key].unitId;

                    let itemAvailable; //undefined so that we don't modify this variable in stock
                    let docId = itemsLib.formatInvDocId(item_id);
                    let invTrans = {};
                    if (saleItemStatus[docId] && saleItemStatus[docId].doc) {
                        invTrans = saleItemStatus[docId].doc;
                    }

                    var uniqueDetails = {};
                    uniqueDetails = {
                        serialnumber: ingCartItem.serialnumber,
                        imeiNumbers: ingCartItem.imeiNumbers
                    }

                    if (ingCartItem.is_serialized || ingCartItem.imeiCount !== 0) {
                        ingCartItem.uniqueDetails = [uniqueDetails];
                    }

                    var batchesArr = getStockKeyByItemId(stockKeyArr, ingCartItem.quantity, itemDoc.batches);

                    for (var i = 0; i < batchesArr.length; i++) {
                        ingCartItem.stockKey = batchesArr[i].stockKey;
                        ingCartItem.quantity = batchesArr[i].quantity;
                        ingCartItem.item_location = batchesArr[i].locationId;
                        ingCartItem.batchId = batchesArr[i].batchId;
                        itemsLib.updateStockHelper(commonLib.getParamsForGettingInvTrans(ingCartItem, timeStamp, employee_id, invoicePrefix + num, true), invTrans, itemAvailable, true, 'sale');
                        saleItemStatus[invTrans._id] = {
                            status: 4,
                            doc: invTrans
                        };
                    };

                    bomSaleItems.push(ingCartItem);
                }

                return {
                    bomSaleItems: bomSaleItems,
                    saleItemStatus: saleItemStatus
                };

            }

            let ingSaleItems = {};
            async function getItemsAndTaxesAndStatus() {

                //RelaxClientTodo Make sure Json doesn't change for salesdoc
                let sale_items = [];
                let saleItemStatus = {};
                for (let key in items) {
                    let cartItem = items[key];
                    sale_items.push(getItemJson(cartItem));

                    let itemAvailable; //undefined so that we don't modify this variable in stock
                    let docId = itemsLib.formatInvDocId(cartItem.item_id);
                    let invTrans = {};
                    if (saleItemStatus[docId] && saleItemStatus[docId].doc) {
                        invTrans = saleItemStatus[docId].doc;
                    }
                    var uniqueDetails = {};
                    uniqueDetails = {
                        serialnumber: cartItem.serialnumber,
                        imeiNumbers: cartItem.imeiNumbers,
                        isNew: cartItem.isNew
                    }

                    if (cartItem.is_serialized || cartItem.imeiCount !== 0) {
                        cartItem.uniqueDetails = [uniqueDetails];
                    }

                    if (cartItem.bomIngredient_info) {
                        ingSaleItems = await updateStockOfBomIngredient(cartItem, saleItemStatus, sale_items);
                    }
                    itemsLib.updateStockHelper(commonLib.getParamsForGettingInvTrans(cartItem, timeStamp, employee_id, invoicePrefix + num, true), invTrans, itemAvailable, true, 'sale');
                    saleItemStatus[invTrans._id] = {
                        status: 4,
                        doc: invTrans
                    };
                }

                return {
                    sale_items: sale_items,
                    saleItemStatus: saleItemStatus
                };

            }

            let itemsAndTaxesAndStatus = await getItemsAndTaxesAndStatus();
            let salesDoc = {
                _id: commonLib.formatSaleId(maxCouchSquence),
                sale_id: sale_id

            };
            salesDoc.sales_info = getSalesInfo();

            salesDoc.payments = payments;
            salesDoc.sale_items = itemsAndTaxesAndStatus.sale_items;
            salesDoc.customerApp = params.customerApp;
            salesDoc.status = {
                status: 4,
                inventoryTrans: itemsAndTaxesAndStatus.saleItemStatus,
                customers: {}
            }

            let customerVersion = 1;
            if (params.loyaltyEarned >= 0) {
                salesDoc.sales_info.loyaltyEarned = params.loyaltyEarned;
            }
            if (params.rmPnts >= 0) {
                salesDoc.sales_info.rmPnts = params.rmPnts;
            }
            if (customer_id) {
                let customerDocId = 'customer_' + customer_id;
                salesDoc.status.customers[customerDocId] = {
                    status: 4,
                    doc: {
                        _id: customerDocId,
                        total: total, //RelaxDanger This is rounded off total. get total without manipulation
                        balance: saleOnCreditAmt,
                        timeStamp: timeStamp,
                        v: customerVersion,
                        loyaltyPnts: params.loyaltyPnts
                    },
                    v: customerVersion
                }
            };
            let salesCreateResp;
            let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts'];
            let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];

            workerProcess.setFreeze(true);
            let saleResponse = {};
            if (editSaleId) {
                //sale edit
                var doc = await couchDBUtils.getTransDoc(editSaleId, mainDBInstance, 'Failed to get  sales Doc. Try Again');
                salesDoc._id = doc._id;
                salesDoc._rev = doc._rev;
                if (doc.sales_info.t_no) {
                    salesDoc.sales_info.t_no = doc.sales_info.t_no;
                }
                commonLib.mergeStatus(salesDoc.status, doc, timeStamp, true);

                if (ingSaleItems.bomSaleItems) {
                    for (var i = 0; i < ingSaleItems.bomSaleItems.length; i++) {
                        let tempTimeStamp = parseInt(moment().format('x'));
                        let itemInfo = ingSaleItems.bomSaleItems[i];
                        let key = 'inventory_' + itemInfo.item_id;
                        let tempTransactions = {
                            _id: key,
                            stock: {},
                            transactions2Delete: {},
                            transactions: {}
                        }

                        let bomInventoryInfo = bomInventoryArr[i];
                        let inventoryInfoKey = Object.keys(bomInventoryInfo.transactions);
                        let lastKey = inventoryInfoKey[inventoryInfoKey.length - 1];
                        let lastTransction = bomInventoryInfo.transactions[lastKey];
                        let factor = commonLib.getFactor(itemInfo.unitsInfo, itemInfo.unitId, itemInfo.baseUnitId);
                        let deltaQ;
                        if (inventoryInfoKey.length == 1) {
                            deltaQ = -(itemInfo.quantity * factor);
                            delete tempTransactions.transactions2Delete;
                        } else {
                            deltaQ = (Math.abs(lastTransction.trans_inventory) - (itemInfo.quantity * factor));
                            tempTransactions.transactions2Delete[lastKey] = {};
                            tempTransactions.transactions2Delete[lastKey].trans_stockKey = lastTransction.trans_stockKey;
                        }
                        copyLastTransction = Object.assign({}, lastTransction);
                        copyLastTransction.trans_date = tempTimeStamp;
                        copyLastTransction.trans_inventory = -itemInfo.quantity * factor;
                        var currentTimeStamp = Object.keys(ingSaleItems.saleItemStatus[key].doc.transactions);
                        copyLastTransction.trans_comment = ingSaleItems.saleItemStatus[key].doc.transactions[currentTimeStamp[0]].trans_comment;
                        tempTransactions.transactions[tempTimeStamp + '_' + copyLastTransction.trans_stockKey] = copyLastTransction;
                        tempTransactions.stock[lastTransction.trans_stockKey] = {
                            'quantity': deltaQ,
                            'uniqueDetails': {}
                        };
                        salesDoc.status.inventoryTrans[key].doc = tempTransactions;
                        currentTimeStamp = undefined;
                    }
                }
                saleResponse = {
                    sale_id: sale_id,
                    num: num,
                    timeStamp: timeStamp,
                    t_no: salesDoc.sales_info.t_no
                };
                salesDoc = await commonLib.encodeTransDoc(salesDoc, 'sale', infoFields, itemFields);
                salesCreateResp = await couchDBUtils.update(salesDoc, mainDBInstance, 3, 'Edit Sales Transaction Failed. Try Again');
            } else {
                //sale
                if (params.calledFromTakeaway && process.env.APP_TYPE === 'restaurant') {
                    salesDoc.sales_info.t_no = getSaleTokenNumber(salesDoc.sales_info.sale_time);
                }
                saleResponse = {
                    sale_id: sale_id,
                    num: num,
                    timeStamp: timeStamp,
                    t_no: salesDoc.sales_info.t_no
                };

                salesDoc = await commonLib.encodeTransDoc(salesDoc, 'sale', infoFields, itemFields);

                salesCreateResp = await couchDBUtils.create(salesDoc, mainDBInstance, 3, 'Sales Transaction Failed. Try Again');
                if (!invoice_no) {
                    autoIncrementHelper.incrementSaleId();
                }
                autoIncrementHelper.incrementCouchSquenceId();
            }

            await lockUtils.unlockAsync(lockPath);
            workerProcess.insertTrans({
                parentDocId: salesDoc._id,
                transactions: salesDoc.status.inventoryTrans,
                itemUpdates: {},
                elementUpdates: salesDoc.status.customers
            });
            workerProcess.setFreeze(false);

            // let saleResponse = {
            //     sale_id: sale_id,
            //     num: num,
            //     timeStamp: timeStamp,
            //     t_no: salesDoc.sales_info.t_no
            // };

            return saleResponse;
        } catch (error) {
            await lockUtils.unlockAsync(lockPath);
            workerProcess.setFreeze(false);
            logger.error(error);
            throw error;
        }
    };

    /**
     * rTodo write api validation to check proper data is passed
     * {
     *      items: [], //refer getItemJson for structure
     *      timeStamp: 14511413321,
     *      checkNo: 132321,
     *      customer_id: 1343242,
     *      employee_id: 'admin',
     *      comment: 'hello world',
     *      parentId: 23,
     *      payments: [],
     *      total: 100,
     *      creditAmt: 10
     * }
     *
     * For Sale Return there is no edit
     */
    this.commitSaleReturn = async function (data) {
        try {

            await lockUtils.lockAsync(lockPath, CLONE(lockOptions));
            let returnId = maxReturnId + 1;
            let retPrefix = data.sReturnPrefix;
            if (!data.timeStamp) {
                data.timeStamp = parseInt(moment().format('x'));
            } else {
                let timeStamp = parseInt(data.timeStamp);
                if (timeStamp === NaN) {
                    timeStamp = data.timeStamp;
                }
                data.timeStamp = parseInt(moment(timeStamp).format('x'));
            }

            function getInfo() {
                return {
                    id: returnId,
                    invoicePrefix: retPrefix,
                    time: data.timeStamp,
                    checkNo: data.checkNo,
                    customer_id: data.customer_id,
                    employee_id: data.employee_id,
                    wcInfo: data.wcInfo,
                    comment: data.comment,
                    parentId: data.parentId,
                    total: parseFloat(data.total),
                    subtotal: parseFloat(data.subtotal),
                    taxes: data.taxes,
                    taxDetailed: data.taxDetailed,
                    cost: parseFloat(data.cost),
                    profit: parseFloat(data.profit),
                    quantity: parseFloat(data.quantity),
                    round_off_method: data.round_off_method,
                    GSTIN: data.GSTIN,
                    state_name: data.state_name,
                    globalDiscountInfo: data.globalDiscountInfo,
                    pProfileId: data.pProfileId,
                    purchaseOrderDocId: ''
                };
            }

            function getItemsAndStatus() {

                //RelaxClientTodo Make sure Json doesn't change for salesdoc
                let items = [];
                let inventoryTrans = {};
                for (let key in data.items) {
                    let cartItem = data.items[key];
                    cartItem.totalWithTax = cartItem.computations ? cartItem.computations.totalWithTax : cartItem.total;
                    cartItem.totalAfterDisAndCharges = cartItem.computations ? cartItem.computations.subTotal : cartItem.subTotal;
                    let itemJson = getItemJson(cartItem);
                    itemJson.taxes = cartItem.computations ? cartItem.computations.taxes : cartItem.taxes;
                    items.push(itemJson);

                    let itemAvailable; //undefined so that we don't modify this variable in stock
                    let docId = itemsLib.formatInvDocId(cartItem.item_id);
                    let invTrans = {};
                    if (inventoryTrans[docId] && inventoryTrans[docId].doc) {
                        invTrans = inventoryTrans[docId].doc;
                    }
                    var uniqueDetails = {};
                    if (cartItem.serialnumber || cartItem.imeiNumbers.length) {
                        uniqueDetails = {
                            serialnumber: cartItem.serialnumber,
                            imeiNumbers: cartItem.imeiNumbers
                        }
                    }

                    if (Object.keys(uniqueDetails).length) {
                        cartItem.uniqueDetails = [uniqueDetails];
                    }

                    itemsLib.updateStockHelper(commonLib.getParamsForGettingInvTrans(cartItem, data.timeStamp, data.employee_id, data.sReturnPrefix + returnId, true, true), invTrans, itemAvailable, false, 'saleReturn');
                    inventoryTrans[invTrans._id] = {
                        status: 4,
                        doc: invTrans
                    };
                }

                return {
                    items: items,
                    inventoryTrans: inventoryTrans
                };

            }

            let itemsAndStatus = getItemsAndStatus();

            let doc = {
                _id: commonLib.formatSaleReturnId(returnId),
                id: returnId,
                num: returnId,
                invoicePrefix: retPrefix
            };
            doc.info = getInfo();
            doc.payments = data.payments;
            doc.items = itemsAndStatus.items;

            doc.status = {
                status: 4,
                inventoryTrans: itemsAndStatus.inventoryTrans,
                customers: {},
                parentDoc: {}
            };
            data.loyaltyPnts = saleEx.getLoyaltyPnts(data.total);
            doc.info.rmPnts = data.loyaltyPnts; // to make sure if reject/delete this return he get this point
            if (data.loyaltyPnts) {
                logger.info("Loyalty points duducted :" + data.loyaltyPnts);
            }
            if (data.customer_id) {
                let customerVersion = 1;
                let customerDocId = 'customer_' + data.customer_id;
                doc.status.customers[customerDocId] = {
                    status: 4,
                    doc: {
                        _id: customerDocId,
                        total: -parseFloat(data.total), //RelaxDanger This is rounded off total. get total without manipulation
                        balance: -data.creditAmt,
                        timeStamp: data.timeStamp,
                        v: customerVersion,
                        loyaltyPnts: -data.loyaltyPnts
                    },
                    v: customerVersion
                }
            };

            let parentDocId = commonLib.formatSaleId(data.parentId);
            doc.status.parentDoc[parentDocId] = {
                status: 4,
                doc: {
                    _id: parentDocId,
                    returnDocId: returnId
                }
            };

            if (data.t_no) {
                doc.info.t_no = data.t_no;
            }

            workerProcess.setFreeze(true);
            let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts'];
            let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
            let docForDB = await commonLib.encodeTransDoc(doc, 'saleReturn', infoFields, itemFields);
            await couchDBUtils.create(doc, mainDBInstance, 3, 'Sales Return Transaction Failed. Try Again');
            maxReturnId++;
            await lockUtils.unlockAsync(lockPath);
            workerProcess.insertTrans({
                parentDocId: doc._id,
                transactions: doc.status.inventoryTrans,
                itemUpdates: {},
                elementUpdates: doc.status.customers,
                returnUpdates: doc.status.parentDoc
            });
            workerProcess.setFreeze(false);

            return {
                message: 'Return Successful',
                data: {
                    id: returnId
                }
            };
        } catch (error) {
            await lockUtils.unlockAsync(lockPath);
            workerProcess.setFreeze(false);
            logger.error(error);
            throw {
                error: error
            };
        }
    };

};

module.exports = new salesControllerLib2();