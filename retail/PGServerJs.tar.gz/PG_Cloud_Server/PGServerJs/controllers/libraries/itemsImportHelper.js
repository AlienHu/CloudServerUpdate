'use strict';

let helper = function() {

    const BPromise = require('bluebird');
    const logger = require('../../common/Logger');

    var Config_controller = require('../GlobalConfigurations');
    var couchDBUtils = require('../common/CouchDBUtils');
    const controllerLib = require('./itemsControllerLib');

    function createImportItemcategory(categoryName) {
        return Promise.resolve().then(function() {
            var category = {};
            category.name = categoryName;
            category.description = '';
            return Config_controller.createCategory(category).then(function(resp) {
                // res.send(resp);
                // res.end();
                var caterogyIdValue = {};
                caterogyIdValue.id = resp.id;
                return caterogyIdValue;
            }).catch(function(reason) {
                console.log(reason);
                return reason;
            });
        }).catch(function(err) {
            return Promise.reject(err);
        });
    }

    function createImportItemVariant(variantData) {
        var variantsController = require('../Variants');
        return Promise.resolve().then(function() {
            var variant = {};
            variant.values = [];
            variant.name = variantData.name;
            variant.values.push({
                name: variantData.value
            });
            return variantsController.create(variant).then(function(resp) {
                // res.send(resp);
                // res.end();

                var variantResponse = {
                    variantId: resp.data.var_id,
                    valueId: 1
                }

                return variantResponse;
            }).catch(function(reason) {
                console.log(reason);
                return reason;
            });
        }).catch(function(err) {
            return Promise.reject(err);
        });
    }

    function updateVariantValuesForImport(updateData) {
        var variantsController = require('../Variants');
        return Promise.resolve().then(function() {
            // var variant = {};
            // variant.values = [];
            // variant.name = variantData.name;
            // variant.values.push({
            //     name: variantData.value
            // });
            return variantsController.update(updateData).then(function(resp) {
                // res.send(resp);
                // res.end();
                var caterogyIdValue = {};
                caterogyIdValue.id = resp.id;
                return caterogyIdValue;
            }).catch(function(reason) {
                console.log(reason);
                return reason;
            });
        }).catch(function(err) {
            return Promise.reject(err);
        });
    }

    function createImportItemUnit(unitName) {
        return Promise.resolve().then(function() {
            var unit = {};
            unit.name = unitName;
            unit.description = '';
            return Config_controller.createUnit(unit).then(function(resp) {
                // res.send(resp);
                // res.end();
                var UnitData = {};
                UnitData.id = resp.id;
                return UnitData;
            }).catch(function(reason) {
                console.log(reason);
                return reason;
            });
        });
    }

    function createImportItemDiscount(discount) {
        return Promise.resolve().then(function() {
            var DiscountData = {};
            DiscountData.discount = discount.discount;
            //DiscountData.description = '';
            DiscountData.name = discount.name;
            DiscountData.expiry = '';
            DiscountData.maxunit = '';
            return Config_controller.createDiscount(DiscountData).then(function(resp) {
                // var DiscountData = {};
                DiscountData.id = resp.id;
                return DiscountData;
            }).catch(function(reason) {
                console.log(reason);
                return reason;
            });
        });
    }

    function createImportItemTax(tax) {
        return Promise.resolve().then(function() {
            var taxData = {};
            taxData.percent = tax.percent;
            //DiscountData.description = '';
            taxData.name = tax.name;

            return Config_controller.createTax(taxData).then(function(resp) {
                // var taxData = {};
                taxData.id = resp.id;
                return taxData;
            }).catch(function(reason) {
                console.log(reason);
                return reason;
            });
        });
    }

    /**
     * supplier
     */
    function getSupplierId(name) {
        return Promise.resolve().then(function() {
            if (name in supplierArray) {
                return supplierArray[name];
            } else {
                var response = {};
                response.msg = "supplier doesn't exists";
                var id = null;
                return id;

            }
        }).catch(function(err) {
            //return meaningful error
            logger.error(err);
            return Promise.reject(err);
        });
    }

    /**
     * categories
     * make it case insensitive
     */
    function getCategoryId(name) {
        return Promise.resolve().then(function() {
            if (name in categoryArray) {
                return categoryArray[name];
            } else if (name !== undefined && name !== '') {
                return createImportItemcategory(name).then(function(resp) {
                    var id;
                    console.log(categoryArray);
                    if (resp.err === 'Enter Unique Values') {
                        id = '';
                    } else {
                        id = resp.id;
                    }
                    categoryArray[name] = id;
                    return id;
                });
            }
        }).catch(function(err) {
            //return meaningful error
            logger.error(err);
            return Promise.reject(err);
        });
    }
    //attributesJson
    function getAttributeIdsForImport(attributeData, attributeInfo) {
        return Promise.resolve().then(function() {
            if (attributeData.name.toLowerCase() in attributesJson) {
                var variantId = attributesJson[attributeData.name.toLowerCase()].id;
                for (var value in attributesJson[attributeData.name.toLowerCase()].values) {

                    var bExists = false;
                    for (var attribute in attributesJson[attributeData.name.toLowerCase()].values) {
                        if (attributesJson[attributeData.name.toLowerCase()].values[attribute].name.toLowerCase() === attributeData.value.toLowerCase()) {
                            bExists = true;
                            break;
                        }
                    }
                    var neIndex;
                    var updateAttribute;
                    if (attributesJson[attributeData.name.toLowerCase()].values[value].name && bExists) {
                        var attributeId = value;
                        attributeInfo[variantId] = attributeId;
                    } else {
                        updateAttribute = attributesJson[attributeData.name.toLowerCase()];

                        var index = Object.keys(updateAttribute.values)[Object.keys(updateAttribute.values).length - 1];
                        neIndex = parseInt(index) + 1;
                        updateAttribute.values[neIndex] = {
                            name: attributeData.value
                        };
                        return updateVariantValuesForImport(updateAttribute).then(function(resp) {
                            var id;
                            // console.log(categoryArray);
                            if (resp.error === "Duplicate variant values found (" + attributeData.value + ")") {
                                id = '';
                            } else {
                                id = resp.id;
                            }
                            attributeInfo[updateAttribute.id] = neIndex;
                            attributesJson[attributeData.name.toLowerCase()] = updateAttribute;
                            return attributeInfo;
                        });
                    }
                    return attributeInfo;
                }
            } else {

                return createImportItemVariant(attributeData).then(function(resp) {
                    var id;

                    if (resp.error === 'Variant name ' + attributeData.name + ' already exist') {
                        id = '';
                    } else {
                        id = resp.variantId;
                    }
                    attributeInfo[id] = resp.valueId;
                    return couchDBUtils.getDoc('variant_' + resp.variantId, mainDBInstance, 'Failed to fetch the document variant_' + id).then(function(resp) {
                        attributesJson[attributeData.name.toLowerCase()] = resp;
                        return attributeInfo;
                    });

                });
            }
        }).catch(function(err) {
            //return meaningful error
            logger.error(err);
            return Promise.reject(err);
        });
    }

    function getUnitById(name) {
        return Promise.resolve().then(function() {
            if (name === undefined) {
                name = '';
            }
            if (name in unitArray) {
                return unitArray[name];
            } else {
                return createImportItemUnit(name).then(function(resp) {
                    var id;
                    if (resp.err === 'Enter Unique Values') {
                        id = '';
                    } else {
                        id = resp.id;
                    }
                    unitArray[name] = id;
                    return id;
                });
            }
        }).catch(function(err) {
            //return meaningful error
            logger.error(err);
            return Promise.reject(err);
        });
    }

    function getDiscountById(discount) {
        var discountArray = [];
        var discountData = {};
        if (discount) {
            var discounts = discount.split('-');

            discountData['name'] = discounts[0];
            discountData['discount'] = discounts[1];

        }
        return Promise.resolve().then(function() {
            if (discountData.name + '-' + discountData.discount in DiscountArray) {
                return DiscountArray[discountData.name + '-' + discountData.discount];
            } else if (discountData.name + '-' + discountData.discount !== undefined && discount !== null) {
                return createImportItemDiscount(discountData).then(function(resp) {
                    var id;
                    if (resp.err === 'Enter Unique Values') {
                        id = '';
                    } else {
                        id = resp.id;
                    }
                    DiscountArray[discountData.name + '-' + discountData.discount] = id;
                    return id;
                });
            }
        }).catch(function(err) {
            //return meaningful error
            logger.error(err);
            return Promise.reject(err);
        });
    }
    //var purchaseTaxes = [];
    //var salesTaxes = [];
    function getTaxesById(taxIds) {
        return Promise.resolve().then(function() {
            var taxesArray = [];
            for (var i = 0; i < taxIds.length; i++) {
                if (taxIds[i] in taxArray) {
                    taxesArray.push(taxArray[taxIds[i]]);
                    return taxesArray;
                } else if (taxIds[i] !== undefined) {
                    return createImportItemTax(taxIds[i]).then(function(resp) {
                        var id;
                        if (resp.err === 'Enter Unique Values') {
                            id = '';
                        } else {
                            id = resp.id;
                        }
                        taxesArray.push(id);
                        taxArray[taxIds[i]] = id;
                        return taxesArray;
                    });
                }
            }
        }).catch(function(err) {
            //return meaningful error
            logger.error(err);
            return Promise.reject(err);
        });
    }

    function getTaxIds(taxIds, taxesArray) {
        // taxesArray = [];
        var taxDataArray = [];
        if (taxIds) {
            var taxes = taxIds.split(',');

            for (let i = 0; i < taxes.length; i++) {
                var taxData = {};
                var iTax = taxes[i].split('-');
                taxData['name'] = iTax[0];
                taxData['percent'] = iTax[1];
                taxDataArray.push(taxData);
            }
        }
        return BPromise.each(taxDataArray, function(tax) {

            // for (var i = 0; i < taxIds.length; i++) {
            if (tax.name + '_' + tax.percent in taxArray) {
                taxesArray.push(taxArray[tax.name + '_' + tax.percent]);
            } else if (tax.name + '_' + tax.percent !== undefined) {
                return createImportItemTax(tax).then(function(resp) {
                    var id;
                    if (resp.err === 'Enter Unique Values') {
                        id = '';
                    } else {
                        id = resp.id;
                    }
                    taxesArray.push(id);
                    taxArray[tax.name + '_' + tax.percent] = id;
                });
            }
            // }
        });
    }

    function getCategoryId2(name) {
        return new Promise(function(resolve, reject) {

            if (name in categories) {
                resolve(categories[name]);
                return;
            } else {
                createImportItemcategory(name).then(function(resp) {
                    var id;
                    if (resp.err === 'Enter Unique Values') {
                        id = '';
                    } else {
                        id = resp.id;
                    }
                    categories[name] = id;
                    resolve(id);
                    return;
                }).catch(function(err) {
                    //return meaningful error
                    logger.error(err);
                    reject(err);
                    return;
                });
            }

        });
    }

    function formatImportItemData(ItemJsonData) {
        // ItemJsonData.initialStock = {};
        if (ItemJsonData.discount !== '' && ItemJsonData.discount !== undefined && ItemJsonData.discount !== 'undefined') {
            ItemJsonData.initialStock.discount = ItemJsonData.discount; //parseFloat(ItemJsonData.discount);

        }

        if (ItemJsonData.purchaseUnit === undefined || ItemJsonData.purchaseUnit === 'undefined') {
            ItemJsonData.purchaseUnit = '';
        }
        if (ItemJsonData.saleUnit === undefined || ItemJsonData.saleUnit === 'undefined') {
            ItemJsonData.saleUnit = '';
        }
        if (ItemJsonData.quantity !== '') {
            ItemJsonData.initialStock.quantity = parseFloat(ItemJsonData.quantity);

        }

        if (ItemJsonData.hsn === undefined || ItemJsonData.hsn === 'undefined') {
            ItemJsonData.hsn = '';
        }
        ItemJsonData.initialStock.expiry = ItemJsonData.expiry;
        delete ItemJsonData.expiry;

        ItemJsonData.initialStock.mrp = parseFloat(ItemJsonData.mrp);
        // delete ItemJsonData.mrp;
        ItemJsonData.initialStock.sellingPrice = parseFloat(ItemJsonData.sellingPrice);
        // delete ItemJsonData.sellingPrice;
        ItemJsonData.initialStock.purchasePrice = parseFloat(ItemJsonData.purchasePrice);
        // delete ItemJsonData.purchasePrice;

        if (ItemJsonData.batchId !== '' && ItemJsonData.batchId !== undefined) {
            ItemJsonData.initialStock.batchId = ItemJsonData.batchId;
            delete ItemJsonData.batchId;
        } else {
            delete ItemJsonData.batchId;
        }

        ItemJsonData.item_number = ItemJsonData.item_number ? ItemJsonData.item_number : null;
        ItemJsonData.purchasePrice = parseFloat(ItemJsonData.purchasePrice);
        ItemJsonData.sellingPrice = parseFloat(ItemJsonData.sellingPrice);
        ItemJsonData.mrp = parseFloat(ItemJsonData.mrp);
        ItemJsonData.is_serialized = ItemJsonData.is_serialized == 'true' ? true : false;
        ItemJsonData.hasExpiryDate = ItemJsonData.hasExpiryDate == 'true' ? true : false;
        ItemJsonData.hasBatchNumber = ItemJsonData.hasBatchNumber == 'true' ? true : false;
        ItemJsonData.bSPTaxInclusive = ItemJsonData.bSPTaxInclusive == 'true' ? true : false;
        ItemJsonData.bPPTaxInclusive = ItemJsonData.bPPTaxInclusive == 'true' ? true : false;
        ItemJsonData.bOTG = ItemJsonData.bOTG == 'true' ? true : false;
        //conversionFactor is not there now
        ItemJsonData.conversionFactor = parseInt(ItemJsonData.conversionFactor);
        ItemJsonData.employeeId = ItemJsonData.employeeId;

        ItemJsonData.brandId = ItemJsonData.brandId ? parseInt(ItemJsonData.brandId) : null;
        ItemJsonData.description = ItemJsonData.description;
        ItemJsonData.reorderLevel = ItemJsonData.reorderLevel === '' ? 0 : parseInt(ItemJsonData.reorderLevel);
        ItemJsonData.imeiCount = parseInt(ItemJsonData.imeiCount);
        ItemJsonData.reorderQuantity = (ItemJsonData.reorderQuantity === '' || ItemJsonData.reorderQuantity === 'null' || ItemJsonData.reorderQuantity === null || ItemJsonData.reorderQuantity === undefined) ? 0 : parseInt(ItemJsonData.reorderQuantity);

        ItemJsonData.loyalityId = ItemJsonData.loyalityId ? parseInt(ItemJsonData.loyalityId) : null;
        return ItemJsonData;
    }

    async function getItemIdForBatchItem(name, category, item_number, mainDBInstance) {
        let allItems = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
        for (var i = 0; i < allItems.length; i++) {
            let categoryId = await getCategoryId(category);
            if (allItems[i].doc.info.name === name && allItems[i].doc.info.categoryId === categoryId && allItems[i].doc.info.item_number === item_number) {
                return await allItems[i].doc.item_id;
            }
        }
    }

    // async function addBatchesInfoToItems(itemData, allBatches, mainDBInstance) {
    //     itemData.uniqueDetails = [];
    //     // for (let i = 0; i < allBatches.length; i++) {

    //     //     if (allBatches[i].name === itemData.name && allBatches[i].category === itemData.category && allBatches[i].item_number === itemData.item_number) {
    //     //         //clubing unique item rows into one
    //     //         var uniqueItem = {};
    //     //         var uniqueDetails = [];
    //     //         if (itemData.is_serialized || itemData.imeiCount !== 0) {
    //     //             uniqueItem.serialnumber = allBatches[i].serialnumber;
    //     //             uniqueItem.imeiNumbers = allBatches[i].imeiNumbers;
    //     //             // uniqueDetails.push(uniqueItem);
    //     //             itemData.uniqueDetails.push(uniqueItem);
    //     //         }
    //     //     }
    //     // }
    //     // let item_id;
    //     let itemBatchToUpdate = {};
    //     itemBatchToUpdate.attributeInfo = [];
    //     for (let j = 0; j < allBatches.length; j++) {
    //         allBatches[j]['attributeInfo'] = allBatches[j]['attributeInfo\r'] ? allBatches[j]['attributeInfo\r'] : (allBatches[j]['attributeInfo'] ? allBatches[j]['attributeInfo'] : []);
    //         delete allBatches[j]['attributeInfo\r'];

    //         if (allBatches[j].attributeInfo) {
    //             var variantsArray = allBatches[j].attributeInfo.split(',');
    //             for (var k = 0; k < variantsArray.length; k++) {
    //                 var attributesArray = variantsArray[k].split('-');
    //                 var attributeData = {
    //                     name: attributesArray[0],
    //                     value: attributesArray[1]
    //                 }
    //                 itemBatchToUpdate.attributeInfo = await getAttributeIdsForImport(attributeData, itemBatchToUpdate.attributeInfo);
    //                 console.log(attributes);
    //             }
    //         }
    //         //get item id
    //         itemBatchToUpdate.item_id = await getItemIdForBatchItem(allBatches[j].name, allBatches[j].category, allBatches[j].item_number, mainDBInstance);
    //         itemBatchToUpdate.newQuantity = allBatches[j].quantity;
    //         itemBatchToUpdate.batchId = allBatches[j].batchId;
    //         itemBatchToUpdate.comment = allBatches[j].comment;
    //         itemBatchToUpdate.uniqueDetails = {};
    //         itemBatchToUpdate.uniqueDetails.serialnumber = allBatches[j].serialNumber;
    //         itemBatchToUpdate.uniqueDetails.imeiNumbers = allBatches[j].imeiNumbers;
    //         itemBatchToUpdate.stockKey = controllerLib.formatStockKey(itemBatchToUpdate.item_id, itemBatchToUpdate.batchId, itemBatchToUpdate.attributeInfo)
    //         console.log(itemBatchToUpdate);
    //         itemData.batches = [];
    //         itemData.batches[itemBatchToUpdate.stockKey] = itemBatchToUpdate;
    //     }

    //     return itemData;
    // }

    async function addBatchesInfoToItems(itemData, allBatches, mainDBInstance) {
        itemData.uniqueDetails = [];

        let itemBatchToUpdate = {};

        itemBatchToUpdate.attributeInfo = {};
        for (let j = 0; j < allBatches.length; j++) {

            allBatches[j]['attributeInfo'] = allBatches[j]['attributeInfo\r'] ? allBatches[j]['attributeInfo\r'] : (allBatches[j]['attributeInfo'] ? allBatches[j]['attributeInfo'] : []);
            delete allBatches[j]['attributeInfo\r'];

            if (allBatches[j].attributeInfo && itemData.hasVariants === 'true') {
                itemBatchToUpdate.skuName = '';
                var variantsArray = allBatches[j].attributeInfo.length !== 0 ? allBatches[j].attributeInfo.split(',') : [];
                for (var k = 0; k < variantsArray.length; k++) {
                    var attributesArray = variantsArray[k].split('-');
                    var attributeData = {
                        name: attributesArray[0],
                        value: attributesArray[1]
                    }
                    itemBatchToUpdate.attributeInfo = await getAttributeIdsForImport(attributeData, itemBatchToUpdate.attributeInfo);

                    itemBatchToUpdate.skuName += "/" + attributeData.value;
                }
            }
            itemData.uniqueDetails = [];
            if (itemData.is_serialized || itemData.imeiCount !== 0) {
                for (let i = 0; i < allBatches.length; i++) {

                    if (allBatches[i].name === itemData.name && allBatches[i].category === itemData.category && allBatches[i].item_number === itemData.item_number) {
                        //clubing unique item rows into one
                        var uniqueItem = {};
                        uniqueItem.imeiNumbers = [];
                        var uniqueDetails = [];
                        if (itemData.is_serialized || itemData.imeiCount !== 0) {
                            uniqueItem.serialnumber = allBatches[i].serialnumber;
                            uniqueItem.imeiNumbers = allBatches[i].imeiNumbers.split(',');
                            // uniqueDetails.push(uniqueItem);
                            itemData.uniqueDetails.push(uniqueItem);
                        }
                    }
                }
            }
            //get item id
            // itemBatchToUpdate.item_id = await getItemIdForBatchItem(allBatches[j].name, allBatches[j].category, allBatches[j].item_number, mainDBInstance);
            itemBatchToUpdate.quantity = allBatches[j].quantity;
            itemBatchToUpdate.batchId = allBatches[j].batchId;
            itemBatchToUpdate.comment = allBatches[j].comment;
            itemBatchToUpdate.uniqueDetails = {};
            itemBatchToUpdate.uniqueDetails.serialnumber = allBatches[j].serialNumber;
            itemBatchToUpdate.uniqueDetails.imeiNumbers = allBatches[j].imeiNumbers;
            itemBatchToUpdate.purchasePrice = allBatches[j].purchasePrice;
            itemBatchToUpdate.mrp = allBatches[j].mrp;
            itemBatchToUpdate.sellingPrice = allBatches[j].sellingPrice;
            itemBatchToUpdate.expiry = allBatches[j].expiry;
            // itemBatchToUpdate.stockKey = controllerLib.formatStockKey(itemBatchToUpdate.item_id, itemBatchToUpdate.batchId, itemBatchToUpdate.attributeInfo)
            console.log(itemBatchToUpdate);
            itemData.initialStock = [];
            itemData.initialStock.push(itemBatchToUpdate);
        }

        return await itemData;
    }

    var nextChunkIndex = 0;

    function readFileDataInChunks(requestData, startIdx, size) {
        var dataChunk = [];
        nextChunkIndex = startIdx + size;
        for (var i = startIdx; i < nextChunkIndex; i++) {
            dataChunk.push(requestData[i]);
        }
        return dataChunk;
    }

    function formIntialBatchData(ItemJsonData, batchesData, mainDBInstance) {
        return addBatchesInfoToItems(ItemJsonData, batchesData, mainDBInstance).then(function(resp) {
            var itemsBatchesJsonData = formatImportItemData(resp);
            return itemsBatchesJsonData;
        }).catch(function(err) {
            logger.error(err);
            throw "Error :" + err;
        });
    }

    function createItemsFromArrayRecursively(requestData, errResponseArray, succResponseArray, session_user, parentInstance, mainDBInstance) {
        var batchesData = requestData.batchesFile;
        var itemsArray = requestData.file;
        return BPromise.each(itemsArray, function(ItemJsonData) {

            ItemJsonData.employeeId = session_user;
            var itemBatchInfo;

            if (!ItemJsonData.initialStock && !batchesData) {
                ItemJsonData = formatImportItemData(ItemJsonData);

            }
            var props = {};
            if (batchesData) {
                props.ItemJsonData = formIntialBatchData(ItemJsonData, batchesData, mainDBInstance);
            }
            props.category = getCategoryId(ItemJsonData.category);
            props.sale_unit = getUnitById(ItemJsonData.saleUnit);
            props.purchase_unit = getUnitById(ItemJsonData.purchaseUnit);
            props.discount = ItemJsonData.initialStock ? getDiscountById(ItemJsonData.initialStock.discount) : getDiscountById(ItemJsonData.discount);
            // props.initial_discount = getDiscountById(ItemJsonData.initialStock.discount);
            var purchaseTaxIds = [];
            props.purchase_tax = getTaxIds(ItemJsonData.purchaseTaxes, purchaseTaxIds);
            var salesTaxIds = [];
            props.sales_tax = getTaxIds(ItemJsonData.salesTaxes, salesTaxIds);
            props.supplier = getSupplierId(ItemJsonData.supplier);
            return BPromise.props(props).then(function(resp) {
                console.log(resp);
                ItemJsonData = resp.ItemJsonData ? resp.ItemJsonData : ItemJsonData;
                ItemJsonData.categoryId = resp.category;
                ItemJsonData.purchaseUnitId = resp.purchase_unit;
                ItemJsonData.sellingUnitId = resp.sale_unit;
                ItemJsonData.discountId = resp.discount;
                ItemJsonData.initialStock.discountId = resp.discount; //resp.initial_discount;
                ItemJsonData.purchaseTaxes = purchaseTaxIds;
                ItemJsonData.salesTaxes = salesTaxIds;
                ItemJsonData.supplier_id = resp.supplier; //supplier_id
                // var intitialStock = [];
                // if (ItemJsonData.hasBatchNumber) {
                //     ItemJsonData.initialStock.batchId = 'initialImport';
                // }
                // intitialStock.push(ItemJsonData.initialStock);
                // delete ItemJsonData.initialStock;

                // ItemJsonData.initialStock = intitialStock;
                ItemJsonData.expiry = ItemJsonData.initialStock.expiry;

                return parentInstance.createItem(ItemJsonData).then(function(resp) {
                    var response = {
                        error: null,
                        response: resp
                    };
                    succResponseArray.push(response);
                    return;
                }).catch(function(err) {
                    var errorMsg;
                    errorMsg = err;

                    var errResponse = {
                        error: errorMsg,
                        response: null
                    };
                    errResponseArray.push(errResponse);
                    return;
                });
            }).catch(function(err) {
                console.log(err);
            });

        });

    }
    var categoryArray = {};
    var DiscountArray = {};
    var unitArray = {};
    var taxArray = {};
    var brandArray = {};
    var supplierArray = {};
    var attributesJson = {};
    var mainDBInstance;
    this.importItems = function(requestData, user, mainDB, parentInstance) {
        mainDBInstance = mainDB;
        var session_user = user;
        var errResponseArray = [];
        var succResponseArray = [];

        var props = {};
        props.categories = Config_controller.getAllConfigDocsByType('category');
        props.units = Config_controller.getAllConfigDocsByType('unit');
        props.discounts = Config_controller.getAllConfigDocsByType('discount');
        props.taxes = Config_controller.getAllConfigDocsByType('tax');
        props.brands = Config_controller.getAllConfigDocsByType('brand');
        props.suppliers = couchDBUtils.getAllDocsByType('supplier', mainDBInstance);
        props.variants = couchDBUtils.getAllDocsByType('variant', mainDBInstance);

        // props.createAllTaxes = itemTaxesModel.createAllTaxes(id, data.salesTaxes, data.purchaseTaxes);

        //return BPromise.props(props);

        return BPromise.props(props).then(function(resp) {
            for (var i = 0; i < resp.categories.length; i++) {
                categoryArray[resp.categories[i].doc.name] = resp.categories[i].doc.id;
            }
            for (var j = 0; j < resp.units.length; j++) {
                unitArray[resp.units[j].doc.name] = resp.units[j].doc.id;
            }
            for (var k = 0; k < resp.discounts.length; k++) {
                DiscountArray[resp.discounts[k].doc.name + '-' + resp.discounts[k].doc.discount] = resp.discounts[k].doc.id;
            }
            for (var l = 0; l < resp.taxes.length; l++) {
                taxArray[resp.taxes[l].doc.name + '_' + resp.taxes[l].doc.percent] = resp.taxes[l].doc.id;
            }
            for (var m = 0; m < resp.brands.length; m++) {
                brandArray[resp.brands[m].doc.name] = resp.brands[m].doc.id;
            }

            for (var n = 0; n < resp.suppliers.length; n++) {
                supplierArray[resp.suppliers[n].doc.company_name] = resp.suppliers[n].doc.person_id;
            }

            for (var o = 0; o < resp.variants.length; o++) {
                attributesJson[resp.variants[o].doc.name] = resp.variants[o].doc;
            }
            while (nextChunkIndex < requestData.file.length) {
                var endOfChunk = requestData.file.length < (nextChunkIndex + 10) ? (requestData.file.length - nextChunkIndex) : 10;
                var itemsChunk = readFileDataInChunks(requestData.file, nextChunkIndex, endOfChunk);
                // var batchesChunk = readFileDataInChunks(requestData.batchesFile, nextChunkIndex, 10);

                var fileDataChunk = {
                    file: itemsChunk,
                    batchesFile: requestData.batchesFile
                }

                importChunkData(fileDataChunk, errResponseArray, succResponseArray, session_user, parentInstance, mainDBInstance);
            }

            nextChunkIndex = 0;

        });
    }

    function importChunkData(fileDataChunk, errResponseArray, succResponseArray, session_user, parentInstance, mainDBInstance) {
        return createItemsFromArrayRecursively(fileDataChunk, errResponseArray, succResponseArray, session_user, parentInstance, mainDBInstance).then(function() {
            return [errResponseArray, succResponseArray];
        }).catch(function(err) {
            logger.error(err);
            return [errResponseArray, succResponseArray];
        });
    }
};

module.exports = new helper();