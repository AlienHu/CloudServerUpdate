"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * encrypt and decryption using crypto
 * Author : Linto thomas
 * Created : 28-Mar-18
 * https://nodejs.org/api/crypto.html#crypto_class_cipher
 */
const crypto = require("crypto");
const logger = require("../../common/Logger");
const alg = 'aes192';
const licenceHelper_1 = require("../../licencer/licenceHelper");
function encrypt(data, password) {
    if (!password) {
        password = licenceHelper_1.getServerSerialNumber();
    }
    logger.info("*** crypto.encrypt");
    let enSMSInfo = JSON.stringify(data);
    let cipher = crypto.createCipher(alg, password);
    let encrypted = cipher.update(enSMSInfo, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}
exports.encrypt = encrypt;
function decrypt(data, password) {
    if (!password) {
        password = licenceHelper_1.getServerSerialNumber();
    }
    logger.info("*** crypto.decrypt ");
    let decipher = crypto.createDecipher(alg, password);
    let decrypted = decipher.update(data, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return JSON.parse(decrypted);
}
exports.decrypt = decrypt;
//# sourceMappingURL=crypto.js.map