"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const reportsLib = require("./reportsLib");
const moment = require("moment");
const couchDBUtils = require("../common/CouchDBUtils");
const logger = require("../../common/Logger");
var path = require('path');
var templateDir = path.resolve(__dirname, '../../templates');
var EmailTemplate = require('email-templates').EmailTemplate;
var templateReport = new EmailTemplate(path.join(templateDir, 'e-reportEmailTemplate'));
let settings = {};
const coredb = couchDBUtils.getCoreCouchDB();
/**
 *
 * @param type daily,weekly,monthly
 * @param emailArr ['linto.thomas.17@gmail.com',...]
 * @param weekDayArr [0,1,...6],[5,6]
 */
function sendReport(type, emailArr, applicationSettings, weekDayArr) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            settings = yield couchDBUtils.getDoc('profitGuruApplicationSettings_', coredb);
            let now = moment();
            let startDate;
            let endDate;
            switch (type) {
                case 'daily':
                    now.subtract(1, 'days').startOf('day');
                    break;
                case 'monthly':
                    now.subtract(1, 'months').startOf('day');
                    break;
                case 'weekly':
                    now.subtract(1, 'weeks').startOf('day');
                    break;
                default:
                    logger.error("A invalid type in sendReports " + type);
            }
            logger.info("Auto report start date : " + now.toString());
            startDate = now.format('x');
            endDate = moment().format('x');
            yield exports.getDailyReport('all_time', 'all_sales_info', startDate, endDate, emailArr);
        }
        catch (error) {
            logger.error("Error from sendReports", error);
            throw error;
        }
    });
}
exports.sendReport = sendReport;
exports.getDailyReport = function (view, docName, start, end, emailArr) {
    return __awaiter(this, void 0, void 0, function* () {
        let dailyReport = yield reportsLib.getReport(docName, start, end, view);
        return formatData(dailyReport, emailArr, start, end);
    });
};
exports.getSaleId = function (sales_info, invoicePrefix, invoiceRetPrefix) {
    var saleID = "";
    if (sales_info.num)
        saleID = invoicePrefix + sales_info.num;
    if (!saleID) {
        saleID = invoicePrefix + sales_info.sale_id;
    }
    if (!sales_info.sale_id) {
        if (invoicePrefix && sales_info.num) {
            saleID = invoicePrefix + sales_info.id;
        }
        else {
            saleID = invoiceRetPrefix + sales_info.id;
        }
    }
    return saleID;
};
exports.getFormattedDateForReportDisplay = function (date) {
    return formatDate(date, 0, settings.dateTime.dateformat);
};
function formatDate(date, startEnd, formatString) {
    var formattedDate = '';
    if (!date) {
        date = moment().format('YYYY-DD-MM');
    }
    var parsedDate = parseInt(date);
    if (isNaN(parsedDate)) {
        date = date.toString();
    }
    else {
        //It is Unix TimeStamp. So convert to integer
        date = parsedDate;
    }
    var dateMoment = moment(new Date(date));
    if (dateMoment.isValid()) {
        if (startEnd === 1) {
            dateMoment = dateMoment.endOf('day');
        }
        else if (startEnd === -1) {
            dateMoment = dateMoment.startOf('day');
        }
        formattedDate = dateMoment.format(formatString);
        if (formatString === 'x') {
            formattedDate = parseInt(formattedDate);
        }
    }
    return formattedDate;
}
function formatData(resp, emailArr, startDate, endDate) {
    return __awaiter(this, void 0, void 0, function* () {
        let docs = resp.docs;
        let employeesDictionary = resp.employees;
        let itemsDictionary = resp.items;
        let customersDictionary = resp.customers;
        let categoriesDictionary = resp.categories;
        let invoiceCurrentCheckpoint = resp.invoiceCurrentCheckpoint;
        var summaryDataArray = [];
        var detailsDataArray = [];
        var overallSummaryData = {};
        overallSummaryData.total = 0;
        overallSummaryData.subtotal = 0;
        overallSummaryData.tax = 0;
        overallSummaryData.cost = 0;
        overallSummaryData.profit = 0;
        overallSummaryData.taxes = {
            CGST: 0,
            SGST: 0,
            IGST: 0,
            CESS: 0,
            Total: 0
        };
        var taxPercentFilter = {};
        var returnsStartingIndex = -1;
        for (var i = 0; i < docs.length; i++) {
            var summaryData = {};
            var doc = docs[i];
            var sales_info = doc.sales_info;
            if (!sales_info) {
                sales_info = doc.info;
            }
            var timeStamp = sales_info.sale_time;
            if (!timeStamp) {
                timeStamp = sales_info.time;
            }
            var invoicePrefix = '';
            var invoiceRetPrefix = '';
            if (!sales_info.invoicePrefix) {
                invoicePrefix = settings.invoiceDefaultCheckpoint.prefix;
                invoiceRetPrefix = settings.invoiceDefaultCheckpoint.sReturnPrefix;
            }
            else {
                invoicePrefix = sales_info.invoicePrefix;
                invoiceRetPrefix = sales_info.invoicePrefix;
            }
            var saleID = exports.getSaleId(sales_info, invoicePrefix, invoiceRetPrefix);
            summaryData.prefix = invoicePrefix;
            summaryData.id = doc.sale_id ? doc.sale_id : sales_info.id;
            summaryData.sale_id = saleID;
            summaryData.num = sales_info.num;
            summaryData.invoiceCheckpoint = sales_info.invoiceCheckpoint ? sales_info.invoiceCheckpoint : 1;
            summaryData._id = doc._id;
            summaryData.gstin = sales_info.GSTIN ? sales_info.GSTIN : '';
            summaryData.bReject = doc.bRejected ? doc.bRejected : false;
            summaryData.bReturned = false;
            if (sales_info.bHomeDelivery) {
                summaryData.bHomeDelivery = sales_info.bHomeDelivery;
            }
            if (doc.mods && doc.mods.length) {
                summaryData.bReturned = true;
            }
            summaryData.sale_date = exports.getFormattedDateForReportDisplay(timeStamp);
            var customerID = sales_info.customer_id;
            summaryData.customer = '';
            if (customerID) {
                if (customersDictionary.hasOwnProperty(customerID)) {
                    var checkCompanyName = customersDictionary[customerID].company_name ? customersDictionary[customerID].company_name : '';
                    var checkLastName = customersDictionary[customerID].last_name ? customersDictionary[customerID].last_name : '';
                    summaryData.customer = checkCompanyName + ' ' + customersDictionary[customerID].first_name + ' ' + checkLastName;
                }
            }
            else if (sales_info.wcInfo && sales_info.wcInfo.name) {
                summaryData.customer = sales_info.wcInfo.name;
            }
            var employeeID = sales_info.employee_id;
            summaryData.employee = '';
            if (employeeID) {
                if (employeesDictionary.hasOwnProperty(employeeID)) {
                    summaryData.employee = employeesDictionary[employeeID].first_name + ' ' + employeesDictionary[employeeID].last_name;
                }
            }
            summaryData.comment = '';
            if (sales_info.comment)
                summaryData.comment = sales_info.comment;
            summaryData.payment_type = '';
            if (Array.isArray(doc.payments)) {
                doc.payments.forEach(function (payment) {
                    summaryData.payment_type += payment.payment_type + ' ' + payment.payment_amount + ', ';
                });
            }
            summaryData.payment_type = summaryData.payment_type.substring(0, summaryData.payment_type.length - 2);
            summaryData.payments = doc.payments;
            summaryData.quantity = 0;
            summaryData.cost = 0;
            summaryData.sub = 0;
            summaryData.tax = 0;
            summaryData.details = [];
            summaryData.taxes = {
                CGST: 0,
                SGST: 0,
                IGST: 0,
                CESS: 0,
                Total: 0
            };
            var reverseSign = 1;
            var items = docs[i].sale_items;
            if (!items) {
                returnsStartingIndex = returnsStartingIndex === -1 ? i : returnsStartingIndex;
                reverseSign = returnsStartingIndex === 0 ? 1 : -1;
                items = docs[i].items;
            }
            if (doc.bRejected) {
                reverseSign = 0;
            }
            // summaryData.taxPercentFilter = {};
            var calculations = {};
            for (var k = 0; k < items.length; k++) {
                var itemInfo = items[k];
                var itemID = itemInfo.item_id;
                var itemComputeInfo = computeItem(itemInfo, 1, calculations);
                summaryData.quantity += itemComputeInfo.quantity;
                summaryData.sub += itemComputeInfo.subTotal;
                summaryData.cost += itemComputeInfo.cost;
                summaryData.tax += itemComputeInfo.tax;
                for (var tax in summaryData.taxes) {
                    summaryData.taxes[tax] += itemComputeInfo.taxes[tax];
                }
                var itemDetails = {};
                itemDetails.name = itemsDictionary[itemID].info.name;
                itemDetails.category = categoriesDictionary[itemsDictionary[itemID].info.categoryId];
                itemDetails.serialnumber = itemInfo.serialnumber;
                itemDetails.imeiNumbers = itemInfo.imeiNumbers;
                itemDetails.description = itemInfo.description;
                itemDetails.quantity = parseFloat(itemComputeInfo.quantity.toFixed(2));
                summaryData.details.push(itemDetails);
                detailsDataArray.push(itemDetails);
            }
            for (var taxP in calculations) {
                var subTotal = calculations[taxP].subTotal;
                delete calculations[taxP].subTotal;
                calculations[taxP]["Sale Id"] = summaryData.sale_id;
                calculations[taxP]["Date"] = summaryData.sale_date;
                calculations[taxP]["GSTIN"] = sales_info.GSTIN ? sales_info.GSTIN : "";
                calculations[taxP]["Sub Total"] = subTotal;
                if (taxP in taxPercentFilter) {
                    taxPercentFilter[taxP].push(calculations[taxP]);
                }
                else {
                    taxPercentFilter[taxP] = [calculations[taxP]];
                }
            }
            summaryData.quantity = summaryData.quantity.toFixed(0); // $filter('decimalsLimitFilter')(summaryData.quantity, 0).toString();
            summaryData.cost = parseFloat(summaryData.cost.toFixed(2)); //utilsSvc.numberRoundOffFormat(summaryData.cost, 'none');
            summaryData.total = parseFloat(add(summaryData.sub, summaryData.tax).toFixed(2)); //utilsSvc.numberRoundOffFormat(computeUtils.add(summaryData.sub, summaryData.tax), sales_info.round_off_method);
            summaryData.deliveryCharge = sales_info.deliveryCharge ? sales_info.deliveryCharge : 0;
            summaryData.total = parseFloat(add(summaryData.total, summaryData.deliveryCharge).toFixed(2)); // utilsSvc.numberRoundOffFormat(computeUtils.add(summaryData.total, summaryData.deliveryCharge), sales_info.round_off_method);
            summaryData.tax = parseFloat(summaryData.tax.toFixed(2)); // utilsSvc.numberRoundOffFormat(summaryData.tax, 'none');
            summaryData.sub = parseFloat(summaryData.sub.toFixed(2)); // utilsSvc.numberRoundOffFormat(summaryData.sub, 'none');
            if (doc.sale_id) {
                summaryData.profit = parseFloat(subtract(summaryData.sub, summaryData.cost).toFixed(2));
                ; // utilsSvc.numberRoundOffFormat(computeUtils.subtract(summaryData.sub, summaryData.cost), 'none');
            }
            else {
                summaryData.profit = "---";
            }
            for (var taxKey in summaryData.taxes) {
                summaryData.taxes[taxKey] = parseFloat(summaryData.taxes[taxKey].toFixed(2)); // utilsSvc.numberRoundOffFormat(summaryData.taxes[taxKey], 'none');
                overallSummaryData.taxes[taxKey] += summaryData.taxes[taxKey] * reverseSign;
            }
            summaryData.taxes['Total'] = summaryData.tax;
            overallSummaryData.subtotal += summaryData.sub * reverseSign;
            overallSummaryData.tax += summaryData.tax * reverseSign;
            overallSummaryData.cost += summaryData.cost * reverseSign;
            overallSummaryData.total += summaryData.total * reverseSign;
            summaryDataArray.push(summaryData);
        }
        for (var taxKey in overallSummaryData.taxes) {
            overallSummaryData.taxes[taxKey] = parseFloat(overallSummaryData.taxes[taxKey].toFixed(2)); // utilsSvc.numberRoundOffFormat(overallSummaryData.taxes[taxKey], 'none');
        }
        overallSummaryData.taxes['Total'] = parseFloat(overallSummaryData.taxes[taxKey].toFixed(2)); // utilsSvc.numberRoundOffFormat(overallSummaryData.tax, 'none');
        overallSummaryData.total = overallSummaryData.total.toString();
        overallSummaryData.profit = subtract(overallSummaryData.subtotal, overallSummaryData.cost).toString();
        overallSummaryData.subtotal = overallSummaryData.subtotal.toString();
        overallSummaryData.tax = overallSummaryData.tax.toString();
        overallSummaryData.cost = overallSummaryData.cost.toString();
        var data = {};
        data.title = "Sales Report";
        // data.subtitle = start_date + '-' + end_date;
        // data.headers = headersJson;
        // data.header_width = header_width;
        // data.start = start_date;
        // data.end = end_date;
        // data.editable = editable;
        data.summ_data = summaryDataArray;
        data.details_data = detailsDataArray;
        data.overall_summary_data = overallSummaryData;
        // data.export_excel = export_excel;
        data.taxPercentFilter = taxPercentFilter;
        startDate = parseInt(startDate);
        endDate = parseInt(endDate);
        var locals = {
            userInfo: {
                name: settings.ownersInfo.company,
                phone: settings.ownersInfo.phone,
                address: settings.ownersInfo.address,
                email: settings.ownersInfo.email,
                website: settings.ownersInfo.website,
                fax: settings.ownersInfo.fax,
                location: settings.ownersInfo.location,
                company: settings.ownersInfo.company
            },
            reportParams: {
                start: moment(startDate).format('llll'),
                end: moment(endDate).format('llll'),
                title: 'Report'
            }
        };
        // await sendReportEmail.sendAutoReport(data,locals);
        // var locals: any = {
        //     reportParams: {
        //         start: 'today',
        //         end: 'tomorrow',
        //         title:'Auto report test'
        //     }
        // };
        var nodemailer = require('nodemailer');
        var credentials = {
            service: 'gmail',
            auth: {
                user: settings.ownersInfo.email,
                pass: settings.ownersInfo.emailPassword
            }
        };
        //define nodemailer transporter with the credentials
        var transporter = nodemailer.createTransport(credentials);
        templateReport.render(locals, function (err, results) {
            if (err) {
                console.log(err);
                throw err;
            }
            var json2csv = require('json2csv');
            var csv = data.details_data.length !== 0 ? json2csv({
                data: data.details_data
            }) : '';
            // ToDo : This mail options needs to be read from app config file
            //CommitTodo: From Body should be changed
            var mailOptions = {
                from: settings.ownersInfo.company + '" Report" <' + settings.ownersInfo.email + '>',
                to: emailArr.toString(),
                subject: 'Auto Report',
                html: results.html,
                text: results.text,
                attachments: [{
                        filename: data.title + '.csv',
                        content: csv
                    }
                ]
            };
            transporter.sendMail(mailOptions, function (err, responseStatus) {
                if (err) {
                    console.error(err);
                    throw err;
                }
                ;
                console.log(responseStatus);
                return responseStatus;
            });
        });
        // return data;
    });
}
let computeItem = function (itemInfo, iAddGlobalDiscount, calculations) {
    if (iAddGlobalDiscount === undefined) {
        //This is for sale return we don't want to include global discount during computation
        iAddGlobalDiscount = 1;
    }
    var info = {};
    info.quantity = parseFloat(itemInfo.quantity_purchased);
    info.itemId = itemInfo.item_id;
    info.sellingPrice = parseFloat(itemInfo.sellingPrice);
    // if (!itemTaxes) {
    var itemTaxes = itemInfo.itemTaxList;
    if (!itemTaxes) {
        itemTaxes = [];
    }
    // }
    var taxPercent = getTotalPercent(itemTaxes, undefined);
    var sellingPriceTaxEx = getPriceTaxEx(info.sellingPrice, itemInfo.bSPTaxInclusive, taxPercent);
    var totalChargesPercent = getTotalPercent(itemInfo.chargesList, undefined);
    var totalChargesTaxPercent = getTotalPercent(itemInfo.chargesTaxList, undefined);
    info.discountPercent = itemInfo.discount_percent ? parseFloat(itemInfo.discount_percent) : 0;
    var gDisP = itemInfo.gDiscountPercent * iAddGlobalDiscount;
    info.discountPercent += itemInfo.gDiscountPercent ? parseFloat(gDisP) : 0;
    info.cost = (parseFloat(itemInfo.purchasePrice)) * info.quantity; //purchasePrice is Tax Exclusive. It is precomputed before writing to db
    info.priceWithoutDiscount = multiply(info.quantity, sellingPriceTaxEx);
    info.discountAmt = computepxax0dot01(info.priceWithoutDiscount, info.discountPercent);
    info.totalWithoutCharges = subtract(info.priceWithoutDiscount, info.discountAmt);
    info.taxes = computeTaxAmounts(itemTaxes, info.totalWithoutCharges, info.itemId);
    info.chargesAmt = computepxax0dot01(totalChargesPercent, info.totalWithoutCharges);
    info.subTotal = add(info.totalWithoutCharges, info.chargesAmt);
    info.tax = add(computepxax0dot01(taxPercent, info.totalWithoutCharges), computepxax0dot01(totalChargesTaxPercent, info.chargesAmt));
    info.totalTaxPercent = taxPercent;
    info.total = add(info.subTotal, info.tax);
    info.profit = subtract(info.subTotal, info.cost);
    computeTaxAmountsByPercentFilter(info, itemTaxes, info.totalWithoutCharges, calculations);
    return info;
};
function getTotalPercent(taxArray, itemId) {
    try {
        var totalTaxPercent = 0;
        if (!taxArray)
            return totalTaxPercent;
        for (var j = 0; j < taxArray.length; j++) {
            var itemTax = taxArray[j];
            if (!itemTax.item_id || itemTax.item_id === itemId) {
                totalTaxPercent += parseFloat(itemTax.percent);
            }
        }
        return totalTaxPercent;
    }
    catch (ex) {
        console.log("ex");
        console.log(ex);
        return totalTaxPercent;
    }
}
let computepxax0dot01 = function (p, a) {
    return (p * a * 0.01);
};
let add = function (a, b) {
    return (a + b);
};
function multiply(a, b) {
    return (a * b);
}
let subtract = function (a, b) {
    return (a - b);
};
function computeTaxAmounts(taxArray, totalWithoutCharges, itemId) {
    var taxAmounts = {
        CGST: 0,
        SGST: 0,
        IGST: 0,
        CESS: 0
    };
    for (var j = 0; j < taxArray.length; j++) {
        var itemTax = taxArray[j];
        if (!itemTax.item_id || itemTax.item_id === itemId) {
            taxAmounts[itemTax.name] = computepxax0dot01(itemTax.percent, totalWithoutCharges);
        }
    }
    return taxAmounts;
}
let getPriceTaxEx = function (price, bTaxInclusive, totalTaxPercent) {
    var priceExcludingTax = price;
    if (bTaxInclusive) {
        priceExcludingTax = calculatePriceExcludingTax(price, totalTaxPercent);
    }
    ;
    return priceExcludingTax;
};
let calculatePriceExcludingTax = function (price, taxPercent) {
    var factor = 1 + (taxPercent * 0.01);
    var priceExTax = price / factor;
    return priceExTax;
};
function computeTaxAmountsByPercentFilter(info, taxArray, totalWithoutCharges, calculations) {
    if (!calculations) {
        return;
    }
    info.taxForExport = {};
    var taxAmounts = {};
    var items = [];
    var bGST = false;
    var bIGST = false;
    var comp = {
        subTotal: 0,
        total: 0
    };
    var taxP;
    var gCount = 0;
    for (var j = 0; j < taxArray.length; j++) {
        var itemTax = taxArray[j];
        if (itemTax.name === 'CGST' || itemTax.name === 'SGST') {
            gCount += 1;
            bGST = true;
            taxP = itemTax.percent * 2;
        }
        else if (itemTax.name === 'IGST') {
            taxP = itemTax.percent;
            bIGST = true;
        }
        if (gCount <= 1 && taxP !== undefined) {
            if (taxP in calculations) {
                calculations[taxP].subTotal += info.subTotal;
                calculations[taxP].total += info.total;
            }
            else {
                calculations[taxP] = {
                    subTotal: info.subTotal,
                    total: info.total
                };
            }
        }
        var taxName = itemTax.name + '-' + itemTax.percent;
        if (!itemTax.item_id || itemTax.item_id === info.itemId) {
            taxAmounts[taxName] = computepxax0dot01(itemTax.percent, totalWithoutCharges);
        }
    }
    if (bGST || bIGST) {
        info.taxForExport[taxP] = taxAmounts;
        if (!calculations[taxP].hasOwnProperty('taxes')) {
            calculations[taxP].taxes = taxAmounts;
        }
        else {
            for (var t in taxAmounts) {
                if (t in calculations[taxP].taxes) {
                    calculations[taxP].taxes[t] += taxAmounts[t];
                }
                else {
                    calculations[taxP].taxes[t] = taxAmounts[t];
                }
            }
        }
    }
    // return taxAmounts;
}
//# sourceMappingURL=sendReport.js.map