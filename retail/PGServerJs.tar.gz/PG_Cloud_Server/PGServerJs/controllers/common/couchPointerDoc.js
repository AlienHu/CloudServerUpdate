/*
 *		Todo: Add bulk_insert, bulk_update and delete functionality
 *		Todo: Use couchdb return status codes http://docs.couchdb.org/en/2.0.0/api/basics.html#http-status-codes
 * 		Todo: status code is in header.status_code
 */

var CouchPointerDoc = function() {
    'use strict';

    var utils = require('./Utils');
    var logger = require('../../common/Logger');
    var respJsonUtil = require('../../common/responseJson');
    var couchDBUtils = require('./CouchDBUtils');

    /**
     * Case: Pointer Doc is Created
     * 11. Create Pointer Doc
     * 12. Create Parent Doc
     * 13. Update Pointer Doc with Parent _id
     * 
     * Case: Parent Doc creation fails
     * 21. Create Pointer Doc
     * 22. Create Parent Doc
     * 23. Create Parent Doc Fails -> Delete Parent Doc
     * 
     * Case: Update 
     * 31. Create New Pointer Doc
     * 32. Update Parent Doc
     * 33. Update New Pointer Doc with Parent _id
     * 34. Delete Old Pointer Doc
     * 
     * Case: Update Fails
     * 41. Create New Pointer Doc
     * 42. Update Parent Doc
     * 43. Update Pointer Doc Fails -> Delete New Pointer Doc 
     * 
     * Case: Delete Document
     * 51. Delete Parent Doc
     * 52. Delete Pointer Doc
     */

    /**
     *  Scrubber:
     *      Bulk Query all Pointer Docs
     *          1. parent_id NOT NULL
     *              Collect all parent_id and Bulk Query all the parent docs
     *                  IF few docs doesn't exist
     *                      Bulk Delete those docs
     * 
     *          2. parent_id NULL
     *               Query all docs with the unique keys
     *                  If ParentDoc is found                   
     *                      Bulk Update all the pointer docs with the parent_ids returned
     *                  else    
     *                      Bulk Delete those Docs                        
     *  
     *          
     *   
     *                       
     *  
     *  
     */

    /**     
     *  docType :: customer, supplier, item, employee
     *  uniqueFieldsArray :: ['99552392'] (phoneNumber) ['apple', 'Fruits', 'an12341310'] (name, category, barcode)
     */
    this.createWithPointerDoc = function(db, doc, uniqueFieldsArray, docType, uniqueConstraintErrMsg, generalErrMsg) {
        var response = responseUtil.get2();

        var id = '';
        for (var i = 0; i < uniqueFieldsArray.length; i++) {
            docType += '-' + uniqueFieldsArray[i];
        }

        if (id.length === uniqueFieldsArray.length) {
            logger.error('Unique Constraint cannot be enforced. Null Hash');
            return Promise.reject(response);
        }

        id = docType + id;

        var pointerDoc = {
            _id: id,
            type: 'pointer'
        };

        var bCreateCalled = false;
        return couchDBUtils.create(pointerDoc, db, 1).then(function() {
            bCreateCalled = true;
            return couchDBUtils.create(doc, db);
        }).then(function(resp) {
            pointerDoc.parent = doc._id;
            return couchDBUtils.update(pointerDoc, db);
        }).catch(function(error) {
            if (bCreateCalled) {
                couchDBUtils.delete(pointerDoc, db); //It can complete at it's own pace. No 1 is waiting for it's completion
                response.error = generalErrMsg;
            } else {
                response.error = uniqueConstraintErrMsg;
            }
            return response;
        });
    };

};

module.exports = new CouchPointerDoc();