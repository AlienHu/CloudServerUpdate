let autoIncrementHelper = function () {

    const couchDBUtils = require('./CouchDBUtils');
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const logger = require('../../common/Logger');
    const configState = require('../../common/configState');
    const commonLib = require('../libraries/commonLib');
    const moment = require('moment');
    let maxVariantId = 0;
    let maxItemId = 0;
    let maxSaleId;
    let prevSaleId;
    let maxReceivingId = 0;
    let maxSaleReturnId = 0;
    let maxReceivingReturnId = 0;
    let maxPaymentId = 0;
    let maxSaleCreditPaymentId = 0;
    let maxReceivingCreditPaymentId = 0;
    let maxRoomSaleId = 0;
    let maxHomeDeliveryId = 0;
    let maxSalesOrderId = 0;
    let maxSalesQuotationId = 0;
    let maxExpenseId = 0;
    let maxCouchSquenceId = 0;
    let maxTokenNumber = 0;
    let lastSaleTime = 0;
    let maxSaleCouchSquenceId = 0;
    let _self = this;

    async function getMaxId(designDocName, viewName, dbInstance, checkpoint, tokenParam) {
        try {
            let queryResp;
            if (checkpoint !== undefined) {
                queryResp = await couchDBUtils.getView(designDocName, viewName, {
                    startkey: checkpoint,
                    endkey: 'z',
                    reduce: true
                }, dbInstance);
            } else if (tokenParam) {
                queryResp = await couchDBUtils.getView(designDocName, viewName, {
                    startkey: tokenParam.start,
                    endkey: tokenParam.end,
                    reduce: true
                }, dbInstance);
            } else {
                queryResp = await couchDBUtils.getView(designDocName, viewName, {
                    reduce: true
                }, dbInstance);
            }
            // }
            let maxId = 0;
            if (queryResp.length) {
                maxId = queryResp[0].value;
            }

            return maxId;
        } catch (error) {
            logger.error(error);
            throw 'Max ID Query Failed';
        }
    }

    //RelaxTodo inv_10 undefined_batch_1 chhetry pc bug

    this.getAllAutoIncrementIds = async function () {
        try {
            maxVariantId = await getMaxId('all_variants_data', 'all_variants_unique_data', mainDBInstance);
            maxItemId = await getMaxId('all_items_data', 'item-hash', mainDBInstance);
            maxSaleId = await getMaxId('all_sales_info', 'sales_info', mainDBInstance);
            maxCouchSquenceId = await couchDBUtils.getUpdateSeq('maindb')
            //  maxCouchSquenceId
            await _self.setSalesId();
            await _self.setMaxSaleCouchSquenceId();
            maxReceivingId = await getMaxId('all_receivings_info', 'receivings_info', mainDBInstance);
            maxSaleReturnId = await getMaxId('all_sales_info', 'sales_return_info', mainDBInstance);
            maxReceivingReturnId = await getMaxId('all_receivings_info', 'receivings_return_info', mainDBInstance);
            maxPaymentId = await getMaxId('all_room_data', 'payments_info', mainDBInstance);
            maxSaleCreditPaymentId = await getMaxId('all_sales_info', 'credit_payments', mainDBInstance);
            maxReceivingCreditPaymentId = await getMaxId('all_receivings_info', 'credit_payments', mainDBInstance);
            maxRoomSaleId = await getMaxId('all_room_data', 'sales_info', mainDBInstance);
            maxHomeDeliveryId = await getMaxId('all_homedelivery_info', 'max_id', mainDBInstance);
            maxSalesOrderId = await getMaxId('all_SalesOrder_info', 'max_id', mainDBInstance);
            maxSalesQuotationId = await getMaxId('all_SalesQuotation_info', 'max_id', mainDBInstance);
            maxExpenseId = await getMaxId('all_expenses', 'all_time', mainDBInstance);
            await getAndSetLastSaleTime();
            await getTokenNumber();
        } catch (error) {
            logger.error(error);
            throw 'Quering the auto-increment ids failed';
        }
    };

    this.setSalesId = async function () {
        let applicationSettings = await commonLib.getApplicationSettings();
        let checkpoint = applicationSettings.invoiceCurrentCheckpoint;
        maxSaleId = await getMaxId('all_sales_info', 'sales_info', mainDBInstance, checkpoint);
        return maxSaleId;
    }
    this.setMaxSaleCouchSquenceId = async function () {
        maxSaleCouchSquenceId = await getMaxId('all_sales_info', 'sales_maxId', mainDBInstance);
        return maxSaleCouchSquenceId;
    }

    getTokenNumber = async () => {
        try {
            let currentTime = parseInt(moment().format('x'));
            let startDay = moment().startOf('day').valueOf();
            let appSet = await commonLib.getApplicationSettings();
            let resetTime = appSet.resetInfo.resetTime; //resetTime = if time is 4'o clock then ms from 12 am to 4 am;
            if (!resetTime) {
                resetTime = 0;
            }
            let todaysResetTimeStamp = startDay + resetTime;
            let tokenParam = {
                start: startDay
            }
            if (currentTime > todaysResetTimeStamp) {
                tokenParam.start = todaysResetTimeStamp;
            } else {
                // var yesterday = new Date(Date.now() - 864e5);
                startDay = moment(tokenParam.start).add(-1, 'day').valueOf();// moment(yesterday).startOf('day').valueOf();
                tokenParam.start = startDay + resetTime;;

            }
            tokenParam.end = moment(tokenParam.start).add(1, 'day').valueOf();
            maxTokenNumber = await getMaxId('all_sales_info', 'token_sale_info', mainDBInstance, undefined, tokenParam);
        } catch (error) {
            logger.error(error);
            throw 'Quering the Max token No failed';
        }
    }

    getAndSetLastSaleTime = async () => {
        let params = {
            reduce: false,
            limit: 1,
            descending: true
        }
        let resp = await couchDBUtils.getView('all_sales_info', 'all_sale_time', params, mainDBInstance);
        if (resp.length) {
            lastSaleTime = resp[0].key;
        }
    }

    this.getMaxVariantId = function () {
        return maxVariantId;
    };

    this.getMaxItemId = function () {
        return maxItemId;
    };

    this.getMaxCouchSquenceId = function () {
        if (maxSaleCouchSquenceId > maxCouchSquenceId) {
            maxCouchSquenceId = maxSaleCouchSquenceId + 1;
        }
        return maxCouchSquenceId;
    };

    this.getMaxSaleId = function () {
        let applicationSettings = configState.getApplicationSettings();
        prevSaleId = applicationSettings.invoice.starting_invoice_number;
        maxSaleId = maxSaleId > prevSaleId ? maxSaleId : prevSaleId;
        return maxSaleId;
    };

    this.setLastSaleTime = function (saleTime) {
        lastSaleTime = saleTime;
    };

    this.getLastSaleTime = function () {
        return lastSaleTime;
    }

    this.setMaxTokenNum = function (tokenNum) {
        if (!tokenNum) {
            maxTokenNumber = 0;
            return;
        }
        maxTokenNumber = tokenNum;
    };

    this.getMaxTokenNum = function () {
        return maxTokenNumber;
    };

    /* this.getCouchSequence = function() {

     }
     */

    this.getMaxRoomSaleId = function () {
        return maxRoomSaleId;
    };

    this.getMaxHomeDeliveryId = function () {
        return maxHomeDeliveryId;
    };

    this.getMaxExpensesId = function () {
        return maxExpenseId;
    };

    this.getMaxSalesOrderId = function () {
        return maxSalesOrderId;
    };

    this.getMaxSalesQuotationId = function () {
        return maxSalesQuotationId;
    };

    this.getMaxSaleCreditPaymentId = function () {
        return maxSaleCreditPaymentId;
    };

    this.getMaxReceivingCreditPaymentId = function () {
        return maxReceivingCreditPaymentId;
    };

    this.incrementSaleId = function () {
        maxSaleId = maxSaleId + 1;
    };

    this.incrementCouchSquenceId = function () {
        maxCouchSquenceId = maxCouchSquenceId + 1;
    }

    this.getMaxReceivingId = function () {
        return maxReceivingId;
    };

    this.incrementReceivingId = function () {
        maxReceivingId = maxReceivingId + 1;
    };

    this.getMaxSaleReturnId = function () {
        return maxSaleReturnId;
    };

    this.getMaxReceivingReturnId = function () {
        return maxReceivingReturnId;
    };

    this.getMaxPaymentId = function () {
        return maxPaymentId;
    };

};

module.exports = new autoIncrementHelper();