import * as couchDBUtils from './common/CouchDBUtils';
const mainDBInstance: any = couchDBUtils.getMainCouchDB();
import * as logger from '../common/Logger';
import { apiResponse } from './crm'
const LOYALTY_ID = 'loyalty';
import * as moment from 'moment';
let loyalty: Loyalty;
export let save = async function (data: Loyalty): Promise<apiResponse> {
    logger.info("*** loyalty.save " + JSON.stringify(data, null, 2));
    let response: apiResponse = {} as apiResponse;
    if (!data._rev) {
        data._id = LOYALTY_ID;
    }
    if (data.startDate) {
        data.startDate = moment(data.startDate).startOf('day').format('x');
    }
    if (data.endDate) {
        data.endDate = moment(data.endDate).endOf('day').format('x');
    }
    if (data.redeemRule) {
        data.redeemRule.point = 1;
    }
    try {
        await couchDBUtils.createOrUpdate(data, mainDBInstance);
        setLoyalty(data);
        // loyalty = data;
    } catch (error) {
        logger.error(error);
        response.error = 'Loyalty save failed';
        throw response;
    }
    response.msg = 'Loyalty save success';
    return response;

}
export let get = async function (): Promise<Loyalty> {
    logger.info("*** loyalty.get ");
    let doc: Loyalty;
    let response: apiResponse = {} as apiResponse;
    try {
        doc = await couchDBUtils.getDocEx(LOYALTY_ID, mainDBInstance);
        // loyalty = doc;
        setLoyalty(doc);
    } catch (error) {
        response.error = 'Loyalty get failed';
        throw response;
    }
    return doc;

}

export let deleteLyty = async function (data: Loyalty): Promise<apiResponse> {
    logger.info("*** loyalty.deleteLyty " + JSON.stringify(data, null, 2));
    let response: apiResponse = {} as apiResponse;
    try {
        await couchDBUtils.delete(data, mainDBInstance);
    } catch (error) {
        response.error = 'Loyalty delete failed';
        throw response;
    }
    return response;
}
export let setLoyalty = function (data: Loyalty) {
    loyalty = data;
}
export let getLoyalty = function () {// _rev doesn't contains on this
    return loyalty;
}
get().then(function () {
    logger.info("Loyalty get success");
}).catch(function (error) {
    logger.info("Loyalty get failed!");
})

export interface Loyalty {
    _id: string;
    _rev?: string;
    isActive: boolean;
    startDate: Timestamp;
    endDate: Timestamp;
    description: string;
    name: string;
    pointRuleArray: Rule[];
    redeemRule: Rule;
    visitRule: Rule;
    earnOnCredit: boolean;
}
export interface Rule {
    min: number;
    max: number;
    point: number;
    amount: number;
}
export type Timestamp = string;