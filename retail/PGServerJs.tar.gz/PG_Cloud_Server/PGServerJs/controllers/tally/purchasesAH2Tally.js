const common = require('../../TSControllers/tally/computations/common.js')
const mapCustomer = require('../../TSControllers/tally/mapAh2Tally/mapCustomer')
const tallyItemController = require('../../TSControllers/tally/controller/tallyItemController');
// const commonLib = require('../../controllers/libraries/commonLib');

var purchasesAH2Tally = function() {
    const fs = require('fs');
    const moment = require('moment');
    const couchDBUtils = require('../../controllers/common/CouchDBUtils');
    const mainDBInstance = couchDBUtils.getMainCouchDB();

    const templatePath = __dirname + '/../../config/profitguruCoreConfig/';
    const PURCHASE_TEMPLATE = 'PurchaseInfo.xml';
    const ITEM_TEMPLATE = 'Item.xml';
    // const ENVELOPE_TEMPLATE = 'Envelope.xml';
    // const OUTPUT_FILE = 'PurchaseImport.xml';
    const PURCHASE_ACCOUNT_TEMPLATE = 'PurchaseAccount.xml';
    const PURCHASE_LEDGER_TEMPLATE = 'PurchaseLedger.xml';
    const CREDITOR_TEMPLATE = 'Creditor.xml';
    const SUPPLIER_TEMPLATE = 'Supplier.xml';
    const ROUNDOFF_TEMPLATE = 'RoundOff.xml';
    // const DUTIES_TAXES_TEMPLATE = 'DutiesAndTaxes.xml';
    // const CURRENT_LIABILITY_TEMPLATE = 'CurrentLiability.xml';
    const LEDGER_TAX_TEMPLATE = 'SaleTax.xml';
    const PAYMENT_TEMPLATE = 'Payment.xml';
    let purchaseXML = fs.readFileSync(templatePath + PURCHASE_TEMPLATE);
    let itemXML = fs.readFileSync(templatePath + ITEM_TEMPLATE);
    let taxXML = fs.readFileSync(templatePath + LEDGER_TAX_TEMPLATE);
    let paymentXML = fs.readFileSync(templatePath + PAYMENT_TEMPLATE);
    let purchaseTemplate = {};
    let itemTemplate = {};
    let taxTemplate = {};
    let paymentTemplate = {};
    let bPurchase = true;
    let itemsToCreate = [];

    let supplierLedgers = {
        'LEDGERS': []
    }
    let inputDataFromUser = {};
    let tallyConfig;
    this.doPurchaseImport = async function(appSettings, data, taxObj) {
        tallyConfig = common.getTallyConfig();
        inputDataFromUser = data;
        try {
            let promises = [];
            promises.push(common.xml2json(purchaseXML));
            let promiseResponse = await Promise.all(promises);
            purchaseTemplate = promiseResponse[0];
            promises = [];
            promises.push(common.xml2json(itemXML));
            promiseResponse = await Promise.all(promises);
            itemTemplate = promiseResponse[0];
            promises = [];
            promises.push(common.xml2json(taxXML));
            promiseResponse = await Promise.all(promises);
            taxTemplate = promiseResponse[0]['LEDGERENTRIES.LIST'];
            promises = [];
            promises.push(common.xml2json(paymentXML));
            promiseResponse = await Promise.all(promises);
            paymentTemplate = promiseResponse[0];
            promises = [];
            promises.push(processData(appSettings, data, taxObj));
            promiseResponse = await Promise.all(promises);
            return promiseResponse[0]
        } catch (err) {
            common.commonErrorLogger(err);
            throw err;
        }
    }

    this.createLedgers = async function(appSettings) { // todo: verify and remove this function, we are creating all ledgers reading from Settings
        try {
            let purchaseAccountXML = fs.readFileSync(templatePath + PURCHASE_ACCOUNT_TEMPLATE);
            let purchaseLedgerXML = fs.readFileSync(templatePath + PURCHASE_LEDGER_TEMPLATE);
            let creditorXML = fs.readFileSync(templatePath + CREDITOR_TEMPLATE);
            let supplierXML = fs.readFileSync(templatePath + SUPPLIER_TEMPLATE);
            let roundOffXML = fs.readFileSync(templatePath + ROUNDOFF_TEMPLATE);
            let promises = [];
            promises.push(common.xml2json(purchaseAccountXML));
            promises.push(common.xml2json(purchaseLedgerXML));
            promises.push(common.xml2json(creditorXML));
            promises.push(common.xml2json(supplierXML));
            promises.push(common.xml2json(roundOffXML));
            let promiseResponse = await Promise.all(promises);
            promiseResponse[3]['LEDGER']['LEDSTATENAME'] = [appSettings.ownersInfo.state ? appSettings.ownersInfo.state : ''];
            common.ExportFile.save(promiseResponse, 0);
        } catch (err) {
            common.commonErrorLogger(err);
            throw err;
        }
    }

    async function processPurchaseData() {
        let purchases = arguments[0]; // arguments has all the passed param to the function as array
        // console.log(purchases);

        let suppliersToCreate = {};
        let purchaseInfoArray = [];
        for (let p = 0; p < purchases.length; p++) {
            try {
                let purchaseDoc = purchases[p];
                common.convertReturnsToProperDoc(purchaseDoc, true);
                if (tallyConfig.trial) {
                    purchaseDoc.receivings_info.receiving_time = parseInt(moment(tallyConfig.date, 'YYYYMMDD').format('x')); // to test with tally in trial
                }
                let infoMapping = getPurchaseInfoMapping()
                let supplier = purchaseDoc.receivings_info.supplier_id ? await getDocById('supplier_' + purchaseDoc.receivings_info.supplier_id) : '';
                let supplierName = common.getName(supplier, true);
                purchaseDoc.receivings_info.supplier = supplierName;
                if (supplier) {
                    purchaseDoc.receivings_info.companyOfSupplier = supplier.company_name;
                    suppliersToCreate[purchaseDoc.receivings_info.supplier_id] = supplier;
                }
                formatPurchaseDoc(purchaseDoc.receivings_info);
                let purchaseInfoResp = mapDataPurchaseInfo(infoMapping, purchaseDoc.receivings_info, purchaseTemplate);
                let thisPurchaseInfoStruct = common.clone(purchaseInfoResp);
                let itemsArray = [];
                let items = purchaseDoc.receiving_items;
                let PurchaseTaxObj = {
                    CGST: 0,
                    SGST: 0,
                    IGST: 0,
                    CESS: 0
                };
                let guid;
                if (purchaseDoc.bReturnTrans) {
                    guid = common.getGUID(purchaseDoc.receivings_info.invoice_number, 'debit', '');
                } else {
                    guid = common.getGUID(purchaseDoc.receivings_info.invoice_number, 'purchase', '');
                }
                thisPurchaseInfoStruct.VOUCHER['BASICBUYERADDRESS.LIST'][0].BASICBUYERADDRESS = [];
                thisPurchaseInfoStruct.VOUCHER['GUID'] = guid;
                thisPurchaseInfoStruct.VOUCHER['$'].REMOTEID = guid;
                thisPurchaseInfoStruct.VOUCHER['$'].VCHKEY = ['']
                thisPurchaseInfoStruct.VOUCHER['LEDGERENTRIES.LIST'] = [];
                thisPurchaseInfoStruct.VOUCHER['ALLINVENTORYENTRIES.LIST'] = []; // reset items
                thisPurchaseInfoStruct.VOUCHER['BASICBUYERADDRESS.LIST'][0].BASICBUYERADDRESS.push(purchaseDoc.receivings_info.supplier)
                if (supplier) {
                    thisPurchaseInfoStruct.VOUCHER['BASICBUYERADDRESS.LIST'][0].BASICBUYERADDRESS.push(purchaseDoc.receivings_info.companyOfSupplier)
                }
                let bReceipt = purchaseDoc.bReturnTrans ? true : false;
                if (!purchaseDoc.bRejected) {
                    let bTaxPresent = false;
                    let totalFromItems = 0
                    for (let i = 0; i < items.length; i++) {
                        let item = items[i];
                        let itemDoc = await common.getItemDocById('item_' + item.item_id);
                        item.name = itemDoc.info.name; // assigning name from item doc in couch
                        let itemTaxes = Object.values(item.itemTaxList);
                        formatItemInfo(item);
                        for (let t = 0; t < itemTaxes.length; t++) {
                            bTaxPresent = true; // tax present
                            PurchaseTaxObj[itemTaxes[t].name] += itemTaxes[t].percent * item.rate * item.quantity_purchased * 0.01;
                        }
                        itemsToCreate.push('item_' + item.item_id);
                        let mappings = getItemMapping()
                        item.rate = assignUnit(item.rate, item.unit, '/');
                        // let qtyPurchased = item.quantity_purchased;
                        item.quantity_purchased = assignUnit(item.quantity_purchased, item.unit, ' ');
                        let itemInfoResp = mapDataItems(mappings, item, itemTemplate)
                        // if (purchaseDoc.receivings_info.discount.amount) {
                        //     common.applyOnBillDiscountAllocation(itemInfoResp['ALLINVENTORYENTRIES.LIST']);
                        // }
                        itemsArray.push(common.clone(itemInfoResp['ALLINVENTORYENTRIES.LIST'])); // remove key, we are adding while assigning
                        // let thisItemTotal = common.roundOff2Point(-(item.total) * (1 + item.totalTax * 0.01));
                        let roundedOffSubTotal = Math.abs(common.getPrecisedValue(item.total));
                        let precisionMultiplier = common.getPrecisionMultiplier(roundedOffSubTotal, totalFromItems);
                        let oldTotalFromItems = totalFromItems;
                        totalFromItems = (roundedOffSubTotal * precisionMultiplier + totalFromItems * precisionMultiplier) / precisionMultiplier;

                        let newDecimalsLength = common.getPrecisionMultiplier(totalFromItems, 0);
                        if (precisionMultiplier < newDecimalsLength) {
                            // calculation went bad again
                            // add one more zero to fix it
                            totalFromItems = ((roundedOffSubTotal * precisionMultiplier * 10) + (oldTotalFromItems * precisionMultiplier * 10)) / (precisionMultiplier * 10);
                        }

                    }
                    thisPurchaseInfoStruct.VOUCHER['ALLINVENTORYENTRIES.LIST'].push(...itemsArray);
                    let supplierLedger = common.getPartyLedger(supplierName, purchaseDoc.receivings_info.total, taxTemplate, true, purchaseDoc.receivings_info.invoice_number);
                    if (bReceipt) {
                        common.makeItOpposite(supplierLedger['BILLALLOCATIONS.LIST'][0], ['AMOUNT']);
                    }

                    thisPurchaseInfoStruct.VOUCHER['LEDGERENTRIES.LIST'].push(supplierLedger);
                    let saleTaxes = 0;
                    if (bTaxPresent) {
                        let taxLedger = common.getTaxLedgers(PurchaseTaxObj, taxTemplate, bPurchase);
                        thisPurchaseInfoStruct.VOUCHER['LEDGERENTRIES.LIST'].push(...taxLedger);
                        saleTaxes = common.getTaxAmount(PurchaseTaxObj);
                    }
                    let precisionMultiplier = common.getPrecisionMultiplier(purchaseDoc.receivings_info.total, totalFromItems, saleTaxes);
                    let roundOff = (Math.abs(purchaseDoc.receivings_info.total) * precisionMultiplier - (Math.abs(totalFromItems) * precisionMultiplier + Math.abs(saleTaxes) * precisionMultiplier)) / precisionMultiplier;
                    const originalPrecisionMultiplier = precisionMultiplier;
                    if (common.getDecimalLength(Math.abs(roundOff)) > precisionMultiplier.toString().length) {
                        precisionMultiplier = originalPrecisionMultiplier * 10;
                        roundOff = (Math.abs(purchaseDoc.receivings_info.total) * precisionMultiplier - (Math.abs(totalFromItems) * precisionMultiplier + Math.abs(saleTaxes) * precisionMultiplier)) / precisionMultiplier;
                    }
                    if (common.getDecimalLength(Math.abs(roundOff)) > precisionMultiplier.toString().length) {
                        precisionMultiplier = originalPrecisionMultiplier / 10;
                        roundOff = (Math.abs(purchaseDoc.receivings_info.total) * precisionMultiplier - (Math.abs(totalFromItems) * precisionMultiplier + Math.abs(saleTaxes) * precisionMultiplier)) / precisionMultiplier;
                    }
                    if (common.getDecimalLength(Math.abs(roundOff)) > precisionMultiplier.toString().length) { // if nothing matches, reset to original precisionMultiplier
                        precisionMultiplier = originalPrecisionMultiplier;
                        roundOff = (Math.abs(purchaseDoc.receivings_info.total) * precisionMultiplier - (Math.abs(totalFromItems) * precisionMultiplier + Math.abs(saleTaxes) * precisionMultiplier)) / precisionMultiplier;
                    }
                    let roundOffLedger = common.getRoundOffLedger(roundOff, common.clone(taxTemplate), -1);
                    thisPurchaseInfoStruct.VOUCHER['LEDGERENTRIES.LIST'].push(roundOffLedger);
                }

                let paymentGuid = common.getGUID(purchaseDoc.receivings_info.invoice_number, 'purchase', purchaseDoc.bReturnTrans ? 'receipt' : 'payment');
                let paymentsToAdd = common.getPaymentsLedger(purchaseDoc.payments, supplierName, inputDataFromUser.voucherClass, paymentGuid, purchaseDoc.receivings_info.dateShort, purchaseDoc.receivings_info.invoice_number, purchaseDoc.receivings_info.receiving_time, !bReceipt)
                if (paymentsToAdd.length) {
                    if (purchaseDoc.bRejected) {
                        paymentsToAdd.forEach(element => {
                            common.cancelTransaction(element.VOUCHER, [], [], true);
                        });
                    }
                    purchaseInfoArray.push(...paymentsToAdd);
                }
                if (purchaseDoc.bRejected) {
                    common.cancelTransaction(thisPurchaseInfoStruct.VOUCHER, [], [], true);
                    if (purchaseDoc.bReturnTrans) {
                        thisPurchaseInfoStruct.VOUCHER.$.VCHTYPE = 'Debit Note';
                        thisPurchaseInfoStruct.VOUCHER.VOUCHERTYPENAME = ['Debit Note'];
                    }
                } else if (purchaseDoc.bReturnTrans) {
                    common.returnTransaction(thisPurchaseInfoStruct.VOUCHER, true);
                }
                purchaseInfoArray.push(thisPurchaseInfoStruct);
            } catch (err) {
                common.commonErrorLogger(err);
                common.commonErrorLogger('tally purchase failed for ' + JSON.stringify(purchases[p]));
                common.increementErrorCount();
            }

        }

        for (let supplier in suppliersToCreate) {
            let supplierXML = mapCustomer.default(suppliersToCreate[supplier]);
            supplierXML.PARENT = ['Sundry Creditors'];
            supplierXML.GUID = [''];
            supplierXML.ISDEEMEDPOSITIVE = ['Yes'];
            supplierXML.ISLASTDEEMEDPOSITIVE = ['Yes'];

            supplierLedgers['LEDGERS'].push(common.clone(supplierXML));
        }
        if (purchaseInfoArray.length) common.ExportFile.save(purchaseInfoArray, 3);

    }

    async function processData(appSettings, data, taxObj) {
        await couchDBUtils.batchProcess(couchDBUtils.getTransView, ['all_receivings_info', 'all_time',
                {
                    startkey: data.voucherClass.fromDate,
                    endkey: data.voucherClass.toDate,
                    include_docs: true,
                    limit: tallyConfig.export.dbDocsLimit
                },
                mainDBInstance,
                'purchase'
            ],
            processPurchaseData);
        if (supplierLedgers['LEDGERS'].length) {
            common.ExportFile.save([supplierLedgers], 2);
            supplierLedgers['LEDGERS'] = [];
        }

        itemsToCreate = common.getUniqueArray(itemsToCreate);
        await tallyItemController.default(itemsToCreate, appSettings, taxObj, false); // tally has only one tax, so false only
    }

    var assignUnit = function(value, unit, separator) {
        if (!unit) {
            separator = '';
            unit = ''
        }
        return value + separator + unit;
    }

    function getTaxable(item) {
        let taxable = item.unitsInfo[item.baseUnitId].purchasePriceWithGDiscount ? item.unitsInfo[item.baseUnitId].purchasePriceWithGDiscount : 0; // for 0 total case
        if (item.bPPTaxInclusive) {
            let precisionMultiplier = common.getPrecisionMultiplier(taxable, item.totalTax);
            taxable = (taxable * precisionMultiplier - (((taxable * item.totalTax) / (100 + item.totalTax)) * precisionMultiplier)) / precisionMultiplier;
        }
        return common.getPrecisedValue(taxable);
    }

    function getTotalTaxPercent(item) {
        let thisItemTax = 0;
        if (item.itemTaxList.length) {
            for (let i = 0; i < item.itemTaxList.length; i++) {
                thisItemTax += item.itemTaxList[i].percent;
            }
        }
        return thisItemTax;
    }

    function formatItemInfo(item) {
        item.totalTax = getTotalTaxPercent(item);
        let taxable = getTaxable(item);
        // item.totalTaxAmount = common.roundOff2Point(item.totalTax * taxable * 0.01);
        item.rate = taxable;
        item.total = -1 * common.getPrecisedValue(taxable * item.quantity_purchased);
    }

    async function formatPurchaseDoc(purchaseDoc) {
        purchaseDoc.dateShort = moment(purchaseDoc.receiving_time).format('YYYYMMDD');
        purchaseDoc.dateLabel = moment(purchaseDoc.receiving_time).format('D-MM-YYYY at HH:mm');
        purchaseDoc.invoice_number = purchaseDoc.invoice_number ? purchaseDoc.invoice_number.toString() : 'REC ' + purchaseDoc.receiving_id.toString();
    }

    async function getDocById(id) {
        let doc = await couchDBUtils.getDoc(id, mainDBInstance);
        return doc;
    }

    function mapDataPurchaseInfo(mappings, json, data) {
        let mainKey = data.VOUCHER;
        mappings.forEach(mapping => {
            mainKey[mapping[1]] = json[mapping[0]] ? [json[mapping[0]].toString()] : ['']
        });
        return data;
    }

    function mapDataItems(mappings, json, data) {
        let mainKey = data['ALLINVENTORYENTRIES.LIST'];
        // let mainKey = data;
        mappings.forEach(mapping => {
            mainKey[mapping[1]] = json[mapping[0]] ? [json[mapping[0]].toString()] : ['']
        });
        // moved this to Item.xml 
        // mainKey.ISDEEMEDPOSITIVE = ['Yes'];
        // mainKey.ISLASTDEEMEDPOSITIVE = ['Yes'];

        let mainKey2 = data['ALLINVENTORYENTRIES.LIST']['BATCHALLOCATIONS.LIST'][0];
        let otherKeys = ['AMOUNT', 'ACTUALQTY', 'BILLEDQTY'];
        otherKeys.forEach(key => {
            mainKey2[key] = mainKey[key]
        });
        // not needed these keys
        // mainKey2.ISDEEMEDPOSITIVE = ['Yes'];
        // mainKey2.ISLASTDEEMEDPOSITIVE = ['Yes'];

        let mainKey3 = data['ALLINVENTORYENTRIES.LIST']['ACCOUNTINGALLOCATIONS.LIST'][0];
        otherKeys.forEach(key => {
            mainKey3[key] = mainKey[key]
        });
        // moved this to Item.xml 
        // mainKey3.ISDEEMEDPOSITIVE = ['Yes'];
        // mainKey3.ISLASTDEEMEDPOSITIVE = ['Yes'];

        return data;
    }

    function getPurchaseInfoMapping() {
        let mappings = [
            // ['AlienHu_JSON_KEY', 'Tally_XML_KEY']
            ['comment', 'NARRATION'],
            ['state_name', 'PLACEOFSUPPLY'],
            ['state_name', 'CONSIGNEESTATENAME'],
            ['state_name', 'STATENAME'],
            ['dateShort', 'DATE'],
            ['dateShort', 'REFERENCEDATE'],
            ['dateLabel', 'BASICDATETIMEOFINVOICE'],
            ['dateLabel', 'BASICDATETIMEOFREMOVAL'],
            ['dateShort', 'EFFECTIVEDATE'],
            ['total', 'AMOUNT'],
            ['supplier', 'PARTYNAME'],
            ['invoice_number', 'VOUCHERNUMBER'],
            ['supplier', 'BASICBASEPARTYNAME'],
            ['supplier', 'PARTYLEDGERNAME'],
            ['companyOfSupplier', 'BASICBUYERNAME'],
            ['invoice_number', 'ALTERID'],
            ['invoice_number', 'MASTERID'],
            ['receiving_time', 'VOUCHERKEY'],
            ['invoice_number', 'REFERENCE']

        ]
        return mappings;
    }

    function getItemMapping() {
        let mappings = [
            ['name', 'STOCKITEMNAME'],
            ['rate', 'RATE'],
            ['total', 'AMOUNT'],
            ['quantity_purchased', 'ACTUALQTY'],
            ['quantity_purchased', 'BILLEDQTY'],
            ['discount', 'DISCOUNT']
        ]

        return mappings;
    }
}

module.exports = new purchasesAH2Tally();