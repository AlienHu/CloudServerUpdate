"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const couchDBUtils = require("./common/CouchDBUtils");
const moment = require("moment");
const logger = require("../common/Logger");
const inventoryTransactionHelper_1 = require("./libraries/inventoryTransactionHelper");
const workerProcess = require("./workers/commonWorker");
const mainDBInstance = couchDBUtils.getMainCouchDB();
exports.PRODUCTION_PLAN_PREFIX = 'pp';
exports.STOCK_ENTRY_PREFIX = 'se';
var Option;
(function (Option) {
    Option[Option["Create"] = 1] = "Create";
    Option[Option["Update"] = 2] = "Update";
    Option[Option["Delete"] = 3] = "Delete";
})(Option = exports.Option || (exports.Option = {}));
exports.getItemByDocId = function (requestData) {
    return __awaiter(this, void 0, void 0, function* () {
        let Item = requestData;
        let curItem = yield couchDBUtils.getDoc(Item.prepared_item_id, mainDBInstance);
        curItem.info.bomData = Item;
        if (!Item.ingredient_info) {
            //this means we have to delete bom
            delete curItem.info.bomData;
        }
        try {
            let resp = yield couchDBUtils.update(curItem, mainDBInstance, 3, "could not fetch Item document");
            return 'success';
        }
        catch (error) {
            throw error;
        }
    });
};
exports.updateProductionPlan = function (data, option) {
    return __awaiter(this, void 0, void 0, function* () {
        let msg = '';
        let succsMsg = '';
        if (!option) {
            option = Option.Create;
            if (data._id) {
                option = Option.Update;
            }
        }
        try {
            if (option === Option.Create) {
                msg = 'Save';
                if (!data._id) {
                    //approve will send the id in case of submit + approve dual action
                    data._id = getPPId();
                }
                yield couchDBUtils.create(data, mainDBInstance);
            }
            else if (option === Option.Update || option === Option.Delete) {
                msg = 'Update';
                if (option === Option.Delete) {
                    data.deleted = '1';
                    msg = 'Delete';
                }
                yield couchDBUtils.update(data, mainDBInstance, 2);
            }
            msg += ' Success.';
            return msg;
        }
        catch (error) {
            logger.error(error);
            msg += ' Failed.';
            throw msg;
        }
    });
};
function convertIngredientListToSaleItemArray(ingredientList) {
    let saleItems = [];
    for (let i = 0; i < ingredientList.length; i++) {
        let ingredient = ingredientList[i];
        for (let j = 0; j < ingredient.batchList.length; j++) {
            let batchData = ingredient.batchList[j];
            let saleItem = {};
            //we didn't write for loop because .. if we write forloop we loose typechecking in compile time
            //is there a way to do it?
            let uidx = ingredient.item_id.indexOf("_");
            saleItem.item_id = parseInt(ingredient.item_id.substring(uidx + 1));
            saleItem.item_location = 1;
            saleItem.baseUnitId = ingredient.baseUnitId;
            saleItem.batchId = batchData.batchId;
            saleItem.stockKey = batchData.stockKey;
            saleItem.quantity = batchData.quantity;
            saleItem.skuName = batchData.skuName;
            saleItem.unitId = batchData.unitId;
            saleItem.unitsInfo = batchData.unitsInfo;
            saleItems.push(saleItem);
        }
    }
    return saleItems;
}
function getPPId() {
    return exports.PRODUCTION_PLAN_PREFIX + '_' + moment().format('x');
}
//tsc controllers/Receipe.ts --lib es2015 --sourceMap true
// #bom1 handle for revert approval also
exports.approveProductionPlan = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        let option = Option.Update;
        if (!data._id) {
            option = Option.Create;
            data._id = getPPId();
        }
        if (option === Option.Update) {
            let doc;
            try {
                doc = yield couchDBUtils.getDoc(data._id, mainDBInstance, 'propagate');
            }
            catch (error) {
                throw 'Production Plan Not Found for Update.';
            }
            if (doc.status === data.status) {
                throw 'Already ' + data.status;
            }
            if (doc.transStatus && doc.transStatus.status) {
                throw 'Try after Some Time. Transaction In Progress';
            }
        }
        let bDecrement = true;
        if (data.status === 'approved') {
            bDecrement = true;
        }
        else if (data.status === 'create') {
            bDecrement = false;
        }
        else {
            throw 'Unknown Status';
        }
        let ingredientList = data.ingredientList;
        let saleItems = convertIngredientListToSaleItemArray(ingredientList);
        let params = {
            items: saleItems,
            timeStamp: data.ppTimeStamp,
            employee_id: data.lastUpdatedBy,
            comment: data._id,
            bDecrement: bDecrement
        };
        let invTransStatusMap = inventoryTransactionHelper_1.getInventoryTransaction(params);
        data.transStatus = {
            status: 4,
            inventoryTrans: invTransStatusMap
        };
        workerProcess.setFreeze(true);
        let resp = yield exports.updateProductionPlan(data, option);
        workerProcess.insertTrans({
            parentDocId: data._id,
            transactions: invTransStatusMap,
            itemUpdates: {},
            elementUpdates: {}
        });
        workerProcess.setFreeze(false);
        return resp;
    });
};
exports.stockEntry = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        let timeStamp = moment().format('x');
        data._id = exports.STOCK_ENTRY_PREFIX + '_' + timeStamp;
        let params = {
            items: data.items,
            timeStamp: timeStamp,
            employee_id: data.employee_id,
            comment: data._id,
            bDecrement: data.bDecrement
        };
        let invTransStatusMap = inventoryTransactionHelper_1.getInventoryTransaction(params);
        data.transStatus = {
            status: 4,
            inventoryTrans: invTransStatusMap
        };
        workerProcess.setFreeze(true);
        let resp = 'Stock Entry Success.';
        try {
            yield couchDBUtils.create(data, mainDBInstance);
            workerProcess.insertTrans({
                parentDocId: data._id,
                transactions: invTransStatusMap,
                itemUpdates: {},
                elementUpdates: {}
            });
        }
        catch (error) {
            throw 'Stock Entry Failed.';
        }
        finally {
            workerProcess.setFreeze(false);
        }
        return resp;
    });
};
//# sourceMappingURL=Receipe.js.map