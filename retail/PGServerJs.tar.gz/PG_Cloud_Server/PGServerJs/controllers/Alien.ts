const couchDBUtils = require('./common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();


export const getAlienPendingSales = async () => {
    try {
        const pendingSales = await couchDBUtils.getView('all_sales_info', 'All_Alien_Pending_Sales', { descending: true }, mainDBInstance);
        return pendingSales;
    } catch (err) {
        throw err;
    }
}