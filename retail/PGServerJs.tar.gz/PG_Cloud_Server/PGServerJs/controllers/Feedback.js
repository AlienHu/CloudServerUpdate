"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const moment = require("moment");
const logger = require("../common/Logger");
const utils = require("../controllers/common/Utils");
const cauch_db_utils = require("../controllers/common/CouchDBUtils");
const coredbInstance = cauch_db_utils.getCoreCouchDB();
const mainDb = cauch_db_utils.getMainCouchDB();
const helper = require("../licencer/licenceHelper");
let feedCtrl = function () {
    this.add_feedback = (req) => __awaiter(this, void 0, void 0, function* () {
        try {
            let response = {
                error: true,
                message: "",
                data: {}
            };
            let app_type = process.env.APP_TYPE;
            let unique_feedback_id = Date.now();
            let request_body = req.generated_form;
            let payload = {
                _id: `feedbackForm_${unique_feedback_id}`,
                form: request_body.form,
                id: unique_feedback_id,
                title: request_body.title
            };
            let create_feed_db = yield coredbInstance;
            if (!create_feed_db) {
                response.message = "DB Not Found";
                throw response;
                // res.send(response_payload)
            }
            else {
                let insrt_db = yield create_feed_db.insert(payload);
                let response_data = { msg: "successfully added", data: { success: insrt_db } };
                return response_data;
                // res.send();
            }
        }
        catch (e) {
            // res.send({msg: "Failed added", err: e})
            throw e;
        }
    });
    this.getFeedBackForm = (req) => __awaiter(this, void 0, void 0, function* () {
        try {
            let response = {
                error: true,
                message: "",
                data: {}
            };
            let create_feed_db = yield coredbInstance;
            if (!create_feed_db) {
                response.message = "DB Not Found";
                throw response;
            }
            else {
                let get_data = yield cauch_db_utils.getAllDocsByType("feedbackForm", create_feed_db);
                console.log('get_data', get_data);
                let response_data = { msg: "successfully added", data: { success: get_data } };
                return response_data;
            }
        }
        catch (e) {
            console.log('e', e);
            throw e;
        }
    });
    this.deleteFeedBackForm = (req) => __awaiter(this, void 0, void 0, function* () {
        try {
            let create_feed_db = yield coredbInstance;
            if (!create_feed_db) {
                let response = {
                    message: ''
                };
                response.message = "DB Not Found";
                throw response;
            }
            else {
                let get_data = yield cauch_db_utils.delete(req.body, create_feed_db);
                console.log('get_data', get_data);
                let response_data = { msg: "successfully added", data: { success: get_data } };
                return response_data;
            }
        }
        catch (e) {
            console.log('e', e);
            throw e;
        }
    });
    //paging
    /**
     * paging
     * accumulated stats - background thread
     * customer -> do using views -> in memory is not ideal
     */
    this.getRepliesForForm = function (param) {
        return __awaiter(this, void 0, void 0, function* () {
            /*
            f_time_formId
            */
            if (param.dateStart) {
                param.dateStart = moment(param.dateStart).format('x');
            }
            if (param.dateEnd) {
                param.dateEnd = moment(param.dateEnd).format('x');
            }
            let startKey = 'f', endKey = 'f';
            startKey += param.dateStart ? "_" + param.dateStart : "_1000000000000";
            startKey += param.feedbackformId ? "_" + param.feedbackformId : "_a";
            endKey += param.dateEnd ? "_" + param.dateEnd : "_9999999999999";
            endKey += param.feedbackformId ? "_" + param.feedbackformId : "_z";
            // var response: responseFormat;
            var response = {
                error: true,
                message: "",
                data: []
            };
            // var queryParam: queryParam;
            var queryParam = {
                startkey: startKey,
                endkey: endKey,
                include_docs: true
            };
            logger.info("calling all feedback replies " + JSON.stringify(queryParam));
            try {
                let dbInstance = yield mainDb;
                if (!dbInstance) {
                    response.message = "DB Not Found";
                }
                else {
                    let replies = yield cauch_db_utils.getView("all_feedback_data", "all_feedback_replies", queryParam, dbInstance);
                    let repliesDocArr = replies.map(reply => reply.doc); //send only doc
                    response = {
                        error: false,
                        message: "Success",
                        data: repliesDocArr
                    };
                    return response;
                }
            }
            catch (e) {
                console.log('e', e);
                response.message = "Error finding replies.";
            }
            response.data = [];
            throw response;
        });
    };
};
module.exports = new feedCtrl();
// try {
//     var x = new feedCtrl();
//     var y = x.getRepliesForForm();
//     console.log(y);
// }
// catch (err) {
//     console.log(err);
// }
//# sourceMappingURL=Feedback.js.map