import * as couchDBUtils from '../controllers/common/CouchDBUtils';
type SaleReturnDoc = any;
import { DocId } from '../TSControllers/interfaces/common';
const TYPE = 'saleReturn';
const PREFIX = TYPE + '_';
import { transformSaleDoc, encodeTransDoc } from '../controllers/libraries/commonLib';

export const createOrUpdate = async (doc: SaleReturnDoc, dbInstance: any, reTryCount: number, errMsg: string): Promise<string> => {
    await encodeTransDoc(doc, TYPE);
    return couchDBUtils.createOrUpdate(doc, dbInstance, reTryCount, errMsg);
};

export const getDoc = async (docId: DocId, dbInstance: any): Promise<SaleReturnDoc> => {
    let doc = await couchDBUtils.getDocEx(PREFIX + docId, dbInstance);
    let SaleReturnDoc: SaleReturnDoc = transformSaleDoc(doc, TYPE);
    return SaleReturnDoc;
};