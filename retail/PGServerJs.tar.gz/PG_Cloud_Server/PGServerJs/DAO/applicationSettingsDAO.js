"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const couchDBApis = require("../TSCouchDB/Common/couchDBApis");
const dbInstanceHelper_1 = require("../TSCouchDB/Common/dbInstanceHelper");
const formatDocIds_1 = require("../TSControllers/utils/formatDocIds");
exports.update = (dbContext, doc, reTryCount, errMsg) => __awaiter(this, void 0, void 0, function* () {
    let resp = yield couchDBApis.update(dbContext, doc, dbInstanceHelper_1.getCoreDBInstance, reTryCount, errMsg, doc._id);
    doc._rev = resp[1]["X-Couch-Update-Newrev"];
    exports.setApplcationSettings(doc, dbContext);
    return doc;
});
exports.setApplcationSettings = (applcationSettings, dbContext) => {
    const signature = formatDocIds_1.getSignature(dbContext);
    applcationSettingsItrObj[signature] = applcationSettings;
};
exports.getApplcationSettings = (dbContext) => {
    const signature = formatDocIds_1.getSignature(dbContext);
    return applcationSettingsItrObj[signature];
};
let applcationSettingsItrObj = {};
//# sourceMappingURL=applicationSettingsDAO.js.map