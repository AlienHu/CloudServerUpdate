/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;

        const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
        try {
            let batchProcessParams = {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger,
                customers: {},
                suppliers: {}
            };

            await batchProcess(50, 'sale', process, batchProcessParams);
            await batchProcess(50, 'saleReturn', process, batchProcessParams);
            await batchProcess(50, 'receiving', process, batchProcessParams);
            await batchProcess(50, 'receivingReturn', process, batchProcessParams);

            async function process(allDocs, params) {
                let docsToUpdate = [];
                for (let i = 0; i < allDocs.length; i++) {
                    let elementKey = 'supplier';
                    let bSale = false;
                    if (allDocs[i].doc._id.indexOf('sale') === 0) {
                        elementKey = 'customer';
                        bSale = true
                    }

                    let info = allDocs[i].doc.receivings_info;
                    if (!info) {
                        info = allDocs[i].doc.info;
                    }
                    if (!info) {
                        info = allDocs[i].doc.sales_info;
                    }

                    if (!info) {
                        continue;
                    }

                    let elementId = info.supplier_id;
                    if (bSale) {
                        elementId = info.customer_id;
                    }

                    let elementDocId = elementKey + '_' + elementId;
                    let elementDoc;
                    if (elementId) {
                        if (!params[elementKey + 's'][elementDocId]) {
                            try {
                                params[elementKey + 's'][elementDocId] = await couchDBUtils.getDoc(elementDocId, params.dbInstance, 'missing');
                            } catch (error) {
                                params.logger.error(elementDocId + ' not found');
                            }
                        }
                        if (params[elementKey + 's'][elementDocId]) {
                            elementDoc = params[elementKey + 's'][elementDocId];
                        }
                    }
                    if (elementDoc) {
                        if (!info.state_name) {
                            info.state_name = elementDoc.state;
                        }
                        if (!info.GSTIN) {
                            info.GSTIN = elementDoc.gstin_number;
                        }
                        docsToUpdate.push(allDocs[i].doc);
                    }
                }

                if (docsToUpdate.length) {
                    let updateResp = await couchDBUtils.bulkInsert(params.dbInstance, docsToUpdate);
                }
            }

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;

        try {
            let batchProcessParams = {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            };
            await batchProcess(20, 'receiving', process, batchProcessParams);
            await batchProcess(20, 'receivingReturn', process, batchProcessParams);

            async function process(allDocs, params) {
                let docsToUpdate = [];

                for (let i = 0; i < allDocs.length; i++) {

                    let info = allDocs[i].doc.receivings_info;
                    if (!info) {
                        info = allDocs[i].doc.info;
                    }
                    if (!info) {
                        info = allDocs[i].doc.sales_info;
                    }

                    if (!info) {
                        continue;
                    }

                    let bUpdate = false;
                    if (info.hasOwnProperty('GSTIN')) {
                        bUpdate = true;
                        delete info.GSTIN;
                    }
                    if (info.hasOwnProperty('state_name')) {
                        bUpdate = true;
                        delete info.state_name;
                    }

                    if (bUpdate) {
                        docsToUpdate.push(allDocs[i].doc);
                    }
                }

                if (docsToUpdate.length) {
                    let updateResp = await couchDBUtils.bulkInsert(params.dbInstance, docsToUpdate);
                }
            }

        } catch (error) {
            logger.error(error);
            logger.error('purchase reprint down migration failed');
            throw error;
        }
    }
};