/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const mainDBInstance = couchDBUtils.getMainCouchDB();
        const usersDBInstance = couchDBUtils.getUserCouchDB();
        const coreDBInstancce = couchDBUtils.getCoreCouchDB();
        let migrationName = path.basename(__filename, '.js');
        try {
            const applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
            let allTableDocs = await couchDBUtils.getAllDocsByType('table', mainDBInstance);
            let newDocs = [];
            for (let i = 0; i < allTableDocs.length; i++) {
                let tableDoc = allTableDocs[i].doc;
                if (tableDoc.hasOwnProperty('isOnlyPrintBill')) {
                    delete tableDoc.isOnlyPrintBill;
                    tableDoc.printedOrders = [];
                    newDocs.push(tableDoc);
                }
            }

            let salesConfigIdx = applicationSettings.terminalConfigs.indexOf('salesConfig');
            if (salesConfigIdx > -1) {
                applicationSettings.terminalConfigs.splice(salesConfigIdx, 1)
                await couchDBUtils.update(applicationSettings, coreDBInstancce, 2);
            }

            if (newDocs.length) {
                await couchDBUtils.bulkInsert(mainDBInstance, newDocs);
            }

            let allUsers = await couchDBUtils.getView('employees', 'all', {}, usersDBInstance);
            let allUsersDoc = [];

            for (let i = 0; i < allUsers.length; i++) {
                if (!allUsers[i].value.roles[0]) continue;
                try {
                    allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                } catch (error) {
                    logger.error(error);
                    continue;
                }
                console.log(allUsers[i])
                let reportObj = allUsers[i].value.roles[0].reports;
                reportObj.editSale = {
                    "allowed": false,
                    "desc": "Allows to edit and delete sale"
                };
                reportObj.rejectSale = {
                    "allowed": false,
                    "desc": "Allows reject sale"
                };
                reportObj.deleteSale = {
                    "allowed": false,
                    "desc": "Allows delete sale"
                };
                var reportFeature = ["purchases",
                    "items",
                    "employees",
                    "suppliers",
                    "sales",
                    "discounts",
                    "taxes",
                    "inventory",
                    "categories",
                    "payments",
                    "customers",
                    "gstreports"
                ]
                for (let i = 0; i < reportFeature.length; i++) {
                    try {
                        console.log(reportFeature[i]);
                        delete reportObj[reportFeature[i]].apis;
                        if (reportFeature[i] === "sales") {
                            delete reportObj[reportFeature[i]]["salesHistory"].apis;
                        }
                    } catch (error) {
                        logger.error(error);
                        continue;
                    }
                }
                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                allUsersDoc.push(allUsers[i].value);
            }
            if (allUsersDoc.length)
                await couchDBUtils.bulkInsert(usersDBInstance, allUsersDoc);
        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const mainDBInstance = couchDBUtils.getMainCouchDB();

        let migrationName = path.basename(__filename, '.js');
        try {
            let allTableDocs = await couchDBUtils.getAllDocsByType('table', mainDBInstance);
            for (let i = 0; i < allTableDocs.length; i++) {
                let tableDoc = allTableDocs[i].doc;
                if (tableDoc.printedOrders) {
                    delete tableDoc.printedOrders;
                    tableDoc.isOnlyPrintBill = false;

                }
            }
            if (newDocs.length) {
                await couchDBUtils.bulkInsert(mainDBInstance, newDocs);
            }

            let allUsers = await couchDBUtils.getView('employees', 'all', {}, usersDBInstance);
            let allUsersDoc = [];

            for (let i = 0; i < allUsers.length; i++) {
                if (!allUsers[i].value.roles[0]) continue;
                try {
                    allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                } catch (error) {
                    logger.error(error);
                    continue;
                }
                let reportObj = allUsers[i].value.roles[0].reports;
                delete reportObj.editSale;
                delete reportObj.rejectSale;
                delete reportObj.deleteSale;
                var reportFeature = {
                    "purchases": ["DetailedEmpRestAPI"],
                    "items": ["graphicalSummaryItemGraphRestAPI", "SummaryItemRestAPI"],
                    "employees": ["graphicalSummaryEmployeeGraphRestAPI", "SummaryEmployeeRestAPI", "DetailedEmpRestAPI"],
                    "suppliers": ["graphicalSummarySupGraphRestAPI", "SummarySupplierRestAPI"],
                    "sales": ["graphicalSummarySaleGraphRestAPI", "SummarySaleRestAPI"],
                    "discounts": ["graphicalSummaryDiscountGraphRestAPI", "SummaryDiscountRestAPI", "DetailedDisRestAPI"],
                    "taxes": ["graphicalSummaryTaxGraphRestAPI", "SummaryDiscountRestAPI", "DetailedDisRestAPI"],
                    "inventory": ["LowInventoryRestAPI", "InventorySumRestAPI"],
                    "categories": ["graphicalSummaryCategoriesGraphRestAPI", "SummaryCategoryRestAPI"],
                    "payments": ["graphicalSummaryPaymentGraphRestAPI", "SummaryPaymentRestAPI"],
                    "customers": ["graphicalSummaryCustomerGraphRestAPI", "SummaryCustomerRestAPI", "DetailedCustRestAPI"],
                    "gstreports": ["gstr1_12", "gstr2"],

                };
                for (let ele in reportFeature) {
                    reportObj[ele].apis = reportFeature[ele];
                    if (ele === "sales") {
                        reportObj[ele].salesHistory.apis = ["DetailedSaleRestAPI"];
                    }
                }
                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                allUsersDoc.push(allUsers[i].value);

            }
            if (allUsersDoc)
                await couchDBUtils.bulkInsert(usersDBInstance, allUsersDoc);

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }

    }
};