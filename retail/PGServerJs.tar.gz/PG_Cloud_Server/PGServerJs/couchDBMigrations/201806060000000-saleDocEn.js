/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require('fs');
var path = require('path');
let logger;
const taxLib = require('./libraries/taxDetailsCommon');
const getTaxesByPercentageDetailed = taxLib.getTaxesByPercentageDetailed;
exports.up = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        try {
            /**sales Multiple units */
            yield batchProcess(1000, 'sale', saleBatchProcess, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            //sales return 
            yield batchProcess(1000, 'saleReturn', processSaleReturns, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
        }
        catch (err) {
            logger.error(err);
            throw migrationName + ' up migration failed';
        }
    });
};
exports.down = function () {
    return __awaiter(this, void 0, void 0, function* () {
    });
};
function bulkInsert(db, docsArray) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let resp = yield db.bulk({
                docs: docsArray
            });
            return resp;
        }
        catch (error) {
            logger.error(error);
            throw 'Bulk Update Failed';
        }
    });
}
;
function processSaleReturns(allSaleRetunDocs, params) {
    return __awaiter(this, void 0, void 0, function* () {
        let docsToPush = [];
        for (var k = 0; k < allSaleRetunDocs.length; k++) {
            if (typeof allSaleRetunDocs[k].doc.info === 'string') {
                continue;
            }
            //computeItem
            let subtotal = 0;
            let cost = 0;
            let profit = 0;
            let quantity = 0;
            var taxes = {};
            for (var l = 0; l < allSaleRetunDocs[k].doc.items.length; l++) {
                computeItem(allSaleRetunDocs[k].doc.items[l], undefined);
                subtotal += allSaleRetunDocs[k].doc.items[l].subtotal;
                cost += allSaleRetunDocs[k].doc.items[l].cost;
                profit += allSaleRetunDocs[k].doc.items[l].profit;
                quantity += allSaleRetunDocs[k].doc.items[l].quantity_purchased;
                for (var t in allSaleRetunDocs[k].doc.items[l].taxes) {
                    var taxAmt = allSaleRetunDocs[k].doc.items[l].taxes[t];
                    if (!taxes[t]) {
                        taxes[t] = taxAmt;
                    }
                    else {
                        taxes[t] += taxAmt;
                    }
                }
            }
            allSaleRetunDocs[k].doc.info.taxDetailed = {};
            allSaleRetunDocs[k].doc.info.taxNames = {};
            allSaleRetunDocs[k].doc.info.hsnTaxes = {};
            getTaxesByPercentageDetailed(allSaleRetunDocs[k].doc.items, allSaleRetunDocs[k].doc.info.taxDetailed, allSaleRetunDocs[k].doc.info.taxNames, allSaleRetunDocs[k].doc.info.hsnTaxes);
            allSaleRetunDocs[k].doc.info.subtotal = subtotal;
            allSaleRetunDocs[k].doc.info.cost = cost;
            allSaleRetunDocs[k].doc.info.profit = profit;
            allSaleRetunDocs[k].doc.info.quantity = quantity;
            allSaleRetunDocs[k].doc.info.taxes = taxes;
            docsToPush.push(allSaleRetunDocs[k].doc);
        }
        yield bulkInsert(params.dbInstance, docsToPush);
    });
}
function getTotalPercent(taxArray, itemId) {
    try {
        var totalTaxPercent = 0;
        if (!taxArray)
            return totalTaxPercent;
        for (var j = 0; j < taxArray.length; j++) {
            var itemTax = taxArray[j];
            if (!itemTax.item_id || itemTax.item_id === itemId) {
                totalTaxPercent += parseFloat(itemTax.percent);
            }
        }
        return totalTaxPercent;
    }
    catch (ex) {
        console.log("ex");
        console.log(ex);
        return totalTaxPercent;
    }
}
function getPriceTaxEx(price, bTaxInclusive, totalTaxPercent) {
    var priceExcludingTax = price;
    if (bTaxInclusive) {
        priceExcludingTax = calculatePriceExcludingTax(price, totalTaxPercent);
    }
    ;
    return priceExcludingTax;
}
;
function calculatePriceExcludingTax(price, taxPercent) {
    var factor = 1 + (taxPercent * 0.01);
    var priceExTax = price / factor;
    return priceExTax;
}
function computepxax0dot01(p, a) {
    return (p * a * 0.01);
}
;
function add(a, b) {
    return (a + b);
}
;
function multiply(a, b) {
    return (a * b);
}
function subtract(a, b) {
    return (a - b);
}
;
function computeTaxAmounts(taxArray, totalWithoutCharges, itemId) {
    var taxAmounts = {
        CGST: 0,
        SGST: 0,
        IGST: 0,
        CESS: 0,
        Total: 0
    };
    for (var j = 0; j < taxArray.length; j++) {
        var itemTax = taxArray[j];
        if (!itemTax.item_id || itemTax.item_id === itemId) {
            taxAmounts[itemTax.name] = computepxax0dot01(itemTax.percent, totalWithoutCharges);
        }
        taxAmounts.Total += taxAmounts[itemTax.name];
    }
    return taxAmounts;
}
function computeItem(itemInfo, iAddGlobalDiscount) {
    if (iAddGlobalDiscount === undefined) {
        //This is for sale return we don't want to include global discount during computation
        iAddGlobalDiscount = 1;
    }
    var info = {};
    info.quantity = parseFloat(itemInfo.quantity_purchased);
    info.itemId = itemInfo.item_id;
    info.sellingPrice = parseFloat(itemInfo.sellingPrice);
    // if (!itemTaxes) {
    var itemTaxes = itemInfo.itemTaxList;
    if (!itemTaxes) {
        itemTaxes = [];
    }
    // }
    var taxPercent = getTotalPercent(itemTaxes, itemInfo.item_id);
    var sellingPriceTaxEx = getPriceTaxEx(info.sellingPrice, itemInfo.bSPTaxInclusive, taxPercent);
    var totalChargesPercent = getTotalPercent(itemInfo.chargesLis, itemInfo.item_idt);
    var totalChargesTaxPercent = getTotalPercent(itemInfo.chargesTaxList, itemInfo.item_id);
    info.discountPercent = itemInfo.discount_percent ? parseFloat(itemInfo.discount_percent) : 0;
    info.discountPercent += itemInfo.gDiscountPercent ? parseFloat(itemInfo.gDiscountPercent) * parseFloat(iAddGlobalDiscount) : 0;
    info.cost = (parseFloat(itemInfo.purchasePrice)) * info.quantity; //purchasePrice is Tax Exclusive. It is precomputed before writing to db
    itemInfo.cost = info.cost;
    info.priceWithoutDiscount = multiply(info.quantity, sellingPriceTaxEx);
    info.discountAmt = computepxax0dot01(info.priceWithoutDiscount, info.discountPercent);
    info.totalWithoutCharges = subtract(info.priceWithoutDiscount, info.discountAmt);
    info.taxes = computeTaxAmounts(itemTaxes, info.totalWithoutCharges, itemInfo.item_id);
    info.chargesAmt = computepxax0dot01(totalChargesPercent, info.totalWithoutCharges);
    info.subTotal = add(info.totalWithoutCharges, info.chargesAmt);
    info.tax = add(computepxax0dot01(taxPercent, info.totalWithoutCharges), computepxax0dot01(totalChargesTaxPercent, info.chargesAmt));
    info.totalTaxPercent = taxPercent;
    info.total = add(info.subTotal, info.tax);
    info.profit = subtract(info.subTotal, info.cost);
    itemInfo.profit = info.profit;
    itemInfo.subtotal = info.subTotal;
    itemInfo.taxes = info.taxes;
    itemInfo.taxes.Total = info.tax;
    // return info;
}
;
function saleBatchProcess(allSalesDocs, params) {
    return __awaiter(this, void 0, void 0, function* () {
        let docsToPush = [];
        for (let j = 0; j < allSalesDocs.length; j++) {
            if (typeof allSalesDocs[j].doc.sales_info === 'string') {
                continue;
            }
            //computeItem
            let subtotal = 0;
            let cost = 0;
            let profit = 0;
            let quantity = 0;
            var taxes = {};
            let sale_info = allSalesDocs[j].doc.sales_info;
            if (sale_info) {
                if (sale_info.type === 3) {
                    continue;
                }
            }
            for (var q = 0; q < allSalesDocs[j].doc.sale_items.length; q++) {
                computeItem(allSalesDocs[j].doc.sale_items[q], undefined);
                subtotal += allSalesDocs[j].doc.sale_items[q].subtotal;
                cost += allSalesDocs[j].doc.sale_items[q].cost;
                profit += allSalesDocs[j].doc.sale_items[q].profit;
                quantity += allSalesDocs[j].doc.sale_items[q].quantity_purchased;
                for (var t in allSalesDocs[j].doc.sale_items[q].taxes) {
                    var taxAmt = allSalesDocs[j].doc.sale_items[q].taxes[t];
                    if (!taxes[t]) {
                        taxes[t] = taxAmt;
                    }
                    else {
                        taxes[t] += taxAmt;
                    }
                }
            }
            allSalesDocs[j].doc.sales_info.taxDetailed = {};
            allSalesDocs[j].doc.sales_info.taxNames = {};
            allSalesDocs[j].doc.sales_info.hsnTaxes = {};
            getTaxesByPercentageDetailed(allSalesDocs[j].doc.sale_items, allSalesDocs[j].doc.sales_info.taxDetailed, allSalesDocs[j].doc.sales_info.taxNames, allSalesDocs[j].doc.sales_info.hsnTaxes);
            allSalesDocs[j].doc.sales_info.subtotal = subtotal;
            allSalesDocs[j].doc.sales_info.cost = cost;
            allSalesDocs[j].doc.sales_info.profit = profit;
            allSalesDocs[j].doc.sales_info.quantity = quantity;
            allSalesDocs[j].doc.sales_info.taxes = taxes;
            docsToPush.push(allSalesDocs[j].doc);
        }
        yield bulkInsert(params.dbInstance, docsToPush);
    });
}
//# sourceMappingURL=201806060000000-saleDocEn.js.map