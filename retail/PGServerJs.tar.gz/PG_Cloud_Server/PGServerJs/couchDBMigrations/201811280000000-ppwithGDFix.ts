/**
 */

'use strict';

let path = require('path');


export const up = async function (params) {
    let logger = params.logger;
    let migrationsBasePath = params.migrationsBasePath;
    const appRootPath = migrationsBasePath + '/../';
    const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
    const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let maindb = nanoClients.maindb;
    let usersdb = nanoClients._users;
    try {
        await batchProcess(1000, 'receiving', processPuchaseDocs, {
            dbInstance: maindb,
            couchDBUtils: couchDBUtils,
            logger: logger
        });
        async function processPuchaseDocs(allPurchases) {
            let docsToPush = [];
            for (let k = 0; k < allPurchases.length; k++) {
                if (typeof allPurchases[k].doc.receivings_info !== 'string' && allPurchases[k].doc.receivings_info.type === 3) {
                    continue;
                }
                allPurchases[k].doc = transformSaleOrPurchaseDoc(allPurchases[k].doc, 'purchase');

                let globalDiscount = allPurchases[k].doc.receivings_info.discount ? allPurchases[k].doc.receivings_info.discount.percent : 0;
                for (let i = 0; i < allPurchases[k].doc.receiving_items.length; i++) {
                    let itemDiscount = allPurchases[k].doc.receiving_items[i].discount ? allPurchases[k].doc.receiving_items[i].discount : 0;
                    let unit = allPurchases[k].doc.receiving_items[i].unitsInfo[allPurchases[k].doc.receiving_items[i].unitId];
                    let totalDiscountPercent = itemDiscount + globalDiscount;
                    unit.purchasePriceWithGDiscount = unit.purchasePrice * (1 - 0.01 * totalDiscountPercent);
                }
                allPurchases[k].doc = await encodeTransDoc(allPurchases[k].doc, 'purchase', maindb, usersdb, couchDBUtils)
                docsToPush.push(allPurchases[k].doc);
            }
            await bulkInsert(maindb, docsToPush, logger);
        }

        await batchProcess(1000, 'receivingReturn', processPuchaseReturnDocs, {
            dbInstance: maindb,
            couchDBUtils: couchDBUtils,
            logger: logger
        });
        async function processPuchaseReturnDocs(allPurchaseReturns) {
            let docsToPush = [];
            for (let k = 0; k < allPurchaseReturns.length; k++) {
                if (typeof allPurchaseReturns[k].doc.info !== 'string' && allPurchaseReturns[k].doc.info.type === 3) {
                    continue;
                }
                allPurchaseReturns[k].doc = transformSaleOrPurchaseDoc(allPurchaseReturns[k].doc, 'purchaseReturn');

                let globalDiscount = allPurchaseReturns[k].doc.info.discount ? allPurchaseReturns[k].doc.info.discount.percent : 0;
                for (let i = 0; i < allPurchaseReturns[k].doc.items.length; i++) {
                    let itemDiscount = allPurchaseReturns[k].doc.items[i].discount ? allPurchaseReturns[k].doc.items[i].discount : 0;
                    let unit = allPurchaseReturns[k].doc.items[i].unitsInfo[allPurchaseReturns[k].doc.items[i].unitId];
                    let totalDiscountPercent = itemDiscount + globalDiscount;
                    unit.purchasePriceWithGDiscount = unit.purchasePrice * (1 - 0.01 * totalDiscountPercent);
                }
                allPurchaseReturns[k].doc = await encodeTransDoc(allPurchaseReturns[k].doc, 'purchaseReturn', maindb, usersdb, couchDBUtils)
                docsToPush.push(allPurchaseReturns[k].doc);
            }
            await bulkInsert(maindb, docsToPush, logger);
        }

    } catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }

};

export const down = async function (params) {

};

async function bulkInsert(db, docsArray, logger) {
    try {
        let resp = await db.bulk({
            docs: docsArray
        });
        return resp;
    } catch (error) {
        logger.error(error);
        throw 'Bulk Update Failed';
    }
};

async function encodeTransDoc(doc, type, maindb, usersdb, couchDBUtils) {
    var infoKey = 'sales_info';
    var itemsKey = 'sale_items';
    let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts', 'discount', 't_no'];
    let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
    if (type === 'saleReturn') {
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts', 'discount', 't_no'];
    } else if (type === 'purchaseReturn') {
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    } else if (type === 'purchase') {
        infoKey = 'receivings_info';
        itemsKey = 'receiving_items';
        infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    }
    if (doc[infoKey].customer_id) {
        var customerInfo = await couchDBUtils.getDoc('customer_' + doc[infoKey].customer_id, maindb);
        var checkCompanyName = customerInfo.company_name ? customerInfo.company_name : '';
        var checkLastName = customerInfo.last_name ? customerInfo.last_name : '';
        doc[infoKey].customer = checkCompanyName + ' ' + customerInfo.first_name + ' ' + checkLastName;
    }
    if (doc[infoKey].employee_id) {
        var empInfo = await couchDBUtils.getDoc('org.couchdb.user:' + doc[infoKey].employee_id, usersdb);
        doc[infoKey].employee = empInfo.first_name ? empInfo.first_name + ' ' + empInfo.last_name : doc[infoKey].employee_id;
    }
    if (doc[infoKey].supplier_id) {
        var supInfo = await couchDBUtils.getDoc('supplier_' + doc[infoKey].supplier_id, maindb);
        var checkCompanyName = supInfo.company_name ? supInfo.company_name : '';
        var checkLastName = supInfo.last_name ? supInfo.last_name : '';
        doc[infoKey].supplier = checkCompanyName + ' ' + supInfo.first_name + ' ' + checkLastName;
    }
    let info = doc[infoKey];
    if (type === 'saleReturn') {
        info.num = doc.id;
    }
    let items = doc[itemsKey];
    let transInfo = doc._id + ';';
    for (let i = 0; i < infoFields.length; i++) {
        let val = getValString(info[infoFields[i]])
        transInfo += val + ';';
    }
    let itemsList = [];
    for (var j = 0; j < items.length; j++) {
        if (!items[j].category) {
            let itemInfo = await couchDBUtils.getDoc('item_' + items[j].item_id, maindb);
            let categoryInfo = await couchDBUtils.getDoc('category_' + itemInfo.info.categoryId, maindb);
            items[j].category = categoryInfo.name;
        }
        let itemString = "";
        for (let k = 0; k < itemFields.length; k++) {
            let fieldVal = getValString(items[j][itemFields[k]])
            itemString += fieldVal + ';';
        }
        itemsList.push(itemString);
    }
    let payments = JSON.stringify(doc.payments);
    doc.payments = payments;
    doc[infoKey] = transInfo;
    doc[itemsKey] = itemsList;
    return doc;

}

function transformSaleOrPurchaseDoc(doc, type) {
    var infoKey = 'sales_info';
    var itemsKey = 'sale_items';
    var idKey = 'sale_id';
    let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts', 'discount', 't_no'];
    let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
    if (type === 'saleReturn') {
        idKey = 'id';
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts', 'discount', 't_no'];
    } else if (type === 'purchaseReturn') {
        idKey = 'id';
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    } else if (type === 'purchase') {
        idKey = 'receiving_id';
        infoKey = 'receivings_info';
        itemsKey = 'receiving_items';
        infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    }

    var items = doc[itemsKey];
    var info = doc[infoKey];
    var itemsArray = [];

    for (var q = 0; q < items.length; q++) {
        var itemVals = items[q].split(';');
        var itemInfo = {};
        for (var iF = 0; iF < itemFields.length; iF++) {
            var val = converValue(itemVals[iF], itemFields[iF]);

            itemInfo[itemFields[iF]] = val;
        }
        itemsArray.push(itemInfo);
    }
    items = itemsArray;
    var salesInfoVals = info.split(';');
    var salesInfo: any = {};
    salesInfo._id = salesInfoVals[0];
    for (var s = 0; s < infoFields.length; s++) {
        var infoVal = converValue(salesInfoVals[s + 1], infoFields[s]);
        salesInfo[infoFields[s]] = infoVal;
    }
    info = salesInfo;
    info[idKey] = doc[idKey];
    doc[infoKey] = info;
    doc[itemsKey] = items;
    doc.payments = JSON.parse(doc.payments);
    return doc

}
var commonFields = ['discount'];
var intFields = ['item_id', 'line', 'imeiCount', 'categoryId', 'num', 'invoiceCheckpoint', 'sale_time', 'receiving_time', 'time', 'supplier_id', 'customer_id', 'pProfileId', 'parentId'];
var floatFields = ['price', 'baseUnitPrice', 'sellingPriceExcludingTax', 'totalTaxPercent', 'totalPurchaseTaxPercent', 'purchasePrice', 'mrp', 'reorder_level', 'total', 'subTotal', 'subtotal', 'cost', 'profit', 'quantity', 'deliveryCharge', 'pending_amount', 'discount', 'discount_percent', 'quantity_purchased', 'sellingPrice', 'gDiscountPercent', 'loyaltyEarned', 'rmPnts'];
var objFields = ['wcInfo', 'slab', 'taxes', 'taxDetailed', 'shippingDetails', 'globalDiscountInfo', 'imeiNumbers', 'unitDocs', 'chargesList', 'chargesTaxList', 'unitsInfo', 'itemTaxList', 'uniqueDetails'];
var boolFields = ['isNew', 'interState', 'is_serialized', 'hasBatchNumber', 'bOTG', 'hasExpiryDate', 'bSPTaxInclusive', 'bPPTaxInclusive', 'isWarranty'];

function converValue(val, key) {
    // var val = itemVals[iF];
    if (commonFields.indexOf(key) !== -1 && bStringifiedJSON(val)) {
        val = JSON.parse(val);
    } else if (intFields.indexOf(key) !== -1) {
        val = val ? parseInt(val) : 0;
    } else if (floatFields.indexOf(key) !== -1) {
        val = val ? parseFloat(val) : 0;
    } else if (objFields.indexOf(key) !== -1) {
        val = val ? JSON.parse(val) : (key === 'wcInfo' ? undefined : {});
    } else if (boolFields.indexOf(key) !== -1) {
        if (val && (val.toLowerCase() === 'yes' || val.toLowerCase() === 'true')) {
            val = true;
        } else {
            val = false;
        }
    }
    return val;
}

function bStringifiedJSON(value) {
    if (!value) {
        return false;
    }
    if (value.indexOf('{') > -1 &&
        value.indexOf('}') > -1 &&
        value.indexOf('":"') > -1 &&
        Object.keys(JSON.parse(value)).length
    ) {
        return true;
    }
    return false;
}
function getValString(val) {
    if (val === undefined || val === null) {
        val = ""
    } else if (typeof val === "object") {
        val = JSON.stringify(val);
    }
    if (typeof val === 'string' && val.indexOf(';') > -1) {
        val = val.replace(';', '');
    }
    return val;
}