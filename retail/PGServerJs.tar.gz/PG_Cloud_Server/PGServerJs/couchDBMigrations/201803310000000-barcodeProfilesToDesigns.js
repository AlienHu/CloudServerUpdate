/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;

        try {
            let nanoClients = params.nanoClients;
            let nanoCore = nanoClients.coredb;
            const appRootPath = params.migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            if (applicationSettings.barcode.profileList && !applicationSettings.barcode.designs) {
                applicationSettings.barcode.designs = applicationSettings.barcode.profileList;
                applicationSettings.barcode.profiles = [];
                delete applicationSettings.barcode.profileList;
            }
            if (applicationSettings.barcode.currentProfile && !applicationSettings.barcode.currentDesign) {
                applicationSettings.barcode.currentDesign = applicationSettings.barcode.currentProfile;
                applicationSettings.barcode.currentProfile = "";
            }
            await couchDBUtils.update(applicationSettings, nanoCore, 2);
        } catch (error) {
            logger.error(error);
            logger.error('barcode profileList to designs update failed');
            throw error;
        }
    },

    down: async function(params) {
        let logger = params.logger;
        try {
            let nanoClients = params.nanoClients;
            let nanoCore = nanoClients.coredb;
            const appRootPath = params.migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            if (applicationSettings.barcode.hasOwnProperty('designs')) {
                applicationSettings.barcode.profileList = applicationSettings.barcode.designs;
                delete applicationSettings.barcode.designs;
                delete applicationSettings.barcode.profiles;
            } else {
                logger.error('not expected to come here. design is missing');
            }
            if (applicationSettings.barcode.hasOwnProperty('currentDesign')) {
                applicationSettings.barcode.currentProfile = applicationSettings.barcode.currentDesign;
                delete applicationSettings.barcode.currentDesign;
            } else {
                logger.error('not expected to come here. currentDesign is missing');
            }
            await couchDBUtils.update(applicationSettings, nanoCore, 2);
        } catch (error) {
            logger.error(error);
            logger.error('barcode profileList from designs update failed');
            throw error;
        }
    }
};