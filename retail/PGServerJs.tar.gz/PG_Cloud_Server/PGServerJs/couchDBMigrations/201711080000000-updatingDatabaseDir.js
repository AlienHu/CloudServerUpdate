/**
 */

'use strict';

var fs = require('fs');
var path = require('path');
const isWin = /^win/.test(process.platform);

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        const httpUtils = require(appRootPath + 'common/httpUtils');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;

        async function getDatabaseDir() {
            let instPathPrefix = '';
            if (isWin) {
                let utils = require(appRootPath + 'common/npmUtils');
                try {
                    instPathPrefix = await utils.getWinCouchInstDir();
                } catch (error) {
                    logger.info('Assuming new couchdb location');
                    instPathPrefix = 'C:/ProfitGuru/CouchDB'
                }
                instPathPrefix = path.resolve(instPathPrefix, 'bin');
            }

            let response = await couchDBUtils.getDatabaseDir();
            if (!path.isAbsolute(response)) {
                response = path.resolve(instPathPrefix, response);
            }
            return response;
        }

        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            applicationSettings.databaseLocation = {
                path: await getDatabaseDir()
            };
            await couchDBUtils.update(applicationSettings, nanoCore);
            await couchDBUtils.updateDatabaseDir(applicationSettings.databaseLocation.path);
        } catch (err) {
            logger.error(err);
            throw migrationName + ' setting migration failed';
        }

    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;

        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            if (applicationSettings.databaseLocation) {
                delete applicationSettings.databaseLocation;
            }
            await couchDBUtils.update(applicationSettings, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' enableSMS setting down migration failed';
        }
    }
};