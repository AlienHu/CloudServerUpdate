/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
let logger;
exports.up = (params) => __awaiter(this, void 0, void 0, function* () {
    logger = params.logger;
    let migrationsBasePath = params.migrationsBasePath;
    const appRootPath = migrationsBasePath + '/../';
    const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
    const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let maindb = nanoClients.maindb;
    try {
        function processCustomerPan(allCustomerDocs, params) {
            return __awaiter(this, void 0, void 0, function* () {
                let docsToPush = [];
                for (var k = 0; k < allCustomerDocs.length; k++) {
                    if (allCustomerDocs[k].doc && allCustomerDocs[k].doc.pan_number != undefined && allCustomerDocs[k].doc.pan_number != null) {
                        let pan_number = allCustomerDocs[k].doc.pan_number + '';
                        if (pan_number != '' && pan_number.length != 10) {
                            allCustomerDocs[k].doc.pan_number = '';
                        }
                    }
                    docsToPush.push(allCustomerDocs[k].doc);
                }
                yield bulkInsert(params.dbInstance, docsToPush);
            });
        }
        yield batchProcess(1000, 'customer', processCustomerPan, {
            dbInstance: maindb,
            couchDBUtils: couchDBUtils,
            logger: logger
        });
        function processSupplierPan(allSupplierDocs, params) {
            return __awaiter(this, void 0, void 0, function* () {
                let docsToPush = [];
                for (var k = 0; k < allSupplierDocs.length; k++) {
                    if (allSupplierDocs[k].doc && allSupplierDocs[k].doc.pan_number != undefined && allSupplierDocs[k].doc.pan_number != null) {
                        let pan_number = allSupplierDocs[k].doc.pan_number + '';
                        if (pan_number != '' && pan_number.length != 10) {
                            allSupplierDocs[k].doc.pan_number = '';
                        }
                    }
                    docsToPush.push(allSupplierDocs[k].doc);
                }
                yield bulkInsert(params.dbInstance, docsToPush);
            });
        }
        yield batchProcess(1000, 'supplier', processSupplierPan, {
            dbInstance: maindb,
            couchDBUtils: couchDBUtils,
            logger: logger
        });
    }
    catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }
});
exports.down = () => __awaiter(this, void 0, void 0, function* () {
    //nothing required
    return;
});
function bulkInsert(db, docsArray) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let resp = yield db.bulk({
                docs: docsArray
            });
            return resp;
        }
        catch (error) {
            logger.error(error);
            throw 'Bulk Update Failed';
        }
    });
}
;
//# sourceMappingURL=201904092000000-removeInvalidPan.js.map