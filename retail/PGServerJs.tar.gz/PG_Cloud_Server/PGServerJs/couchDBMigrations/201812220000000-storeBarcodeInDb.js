'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
let logger;
let maindb;
let couchDBUtils;
const getSystemGeneratedBarcode = (item_id, batch) => {
    let barcode = ':' + item_id;
    let attributeInfo = batch.attributeInfo;
    if (attributeInfo) {
        for (let attributeId in attributeInfo) {
            barcode += ':' + attributeInfo[attributeId];
        }
    }
    return barcode;
};
function processItemsChunk(itemsList) {
    return __awaiter(this, void 0, void 0, function* () {
        for (let i = 0; i < itemsList.length; i++) {
            let thisItem = itemsList[i].doc;
            const batchKeys = Object.keys(thisItem.batches);
            // not checking any variant flags, computation over batches count directly
            for (let j = 0; j < batchKeys.length; j++) {
                let thisBatch = thisItem.batches[batchKeys[j]];
                thisBatch.barcode = getSystemGeneratedBarcode(thisItem.item_id, thisBatch);
            }
            itemsList[i] = thisItem; //assigning doc only
        }
        try {
            let resp = yield couchDBUtils.bulkDocs(itemsList, maindb);
            if (resp) {
                logger.info('Item Barcode Update Success:' + resp);
            }
        }
        catch (err) {
            logger.error('Item Barcode Update Fail:' + err);
            logger.error(itemsList);
        }
    });
}
exports.up = (params) => __awaiter(this, void 0, void 0, function* () {
    logger = params.logger;
    let migrationsBasePath = params.migrationsBasePath;
    const appRootPath = migrationsBasePath + '/../';
    couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
    const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
    let nanoClients = params.nanoClients;
    maindb = nanoClients.maindb; // main is global
    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    yield batchProcess(1000, 'item', processItemsChunk, {
        dbInstance: maindb,
        couchDBUtils: couchDBUtils,
        logger: logger
    });
});
exports.down = () => __awaiter(this, void 0, void 0, function* () {
    return;
});
//# sourceMappingURL=201812220000000-storeBarcodeInDb.js.map