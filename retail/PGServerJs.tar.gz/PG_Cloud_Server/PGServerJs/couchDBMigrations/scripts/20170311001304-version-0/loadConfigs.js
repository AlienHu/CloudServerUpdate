let loadConfigs = async function(params) {

    let logger = params.logger;
    let migrationsBasePath = params.migrationsBasePath;
    let migrationName = params.migrationName;

    const appRootPath = migrationsBasePath + '/../';
    const prepareDocWithAppSpecifics = require(appRootPath + 'couchDb/firstTimeCouchInitHandler').prepareDocWithAppSpecifics;
    const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
    const employeeProfiler = require(appRootPath + 'employees/employeeProfiles.js');

    let nanoClients = params.nanoClients;
    let nanoUsers = nanoClients._users;
    let nanoCore = nanoClients.coredb;

    let promisesArray = [];
    //can use couchdb bulk api as well
    promisesArray.push(loadprofitGuruApplicationSettings());
    promisesArray.push(loadProfitGuruAllowedFeatures());
    promisesArray.push(createDefaultUsers());

    return await Promise.all(promisesArray);

    async function loadprofitGuruApplicationSettings() {
        var settingsFilePath = migrationsBasePath + '/profitguruCoreConfig/' + migrationName + '/profitGuruApplicationSettings.json';
        var applicationSettingsDoc = prepareDocWithAppSpecifics(settingsFilePath);
        applicationSettingsDoc._id = 'profitGuruApplicationSettings_';
        await couchDBUtils.create(applicationSettingsDoc, nanoCore, 1);
    }

    async function loadProfitGuruAllowedFeatures() {
        var featuresFilePath = migrationsBasePath + '/profitguruCoreConfig/' + migrationName + '/profitGuruAllowedFeatures.json';
        var profitGuruAllowedFeaturesDoc = prepareDocWithAppSpecifics(featuresFilePath);
        profitGuruAllowedFeaturesDoc._id = 'profitGuruAllowedFeatures_';
        await couchDBUtils.create(profitGuruAllowedFeaturesDoc, nanoCore, 1);
    }

    function setDefaultPermission(role, revokePermission) {
        if (revokePermission) {
            role.allowNone = true;
            role.viewOnMenu = true;
            role.allowAll = false;
            return;
        }
        role.allowNone = false;
        role.viewOnMenu = true;
        role.allowAll = true;
        return;
    }

    function enableAllEntitlements(allUserEntitlements) {
        for (var role in allUserEntitlements) {
            setDefaultPermission(allUserEntitlements[role], false);
            for (var grant in allUserEntitlements[role]) {
                if (typeof allUserEntitlements[role][grant].allowed !== 'undefined') {
                    allUserEntitlements[role][grant].allowed = true;
                }
            }
        }
    }

    async function createUserWithAdminRole(user) {
        var filePath = migrationsBasePath + '/profitguruCoreConfig/' + migrationName + '/profitGuruUsersAllEntitlements.json';
        let entitlements = prepareDocWithAppSpecifics(filePath);
        employeeProfiler.adminRolePermissions(entitlements);

        user._id = "org.couchdb.user:" + user.name;
        user.type = 'user';
        var rolesJSON = entitlements;
        user.roles.push(JSON.stringify(rolesJSON));
        user.roles.push('admin');

        try {
            await couchDBUtils.create(user, nanoUsers, 1, 'propagate');
        } catch (error) {
            if (error.statusCode === 409) {
                logger.error(error.reason);
                logger.error(user.name + ' create error.  Not throwing error. Giving benefit of doubt, user already created for some other purpose');
            } else {
                throw error;
            }
        }
    }

    function createDefaultUsers() {

        var adminUser = {
            username: 'admin',
            password: 'profitGuru',
            password_again: 'profitGuru',
            passwordHasToBeChanged: true,
            first_name: 'Welcome to',
            last_name: 'ProfitGuru',
            gender: '',
            email: 'abc@xyz.com',
            phone_number: '123-456-789',
            address_1: 'xxxxxxx',
            address_2: 'xx xx xx',
            city: 'Dandeli',
            state: 'Karnataka',
            zip: '581329',
            country: 'India',
            comments: '',
            profile: 'adminProfile',
            name: 'admin',
            roles: []
        };

        var trialUser = {
            username: 'trial',
            password: 'trial',
            password_again: 'trial',
            passwordHasToBeChanged: false,
            first_name: 'Trial',
            last_name: 'Employee',
            gender: '',
            email: 'trialEmployee@alienhu.com',
            phone_number: '9875485611',
            address_1: 'Rajaji Nagar',
            address_2: '281, 11th Cross',
            city: 'Bangalore',
            state: 'Karnataka',
            zip: '581329',
            country: 'India',
            profile: 'adminProfile',
            comments: '',
            name: 'trial',
            roles: []
        };

        return createUserWithAdminRole(adminUser).then(function(resp) {
            if (process.env.IS_DEMO_APP === 'YES') {
                return createUserWithAdminRole(trialUser);
            }
        }).catch(function(err) {
            throw new Error(err);
        });
    }

};

module.exports = async function(params) {
    return loadConfigs(params);
};