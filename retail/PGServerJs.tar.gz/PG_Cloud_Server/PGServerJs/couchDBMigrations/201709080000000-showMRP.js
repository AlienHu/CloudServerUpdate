/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;
        try {

            var params = {};

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);

            applicationSettings.paperReceipt.mrp_display = false;
            applicationSettings.barcode.a4 = false;
            var appSettingsDoc = [applicationSettings];
            await couchDBUtils.bulkInsert(nanoCore, appSettingsDoc);

        } catch (error) {
            logger.error(error);
            throw migrationName + 'up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            var params = {};
            let docsToUpdate = [];

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);

            if (applicationSettings.paperReceipt.hasOwnProperty('mrp_display')) {
                delete applicationSettings.paperReceipt.mrp_display;
            } else {
                logger.error('Not expected to come here');
                logger.error('mrp_display property not found');
            }
            if (applicationSettings.barcode.hasOwnProperty('a4')) {
                delete applicationSettings.barcode.a4;
            } else {
                logger.error('Not expected to come here');
                logger.error('a4 property not found');
            }

            var appSettingsDoc = [applicationSettings];
            await couchDBUtils.bulkInsert(nanoCore, appSettingsDoc);
        } catch (error) {
            logger.error(error);
            logger.error('application settings update failed');
            throw migrationName + "DOwN Failed";
        }
    }
};