/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
exports.up = (params) => __awaiter(this, void 0, void 0, function* () {
    const logger = params.logger;
    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let dbInstance = nanoClients.maindb;
    let skip = 0;
    let totalDeleted = 0;
    try {
        while (true) {
            let resp = (yield dbInstance.fetch({}, {
                include_docs: true,
                limit: 10000,
                skip: skip
            }))[0];
            if (resp.rows.length === 0) {
                break;
            }
            let docs2DeleteArr = [];
            for (let i = 0; i < resp.rows.length; i++) {
                if (Object.keys(resp.rows[i].doc).length !== 2) {
                    continue;
                }
                resp.rows[i].doc._deleted = true;
                docs2DeleteArr.push(resp.rows[i].doc);
            }
            if (docs2DeleteArr.length) {
                yield dbInstance.bulk({
                    docs: docs2DeleteArr
                });
            }
            skip += 10000 - docs2DeleteArr.length;
            totalDeleted += docs2DeleteArr.length;
            logger.silly('skip<' + skip + '> totaldelted<' + totalDeleted + '>');
        }
    }
    catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }
});
exports.down = () => __awaiter(this, void 0, void 0, function* () {
    //nothing required
    return;
});
//# sourceMappingURL=201810230000000-dummydocsdelete.js.map