/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require('fs');
var path = require('path');
exports.up = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        try {
            function subtract(a, b) {
                return (a - b);
            }
            ;
            function getPaymentsTotal(payments) {
                var total = 0;
                for (var i = 0; i < payments.length; i++) {
                    if (payments[i].payment_type === 'Purchase On Credit') {
                        continue;
                    }
                    total += payments[i].payment_amount;
                }
                return total;
            }
            /**sales Multiple units */
            function processPuchaseDocs(allPurchaseDocs) {
                return __awaiter(this, void 0, void 0, function* () {
                    let docsToPush = [];
                    for (var j = 0; j < allPurchaseDocs.length; j++) {
                        var paymentTotal = getPaymentsTotal(allPurchaseDocs[j].doc.payments);
                        var changeDue = subtract(paymentTotal, allPurchaseDocs[j].doc.receivings_info.total);
                        let creditPIdx = -1;
                        for (var p = 0; p < allPurchaseDocs[j].doc.payments.length; p++) {
                            if (allPurchaseDocs[j].doc.payments[p].payment_type === 'Purchase On Credit' && creditPIdx === -1) {
                                creditPIdx = p;
                            }
                        }
                        if (creditPIdx < 0) {
                            continue;
                        }
                        else {
                            if (allPurchaseDocs[j].doc.payments.length > 1) {
                                if (allPurchaseDocs[j].doc.payments[0].payment_type === 'Purchase On Credit') {
                                    allPurchaseDocs[j].doc.payments[0].payment_amount = allPurchaseDocs[j].doc.receivings_info.total - paymentTotal;
                                }
                            }
                            else if (allPurchaseDocs[j].doc.payments.length === 1) {
                                allPurchaseDocs[j].doc.payments[0].payment_amount = allPurchaseDocs[j].doc.receivings_info.total;
                            }
                        }
                        docsToPush.push(allPurchaseDocs[j].doc);
                    }
                    yield couchDBUtils.bulkInsert(maindb, docsToPush);
                });
            }
            yield batchProcess(1000, 'receiving', processPuchaseDocs, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            //sales return 
            yield batchProcess(1000, 'receivingReturn', processPuchaseReturnDocs, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            function processPuchaseReturnDocs(allPurchaseRetunDocs) {
                return __awaiter(this, void 0, void 0, function* () {
                    let docsToPush = [];
                    for (var k = 0; k < allPurchaseRetunDocs.length; k++) {
                        var paymentTotal = getPaymentsTotal(allPurchaseRetunDocs[k].doc.payments);
                        var changeDue = subtract(paymentTotal, allPurchaseRetunDocs[k].doc.info.total);
                        let creditPIdx = -1;
                        for (var p = 0; p < allPurchaseRetunDocs[k].doc.payments.length; p++) {
                            if (allPurchaseRetunDocs[k].doc.payments[p].payment_type === 'Purchase On Credit') {
                                creditPIdx = p;
                            }
                        }
                        if (creditPIdx < 0) {
                            continue;
                        }
                        else {
                            if (allPurchaseRetunDocs[k].doc.payments.length > 1) {
                                if (allPurchaseRetunDocs[k].doc.payments[0].payment_type === 'Purchase On Credit') {
                                    allPurchaseRetunDocs[k].doc.payments[0].payment_amount = allPurchaseRetunDocs[k].doc.info.total - paymentTotal;
                                }
                            }
                            else if (allPurchaseRetunDocs[k].doc.payments.length === 1) {
                                allPurchaseRetunDocs[k].doc.payments[0].payment_amount = allPurchaseRetunDocs[k].doc.info.total;
                            }
                        }
                        docsToPush.push(allPurchaseRetunDocs[k].doc);
                    }
                    yield couchDBUtils.bulkInsert(maindb, docsToPush);
                });
            }
        }
        catch (err) {
            logger.error(err);
            throw migrationName + ' up migration failed';
        }
    });
};
exports.down = function () {
    return __awaiter(this, void 0, void 0, function* () {
    });
};
//# sourceMappingURL=201806230000000-purhaseOnCreditNullErrorFix.js.map