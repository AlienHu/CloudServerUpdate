/**
 */

'use strict';

var fs = require('fs');
var path = require('path');
var APP_TYPE = process.env.APP_TYPE;

var adminUser = {
    username: 'admin_' + APP_TYPE,
    name: 'admin_' + APP_TYPE,
    APP_TYPE: APP_TYPE,
    password: 'profitGuru',
    password_again: 'profitGuru',
    isDefaultAdmin: true,
    passwordHasToBeChanged: true,
    first_name: 'Welcome to',
    last_name: 'ProfitGuru',
    gender: '',
    email: APP_TYPE + '@xyz.com',
    phone_number: '',
    address_1: 'xxxxxxx-1',
    address_2: 'xx xx xx',
    city: 'Dandeli',
    state: 'Karnataka',
    zip: '581329',
    country: 'India',
    comments: '',
    profile: 'adminProfile',
    isDistributor: false,
    distributorEmail: '',
    roles: []
};

module.exports = {
    up: async function(params) {

        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoUsers = nanoClients._users;
        let adminDoc;
        try {
            var params = {};
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            var allUsersDoc = [];
            let bUpdate = false;
            for (var i = 0; i < allUsers.length; i++) {
                if (allUsers[i].value._id === 'org.couchdb.user:admin') {
                    adminDoc = allUsers[i].value;
                    if (!allUsers[i].value.hasOwnProperty('isDefaultAdmin')) {
                        allUsers[i].value.isDefaultAdmin = true;
                        bUpdate = true;
                    }
                }
                if (!allUsers[i].value.hasOwnProperty('APP_TYPE')) {
                    allUsers[i].value.APP_TYPE = APP_TYPE;
                    bUpdate = true;
                }
                allUsersDoc.push(allUsers[i].value);
            }
            if (bUpdate)
                await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);
        } catch (error) {
            logger.error(error);
            throw migrationName + ' migration failed';
        }

        if (adminDoc && adminDoc.APP_TYPE !== APP_TYPE) {
            try {
                logger.info('info: creating new User');
                const prepareDocWithAppSpecifics = require(appRootPath + 'couchDb/firstTimeCouchInitHandler').prepareDocWithAppSpecifics;
                const employeeProfiler = require(appRootPath + 'employees/employeeProfiles.js');
                var filePath = migrationsBasePath + '/profitguruCoreConfig/20170311001304-version-0/profitGuruUsersAllEntitlements.json';
                let entitlements = prepareDocWithAppSpecifics(filePath);
                employeeProfiler.adminRolePermissions(entitlements);
                let user = adminUser;
                logger.info(user);
                user._id = "org.couchdb.user:" + user.name;
                user.type = 'user';
                var rolesJSON = entitlements;
                user.roles.push(JSON.stringify(rolesJSON));
                user.roles.push('admin');
                try {
                    await couchDBUtils.create(user, nanoUsers, 1, 'propagate');
                } catch (error) {
                    if (error.statusCode === 409) {
                        logger.error("Not expected to come here");
                        logger.error(error.reason);
                        logger.error(user.name + ' create error.  Not throwing error. Giving benefit of doubt, user already created for some other purpose');
                    }
                    throw error;

                }

            } catch (error) {
                logger.error(error);
                throw migrationName + ' migration failed';
            }

        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoUsers = nanoClients._users;

        try {
            var params = {};
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            var allUsersDoc = [];
            let bUpdate = false;
            for (var i = 0; i < allUsers.length; i++) {
                if (allUsers[i].value._id.indexOf('org.couchdb.user:admin_' + APP_TYPE) == 0) {
                    //deleting the adminuser with _appType
                    await couchDBUtils.delete(allUsers[i].value, nanoUsers, 2);
                    continue;
                }

                if (allUsers[i].value._id === 'org.couchdb.user:admin') {
                    if (allUsers[i].value.hasOwnProperty('isDefaultAdmin')) {
                        delete allUsers[i].value.isDefaultAdmin
                        bUpdate = true;
                    }
                }

                if (-1 < allUsers[i].value._id.indexOf('org.couchdb.user:admin') && allUsers[i].value.hasOwnProperty('isDefaultAdmin')) {
                    if (allUsers[i].value.hasOwnProperty('isDefaultAdmin')) {
                        delete allUsers[i].value.isDefaultAdmin
                        bUpdate = true;
                    }
                }

                if (allUsers[i].value.hasOwnProperty('APP_TYPE')) {
                    delete allUsers[i].value.APP_TYPE;
                    bUpdate = true;
                }
                allUsersDoc.push(allUsers[i].value);
            }
            if (bUpdate)
                await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);
        } catch (error) {
            logger.error(error);
            throw migrationName + ' migration down failed';
        }

    }
};