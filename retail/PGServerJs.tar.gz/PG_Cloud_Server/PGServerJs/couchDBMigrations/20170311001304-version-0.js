/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        try {
            await require(__dirname + '/scripts/' + params.migrationName + '/loadConfigs.js')(params);
        } catch (error) {
            logger.error(error);
            throw migrationName + ' migration failed';
        }
    },

    down: async function(params) {
        console.log('down' + __filename);
    }
};