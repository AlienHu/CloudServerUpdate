/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
let logger;
exports.up = (params) => __awaiter(this, void 0, void 0, function* () {
    logger = params.logger;
    let migrationsBasePath = params.migrationsBasePath;
    const appRootPath = migrationsBasePath + '/../';
    const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
    const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let maindb = nanoClients.maindb;
    let usersdb = nanoClients._users;
    const taxLib = require('./libraries/taxDetailsCommon');
    const getTaxesByPercentageDetailed = taxLib.getTaxesByPercentageDetailed;
    try {
        function processSaleReturns(allSaleRetunDocs, params) {
            return __awaiter(this, void 0, void 0, function* () {
                let docsToPush = [];
                for (var k = 0; k < allSaleRetunDocs.length; k++) {
                    if (typeof allSaleRetunDocs[k].doc.info !== 'string' && allSaleRetunDocs[k].doc.info.type === 3) {
                        continue;
                    }
                    console.log(allSaleRetunDocs[k].id);
                    allSaleRetunDocs[k].doc = transformSaleOrPurchaseDoc(allSaleRetunDocs[k].doc, 'saleReturn');
                    allSaleRetunDocs[k].doc.info.taxDetailed = {};
                    allSaleRetunDocs[k].doc.info.taxNames = {};
                    allSaleRetunDocs[k].doc.info.hsnTaxes = {};
                    getTaxesByPercentageDetailed(allSaleRetunDocs[k].doc.items, allSaleRetunDocs[k].doc.info.taxDetailed, allSaleRetunDocs[k].doc.info.taxNames, allSaleRetunDocs[k].doc.info.hsnTaxes);
                    allSaleRetunDocs[k].doc = yield encodeTransDoc(allSaleRetunDocs[k].doc, 'saleReturn', maindb, usersdb, couchDBUtils);
                    docsToPush.push(allSaleRetunDocs[k].doc);
                }
                yield bulkInsert(params.dbInstance, docsToPush);
            });
        }
        yield batchProcess(1000, 'saleReturn', processSaleReturns, {
            dbInstance: maindb,
            couchDBUtils: couchDBUtils,
            logger: logger
        });
        function processPurchaseReturns(allPurchaseRetunDocs, params) {
            return __awaiter(this, void 0, void 0, function* () {
                let docsToPush = [];
                for (var k = 0; k < allPurchaseRetunDocs.length; k++) {
                    if (typeof allPurchaseRetunDocs[k].doc.info !== 'string' && allPurchaseRetunDocs[k].doc.info.type === 3) {
                        continue;
                    }
                    console.log(allPurchaseRetunDocs[k].id);
                    allPurchaseRetunDocs[k].doc = transformSaleOrPurchaseDoc(allPurchaseRetunDocs[k].doc, 'purchaseReturn');
                    allPurchaseRetunDocs[k].doc.info.taxDetailed = {};
                    allPurchaseRetunDocs[k].doc.info.taxNames = {};
                    allPurchaseRetunDocs[k].doc.info.hsnTaxes = {};
                    getTaxesByPercentageDetailed(allPurchaseRetunDocs[k].doc.items, allPurchaseRetunDocs[k].doc.info.taxDetailed, allPurchaseRetunDocs[k].doc.info.taxNames, allPurchaseRetunDocs[k].doc.info.hsnTaxes);
                    allPurchaseRetunDocs[k].doc = yield encodeTransDoc(allPurchaseRetunDocs[k].doc, 'purchaseReturn', maindb, usersdb, couchDBUtils);
                    docsToPush.push(allPurchaseRetunDocs[k].doc);
                }
                yield bulkInsert(params.dbInstance, docsToPush);
            });
        }
        yield batchProcess(1000, 'receivingReturn', processPurchaseReturns, {
            dbInstance: maindb,
            couchDBUtils: couchDBUtils,
            logger: logger
        });
    }
    catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }
});
exports.down = () => __awaiter(this, void 0, void 0, function* () {
    //nothing required
    return;
});
function encodeTransDoc(doc, type, maindb, usersdb, couchDBUtils) {
    return __awaiter(this, void 0, void 0, function* () {
        var infoKey = 'sales_info';
        var itemsKey = 'sale_items';
        /**
         * whene you change the fields array or encodeTransDoc or transformSalesDoc change in the following places as well
         * 1.commolib (currentfile)
         * 2. maindbViews (2 places ) : update_customer view and delta_pending_amount
         * 3. computeUtils in profitGuruCore/Services/Reports/
         */
        let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts', 'discount', 't_no'];
        let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
        if (type === 'saleReturn') {
            infoKey = 'info';
            itemsKey = 'items';
            infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts', 'discount', 't_no'];
        }
        else if (type === 'purchaseReturn') {
            infoKey = 'info';
            itemsKey = 'items';
            infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
            itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
        }
        else if (type === 'purchase') {
            infoKey = 'receivings_info';
            itemsKey = 'receiving_items';
            infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
            itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
        }
        if (doc[infoKey].customer_id) {
            var customerInfo = yield couchDBUtils.getDoc('customer_' + doc[infoKey].customer_id, maindb);
            var checkCompanyName = customerInfo.company_name ? customerInfo.company_name : '';
            var checkLastName = customerInfo.last_name ? customerInfo.last_name : '';
            doc[infoKey].customer = checkCompanyName + ' ' + customerInfo.first_name + ' ' + checkLastName;
        }
        if (doc[infoKey].employee_id) {
            var empInfo = yield couchDBUtils.getDoc('org.couchdb.user:' + doc[infoKey].employee_id, usersdb);
            doc[infoKey].employee = empInfo.first_name ? empInfo.first_name + ' ' + empInfo.last_name : doc[infoKey].employee_id;
        }
        if (doc[infoKey].supplier_id) {
            var supInfo = yield couchDBUtils.getDoc('supplier_' + doc[infoKey].supplier_id, maindb);
            var checkCompanyName = supInfo.company_name ? supInfo.company_name : '';
            var checkLastName = supInfo.last_name ? supInfo.last_name : '';
            doc[infoKey].supplier = checkCompanyName + ' ' + supInfo.first_name + ' ' + checkLastName;
        }
        let info = doc[infoKey];
        if (type === 'saleReturn') {
            info.num = doc.id;
        }
        let items = doc[itemsKey];
        let transInfo = doc._id + ';';
        for (let i = 0; i < infoFields.length; i++) {
            let val = getValString(info[infoFields[i]]);
            transInfo += val + ';';
        }
        let itemsList = [];
        for (var j = 0; j < items.length; j++) {
            if (!items[j].category) {
                let itemInfo = yield couchDBUtils.getDoc('item_' + items[j].item_id, maindb);
                let categoryInfo = yield couchDBUtils.getDoc('category_' + itemInfo.info.categoryId, maindb);
                items[j].category = categoryInfo.name;
            }
            let itemString = "";
            for (let k = 0; k < itemFields.length; k++) {
                let fieldVal = getValString(items[j][itemFields[k]]);
                itemString += fieldVal + ';';
            }
            itemsList.push(itemString);
        }
        let payments = JSON.stringify(doc.payments);
        doc.payments = payments;
        doc[infoKey] = transInfo;
        doc[itemsKey] = itemsList;
        return doc;
    });
}
function transformSaleOrPurchaseDoc(doc, type) {
    var infoKey = 'sales_info';
    var itemsKey = 'sale_items';
    var idKey = 'sale_id';
    let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts', 'discount', 't_no'];
    let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
    if (type === 'saleReturn') {
        idKey = 'id';
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts', 'discount', 't_no'];
    }
    else if (type === 'purchaseReturn') {
        idKey = 'id';
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    }
    else if (type === 'purchase') {
        idKey = 'receiving_id';
        infoKey = 'receivings_info';
        itemsKey = 'receiving_items';
        infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    }
    var items = doc[itemsKey];
    var info = doc[infoKey];
    var itemsArray = [];
    for (var q = 0; q < items.length; q++) {
        var itemVals = items[q].split(';');
        var itemInfo = {};
        for (var iF = 0; iF < itemFields.length; iF++) {
            var val = converValue(itemVals[iF], itemFields[iF]);
            itemInfo[itemFields[iF]] = val;
        }
        itemsArray.push(itemInfo);
    }
    items = itemsArray;
    var salesInfoVals = info.split(';');
    var salesInfo = {};
    salesInfo._id = salesInfoVals[0];
    for (var s = 0; s < infoFields.length; s++) {
        var infoVal = converValue(salesInfoVals[s + 1], infoFields[s]);
        salesInfo[infoFields[s]] = infoVal;
    }
    info = salesInfo;
    info[idKey] = doc[idKey];
    doc[infoKey] = info;
    doc[itemsKey] = items;
    doc.payments = JSON.parse(doc.payments);
    return doc;
}
var commonFields = ['discount'];
var intFields = ['item_id', 'line', 'imeiCount', 'categoryId', 'num', 'invoiceCheckpoint', 'sale_time', 'receiving_time', 'time', 'supplier_id', 'customer_id', 'pProfileId', 'parentId'];
var floatFields = ['price', 'baseUnitPrice', 'sellingPriceExcludingTax', 'totalTaxPercent', 'totalPurchaseTaxPercent', 'purchasePrice', 'mrp', 'reorder_level', 'total', 'subTotal', 'subtotal', 'cost', 'profit', 'quantity', 'deliveryCharge', 'pending_amount', 'discount', 'discount_percent', 'quantity_purchased', 'sellingPrice', 'gDiscountPercent', 'loyaltyEarned', 'rmPnts'];
var objFields = ['wcInfo', 'slab', 'taxes', 'taxDetailed', 'shippingDetails', 'globalDiscountInfo', 'imeiNumbers', 'unitDocs', 'chargesList', 'chargesTaxList', 'unitsInfo', 'itemTaxList', 'uniqueDetails'];
var boolFields = ['isNew', 'interState', 'is_serialized', 'hasBatchNumber', 'bOTG', 'hasExpiryDate', 'bSPTaxInclusive', 'bPPTaxInclusive', 'isWarranty'];
function converValue(val, key) {
    // var val = itemVals[iF];
    if (commonFields.indexOf(key) !== -1 && bStringifiedJSON(val)) {
        val = JSON.parse(val);
    }
    else if (intFields.indexOf(key) !== -1) {
        val = val ? parseInt(val) : 0;
    }
    else if (floatFields.indexOf(key) !== -1) {
        val = val ? parseFloat(val) : 0;
    }
    else if (objFields.indexOf(key) !== -1) {
        val = val ? JSON.parse(val) : (key === 'wcInfo' ? undefined : {});
    }
    else if (boolFields.indexOf(key) !== -1) {
        if (val && (val.toLowerCase() === 'yes' || val.toLowerCase() === 'true')) {
            val = true;
        }
        else {
            val = false;
        }
    }
    return val;
}
function bStringifiedJSON(value) {
    if (!value) {
        return false;
    }
    if (value.indexOf('{') > -1 &&
        value.indexOf('}') > -1 &&
        value.indexOf('":"') > -1 &&
        Object.keys(JSON.parse(value)).length) {
        return true;
    }
    return false;
}
function getValString(val) {
    if (val === undefined || val === null) {
        val = "";
    }
    else if (typeof val === "object") {
        val = JSON.stringify(val);
    }
    if (typeof val === 'string' && val.indexOf(';') > -1) {
        val = val.replace(';', '');
    }
    return val;
}
function bulkInsert(db, docsArray) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let resp = yield db.bulk({
                docs: docsArray
            });
            return resp;
        }
        catch (error) {
            logger.error(error);
            throw 'Bulk Update Failed';
        }
    });
}
;
//# sourceMappingURL=201902020000000-returnDetailedTaxCalculationBug.js.map