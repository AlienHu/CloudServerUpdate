'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var path = require('path');
let infectedItems = [];
let infectedCategories = [];
let infectedCustomers = [];
let infectedSuppliers = [];
let infectedEmployees = [];
let errorsArray = [];
let allEmployees;
let allUpdatedSale = [];
let allUpdatedSaleReturn = [];
let allUpdatedPurchase = [];
let allUpdatedRecivingReturns = [];
let logger;
let infectedItemNameArr = [];
let infectedCategoryNameArr = [];
let infectedCustomerDisplayNameArr = [];
let infectedEmployeeNameArr = [];
let infectedSupplierDisplayNameArr = [];
const utils = require('../controllers/common/Utils');
const CLONE = utils.clone;
exports.up = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        const userdb = nanoClients._users;
        //returnAmt
        try {
            //item, category, employee, customer - get docs in batches, find semicolon, if infected update and keep it in array.
            //update all sales in batch
            //try to parse the sales_info and sale_items -> you should not get any error
            allEmployees = yield getAllUserDocs(userdb, {}, false, logger);
            yield batchProcess(1000, 'item', processItemsChunk, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            yield batchProcess(1000, 'category', parseCategoryChunk, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            yield batchProcess(1000, 'customer', parseElementChunk, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            yield batchProcess(1000, 'supplier', parseElementChunk, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            yield parseEmployees();
            yield parseAllTransactions();
            function parseAllTransactions() {
                return __awaiter(this, void 0, void 0, function* () {
                    yield getAndParseAllSales();
                    yield getAndParseAllSalesReturn();
                    yield getAndParseAllPurchase();
                    yield getAndParseAllPurchaseReturn();
                    yield updateDocs(maindb, userdb, couchDBUtils);
                });
            }
            function getAndParseAllSales() {
                return __awaiter(this, void 0, void 0, function* () {
                    yield batchProcess(1000, 'sale', processSaleBatch, {
                        dbInstance: maindb,
                        couchDBUtils: couchDBUtils,
                        logger: logger
                    });
                });
            }
            ;
            function getAndParseAllSalesReturn() {
                return __awaiter(this, void 0, void 0, function* () {
                    let getAndParseAllSalesReturnErrorsArray = [];
                    yield batchProcess(1000, 'saleReturn', processSaleReturnBatch, {
                        dbInstance: maindb,
                        couchDBUtils: couchDBUtils,
                        logger: logger
                    });
                });
            }
            ;
            function getAndParseAllPurchase() {
                return __awaiter(this, void 0, void 0, function* () {
                    yield batchProcess(1000, 'receiving', processPurchaseBatch, {
                        dbInstance: maindb,
                        couchDBUtils: couchDBUtils,
                        logger: logger
                    });
                });
            }
            ;
            function getAndParseAllPurchaseReturn() {
                return __awaiter(this, void 0, void 0, function* () {
                    yield batchProcess(1000, 'receivingReturn', processPurchaseReturnBatch, {
                        dbInstance: maindb,
                        couchDBUtils: couchDBUtils,
                        logger: logger
                    });
                });
            }
            ;
        }
        catch (err) {
            logger.error(err);
            throw migrationName + ' up migration failed';
        }
    });
};
exports.down = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
    });
};
function processItemsChunk(chunk) {
    return __awaiter(this, void 0, void 0, function* () {
        for (let i = 0; i < chunk.length; i++) {
            if (chunk[i].doc.info.name.indexOf(';') > -1) {
                infectedItems.push(chunk[i]);
                infectedItemNameArr.push('<Name: >' + chunk[i].doc.info.name + ' <ID > ' + chunk[i].doc._id);
            }
        }
    });
}
function parseCategoryChunk(chunk) {
    return __awaiter(this, void 0, void 0, function* () {
        for (let i = 0; i < chunk.length; i++) {
            if (chunk[i].doc.name.indexOf(';') > -1) {
                infectedCategories.push(chunk[i]);
                infectedCategoryNameArr.push('<Category Name: >' + chunk[i].doc.name + ' <ID > ' + chunk[i].doc._id);
            }
        }
    });
}
function parseElementChunk(chunk) {
    return __awaiter(this, void 0, void 0, function* () {
        for (let i = 0; i < chunk.length; i++) {
            let companyName = chunk[i].doc.company_name ? chunk[i].doc.company_name : '';
            let lastName = chunk[i].doc.last_name ? chunk[i].doc.last_name : '';
            let fullName = companyName + ' ' + chunk[i].doc.first_name + ' ' + lastName;
            if (fullName.indexOf(';') > -1) {
                if (chunk[i].doc._id.indexOf('customer') > -1) {
                    infectedCustomers.push(chunk[i]);
                    infectedCustomerDisplayNameArr.push('<Customer Name: >' + chunk[i].doc.first_name + ' <ID > ' + chunk[i].doc._id);
                }
                else {
                    infectedSuppliers.push(chunk[i]);
                    infectedSupplierDisplayNameArr.push('<Supplier Name: >' + chunk[i].doc.first_name + ' <ID > ' + chunk[i].doc._id);
                }
            }
        }
    });
}
function parseEmployees() {
    return __awaiter(this, void 0, void 0, function* () {
        for (let i = 0; i < allEmployees.length; i++) {
            if (allEmployees[i].doc.APP_TYPE !== process.env.APP_TYPE) {
                continue;
            }
            let employeeFullName = allEmployees[i].doc.first_name;
            if (allEmployees[i].doc.last_name) {
                employeeFullName += ' ' + allEmployees[i].doc.last_name;
            }
            if (employeeFullName.indexOf(';') > -1 || allEmployees[i].doc.name.indexOf(';') > -1 || allEmployees[i].doc.username.indexOf(';') > -1) {
                infectedEmployees.push(allEmployees[i]);
                infectedEmployeeNameArr.push('<Employye Name: >' + allEmployees[i].doc.name + ' <ID > ' + allEmployees[i].doc._id);
            }
        }
    });
}
var commonFields = ['discount'];
var intFields = ['item_id', 'line', 'imeiCount', 'categoryId', 'num', 'invoiceCheckpoint', 'sale_time', 'receiving_time', 'time', 'supplier_id', 'customer_id', 'pProfileId', 'parentId'];
var floatFields = ['price', 'baseUnitPrice', 'sellingPriceExcludingTax', 'totalTaxPercent', 'totalPurchaseTaxPercent', 'purchasePrice', 'mrp', 'reorder_level', 'total', 'subTotal', 'subtotal', 'cost', 'profit', 'quantity', 'deliveryCharge', 'pending_amount', 'discount', 'discount_percent', 'quantity_purchased', 'sellingPrice', 'gDiscountPercent', 'loyaltyEarned', 'rmPnts'];
var objFields = ['wcInfo', 'slab', 'taxes', 'taxDetailed', 'shippingDetails', 'globalDiscountInfo', 'imeiNumbers', 'unitDocs', 'chargesList', 'chargesTaxList', 'unitsInfo', 'itemTaxList', 'uniqueDetails'];
var boolFields = ['isNew', 'interState', 'is_serialized', 'hasBatchNumber', 'bOTG', 'hasExpiryDate', 'bSPTaxInclusive', 'bPPTaxInclusive', 'isWarranty'];
function bStringifiedJSON(value) {
    if (!value) {
        return false;
    }
    if (value.indexOf('{') > -1 &&
        value.indexOf('}') > -1 &&
        value.indexOf('":"') > -1 &&
        Object.keys(JSON.parse(value)).length) {
        return true;
    }
    return false;
}
function converValue(val, key) {
    // var val = itemVals[iF];
    if (commonFields.indexOf(key) !== -1 && bStringifiedJSON(val)) {
        val = JSON.parse(val);
    }
    else if (intFields.indexOf(key) !== -1) {
        val = val ? parseInt(val) : 0;
    }
    else if (floatFields.indexOf(key) !== -1) {
        val = val ? parseFloat(val) : 0;
    }
    else if (objFields.indexOf(key) !== -1) {
        val = val ? JSON.parse(val) : (key === 'wcInfo' ? undefined : {});
    }
    else if (boolFields.indexOf(key) !== -1) {
        if (val && (val.toLowerCase() === 'yes' || val.toLowerCase() === 'true')) {
            val = true;
        }
        else {
            val = false;
        }
    }
    return val;
}
function transformSaleOrPurchaseDoc(doc, type) {
    var infoKey = 'sales_info';
    var itemsKey = 'sale_items';
    var idKey = 'sale_id';
    let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts', 'discount', 't_no'];
    let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
    if (type === 'saleReturn') {
        idKey = 'id';
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts', 'discount', 't_no'];
    }
    else if (type === 'purchaseReturn') {
        idKey = 'id';
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    }
    else if (type === 'purchase') {
        idKey = 'receiving_id';
        infoKey = 'receivings_info';
        itemsKey = 'receiving_items';
        infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    }
    var items = doc[itemsKey];
    var info = doc[infoKey];
    var itemsArray = [];
    try {
        for (var q = 0; q < items.length; q++) {
            var itemVals = items[q].split(';');
            var itemInfo = {};
            for (var iF = 0; iF < itemFields.length; iF++) {
                var val = converValue(itemVals[iF], itemFields[iF]);
                itemInfo[itemFields[iF]] = val;
            }
            itemsArray.push(itemInfo);
        }
        items = itemsArray;
        var salesInfoVals = info.split(';');
        var salesInfo = {
            _id: salesInfoVals[0]
        };
        // salesInfo._id = salesInfoVals[0];
        for (var s = 0; s < infoFields.length; s++) {
            var infoVal = converValue(salesInfoVals[s + 1], infoFields[s]);
            salesInfo[infoFields[s]] = infoVal;
        }
        info = salesInfo;
        info[idKey] = doc[idKey];
        doc[infoKey] = info;
        doc[itemsKey] = items;
        doc.payments = JSON.parse(doc.payments);
        return doc;
    }
    catch (error) {
        errorsArray.push(doc);
    }
}
function getAllUserDocs(db, params, bOnlyDocs, logger) {
    return __awaiter(this, void 0, void 0, function* () {
        var type = "org.couchdb.user";
        params = params || {};
        params.startkey = type + '';
        params.endkey = type + '_';
        params.include_docs = true;
        try {
            let [body, header] = yield db.fetch({}, params);
            if (!bOnlyDocs) {
                return body.rows;
            }
            else {
                //This is just wasting of 1 for loop for the inconvinience of having to write body.rows[i].doc everytime
                //Bad don't use it
                let resp = [];
                for (let i = 0; i < body.rows.length; i++) {
                    let doc = body.rows[i].doc;
                    resp.push(doc);
                }
                return resp;
            }
        }
        catch (err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        }
    });
}
function updateDocs(maindb, userdb, couchDBUtils) {
    return __awaiter(this, void 0, void 0, function* () {
        /**
        let allUpdatedSale = [];
    let allUpdatedSaleReturn = [];
        */
        logger.error(infectedItemNameArr);
        logger.error(infectedCategoryNameArr);
        logger.error(infectedCustomerDisplayNameArr);
        logger.error(infectedEmployeeNameArr);
        logger.error(infectedSupplierDisplayNameArr);
        yield processTransDocsAndUpdate(allUpdatedSale, 'sale', maindb, couchDBUtils);
        yield processTransDocsAndUpdate(allUpdatedSaleReturn, 'saleReturn', maindb, couchDBUtils);
        yield processTransDocsAndUpdate(allUpdatedPurchase, 'purchase', maindb, couchDBUtils);
        yield processTransDocsAndUpdate(allUpdatedRecivingReturns, 'purchaseReturn', maindb, couchDBUtils);
        yield processAndUpdateItemDocs(infectedItems, maindb, couchDBUtils);
        yield processAndUpdateCategoryDocs(infectedCategories, maindb, couchDBUtils);
        yield processAndUpdateCustomerDocs(infectedCustomers, maindb, couchDBUtils, 'customer');
        yield processAndUpdateCustomerDocs(infectedSuppliers, maindb, couchDBUtils, 'supplier');
        yield processAndUpdateEmployeeDocs(infectedEmployees, userdb, couchDBUtils);
    });
}
;
function processTransDocsAndUpdate(docs, type, maindb, couchDBUtils) {
    return __awaiter(this, void 0, void 0, function* () {
        if (docs.length) {
            for (let i = 0; i < docs.length; i++) {
                yield transformSaleOrPurchaseDoc(CLONE(docs[i]), type);
            }
            try {
                let resp = yield couchDBUtils.bulkDocs(docs, maindb);
                if (resp) {
                    logger.info(type + ' Update Success:' + resp);
                }
            }
            catch (err) {
                logger.error(type + ' Update Fail:' + err);
                logger.error(docs);
            }
        }
    });
}
function processAndUpdateItemDocs(infectedItems, maindb, couchDBUtils) {
    return __awaiter(this, void 0, void 0, function* () {
        if (infectedItems.length) {
            let itemDocs2Update = [];
            for (let i = 0; i < infectedItems.length; i++) {
                infectedItems[i].doc.info.name = infectedItems[i].doc.info.name.replace(';', '');
                itemDocs2Update.push(infectedItems[i].doc);
            }
            try {
                let resp = yield couchDBUtils.bulkDocs(itemDocs2Update, maindb);
                if (resp) {
                    logger.info('Item Update Success:' + resp);
                }
            }
            catch (err) {
                logger.error('Item Update Fail:' + err);
                logger.error(infectedItems);
            }
        }
        ;
    });
}
function processAndUpdateCategoryDocs(infectedCategories, maindb, couchDBUtils) {
    return __awaiter(this, void 0, void 0, function* () {
        if (infectedCategories.length) {
            let categoryDocs2Update = [];
            for (let i = 0; i < infectedCategories.length; i++) {
                infectedCategories[i].doc.name = infectedCategories[i].doc.name.replace(';', '');
                categoryDocs2Update.push(infectedCategories[i].doc);
            }
            try {
                let resp = yield couchDBUtils.bulkDocs(categoryDocs2Update, maindb);
                if (resp) {
                    logger.info('Category Update Success:' + resp);
                }
            }
            catch (err) {
                logger.error('Category Update Fail:' + err);
                logger.error(infectedCategories);
            }
        }
        ;
    });
}
function processAndUpdateCustomerDocs(infectedElementDocs, maindb, couchDBUtils, type) {
    return __awaiter(this, void 0, void 0, function* () {
        if (infectedElementDocs.length) {
            let elementsToUpdate = [];
            for (let i = 0; i < infectedElementDocs.length; i++) {
                infectedElementDocs[i].doc.first_name = infectedElementDocs[i].doc.first_name.replace(';', '');
                infectedElementDocs[i].doc.last_name = infectedElementDocs[i].doc.last_name.replace(';', '');
                infectedElementDocs[i].doc.company_name = infectedElementDocs[i].doc.company_name.replace(';', '');
                elementsToUpdate.push(infectedElementDocs[i].doc);
            }
            try {
                let resp = yield couchDBUtils.bulkDocs(elementsToUpdate, maindb);
                if (resp) {
                    logger.info(type + ' Update Success:' + resp);
                }
            }
            catch (err) {
                logger.error(type + ' Update Fail:' + err);
                logger.error(infectedElementDocs);
            }
        }
        ;
    });
}
function processAndUpdateEmployeeDocs(infectedEmployees, userdb, couchDBUtils) {
    return __awaiter(this, void 0, void 0, function* () {
        if (infectedEmployees.length) {
            let employeeDocs2Update = [];
            for (let i = 0; i < infectedEmployees.length; i++) {
                infectedEmployees[i].doc.first_name = infectedEmployees[i].doc.first_name.replace(';', '');
                infectedEmployees[i].doc.last_name = infectedEmployees[i].doc.last_name.replace(';', '');
                infectedEmployees[i].doc.name = infectedEmployees[i].doc.name.replace(';', '');
                infectedEmployees[i].doc.username = infectedEmployees[i].doc.username.replace(';', '');
                employeeDocs2Update.push(infectedEmployees[i].doc);
            }
            try {
                let resp = yield couchDBUtils.bulkDocs(employeeDocs2Update, userdb);
                if (resp) {
                    logger.info('Employee Update Success:' + resp);
                }
            }
            catch (err) {
                logger.error('Employee Update Fail:' + err);
                logger.error(infectedEmployees);
            }
        }
        ;
    });
}
function processPurchaseReturnBatch(allRecivingReturns) {
    return __awaiter(this, void 0, void 0, function* () {
        allRecivingReturns.forEach(function (purchase, i) {
            return __awaiter(this, void 0, void 0, function* () {
                let tempItems = purchase.doc.items;
                let bUpdateDoc = false;
                let purchaseInfoAfterSupplierUpdate;
                if (infectedSuppliers.length) {
                    purchaseInfoAfterSupplierUpdate = yield findSemicolonInSupplier(purchase.doc.info, purchase.doc._id);
                }
                if (purchaseInfoAfterSupplierUpdate && purchaseInfoAfterSupplierUpdate.isEdited) {
                    allRecivingReturns[i].doc.info = purchaseInfoAfterSupplierUpdate.item;
                    bUpdateDoc = true;
                }
                let purchaseInfoAfterEmployeeUpdate;
                if (infectedEmployees.length) {
                    purchaseInfoAfterEmployeeUpdate = yield findSemicolonInEmployee(allRecivingReturns[i].doc.info);
                }
                if (purchaseInfoAfterEmployeeUpdate && purchaseInfoAfterEmployeeUpdate.isEdited) {
                    allRecivingReturns[i].doc.info = purchaseInfoAfterEmployeeUpdate.item;
                    bUpdateDoc = true;
                }
                if (infectedItems.length) {
                    for (let j = 0; j < tempItems.length; j++) {
                        let item = tempItems[j];
                        let itemAfterUpdate = yield findSemicolonInItem(item, allRecivingReturns[i].doc._id);
                        if (itemAfterUpdate && itemAfterUpdate.isEdited) {
                            allRecivingReturns[i].doc.items[j] = itemAfterUpdate.item;
                            bUpdateDoc = true;
                        }
                        if (infectedCategories.length) {
                            let updatedCatagory = yield findSemicolonInCategory(allRecivingReturns[i].doc.items[j], allRecivingReturns[i].doc._id);
                            if (updatedCatagory && updatedCatagory.isEdited) {
                                allRecivingReturns[i].doc.items[j] = updatedCatagory.item;
                                bUpdateDoc = true;
                            }
                        }
                    }
                }
                if (bUpdateDoc) {
                    allUpdatedRecivingReturns.push(allRecivingReturns[i].doc);
                }
            });
        });
    });
}
function findSemicolonInItem(itemString, docId) {
    return __awaiter(this, void 0, void 0, function* () {
        let matchedItemInfoArr = [];
        let data = {
            isEdited: false,
            item: undefined
        };
        let idxOfInfectedItem;
        for (let q = 0; q < infectedItems.length; q++) {
            let item = infectedItems[q];
            let itemIndex = itemString.indexOf(item.doc.info.name);
            if (itemIndex > -1) {
                let itemName = item.doc.info.name;
                if (itemName.indexOf(';') > -1) {
                    idxOfInfectedItem = q;
                    matchedItemInfoArr.push(itemName);
                }
            }
        }
        if (matchedItemInfoArr.length === 1) {
            data.isEdited = true;
            let itemName = matchedItemInfoArr[0].replace(';', "");
            itemString = itemString.replace(matchedItemInfoArr[0], itemName);
            data.item = itemString;
            infectedItems[idxOfInfectedItem].doc.info.name = itemName;
        }
        else if (matchedItemInfoArr.length > 1) {
            logger.error(matchedItemInfoArr);
            logger.error('SaleId<' + docId + '> MatchedCustomers<' + matchedItemInfoArr.length + '>');
        }
        return data;
    });
}
;
function findSemicolonInCategory(itemString, docId) {
    return __awaiter(this, void 0, void 0, function* () {
        let data = {
            isEdited: false,
            item: undefined
        };
        let matchedCategoryInfoArr = [];
        let infectedCatItemIndex;
        for (let q = 0; q < infectedCategories.length; q++) {
            let category = infectedCategories[q];
            if (itemString.indexOf(category.doc.name) > -1) {
                let categoryName = category.doc.name;
                if (categoryName.indexOf(';') > -1) {
                    matchedCategoryInfoArr.push(categoryName);
                    infectedCatItemIndex = q;
                }
            }
        }
        if (matchedCategoryInfoArr.length === 1) {
            data.isEdited = true;
            let categoryName = matchedCategoryInfoArr[0].replace(';', "");
            itemString = itemString.replace(matchedCategoryInfoArr[0], categoryName);
            data.item = itemString;
            infectedCategories[infectedCatItemIndex].doc.name = categoryName;
        }
        else if (matchedCategoryInfoArr.length > 1) {
            logger.error(matchedCategoryInfoArr);
            logger.error('SaleId<' + docId + '> MatchedCustomers<' + matchedCategoryInfoArr.length + '>');
        }
        return data;
    });
}
;
function findSemicolonInCustomer(salesInfo, docId) {
    return __awaiter(this, void 0, void 0, function* () {
        let data = {
            isEdited: false,
            item: undefined
        };
        let matchedCustInfoArr = [];
        for (let q = 0; q < infectedCustomers.length; q++) {
            let customer = infectedCustomers[q];
            let customerInfo = customer.doc;
            let checkCompanyName = customerInfo.company_name ? customerInfo.company_name : '';
            let checkLastName = customerInfo.last_name ? customerInfo.last_name : '';
            let custinfo = checkCompanyName + ' ' + customerInfo.first_name + ' ' + checkLastName;
            if ((custinfo.indexOf(';') > -1)) {
                if (salesInfo.indexOf(custinfo) > -1) {
                    matchedCustInfoArr.push(custinfo);
                }
            }
        }
        if (matchedCustInfoArr.length === 1) {
            let revCustInfo = matchedCustInfoArr[0].replace(';', '');
            salesInfo = salesInfo.replace(matchedCustInfoArr[0], revCustInfo);
            data.item = salesInfo;
            data.isEdited = true;
        }
        else if (matchedCustInfoArr.length > 1) {
            logger.error(matchedCustInfoArr);
            logger.error('SaleId<' + docId + '> MatchedCustomers<' + matchedCustInfoArr.length + '>');
        }
        return data;
    });
}
;
function findSemicolonInSupplier(purchaseInfo, docId) {
    return __awaiter(this, void 0, void 0, function* () {
        let data = {
            isEdited: false,
            item: undefined
        };
        let matchedSupInfoArr = [];
        for (let q = 0; q < infectedSuppliers.length; q++) {
            let supplier = infectedSuppliers[q];
            let supplierInfo = supplier.doc;
            let checkCompanyName = supplierInfo.company_name ? supplierInfo.company_name : '';
            let checkLastName = supplierInfo.last_name ? supplierInfo.last_name : '';
            let supplierFullName = checkCompanyName + ' ' + supplierInfo.first_name + ' ' + checkLastName;
            if ((supplierFullName.indexOf(';') > -1)) {
                if (purchaseInfo.indexOf(supplierFullName) > -1) {
                    matchedSupInfoArr.push(supplierFullName);
                }
            }
        }
        if (matchedSupInfoArr.length === 1) {
            let revSupInfo = matchedSupInfoArr[0].replace(';', '');
            purchaseInfo = purchaseInfo.replace(matchedSupInfoArr[0], revSupInfo);
            data.item = purchaseInfo;
            data.isEdited = true;
        }
        else if (matchedSupInfoArr.length > 1) {
            logger.error(matchedSupInfoArr);
            logger.error('PurchaseId<' + docId + '> MatchedSuppliers<' + matchedSupInfoArr.length + '>');
        }
        return data;
    });
}
;
function findSemicolonInEmployee(salesInfo) {
    return __awaiter(this, void 0, void 0, function* () {
        let data = {
            isEdited: false,
            item: undefined
        };
        for (let q = 0; q < allEmployees.length; q++) {
            let employee = allEmployees[q];
            let employeeFName = employee.doc.first_name;
            employeeFName = employee.doc.last_name ? employeeFName + ' ' + employee.doc.last_name : employeeFName;
            if (salesInfo.indexOf(employeeFName) > -1 && employeeFName.indexOf(';') > -1) {
                let employeeFNameWithoutSemiColon = employeeFName.replace(';', '');
                salesInfo = salesInfo.replace(employeeFName, employeeFNameWithoutSemiColon);
                data.item = salesInfo;
                data.isEdited = true;
            }
        }
        return data;
    });
}
;
function processSaleBatch(allSales) {
    return __awaiter(this, void 0, void 0, function* () {
        allSales.forEach(function (sale, i) {
            return __awaiter(this, void 0, void 0, function* () {
                let tempItems = sale.doc.sale_items;
                let bUpdateDoc = false;
                let saleInfoAfterCustomerUpdate;
                if (infectedCustomers.length) {
                    saleInfoAfterCustomerUpdate = yield findSemicolonInCustomer(sale.doc.sales_info, sale.doc._id);
                }
                if (saleInfoAfterCustomerUpdate && saleInfoAfterCustomerUpdate.isEdited) {
                    allSales[i].doc.sales_info = saleInfoAfterCustomerUpdate.item;
                    bUpdateDoc = true;
                }
                let saleInfoAfterEmployeeUpdate;
                if (infectedEmployees.length) {
                    saleInfoAfterEmployeeUpdate = yield findSemicolonInEmployee(allSales[i].doc.sales_info);
                }
                if (saleInfoAfterEmployeeUpdate && saleInfoAfterEmployeeUpdate.isEdited) {
                    allSales[i].doc.sales_info = saleInfoAfterEmployeeUpdate.item;
                    bUpdateDoc = true;
                }
                if (infectedItems.length) {
                    for (let j = 0; j < tempItems.length; j++) {
                        let item = tempItems[j];
                        let itemAfterUpdate = yield findSemicolonInItem(item, allSales[i].doc._id);
                        if (itemAfterUpdate && itemAfterUpdate.isEdited) {
                            allSales[i].doc.sale_items[j] = itemAfterUpdate.item;
                            bUpdateDoc = true;
                        }
                        if (infectedCategories.length) {
                            let updatedCatagory = yield findSemicolonInCategory(allSales[i].doc.sale_items[j], allSales[i].doc._id);
                            if (updatedCatagory && updatedCatagory.isEdited) {
                                allSales[i].doc.sale_items[j] = updatedCatagory.item;
                                bUpdateDoc = true;
                            }
                        }
                    }
                }
                if (bUpdateDoc) {
                    allUpdatedSale.push(allSales[i].doc);
                }
            });
        });
    });
}
function processSaleReturnBatch(allSalesReturns) {
    return __awaiter(this, void 0, void 0, function* () {
        allSalesReturns.forEach(function (sale, i) {
            return __awaiter(this, void 0, void 0, function* () {
                let bUpdateDoc = false;
                let tempItems = sale.doc.items;
                let infoAfterCustomerUpdate;
                if (infectedCustomers.length) {
                    infoAfterCustomerUpdate = yield findSemicolonInCustomer(sale.doc.info, sale.doc._id);
                }
                if (infoAfterCustomerUpdate && infoAfterCustomerUpdate.isEdited) {
                    allSalesReturns[i].doc.info = infoAfterCustomerUpdate.item;
                    bUpdateDoc = true;
                }
                let infoAfterEmployeeUpdate;
                if (infectedEmployees.length) {
                    infoAfterEmployeeUpdate = yield findSemicolonInEmployee(allSalesReturns[i].doc.info);
                }
                if (infoAfterEmployeeUpdate && infoAfterEmployeeUpdate.isEdited) {
                    allSalesReturns[i].doc.info = infoAfterEmployeeUpdate.item;
                    bUpdateDoc = true;
                }
                if (infectedItems.length) {
                    for (let j = 0; j < tempItems.length; j++) {
                        let item = tempItems[j];
                        let itemAfterUpdate = yield findSemicolonInItem(item, allSalesReturns[i].doc._id);
                        if (itemAfterUpdate && itemAfterUpdate.isEdited) {
                            allSalesReturns[i].doc.items[j] = itemAfterUpdate.item;
                            bUpdateDoc = true;
                        }
                        if (infectedCategories.length) {
                            let updatedCatagory = yield findSemicolonInCategory(allSalesReturns[i].doc.items[j], allSalesReturns[i].doc._id);
                            if (updatedCatagory && updatedCatagory.isEdited) {
                                allSalesReturns[i].doc.items[j] = updatedCatagory.item;
                                bUpdateDoc = true;
                            }
                        }
                    }
                }
                if (bUpdateDoc) {
                    allUpdatedSaleReturn.push(allSalesReturns[i].doc);
                }
            });
        });
    });
}
function processPurchaseBatch(allPurchase) {
    return __awaiter(this, void 0, void 0, function* () {
        allPurchase.forEach(function (purchase, i) {
            return __awaiter(this, void 0, void 0, function* () {
                let tempItems = purchase.doc.receiving_items;
                let bUpdateDoc = false;
                let purchaseInfoAfterSupplierUpdate;
                if (infectedSuppliers.length) {
                    purchaseInfoAfterSupplierUpdate = yield findSemicolonInSupplier(purchase.doc.receivings_info, purchase.doc._id);
                }
                if (purchaseInfoAfterSupplierUpdate && purchaseInfoAfterSupplierUpdate.isEdited) {
                    allPurchase[i].doc.receivings_info = purchaseInfoAfterSupplierUpdate.item;
                    bUpdateDoc = true;
                }
                let purchaseInfoAfterEmployeeUpdate;
                if (infectedEmployees.length) {
                    purchaseInfoAfterEmployeeUpdate = yield findSemicolonInEmployee(allPurchase[i].doc.receivings_info);
                }
                if (purchaseInfoAfterEmployeeUpdate && purchaseInfoAfterEmployeeUpdate.isEdited) {
                    allPurchase[i].doc.receivings_info = purchaseInfoAfterEmployeeUpdate.item;
                    bUpdateDoc = true;
                }
                if (infectedItems.length) {
                    for (let j = 0; j < tempItems.length; j++) {
                        let item = tempItems[j];
                        let itemAfterUpdate = yield findSemicolonInItem(item, allPurchase[i].doc._id);
                        if (itemAfterUpdate && itemAfterUpdate.isEdited) {
                            allPurchase[i].doc.receiving_items[j] = itemAfterUpdate.item;
                            bUpdateDoc = true;
                        }
                        if (infectedCategories.length) {
                            let updatedCatagory = yield findSemicolonInCategory(allPurchase[i].doc.receiving_items[j], allPurchase[i].doc._id);
                            if (updatedCatagory && updatedCatagory.isEdited) {
                                allPurchase[i].doc.receiving_items[j] = updatedCatagory.item;
                                bUpdateDoc = true;
                            }
                        }
                    }
                }
                if (bUpdateDoc) {
                    allUpdatedPurchase.push(allPurchase[i].doc);
                }
            });
        });
    });
}
//# sourceMappingURL=201809260000000-fixSemicolonIssue.js.map