/**
 */

'use strict';

import * as path from 'path';
let logger;
export const up = async (params) => {
    logger = params.logger;
    let migrationsBasePath = params.migrationsBasePath;

    const appRootPath = migrationsBasePath + '/../';
    const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
    const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let maindb = nanoClients.maindb;

    try {
        async function processCustomerPan(allCustomerDocs, params) {
            let docsToPush = [];
            for (var k = 0; k < allCustomerDocs.length; k++) {
                if (allCustomerDocs[k].doc && allCustomerDocs[k].doc.pan_number != undefined && allCustomerDocs[k].doc.pan_number != null) {
                    let pan_number = allCustomerDocs[k].doc.pan_number + '';

                    if (pan_number != '' && pan_number.length != 10) {
                        allCustomerDocs[k].doc.pan_number = '';
                    }
                }

                docsToPush.push(allCustomerDocs[k].doc);
            }
            await bulkInsert(params.dbInstance, docsToPush);
        }

        await batchProcess(1000, 'customer', processCustomerPan, {
            dbInstance: maindb,
            couchDBUtils: couchDBUtils,
            logger: logger
        });

        async function processSupplierPan(allSupplierDocs, params) {
            let docsToPush = [];
            for (var k = 0; k < allSupplierDocs.length; k++) {
                if (allSupplierDocs[k].doc && allSupplierDocs[k].doc.pan_number != undefined && allSupplierDocs[k].doc.pan_number != null) {
                    let pan_number = allSupplierDocs[k].doc.pan_number + '';

                    if (pan_number != '' && pan_number.length != 10) {
                        allSupplierDocs[k].doc.pan_number = '';
                    }
                }
                docsToPush.push(allSupplierDocs[k].doc);
            }
            await bulkInsert(params.dbInstance, docsToPush);
        }

        await batchProcess(1000, 'supplier', processSupplierPan, {
            dbInstance: maindb,
            couchDBUtils: couchDBUtils,
            logger: logger
        });
    } catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }
}

export const down = async () => {
    //nothing required
    return;
};

async function bulkInsert(db, docsArray) {
    try {
        let resp = await db.bulk({
            docs: docsArray
        });
        return resp;
    } catch (error) {
        logger.error(error);
        throw 'Bulk Update Failed';
    }
};
