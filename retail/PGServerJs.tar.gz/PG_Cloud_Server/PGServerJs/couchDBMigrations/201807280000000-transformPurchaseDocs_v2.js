/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
            let logger = params.logger;
            let migrationsBasePath = params.migrationsBasePath;

            const appRootPath = migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            const couchDBUtils2 = require('../couchDb/couchDBUtils2');
            const utils = require('../controllers/common/Utils');
            const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
            const CLONE = utils.clone;

            let migrationName = path.basename(__filename, '.js');
            params.migrationName = migrationName;
            let nanoClients = params.nanoClients;
            let maindb = nanoClients.maindb;
            let coredb = nanoClients.coredb;
            let usersdb = nanoClients._users;

            try {
                const taxLib = require('../TSControllers/libraries/taxDetailsCommon');
                const commonLib = require('../controllers/libraries/commonLib');
                const getTaxesByPercentageDetailed = taxLib.getTaxesByPercentageDetailed;

                function getTotalPercent(taxArray, itemId) {
                    try {
                        var totalTaxPercent = 0;
                        if (!taxArray)
                            return totalTaxPercent;
                        for (var j = 0; j < taxArray.length; j++) {
                            var itemTax = taxArray[j];
                            if (!itemTax.item_id || itemTax.item_id === itemId) {
                                totalTaxPercent += parseFloat(itemTax.percent);
                            }
                        }

                        return totalTaxPercent;
                    } catch (ex) {
                        console.log("ex");
                        console.log(ex);
                        return totalTaxPercent;
                    }
                }

                function getPriceTaxEx(price, bTaxInclusive, totalTaxPercent) {
                    var priceExcludingTax = price;
                    if (bTaxInclusive) {
                        priceExcludingTax = calculatePriceExcludingTax(price, totalTaxPercent);
                    };

                    return priceExcludingTax;
                };

                function calculatePriceExcludingTax(price, taxPercent) {
                    var factor = 1 + (taxPercent * 0.01);
                    var priceExTax = price / factor;

                    return priceExTax;
                }

                function computepxax0dot01(p, a) {
                    return (p * a * 0.01);
                };

                function add(a, b) {
                    return (a + b);
                };

                function multiply(a, b) {
                    return (a * b);
                }

                function subtract(a, b) {
                    return (a - b);
                };

                function computeTaxAmounts(taxArray, totalWithoutCharges) {

                    var taxAmounts = {
                        CGST: 0,
                        SGST: 0,
                        IGST: 0,
                        CESS: 0,
                        Total: 0
                    };
                    for (var j = 0; j < taxArray.length; j++) {
                        var itemTax = taxArray[j];
                        if (!itemTax.item_id || itemTax.item_id === itemId) {
                            taxAmounts[itemTax.name] = computepxax0dot01(itemTax.percent, totalWithoutCharges);
                        }
                        taxAmounts.Total += taxAmounts[itemTax.name];
                    }
                    return taxAmounts;

                }

                function getTaxAmt(taxArray) {
                    let taxAmt = 0;
                    for (let tax in taxArray) {
                        taxAmt += taxArray[tax];
                    }
                    return taxAmt;
                }

                function computePurItem(itemInfo, globalDiscountInfo, calculations) {
                    globalDiscountInfo = globalDiscountInfo ? globalDiscountInfo : {};
                    var info = {};
                    info.quantity = parseFloat(itemInfo.quantity_purchased);
                    info.itemId = itemInfo.item_id;

                    info.purchasePrice = parseFloat(itemInfo.unitsInfo[itemInfo.unitId].purchasePrice);
                    var itemTaxes = itemInfo.itemTaxList;
                    if (!itemTaxes) {
                        itemTaxes = [];
                    }

                    var taxPercent = getTotalPercent(itemTaxes);
                    var priceTaxEx = getPriceTaxEx(info.purchasePrice, itemInfo.bPPTaxInclusive, taxPercent);
                    info.discount = itemInfo.discount ? itemInfo.discount : 0;
                    itemInfo.discount_percent = info.discount;
                    info.discountPercent = itemInfo.discount_percent ? parseFloat(itemInfo.discount_percent) : 0;
                    // info.discountPercent += globalDiscountInfo && globalDiscountInfo.percent ? globalDiscountInfo.percent : 0;

                    info.priceWithoutDiscount = multiply(info.quantity, priceTaxEx);
                    info.discountAmt = computepxax0dot01(info.priceWithoutDiscount, info.discountPercent);
                    info.subTotal = subtract(info.priceWithoutDiscount, info.discountAmt);
                    info.subTotalWithoutGD = info.subTotal;
                    info.taxes = computeTaxAmounts(itemTaxes, info.subTotal);
                    itemInfo.taxes = info.taxes;
                    info.tax = computepxax0dot01(taxPercent, info.subTotal);
                    info.total = add(info.subTotal, info.tax);

                    if (globalDiscountInfo) {
                        if (globalDiscountInfo.method == 'onTaxable') {
                            info.subTotal = info.priceWithoutDiscount * (1 - (globalDiscountInfo.percent + info.discountPercent) * 0.01);
                            info.taxes = computeTaxAmounts(itemTaxes, info.subTotal);

                            info.tax = computepxax0dot01(taxPercent, info.subTotal);
                            info.total = add(info.subTotal, info.tax);
                            // computeTaxAmountsByPercentFilter(info, itemTaxes, info.subTotal, calculations);
                        } else if (globalDiscountInfo.method == 'onTotal') {
                            info.total = info.total * (1 - (globalDiscountInfo.percent) * 0.01);
                            info.subTotal = info.total / ((1 + taxPercent * 0.01))
                            info.taxes = computeTaxAmounts(itemTaxes, info.subTotal);

                            info.tax = computepxax0dot01(taxPercent, info.subTotal);
                            // computeTaxAmountsByPercentFilter(info, itemTaxes, info.subTotal, calculations);
                        }
                    }
                    itemInfo.subTotal = info.subTotal;
                    itemInfo.quantity = info.quantity;
                    itemInfo.total = info.total;
                    info.totalTaxPercent = taxPercent;
                    return info;
                };

                function getPaymentsTotal(payments) {
                    var total = 0;
                    for (var i = 0; i < payments.length; i++) {
                        total += payments[i].payment_amount;
                    }
                    return total;
                }

                /**Purchase: calculate subtotal; qty; taxes */
                // let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', maindb);
                await batchProcess(1000, 'receiving', processPuchaseDocs, {
                    dbInstance: maindb,
                    couchDBUtils: couchDBUtils,
                    logger: logger
                });
                async function processPuchaseDocs(allPurchaseDocs) {
                    let docsToPush = [];
                    for (var j = 0; j < allPurchaseDocs.length; j++) {
                        if (typeof allPurchaseDocs[j].doc.receivings_info !== 'string' && allPurchaseDocs[j].doc.receivings_info.type === 3) {
                            continue;
                        }
                        //computeItem
                        allPurchaseDocs[j].doc = commonLib.transformSaleDoc(allPurchaseDocs[j].doc, 'purchase');
                        let subtotal = 0;
                        let quantity = 0;
                        var taxes = {};
                        for (var q = 0; q < allPurchaseDocs[j].doc.receiving_items.length; q++) {
                            let itemCalculations = computePurItem(allPurchaseDocs[j].doc.receiving_items[q], allPurchaseDocs[j].doc.receivings_info.discount);

                            subtotal += itemCalculations.subTotal;
                            quantity += itemCalculations.quantity;
                            for (var t in itemCalculations.taxes) {
                                var taxAmt = itemCalculations.taxes[t];
                                if (!taxes[t]) {
                                    taxes[t] = taxAmt;
                                } else {
                                    taxes[t] += taxAmt;
                                }
                            }
                            allPurchaseDocs[j].doc.receiving_items[q].subTotal = itemCalculations.subTotal;
                            allPurchaseDocs[j].doc.receiving_items[q].total = itemCalculations.total;
                        }
                        allPurchaseDocs[j].doc.receivings_info.taxDetailed = {};
                        allPurchaseDocs[j].doc.receivings_info.taxNames = {};
                        allPurchaseDocs[j].doc.receivings_info.hsnTaxes = {};
                        getTaxesByPercentageDetailed(allPurchaseDocs[j].doc.receiving_items, allPurchaseDocs[j].doc.receivings_info.taxDetailed, allPurchaseDocs[j].doc.receivings_info.taxNames, allPurchaseDocs[j].doc.receivings_info.hsnTaxes);
                        allPurchaseDocs[j].doc.receivings_info.subtotal = subtotal;
                        allPurchaseDocs[j].doc.receivings_info.quantity = quantity;
                        allPurchaseDocs[j].doc.receivings_info.taxes = taxes;
                        var paymentTotal = getPaymentsTotal(allPurchaseDocs[j].doc.payments);
                        var changeDue = subtract(paymentTotal, allPurchaseDocs[j].doc.receivings_info.total);
                        for (var p = 0; p < allPurchaseDocs[j].doc.payments.length; p++) {
                            if (allPurchaseDocs[j].doc.payments[p].payment_type === 'Cash') {
                                allPurchaseDocs[j].doc.payments[p].returnAmt = changeDue;
                            }
                        }

                        allPurchaseDocs[j].doc = await commonLib.encodeTransDoc(allPurchaseDocs[j].doc, 'purchase');
                        docsToPush.push(allPurchaseDocs[j].doc);
                    }
                    await couchDBUtils.bulkInsert(maindb, docsToPush);
                }
                //sales return 
                // let allPurchaseRetunDocs = await couchDBUtils.getAllDocsByType('receivingReturn', maindb);
                await batchProcess(1000, 'receivingReturn', processPuchaseReturnDocs, {
                    dbInstance: maindb,
                    couchDBUtils: couchDBUtils,
                    logger: logger
                });
                async function processPuchaseReturnDocs(allPurchaseRetunDocs) {
                    let docsToPush = [];
                    for (var k = 0; k < allPurchaseRetunDocs.length; k++) {
                        if (typeof allPurchaseRetunDocs[k].doc.info !== 'string' && allPurchaseRetunDocs[k].doc.info.type === 3) {
                            continue;
                        }
                        //computePurItem
                        allPurchaseRetunDocs[k].doc = commonLib.transformSaleDoc(allPurchaseRetunDocs[k].doc, 'purchaseReturn');
                        if (typeof allPurchaseRetunDocs[k].doc.info === 'string') {
                            continue;
                        }
                        let subtotal = 0;
                        let cost = 0;
                        let profit = 0;
                        let quantity = 0;
                        var taxes = {};
                        for (var l = 0; l < allPurchaseRetunDocs[k].doc.items.length; l++) {
                            let calculations = computePurItem(allPurchaseRetunDocs[k].doc.items[l], allPurchaseRetunDocs[k].doc.info.discount);
                            subtotal += calculations.subTotal;
                            quantity += calculations.quantity;
                            for (var t in calculations.taxes) {
                                var taxAmt = calculations.taxes[t];
                                if (!taxes[t]) {
                                    taxes[t] = taxAmt;
                                } else {
                                    taxes[t] += taxAmt;
                                }
                            }
                            allPurchaseRetunDocs[k].doc.items[l].subTotal = calculations.subTotal;
                            allPurchaseRetunDocs[k].doc.items[l].total = calculations.total;
                        }
                        allPurchaseRetunDocs[k].doc.info.taxDetailed = {};
                        allPurchaseRetunDocs[k].doc.info.taxNames = {};
                        allPurchaseRetunDocs[k].doc.info.hsnTaxes = {};
                        getTaxesByPercentageDetailed(allPurchaseRetunDocs[k].doc.items, allPurchaseRetunDocs[k].doc.info.taxDetailed, allPurchaseRetunDocs[k].doc.info.taxNames, allPurchaseRetunDocs[k].doc.info.hsnTaxes);
                        allPurchaseRetunDocs[k].doc.info.subtotal = subtotal;
                        allPurchaseRetunDocs[k].doc.info.quantity = quantity;
                        allPurchaseRetunDocs[k].doc.info.taxes = taxes;
                        // allPurchaseRetunDocs[k].doc.info.taxes.Total = commonLib.getTaxAmt(allPurchaseRetunDocs[k].doc.info.taxes);
                        var totalPaid = getPaymentsTotal(allPurchaseRetunDocs[k].doc.payments);
                        var changeAmt = subtract(totalPaid, allPurchaseRetunDocs[k].doc.info.total);
                        for (var p = 0; p < allPurchaseRetunDocs[k].doc.payments.length; p++) {
                            if (allPurchaseRetunDocs[k].doc.payments[p].payment_type === 'Cash') {
                                allPurchaseRetunDocs[k].doc.payments[p].returnAmt = changeAmt;
                            }
                        }
                        allPurchaseRetunDocs[k].doc = await commonLib.encodeTransDoc(allPurchaseRetunDocs[k].doc, 'purchaseReturn');
                        docsToPush.push(allPurchaseRetunDocs[k].doc);
                    }
                    await couchDBUtils.bulkInsert(maindb, docsToPush);
                }

            } catch (err) {
                logger.error(err);
                throw migrationName + ' up migration failed';
            }
        },

        down: async function(params) {
            let logger = params.logger;
            let migrationName = path.basename(__filename, '.js');
            params.migrationName = migrationName;
            let migrationsBasePath = params.migrationsBasePath;
            const appRootPath = migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            const couchDBUtils2 = require('../couchDb/couchDBUtils2');
            const commonLib = require('../controllers/libraries/commonLib');
            let nanoClients = params.nanoClients;
            let maindb = nanoClients.maindb;
            let nanoUsers = nanoClients._users;

            try {
                //as if now down migration is not required
                //todo write code if down is rquired

            } catch (err) {
                logger.error(err);
                throw migrationName + ' down migration failed';
            }
        }
};