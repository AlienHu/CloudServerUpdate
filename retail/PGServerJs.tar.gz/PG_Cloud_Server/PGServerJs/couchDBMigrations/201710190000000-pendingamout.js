/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;

        const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
        try {
            let batchProcessParams = {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            };

            await batchProcess(50, 'sale', process, batchProcessParams);
            await batchProcess(50, 'receiving', process, batchProcessParams);

            async function process(allDocs, params) {
                let docsToUpdate = [];
                for (let i = 0; i < allDocs.length; i++) {

                    let doc = allDocs[i].doc;
                    let bUpdate = false;
                    let infoKey = 'sales_info';
                    let onCreditType = 'Sale on credit';
                    let paymentIdKey = 'payment_sale_id';
                    if (doc._id.indexOf('receiving') === 0) {
                        onCreditType = 'Purchase On Credit';
                        paymentIdKey = 'payment_receiving_id';
                        infoKey = 'receivings_info';
                    }

                    let payments = doc.payments;
                    let paymentIdTypeMap = {};
                    let pending_amount = 0;

                    let newPayments = [];

                    for (let i = 0; i < payments.length; i++) {
                        let parentPaymentId = payments[i][paymentIdKey];
                        let payment_amount = payments[i].payment_amount;
                        let bPush = true;
                        if (parentPaymentId) {
                            let key = parentPaymentId + '-' + payments[i].payment_type;
                            if (paymentIdTypeMap[key]) {
                                logger.error('Duplicate entry found');
                                //We have to remove
                                bPush = false;
                                bUpdate = true;
                            } else {
                                paymentIdTypeMap[key] = 1;
                                pending_amount -= payment_amount;
                            }
                        }

                        if (payments[i].payment_type === onCreditType) {
                            pending_amount += payment_amount;
                        }
                        if (bPush) {
                            newPayments.push(payments[i]);
                        }
                    }

                    if (bUpdate) {

                        doc.pending_amount = pending_amount;

                        doc.payments = newPayments;
                        docsToUpdate.push(allDocs[i].doc);
                    }
                }

                if (docsToUpdate.length) {
                    let updateResp = await couchDBUtils.bulkInsert(params.dbInstance, docsToUpdate);
                }
            }

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    },

    //bug fix so down function not required
    down: async function(params) {}
};