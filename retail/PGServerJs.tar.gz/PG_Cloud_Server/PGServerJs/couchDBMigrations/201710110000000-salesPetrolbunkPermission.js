/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;
        try {
            var params = {};
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            var allUsersDoc = [];
            var json = {
                "desc": "",
                "allowNone": false,
                "allowAll": false,
                "viewOnMenu": false,
                "apis": ["getSalesRestApi"],
                "sendEmail": {
                    "apis": ["/common/sendEmailApi"],
                    "common": true,
                    "allowed": false,
                    "desc": "Allows to Send the Email to the Customer"
                },
                "makeSale": {
                    "allowed": false,
                    "desc": "Allows to Add Items to Cart,Accept Payments, Complete Sale and to Generate Print Receipt on printer if configured.",
                    "apis": ["getSalesRestApi", "additemRestApi", "removeitemRestApi", "add_paymentRestApi", "completeSaleRestApi", "getCartTaxes", "addCustomer2SaleRestApi", "receiptRestApi", "printReceiptApi", "setPrintAfterSaleRestApi", "setInvoiceNumberEnabledRestApi", "setInvoiceNumberRestApi", "invoiceRestApi", "DeleteItemFromCartRestApi", "getItemsRestApi", "cancel_saleRestApi", "changeModeRestApi", "makeCustomerCreditPayment", "printSaleRestApi"]
                },
                "makeReturn": {
                    "allowed": false,
                    "desc": "Allows Returning of Sold Items.",
                    "apis": ["getSalesRestApi", "additemRestApi", "removeitemRestApi", "add_paymentRestApi", "completeSaleRestApi", "getCartTaxes", "addCustomer2SaleRestApi", "receiptRestApi", "printReceiptApi", "setPrintAfterSaleRestApi", "setInvoiceNumberEnabledRestApi", "setInvoiceNumberRestApi", "invoiceRestApi", "DeleteItemFromCartRestApi", "getItemsRestApi", "cancel_saleRestApi", "changeModeRestApi", "makeCustomerCreditPayment", "printSaleRestApi"]
                },
                "editPrice": {
                    "allowed": false,
                    "desc": "Allows to Modify the Price While making the Sale.",
                    "apis": ["editItemRestApi"]
                },
                "editDiscount": {
                    "allowed": false,
                    "desc": "Allows to Modify Discount Percents%",
                    "apis": ["editItemRestApi", "getItemDiscountRestApi"]
                },
                "suspendSales": {
                    "allowed": false,
                    "desc": "Allows to View Suspened Sales of OtherUsers",
                    "apis": ["allSuspendedSalesRestApi", "suspendSaleRestApi"]
                },
                "unsuspendSales": {
                    "allowed": false,
                    "desc": "Allows to View Suspened Sales of OtherUsers",
                    "apis": ["unsuspendSaleRestApi"]
                },
                "viewOthersSuspendedSales": {
                    "allowed": false,
                    "desc": "Allows to View Suspened Sales of OtherUsers"
                },
                "unsuspendOthersSales": {
                    "allowed": false,
                    "desc": "Allows to Unsuspend the Sales"
                },
                "deleteOthersSuspendedSales": {
                    "allowed": false,
                    "desc": "Allows to Delete Suspened Sales of OtherUsers"
                },
                "salesHistory": {
                    "view": {
                        "apis": ["handled@ClientSide", "manageRestApi"],
                        "allowed": false,
                        "desc": "Allows to View Sales History"
                    },
                    "update": {
                        "apis": ["update", "saveEditSalesRestApi"],
                        "allowed": false,
                        "desc": "Allows to Modify Sales History"
                    },
                    "delete": {
                        "apis": ["delete", "deleteSaleRestApi"],
                        "allowed": false,
                        "desc": "Allows to Delete Sales History"
                    }
                }
            }
            var flag = false;
            for (var i = 0; i < allUsers.length; i++) {
                if (allUsers[i].value.APP_TYPE !== 'petrolbunk') return;
                flag = true;
                try {
                    allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                } catch (error) {
                    logger.error(error);
                    continue;
                }

                if (allUsers[i].value.roles[1] === 'admin') {
                    json.allowAll = true;
                    json.viewOnMenu = true;
                    json.sendEmail.allowed = true;
                    json.makeSale.allowed = true;
                    json.makeReturn.allowed = true;
                    json.editPrice.allowed = true;
                    json.editDiscount.allowed = true;
                    json.suspendSales.allowed = true;
                    json.unsuspendSales.allowed = true;
                    json.viewOthersSuspendedSales.allowed = true;
                    json.unsuspendOthersSales.allowed = true;
                    json.deleteOthersSuspendedSales.allowed = true;
                    json.salesHistory.view.allowed = true;
                    json.salesHistory.update.allowed = true;
                    json.salesHistory.delete.allowed = true;

                }
                allUsers[i].value.roles[0].sales = json;
                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);

                allUsersDoc.push(allUsers[i].value);
            }
            if (flag) await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            var params = {};
            let allUsersDoc = [];
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            var flag = false;
            for (var i = 0; i < allUsers.length; i++) {
                if (allUsers[i].value.APP_TYPE !== 'petrolbunk') return;
                flag = true;
                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);

                if (allUsers[i].value.roles[0].hasOwnProperty('sales')) {
                    delete allUsers[i].value.roles[0].sales;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('sale property not found');
                }
                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                allUsersDoc.push(allUsers[i].value);
            }

            if (flag) await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);
        } catch (error) {
            logger.error(error);
            logger.error('sale down migration failed');
            throw error;
        }
    }
};