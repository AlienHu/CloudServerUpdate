'use strict';

import * as path from 'path';
let logger;
let coredb;
let couchDBUtils;

export const up = async (params) => {
    logger = params.logger;
    const migrationsBasePath = params.migrationsBasePath;
    const appRootPath = migrationsBasePath + '/../';
    couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
    const nanoClients = params.nanoClients;
    coredb = nanoClients.coredb; // main is global

    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    try {
        const key = "weighingMachine";
        let appSettings = await couchDBUtils.getDoc("profitGuruApplicationSettings_", coredb);
        if (!appSettings.terminalConfigs.includes(key)) {
            appSettings.terminalConfigs.push(key);
            await couchDBUtils.update(appSettings, coredb);
            console.log("weighingMachine added to terminalConfigs");
        } else {
            console.log("weighingMachine already exists in terminalConfigs");
        }
    } catch (err) {
        logger.error(err);;
        throw "adding weighingMachine in terminalConfigs migration failed";
    }

};

export const down = async () => {
    return;
};