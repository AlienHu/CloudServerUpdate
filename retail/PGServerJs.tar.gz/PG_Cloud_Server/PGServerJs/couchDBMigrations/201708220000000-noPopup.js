/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;
        try {

            var params = {};
            await couchDBUtils2.createCouchDbAndViews(nanoUsers, '_users');

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            applicationSettings.easyProcess = {
                "value": false
            };
            var appSettingsDoc = [applicationSettings];
            await couchDBUtils.bulkInsert(nanoCore, appSettingsDoc);

        } catch (error) {
            logger.error(error);
            throw migrationName + 'up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            var params = {};
            let docsToUpdate = [];

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            if (applicationSettings.hasOwnProperty('easyProcess')) {
                delete applicationSettings.easyProcess;
            } else {
                logger.error('Not expected to come here');
                logger.error('easyProcess property not found');
            }

            var appSettingsDoc = [applicationSettings];
            await couchDBUtils.bulkInsert(nanoCore, appSettingsDoc);
        } catch (error) {
            logger.error(error);
            logger.error('application settings easyProcess update failed');
            throw migrationName + "DOwN Failed";
        }
    }
};