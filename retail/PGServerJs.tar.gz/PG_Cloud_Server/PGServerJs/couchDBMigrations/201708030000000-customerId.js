/**
 */

'use strict';

var path = require('path');
let migrationName = path.basename(__filename, '.js');
let errMsg = migrationName + ' Migration Failed';

//add suppliers, customers, suppliers in recv, sale, recv

module.exports = {
    up: async function(params) {
        const appRootPath = params.migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let logger = params.logger;

        try {
            let mainDBInstance = params.nanoClients.maindb;

            let newDocs = [];

            async function addTotalAndInitalCreditBalance(type) {
                let allElementsDocs = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
                for (let i = 0; i < allElementsDocs.length; i++) {
                    allElementsDocs[i].doc.total = 0;
                    allElementsDocs[i].doc.initial_credit_balance = allElementsDocs[i].doc.credit_balance;
                    newDocs.push(allElementsDocs[i].doc);
                }
            }

            await addTotalAndInitalCreditBalance('customer');
            await addTotalAndInitalCreditBalance('supplier');

            let allSaleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
            for (let i = 0; i < allSaleDocs.length; i++) {
                let pendingCustomersUpdates = allSaleDocs[i].doc.status.customers;
                for (let customerDocId in pendingCustomersUpdates) {
                    if (pendingCustomersUpdates[customerDocId].doc) {
                        pendingCustomersUpdates[customerDocId].doc._id = customerDocId;
                    }
                }

                newDocs.push(allSaleDocs[i].doc);
            }

            let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance);
            for (let i = 0; i < allPurchaseDocs.length; i++) {
                let doc = allPurchaseDocs[i].doc;
                let pendingSuppliersUpdates = doc.status.suppliers;
                if (!pendingSuppliersUpdates) {
                    let supplierDocId = 'supplier_' + doc.receivings_info.supplier_id;
                    doc.status.status = 4;
                    doc.status.suppliers = {};
                    doc.status.suppliers[supplierDocId] = {
                        status: 4,
                        doc: {
                            _id: supplierDocId,
                            total: doc.receivings_info.total,
                            balance: doc.receivings_info.pending_amount
                        }
                    }
                }

                newDocs.push(allPurchaseDocs[i].doc);
            }
            if (newDocs.length) {
                await couchDBUtils.bulkInsert(mainDBInstance, newDocs);
            }
        } catch (error) {
            logger.error(error);
            throw errMsg;
        }
    },

    //No need to remove the doc._id
    down: async function(params) {
        const appRootPath = params.migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let logger = params.logger;

        try {
            let mainDBInstance = params.nanoClients.maindb;
            let newDocs = [];
            async function removeTotalAndInitalCreditBalance(type) {
                let allElementsDocs = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
                for (let i = 0; i < allElementsDocs.length; i++) {
                    delete allElementsDocs[i].doc.total;
                    delete allElementsDocs[i].doc.initial_credit_balance;
                    newDocs.push(allElementsDocs[i].doc);
                }
            }

            await removeTotalAndInitalCreditBalance('customer');
            await removeTotalAndInitalCreditBalance('supplier');

            let allSaleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);

            for (let i = 0; i < allSaleDocs.length; i++) {
                let pendingCustomersUpdates = allSaleDocs[i].doc.status.customers;
                for (let customerDocId in pendingCustomersUpdates) {
                    if (pendingCustomersUpdates[customerDocId].doc) {
                        delete pendingCustomersUpdates[customerDocId].doc._id;
                    }
                }

                newDocs.push(allSaleDocs[i].doc);
            }

            let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance);
            for (let i = 0; i < allPurchaseDocs.length; i++) {
                let doc = allPurchaseDocs[i].doc;
                if (doc.status.suppliers) {
                    delete doc.status.suppliers;
                }

                newDocs.push(allPurchaseDocs[i].doc);
            }
            if (newDocs.length) {
                await couchDBUtils.bulkInsert(mainDBInstance, newDocs);
            }
        } catch (error) {
            logger.error(error);
            throw errMsg;
        }
    }
};