'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
let logger;
let coredb;
let couchDBUtils;
exports.up = (params) => __awaiter(this, void 0, void 0, function* () {
    logger = params.logger;
    const migrationsBasePath = params.migrationsBasePath;
    const appRootPath = migrationsBasePath + '/../';
    couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
    const nanoClients = params.nanoClients;
    coredb = nanoClients.coredb; // main is global
    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    try {
        const key = "weighingMachine";
        let appSettings = yield couchDBUtils.getDoc("profitGuruApplicationSettings_", coredb);
        if (!appSettings.terminalConfigs.includes(key)) {
            appSettings.terminalConfigs.push(key);
            yield couchDBUtils.update(appSettings, coredb);
            console.log("weighingMachine added to terminalConfigs");
        }
        else {
            console.log("weighingMachine already exists in terminalConfigs");
        }
    }
    catch (err) {
        logger.error(err);
        ;
        throw "adding weighingMachine in terminalConfigs migration failed";
    }
});
exports.down = () => __awaiter(this, void 0, void 0, function* () {
    return;
});
//# sourceMappingURL=201903090000000-addWeighingMachineToTerminalConfigs.js.map