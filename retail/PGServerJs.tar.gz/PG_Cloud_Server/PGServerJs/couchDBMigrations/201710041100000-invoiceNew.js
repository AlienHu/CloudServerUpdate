/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        var invoiceSettingsJSON = {
            "pageBorder": false,
            "printInvoice": true,
            "showLoyalityInfo": "",
            "declaration_note": "",
            "additional_note": "",
            "sub_note": "",
            "invoiceTitle": "",
            "showCustomerSignature": true,
            "company_tin": "",
            "companyTIN": "",
            "salesPrinter": "",
            "kotPrinter": "",
            "kotCopy": 1,
            "receiptCopy": 1,
            "taxDisplayType": "byName",
            "borderType": "normal",
            "printReceiptByDefault": true,
            "title": "Invoice",
            "showTitle": true,
            "titleFontSize": 4,
            "shortWord": false,
            "showCompanyName": true,
            "showCustomerName": true,
            "snippetDisplayType": true,
            "bodyWidthPerc": 0,
            "bodyMarginTop": 1,
            "bodyMarginBottom": 1,
            "bodyMarginLeft": 1,
            "bodyMarginRight": 1,
            "showBorder": true,
            "bodyBorderSize": 0.2,
            "padding": 4,
            "showHead": true,
            "headInfoWidth": 40,
            "headFontSize": 4,
            "headTextAlign": "left",
            "showLogo": true,
            "logoPath": "#",
            "logoFloat": "center",
            "logoWidth": 20,
            "logoHeight": 20,
            "showCompanyInfo": true,
            "headCompanyFloat": "left",
            "companyNameFontSize": 4,
            "showCustomerInfo": true,
            "headCustomerFloat": "right",
            "showInvoiceInfo": true,
            "showCompanyAbout": true,
            "showCompanyAddress": true,
            "showCompanyPhone": true,
            "showCompanyEmail": true,
            "showCompanyGSTIN": true,
            "showCompanyStateCode": true,
            "showCustomerAddress": true,
            "showCustomerPhone": true,
            "showCustomerEmail": true,
            "showCustomerGSTIN": true,
            "showCustomerStateCode": true,
            "midFontSize": 4,
            "showItemName": true,
            "showItemNumber": false,
            "showQuantity": true,
            "showHSN": false,
            "showUnit": true,
            "showIMEI": false,
            "showSerialNum": false,
            "showSign": true,
            "showTaxPerc": false,
            "showPrice": false,
            "showMRP": true,
            "showPriceExTax": false,
            "showDiscTotal": false,
            "showDiscPrice": false,
            "showTaxableAmt": false,
            "showGSTAmt": true,
            "showTotalWithTax": true,
            "showDiscount": true,
            "showTotalWtChargesNDisc": false,
            "showSummary": true,
            "showChangeDue": true,
            "showTotalTaxableAmt": true,
            "showTotalTax": true,
            "showInvoiveTotal": true,
            "showTotalDiscount": true,
            "showPayments": true,
            "showAmountInWord": true,
            "showSNum": true,
            "showInvoiceTotal": true,
            "saleSummaryWidth": 70,
            "showVariants": true,
            "showTaxBreakings": true,
            "isTaxInSameRow": true,
            "taxBreakingLabel": "Tax Breakings",
            "taxBreakWidth": 100,
            "showCustomerSign": true,
            "showCompanySign": true,
            "signLineWidth": 60,
            "signTopMargin": 31,
            "signBottomMargin": 0,
            "showFoot": true,
            "showDeclarationNote": true,
            "showAdditionalNote": true,
            "showSubNote": true,
            "showReturnPolicy": true,
            "footNoteAlign": "left",
            "footNoteFontSize": 4,
            "returnPolicy": "Return policy for the business",
            "subNote": "Sub note if any",
            "additionalNote": "Some additional note if any",
            "declarationNote": "Declaration note if any",
            "showComment": true
        };

        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);

            applicationSettings.invoiceSettings.declarationNote = (applicationSettings.invoiceSettings.declaration_note) ? applicationSettings.invoiceSettings.declaration_note : "Declaration note if any";
            applicationSettings.invoiceSettings.additionalNote = (applicationSettings.invoiceSettings.additional_note) ? applicationSettings.invoiceSettings.additional_note : "Some additional note if any";
            applicationSettings.invoiceSettings.subNote = (applicationSettings.invoiceSettings.sub_note) ? applicationSettings.invoiceSettings.sub_note : "Sub note if any";
            applicationSettings.invoiceSettings.returnPolicy = (applicationSettings.returnPolicy.policyMessage) ? applicationSettings.returnPolicy.policyMessage : "Return policy for the business";
            applicationSettings.invoiceSettings.printReceiptByDefault = (applicationSettings.serverPrinter.printReceiptByDefault) ? applicationSettings.serverPrinter.printReceiptByDefault : true;
            applicationSettings.invoiceSettings.title = (applicationSettings.invoiceSettings.invoiceTitle) ? applicationSettings.invoiceSettings.invoiceTitle : "Invoice";
            applicationSettings.invoiceSettings.showCustomerSign = (applicationSettings.invoiceSettings.showCustomerSignature) ? applicationSettings.invoiceSettings.showCustomerSignature : true;
            applicationSettings.invoiceSettings.companyTIN = (applicationSettings.invoiceSettings.company_tin) ? applicationSettings.invoiceSettings.company_tin : "";
            applicationSettings.invoiceSettings.printInvoice = (applicationSettings.invoiceSettings.print_invoice) ? applicationSettings.invoiceSettings.print_invoice : false;
            applicationSettings.invoiceSettings.logoFloat = (applicationSettings.shopLogo.position) ? applicationSettings.shopLogo.position : "center";
            applicationSettings.invoiceSettings.salesPrinter = applicationSettings.ReceiptData.sales_printer;
            applicationSettings.invoiceSettings.kotPrinter = applicationSettings.ReceiptData.Kot_printer;
            applicationSettings.invoiceSettings.receiptCopy = (applicationSettings.ReceiptData.receiptCopy) ? applicationSettings.ReceiptData.receiptCopy : 1;
            applicationSettings.invoiceSettings.kotCopy = (applicationSettings.ReceiptData.kotCopy) ? applicationSettings.ReceiptData.kotCopy : 1;

            applicationSettings.invoiceSettings.showMRP = (applicationSettings.paperReceipt.mrp_display) ? applicationSettings.paperReceipt.mrp_display : false;
            applicationSettings.invoiceSettings.showSNum = (applicationSettings.paperReceipt.lineNo_display) ? applicationSettings.paperReceipt.lineNo_display : true;
            applicationSettings.invoiceSettings.showDiscount = (applicationSettings.paperReceipt.discount_display) ? applicationSettings.paperReceipt.discount_display : true;
            applicationSettings.invoiceSettings.showIMEI = (applicationSettings.paperReceipt.imei_display) ? applicationSettings.paperReceipt.imei_display : true;
            applicationSettings.invoiceSettings.showVariants = (applicationSettings.paperReceipt.varients_display) ? applicationSettings.paperReceipt.varients_display : true;
            applicationSettings.invoiceSettings.showTaxBreakings = (applicationSettings.paperReceipt.receiptShowTaxes) ? applicationSettings.paperReceipt.receiptShowTaxes : false;
            applicationSettings.invoiceSettings.showLoyalityInfo = (applicationSettings.paperReceipt.showLoyalityInfo) ? applicationSettings.paperReceipt.showLoyalityInfo : false;
            applicationSettings.invoiceSettings.showSerialNum = (applicationSettings.paperReceipt.serialNo_display) ? applicationSettings.paperReceipt.serialNo_display : false;
            applicationSettings.invoiceSettings.showHSN = (applicationSettings.paperReceipt.hsn_display) ? applicationSettings.paperReceipt.hsn_display : false;
            applicationSettings.invoiceSettings.showGSTAmt = (applicationSettings.paperReceipt.tax_display) ? applicationSettings.paperReceipt.tax_display : false;

            var oldKeys = Object.keys(applicationSettings.invoiceSettings);
            for (var i = 0; i < oldKeys.length; i++) {
                var currentKey = oldKeys[i];
                invoiceSettingsJSON[currentKey] = applicationSettings.invoiceSettings[currentKey];
            }
            applicationSettings.invoiceSettings = invoiceSettingsJSON;
            await couchDBUtils.update(applicationSettings, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' invoiceSettings up migration failed';
        }
        // entitlements are in profitGuruUsersAllEntitlements.json
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            var settings = {};
            settings.declaration_note = (applicationSettings.invoiceSettings.declaration_note) ? applicationSettings.invoiceSettings.declaration_note : "";
            settings.additional_note = (applicationSettings.invoiceSettings.additional_note) ? applicationSettings.invoiceSettings.additional_note : "";
            settings.sub_note = (applicationSettings.invoiceSettings.sub_note) ? applicationSettings.invoiceSettings.sub_note : "";
            settings.invoiceTitle = (applicationSettings.invoiceSettings.invoiceTitle) ? applicationSettings.invoiceSettings.invoiceTitle : "";
            settings.showCustomerSignature = (applicationSettings.invoiceSettings.showCustomerSignature) ? applicationSettings.invoiceSettings.showCustomerSignature : true;
            settings.company_tin = (applicationSettings.invoiceSettings.company_tin) ? applicationSettings.invoiceSettings.company_tin : "";
            settings.desc = "";
            settings.print_invoice = (applicationSettings.invoiceSettings.print_invoice) ? applicationSettings.invoiceSettings.print_invoice : false;
            settings.invoice_format = (applicationSettings.invoiceSettings.invoice_format) ? applicationSettings.invoiceSettings.invoice_format : "invoice_1";
            applicationSettings.invoiceSettings = settings;
            await couchDBUtils.update(applicationSettings, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' invoiceSettings setting down migration failed';
        }
    }
};