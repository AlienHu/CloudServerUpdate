'use strict';

import * as path from 'path';
let logger;
let coredb;
let couchDBUtils;

export const up = async (params) => {
    logger = params.logger;
    const migrationsBasePath = params.migrationsBasePath;
    const appRootPath = migrationsBasePath + '/../';
    couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
    const nanoClients = params.nanoClients;
    coredb = nanoClients.coredb; // main is global

    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    try {
        let appSettings = await couchDBUtils.getDoc("profitGuruApplicationSettings_", coredb);
        if (!appSettings.paymentTerms.value.includes("AlienHu App")) {
            appSettings.paymentTerms.value.push("AlienHu App");
            await couchDBUtils.update(appSettings, coredb);
            console.log("alienhu app added to payments");
        } else {
            console.log("alienhu app already exists in payments");
        }
    } catch (err) {
        logger.error(err);;
        throw "adding alienhu app in payments migration failed";
    }

};

export const down = async () => {
    return;
};