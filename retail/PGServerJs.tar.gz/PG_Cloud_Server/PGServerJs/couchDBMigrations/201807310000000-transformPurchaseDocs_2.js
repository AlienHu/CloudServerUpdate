/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        const utils = require('../controllers/common/Utils');
        const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
        const CLONE = utils.clone;

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        let coredb = nanoClients.coredb;
        let usersdb = nanoClients._users;

        try {
            const taxLib = require('../TSControllers/libraries/taxDetailsCommon');
            const commonLib = require('../controllers/libraries/commonLib');

            function subtract(a, b) {
                return (a - b);
            };

            function getPaymentsTotal(payments) {
                var total = 0;
                for (var i = 0; i < payments.length; i++) {
                    total += payments[i].payment_amount;
                }
                return total;
            }

            /**sales Multiple units */
            // let allPurchaseDocs = await couchDBUtils.getAllDocIdsByType('receiving', maindb, paramObject);
            await batchProcess(1000, 'receiving', processPuchaseDocs, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });

            async function processPuchaseDocs(allPurchaseDocs) {
                let docsToPush = [];
                let paramObject = {
                    revs: true,
                    open_revs: 'all',
                    include_docs: true // waste
                }
                for (var j = 0; j < allPurchaseDocs.length; j++) {
                    if (typeof allPurchaseDocs[j].doc.receivings_info !== 'string' && allPurchaseDocs[j].doc.receivings_info.type === 3) {
                        continue;
                    }
                    let prevRevDoc = await couchDBUtils.getTransDocByRev(allPurchaseDocs[j].key, maindb, paramObject);
                    if (!prevRevDoc) {
                        continue;
                    }
                    allPurchaseDocs[j].doc = commonLib.transformSaleDoc(allPurchaseDocs[j].doc, 'purchase');
                    for (var q = 0; q < allPurchaseDocs[j].doc.receiving_items.length; q++) {
                        if (!prevRevDoc.receiving_items[q]) {
                            if (!allPurchaseDocs[j].doc.receiving_items[q].uniqueDetails) {
                                allPurchaseDocs[j].doc.receiving_items[q].uniqueDetails = [];
                            }
                            continue;
                        }
                        if (allPurchaseDocs[j].doc.receiving_items[q].item_id === prevRevDoc.receiving_items[q].item_id) {
                            // if (allPurchaseDocs[j].doc.receiving_items[q].uniqueDetails) {
                            //     continue;
                            // }
                            if (allPurchaseDocs[j].doc.receiving_items[q].uniqueDetails.length && allPurchaseDocs[j].doc.receiving_items[q].uniqueDetails.length === allPurchaseDocs[j].doc.receiving_items[q].quantity_purchased) {
                                continue;
                            }
                            allPurchaseDocs[j].doc.receiving_items[q].uniqueDetails = prevRevDoc.receiving_items[q].uniqueDetails;
                        }
                    }

                    var paymentTotal = getPaymentsTotal(allPurchaseDocs[j].doc.payments);
                    var changeDue = subtract(paymentTotal, allPurchaseDocs[j].doc.receivings_info.total);
                    let cashPIndex = -1;
                    for (var p = 0; p < allPurchaseDocs[j].doc.payments.length; p++) {
                        if (allPurchaseDocs[j].doc.payments[p].returnAmt) {
                            delete allPurchaseDocs[j].doc.payments[p].returnAmt;
                        }
                        if (allPurchaseDocs[j].doc.payments[p].payment_type === 'Cash' && cashPIndex === -1) {
                            cashPIndex = p;
                        }
                    }
                    if (cashPIndex !== -1) {
                        allPurchaseDocs[j].doc.payments[cashPIndex].returnAmt = changeDue;
                    } else {
                        if (allPurchaseDocs[j].doc.payments.length > 1) {
                            if (allPurchaseDocs[j].doc.payments[0].payment_type !== 'Purchase On Credit') {
                                allPurchaseDocs[j].doc.payments[0].returnAmt = changeDue;

                            } else {
                                allPurchaseDocs[j].doc.payments[1].returnAmt = changeDue;

                            }
                        } else if (allPurchaseDocs[j].doc.payments.length === 1) {
                            if (allPurchaseDocs[j].doc.payments[0].payment_type !== 'Purchase On Credit') {
                                allPurchaseDocs[j].doc.payments[0].returnAmt = changeDue;

                            } else {
                                allPurchaseDocs[j].doc.payments[0].payment_amount -= changeDue;
                                allPurchaseDocs[j].doc.receivings_info.pending_amount -= changeDue;
                            }
                        }
                    }

                    allPurchaseDocs[j].doc = await commonLib.encodeTransDoc(allPurchaseDocs[j].doc, 'purchase');
                    docsToPush.push(allPurchaseDocs[j].doc);
                }
                await couchDBUtils.bulkInsert(maindb, docsToPush);
            }

            //sales return 
            // let allPurchaseRetunDocs = await couchDBUtils.getAllDocIdsByType('receivingReturn', maindb, paramObject);
            await batchProcess(1000, 'receivingReturn', processPurchaseReturnDocs, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            async function processPurchaseReturnDocs(allPurchaseRetunDocs) {
                let paramObject = {
                    revs: true,
                    open_revs: 'all',
                    include_docs: true // waste
                }
                let docsToPush = [];

                for (var k = 0; k < allPurchaseRetunDocs.length; k++) {
                    if (typeof allPurchaseRetunDocs[k].doc.info !== 'string' && allPurchaseRetunDocs[k].doc.info.type === 3) {
                        continue;
                    }
                    //computePurItem
                    let prevRevDoc = await couchDBUtils.getTransDocByRev(allPurchaseRetunDocs[k].key, maindb, paramObject);
                    if (!prevRevDoc) {
                        continue;
                    }
                    allPurchaseRetunDocs[k].doc = commonLib.transformSaleDoc(allPurchaseRetunDocs[k].doc, 'purchaseReturn');
                    for (var q = 0; q < allPurchaseRetunDocs[k].doc.items.length; q++) {
                        if (!prevRevDoc.items[q]) {
                            if (!allPurchaseRetunDocs[k].doc.items[q].uniqueDetails) {
                                allPurchaseRetunDocs[k].doc.items[q].uniqueDetails = [];
                            }
                            continue;
                        }
                        if (allPurchaseRetunDocs[k].doc.items[q].item_id === prevRevDoc.items[q].item_id) {
                            if (allPurchaseRetunDocs[k].doc.items[q].uniqueDetails.length && allPurchaseRetunDocs[k].doc.items[q].uniqueDetails.length === allPurchaseRetunDocs[k].doc.items[q].quantity_purchased) {
                                continue;
                            }
                            allPurchaseRetunDocs[k].doc.items[q].uniqueDetails = prevRevDoc.items[q].uniqueDetails;
                        }
                    }

                    var paymentTotal = getPaymentsTotal(allPurchaseRetunDocs[k].doc.payments);
                    var changeDue = subtract(paymentTotal, allPurchaseRetunDocs[k].doc.info.total);

                    let cashPIndex = -1;
                    for (var p = 0; p < allPurchaseRetunDocs[k].doc.payments.length; p++) {
                        if (allPurchaseRetunDocs[k].doc.payments[p].returnAmt) {
                            delete allPurchaseRetunDocs[k].doc.payments[p].returnAmt;
                        }
                        if (allPurchaseRetunDocs[k].doc.payments[p].payment_type === 'Cash') {

                            cashPIndex = p;
                        }
                    }
                    if (cashPIndex !== -1) {
                        allPurchaseRetunDocs[k].doc.payments[cashPIndex].returnAmt = changeDue;
                    } else {
                        if (allPurchaseRetunDocs[k].doc.payments.length > 1) {
                            if (allPurchaseRetunDocs[k].doc.payments[0].payment_type !== 'Purchase On Credit') {
                                allPurchaseRetunDocs[k].doc.payments[0].returnAmt = changeDue;

                            } else {
                                allPurchaseRetunDocs[k].doc.payments[1].returnAmt = changeDue;

                            }
                        } else if (allPurchaseRetunDocs[k].doc.payments.length === 1) {
                            if (allPurchaseRetunDocs[k].doc.payments[0].payment_type !== 'Purchase On Credit') {
                                allPurchaseRetunDocs[k].doc.payments[0].returnAmt = changeDue;

                            } else {
                                allPurchaseRetunDocs[k].doc.payments[0].payment_amount -= changeDue;
                                allPurchaseRetunDocs[k].doc.info.pending_amount -= changeDue;
                            }
                        }
                    }

                    allPurchaseRetunDocs[k].doc = await commonLib.encodeTransDoc(allPurchaseRetunDocs[k].doc, 'purchaseReturn');
                    docsToPush.push(allPurchaseRetunDocs[k].doc);
                }
                await couchDBUtils.bulkInsert(maindb, docsToPush);
            }

        } catch (err) {
            logger.error(err);
            throw migrationName + ' up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        const commonLib = require('../controllers/libraries/commonLib');
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        let nanoUsers = nanoClients._users;

        try {
            //as if now down migration is not required
            //todo write code if down is rquired

        } catch (err) {
            logger.error(err);
            throw migrationName + ' down migration failed';
        }
    }
};