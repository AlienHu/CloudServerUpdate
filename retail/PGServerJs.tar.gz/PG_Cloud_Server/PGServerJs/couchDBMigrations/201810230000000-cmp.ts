/**
 */

'use strict';

import * as path from 'path';
import * as moment from 'moment';

export const up = async (params) => {
    let logger = params.logger;
    let nanoClients = params.nanoClients;
    const mainDBInstance = nanoClients.maindb;

    let migrationName = path.basename(__filename, '.js');
    try {

        let allCmpDocsArr: OldAllDocsResponseRow[] = await getAllCmpDocs(mainDBInstance, logger);

        let newDocs: NewBasicCampaign[] = [];
        for (let i: number = 0; i < allCmpDocsArr.length; i++) {
            // @ts-ignore
            let cmp: NewBasicCampaign = allCmpDocsArr[i].doc;
            for (let j: number = 0; j < cmp.customers.length; j++) {
                // @ts-ignore
                if (cmp.customers[j].status) {
                    // @ts-ignore
                    cmp.customers[j].smsStatus = cmp.customers[j].status;
                    cmp.customers[j].cAppStatus = cmp.customers[j].smsStatus;
                    // @ts-ignore
                    delete cmp.customers[j].status;
                }

            }
            newDocs.push(cmp);
        }

        if (newDocs.length) {
            await bulkDocs(newDocs, mainDBInstance, undefined, undefined, logger);
        }

    } catch (error) {
        logger.error(error);
        throw migrationName + ' up migration failed';
    }
};

export const down = async (params) => {
    let logger = params.logger;

    let nanoClients = params.nanoClients;
    const mainDBInstance = nanoClients.maindb;


    let migrationName = path.basename(__filename, '.js');
    try {
        let allCmpDocs: NewAllDocsResponseRow[] = await getAllCmpDocs(mainDBInstance, logger);
        let newDocs: OldBasicCampaign[] = [];
        for (let i: number = 0; i < allCmpDocs.length; i++) {
            // @ts-ignore
            let cmp: OldBasicCampaign = allCmpDocs[i].doc;
            for (let j: number = 0; j < cmp.customers.length; j++) {
                // @ts-ignore
                if (cmp.customers[j].smsStatus) {
                    // @ts-ignore
                    cmp.customers[j].status = cmp.customers[j].smsStatus;
                    // @ts-ignore
                    delete cmp.customers[j].cAppStatus;
                }
            }
            newDocs.push(cmp);
        }

        if (newDocs.length) {
            await bulkDocs(newDocs, mainDBInstance, undefined, undefined, logger);
        }

    } catch (error) {
        logger.error(error);
        throw migrationName + ' up migration failed';
    }

};


const getAllDocsByType = async function (type, db, params, bOnlyDocs, logger) {
    params = params || {};
    params.startkey = type + '_';
    params.endkey = type + '_z';
    params.include_docs = true;

    try {
        let [body, header] = await db.fetch({}, params);
        if (!bOnlyDocs) {
            return body.rows;
        } else {
            //This is just wasting of 1 for loop for the inconvinience of having to write body.rows[i].doc everytime
            //Bad don't use it
            let resp = [];
            for (let i = 0; i < body.rows.length; i++) {
                resp.push(body.rows[i].doc);
            }

            return resp;
        }
    } catch (err) {
        logger.error(err);
        throw 'Fatal! Not expected to come here. This API doesnt throw any error';
    }
};

const bulkDocs = async function (docsArray, db, reTryCount, docType, logger) {
    if (reTryCount === undefined) {
        reTryCount = 99;
    }

    if (reTryCount === 0) {
        throw 'Out of trials';
    }
    if (docType) {
        let ts = parseInt(moment().format("x"));
        docsArray.forEach(function (doc) {
            if (!doc._id) {

                doc._id = docType + '_' + ts;
                ts += 1;
            }
        });
    }

    try {
        let resp = await db.bulk({
            docs: docsArray
        });

        let pendingDocs = [];
        for (let i = 0; i < resp.length; i++) {
            if (resp[i].error || resp[i].reason) {
                if (resp[i].error === 'conflict' || resp[i].reason === 'Document update conflict.') {
                    throw resp[i]._id + ' Document update conflict.';
                }

                pendingDocs.push(docsArray[i]);
            }
        }

        if (pendingDocs.length) {
            return await bulkDocs(pendingDocs, db, reTryCount - 1, undefined, logger);
        }

        return 0;
    } catch (error) {
        logger.error(error);
        logger.error('bulkInsert2 catch block. Not Expected to come here');
        throw 'Internal Error';
    }
};

const getAllCmpDocs = async (mainDBInstance: any, logger: any): Promise<AllDocsResponseRow[]> => {
    let allCmpDocsArr: AllDocsResponseRow[] = [];
    let respRowArr: AllDocsResponseRow[] = await getAllDocsByType('cmp', mainDBInstance, undefined, false, logger);
    Array.prototype.push.apply(allCmpDocsArr, respRowArr);
    respRowArr = await getAllDocsByType('wisher', mainDBInstance, undefined, false, logger);
    Array.prototype.push.apply(allCmpDocsArr, respRowArr);
    respRowArr = await getAllDocsByType('scheduler', mainDBInstance, undefined, false, logger);
    Array.prototype.push.apply(allCmpDocsArr, respRowArr);

    return allCmpDocsArr;
}

let COMPLETED = 'completed';

interface TemplateType {
    _id: string;
    _rev?: string;
    name: string; //Birthday, Christmas
    templates: Template[];
    iPendingCount: number; //This is a cheating variable. Update only for doc in maindb. For licencedb it is  0
    isUpdate?: boolean;
    deleted?: string;
    _deleted?: boolean;
}

type Timestamp = string;

interface Template {
    message: string;
    modifiedTs: Timestamp;
    bApproved: boolean;
}

interface NewCmpCustomers {
    _id: string;
    smsStatus: string;
    email: string;
    cAppStatus: string;
}

interface NewBasicCampaign {
    message: string;
    template: Template; //Selected Template from TemplateType
    templateType: TemplateType; //Birthday, Christmas full details
    _id: string;
    _rev?: string;
    templateTypeName?: string; //Birthday, Christmas
    isTemplate: boolean; //Save the template checkbox in UI
    sendEmail: boolean;
    sendSMS: boolean;
    customers: NewCmpCustomers[];
    status: string;
    nextTime: string;
    retryCount: number;
    feedbackFormId?: string;
}

interface OldAllDocsResponseRow {
    id: string;
    doc: OldBasicCampaign;
    key: any;
    value: any;
}

interface NewAllDocsResponseRow {
    id: string;
    doc: NewBasicCampaign;
    key: any;
    value: any;
}

interface AllDocsResponseRow {
    id: string;
    doc: any;
    key: any;
    value: any;
}

interface OldBasicCampaign {
    message: string;
    template: Template; //Selected Template from TemplateType
    templateType: TemplateType; //Birthday, Christmas full details
    _id: string;
    _rev?: string;
    templateTypeName?: string; //Birthday, Christmas
    isTemplate: boolean; //Save the template checkbox in UI
    sendEmail: boolean;
    sendSMS: boolean;
    customers: OldCmpCustomers[];
    status: string;
    nextTime: string;
    retryCount: number;
    feedbackFormId?: string;
}

interface OldCmpCustomers {
    _id: string;
    status: string;
    email: string;
}