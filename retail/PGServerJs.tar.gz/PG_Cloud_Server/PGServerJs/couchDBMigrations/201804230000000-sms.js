/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;
        try {
            var params = {};
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            var allUsersDoc = [];
            var json = {
                "desc": "Allows to Make the HomeDelivery",
                "viewOnMenu": false,
                "allowNone": false,
                "allowAll": false,
                "takeOrder": {
                    "apis": ["addCustomer2OrdersRestApi", "saveDeliveryRetailRestApi", "saveDeliveryRestApi", "additemRestApi", "cancel_saleRestApi", "getCartTaxes", "editItemRestApi", "getEditRestApi", "removeitemRestApi", "getItemDiscountRestApi", "DeleteItemFromCartRestApi", "saveDeliveryRestApi", "getItemsRestApi"],
                    "allowed": false,
                    "desc": "Allows to Take Order For Home Delivery"
                },
                "sendSms": {
                    "apis": ["/common/sendSMS"],
                    "common": true,
                    "allowed": false,
                    "desc": "Allows to Send SMS to the Customer"
                },
                "editOrder": {
                    "apis": ["getEditRestApi", "editItemRestApi"],
                    "allowed": false,
                    "desc": "Allows to edit the HomeADelivery Order"
                },
                "viewOrder": {
                    "apis": ["allSuspendedSalesRestApi"],
                    "allowed": false,
                    "desc": "Allows to View All HomeDelivery Orders"
                },
                "takeOrderPayment": {
                    "apis": ["add_paymentRestApi"],
                    "allowed": false,
                    "desc": "Allows to Take the Payment of the HomeDelivery"
                },
                "completeDelivery": {
                    "apis": ["completeDeliverySaleApiRestApi"],
                    "allowed": false,
                    "desc": "Allows to Complete the HomeDelivery Transaction"
                },
                "deleteOrder": {
                    "apis": ["deleteHomeDeliveryRestApi"],
                    "allowed": false,
                    "desc": "Allows to Delete the HomeDelivery Order"
                }
            };
            for (var i = 0; i < allUsers.length; i++) {
                try {
                    allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                } catch (error) {
                    logger.error(error);
                    continue;
                }

                if (allUsers[i].value.roles[1] === 'admin') {
                    json.allowAll = true;
                    json.viewOnMenu = true;
                }
                allUsers[i].value.roles[0].homeDelivery = json;
                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);

                allUsersDoc.push(allUsers[i].value);
            }
            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
        try {
            var allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', nanoCore);
            allowedFeatures.homeDelivery = {
                "enabled": true,
                "desc": ""
            }
            await couchDBUtils.update(allowedFeatures, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' up-2 migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            var params = {};
            let allUsersDoc = [];
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            for (var i = 0; i < allUsers.length; i++) {
                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);

                if (allUsers[i].value.roles[0].hasOwnProperty('homeDelivery')) {
                    delete allUsers[i].value.roles[0].homeDelivery;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('homeDelivery property not found');
                }
                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                allUsersDoc.push(allUsers[i].value);
            }

            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);
        } catch (error) {
            logger.error(error);
            logger.error('homeDelivery down migration failed');
            throw error;
        }
        try {
            var allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', nanoCore);
            if (allowedFeatures.hasOwnProperty('homeDelivery')) {
                delete allowedFeatures.homeDelivery;
            }
            await couchDBUtils.update(allowedFeatures, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' allowedFeature down migration failed';
        }
    }
};