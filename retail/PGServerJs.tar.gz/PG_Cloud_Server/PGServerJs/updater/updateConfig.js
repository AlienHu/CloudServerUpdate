var path = require("path");
var UpdaterDir;
var MYSELF;

if (!process.env.MYSELF) {
    MYSELF = process.env.MYSELF = 'PGServerJs';
} else {
    MYSELF = process.env.MYSELF;
}

if (!process.env.UpdaterDir) {
    UpdaterDir = process.env.UpdaterDir = path.resolve(__dirname + '/../../profitGuruUpdater');
} else {
    UpdaterDir = path.resolve(process.env.UpdaterDir);
}

var baseUpdateconfig = function() {

    if (process.env.ENVIRONMENT === 'production') {
        return {
            path: {
                liveAppParentDir: path.resolve(UpdaterDir, 'installedServers/currentLive/'),
                liveAppVersionDetails: path.resolve(UpdaterDir, 'installedServers/currentLive/' + MYSELF + '/package.json'),
                installerDownLoadDir: path.resolve(UpdaterDir, "unInstalledServers/"),
                availableUpdateInfo: path.resolve(UpdaterDir, "update/updateAvailable.json"),
                process2Launch: path.resolve(UpdaterDir, 'installedServers/currentLive/' + MYSELF + '/bin/PGServerJs.js')
            },
            fileWatchers: {
                doUpdateFile: path.resolve(UpdaterDir, "update/doUpdate.json")
            },

            aws: {
                host: "idtdyqhwui.execute-api.ap-south-1.amazonaws.com",
                ssl: true,
                apiKey: "WybIeEbyiD7M1swKjI3en2PPW9CiZhwE5ZEyqxwF",
                api: {
                    fwCheck: "/testing_updater/firmware/check"
                }
            },
            default: {
                dwldDir: path.resolve(UpdaterDir, "unInstalledServers/"),
                doNpmInstallOnUpdate: false
            },
            tout: {
                updateCheck: 1000 * 60 * 60 * 8
            },
            takeBackUpB4Update: true
        };
    } else {
        return {
            path: {
                liveAppParentDir: path.resolve(UpdaterDir, 'installedServers/currentLive/'),
                liveAppVersionDetails: path.resolve(UpdaterDir, 'installedServers/currentLive/' + MYSELF + '/package.json'),
                installerDownLoadDir: path.resolve(UpdaterDir, "unInstalledServers/"),
                availableUpdateInfo: path.resolve(UpdaterDir, "update/updateAvailable.json"),
                process2Launch: path.resolve(UpdaterDir, 'installedServers/currentLive/' + MYSELF + '/bin/PGServerJs.js')
            },
            fileWatchers: {
                doUpdateFile: path.resolve(UpdaterDir, "update/doUpdate.json")
            },

            aws: {
                host: "127.0.0.1",
                ssl: false,
                apiKey: "BdXawOw9Mm8pxqyElIhg6aQaF3ON5f0S5cRgcOot",
                api: {
                    fwCheck: "/profitguru/firmware/check"
                }
            },
            default: {
                dwldDir: path.resolve(UpdaterDir, "unInstalledServers/"),
                doNpmInstallOnUpdate: false
            },
            tout: {
                updateCheck: 1000 * 60 * 1
            },
            port: 3337,
            takeBackUpB4Update: true
        };
    }
};

module.exports = function updaterConfig() {
    var extendedConfig = baseUpdateconfig();

    extendedConfig.UpdaterDir = UpdaterDir;
    //Parents directories
    extendedConfig.liveAppParentDir = extendedConfig.path.liveAppParentDir;
    extendedConfig.previousLiveAppParentDir = path.resolve(extendedConfig.liveAppParentDir, "..", "previousLive");
    extendedConfig.toBeLiveAppParentDir = path.resolve(extendedConfig.liveAppParentDir, "..", "preparing2GoLive");

    //CurrentApp Directories
    extendedConfig.liveAppDir = path.resolve(extendedConfig.liveAppParentDir, MYSELF);
    extendedConfig.previousLiveAppDir = path.resolve(extendedConfig.liveAppParentDir, "..", "previousLive", MYSELF);
    extendedConfig.toBeLiveAppDir = path.resolve(extendedConfig.liveAppParentDir, "..", "preparing2GoLive", MYSELF);
    extendedConfig.connectMeAt = 'http://localhost:' + process.env.PROFITGURU_SERVER_PORT;
    return extendedConfig;
};