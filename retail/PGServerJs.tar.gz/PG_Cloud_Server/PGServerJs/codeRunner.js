var tk = require('timekeeper');
var moment = require('moment');
var time = new Date(1893448800000); // January 1, 2030 00:00:00
var today = moment(new Date());
console.log(time instanceof Date);
console.log(today instanceof moment);
console.log(today instanceof Date);

console.log(new Date());
tk.travel(time); // Travel to that date.

console.log(new Date());
setTimeout(function() {

    // `time` + ~500 ms.

    var date = new Date;
    var ms = Date.now();
    console.log(date);
    tk.reset(); // Reset.

}, 2000);