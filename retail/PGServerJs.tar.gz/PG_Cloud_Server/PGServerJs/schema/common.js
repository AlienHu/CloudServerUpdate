    const logger = require('../common/Logger');
    let common = function() {
        this.getJSON = function(type, allowNULL, _default) {
            return {
                type: type,
                allowNULL: allowNULL,
                _default: _default
            };
        };
    }
    module.exports = new common();