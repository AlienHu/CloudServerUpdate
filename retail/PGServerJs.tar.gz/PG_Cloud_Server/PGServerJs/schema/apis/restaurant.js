const getJSON = require('../common.js').getJSON;
/**
 * date check is string 
 * array and object are checked as object
 */
let resturantApi = function() {

    this.saveReservation = {
        table_no: getJSON('number', false),
        book_time: getJSON('string', false),
        booking_Call_Time: getJSON('string', false),
        booking_end_time: getJSON('string', false),
        customer_contact_info: getJSON('string', false),
        employee: getJSON('string', true),
        Description: getJSON('string', false)

    }

    this.deleteReservation = {
        reservation_id: getJSON('number', false)
    }
    this.selectTable = {
        bookingEndTime: getJSON('string', false),
        bookingTime: getJSON('string', false)
    }
    this.minimumReservationDuration = {

    };
    this.getReservationDetails = {

    };
    this.getReservationDetails4TableColorChange = {

    };
    this.checkReservation4table = {
        tableNo: getJSON('number', false)
    }
    this.checkAlreadyReservedRestApi = {

        table_no: getJSON('number', false)

    };
    this.reservationWindow = {
        starttime: getJSON('string', false),
        endtime: getJSON('string', false)
    };

}

module.exports = new resturantApi();