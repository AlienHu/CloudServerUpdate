require('errors');
//Shuould not be included in production release
var bodyParser = require('body-parser');
var dbMangerRoute = require('express').Router();
var shellJs = require('shelljs');
var logger = require('../common/Logger');
var isWin = /^win/.test(process.platform);
dbMangerRoute.use(bodyParser.urlencoded({
    extended: true
}));
dbMangerRoute.use(bodyParser.json());
var bonjourService = require('../common/bonjourServer.js');

dbMangerRoute.post('/', function(req, res) {
    var options = req.body;
    try {
        var cmd = "node " + __dirname + '/../dbManagers/resetDB.js ' + '-d ' + true + ' -c ' + true + ' -s ' + options.serverId + ' -t ' + options.bTrial + ' -BL ' + options.backUpLocation;
        var result = {
            done: false,
            restarted: false
        };

        var execResult = shellJs.exec(cmd);

        if (execResult.code !== 0) {
            result.errorMsg = execResult.stdout;
        } else {
            result.done = true;
        }

        //Self Re-start after Db Reset
        if (options.restart) {
            bonjourService.stopBonjourServiceInstance(); //.stop();
            if (!isWin) {
                var retsartCmd = "node " + __dirname + '/../bin/PGServerJs.js';
                result.restarted = true;

                shellJs.exec(retsartCmd);
            } else {
                //killing node process
                logger.info('Reset Dbs');
                res.send(result);
                res.end();
                setTimeout(function() {
                    process.exit();
                }, 3000);
                return;
            }
        }
        logger.info('Reset Dbs');
        res.send(result);
        res.end();
        //process.exit(0);
    } catch (exception) {
        console.log(exception);
        logger.error(exception);
        res.send(new Error(exception));
        res.end();
    }
});

module.exports = dbMangerRoute;