var fs = require('fs');
//var csv2json = require('csv2json');
require('dotenv-safe').load({
    path: __dirname + '/.env',
    sample: __dirname + '/env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 -f items.csv -t items')
    .alias('f', 'fileName')
    .describe('f', 'csv file name')
    .default('f', '/home/ganesh/profitGuru_Workspace/profitguru/PGServerJs/test/unit/controllers/ExportedItems_ref.csv')
    .alias('t', 'type')
    .describe('t', 'specify element type - item/customer/supplier')
    .choices('t', ['items', 'customers', 'suppliers'])
    .default('t', 'items')
    .demand(['f', 't'], 'Please provide mandatory arguments')
    .argv;
var file = argv.f;
const couchDbManager = require('../dbManagers/couchDbManager');

console.log(argv.f);
console.log(argv.type);
var itemsArray = [];
var csv = require('csvtojson')
// csv()
csv()
    .fromFile(file)
    .on('json', (jsonObj) => {
        // combine csv header row and csv line to a json object 
        // jsonObj.a ==> 1 or 4 
        // console.log(jsonObj);
        itemsArray.push(jsonObj);
        console.log("Array starts here");

    })
    .on('done', (error) => {
        // console.log(itemsArray[0]);
        console.log('end');
        console.log(error);
        return couchDbManager.initCouchDb(false).then(function(resp) {
            var itemController = require('./controllers/Items');
            return itemController.importItems(itemsArray);
        }).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
        });
        // .then(function(resp) {
        //     // defered.resolve(resp);
        //     console.log('successfully created Items');
        // }).catch(function(err) {
        //     console.log('items creation faild');
        //     // defered.reject(false);
        // });
    });