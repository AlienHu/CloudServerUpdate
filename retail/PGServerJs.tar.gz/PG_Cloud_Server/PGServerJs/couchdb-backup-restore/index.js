'use strict';

const httpUtils = require('../common/httpUtils');
const shelljs = require('shelljs');
const configState = require('../common/configState');
const path = require('path');
const couchDBUtils2 = require('../couchDb/couchDBUtils2');
let couchbackup;
let nano = require('nano-blue')("http://" + process.env.COUCHDB_USERNAME + ":" + process.env.COUCHDB_PASSWORD + "@127.0.0.1:5984");
let couchDBUtils;
const logger = require('../common/Logger');
let instPathPrefix = '';
let bCouch2;
const isWin = /^win/.test(process.platform);
dummyInit();
async function dummyInit() {
    bCouch2 = await couchDBUtils2.isCouch2();
    if (bCouch2) {
        couchbackup = require('couchbackup');
    }
}
// bCouch2 = true; //not yet done
function getDatabaseFilesToBackup(databaseDir) {
    // bCouch2 = await couchDBUtils2.isCouch2();
    let appConfig = configState.getAppConfig();
    let dbPrefix = appConfig.localCouch.DBPrefix;

    let dbFileNames = [];
    for (let dbSuffix in appConfig.localCouch.DBs) {
        if (dbSuffix === 'hsndb') {
            continue;
        }
        if (bCouch2) {
            dbFileNames.push(couchDBUtils2.getDBName(dbPrefix, process.env.APP_TYPE, dbSuffix, appConfig.localCouch.DBs[dbSuffix].appSpecific));
        } else {
            dbFileNames.push(path.resolve(databaseDir, couchDBUtils2.getDBName(dbPrefix, process.env.APP_TYPE, dbSuffix, appConfig.localCouch.DBs[dbSuffix].appSpecific) + '.couch'));
        }

    }

    return dbFileNames;
}

function getDatabaseNamesToBackup() {
    let appConfig = configState.getAppConfig();
    let dbPrefix = appConfig.localCouch.DBPrefix;

    let dbNames = [];
    for (let dbSuffix in appConfig.localCouch.DBs) {
        if (dbSuffix === 'hsndb') {
            continue;
        }

        dbNames.push(couchDBUtils2.getDBName(dbPrefix, process.env.APP_TYPE, dbSuffix, appConfig.localCouch.DBs[dbSuffix].appSpecific));
    }

    return dbNames;
}

//windows ../var/lib/couchdb
async function getDatabaseDir() {

    if (isWin && !instPathPrefix) {
        let utils = require('../common/npmUtils');
        try {
            instPathPrefix = await utils.getWinCouchInstDir();
        } catch (error) {
            logger.info('Assuming new couchdb location');
            instPathPrefix = 'C:/ProfitGuru/CouchDB'
        }
        instPathPrefix = path.resolve(instPathPrefix, 'bin');
    }

    if (!couchDBUtils) {
        couchDBUtils = require('../controllers/common/CouchDBUtils');
    }
    let response = await couchDBUtils.getDatabaseDir();
    if (!path.isAbsolute(response) && instPathPrefix) {
        response = path.resolve(instPathPrefix, response);
    }
    return response;
}

const deleteViews = async () => {
    if (!couchDBUtils) {
        couchDBUtils = require('../controllers/common/CouchDBUtils');
    }
    const viewFullPath = await couchDBUtils.getViewDirectory();
    shelljs.rm('-r', viewFullPath);
    logger.info('couch views deleted');
}

async function backup(params) {
    // bCouch2 = await couchDBUtils2.isCouch2();

    if (bCouch2) {
        await createBackupDb();
        await replicateBackupDb();
        let dbFileNames = getDbNameInOrder(getDatabaseFilesToBackup());
        let add = 0;
        let promises = [];
        for (let i = 0; i < dbFileNames.length; i++) {
            // add += 5000;
            add += 1000;
            promises.push(couch2BackupHandler(add, dbFileNames[i], params.backUpLocation));
        }
        try {
            let resp = await Promise.all(promises);
            console.log('all backup done');
            logger.info('all backup done');
        } catch (err) {
            console.error(err);
            throw '2.0 Backup failed';
        }

    } else {
        let databaseDir = await getDatabaseDir();
        let dbFileNames = getDatabaseFilesToBackup(databaseDir);
        for (let i = 0; i < dbFileNames.length; i++) {
            shelljs.cp(dbFileNames[i], params.backUpLocation);
        }
    }
}

function couch2BackupHandler(add, dbFileName, backUpLocation) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            let destPath = backUpLocation + '/' + dbFileName + '.couch';
            let opts = {
                "COUCH_URL": "http://" + process.env.COUCHDB_USERNAME + ":" + process.env.COUCHDB_PASSWORD + "@localhost:5984",
                "COUCH_DATABASE": dbFileName,
            }
            if (dbFileName !== "_users") {
                couchbackup.backupFile(destPath, opts, function () {
                    logger.info(dbFileName + ' backup is done');
                    console.log(dbFileName + ' backup is done');
                    resolve(add);
                });
            } else {
                opts.COUCH_DATABASE = 'userbackup'; //creating temp db to sync userdb
                couchbackup.backupFile(destPath, opts, async function () {
                    logger.info(dbFileName + ' backup is done');
                    console.log(dbFileName + ' backup is done');
                    await deleteBackupDb();
                    console.log(dbFileName + ' temp userdb backup is cleared');
                    resolve(add);
                });
            }
        }, add);
    });
}

function getDbNameInOrder(dbFileNames) {
    var x = dbFileNames.splice(dbFileNames.indexOf("pg_collection_" + process.env.APP_TYPE + "_maindb"), 1)
    dbFileNames.push(x[x.indexOf("pg_collection_" + process.env.APP_TYPE + "_maindb")])
    return dbFileNames;
};

async function createBackupDb() {
    try {
        let resp = await nano.db.create('userbackup');
        logger.info(resp);
    } catch (err) {
        logger.info('db Creation failed.');
        logger.info(err);
    };
};
async function replicateBackupDb() {
    try {
        let rep = await nano.db.replicate('http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@localhost:5984/_users', 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@localhost:5984/userbackup')
        logger.info(rep);
    } catch (err) {
        logger.info('replication failed');
    }
};
async function deleteBackupDb() {
    try {
        let resp = await nano.db.destroy('userbackup');
        logger.info(resp);
    } catch (err) {
        logger.info(err);
    }
};

function stopStartCouch(bStop) {
    let key = 'start'
    if (bStop) {
        key = 'stop';
    }

    let cmd = 'service couchdb ' + key;
    if (isWin) {

        cmd = 'net ' + key + ' "Apache CouchDB"';
    }

    shelljs.exec(cmd);
}

async function restore(params) {
    if (bCouch2) {
        let dbFileNames = getDatabaseFilesToBackup();
        for (let i = 0; i < dbFileNames.length; i++) {
            let backUpFile = params.backUpLocation2Restore + dbFileNames[i] + '.couch';
            var opts = {
                "COUCH_URL": "http://" + process.env.COUCHDB_USERNAME + ":" + process.env.COUCHDB_PASSWORD + "@localhost:5984",
                "COUCH_DATABASE": dbFileNames[i],
            }
            let bFailed = true;
            couchbackup.restoreFile(backUpFile, opts, function () {
                console.log('Restore of ' + dbFileNames[i] + 'Done');
            });
        }
    } else {

        let databaseDir = await getDatabaseDir();

        /**
         * The below code was written in suspicion that if we just delete the database file some error may come
         * So first deleting those databases, then copying
         */
        // let dbNames = getDatabaseNamesToBackup();
        // let couchInstance = require('nano-blue')("http://"+process.env.COUCHDB_USERNAME+":"+process.env.COUCHDB_PASSWORD+"@127.0.0.1:5984");

        // for (let i = 0; i < dbNames.length; i++) {
        //     logger.silly(dbNames[i]);
        //     try {
        //         await couchInstance.db.destroy(dbNames[i]);
        //     } catch (error) {
        //         logger.error(dbNames[i] + ' doesnot exist');
        //     }
        // }
        /**
         * Stop Start CouchDB is required to avoid clashes with users db
         * we delete user db, but couchdb creates automatically
         */

        logger.silly(params.backUpLocation2Restore);
        await copyData(params.backUpLocation2Restore, databaseDir, true);
    }
}

async function copyData(srcPath, dstPath, bDeleteView) {
    stopStartCouch(true);
    if (bDeleteView) {
        try {
            await deleteViews();
        } catch (err) {
            logger.error(err);
        }

    }
    let stdOut = shelljs.cp(srcPath + '/*', dstPath);

    if (!isWin) {
        shelljs.exec('chown -R couchdb:couchdb /var/lib/couchdb');
    }
    stopStartCouch(false);
    return stdOut.code === 0;
}

/**
 * 
 * @param {*} params 
 */
async function changeDatabaseDir(req) {
    if (bCouch2) {
        throw 'unimplemented';
    }

    let params = req.body;
    if (!params.path) {
        throw "Empty path";
    }

    let appSettings = configState.getApplicationSettings();
    let oldDir = appSettings.databaseLocation.path;
    if (path.resolve(oldDir) === path.resolve(params.path)) {
        throw "No change in database dir";
    }

    let newPath = path.resolve(params.path, 'pg/data');
    if (shelljs.mkdir('-p', newPath).code !== 0) {
        throw "Failed to create directory. Please choose some other directory";
    };

    if (shelljs.ls(newPath).length !== 0) {
        throw "Path is not empty."
    }

    let oldPath = await getDatabaseDir();
    let resp = await copyData(oldPath, newPath);
    if (!resp) {
        throw "Failed to move database. Try Again Later.";
    }

    if (!couchDBUtils) {
        couchDBUtils = require('../controllers/common/CouchDBUtils');
    }
    let applicationSettingsCouchHandler = require('../couchDb/applicationSettingsCouchHandler')();

    try {
        appSettings.databaseLocation.path = params.path;
        req.body = appSettings;
        logger.info('updating settings');
        await applicationSettingsCouchHandler.updateApplicationSettings(req, process.env.APP_TYPE);
        logger.info('settings updated');

        logger.info('updating db path');
        await couchDBUtils.updateDatabaseDir(newPath);
        logger.info('updated db path');
        Promise.resolve().then(function () {
            //deleting in async
            shelljs.rm('-r', oldDir);
        });

        return 'Database Path Changed';
    } catch (error) {
        logger.error(error);
        logger.error('danger change databasedir');

        throw error;
    }

    //send statistics of copy if available
}

module.exports = {
    backup: backup,
    restore: restore,
    changeDatabaseDir: changeDatabaseDir
};