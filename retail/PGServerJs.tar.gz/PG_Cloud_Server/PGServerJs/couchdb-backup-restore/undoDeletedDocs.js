'use strict';

// require('errors');

var couchDB;
var couchDBOther;
var couchDbMain = require('../couchDb/couchDBMain');
var utils = require('../controllers/common/Utils');
const CLONE = utils.clone;

var _self = this;
let APP_TYPE = 'retail';

var couchDBUtils = require('../controllers/common/CouchDBUtils');
//In case couchDbMain is not done , i.e. when couchDbUtils used before launching the PGServerJs 
//Ex: in controller unit tests
if (couchDbMain.isInitDone()) {
    couchDB = couchDbMain;
} else {
    initCouchDbMyself();
}
initCouchDbOther();

function initCouchDbMyself() {
    var createSingleton = require('create-singleton');

    var initCouchDB = function() {
        // var couchUsersDbUrl = 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT;
        var couchUsersDbUrl = 'http://' + 'couchadmin' + ':' + 'test' + '@127.0.0.1:5984';
        var nano = require('nano-blue')(couchUsersDbUrl);
        var dbName = 'pg_collection_' + APP_TYPE + '_maindb';
        var userDBName = '_users';
        var coreDBName = 'pg_collection_' + APP_TYPE + '_coredb';
        var licenceDBName = 'pg_collection_' + APP_TYPE + '_licencedb';

        this.getMainDbCouchClient = function() {
            return nano.use(dbName);
        };

        this.getUserDBClient = function() {
            return nano.use(userDBName);
        };

        this.getCoreDBClient = function() {
            return nano.use(coreDBName);
        };

        this.getLicenceDBClient = function() {
            return nano.use(licenceDBName);
        };

    };

    // Todo: is there use
    // for this singleton ?
    var initCouchDBSingleton = createSingleton(initCouchDB);
    couchDB = new initCouchDBSingleton();
}

function initCouchDbOther() {
    var createSingleton = require('create-singleton');

    var initCouchDB = function() {
        // var couchUsersDbUrl = 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT;
        var couchUsersDbUrl = 'http://couchadmin:test@163.172.165.51:5984/';
        var nano = require('nano-blue')(couchUsersDbUrl);
        var dbName = 'pg_collection_retail_maindb';
        var userDBName = '_users';
        var coreDBName = 'pg_collection_' + APP_TYPE + '_coredb';
        var licenceDBName = 'pg_collection_' + APP_TYPE + '_licencedb';

        this.getMainDbCouchClient = function() {
            return nano.use(dbName);
        };

    };

    // Todo: is there use
    // for this singleton ?
    var initCouchDBSingleton = createSingleton(initCouchDB);
    couchDBOther = new initCouchDBSingleton();
}

this.getMainCouchDB = function() {
    return couchDB.getMainDbCouchClient();
};

this.getOtherCouchDB = function() {
    return couchDBOther.getMainDbCouchClient();
};

async function getDeletedDoc(DB, ID, rev) {

    let param = {
        revs: true,
        open_revs: 'all',
        include_docs: true // waste
    }
    if (rev) {
        param._rev = rev
    };
    try {
        let respDoc = await DB.get(ID, param);
        let deletedDoc = respDoc[0][0].ok;
        //localhost:5984/pg_collection_retail_maindb/ID?revs=true&open_revs=all
        if (deletedDoc._id) {
            return deletedDoc;
        } else {
            throw '_id not available in deleted doc'
        }
    } catch (err) {
        console.error(err);
        throw 'failed to get deleted doc'
    }
}

async function getChanges(DB) {
    try {
        let changes = await DB.changes();
        return changes[0].results;
    } catch (err) {
        console.error(err);
        return 'failed to get changes'
    }
}

async function handleDeletedDoc(DB, docType, localDB) {
    try {
        let changes = await getChanges(DB);
        let updateDocArr = [];
        let maxId = 0;
        if (changes && changes.length) {
            for (let i = 0; i < changes.length; i++) {
                let thisChangeDoc = changes[i];
                if (thisChangeDoc.id.indexOf(docType + '_') > -1 && thisChangeDoc.deleted === true) {
                    let deletedDocRev = await getDeletedDoc(DB, thisChangeDoc.id);
                    let deletedDoc = await getDeletedDoc(DB, thisChangeDoc.id, deletedDocRev._revisions.start - 1 + '-' + deletedDocRev._revisions.ids[1]);
                    //todo get document one revision before deleting
                    if (!deletedDoc.sale_id && !thisChangeDoc.bDeleted) deletedDoc.sale_id = parseInt(deletedDoc._id.substr(deletedDoc._id.indexOf('_') + 1, deletedDoc._id.length));
                    maxId = maxId < deletedDoc.sale_id ? deletedDoc.sale_id : maxId;
                    if (deletedDoc._id) {
                        delete deletedDoc._rev; // delete last rev
                        delete deletedDoc._revisions; // deleted pre rev
                        delete deletedDoc._deleted; // delete flag
                        deletedDoc.etc = 'created from deleted';
                        updateDocArr.push(deletedDoc);
                    }
                }
            }
        } else {
            console.log('no changes found');
        }
        let currentDocs = await getCurrentDocs(DB, docType);
        let deleteExistArr = [];
        for (let i = 0; i < currentDocs.length; i++) {
            let thisDoc = currentDocs[i].doc;
            let newDoc = CLONE(thisDoc); // copy of existing
            thisDoc._deleted = true;
            thisDoc.etc = 'deleted from existing';
            deleteExistArr.push(thisDoc); // delete existing 

            let newSaleId = maxId + i + 1;
            newDoc._id = 'sale_' + newSaleId;
            if (!newDoc.sale_id) newDoc.sale_id = parseInt(newDoc._id.substr(newDoc._id.indexOf('_') + 1, newDoc._id.length));
            newDoc.sale_id = newSaleId;
            newDoc.etc = 'recreated from existing';
            newDoc.sales_info.sale_id = newSaleId;
            delete newDoc._rev;
            delete newDoc._deleted;
            updateDocArr.push(newDoc); // recreate existing
        }
        if (!deleteExistArr.length) {
            console.log('nothing to delete');
        } else {
            let bulkDelete = {
                docs: deleteExistArr
            }
            // let resp = await DB.bulk(bulkDelete);
            // console.log('successfully deleted existing docs');
            // console.log(resp[0]);
        }

        if (!updateDocArr.length) {
            console.log('found NOTHING to update');
            console.log('script will end now.');
            return;
        }
        let bulkInsert = {
            docs: updateDocArr
        }
        let resp = await localDB.bulk(bulkInsert);
        console.log('successfully updated deleted docs');
        console.log(resp[0]);
        console.log('script ends');

    } catch (err) {
        console.error('failed to handle deleted doc');
        console.error(err);
    }
}

async function getCurrentDocs(DB, docType) {
    try {
        let resp = await couchDBUtils.getAllDocsByType(docType, DB);
        return resp;
    } catch (err) {
        console.error(err);
        throw 'failed to get current docs';
    }
}

console.log('script starts...');
let mainDbInstance = this.getMainCouchDB();
let cloudDbInstance = this.getOtherCouchDB();
let docType = 'sale';
handleDeletedDoc(cloudDbInstance, docType, mainDbInstance);
// getCurrentDocs(mainDbInstance, docType);