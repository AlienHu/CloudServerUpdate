var argv = require('yargs')
    .usage('Usage: $0 -e <envirnment> -app <AppName> -p <platform> ')
    .alias('e', 'env')
    .describe('e', 'environment(development/production)')
    .default('e', 'development')
    //.choices('e', ['development', 'production'])
    .alias('a', 'app')
    .describe('a', 'Apptype to run (combo/retail/restaurant)')
    .default('a', 'retail')
    .alias('u', 'enableSelfUpdate')
    .boolean('u')
    .default('u', true)
    .describe('u', 'enableSelfUpdate')
    .alias('m', 'myself')
    .describe('m', 'Source Name')
    .default('m', 'PGServerJs')
    .help('h')
    .alias('h', 'help')
    .argv;

var shelljs = require('shelljs');
var extend = require('extend');
var comboApps = ['retail', 'restaurant'];

var updaterDir;

//This is set in the installer startMeWithUpdate.js script
if (!process.env.UpdaterDir && argv.enableSelfUpdate) {
    updaterDir = process.env.UpdaterDir = __dirname + '/../profitGuruUpdater';
} else {
    updaterDir = process.env.UpdaterDir;
}

//use the args only if environment variables are not set
//startMeWithUpdater doesn't pass any args, the env variables are already set
if (process.env.ENVIRONMENT !== 'development' && process.env.ENVIRONMENT !== 'production') {
    //Adding The environment Variables
    extend(process.env, {
        MYSELF: argv.myself,
        APP_TYPE: argv.app,
        enableSelfUpdate: argv.enableSelfUpdate,
        //  UpdaterDir: __dirname + '/../profitGuruUpdater',
        ENVIRONMENT: argv.env,
        PROFITGURU_SERVER_PORT: 3000,
        COUCHDB_USERNAME: 'couchadmin',
        COUCHDB_PASSWORD: 'test',
        COUCH_PORT: 5984
    });
}

console.log('enableSelfUpdate', argv.enableSelfUpdate)
var path = require('path');
var PM2 = __dirname + '/node_modules/pm2/bin/pm2';
var startWithPm2;
var isWin = /^win/.test(process.platform);
// isWin = true; //not launching with pm2 ..
if (isWin) {
    startWithPm2 = path.resolve(updaterDir + '/index.js');
} else {
    if (argv.enableSelfUpdate) {
        startWithPm2 = path.resolve(PM2 + ' start -f ' + updaterDir + '/index.js');
    } else {
        startWithPm2 = PM2 + ' start -f ' + __dirname + '/bin/PGServerJs.js';
    }
}

if (argv.enableSelfUpdate) {
    //Lets marry PGTServerJs  and profitGuruUpdater
    console.log('Checking for config file ', updaterDir + '/updater/updateConfig.js')
    if (!shelljs.test('-f', __dirname + '/updater/updateConfig.js')) {
        console.log('ERROR:Can not find PGTServerJs updater config');
        process.exit(1);
    }
    //Creating the profitGuruUpdater structure for integration
    if (!shelljs.test('-d', updaterDir + '/config')) {
        if (shelljs.mkdir(updaterDir + '/config').code === 0) {
            console.log('Created ', updaterDir + '/config');
        } else {
            console.error('Could not Create', updaterDir + '/config')
        }
    }

    if (!shelljs.test('-f', path.resolve(updaterDir + '/config/updateConfig.js'))) {
        if (!shelljs.cp(path.resolve(__dirname + '/updater/updateConfig.js'), path.resolve(updaterDir + '/config/updateConfig.js'))) {
            console.error('Could not copy ', path.resolve(__dirname + '/updater/updateConfig.js'), ' to', path.resolve(updaterDir + '/config/updateConfig.js'));
        }
    }
}
//create locks dir if not exists
if (!shelljs.test('-d', __dirname + '/locks')) {
    if (shelljs.mkdir(__dirname + '/locks').code === 0) {
        console.log('Created ', __dirname + '/locks');
    } else {
        console.error('Could not Create', __dirname + '/locks');
    }
}

if (['combo', 'cloud'].indexOf(argv.app) < 0) {
    if (isWin) {
        require(startWithPm2);
    } else {
        shelljs.exec(PM2 + ' delete PGServerJs_' + argv.app);
        shelljs.exec(PM2 + ' update');
        shelljs.exec(startWithPm2 + ' --name PGServerJs_' + argv.app);
    }
} else {
    comboApps.forEach(function(appType) {
        switch (appType) {
            case 'retail':
                extend(process.env, {
                    MYSELF: argv.myself,
                    APP_TYPE: appType,
                    enableSelfUpdate: argv.enableSelfUpdate,
                    PROFITGURU_SERVER_PORT: 3000
                });
                if (argv.app === 'cloud') {
                    extend(process.env, {
                        IS_DEMO_APP: 'YES'
                    });
                }

                if (isWin) {
                    require(startWithPm2);
                } else {
                    shelljs.exec(PM2 + ' delete PGServerJs_' + appType);
                    shelljs.exec(PM2 + ' update');
                    shelljs.exec(startWithPm2 + ' --name PGServerJs_' + appType);
                }
                break;
            case 'restaurant':
                extend(process.env, {
                    MYSELF: argv.myself,
                    APP_TYPE: appType,
                    enableSelfUpdate: false,
                    PROFITGURU_SERVER_PORT: 3001
                });
                if (argv.app === 'cloud') {
                    extend(process.env, {
                        IS_DEMO_APP: 'YES'
                    });
                }

                if (isWin) {
                    require(startWithPm2);
                } else {
                    shelljs.exec(PM2 + ' delete PGServerJs_' + appType);
                    shelljs.exec(PM2 + ' update');
                    shelljs.exec(startWithPm2 + ' --name PGServerJs_' + appType);
                }
                break;
            default:
                console.log('Not Valid AppType');
        }
    });
}