// # expressUserCouchDb
//
// This module is an express plugin module, which means you can
// require the module in your express app, and add it to your express
// application by using `app.use(user(config));`
//
var express = require('express');
var nano = require('nano');
var uuid = require('uuid');
var emailTemplates = require('email-templates');
var nodemailer = require('nodemailer');
var _ = require('underscore');
var only = require('only');
var logger = require('../../common/Logger');
var couchDBUtils = require('../../controllers/common/CouchDBUtils');
var couchUserDb = couchDBUtils.getUserCouchDB();
var couchCoreDB = couchDBUtils.getCoreCouchDB();
const licencer = require('../../licencer/licenceHelper');

module.exports = function (config) {
    //var express = require('express');
    //var app = express.Router();
    var app = express();
    var safeUserFields = config.safeUserFields ? config.safeUserFields : "name email roles profile",
        db;

    function configureNano(cookie) {
        return nano({
            url: config.users,
            request_defaults: config.request_defaults,
            cookie: cookie
        });
    }

    db = configureNano();

    var transport;
    try {
        transport = nodemailer.createTransport(
            config.email.service,
            config.email[config.email.service]
        );
    } catch (err) {
        console.log('*** Email Service is not configured ***');
    }

    if (!config.validateUser) {
        config.validateUser = function (input, cb) {
            cb();
        };
    }

    function runEmployeeValidator(requestData, isUpdate) {
        var params = {
            keys: [requestData.email, requestData.phone_number]
        };

        return couchDBUtils.getView('employees', 'unique_data', params, couchUserDb).then(function (resp) {
            //return body.rows;
            //var resp = body.rows;
            var msg = ' should be unique';

            var bUnique = true;
            for (var i = 0; i < resp.length; i++) {
                if (isUpdate && resp[i].id === requestData._id) {
                    continue;
                }

                var key = resp[i].key;

                if (requestData.email && requestData.email === key) {
                    msg = 'Email ' + requestData.email + msg;
                    bUnique = false;
                }
                if (requestData.phone_number === key) {
                    msg = 'Phone Number ' + requestData.phone_number + ' ' + msg;
                    bUnique = false;
                }
            }

            if (!bUnique) {
                return Promise.reject(msg);
            }
        }).catch(function (err) {
            logger.error(err);
            //return [];
            return Promise.reject(err);
        });

    }

    // required properties on req.body
    // * name
    // * password
    // * email
    //
    // ### note: you can add more properties to
    // your user registration object
    app.post('/employees/signup', function (req, res) {
        if (!req.body || !req.body.name || !req.body.password || !req.body.email) {
            return res.status(400).send(JSON.stringify({
                ok: false,
                message: 'A name, password, and email address are required.'
            }));
        }

        //if (req.body.confirm_password) delete req.body.confirm_password;
        if (req.body.password_again) delete req.body.password_again;

        req.body.type = 'user';

        // Check to see whether a user with the same email address already exists.  Throw an error if it does.
        // Todo check with phone number also along with email
        db.view('employees', 'all', {
            key: req.body.email
        }, function (err, body) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }
            if (body.rows && body.rows.length > 0) {
                return res.status(400).send({
                    ok: false,
                    message: "A user with this email address already exists.  Try resetting your password instead."
                })
            };

            // We can now safely create the user.
            db.insert(req.body, 'org.couchdb.user:' + req.body.name, done);
        });

        function done(err, body) {
            if (err) {
                return res.status(err.status_code).send(err);
            }

            if (config.verify) {
                try {
                    if (req.body.email) {
                        validateUserByEmail(req.body.email);
                    }
                    db.get(body._id, function (err, user) {
                        if (err) {
                            return res.status(err.status_code).send(err);
                        }
                        res.status(200).send(JSON.stringify({
                            ok: true,
                            user: strip(user)
                        }));
                    });
                } catch (email_err) {
                    res.status(err.status_code).send(email_err);
                }
            } else {
                res.status(200).send(JSON.stringify(_.extend(req.body, {
                    _rev: body.rev,
                    ok: true
                })));
            }
        }
    });

    app.post('/employees/changeAdminPassword', async function (req, res) {
        if (!req.body || !req.body.name || !req.body.password || !req.body.password_again) {
            return res.status(400).send(JSON.stringify({
                ok: false,
                message: 'A name, password and confirm password are required.'
            }));
        }

        if (req.body.name !== 'admin') {
            if (req.body.name !== 'admin_' + process.env.APP_TYPE) {
                return res.status(400).send(JSON.stringify({
                    ok: false,
                    message: req.body.name + ' is not a admin user.'
                }));
            }
        }
        if (req.body.password_again !== req.body.password) {
            var error = new Error();
            error.message = 'Passwords does not matches.';
            return res.status(500).send(error);
        } else {
            //if (req.body.confirm_password) delete req.body.confirm_password;
            if (req.body.password_again) delete req.body.password_again;

            req.body.type = 'user';

            db.get('org.couchdb.user:' + req.body.name, function (err, adminUser) {
                if (err) {
                    return res.status(err.status_code ? err.status_code : 500).send(err);
                }
                if (!adminUser) {
                    return res.status(400).send({
                        ok: false,
                        message: "Admin User Doesn't Exist."
                    })
                };

                adminUser.password = req.body.password;
                adminUser.passwordHasToBeChanged = false;
                adminUser.email = req.body.email;
                adminUser.phone_number = req.body.phone;
                adminUser.isDistributor = req.body.isDistributor;
                adminUser.distributorEmail = req.body.distributorEmail;
                adminUser.securityQuestion1 = {
                    'quest': req.body.securityQuestion1.quest,
                    'ans': req.body.securityQuestion1.ans
                };
                adminUser.securityQuestion2 = {
                    'quest': req.body.securityQuestion2.quest,
                    'ans': req.body.securityQuestion2.ans
                };
                adminUser.isSecurityQuestAnswered = req.body.isSecurityQuestAnswered;
                // We can now safely create the user.
                db.insert(adminUser, 'org.couchdb.user:' + req.body.name, async function (err, data) {
                    if (err) {
                        return res.status(err.status_code ? err.status_code : 500).send(err);
                    }

                    adminUser._rev = data.rev;

                    // If a user updates their record, we need to update the session data
                    if (req.session && req.session.user && req.session.user.name === req.body.name) {
                        req.session.user = strip(adminUser);
                    }
                    let appSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', couchCoreDB);
                    appSettings.ownersInfo.state = req.body.state;
                    await couchDBUtils.update(appSettings, couchCoreDB, 3, "Failed to update the state name");
                    return res.status(200).send(JSON.stringify({
                        ok: true,
                        user: strip(adminUser)
                    }));
                });
            });
        }

    });
    //resetPassword
    app.post('/employees/resetPassword', function (req, res) {
        if (!req.body || !req.body.name || !req.body.password || !req.body.password_again) {
            return res.status(400).send(JSON.stringify({
                ok: false,
                message: 'A name, password and confirm password are required.'
            }));
        }

        if (req.body.name !== 'admin') {
            if (req.body.name !== 'admin_' + process.env.APP_TYPE) {
                return res.status(400).send(JSON.stringify({
                    ok: false,
                    message: req.body.name + ' is not a admin user.'
                }));
            }
        }
        if (req.body.password_again !== req.body.password) {
            var error = new Error();
            error.message = 'Passwords does not matches.';
            return res.status(500).send(error);
        } else {
            //if (req.body.confirm_password) delete req.body.confirm_password;
            if (req.body.password_again) delete req.body.password_again;

            req.body.type = 'user';

            db.get('org.couchdb.user:' + req.body.name, function (err, adminUser) {
                if (err) {
                    return res.status(err.status_code ? err.status_code : 500).send(err);
                }
                if (!adminUser) {
                    return res.status(400).send({
                        ok: false,
                        message: "Admin User Doesn't Exist."
                    })
                };

                adminUser.password = req.body.password;
                adminUser.passwordHasToBeChanged = false;
                // We can now safely create the user.
                db.insert(adminUser, 'org.couchdb.user:' + req.body.name, function (err, data) {
                    if (err) {
                        return res.status(err.status_code ? err.status_code : 500).send(err);
                    }

                    adminUser._rev = data.rev;

                    // If a user updates their record, we need to update the session data
                    if (req.session && req.session.user && req.session.user.name === req.body.name) {
                        req.session.user = strip(adminUser);
                    }

                    return res.status(200).send(JSON.stringify({
                        ok: true,
                        user: strip(adminUser)
                    }));
                });
            });
        }

    });
    // login user
    // required properties on req.body
    // * name
    // * password
    app.post('/employees/signin', function (req, res) {

        if (!req.body || !req.body.name || !req.body.password) {
            return res.status(400).send(JSON.stringify({
                ok: false,
                message: 'A name, and password are required.'
            }));
        }

        db.auth(req.body.name, req.body.password, populateSessionWithUser(function (err, user) {
            if (err) {
                return res.status(err.statusCode ? err.statusCode : 500).send({
                    ok: false,
                    message: err.message,
                    error: err.error
                });
            }
            let couchAuthInfo = {
                username: process.env.COUCHDB_USERNAME,
                password: process.env.COUCHDB_PASSWORD
            };
            res.end(JSON.stringify({
                ok: true,
                user: strip(user),
                couchAuth: couchAuthInfo,
                serverSerialNumber: licencer.getServerSerialNumber()
            }));
            // res.end(JSON.stringify({ok:true, user: strip(user),serverSettings: req.app.locals.applicationSettings}));
        }, req.body.clientId));

        function populateSessionWithUser(cb, clientId) {
            return function (err, body, headers) {
                if (err) {
                    return cb(err);
                }

                getUserName(body.name, headers['set-cookie'], function (err, name) {
                    if (err) {
                        return cb(err);
                    }

                    lookupUser(name, function (err, user) {
                        user.clientId = clientId;
                        if (err) {
                            return cb(err);
                        }

                        if (user.APP_TYPE !== process.env.APP_TYPE) {
                            return cb({
                                statusCode: 401,
                                ok: false,
                                message: 'Invalid User Login'
                            });
                        }

                        if (config.verify && !user.verified) {
                            return cb({
                                statusCode: 401,
                                ok: false,
                                message: 'You must verify your account before you can log in.  Please check your email (including spam folder) for more details.'
                            });
                        }

                        if (user.enabled === false) {
                            return cb({
                                statusCode: 403,
                                ok: false,
                                message: 'Your account is no longer enabled.  Please contact an Administrator to enable your account.'
                            });
                        }

                        if (user.deleted) {
                            return cb({
                                statusCode: 403,
                                ok: false,
                                message: 'Your account is deleted.'
                            });
                        }

                        config.validateUser({
                            req: req,
                            user: user,
                            headers: headers
                        }, function (err, data) {
                            if (err) {
                                err.statusCode = err.statusCode || 401;
                                err.message = err.message || 'Invalid User Login';
                                err.error = err.error || 'unauthorized';
                                return cb(err);
                            }

                            createSession(user, data, function () {
                                cb(null, user);
                            });

                        });

                    });
                });

            }
        }

        function getUserName(name, authCookie, cb) {
            if (name) {
                cb(null, name);
            } else {
                /**
                 * Work around for issue:  https://issues.apache.org/jira/browse/COUCHDB-1356
                 * Must fetch the session after authentication in order to find username of server admin that logged in
                 */
                configureNano(authCookie).session(function (err, session) {
                    cb(err, session.userCtx.name);
                });
            }
        }

        function lookupUser(name, cb) {
            db.get('org.couchdb.user:' + name, cb);
        }

        async function createSession(user, data, cb, maxTrials) {
            if (maxTrials === undefined) {
                maxTrials = 5;
            }

            //getSessionDB
            var couchDbMain = require('../../couchDb/couchDBMain.js');
            let sessionDB = couchDbMain.getSessionDB();

            //getView
            var CouchDBUtils = require('../../controllers/common/CouchDBUtils.js');
            let paramObject = {
                key: user.name + '::' + user.clientId,
                include_docs: true
            }
            let sessions = await CouchDBUtils.getView('all_user_sessions', 'all_user_sessions', paramObject, sessionDB);
            let deleteArray = [];
            //todo : need to improve
            for (var s = 0; s < sessions.length; s++) {
                // sessions[s].doc._deleted = true;
                // deleteArray.push(sessions[s].doc);
                let deleteResp = await CouchDBUtils.delete(sessions[s].doc, sessionDB);
            }
            await sessionDB.compact();
            // let deleteResp = CouchDBUtils.bulkInsert(sessionDB, deleteArray).catch(function(err) {
            //     logger.err('session delete failed with error ' + err);
            // });

            req.session.regenerate(function (err) {

                if (sessions.length) {
                    let idx = sessions.length - 1;
                    let excludeFields = ['_id', '_rev', 'collectionName', 'cookie', 'expires'];
                    // let includeFields = ['cart', 'user', 'clientType'];
                    let keys = Object.keys(sessions[idx].doc);
                    for (let i = 0; i < keys.length; i++) {
                        if (excludeFields.indexOf(keys[i]) === -1) {
                            req.session[keys[i]] = sessions[idx].doc[keys[i]] ? sessions[idx].doc[keys[i]] : req.session[keys[i]];
                        }
                    }

                } else {
                    req.session.clientType = req.body.clientType;
                }
                req.session.user = user;

                if (data) {
                    _.each(data, function (val, key) {
                        req.session[key] = val;
                    });
                }

                maxTrials = maxTrials - 1;

                if (req.sessionID.indexOf('_') === 0) {
                    if (!err) {
                        err = 'documents with "_" are reserved for couchdb';
                    }
                }

                if (!err || maxTrials === 0) {
                    if (err) {
                        console.log('out of trials. CreateSession Failed');
                    }
                    cb();
                } else {
                    console.log('create session failed. Trying again');
                    createSession(user, data, cb, maxTrials);
                }
            });
        }

    });

    // logout user
    // required properties on req.body
    // * name
    app.post('/employees/signout', function (req, res) {
        req.session.destroy(function (err) {
            if (err) {
                console.log('Error destroying session during logout' + err);
            }
            res.status(200).send(JSON.stringify({
                ok: true,
                message: "You have successfully logged out."
            }));
        });
    });

    // forgot user password
    // required properties on req.body
    // * email
    app.post('/employees/forgot', function (req, res) {
        if (!req.body || !req.body.email) {
            return res.status(400).send(JSON.stringify({
                ok: false,
                message: 'An email address is required.'
            }));
        }

        var user;
        // use email address to find user
        db.view('employees', 'all', {
            key: req.body.email
        }, saveUser);

        // generate uuid code
        // and save user record
        function saveUser(err, body) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }

            if (body.rows && body.rows.length === 0) {
                return res.status(500).send(JSON.stringify({
                    ok: false,
                    message: 'No user found with that email.'
                }));
            }

            user = body.rows[0].value;

            if (user.enabled === false) {
                return res.status(403).send(JSON.stringify({
                    ok: false,
                    message: 'Your account is no longer enabled.  Please contact an Administrator to enable your account.'
                }));
            }

            // generate uuid save to document
            user.code = uuid.v1();
            db.insert(user, user._id, createEmail);
        }

        // initialize the emailTemplate engine
        function createEmail(err, body) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }
            emailTemplates(config.email.templateDir, renderForgotTemplate);
        }

        // render forgot.ejs
        function renderForgotTemplate(err, template) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }
            // use header host for reset url
            config.app.url = 'http://' + req.headers.host;
            template('forgot', {
                user: user,
                app: config.app
            }, sendEmail);
        }

        // send rendered template to user
        function sendEmail(err, html, text) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }
            if (!transport) {
                return res.status(500).send({
                    message: 'transport is not configured!'
                });
            }
            transport.sendMail({
                from: config.email.from,
                to: user.email,
                subject: config.app.name + ': Reset Password Request',
                html: html,
                text: text
            }, done);
        }

        // complete action
        function done(err, status) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }
            res.status(200).send(JSON.stringify({
                ok: true,
                message: "forgot password link sent..."
            }));
            //app.emit('user: forgot password', user);
        }
    });

    app.get('/employees/code/:code', function (req, res) {
        if (!req.params.code) {
            return res.status(500).send(JSON.stringify({
                ok: false,
                message: 'You must provide a code parameter.'
            }));
        }

        db.view('employees', 'code', {
            key: req.params.code
        }, function (err, body) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }
            if (body.rows.length > 1) {
                return res.status(500).send(JSON.stringify({
                    ok: false,
                    message: 'More than one user found.'
                }));
            } else if (body.rows.length === 0) {
                return res.status(500).send(JSON.stringify({
                    ok: false,
                    message: 'Reset code is not valid.'
                }));
            } else {
                var user = body.rows[0].value;
                var name = user.name;
                if (user.fname && user.lname) {
                    name = user.fname + ' ' + user.lname;
                }
                return res.status(200).send(JSON.stringify({
                    ok: true,
                    user: strip(user)
                }));
            }
        });
    });

    // reset user password
    // required properties on req.body
    // * code (generated by /api/employees/forgot)
    // * password
    app.post('/employees/reset', function (req, res) {
        if (!req.body || !req.body.code || !req.body.password) {
            return res.status(400).send(JSON.stringify({
                ok: false,
                message: 'A password and valid password reset code are required.'
            }));
        }

        // get user by code
        db.view('employees', 'code', {
            key: req.body.code
        }, checkCode);

        function checkCode(err, body) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }
            if (body.rows && body.rows.length === 0) {
                return res.status(500).send(JSON.stringify({
                    ok: false,
                    message: 'Not Found'
                }));
            }
            var user = body.rows[0].value;
            user.password = req.body.password;
            // clear code
            delete user.code;
            db.insert(user, user._id, function (err, user) {
                if (err) {
                    return res.status(err.status_code ? err.status_code : 500).send(err);
                }
                return res.status(200).send(JSON.stringify({
                    ok: true,
                    user: strip(user)
                }));
            });
        }
    });

    // Send (or resend) verification code to a user's email address
    // required properties on req.body
    // * email
    app.post('/employees/verify', function (req, res) {
        if (!req.body || !req.body.email) {
            return res.status(400).send(JSON.stringify({
                ok: false,
                message: 'An email address must be passed as part of the query string before a verification code can be sent.'
            }));
        }

        try {
            validateUserByEmail(req.body.email);
            res.status(200).send(JSON.stringify({
                ok: true,
                message: "Verification code sent..."
            }));
        } catch (validate_err) {
            res.status(validate_err.status_code).send(validate_err);
        }
    });

    // Accept a verification code and flag the user as verified.
    // required properties on req.params
    // * code
    app.get('/employees/verify/:code', function (req, res) {
        if (!req.params.code) {
            return res.status(400).send(JSON.stringify({
                ok: false,
                message: 'A verification code is required.'
            }));
        }

        var user;
        // use verification code
        db.view('employees', 'verification_code', {
            key: req.params.code
        }, saveUser);

        function saveUser(err, body) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }

            if (body.rows && body.rows.length === 0) {
                return res.status(400).send(JSON.stringify({
                    ok: false,
                    message: 'Invalid verification code.'
                }));
            }

            // TODO:  Add an expiration date for the verification code and check it.

            user = body.rows[0].value;
            if (!user.verification_code || user.verification_code !== req.params.code) {
                return res.status(400).send(JSON.stringify({
                    ok: false,
                    message: 'The verification code you attempted to use does not match our records.'
                }));
            }

            delete user.verification_code;
            user.verified = new Date();
            db.insert(user, user._id, function (err, body) {
                if (err) {
                    return res.status(err.status_code ? err.status_code : 500).send(err);
                }
                return res.status(200).send(JSON.stringify({
                    ok: true,
                    message: "Account verified."
                }));
            });
        }
    });

    // Return the name of the currently logged in user.
    app.get('/employees/current', function (req, res) {
        if (!req.session || !req.session.user) {
            return res.status(401).send(JSON.stringify({
                ok: false,
                message: "Not currently logged in."
            }));
        }

        res.status(200).send(JSON.stringify({
            ok: true,
            user: strip(req.session.user)
        }));
    });

    // Look up another user's information
    app.get('/employees/:name', function (req, res) {
        if (!req.session || !req.session.user) {
            return res.status(401).send(JSON.stringify({
                ok: false,
                message: "You must be logged in to use this function."
            }));
        }

        db.get('org.couchdb.user:' + req.params.name, function (err, user) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }
            return res.status(200).send(JSON.stringify({
                ok: true,
                user: strip(user)
            }));
        });
    });

    // Create a new user or update an existing user
    app.put('/employees/:name', function (req, res) {
        if (!req.session || !req.session.user) {
            return res.status(401).send(JSON.stringify({
                ok: false,
                message: "You must be logged in to use this function"
            }));
        } else if (config.adminRoles && !hasAdminPermission(req.session.user) && req.session.user.name !== req.params.name) {
            return res.status(403).send(JSON.stringify({
                ok: false,
                message: "You do not have permission to use this function."
            }));
        }

        db.get('org.couchdb.user:' + req.params.name, function (err, user) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }
            var updates = strip(req.body);

            var keys = Object.keys(updates);
            for (var i in keys) {
                var key = keys[i];
                if ((user.name === 'admin' || user.name === 'admin_' + process.env.APP_TYPE) && updates.profile !== 'adminProfile') {
                    console.log('Admin role cannot be changed');
                    return res.status(403).send(JSON.stringify({
                        ok: false,
                        message: "Admin role cannot be changed"
                    }));
                } else if (key === "roles" && !hasAdminPermission(req.session.user)) {
                    console.log("Stripped updated role information, non-admin users are not allowed to change roles.");
                } else {
                    user[key] = updates[key];

                    if (key === "roles") {
                        //user[key][1] = req.body.profile;
                        user.roles = processEmployeeProfilesNEntitlements.processEntitlements(req.body);
                    }
                }
            }

            db.insert(user, 'org.couchdb.user:' + req.params.name, function (err, data) {
                if (err) {
                    return res.status(err.status_code ? err.status_code : 500).send(err);
                }

                user._rev = data.rev;

                // If a user updates their record, we need to update the session data
                if (req.session.user.name === req.params.name) {
                    req.session.user = strip(user);
                }

                return res.status(200).send(JSON.stringify({
                    ok: true,
                    user: strip(user)
                }));
            });
        });
    });

    // Delete a user
    app.delete('/employees/:name', function (req, res) {
        if (!req.session || !req.session.user) {
            return res.status(401).send(JSON.stringify({
                ok: false,
                message: "You must be logged in to use this function"
            }));
        } else if (config.adminRoles && !hasAdminPermission(req.session.user)) {
            return res.status(403).send(JSON.stringify({
                ok: false,
                message: "You do not have permission to use this function."
            }));
        }

        //Todo: Actual use case for this condition is atleast 1 admin user (with all permissions or atleast login and grant employee access should be present). Otherwise we would be blocking the user

        if (process.env.IS_DEMO_APP === 'YES') {
            if (req.params.name === 'trial') {
                return res.status(500).send(JSON.stringify({
                    ok: false,
                    message: "trial user cannot be deleted"
                }));
            }
        }

        db.get('org.couchdb.user:' + req.params.name, function (err, user) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }

            if (user.isDefaultAdmin === true) {
                return res.status(500).send(JSON.stringify({
                    ok: false,
                    message: "admin user cannot be deleted"
                }));
            }

            user.deleted = "1";

            db.insert(user, 'org.couchdb.user:' + req.params.name, function (err, data) {
                if (err) {
                    return res.status(err.status_code ? err.status_code : 500).send(err);
                }

                function respondUserDeleted() {
                    res.status(200).send(JSON.stringify({
                        ok: true,
                        message: "User " + req.params.name + " deleted."
                    }));
                }
                // Admins can delete their own accounts, but this will log them out.
                if (req.session.user.name === req.params.name) {
                    req.session.destroy(function (err) {
                        if (err) {
                            console.log('Error destroying session for ' + req.params.name + ' ' + err);
                        }
                        respondUserDeleted();
                    });
                } else {
                    respondUserDeleted();
                }
            });

        });
    });

    // Create a user
    var processEmployeeProfilesNEntitlements = require('../employeeProfiles');

    app.post('/employees', function (req, res) {
        if (!req.session || !req.session.user) {
            return res.status(401).send(JSON.stringify({
                ok: false,
                message: "You must be logged in to use this function"
            }));
        } else if (config.adminRoles && !hasAdminPermission(req.session.user)) {
            return res.status(403).send(JSON.stringify({
                ok: false,
                message: "You do not have permission to use this function."
            }));
        }
        req.body.type = 'user';
        req.body.APP_TYPE = process.env.APP_TYPE;
        // if (req.body.password_again!== req.body.password)

        req.body.roles = processEmployeeProfilesNEntitlements.processEntitlements(req.body);
        if (req.body.password_again === req.body.password) {
            if (req.body.password_again) delete req.body.password_again;
            return runEmployeeValidator(req.body, false).then(function () {
                db.get('org.couchdb.user:' + req.body.name, function (err, user) {
                    if (user) {
                        if (user.deleted) {
                            req.body._rev = user._rev;
                        }
                    }
                    _insertUser();
                });

                function _insertUser() {

                    db.insert(req.body, 'org.couchdb.user:' + req.body.name, function (err, data) {
                        if (err) {
                            if (err.message === 'Document update conflict.') {
                                err.message = 'User name already Exists, Enter Unique User name';
                            }
                            return res.status(err.status_code ? err.status_code : 500).send(err);
                        }
                        res.status(200).send(JSON.stringify({
                            ok: true,
                            data: data
                        }));
                    });
                }

            }).catch(function (err) {
                console.log(err);
                //return Promise.reject(err);
                var error = {};
                error.error = {};
                error.error.message = err;
                return res.status(err.status_code ? err.status_code : 500).send(error);
            });
        } else {
            return res.status(500).send(JSON.stringify({
                ok: false,
                message: "Password does not matches."
            }));
        }
    });

    // Return a list of users matching one or more roles
    app.get('/employees', function (req, res) {
        if (!req.session || !req.session.user) {
            return res.status(401).send(JSON.stringify({
                ok: false,
                message: "You must be logged in to use this function"
            }));
        }
        if (!req.query.roles) {
            return res.status(400).send(JSON.stringify({
                ok: false,
                message: 'Roles are required!'
            }));
        }
        var keys = req.query.roles.split(',');
        db.view('employees', 'role', {
            keys: keys
        }, function (err, body) {
            if (err) {
                return res.status(err.status_code ? err.status_code : 500).send(err);
            }
            var users = _(body.rows).pluck('value');
            res.status(200).send(JSON.stringify({
                ok: true,
                users: stripArray(users)
            }));
        });
    });

    function strip(value) {
        return only(value, safeUserFields);
    }

    function stripArray(array) {
        var returnArray = [];
        array.forEach(function (value) {
            returnArray.push(only(value, safeUserFields));
        });
        return returnArray;
    }

    function hasAdminPermission(user) {
        // If admin roles are disabled, then everyone has admin permissions
        if (!config.adminRoles) {
            return true;
        }

        if (user.roles) {
            for (var i in user.roles) {
                var role = user.roles[i];
                if (config.adminRoles instanceof String) {
                    if (config.adminRoles === role) {
                        return true;
                    }
                } else if (config.adminRoles instanceof Array) {
                    if (config.adminRoles.indexOf(role) >= 0) {
                        return true;
                    }
                } else {
                    console.log("config.adminRoles must be a String or Array.  Admin checks are disabled until this is fixed.");
                    return true;
                }
            }
        }

        return false;
    }

    function validateUserByEmail(email) {
        var user;
        // use email address to find user
        db.view('employees', 'all', {
            key: email
        }, saveUserVerificationDetails);

        function saveUserVerificationDetails(err, body) {
            if (err) {
                throw (err);
            }

            if (body.rows && body.rows.length === 0) {
                var error = new Error('No user found with the specified email address.');
                error.status_code = 404;
                throw (error);
            }

            user = body.rows[0].value;
            // TODO:  Add an expiration date for the verification code and check it.
            user.verification_code = uuid.v1();
            db.insert(user, user._id, verificationEmail);
        }

        // initialize the emailTemplate engine
        function verificationEmail(err, body) {
            if (err) {
                throw (err);
            }
            emailTemplates(config.email.templateDir, renderVerificationTemplate);
        }

        // render verify template
        function renderVerificationTemplate(err, template) {
            if (err) {
                throw (err);
            }
            template('verify', {
                user: user,
                app: config.app
            }, sendVerificationEmail);
        }

        // send rendered template to user
        function sendVerificationEmail(err, html, text) {
            if (err) {
                throw (err);
            }
            if (!transport) {
                var error = new Error('Mail transport is not configured!');
                error.status_code = 500;
                throw (error);
            }
            transport.sendMail({
                from: config.email.from,
                to: user.email,
                subject: config.app.name + ': Please Verify Your Account',
                html: html,
                text: text
            }, done);
        }

        // complete action
        function done(err, status) {
            if (err) {
                throw (err);
            }
            //app.emit('user: verify account', user);
        }
    }

    return app;
};