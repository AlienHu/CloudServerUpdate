//Refernces for couchdb users/security implementation
//https://jamesadam.me/index.php/2014/11/09/couchdb-authorization/

// exports.getUserDBUrl = function(config, name, cb) {

//    var nano = require('nano')("http://" + config.couch_admin + ":" + config.couch_password + "@" + config.couch_host + ':' + config.couch_port);
//    var users = nano.use('_users');

//    users.get("org.couchdb.user:" + name, function(err, body) {
//       if (err) {
//          console.log(err);
//          cb("failed", null);
//       } else {
//          cb(null, body.dburl);
//       }
//    });
// };

//var env = process.env.NODE_ENV || 'development';
//var gconfig = require('./' + env + '.js');
module.exports = function(config) {
    var couchUrl = "http://" + config.localCouch.UserName + ":" + config.localCouch.Password + "@" + config.localCouch.Host + ':' + config.localCouch.Port;
    var nano = require('nano')(couchUrl);

    var nanoPromises = require('nano-promises')(nano);
    var users = nanoPromises.use('_users');
    var profitGuruCouch = {};

    profitGuruCouch.findUser = function(userName) {
        if (userName.indexOf('org.couchdb.user') >= 0) {
            return users.get(userName);
        } else {
            return users.get("org.couchdb.user:" + userName);
        }
    };

    profitGuruCouch.login = function(username, password) {
        return nanoPromises.auth(username, password);
    };
    profitGuruCouch.getUserDBUrl = function(userName) {

        return users.get("org.couchdb.user:" + userName);
    };

    profitGuruCouch.updateDbSecurity = function(creds) {

        var userDB = nanoPromises.use(creds.username);
        var secObj = {
            admins: {
                names: [],
                roles: []
            },
            members: {
                names: [creds.username],
                roles: []
            }
        };

        return userDB.insert(secObj, "_security");
    };

    profitGuruCouch.createUser = function(creds) {

        if (creds.password !== creds.password_again) {
            throw new Error('Re-entered password does not match');
        } else {
            delete creds.password_again;
        }
        creds._id = "org.couchdb.user:" + creds.username;
        creds.name = creds.username;
        creds.type = "user";
        creds.roles = creds.grants;

        delete creds.grants;

        // var user = {
        //     _id: "org.couchdb.user:" + creds.username,
        //     name: creds.username,
        //     roles: creds.grants,
        //     type: "user",
        //     password: creds.password,
        //     // dburl: "http://" + config.couch_host + ':' + config.couch_port + "/" + creds.username,
        //     email: creds.email
        // };

        return users.insert(creds);
    };

    profitGuruCouch.deleteUser = function(user) {
        var couchUser = "org.couchdb.user:" + user.username;
        return new Promise(function(resolve, reject) {
            return profitGuruCouch.findUser(couchUser).then(function(response) {
                return users.head(couchUser).then(function(response) {
                    console.log(response);
                    var etag = JSON.parse(response[1].etag);
                    return users.destroy(couchUser, etag).then(function(resp) {
                        resolve(true);
                    }).catch(function(reason) {
                        throw new Error(reason);
                    });
                });

            }).catch(function(reason) {
                throw new Error('User doesnot Exists:', reason);
            });
        });

    };
    profitGuruCouch.updateUser = function(user) {
        //TODO findout if thr is a better way for update
        var couchUser = "org.couchdb.user:" + user.username;

        return new Promise(function(resolve, reject) {
            return profitGuruCouch.findUser(couchUser).then(function(dbUser) {

                return users.head(couchUser).then(function(response) {
                    console.log(response);
                    var etag = JSON.parse(response[1].etag);
                    return users.destroy(couchUser, etag).then(function(resp) {
                        resolve(true);
                    }).catch(function(reason) {
                        throw new Error(reason);
                    });
                });

            }).catch(function(reason) {
                throw new Error('User doesnot Exists:', reason);
            });
        });

    };

    profitGuruCouch.createUserDb = function(creds) {
        return nanoPromises.db.create(creds.username);
    };

    profitGuruCouch.createUserAndItsOwnDB = function(creds) {

        return profitGuruCouch.createUser(creds)
            .then(profitGuruCouch.createUserDb(creds))
            .then(profitGuruCouch.updateDbSecurity(creds));

    };

    return profitGuruCouch;
};