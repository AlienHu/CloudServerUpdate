var allApis = {
    "core": {
        "getProfitGuruRestApis": "http://localhost:4080/profitGuruRestSvc/index.php/core/getProfitGuruRestApis",
        "getProfitGuruElements": "http://localhost:4080/profitGuruRestSvc/index.php/core/getProfitGuruElements"
    },
    "login": {
        "isLogedInRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/login/isLogedInRestApi",
        "loginRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/login/loginRestApi",
        "logOutRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/login/logOutRestApi",
        "amIAuthorized2Connect": "http://localhost:4080/profitGuruRestSvc/index.php/login/amIAuthorized2Connect",
        "apply4Licence": "http://localhost:4080/profitGuruRestSvc/index.php/login/apply4Licence"
    },
    "customers": {
        "getCustomersRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/customers/getCustomersRestApi",
        "saveCustomerRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/customers/saveCustomerRestApi",
        "deleteCustomerRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/customers/deleteCustomerRestApi",
        "importCustomerRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/customers/importCustomerRestApi"
    },
    "sales": {
        "addCustomer2SaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/addCustomer2SaleRestApi",
        "manageRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/manageRestApi",
        "changeModeRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/changeModeRestApi",
        "allSuspendedSalesRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/allSuspendedSalesRestApi",
        "unsuspendSaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/unsuspendSaleRestApi",
        "editItemRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/editItemRestApi",
        "getEditRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/getEditRestApi",
        "saveEditSalesRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/saveEditSalesRestApi",
        "getSalesRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/getSalesRestApi",
        "additemRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/additemRestApi",
        "removeitemRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/removeitemRestApi",
        "cancel_saleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/cancel_saleRestApi",
        "add_paymentRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/add_paymentRestApi",
        "completeSaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/completeSaleRestApi",
        "suspendSaleRestApi": {
            status: DONE,
            url: "http://localhost:4080/profitGuruRestSvc/index.php/sales/suspendSaleRestApi"
        },
        "receiptRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/receiptRestApi",
        "printReceiptApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/printReceiptApi",
        "setPrintAfterSaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/setPrintAfterSaleRestApi",
        "setInvoiceNumberEnabledRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/setInvoiceNumberEnabledRestApi",
        "setInvoiceNumberRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/setInvoiceNumberRestApi",
        "getAllItemsIdRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/tables/getKOTItemRestApi",
        "invoiceRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/invoiceRestApi",
        "deleteSaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/deleteSaleRestApi",
        "getItemDiscountRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/getItemDiscountRestApi",
        "DeleteItemFromCartRestApi": {
            status: DONE,
            url: "http://localhost:4080/profitGuruRestSvc/index.php/sales/DeleteItemFromCartRestApi"
        },
        "saveTableOrderRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/sales/saveTableOrderRestApi",
            priority: high,
            couchsync: true
        },
        "loadAllOrderItemBeforeCheckOutRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/sales/loadAllOrderItemBeforeCheckOutRestApi",
            priority: high
        },
        "unsuspendSaleRestaurantRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/unsuspendSaleRestaurantRestApi",
        "unsuspendDeliveryRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/unsuspendDeliveryRestApi",
        "splitBillRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/sales/splitBillRestApi",
            priority: high
        },
        "get_max_order_numberRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/get_max_order_numberRestApi",
        "saveDeliveryRetailRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/saveDeliveryRetailRestApi",
        "completeDeliverySaleApiRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/completeDeliverySaleApiRestApi",
        "completeTakeOrderRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/sales/completeTakeOrderRestApi",
            priority: high,
            couchsync: true
        },
        getItemsRestApi: {
            "url": "http://localhost:4080/profitGuruRestSvc/index.php/sales/getItemsRestApi",
            observations: {
                1: 'This is not required'
            }
        },
        "getCartTaxes": "http://localhost:4080/profitGuruRestSvc/index.php/sales/getCartTaxes",
        "loadKotToCartRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/sales/loadKotToCartRestApi",
            priority: high
        },
        "editSaveKOTRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/editSaveKOTRestApi",
        "addCustomer2OrdersRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/sales/addCustomer2OrdersRestApi",
            priority: high
        },
        "deleteWholeSaleRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/deleteWholeSaleRestApi",
        "delete_paymentRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/delete_paymentRestApi",
        "saveTwoTerminalOdersRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/saveTwoTerminalOdersRestApi",
        "unsuspendOrders4TwoTerminalRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/unsuspendOrders4TwoTerminalRestApi",
        "completeSale4TwoTerminalRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/sales/completeSale4TwoTerminalRestApi"
    },
    "receivings": {
        "getReceivingsRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/receivings/getReceivingsRestApi",
            status: code_complete
        },
        "changeModeRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/receivings/changeModeRestApi",
            status: code_complete
        },
        "addSupplier2RecRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/receivings/addSupplier2RecRestApi",
            status: code_complete
        },
        "additem2ReceivingsRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/receivings/additem2ReceivingsRestApi",
            status: code_complete
        },
        "removeItemfromReceivingsRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/receivings/removeItemfromReceivingsRestApi",
            status: code_complete
        },
        "completeReceiveRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/receivings/completeReceiveRestApi",
            status: code_complete
        },
        "cancelReceivingsRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/receivings/cancelReceivingsRestApi",
            status: code_complete
        },
        "saveRecvEditRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/receivings/saveRecvEditRestApi",
        "getEditRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/receivings/getEditRestApi",
        "editRecvItemRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/receivings/editRecvItemRestApi",
            status: code_complete
        },
        "DeleteItemFromCartRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/receivings/DeleteItemFromCartRestApi",
            status: code_complete
        },
        "deleteRecvRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/receivings/deleteRecvRestApi",
        "set_invoice_number_enabledRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/receivings/set_invoice_number_enabledRestApi",
            status: code_complete
        },
        "setInvoiceNumber4RecevingsRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/receivings/setInvoiceNumber4RecevingsRestApi",
    },
    "items": {
        "getItemsRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/items/getItemsRestApi",
        "saveItemRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/items/saveItemRestApi",
        "doExcelImportRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/items/doExcelImportRestApi",
        "getItemsExportDataRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/items/getItemsExportDataRestApi",
        "excel": "http://localhost:4080/profitGuruRestSvc/index.php/items/excel",
        "deleteItemsRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/items/deleteItemsRestApi",
        "saveInventoryRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/items/saveInventoryRestApi",
        "getItemsEditRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/items/getItemsEditRestApi",
        "getInvetaryDetailRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/items/getInvetaryDetailRestApi"
    },
    "config": {
        "ConfigSettings4GiftCardRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/config/ConfigSettings4GiftCardRestApi",
            priority: high
        },
        "getConfigsRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/config/getConfigsRestApi",
            priority: high
        },
        "saveConfigRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/config/saveConfigRestAPI",
        "saveLocaleConfigRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/config/saveLocaleConfigRestAPI",
        "saveBarcodeRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/config/saveBarcodeRestApi",
        "saveLocationsRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/config/saveLocationsRestAPI",
        "savePrinterSettingsRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/config/savePrinterSettingsRestApi",
        "BackupDBRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/config/BackupDBRestApi"
    },
    "reports": {
        "graphicalSummaryCategoriesGraphRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/graphicalSummaryCategoriesGraphRestAPI",
        "graphicalSummaryCustomerGraphRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/graphicalSummaryCustomerGraphRestAPI",
        "graphicalSummaryDiscountGraphRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/graphicalSummaryDiscountGraphRestAPI",
        "graphicalSummaryEmployeeGraphRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/graphicalSummaryEmployeeGraphRestAPI",
        "graphicalSummaryItemGraphRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/graphicalSummaryItemGraphRestAPI",
        "graphicalSummaryPaymentGraphRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/graphicalSummaryPaymentGraphRestAPI",
        "graphicalSummarySaleGraphRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/graphicalSummarySaleGraphRestAPI",
        "graphicalSummarySupGraphRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/graphicalSummarySupGraphRestAPI",
        "graphicalSummaryTaxGraphRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/graphicalSummaryTaxGraphRestAPI",
        "SummaryCategoryRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/SummaryCategoryRestAPI",
        "SummaryCustomerRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/SummaryCustomerRestAPI",
        "SummaryDiscountRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/SummaryDiscountRestAPI",
        "SummaryEmployeeRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/SummaryEmployeeRestAPI",
        "SummaryItemRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/SummaryItemRestAPI",
        "SummaryPaymentRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/SummaryPaymentRestAPI",
        "SummarySaleRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/SummarySaleRestAPI",
        "SummarySupplierRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/SummarySupplierRestAPI",
        "SummaryTaxesRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/SummaryTaxesRestAPI",
        "DetailedSaleRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/DetailedSaleRestAPI",
        "DetailedRecRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/DetailedRecRestAPI",
        "DetailedDisRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/DetailedDisRestAPI",
        "DetailedEmpRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/DetailedEmpRestAPI",
        "LowInventoryRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/LowInventoryRestAPI",
        "DetailedCustRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/DetailedCustRestAPI",
        "InventorySumRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/reports/InventorySumRestAPI",
        "getDateRangesRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/reports/getDateRangesRestApi"
    },

    "suppliers": {
        "getSuppliersRestAPI": "http://localhost:4080/profitGuruRestSvc/index.php/suppliers/getSuppliersRestAPI",
        "doExcelImportRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/suppliers/doExcelImportRestApi",
        "saveSupplierRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/suppliers/saveSupplierRestApi",
        "deleteSuppliersRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/suppliers/deleteSuppliersRestApi"
    },
    "employees": {
        "getEmployeeRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/employees/getEmployeeRestApi",
        "employeeSaveRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/employees/employeeSaveRestApi",
        "deleteEmployeeRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/employees/deleteEmployeeRestApi",
        "getEmployeeGrantDetailsRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/employees/getEmployeeGrantDetailsRestApi",
        "getEmployeeModDetailsRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/employees/getEmployeeModDetailsRestApi"

    },
    "EmployeesRestApiCntrlr": {
        "getGrants4Restaurent": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/EmployeesRestApiCntrlr/getGrants4Restaurent",
            priority: high
        },
        "getEmployeeIdRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/EmployeesRestApiCntrlr/getEmployeeIdRestApi",
            priority: high
        },
        "getEmployeeGrantDetails4loyalityRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/EmployeesRestApiCntrlr/getEmployeeGrantDetails4loyalityRestApi",
            priority: high
        }
    },
    "item_kits": {
        "getitemKitsRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/item_kits/getitemKitsRestApi",
        "itemKitsSaveRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/item_kits/itemKitsSaveRestApi",
        "deleteitemKitsRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/item_kits/deleteitemKitsRestApi",
        "itemKitslistRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/item_kits/itemKitslistRestApi",
        "ItemkitDetailsRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/item_kits/ItemkitDetailsRestApi"
    },
    "notes": {
        "SaveNotesRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/customers/SaveNotesRestApi",
        "getNotesRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/customers/getNotesRestApi"
    },
    "giftcards": {
        "viewRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/giftcards/viewRestApi",
        "gfCardsOfCustomer": "http://localhost:4080/profitGuruRestSvc/index.php/giftcards/gfCardsOfCustomer",
        "getGiftCardsRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/giftcards/getGiftCardsRestApi",
        "saveGiftCardRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/giftcards/saveGiftCardRestApi",
        "deleteGiftCardRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/giftcards/deleteGiftCardRestApi",
        "giftCrdAmt4Customer": "http://localhost:4080/profitGuruRestSvc/index.php/giftcards/giftCrdAmt4Customer"

    },
    "tables": {
        "getOKOT4ThisTableRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/tables/getOKOT4ThisTableRestApi",
        "createTableRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/tables/createTableRestApi",
            priority: high,
            couchsync: true
        },
        "getKOTItemRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/tables/getKOTItemRestApi",
        "getTablesRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/tables/getTablesRestApi",
        "getOrders4ThisTableRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/tables/getOrders4ThisTableRestApi",
        "getAllTablesOrdersRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/tables/getAllTablesOrdersRestApi",
        "getItemsForTableOrderRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/tables/getItemsForTableOrderRestApi",
            priority: high
        },
        "getDeliveryDetailRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/tables/getDeliveryDetailRestApi",
        "deleteTableApiRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/tables/deleteTableApiRestApi",
            deleteFlagUsed: false,
            couchdSync: true,
            priority: high
        },
        "deleteCustomer4OrderRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/tables/deleteCustomer4OrderRestApi",
            priority: high
        },
        "deleteOrdersOfTableRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/tables/deleteOrdersOfTableRestApi",
            priority: high,
            couchsync: true
        }
    },
    "reservation": {
        "saveReservationRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/reservation/saveReservationRestApi",
        "getReservationDetails": "http://localhost:4080/profitGuruRestSvc/index.php/reservation/getReservationDetails",
        "selectTable": "http://localhost:4080/profitGuruRestSvc/index.php/reservation/selectTable",
        "checkReservation4tableRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/reservation/checkReservation4tableRestApi",
        "minimumReservationDuration": "http://localhost:4080/profitGuruRestSvc/index.php/reservation/minimumReservationDuration",
        "checkAlreadyReservedRestApi": {
            url: "http://localhost:4080/profitGuruRestSvc/index.php/reservation/checkAlreadyReservedRestApi",
            priority: high
        },
        "deleteReservationRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/reservation/deleteReservationRestApi",
        "reservationWindowRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/reservation/reservationWindowRestApi",
        "getReservationDetails4TableColorChange": "http://localhost:4080/profitGuruRestSvc/index.php/reservation/getReservationDetails4TableColorChange"
    },
    "homedelivery": {
        "deleteHomeDeliveryRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/homedelivery/deleteHomeDeliveryRestApi"
    },
    "terminalOrders": {
        "getOrderDetails4TwoTerminalRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/TwoterminalPayment/getOrderDetails4TwoTerminalRestApi",
        "deleteOrderRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/TwoterminalPayment/deleteOrderRestApi"
    },
    "sms": {
        "SendSMS": "http://localhost:4080/profitGuruRestSvc/tests_sample.php/SendSMS"
    },
    "email": {
        "gmail_sample.php": "http://localhost:4080/profitGuruRestSvc/PHPMailer/examples/gmail_sample.php"
    },
    "terminalApp": {
        "getProfitGuruServers": "http://localhost:4081/profitGuruRestSvc/index.php/terminalApp/getProfitGuruServers"
    },
    "counterOrders": {
        "deleteOrderRestApi": "http://localhost:4080/profitGuruRestSvc/index.php/counterOrders/deleteOrderRestApi"
    }
};