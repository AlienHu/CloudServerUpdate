import { load } from 'dotenv-safe';
load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});

import * as chai from 'chai';
const expect = chai.expect;

import * as testUtils from '../common/Utils';
import compareObject = testUtils.compareObject;
import compareArray = testUtils.compareArray;

import { ComputeSale } from '../../TSControllers/interfaces/computeSaleDoc';
import ComputeSaleItem = ComputeSale.SaleItem;

import { assignTaxesForItem4UT } from '../../TSControllers/libraries/SalesEx';
import { TaxProfileEx } from '../../TSControllers/interfaces/TaxProfile';
import { Tax } from '../../TSControllers/interfaces/taxCommon';
import { UnitsInfo } from '../../TSControllers/interfaces/unitsInfo';
import * as commonLib from '../../controllers/libraries/commonLib';
import * as computeUtils from '../../controllers/common/computeUtils';
import getPriceTaxEx = computeUtils.getPriceTaxEx;

import { getTaxesFromProfile } from '../../TSControllers/libraries/commonLibEx';

describe('assignTaxesForItem UT', function () {
    this.timeout(100000);

    let unitsInfo: UnitsInfo = {
        "1": {
            factor: 1,
            refUnitId: 1,
            purchasePrice: 0,
            mrp: 0,
            pProfilesData: {}
        },
        "2": {
            factor: 10,
            refUnitId: 1,
            purchasePrice: 0,
            mrp: 0,
            pProfilesData: {}
        },
        "3": {
            factor: 10,
            refUnitId: 2,
            purchasePrice: 0,
            mrp: 0,
            pProfilesData: {}
        },
        "4": {
            factor: 100,
            refUnitId: 5,
            purchasePrice: 0,
            mrp: 0,
            pProfilesData: {}
        },
        "5": {
            factor: 1,
            refUnitId: 5,
            purchasePrice: 0,
            mrp: 0,
            pProfilesData: {}
        }
    } as UnitsInfo;

    let item: ComputeSaleItem = {
        unitId: "1",
        baseUnitId: "1",
        unitsInfo: unitsInfo,
        origTaxesList: [{
            name: 'GST',
            percent: 5
        }, {
            name: 'Cess',
            percent: 0.5
        }, {
            name: 'VAT',
            percent: 20
        }],
        slab: {
            name: 'temp',
            taxName: 'GST',
            rates: [{
                min: 0,
                max: 1000,
                percent: 0
            }, {
                min: 1000,
                max: 2000,
                percent: 12
            }, {
                min: 2000,
                max: 9999,
                percent: 28
            }]
        },
        ItemType: 'Normal',
        bSPTaxInclusive: false,
    } as ComputeSaleItem;

    let taxProfileEx: TaxProfileEx = {
        name: 'default',
        description: 'hello',
        slab: {
            name: 'tempTaxProfileSlab',
            taxName: 'GST',
            rates: [{
                min: 0,
                max: 1000,
                percent: 10
            }, {
                min: 1000,
                max: 2000,
                percent: 20
            }, {
                min: 2000,
                max: 9999,
                percent: 30
            }]
        },
        normalTaxes: [{
            name: 'GST',
            percent: 5.2
        }, {
            name: 'Extra Tax',
            percent: 5
        }, {
            name: 'VAT',
            percent: 5.4
        }],
        preparedTaxes: [{
            name: 'GST',
            percent: 6.2
        }, {
            name: 'Cess',
            percent: 6.6
        }, {
            name: 'VAT',
            percent: 6.4
        }],
        liquorTaxes: [{
            name: 'GST',
            percent: 8.2
        }, {
            name: 'Cess',
            percent: 8.6
        }, {
            name: 'VAT',
            percent: 8.4
        }],
        charges: [{
            name: 'Service Charge',
            percent: 20
        }]
    } as TaxProfileEx;

    it('get base unit price', function () {
        expect(commonLib.getBaseUnitPrice(1000, "1", "1", unitsInfo)).to.equal(1000);
        expect(commonLib.getBaseUnitPrice(1000, "2", "1", unitsInfo)).to.equal(100);
        expect(commonLib.getBaseUnitPrice(1000, "3", "1", unitsInfo)).to.equal(10);
        expect(commonLib.getBaseUnitPrice(1000, "4", "1", unitsInfo)).to.equal(1000);
    });

    it('get slab first slab', function () {
        let taxFromSlab: Tax = computeUtils.getTaxFromSlab(item.slab, 900);
        let expectedTax: Tax = {
            name: 'GST',
            percent: 0
        };
        let errorsArray: string[] = [];
        let bSame: boolean = compareObject(expectedTax, taxFromSlab, 0, [], );
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });

    it('get slab second slab', function () {
        let taxFromSlab: Tax = computeUtils.getTaxFromSlab(item.slab, 1900);
        let expectedTax: Tax = {
            name: 'GST',
            percent: 12
        };
        let errorsArray: string[] = [];
        let bSame: boolean = compareObject(expectedTax, taxFromSlab, 0, [], );
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });

    it('formatting taxes local', () => {
        let taxArr: Tax[] = [{
            name: 'GST',
            percent: 10
        }];
        computeUtils.formatGSTTaxes(taxArr, true);
        let expectedTaxArr: Tax[] = [{
            name: 'CGST',
            percent: 5
        }, {
            name: 'SGST',
            percent: 5
        }];
        let errorsArray: string[] = [];
        let bSame: boolean = compareObject(expectedTaxArr, taxArr, 0, [], );
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });

    it('formatting taxes inter', () => {
        let taxArr: Tax[] = [{
            name: 'GST',
            percent: 10
        }];
        computeUtils.formatGSTTaxes(taxArr, false);
        let expectedTaxArr: Tax[] = [{
            name: 'IGST',
            percent: 10
        }];
        let errorsArray: string[] = [];
        let bSame: boolean = compareObject(expectedTaxArr, taxArr, 0, [], );
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });

    it('getTaxesFromProfile', () => {
        let taxArr: Tax[] = getTaxesFromProfile(taxProfileEx, 'Normal');
        let errorsArray: string[] = [];
        let bSame: boolean = compareArray(taxProfileEx.normalTaxes, taxArr, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);

        taxArr = getTaxesFromProfile(taxProfileEx, 'Prepared');
        errorsArray = [];
        bSame = compareArray(taxProfileEx.preparedTaxes, taxArr, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);

        taxArr = getTaxesFromProfile(taxProfileEx, 'Liquor');
        errorsArray = [];
        bSame = compareArray(taxProfileEx.liquorTaxes, taxArr, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });

    it('with item slab', async function () {
        let totalTaxPercent: number = assignTaxesForItem4UT(item, taxProfileEx, true, 900);
        expect(totalTaxPercent).to.equal(25.5);
        expect(item.itemTaxList.length).to.equal(5);
        let expectedItemTaxArr: Tax[] = [{
            name: 'Cess',
            percent: 0.5
        }, {
            name: 'VAT',
            percent: 20
        }, {
            name: 'Extra Tax',
            percent: 5
        }, {
            name: 'CGST',
            percent: 0
        }, {
            name: 'SGST',
            percent: 0
        }];

        let errorsArray: string[] = [];
        let bSame: boolean = compareArray(expectedItemTaxArr, item.itemTaxList, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });

    it('without item slab', async function () {
        let key: string = 'slab';
        delete item[key]; //cheating because it is a readonly property
        let totalTaxPercent: number = assignTaxesForItem4UT(item, taxProfileEx, true, 900);
        expect(totalTaxPercent).to.equal(35.5);
        expect(item.itemTaxList.length).to.equal(5);
        let expectedItemTaxArr: Tax[] = [{
            name: 'Cess',
            percent: 0.5
        }, {
            name: 'VAT',
            percent: 20
        }, {
            name: 'Extra Tax',
            percent: 5
        }, {
            name: 'CGST',
            percent: 5
        }, {
            name: 'SGST',
            percent: 5
        }];

        let errorsArray: string[] = [];
        let bSame: boolean = compareArray(expectedItemTaxArr, item.itemTaxList, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });

    it('without slab', async function () {
        let key: string = 'slab';
        delete taxProfileEx[key]; //cheating because it is a readonly property
        let totalTaxPercent: number = assignTaxesForItem4UT(item, taxProfileEx, true, 900);
        expect(totalTaxPercent).to.equal(30.5);
        expect(item.itemTaxList.length).to.equal(5);
        let expectedItemTaxArr: Tax[] = [{
            name: 'Cess',
            percent: 0.5
        }, {
            name: 'VAT',
            percent: 20
        }, {
            name: 'Extra Tax',
            percent: 5
        }, {
            name: 'CGST',
            percent: 2.5
        }, {
            name: 'SGST',
            percent: 2.5
        }];

        let errorsArray: string[] = [];
        let bSame: boolean = compareArray(expectedItemTaxArr, item.itemTaxList, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });

    it('getPriceTaxEx test', function () {
        //including tax test
        let priceExTax = getPriceTaxEx(100, true, 10);
        expect(priceExTax - 90.9).to.within(-0.01, 0.01);
        //excluding tax test
        priceExTax = getPriceTaxEx(100, false, 10);
        expect(priceExTax).to.equal(100);
    });

});