import { load } from 'dotenv-safe';
load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});

import * as chai from 'chai';
const expect = chai.expect;

import * as testUtils from '../common/Utils';
import compareObject = testUtils.compareObject;
import compareArray = testUtils.compareArray;
import { isLocalTax4UT, getChargesTaxesList4UT, doComputation4UT } from '../../TSControllers/libraries/SalesEx';

import { ComputeSale } from '../../TSControllers/interfaces/computeSaleDoc';
import SaleFullInfo = ComputeSale.SaleFullInfo;
import SaleDoc = ComputeSale.SaleDoc;
import SaleItem = ComputeSale.SaleItem;
import Computation = ComputeSale.Computation;

import { TaxProfileEx } from '../../TSControllers/interfaces/TaxProfile';
import { Tax } from '../../TSControllers/interfaces/taxCommon';
import { UnitsInfo } from '../../TSControllers/interfaces/unitsInfo';
import { ApplicationSettings } from '../../TSControllers/interfaces/applicationSettings';

describe('Sales Logic UT', function () {
    this.timeout(100000);

    it('is local tax', () => {
        let fullInfo: SaleFullInfo = {
            customer: {
                state_name: 'Andhra Pradesh'
            },
            applicationSettings: {
                ownersInfo: {
                    state: 'Andhra Pradesh'
                }
            }
        } as SaleFullInfo;

        expect(isLocalTax4UT(fullInfo)).to.equal(true);

        fullInfo = {
            customer: {
                state_name: 'Andhra Pradesh'
            },
            applicationSettings: {
                ownersInfo: {
                    state: 'Tamil Nadu'
                }
            }
        } as SaleFullInfo;

        expect(isLocalTax4UT(fullInfo)).to.equal(false);

        fullInfo = {
            customer: {
                state_name: 'Andhra Pradesh'
            },
            applicationSettings: {
                ownersInfo: {

                }
            }
        } as SaleFullInfo;

        expect(isLocalTax4UT(fullInfo)).to.equal(true);

        fullInfo = {
            applicationSettings: {
                ownersInfo: {
                    state: 'Tamil Nadu'
                }
            }
        } as SaleFullInfo;

        expect(isLocalTax4UT(fullInfo)).to.equal(true);
    });

    it('get charges tax list', () => {
        let taxProfileEx: TaxProfileEx = {
            preparedTaxes: [{
                name: 'GST',
                percent: 6.2
            }, {
                name: 'Cess',
                percent: 6.6
            }, {
                name: 'VAT',
                percent: 6.4
            }]
        } as TaxProfileEx;

        let chargesTaxArr: Tax[] = getChargesTaxesList4UT(taxProfileEx, true);
        let expectedChargesTaxArr: Tax[] = [{
            name: 'Cess',
            percent: 6.6
        }, {
            name: 'VAT',
            percent: 6.4
        }, {
            name: 'CGST',
            percent: 3.1
        }, {
            name: 'SGST',
            percent: 3.1
        }];

        let errorsArray: string[] = [];
        let bSame: boolean = compareArray(expectedChargesTaxArr, chargesTaxArr, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });

    it('get charges tax list 2', () => {
        let taxProfileEx: TaxProfileEx = { preparedTaxes: [] } as TaxProfileEx;

        let chargesTaxArr: Tax[] = getChargesTaxesList4UT(taxProfileEx, true);
        let expectedChargesTaxArr: Tax[] = [];

        let errorsArray: string[] = [];
        let bSame: boolean = compareArray(expectedChargesTaxArr, chargesTaxArr, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });

    it('do compute', () => {
        let saleDoc: SaleDoc = {
            temp: {
                bLocalTax: true,
                chargesTaxList: [{
                    name: 'CGST',
                    percent: 10
                }, {
                    name: 'SGST',
                    percent: 10
                }]
            },
            sale_items: [{
                discount_percent: 5,
                sellingPrice: 100,
                bSPTaxInclusive: false,
                quantity_purchased: 10,
                unitId: "1",
                baseUnitId: "1",
                unitsInfo: {
                    "1": {
                        factor: 1,
                        refUnitId: 1,
                        purchasePrice: 0,
                        mrp: 0,
                        pProfilesData: {}
                    }
                } as UnitsInfo,
                origTaxesList: [{
                    name: 'GST',
                    percent: 5
                }],
                ItemType: 'Normal',
                chargesList: [{
                    name: 'Service Charge',
                    percent: 10
                }],
                chargesTaxList: [{
                    name: 'CGST',
                    percent: 10
                }, {
                    name: 'SGST',
                    percent: 10
                }]
            }],
            fullInfo: {},
            bSuccess: false,
            message: '',
            _id: '',
            _rev: '',
            sale_id: 1,
            payments: [],
            status: {}
        } as SaleDoc;

        let computation: Computation = doComputation4UT(saleDoc, 0, 10);
        expect(computation.totalExDiscount).to.equal(1000);
        expect(computation.totalItemDiscountAmt).to.equal(50);
        expect(computation.gDiscountPercent).to.equal(10);
        expect(computation.totalDiscountPercent).to.equal(15);
        expect(computation.totalGDiscountAmt).to.equal(100);
        expect(computation.totalDiscountAmt).to.equal(150);
        expect(computation.totalInDiscount).to.equal(850);
        expect(computation.totalCharges).to.equal(85);
        expect(computation.taxableValue).to.equal(935);
        expect(computation.totalChargesTaxAmt).to.equal(17);
        expect(computation.totalItemTaxAmt).to.equal(42.50);
        expect(computation.totalTaxPercent).to.equal(5);
        expect(computation.totalTaxAmt).to.equal(59.50);
        expect(computation.totalExDiscount).to.equal(1000);
    });

});