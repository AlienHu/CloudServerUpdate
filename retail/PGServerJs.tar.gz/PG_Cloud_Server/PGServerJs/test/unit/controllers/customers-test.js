// var type = [];
// type[0] = "supplier";
// type[1] = "customer";
// for (var element = 0; element < type.length; element++) {

(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });
    var utils = require('../../common/Utils.js');
    var cntrlUtils = require('../../../controllers/common/Utils.js');
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var mainDBInstance = couchDBUtils.getMainCouchDB();
    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    var chaiFiles = require('chai-files');
    chai.use(chaiFiles);
    var file = chaiFiles.file;
    chai.should();
    var expect = chai.expect;
    var type = 'supplier';
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    var faker = require('faker');
    var profitGuruFaker = require('../../common/profitGuruFaker.js');

    /**
     * CommitTodo 
     * 1. Write all the tests in a loop -> run once for customer, run once for supplier. 
     *        CouchDB Views are also different
     *        Because validations may be different.
     *        Example GSTIN is not mandatory for customer but mandatory for supplier     *          * 
     * */

    describe('Elemets Controller UTs  ', function(done) {

        this.timeout(100000);
        var elementsController = require('../../../controllers/Elements');

        var personData;
        if (type === 'customer') {
            personData = profitGuruFaker.getFakerCustomer();
        } else {
            personData = profitGuruFaker.getFakerSupplier();
        }
        var email = personData.email;

        var createdPersonID = -1;

        before(function() {
            var logDir = '.';
            utils.deleteFilesOfType(logDir, ['log']);

            return couchDbManager.initCouchDb(true);
        });

        beforeEach(function() {});

        it('merge customer test', async function() {
            let fakeData = profitGuruFaker.getFakerCustomer();
            let resp = await elementsController.mergeCustomer(fakeData);
            let queryResponse = await couchDBUtils.getDoc('customer_' + resp.data.id, mainDBInstance);
            expect(utils.compareObject(fakeData, queryResponse)).to.equal(true);
            fakeData.person_id = resp.data.id;
            resp = await elementsController.mergeCustomer(fakeData);
            queryResponse = await couchDBUtils.getDoc('customer_' + resp.data.id, mainDBInstance);
            expect(utils.compareObject(fakeData, queryResponse)).to.equal(true);
        });

    });

})();