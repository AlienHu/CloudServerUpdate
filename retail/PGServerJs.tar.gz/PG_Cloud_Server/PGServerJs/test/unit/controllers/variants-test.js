 'use strict';
 require('dotenv-safe').load({
     path: __dirname + '/../../../.env',
     sample: __dirname + '/../../../env.example'
 });
 var chai = require("chai");
 var chaiAsPromised = require("chai-as-promised");
 chai.use(chaiAsPromised);
 chai.should();
 var expect = chai.expect;
 var profitGuruFakerExt = require('../../common/profitGuruFakerExt.js');
 var utils = require('../../common/Utils.js');
 const couchDbManager = require('../../../dbManagers/couchDbManager');
 var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
 var mainDBInstance = couchDBUtils.getMainCouchDB();

 var BPromise = require('bluebird');

 describe('Variants Controller UTS', function() {

     var variantData = profitGuruFakerExt.getFakerRandomAttribute();
     var variantsController;
     this.timeout(200000);
     var variantDataId = -1;
     var variantCouchDoc = {};
     var variantToUpdateDoc = {}
     var coutchUpdatedVariantDoc = {};
     before(function() {
         return couchDbManager.initCouchDb(false).then(resp => {
             variantsController = require('../../../controllers/Variants');
         });
     });

     it('create variant', function() {
         var name = variantData.name;
         console.log(JSON.stringify(variantData));
         return variantsController.create(variantData).then(function(resp) {
             expect(resp.message).to.equal(name + ' created Successfully');
             expect(resp.error).to.equal(null);
             expect(resp.data).to.not.equal(null)
             expect(resp.data.id).to.not.equal(undefined);
             variantDataId = resp.data.id;
             return couchDBUtils.getDoc(variantDataId, mainDBInstance);
         }).then(function(variantDoc) {
             variantCouchDoc = variantDoc;
             var expectedData = {};
             expectedData.name = name;
             expectedData.values = {};
             for (var i = 0; i < variantData.values.length; i++) {
                 expectedData.values[i + 1] = variantData.values[i];
             }
             expect(variantDoc.name).to.equal(expectedData.name);
             for (i in variantDoc.values) {
                 expect(variantDoc.values[i].name).to.equal(expectedData.values[i].name);
             }

         }).catch(function(err) {
             console.log(err);
             console.log('error in variant creation');
             expect(1).to.equal(0);
         });
     });

     it('create duplicate variant data', function() {
         variantData.name = variantData.name.toUpperCase();
         var bException = false;
         return variantsController.create(variantData).then(function(resp) {
             bException = true;
             expect(1).to.equal(0);
         }).catch(function(err) {
             if (bException) {
                 expect(1).to.equal(0);
             }

             console.log(err);
             expect(err.error).to.not.equal(null);
         });
     });

     it('update variant data', function() {

         console.log("Doc in db: " + JSON.stringify(variantCouchDoc));
         variantToUpdateDoc = profitGuruFakerExt.getFakerRandomAttributeUpdate(variantCouchDoc);
         console.log("New Doc to update: " + JSON.stringify(variantToUpdateDoc));
         return variantsController.update(variantToUpdateDoc).then(function(resp) {
             expect(resp.message).to.equal("Variant updated successfully");
             expect(resp.error).to.equal(null);
             expect(resp.data).to.not.equal(null);
             expect(resp.data.id).to.equal(variantDataId);
             return couchDBUtils.getDoc(variantDataId, mainDBInstance);
         }).then(function(variantDoc) {
             coutchUpdatedVariantDoc = variantDoc;
             console.log("New updated Doc in db : " + JSON.stringify(coutchUpdatedVariantDoc));
             return variantsController.runVariantValidations(variantToUpdateDoc, true); //Using this function without UT
         }).then(function(processedInput) {
             expect(coutchUpdatedVariantDoc.name).to.equal(processedInput.name);
             for (var i in coutchUpdatedVariantDoc.values) {
                 expect(coutchUpdatedVariantDoc.values[i].name).to.equal(processedInput.values[i].name);
             }
         }).catch(function(error) {
             console.log(error);
             expect(1).to.equal(0);
         });
     });

     it('delete variant', function() {
         return variantsController.delete(variantCouchDoc).then(function(resp) {
             expect(resp.message).to.equal("Variant deleted successfully");
             expect(resp.error).to.equal(null);
             expect(resp.data).to.not.equal(null);
             expect(resp.data.id).to.equal(variantCouchDoc.id);
             return couchDBUtils.getDoc(variantDataId, mainDBInstance);
         }).then(function(variantDoc) {
             expect(variantDoc.deleted).to.equal("1");
         }).catch(function(error) {
             console.log("Failed to delete variant");
             expect(1).to.equal(0);
         });
     });

 });