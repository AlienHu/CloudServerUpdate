"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const testUtils = require("../../common/Utils");
var compareObject = testUtils.compareObject;
var compareArray = testUtils.compareArray;
const scheduleCampaignHelper_1 = require("../../../controllers/libraries/scheduleCampaignHelper");
const scheduler_1 = require("../../../controllers/libraries/scheduler");
const moment = require("moment");
describe('XXXX UT', function () {
    this.timeout(100000);
    before(function () {
    });
    it('xxxxxxxxxx', () => {
        let refObj = { a: 1, b: 2, c: 5 };
        let insObj = { a: 2, b: 1 };
        let errorsArray = [];
        let bSame = compareObject(refObj, insObj, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(false);
    });
    it('XXXXXX', function () {
        let refArr = [1, 2, 3];
        let insArr = [1, 2, 3];
        let errorsArray = [];
        let bSame = compareArray(refArr, insArr, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });
    it('testing generateSchedules4UT', () => {
        let startTime = moment('2018-03-19');
        let data = {
            "message": "linto hello",
            "customers": [
                {
                    "_id": "customer_1521046268402",
                    "status": "pending"
                }
            ],
            "dayOfWeekArr": [
                0, 1, 2, 3, 4, 5, 6
            ],
            "timeOfDayArr": [
                "1970-01-01T20:00:00.000Z"
            ],
            "startDate": "2018-03-19T10:25:45.225Z",
            "endDate": "2018-03-25T18:30:00.000Z",
            "status": "pending"
        };
        scheduleCampaignHelper_1.generateSchedules(data);
        console.log(data);
        expect(data.scheduleStatusArr.length).to.equal(7);
        let firstTime = moment(data.startDate).startOf('day');
        let dayNumber = 0;
        data.scheduleStatusArr.forEach(function (sch) {
            data.timeOfDayArr.forEach(function (time) {
                let schTime = new Date(time);
                let hours = schTime.getHours();
                let minutes = schTime.getMinutes();
                let ts = moment(firstTime).startOf('day').add(dayNumber, 'day').add(hours, 'h').add(minutes, 'm').format('x');
                expect(sch.timestamp).to.equal(ts);
            });
            dayNumber += 1;
        });
    });
    it('testing processWisher4UT', () => {
        let startTime = moment('2018-03-19');
        let data = {
            "message": "linto hello",
            "customers": [
                {
                    "_id": "customer_1521046268402",
                    "status": "pending"
                }
            ],
            "dayOfWeekArr": [
                0, 1, 2, 3, 4, 5, 6
            ],
            "timeOfDayArr": [
                "1970-01-01T20:00:00.000Z"
            ],
            daysBefore: 20,
            type: 'birth_day',
            "status": "pending"
        };
        scheduler_1.processWisher4UT();
    });
    it.only('testing getBdayCustomers4UT', () => __awaiter(this, void 0, void 0, function* () {
        let start = moment().startOf('day').toISOString();
        let end = moment().add(4, 'days').endOf('day').toISOString();
        let type = 'birth_day';
        let customers = yield scheduler_1.getBdayCustomers4UT(type, start, end);
        expect(customers.length).to.equal(0);
    }));
});
//# sourceMappingURL=crmts-test.js.map