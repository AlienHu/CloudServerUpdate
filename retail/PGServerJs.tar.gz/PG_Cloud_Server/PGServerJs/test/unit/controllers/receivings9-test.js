'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const profitGuruFaker = require('../../common/profitGuruFaker.js');
// const logger = require('../../../common/Logger');
const utils = require('../../common/Utils.js');
// const CLONE = utils.clone;
const commonUtils = require('../../common/commonUtils');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
let receivingsController;
let itemLib;
let commonLib;
let commonWorker;

describe('Purchase Controller 7 Purchase Edit UTS', function () {

    this.timeout(500000);
    this.slow(0);

    let prevItems;

    var curItemData = {};
    var curItemDoc = {};
    var allCategories = {};
    var allUnits = {};
    var categoryId = '';
    var unitId = '';
    var itemJson1 = {};
    var itemJson2 = {};
    var itemJson3 = {};
    var unitObj = {};
    var recentItemId = '';
    let curResponse = {};
    var itemController;
    let itemControllerLib;


    const curSession = profitGuruFaker.getFakerSession();
    let applicationSettings;

    var loadJson = function () {
        itemJson1 = {
            "uniqueItemCode": "",
            "name": "itemNormal256",
            "item_number": "",
            "receiving_quantity": 0,
            "reorder_level": 0,
            "description": "",
            "expiry_date": "",
            "allow_alt_description": "0",
            "ItemType": "",
            "categoryId": categoryId,
            "purchasePrice": "",
            "sellingPrice": "",
            "mrp": "",
            "hasMeasurementUnit": false,
            "is_serialized": false,
            "hasExpiryDate": false,
            "purchaseTaxes": [],
            "salesTaxes": [],
            "reorderLevel": "",
            "reorderQuantity": "",
            "isNewBatch": false,
            "hasBatchNumber": false,
            "bOTG": false,
            "bPPTaxInclusive": false,
            "bSPTaxInclusive": false,
            "imeiCount": 0,
            "imeNumbers": [],
            "initialStock": [{
                "quantity": 0,
                "expiry": null,
                "uniqueDetails": [],
                "unitsInfo": unitObj
            }],
            "unitsInfo": unitObj,
            "hasVariants": false,
            "density": 0,
            "pricingProfiles": false,
            "multipleUnits": false,
            "itemNprice": 0,
            "baseUnitId": unitId,
            "defaultPurchaseUnitId": unitId,
            "defaultSellingUnitId": unitId,
            "convPurchasePrice": "",
            "attributes": [],
            "isprepared": false,
            "issellable": false,
            "isbought": false,
            "is_deleted": "",
            "discount_expiry": null
        };
        itemJson2 = {
            "item_id": "",
            "uniqueItemCode": "",
            "name": "var445",
            "item_number": "",
            "receiving_quantity": 0,
            "reorder_level": null,
            "description": "",
            "supplier_id": "",
            "expiry_date": null,
            "allow_alt_description": "0",
            "ItemType": "",
            "categoryId": categoryId,
            "purchasePrice": "",
            "sellingPrice": "",
            "mrp": "",
            "hasMeasurementUnit": false,
            "is_serialized": false,
            "hasExpiryDate": false,
            "purchaseTaxes": [],
            "salesTaxes": [],
            "reorderLevel": null,
            "reorderQuantity": null,
            "isNewBatch": false,
            "hasBatchNumber": false,
            "bOTG": false,
            "bPPTaxInclusive": false,
            "bSPTaxInclusive": false,
            "imeiCount": 0,
            "imeNumbers": [],
            "initialStock": [
                {
                    "quantity": 100,
                    "unitsInfo": unitObj,
                    "attributeInfo": {
                        "1": "3",
                        "10": "4"
                    },
                    "skuName": "Cotton3/Metal4"
                }
            ],
            "unitsInfo": unitObj,
            "hasVariants": true,
            "density": 0,
            "pricingProfiles": false,
            "multipleUnits": false,
            "images": [],
            "bAvailableForPurchaseOrder": true,
            "bReadQtyFromWeighingMachine": false,
            "itemNprice": 0,
            "baseUnitId": unitId,
            "subCategories": [],
            "defaultPurchaseUnitId": unitId,
            "defaultSellingUnitId": unitId,
            "subCategoryId": "",
            "attributes": [
                1,
                10
            ]
        };
        itemJson3 = {
            "item_id": "",
            "uniqueItemCode": "",
            "name": "imei1",
            "item_number": "",
            "receiving_quantity": 0,
            "reorder_level": null,
            "description": "",
            "supplier_id": "",
            "expiry_date": null,
            "allow_alt_description": "0",
            "ItemType": "",
            "categoryId": categoryId,
            "purchasePrice": "",
            "sellingPrice": "",
            "mrp": "",
            "hasMeasurementUnit": false,
            "is_serialized": true,
            "hasExpiryDate": false,
            "purchaseTaxes": [],
            "salesTaxes": [],
            "reorderLevel": null,
            "reorderQuantity": null,
            "isNewBatch": false,
            "hasBatchNumber": false,
            "bOTG": false,
            "bPPTaxInclusive": false,
            "bSPTaxInclusive": false,
            "imeiCount": 1,
            "imeNumbers": [],
            "initialStock": [
                {
                    "quantity": 1,
                    "expiry": null,
                    "uniqueDetails": [
                        {
                            "serialnumber": "5656",
                            "imeiNumbers": [
                                656646134646316
                            ]
                        }
                    ],
                    "unitsInfo": unitObj
                }
            ],
            "unitsInfo": unitObj,
            "hasVariants": false,
            "density": 0,
            "pricingProfiles": false,
            "multipleUnits": false,
            "images": [],
            "bAvailableForPurchaseOrder": false,
            "bReadQtyFromWeighingMachine": false,
            "itemNprice": 0,
            "baseUnitId": unitId,
            "subCategories": [],
            "defaultPurchaseUnitId": unitId,
            "defaultSellingUnitId": unitId,
            "subCategoryId": "",
            "imei": true,
            "attributes": []
        };
    }

    before(async function () {
        let logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);

        let bResetDB = true;
        let resp = await couchDbManager.initCouchDb(bResetDB);
        applicationSettings = resp.applicationSettings;
        commonWorker = require('../../../controllers/workers/commonWorker');
        itemController = require('../../../controllers/Items');
        itemControllerLib = require('../../../controllers/libraries/itemsControllerLib');

        // commonWorker.setFreeze(true);

        prevItems = await commonUtils.createAllItemTypes(true, true);
        // supplierArray = await commonUtils.getPeople(2, 'supplier');
        // allVariants = await couchDBUtils.getAllDocsByType('variant', mainDBInstance, {}, true);
        receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);
        // receivingsTestHelper = require('./testHelpers/receivingsTestHelper')(curSession, applicationSettings);
        itemLib = require('../../../controllers/libraries/itemsControllerLib');
        commonLib = require('../../../controllers/libraries/commonLib');

        allCategories = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
        allUnits = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);
        // expect(customerArray.length).to.be.at.least(2);
        categoryId = allCategories[0].doc.id;
        unitId = allUnits[0].doc.id;

        unitObj[unitId] = {
            "refUnitId": unitId,
            "factor": 1,
            "purchasePrice": 100,
            "mrp": 300,
            "pProfilesData": {
                "1543060926258": {
                    "sellingPrice": 200,
                    "discountId": ""
                }
            }
        }
        loadJson();
    });

    after(function () { });

    it('create item', async function () {
        curItemData = itemJson1;
        recentItemId = '';
        return itemController.createItem(curItemData).then(function (resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function (resp) {
            curItemDoc = resp;
            recentItemId = curItemDoc.item_id
            console.log('Item created ==' + curItemDoc.item_id);
        }).catch(function (err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        });
    });


    it('additemById', async function () {
        return await receivingsController.additemById({
            item_id: recentItemId
        }).then(function (resp) {
            curResponse = resp;
            if (recentItemId === resp.cart[0].item_id) {
                expect(resp.cart[0].quantity).to.equal(1);
            }
            console.log('Item Added to cart ==' + resp.cart[0].item_id);
        }).catch();
    });

    it('create item', async function () {
        curItemData = itemJson2;
        recentItemId = '';
        return itemController.createItem(curItemData).then(function (resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function (resp) {
            curItemDoc = resp;
            recentItemId = curItemDoc.item_id
            console.log('Item created ==' + curItemDoc.item_id);
        }).catch(function (err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        });
    });

    it('additemById', async function () {
        return await receivingsController.additemById({
            item_id: recentItemId
        }).then(function (resp) {
            curResponse = resp;
            // if (recentItemId === resp.cart[0].item_id) {
            //     expect(resp.cart[0].quantity).to.equal(1);
            // }

            expect(resp.cart).to.equal(undefined);
            // }
            console.log('Item Added to cart ==' + resp.cart);
            console.log('Item Added to cart ==' + resp.err);
        }).catch();
    });

    it('create item', async function () {
        curItemData = itemJson3;
        recentItemId = '';
        return itemController.createItem(curItemData).then(function (resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function (resp) {
            curItemDoc = resp;
            recentItemId = curItemDoc.item_id
            console.log('Item created ==' + curItemDoc.item_id);
        }).catch(function (err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        });
    });

    it('additemById', async function () {
        return await receivingsController.additemById({
            item_id: recentItemId
        }).then(function (resp) {
            curResponse = resp;
            // if (recentItemId === resp.cart[0].item_id) {
            //     expect(resp.cart[0].quantity).to.equal(1);
            // }
            expect(resp.cart).to.equal(undefined);
            // }
            console.log('Item Added to cart ==' + resp.cart);
            console.log('Item Added to cart ==' + resp.err);
        }).catch();
    })
});