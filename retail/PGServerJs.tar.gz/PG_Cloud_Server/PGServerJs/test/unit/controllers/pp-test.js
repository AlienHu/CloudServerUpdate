'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const moment = require('moment');
const utils = require('../../common/Utils.js');
const commonUtils = require('../../common/commonUtils');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
let recipeCntrlr;

describe('Production Plan UTS', function () {

    this.timeout(500000);
    this.slow(0);

    let prevItems = [];
    let pProfiles;
    let cart = {};
    let prevResponse;
    let pp = {
        ingredientList: [],
        ppTimeStamp: moment().format('x'),
        lastupdatedBy: "hello",
    };

    before(async function () {
        let logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);

        let bResetDB = false;
        let resp = await couchDbManager.initCouchDb(bResetDB);

        prevItems = await commonUtils.createAllItemTypes(true, true, false);
        recipeCntrlr = require('../../../controllers/Receipe');
        await recipeCntrlr.updateProductionPlan(pp);
    });

    //rm controllers/Receipe.js controllers/libraries/inventoryTransactionHelper.js controllers/interfaces/*.js

    it('make pp json for test', function () {
        //different units can be there
        let ingredientList = pp.ingredientList;
        for (let i = 0; i < prevItems.length; i++) {
            let quantity = 10;
            let item = prevItems[i];
            let inventory = item.inventory;
            let stock = inventory.stock
            if (inventory.quantity < quantity) {
                throw 'Insufficient Quantity';
            }
            let batchesLength = Object.keys(stock).length;
            let noOfBatches = 3;
            if (batchesLength < noOfBatches) {
                noOfBatches = batchesLength;
            }

            let ingredient = {
                item_id: 'item_' + item.item_id,
                unitId: item.baseUnitId,
                baseUnitId: item.baseUnitId,
                quantity: quantity,
                batchList: []
            }

            let splitQuantity = quantity / noOfBatches;
            for (let j = 0; j < noOfBatches; j++) {
                let stockInfo = item.batches[j];
                let curQuantity = Math.ceil(splitQuantity);
                quantity -= curQuantity;
                if (quantity < 0) {
                    curQuantity += quantity;
                }

                let batch = {
                    stockKey: stockInfo.stockKey,
                    unitId: item.baseUnitId,
                    batchId: stockInfo.batchId,
                    skuName: stockInfo.skuName,
                    quantity: curQuantity,
                    unitsInfo: stockInfo.unitsInfo
                };
                ingredient.batchList.push(batch);
            }
            ingredientList.push(ingredient);
        }

        console.log(ingredientList);
    });

    function checkInventory(curItems, prevItems, ingredientList) {
        for (let i = 0; i < ingredientList.length; i++) {
            let prevInventory = prevItems[i].inventory;
            let curInventory = curItems[i].inventory;
            let ingredient = ingredientList[i];
            expect(prevInventory.quantity - curInventory.quantity).to.equal(ingredient.quantity);
            let batchList = ingredient.batchList;
            let prevStock = prevInventory.stock;
            let curStock = curInventory.stock;
            for (let j = 0; j < batchList.length; j++) {
                let batchInfo = batchList[j];
                let stockKey = batchInfo.stockKey;
                expect(prevStock[stockKey].quantity - curStock[stockKey].quantity).to.equal(batchInfo.quantity);
            }
        }
    }

    function checkInventory1(curItems, prevItems, se) {
        let { items, bDecrement } = se;
        let multiply = 1;
        if (!bDecrement) {
            multiply = -1;
        }
        for (let i = 0; i < items.length; i++) {
            let item = items[i];
            let itemIndex = parseInt(item.item_id) - 1;
            let prevInventory = prevItems[itemIndex].inventory;
            let curInventory = curItems[itemIndex].inventory;
            expect(prevInventory.quantity - curInventory.quantity).to.equal(10 * multiply);
            let prevStock = prevInventory.stock;
            let curStock = curInventory.stock;
            let stockKey = item.stockKey;
            expect(prevStock[stockKey].quantity - curStock[stockKey].quantity).to.equal(item.quantity * multiply);
        }
    }

    it('issue stock', async function () {
        await recipeCntrlr.approveProductionPlan(pp);
        await commonUtils.pgTimeOut(1000);
        let curItems = await commonUtils.createAllItemTypes(true, true, false);
        checkInventory(curItems, prevItems, pp.ingredientList);
        prevItems = curItems;
    });

    let stockEntry;
    it('stock entry json', function () {
        stockEntry = {
            items: [],
            timeStamp: parseInt(moment().format('x')) + 1,
            employee_id: 'admin'
        };

        for (let i = 0; i < prevItems.length; i++) {
            let quantity = 10;
            let item = prevItems[i];
            let inventory = item.inventory;
            let stock = inventory.stock
            if (inventory.quantity < quantity) {
                throw 'Insufficient Quantity';
            }
            let batchesLength = Object.keys(stock).length;
            let noOfBatches = 3;
            if (batchesLength < noOfBatches) {
                noOfBatches = batchesLength;
            }

            let splitQuantity = quantity / noOfBatches;
            for (let j = 0; j < noOfBatches; j++) {
                let stockInfo = item.batches[j];
                let curQuantity = Math.ceil(splitQuantity);
                quantity -= curQuantity;
                if (quantity < 0) {
                    curQuantity += quantity;
                }

                let stockEntryItem = {
                    item_id: item.item_id,
                    batchId: stockInfo.batchId,
                    stockKey: stockInfo.stockKey,
                    quantity: curQuantity,
                    item_location: 1,
                    skuName: stockInfo.skuName,
                    unitId: item.baseUnitId,
                    baseUnitId: item.baseUnitId,
                    unitsInfo: stockInfo.unitsInfo
                }


                stockEntry.items.push(stockEntryItem);
            }
        }
        console.log(stockEntry);
    });

    it('increase stock', async function () {
        stockEntry.bDecrement = false;
        await recipeCntrlr.stockEntry(stockEntry);
        await commonUtils.pgTimeOut(1000);
        let curItems = await commonUtils.createAllItemTypes(true, true, false);
        checkInventory1(curItems, prevItems, stockEntry);
        prevItems = curItems;
    });

    it('decrease stock', async function () {
        stockEntry.bDecrement = true;
        await recipeCntrlr.stockEntry(stockEntry);
        await commonUtils.pgTimeOut(1000);
        let curItems = await commonUtils.createAllItemTypes(true, true, false);
        checkInventory1(curItems, prevItems, stockEntry);
        prevItems = curItems;
    });

});