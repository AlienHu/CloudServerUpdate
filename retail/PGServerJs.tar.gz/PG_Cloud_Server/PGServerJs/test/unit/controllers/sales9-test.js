/**
 * Todo: write a sales/receivings common class for tests
 */

'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

/**
 *  Todo: Items and other required elements can be created once. No need to drop everytime. Consumes too much time.
 */

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
var profitGuruFaker = require('../../common/profitGuruFaker.js');
var commonTestUtils = require('../../common/commonUtils.js');
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
var mainDBInstance = couchDBUtils.getMainCouchDB();
var itemController;
var itemControllerLib;
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
const couchDbManager = require('../../../dbManagers/couchDbManager');
var curSession = profitGuruFaker.getFakerSession();
var applicationSettings = {};

describe('Sales Controller 9 UTS', function () {
    var curItemData = {};
    var curItemDoc = {};
    var allCategories = {};
    var allUnits = {};
    var categoryId = '';
    var unitId = '';
    var itemJson1 = {};
    var itemJson2 = {};
    var itemJson3 = {};
    var itemJson4 = {};
    var itemJson5 = {};
    var unitObj = {};
    var d = '';
    var n = '';
    var recentItemId = '';

    this.timeout(500000);
    this.slow(0);


    var loadJson = function () {
        itemJson1 = {
            "uniqueItemCode": "",
            "name": "itemNormal256",
            "item_number": "",
            "receiving_quantity": 0,
            "reorder_level": 0,
            "description": "",
            "expiry_date": "",
            "allow_alt_description": "0",
            "ItemType": "",
            "categoryId": categoryId,
            "purchasePrice": "",
            "sellingPrice": "",
            "mrp": "",
            "hasMeasurementUnit": false,
            "is_serialized": false,
            "hasExpiryDate": false,
            "purchaseTaxes": [],
            "salesTaxes": [],
            "reorderLevel": "",
            "reorderQuantity": "",
            "isNewBatch": false,
            "hasBatchNumber": false,
            "bOTG": false,
            "bPPTaxInclusive": false,
            "bSPTaxInclusive": false,
            "imeiCount": 0,
            "imeNumbers": [],
            "initialStock": [{
                "quantity": 0,
                "expiry": null,
                "uniqueDetails": [],
                "unitsInfo": unitObj
            }],
            "unitsInfo": unitObj,
            "hasVariants": false,
            "density": 0,
            "pricingProfiles": false,
            "multipleUnits": false,
            "itemNprice": 0,
            "baseUnitId": unitId,
            "defaultPurchaseUnitId": unitId,
            "defaultSellingUnitId": unitId,
            "convPurchasePrice": "",
            "attributes": [],
            "isprepared": false,
            "issellable": false,
            "isbought": false,
            "is_deleted": "",
            "discount_expiry": null
        };
        itemJson2 = {
            "item_id": "",
            "uniqueItemCode": "",
            "name": "var445",
            "item_number": "",
            "receiving_quantity": 0,
            "reorder_level": null,
            "description": "",
            "supplier_id": "",
            "expiry_date": null,
            "allow_alt_description": "0",
            "ItemType": "",
            "categoryId": categoryId,
            "purchasePrice": "",
            "sellingPrice": "",
            "mrp": "",
            "hasMeasurementUnit": false,
            "is_serialized": false,
            "hasExpiryDate": false,
            "purchaseTaxes": [],
            "salesTaxes": [],
            "reorderLevel": null,
            "reorderQuantity": null,
            "isNewBatch": false,
            "hasBatchNumber": false,
            "bOTG": false,
            "bPPTaxInclusive": false,
            "bSPTaxInclusive": false,
            "imeiCount": 0,
            "imeNumbers": [],
            "initialStock": [
                {
                    "quantity": 100,
                    "unitsInfo": unitObj,
                    "attributeInfo": {
                        "1": "3",
                        "10": "4"
                    },
                    "skuName": "Cotton3/Metal4"
                }
            ],
            "unitsInfo": unitObj,
            "hasVariants": true,
            "density": 0,
            "pricingProfiles": false,
            "multipleUnits": false,
            "images": [],
            "bAvailableForPurchaseOrder": true,
            "bReadQtyFromWeighingMachine": false,
            "itemNprice": 0,
            "baseUnitId": unitId,
            "subCategories": [],
            "defaultPurchaseUnitId": unitId,
            "defaultSellingUnitId": unitId,
            "subCategoryId": "",
            "attributes": [
                1,
                10
            ]
        };
        itemJson3 = {
            "item_id": "",
            "uniqueItemCode": "",
            "name": "imei1",
            "item_number": "",
            "receiving_quantity": 0,
            "reorder_level": null,
            "description": "",
            "supplier_id": "",
            "expiry_date": null,
            "allow_alt_description": "0",
            "ItemType": "",
            "categoryId": categoryId,
            "purchasePrice": "",
            "sellingPrice": "",
            "mrp": "",
            "hasMeasurementUnit": false,
            "is_serialized": true,
            "hasExpiryDate": false,
            "purchaseTaxes": [],
            "salesTaxes": [],
            "reorderLevel": null,
            "reorderQuantity": null,
            "isNewBatch": false,
            "hasBatchNumber": false,
            "bOTG": false,
            "bPPTaxInclusive": false,
            "bSPTaxInclusive": false,
            "imeiCount": 1,
            "imeNumbers": [],
            "initialStock": [
                {
                    "quantity": 1,
                    "expiry": null,
                    "uniqueDetails": [
                        {
                            "serialnumber": "5656",
                            "imeiNumbers": [
                                656646134646316
                            ]
                        }
                    ],
                    "unitsInfo": unitObj
                }
            ],
            "unitsInfo": unitObj,
            "hasVariants": false,
            "density": 0,
            "pricingProfiles": false,
            "multipleUnits": false,
            "images": [],
            "bAvailableForPurchaseOrder": false,
            "bReadQtyFromWeighingMachine": false,
            "itemNprice": 0,
            "baseUnitId": unitId,
            "subCategories": [],
            "defaultPurchaseUnitId": unitId,
            "defaultSellingUnitId": unitId,
            "subCategoryId": "",
            "imei": true,
            "attributes": []
        };
        itemJson4 = {
            "item_id": "",
            "uniqueItemCode": "",
            "name": "varTwo",
            "item_number": "",
            "receiving_quantity": 0,
            "reorder_level": null,
            "description": "",
            "supplier_id": "",
            "expiry_date": null,
            "allow_alt_description": "0",
            "ItemType": "",
            "categoryId": categoryId,
            "purchasePrice": "",
            "sellingPrice": "",
            "mrp": "",
            "hasMeasurementUnit": false,
            "is_serialized": false,
            "hasExpiryDate": false,
            "purchaseTaxes": [],
            "salesTaxes": [],
            "reorderLevel": null,
            "reorderQuantity": null,
            "isNewBatch": false,
            "hasBatchNumber": false,
            "bOTG": false,
            "bPPTaxInclusive": false,
            "bSPTaxInclusive": false,
            "imeiCount": 0,
            "imeNumbers": [],
            "initialStock": [
                {
                    "quantity": 10,
                    "unitsInfo": unitObj,
                    "attributeInfo": {
                        "1": "1",
                        "10": "2"
                    },
                    "skuName": "Steel1/Rubber2"
                },
                {
                    "quantity": 20,
                    "uniqueDetails": [],
                    "unitsInfo": unitObj,
                    "attributeInfo": {
                        "1": "2",
                        "10": "2"
                    },
                    "skuName": "Soft2/Rubber2"
                }
            ],
            "unitsInfo": unitObj,
            "hasVariants": true,
            "density": 0,
            "pricingProfiles": false,
            "multipleUnits": false,
            "images": [],
            "bAvailableForPurchaseOrder": true,
            "bReadQtyFromWeighingMachine": false,
            "itemNprice": 0,
            "baseUnitId": unitId,
            "subCategories": [],
            "defaultPurchaseUnitId": unitId,
            "defaultSellingUnitId": unitId,
            "subCategoryId": "",
            "attributes": [
                1,
                10
            ]
        };
        itemJson5 = {
            "item_id": "",
            "uniqueItemCode": "",
            "name": "imeiTwo",
            "item_number": "",
            "receiving_quantity": 0,
            "reorder_level": null,
            "description": "",
            "supplier_id": "",
            "expiry_date": null,
            "allow_alt_description": "0",
            "ItemType": "",
            "categoryId": categoryId,
            "purchasePrice": "",
            "sellingPrice": "",
            "mrp": "",
            "hasMeasurementUnit": false,
            "is_serialized": true,
            "hasExpiryDate": false,
            "purchaseTaxes": [],
            "salesTaxes": [],
            "reorderLevel": null,
            "reorderQuantity": null,
            "isNewBatch": false,
            "hasBatchNumber": false,
            "bOTG": false,
            "bPPTaxInclusive": false,
            "bSPTaxInclusive": false,
            "imeiCount": 1,
            "imeNumbers": [],
            "initialStock": [
                {
                    "quantity": 2,
                    "expiry": null,
                    "uniqueDetails": [
                        {
                            "serialnumber": "2546",
                            "imeiNumbers": [
                                656656666464463
                            ]
                        },
                        {
                            "serialnumber": "5689",
                            "imeiNumbers": [
                                654646614664646
                            ]
                        }
                    ],
                    "unitsInfo": unitObj
                }
            ],
            "unitsInfo": unitObj,
            "hasVariants": false,
            "density": 0,
            "pricingProfiles": false,
            "multipleUnits": false,
            "images": [],
            "bAvailableForPurchaseOrder": true,
            "bReadQtyFromWeighingMachine": false,
            "itemNprice": 0,
            "baseUnitId": unitId,
            "subCategories": [],
            "defaultPurchaseUnitId": unitId,
            "defaultSellingUnitId": unitId,
            "subCategoryId": "",
            "imei": true,
            "attributes": []
        };
    }

    before(async function () {
        console.log('hi')
        var resp = await couchDbManager.initCouchDb(true);
        applicationSettings = resp.applicationSettings;
        await commonTestUtils.createGlobalConfigs(5);
        itemController = require('../../../controllers/Items');
        itemControllerLib = require('../../../controllers/libraries/itemsControllerLib');

        allCategories = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
        allUnits = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);
        // expect(customerArray.length).to.be.at.least(2);
        categoryId = allCategories[0].doc.id;
        unitId = allUnits[0].doc.id;

        unitObj[unitId] = {
            "refUnitId": unitId,
            "factor": 1,
            "purchasePrice": 100,
            "mrp": 300,
            "pProfilesData": {
                "1543060926258": {
                    "sellingPrice": 200,
                    "discountId": ""
                }
            }
        }
        loadJson();
    });

    after(function () { });

    it('create item', async function () {
        curItemData = itemJson1;
        recentItemId = '';
        return itemController.createItem(curItemData).then(function (resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function (resp) {
            curItemDoc = resp;
            recentItemId = curItemDoc.item_id
            console.log('Item created ==' + curItemDoc.item_id);
        }).catch(function (err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        });
    });

    it('add Item to Cart', function () {
        curSession = profitGuruFaker.getFakerSession();
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);

        function testAddItem(id) {
            return salesController.addItemById({
                item_id: recentItemId
            }).then(function (resp) {
                curResponse = resp;
                if (recentItemId === resp.cart[0].item_id) {
                    expect(resp.cart[0].quantity).to.equal(1);
                }
                console.log('Item Added to cart ==' + resp.cart[0].item_id);
            });
        }
        testAddItem();
    });

    it('create item', async function () {
        curItemData = itemJson2;
        recentItemId = '';
        return itemController.createItem(curItemData).then(function (resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function (resp) {
            curItemDoc = resp;
            recentItemId = curItemDoc.item_id
            console.log('Item created ==' + curItemDoc.item_id);
        }).catch(function (err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        });
    });

    it('add Item to Cart', function () {
        // curSession = profitGuruFaker.getFakerSession();
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);

        function testAddItem(id) {
            return salesController.addItemById({
                item_id: recentItemId
            }).then(function (resp) {
                curResponse = resp;
                if (recentItemId === resp.cart[1].item_id) {
                    expect(resp.cart[1].quantity).to.equal(1);
                }
                console.log('Item Added to cart ==' + resp.cart[1].item_id);
            });
        }
        testAddItem();
    });

    it('create item', async function () {
        curItemData = itemJson3;
        recentItemId = '';
        return itemController.createItem(curItemData).then(function (resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function (resp) {
            curItemDoc = resp;
            recentItemId = curItemDoc.item_id
            console.log('Item created ==' + curItemDoc.item_id);
        }).catch(function (err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        });
    });

    it('add Item to Cart', function () {
        // curSession = profitGuruFaker.getFakerSession();
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);

        function testAddItem(id) {
            return salesController.addItemById({
                item_id: recentItemId
            }).then(function (resp) {
                curResponse = resp;
                if (recentItemId === resp.cart[2].item_id) {
                    expect(resp.cart[2].quantity).to.equal(1);
                }
                console.log('Item Added to cart ==' + resp.cart[2].item_id);
            });
        }
        testAddItem();
    });

    it('create item', async function () {
        curItemData = itemJson4;
        recentItemId = '';
        return itemController.createItem(curItemData).then(function (resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function (resp) {
            curItemDoc = resp;
            recentItemId = curItemDoc.item_id
            console.log('Item created ==' + curItemDoc.item_id);
        }).catch(function (err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        });
    });

    it('add Item to Cart', function () {
        // curSession = profitGuruFaker.getFakerSession();
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);

        function testAddItem(id) {
            return salesController.addItemById({
                item_id: recentItemId
            }).then(function (resp) {
                curResponse = resp;
                // if (recentItemId === resp.cart[3].item_id) {
                expect(resp.cart).to.equal(undefined);
                // }
                console.log('Item Added to cart ==' + resp);
                console.log('Item Added to cart ==' + resp.err);
            });
        }
        testAddItem();
    });

    it('create item', async function () {
        curItemData = itemJson5;
        recentItemId = '';
        return itemController.createItem(curItemData).then(function (resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function (resp) {
            curItemDoc = resp;
            recentItemId = curItemDoc.item_id
            console.log('Item created ==' + curItemDoc.item_id);
        }).catch(function (err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        });
    });

    it('add Item to Cart', function () {
        // curSession = profitGuruFaker.getFakerSession();
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);

        function testAddItem(id) {
            return salesController.addItemById({
                item_id: recentItemId
            }).then(function (resp) {
                curResponse = resp;
                // if (recentItemId === resp.cart[4].item_id) {
                expect(resp.cart).to.equal(undefined);
                // }
                console.log('Item Added to cart ==' + resp.cart);
                console.log('Item Added to cart ==' + resp.err);
            });
        }
        testAddItem();
    });
});