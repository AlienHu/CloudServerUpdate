   'use strict';
   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");

   var commonTestUtils = require('../../common/commonUtils.js');
   var faker = require('faker');

   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;

   const couchDbManager = require('../../../dbManagers/couchDbManager');
   var BPromise = require('bluebird');
   var profitGuruFaker = require('../../common/profitGuruFaker.js');
   var curSession = profitGuruFaker.getFakerSession();

   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   var mainDBInstance = couchDBUtils.getMainCouchDB();
   const commonLib = require('../../../controllers/libraries/commonLib');

   var applicationSettings = {};

   describe('Sales Credit Test UTS', function() {

       this.timeout(500000);
       var customersTransactions;
       var customersArray = [];
       var maxSaleCreditId = 0;

       /**
        * Prerequisite: run sales-test.js complete sale with partial credit
        */
       before(function() {
           return couchDbManager.initCouchDb(false).then(function(resp) {
               applicationSettings = resp.applicationSettings;
               return commonTestUtils.getAllPendingTransactionsAndMaxCreditId('sale');
           }).then(function(resp) {
               customersTransactions = resp[0];
               maxSaleCreditId = resp[1];
               var bUseful = false;
               for (var id in customersTransactions) {
                   expect(customersTransactions[id].pendingTransactions.length).to.greaterThan(0);
                   customersArray.push(id);
                   bUseful = true;
               }
               expect(bUseful).to.equal(true);
               expect(customersArray.length).to.greaterThan(0);
           });

       });

       /**
        * CreditsTodo: Change all the reports and filter by type
        */

       after(function() {});

       function cleanUpCustomerTransactions() {
           for (id in customersTransactions) {
               if (customersTransactions[id].pending_amount <= 0) {
                   delete customersTransactions[id];
               }
           }
           customersArray = Object.keys(customersTransactions);
       }

       async function validate(params) {
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);

           var parentIds = [];
           var totalPaid = 0;
           var excessPayment = 0;

           let customerDocId = 'customer_' + params.customerId;
           let prevCustomerDoc = await couchDBUtils.getDoc(customerDocId, mainDBInstance);
           let resp = await salesController.makeCustomerCreditPayment(params);
           maxSaleCreditId = maxSaleCreditId + 1;
           resp = await couchDBUtils.getDoc(commonLib.formatSaleCreditId(maxSaleCreditId), mainDBInstance);

           expect(resp).to.not.equal(null);
           expect(resp.sales_info.customer_id).to.equal(params.customerId);
           var paymentTypeArray = Object.keys(params.paymentsView);
           expect(resp.payments.length).to.equal(paymentTypeArray.length);
           for (var i = 0; i < paymentTypeArray.length; i++) {
               expect(resp.payments[i].payment_type).to.equal(params.paymentsView[i].payment_type);
           }
           expect(resp.parentIds.length).to.greaterThan(0);

           excessPayment = resp.sales_info.pending_amount * -1;

           for (var i = 0; i < resp.payments.length; i++) {
               var paymentInfo = resp.payments[i];
               var paymentAmount = paymentInfo.payment_amount;
               totalPaid += paymentAmount;
               for (var j = 0; j < params.paymentsView.length; j++) {
                   if (params.paymentsView[j].payment_type === paymentInfo.payment_type) {
                       expect(params.paymentsView[j].payment_amount).to.equal(paymentAmount);
                   }

               }

           }

           parentIds = resp.parentIds;

           await commonTestUtils.pgTimeOut(10000);

           let curCustomerDoc = await couchDBUtils.getDoc(customerDocId, mainDBInstance);
           expect(prevCustomerDoc.credit_balance - curCustomerDoc.credit_balance - totalPaid).within(-0.001, 0.001);
           let newSalesDocs = await couchDBUtils.getAllDocs(parentIds.map(function(id) {
               return commonLib.formatSaleId(id);
           }), mainDBInstance);

           expect(parentIds.length).to.equal(newSalesDocs.length);
           var parentInfo = {};

           for (var i = 0; i < params.pendingTransactions.length; i++) {
               var index = parentIds.indexOf(params.pendingTransactions[i].sale_id);
               if (index >= 0) {
                   parentInfo[parentIds[index]] = {
                       oldDoc: params.pendingTransactions[i],
                       newDoc: commonLib.transformSaleDoc(newSalesDocs[index].doc, 'sale')
                   };
               }
           }

           var total = 0;
           for (id in parentInfo) {
               var oldDoc = parentInfo[id].oldDoc;
               var newDoc = parentInfo[id].newDoc;
               var paidAmount = oldDoc.sales_info.pending_amount - newDoc.sales_info.pending_amount;
               total += paidAmount;
               var newPaymentsLength = newDoc.payments.length;
               expect(newPaymentsLength).to.equal(oldDoc.payments.length + 1);
               newDoc.payments[newPaymentsLength - 1].payment_amount = paidAmount;
               newDoc.payments[newPaymentsLength - 1].payment_sale_id = maxSaleCreditId;
           }

           expect(Math.abs(total + excessPayment - totalPaid)).to.lessThan(0.00001);

           //Updating the data
           for (var i = 0; i < params.pendingTransactions.length; i++) {
               var index = parentIds.indexOf(params.pendingTransactions[i].sales_info.sale_id);
               if (index >= 0) {
                   params.pendingTransactions[i] = newSalesDocs[index].doc;
               }
           }

           customersTransactions[params.customerId].pending_amount -= totalPaid;
           cleanUpCustomerTransactions();

       }

       it('make less payment', function() {

           var selectedCustomerId = faker.random.arrayElement(customersArray);
           var selectedCustomerHistory = customersTransactions[selectedCustomerId];
           var params = {
               customerId: selectedCustomerId,
               paymentsView: [{
                   payment_type: "Cash",
                   payment_amount: selectedCustomerHistory.pending_amount * 0.3,
                   ref_no: ""
               }, {
                   payment_type: "Cheque",
                   payment_amount: selectedCustomerHistory.pending_amount * 0.2,
                   ref_no: "00000"
               }],

               pendingTransactions: selectedCustomerHistory.pendingTransactions,
               comment: 'hello world',
               employeeId: 'admin'
           };

           return validate(params);

       });

       it('make exact payment', function() {

           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           var selectedCustomerId = faker.random.arrayElement(customersArray);
           var selectedCustomerHistory = customersTransactions[selectedCustomerId];
           var params = {
               customerId: selectedCustomerId,
               paymentsView: [{
                   payment_type: "Cash",
                   payment_amount: selectedCustomerHistory.pending_amount * 0.7,
                   ref_no: ""
               }, {
                   payment_type: "Cheque",
                   payment_amount: selectedCustomerHistory.pending_amount * 0.3,
                   ref_no: "00000"
               }],
               pendingTransactions: selectedCustomerHistory.pendingTransactions,
               comment: 'hello world',
               employeeId: 'admin'
           };

           return validate(params);
       });

       it('make more payment', function() {

           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           var selectedCustomerId = faker.random.arrayElement(customersArray);
           var selectedCustomerHistory = customersTransactions[selectedCustomerId];
           var params = {
               customerId: selectedCustomerId,
               paymentsView: [{
                   payment_type: "Cash",
                   payment_amount: selectedCustomerHistory.pending_amount * 1.3,
                   ref_no: ""
               }, {
                   payment_type: "Cheque",
                   payment_amount: selectedCustomerHistory.pending_amount * 0.2,
                   ref_no: "00000"
               }],
               pendingTransactions: selectedCustomerHistory.pendingTransactions,
               comment: 'hello world',
               employeeId: 'admin'
           };

           return validate(params);
       });

       it('payment type is 1', function() {

           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           var selectedCustomerId = faker.random.arrayElement(customersArray);
           var selectedCustomerHistory = customersTransactions[selectedCustomerId];
           var params = {
               customerId: selectedCustomerId,
               paymentsView: [{
                   payment_type: "Cash",
                   payment_amount: selectedCustomerHistory.pending_amount * 0.3,
                   ref_no: ""
               }],
               pendingTransactions: selectedCustomerHistory.pendingTransactions,
               comment: 'hello world',
               employeeId: 'admin'
           };

           return validate(params);
       });

   });