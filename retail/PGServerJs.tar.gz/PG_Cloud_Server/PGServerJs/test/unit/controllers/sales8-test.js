'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const faker = require('faker');
const profitGuruFaker = require('../../common/profitGuruFaker.js');
const logger = require('../../../common/Logger');
const utils = require('../../common/Utils.js');
const commonUtils = require('../../common/commonUtils');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
let salesController;
let itemsLib;
let commonLib;
let appSettingsHandler;
const computeUtils = require('../../../controllers/common/computeUtils');
let salesTestHelper;
const contrUtils = require('../../../controllers/common/Utils');
const CLONE = contrUtils.clone;

describe('Sales Controller 8 Sale Edit UTS', function() {

    this.timeout(500000);
    this.slow(0);

    let prevItems;
    let pProfiles;
    let curItems;
    /*
     * {
     *     0:{
     *          stock: {
     *              0: {
     *                  uniqueItemIndex: [0, 1],
     *                  quantity: 2
     *              },
     *              1: {
     *                  uniqueItemIndex: [0],
     *                  quantity: 1
     *              }
     *          },
     *          quantity: 4
     *     } 
     * }
     */
    let cart = {};
    let customerArray;
    let prevResponse;
    let prevSaleId;
    let timeStamp;
    let prevCustomer = [];
    let prevTotal = 0;
    let bSaleEdit = false;

    let globalDiscountParam = {
        value: 0,
        bPercent: false,
        itemCount: 1111,
        discountMethod: 'onTaxable'
    };

    const curSession = profitGuruFaker.getFakerSession();
    let applicationSettings;
    let salesConfig;

    before(async function() {
        let logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);

        let bResetDB = true;
        let resp = await couchDbManager.initCouchDb(bResetDB);
        applicationSettings = resp.applicationSettings;
        salesConfig = applicationSettings.salesConfig;

        prevItems = await commonUtils.createAllItemTypes(true, true);
        pProfiles = await commonUtils.getAllPProfiles();
        customerArray = await commonUtils.getPeople(2, 'customer');
        salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        itemsLib = require('../../../controllers/libraries/itemsControllerLib');
        salesTestHelper = require('./testHelpers/salesTestHelper.js');
        commonLib = require('../../../controllers/libraries/commonLib');
        appSettingsHandler = require('../../../couchDb/applicationSettingsCouchHandler')();
        salesTestHelper.set(itemsLib, commonLib, salesController.getSaleLib(), computeUtils, curSession, applicationSettings);
    });

    after(function() {});

    function getCartItemFactor(response, itemIndex, stockIndex) {
        let factor = 1;
        let cartItem = getCartItem(response, itemIndex, stockIndex);
        if (cartItem) {
            factor = commonLib.getFactor(cartItem.unitsInfo, cartItem.unitId, cartItem.baseUnitId);
        }

        return factor;
    }

    function getCartItem(response, itemIndex, stockIndex) {
        let index = -1;
        for (let i = 0; i < response.cart.length; i++) {
            let cartItem = response.cart[i];
            if (cartItem.item_id === prevItems[itemIndex].item_id && cartItem.stockKey === prevItems[itemIndex].batches[stockIndex].stockKey) {
                index = i;
                //There may be more than 1 which matches the above input .. because unique details we are adding separately
                //returning the last matched index
                //  break;
            }
        }

        if (index === -1) {
            return;
        }

        return response.cart[index];
    }

    async function opItem(itemIndex, stockIndex, uniqueIndex, type, curResponse) {

        if (!cart[itemIndex]) {
            cart[itemIndex] = {
                stock: {}
            };
        }

        if (!cart[itemIndex].stock[stockIndex]) {
            cart[itemIndex].stock[stockIndex] = {
                quantity: 0,
                uniqueIndexes: [],
                returnedUniqueIndexes: [],
                factor: 1
            }
        }

        if (type === undefined) {
            type = 1;
        }

        let stockKey = prevItems[itemIndex].batches[stockIndex].stockKey;
        let uniqueDetails = prevItems[itemIndex].inventory.stock[stockKey].uniqueDetails;
        let uniqueDetailsKeys = Object.keys(uniqueDetails);

        if (type === 1) {
            let params = {
                item: prevItems[itemIndex].item_id,
                stockKey: stockKey
            };

            if (uniqueDetailsKeys.length) {
                params.uniqueDetails = uniqueDetails[uniqueDetailsKeys[uniqueIndex]].info;
            }
            curResponse = await salesController.additemRestApi(params);
        } else if (type === 2) {
            let params = {
                item: prevItems[itemIndex].item_id,
                stockKey: stockKey
            };

            curResponse = await salesController.removeItem(params);
        } else if (type == 3) {
            let cartItem = getCartItem(curResponse, itemIndex, stockIndex);
            expect(!cartItem).to.equal(false);
            let params = {
                item: cartItem.line
            }
            curResponse = await salesController.delteItemFromCart(params);
            cart[itemIndex].stock[stockIndex].quantity--;
            let detail = cart[itemIndex].stock[stockIndex].uniqueIndexes.pop();
            if (bSaleEdit && detail !== undefined) {
                cart[itemIndex].stock[stockIndex].returnedUniqueIndexes.push(detail);
            }
        }

        await salesTestHelper.compareOverAllResponse(curResponse, globalDiscountParam, false);

        let factor = getCartItemFactor(curResponse, itemIndex, stockIndex);

        if (type === 1) {
            cart[itemIndex].stock[stockIndex].quantity++;
            cart[itemIndex].stock[stockIndex].factor = factor;
            if (uniqueIndex !== undefined) {
                cart[itemIndex].stock[stockIndex].uniqueIndexes.push(uniqueIndex);
            }
        } else if (type === 2) {
            cart[itemIndex].stock[stockIndex].quantity--;
            let detail = cart[itemIndex].stock[stockIndex].uniqueIndexes.pop();
            if (bSaleEdit && detail !== undefined) {
                cart[itemIndex].stock[stockIndex].returnedUniqueIndexes.push(detail);
            }
            cart[itemIndex].stock[stockIndex].factor = factor;
        }

        return curResponse;
    }

    async function validateStock() {
        curItems = await commonUtils.createAllItemTypes();

        let itemIndexes = Object.keys(cart);
        for (let itemIndex in cart) {
            checkInventoryDoc(parseInt(itemIndex));
        }

        //  prevItems = curItems;
    }

    function checkInventoryDoc(itemIndex) {
        let quantity = 0;
        for (let stockIndex in cart[itemIndex].stock) {
            quantity += checkStockByKey(itemIndex, parseInt(stockIndex));
        }
        expect(prevItems[itemIndex].inventory.quantity - curItems[itemIndex].inventory.quantity).to.equal(quantity);
    }

    function checkStockByKey(itemIndex, stockIndex) {
        let stockKey = prevItems[itemIndex].batches[stockIndex].stockKey;
        let quantity = cart[itemIndex].stock[stockIndex].quantity * cart[itemIndex].stock[stockIndex].factor;
        expect(prevItems[itemIndex].inventory.stock[stockKey].quantity - curItems[itemIndex].inventory.stock[stockKey].quantity).to.equal(quantity);
        let uniqueIndexes = cart[itemIndex].stock[stockIndex].uniqueIndexes;
        let uniqueDetails = curItems[itemIndex].inventory.stock[stockKey].uniqueDetails;
        let uniqueDetailsKeys = Object.keys(uniqueDetails);
        for (let i = 0; i < uniqueIndexes.length; i++) {
            expect(uniqueDetails[uniqueDetailsKeys[uniqueIndexes[i]]].sold).to.equal(true);
        }
        uniqueIndexes = cart[itemIndex].stock[stockIndex].returnedUniqueIndexes;
        for (let i = 0; i < uniqueIndexes.length; i++) {
            expect(uniqueDetails[uniqueDetailsKeys[uniqueIndexes[i]]].sold).to.equal(false);
        }

        let transKey = itemsLib.formatInvTransKey(timeStamp, stockKey);

        if (quantity) {
            expect(curItems[itemIndex].inventory.transactions[transKey].trans_inventory).to.equal(-1 * quantity);
        }

        return quantity;
    }

    async function updatePProfileHelper(index) {
        applicationSettings.salesConfig.pProfileId = pProfiles[index].id;
        await appSettingsHandler.updateApplicationSettings({
            body: applicationSettings,
            app: {
                locals: {}
            }
        }, process.env.APP_TYPE);
        salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        salesTestHelper.set(itemsLib, commonLib, salesController.getSaleLib(), computeUtils, curSession, applicationSettings);
    }

    async function updatePProfile(index) {
        await updatePProfileHelper(index);
        let resp = await salesController.getSales();

        await salesTestHelper.compareOverAllResponse(resp, globalDiscountParam, false);
        return resp;
    }

    async function changeProfile() {
        for (let i = 0; i < pProfiles.length; i++) {
            if (pProfiles[i].id !== applicationSettings.salesConfig.pProfileId) {
                await updatePProfileHelper(i)
                break;
            }
        }
    }

    async function updateUnit(curResponse, unitIndex, itemIndex, stockIndex) {
        let cartItem = getCartItem(curResponse, itemIndex, stockIndex);

        let unitsArray = Object.keys(prevItems[1].batches[0].unitsInfo);
        curResponse = await salesController.updateUnit({
            line: cartItem.line,
            unitId: unitsArray[unitIndex]
        });

        for (let i = 0; i < curResponse.cart.length; i++) {
            if (curResponse.cart[i].line !== cartItem.line) {
                continue;
            }
            expect(curResponse.cart[i].price).to.equal(prevItems[itemIndex].batches[stockIndex].unitsInfo[unitsArray[unitIndex]].pProfilesData[salesConfig.pProfileId].sellingPrice);
            break;
        }

        await salesTestHelper.compareOverAllResponse(curResponse, globalDiscountParam, false);
        return curResponse;
    }

    it('util test', async function() {
        let saleLib = salesController.getSaleLib();
        let pProfilesData = {
            1: {
                sellingPrice: 100,
                discountId: 12334
            },
            2: {
                sellingPrice: 200,
                discountId: 4321
            }
        }
        let curPProfile = {
            id: 1
        };
        let data = await saleLib.getPProfileData(pProfilesData, curPProfile);

        expect(utils.compareObject(pProfilesData["1"], data)).to.equal(true);
        expect(utils.compareObject(pProfilesData["2"], data)).to.equal(false);
        curPProfile = {
            id: 2
        };
        data = await saleLib.getPProfileData(pProfilesData, curPProfile)
        expect(utils.compareObject(pProfilesData["1"], data)).to.equal(false);
        expect(utils.compareObject(pProfilesData["2"], data)).to.equal(true);

        curPProfile = {
            id: 3
        };
        data = await saleLib.getPProfileData(pProfilesData, curPProfile)
        expect(utils.compareObject(pProfilesData["1"], data)).to.equal(true);
        expect(utils.compareObject(pProfilesData["2"], data)).to.equal(false);

        curPProfile = {
            id: 4,
            delta: 20,
            refId: "1"
        };
        data = await saleLib.getPProfileData(pProfilesData, curPProfile)
        expect(utils.compareObject(pProfilesData["1"], data)).to.equal(false);
        expect(utils.compareObject(pProfilesData["2"], data)).to.equal(false);
        expect(utils.compareObject({
            sellingPrice: 120,
            discountId: 12334
        }, data)).to.equal(true);

        curPProfile = {
            id: 5,
            deltaPercent: -40,
            refId: "2"
        };
        data = await saleLib.getPProfileData(pProfilesData, curPProfile)
        expect(utils.compareObject(pProfilesData["1"], data)).to.equal(false);
        expect(utils.compareObject(pProfilesData["2"], data)).to.equal(false);
        expect(utils.compareObject({
            sellingPrice: 120,
            discountId: 4321
        }, data)).to.equal(true);

        let unitsArray = Object.keys(prevItems[1].unitsInfo);
        let unitId = unitsArray[0];
        pProfilesData = prevItems[1].unitsInfo[unitId].pProfilesData;
        data = await saleLib.getPProfileData(pProfilesData, pProfiles[0]);
        expect(utils.compareObject(pProfilesData[pProfiles[0].id], data)).to.equal(true);
        data = await saleLib.getPProfileData(pProfilesData, pProfiles[1]);
        expect(utils.compareObject(pProfilesData[pProfiles[1].id], data)).to.equal(true);
        let data2 = await saleLib.getPProfileData(pProfilesData, pProfiles[2]);
        expect(utils.compareObject(pProfilesData[pProfiles[2].id], data2)).to.equal(true);

        async function compareRelativePProfileCalc(index, prevData) {
            prevData = CLONE(prevData);
            let pProfile = pProfiles[index];
            let curData = await saleLib.getPProfileData(pProfilesData, pProfile);

            if (pProfile.delta) {
                prevData.sellingPrice += pProfile.delta;
            } else if (pProfile.deltaPercent) {
                prevData.sellingPrice *= (1 + pProfile.deltaPercent * 0.01);
            }
            expect(utils.compareObject(prevData, curData)).to.equal(true);

            return curData;
        }
        let data3 = await compareRelativePProfileCalc(3, data2);
        let data4 = await compareRelativePProfileCalc(4, data3);
        let data5 = await compareRelativePProfileCalc(5, data4);
        let data6 = await compareRelativePProfileCalc(6, data5);
    });

    async function doTest(itemIndex, stockIndex, curResponse) {

        let cartItem = CLONE(getCartItem(curResponse, itemIndex, stockIndex));
        cartItem.price = 1000 + (cartItem.price / 2);
        cartItem.quantity += 5;
        cart[itemIndex].stock[stockIndex].quantity = cartItem.quantity; //factor didn't change

        cart[itemIndex].stock[stockIndex].factor = getCartItemFactor(curResponse, itemIndex, stockIndex);

        curResponse = await salesController.editItemRestApi(cartItem);
        await salesTestHelper.compareOverAllResponse(curResponse, globalDiscountParam, false);

        let unitIndex = 1;
        let profileIndex = 2;
        if (bSaleEdit) {
            unitIndex = 2;
            profileIndex = 1;
        }
        for (let i = 0; i < 3; i++) {
            curResponse = await updateUnit(curResponse, unitIndex, itemIndex, stockIndex);
            for (let j = 0; j < 2; j++) {
                curResponse = await updatePProfile(profileIndex);
                profileIndex--;
                if (profileIndex === -1) {
                    profileIndex = 2;
                }
            }
            unitIndex++;
            if (unitIndex === 3) {
                unitIndex = 0;
            }
        }

        cart[itemIndex].stock[stockIndex].factor = getCartItemFactor(curResponse, itemIndex, stockIndex);
        return curResponse;
    }

    //inv transaction check missing
    it('make sale', async function() {
        await opItem(1, 0);
        await opItem(1, 0);
        await opItem(0, 0, 0);
        await opItem(0, 1, 0);
        await opItem(0, 1, 1);
        await opItem(0, 2, 0);
        await opItem(2, 0);
        await opItem(2, 1);
        await opItem(2, 1);
        let curResponse = await opItem(2, 2);
        expect(curResponse.cart.length).to.equal(8);
        curResponse = await doTest(1, 0, curResponse);
        curResponse = await doTest(2, 0, curResponse);
        curResponse = await doTest(2, 1, curResponse);
        curResponse = await doTest(2, 2, curResponse);
        let cartItem = CLONE(curResponse.cart[1]);
        cartItem.price = 10000;
        await salesController.editItemRestApi(cartItem);
        cartItem = CLONE(curResponse.cart[2]);
        cartItem.price = 10;
        await salesController.editItemRestApi(cartItem);
        cartItem = CLONE(curResponse.cart[3]);
        cartItem.priceprice = 100;
        curResponse = await salesController.editItemRestApi(cartItem);
        await salesTestHelper.compareOverAllResponse(curResponse, globalDiscountParam, false);

        let paymentParams = {
            payment_type: "Cash",
            amount_tendered: curResponse.amount_due / 2
        };

        curResponse = await salesController.add_paymentRestApi(paymentParams);

        let param = {
            customer_id: customerArray[0]
        };
        curResponse = await salesController.addCustomer2Sale(param);

        paymentParams = {
            payment_type: "Debit Card",
            amount_tendered: curResponse.amount_due
        };

        curResponse = await salesController.add_paymentRestApi(paymentParams);

        prevResponse = curResponse;
        prevCustomer.push(await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance));
        prevCustomer.push(await couchDBUtils.getDoc('customer_' + customerArray[1], mainDBInstance));

        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });
        // const jsonFile = require('jsonfile');
        // jsonFile.writeFileSync('saleReceiptOld.json', resp);
        await salesTestHelper.compareOverAllResponse(resp, globalDiscountParam, true);
        prevSaleId = resp.id;

        await commonUtils.pgTimeOut(2000);

        let saleDoc = await couchDBUtils.getDoc('sale_' + prevSaleId, mainDBInstance);
        // jsonFile.writeFileSync('saleDocOld.json', saleDoc);
        timeStamp = saleDoc.sales_info.sale_time;
        await validateStock();

        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        expect(custDoc.total - prevCustomer[0].total - resp.total).within(-0.001, 0.001);
        prevCustomer[0] = custDoc;

        await changeProfile();
    });

    async function initSaleEdit() {
        let curResponse = await salesController.initEditSalesSession({
            saleId: 'sale_' + prevSaleId
        });
        var errArray = [];
        var compResult = utils.compareObject(prevResponse, curResponse, 0, ['email_receipt', 'bGDiscountPercent', 'slab', 'origTaxes', 'comment', 'line', 'sale_time', 'returnAmt'], errArray);
        console.log(errArray);
        expect(compResult).to.equal(true);
    }

    it('initSaleEdit', async function() {
        await initSaleEdit();
    });

    let bFlip = false;
    async function makeSaleEdit() {
        cart[0].stock[0].returnedUniqueIndexes = [];
        cart[0].stock[1].returnedUniqueIndexes = [];
        bSaleEdit = true;
        let curResponse;
        if (!bFlip) {
            curResponse = await opItem(0, 1, 2);
            curResponse = await opItem(0, 0, undefined, 3, curResponse);
        } else {
            curResponse = await opItem(0, 0, 0);
            curResponse = await opItem(0, 1, undefined, 3, curResponse);
        }
        bFlip = !bFlip;

        curResponse = await opItem(1, 0, undefined, 2);
        curResponse.cart[2].price = 99;
        curResponse = await salesController.editItemRestApi(curResponse.cart[2]);
        await salesTestHelper.compareOverAllResponse(curResponse, globalDiscountParam, false);

        expect(curResponse.cart.length).to.equal(8);

        curResponse = await doTest(1, 0, curResponse);
        curResponse = await doTest(2, 0, curResponse);
        curResponse = await doTest(2, 1, curResponse);
        curResponse = await doTest(2, 2, curResponse);

        let param = {
            customer_id: customerArray[1]
        };
        curResponse = await salesController.addCustomer2Sale(param);

        curResponse = await salesController.deletePayment({
            payment_id: "Debit Card"
        });
        curResponse = await salesController.deletePayment({
            payment_id: "Cash"
        });
        if (curResponse.payments.length) {
            curResponse = await salesController.deletePayment({
                payment_id: "Sale on credit"
            });
        }

        let paymentParams = {
            payment_type: "Cash",
            amount_tendered: curResponse.amount_due / 2
        };
        curResponse = await salesController.add_paymentRestApi(paymentParams);

        paymentParams = {
            payment_type: "Sale on credit",
            amount_tendered: curResponse.amount_due
        };
        curResponse = await salesController.add_paymentRestApi(paymentParams);
        prevResponse = curResponse;

        let commonWorker = require('../../../controllers/workers/commonWorker');
        // commonWorker.setFreeze(true);
        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world',
            saleIdToEdit: 'sale_' + prevSaleId,
            timeStamp: curResponse.sale_time
        });

        await commonUtils.pgTimeOut(2000);

        let saleDoc = await couchDBUtils.getDoc('sale_' + prevSaleId, mainDBInstance);
        timeStamp = saleDoc.sales_info.sale_time;
        await validateStock();

        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        expect(custDoc.total - prevCustomer[0].total + prevTotal).within(-0.001, 0.001);
        custDoc = await couchDBUtils.getDoc('customer_' + customerArray[1], mainDBInstance);
        expect(custDoc.total - prevCustomer[1].total - resp.total).within(-0.001, 0.001);
        expect(custDoc.credit_balance - prevCustomer[1].credit_balance - paymentParams.amount_tendered).within(-0.001, 0.001);
        await changeProfile();
    }

    it('edit sale', async function() {
        await makeSaleEdit();
    });

    async function changeItemDataAndTestEdit(changeItemsData, failStep) {
        let itemDocs = await couchDBUtils.getAllDocsByType('item', mainDBInstance, undefined, true);
        let prevItemDocs = [];
        for (let i = 0; i < itemDocs.length; i++) {
            delete itemDocs[i]._rev;
            prevItemDocs.push(CLONE(itemDocs[i]));
        }

        changeItemsData(itemDocs);
        for (let i = 0; i < itemDocs.length; i++) {
            if (itemDocs[i].bChanged) {
                await couchDBUtils.update(itemDocs[i], mainDBInstance);
            }
        }
        let _error = "";
        let curStep = 0;
        try {
            curStep = 1;
            await initSaleEdit();
            curStep = 2;
            await makeSaleEdit();
        } catch (error) {
            _error = error;
        } finally {
            for (let i = 0; i < itemDocs.length; i++) {
                //for purchase this doesn't work..because doing purchase will update item doc also.. so write a reverse changefun also
                await couchDBUtils.update(prevItemDocs[i], mainDBInstance);
            }
        }

        expect(_error !== "").to.equal(failStep > 0);
        if (failStep) {
            expect(curStep).to.equal(failStep);
        }
    }

    it('make sure info.unitsInfo is not used ', async function() {
        await changeItemDataAndTestEdit(function(itemDocs) {
            itemDocs[1].bChanged = true;
            delete itemDocs[1].info.unitsInfo;
            for (let i = 1; i < 3; i++) {
                for (let stockKey in itemDocs[i].batches) {
                    for (let unitId in itemDocs[i].info.unitsInfo) {
                        let unitInfo = itemDocs[i].batches[stockKey].unitsInfo[unitId];
                        if (unitInfo.factor !== 1) {
                            unitInfo.factor *= 2;
                        }
                        for (let pProfileId in unitInfo.pProfilesData) {
                            unitInfo.pProfilesData[pProfileId].sellingPrice *= 1.1;
                        }
                    }
                }
            }
        }, 0);
    });

    it('sale edit fails if baseUnitId doesnt match', async function() {
        await changeItemDataAndTestEdit(function(itemDocs) {
            itemDocs[1].bChanged = true;
            for (let key in itemDocs[1].info.unitsInfo) {
                if (key !== itemDocs[1].info.baseUnitId) {
                    itemDocs[1].info.baseUnitId = key;
                    break;
                }
            }
        }, 1);
        await changeItemDataAndTestEdit(function(itemDocs) {
            itemDocs[2].bChanged = true;
            for (let key in itemDocs[2].info.unitsInfo) {
                if (key !== itemDocs[2].info.baseUnitId) {
                    itemDocs[2].info.baseUnitId = key;
                    break;
                }
            }
        }, 1);
    });

    //todomultipleunits make sure.. we check false of uniquedetails in case of edit
    //todomultipleunits make sure.. edit .. we don't have extra entry.. sale_time and all
    //todomultipleunits slab example.. have price so that it is in second slab and give discount so that it comes into the lower slab
    //todomultipleunits slab we are just saving direct slab.. what about slab inside profiles
});