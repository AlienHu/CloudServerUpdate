   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;

   var faker = require('faker');

   describe('Bonjour Tests', function() {
       this.timeout(200000);

       before(function() {

       });

       it('emit service', function(done) {

           process.env.PROFITGURU_SERVER_PORT = faker.random.number({
               min: 1000,
               max: 9999
           });
           var locationName = faker.name.firstName();
           console.log(locationName);
           console.log(process.env.PROFITGURU_SERVER_PORT);

           var bonjourService = require('../../../common/bonjourServer.js');
           bonjourService.setLocationNameAndStartBonjourServer(locationName);

           var profitGuruStatusEvents = require('../../../common/profitGuruStatusEvents.js');
           profitGuruStatusEvents.emit('ServerUUID_Available', faker.internet.mac());
           setTimeout(function() {
               bonjourService.stopBonjourServiceInstance().then(() => {
                   done();
               }).catch((error) => {
                   console.log(error);
                   done();
               });
           }, 5000)

       });

       //    it('list all tables', function() {
       //        return knex.raw("SELECT name FROM sqlite_master WHERE type='table';").then(function(resp) {
       //            console.log(resp);
       //        }).catch(function(err) {
       //            console.log(err);
       //        });
       //    });

   });