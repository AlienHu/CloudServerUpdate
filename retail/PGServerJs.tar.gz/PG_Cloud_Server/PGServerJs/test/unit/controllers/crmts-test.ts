import { load } from 'dotenv-safe';
load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

import * as chai from 'chai';
const expect = chai.expect;

import * as testUtils from '../../common/Utils';
import compareObject = testUtils.compareObject;
import compareArray = testUtils.compareArray;
import { ScheduledCampaign, ScheduleStatus, Wisher, CmpCustomers } from '../../../controllers/crm';
import { generateSchedules } from '../../../controllers/libraries/scheduleCampaignHelper';
import { processWisher4UT, getBdayCustomers4UT } from '../../../controllers/libraries/scheduler';

import * as moment from 'moment';
import Moment = moment.Moment;

describe('XXXX UT', function () {
    this.timeout(100000);

    before(function () {

    });

    it('xxxxxxxxxx', () => {
        let refObj = { a: 1, b: 2, c: 5 };
        let insObj = { a: 2, b: 1 };

        let errorsArray: string[] = [];
        let bSame: boolean = compareObject(refObj, insObj, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(false);
    })

    it('XXXXXX', function () {

        let refArr = [1, 2, 3];
        let insArr = [1, 2, 3];

        let errorsArray: string[] = [];
        let bSame: boolean = compareArray(refArr, insArr, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });

    it('testing generateSchedules4UT', () => {
        let startTime: Moment = moment('2018-03-19');
        let data: ScheduledCampaign = {
            "message": "linto hello",
            "customers": [
                {
                    "_id": "customer_1521046268402",
                    "status": "pending"
                }
            ],
            "dayOfWeekArr": [
                0, 1, 2, 3, 4, 5, 6
            ],
            "timeOfDayArr": [
                "1970-01-01T20:00:00.000Z"
            ],
            "startDate": "2018-03-19T10:25:45.225Z",
            "endDate": "2018-03-25T18:30:00.000Z",
            "status": "pending"
        } as ScheduledCampaign;
        generateSchedules(data);
        console.log(data);
        expect(data.scheduleStatusArr.length).to.equal(7);
        let firstTime: Moment = moment(data.startDate).startOf('day');
        let dayNumber: number = 0;
        data.scheduleStatusArr.forEach(function (sch: ScheduleStatus) {
            data.timeOfDayArr.forEach(function (time) {
                let schTime = new Date(time);
                let hours: number = schTime.getHours();
                let minutes: number = schTime.getMinutes();
                let ts: string = moment(firstTime).startOf('day').add(dayNumber, 'day').add(hours, 'h').add(minutes, 'm').format('x');
                expect(sch.timestamp).to.equal(ts);
            });
            dayNumber += 1;
        })

    });
    it('testing processWisher4UT', () => {
        let startTime: Moment = moment('2018-03-19');
        let data: Wisher = {
            "message": "linto hello",
            "customers": [
                {
                    "_id": "customer_1521046268402",
                    "status": "pending"
                }
            ],
            "dayOfWeekArr": [
                0, 1, 2, 3, 4, 5, 6
            ],
            "timeOfDayArr": [
                "1970-01-01T20:00:00.000Z"
            ],
            daysBefore: 20,
            type: 'birth_day',
            "status": "pending"
        } as Wisher;
        processWisher4UT();
    });
    it.only('testing getBdayCustomers4UT', async () => {
        let start: string = moment().startOf('day').toISOString();
        let end: string = moment().add(4, 'days').endOf('day').toISOString();
        let type: string = 'birth_day';

        let customers: CmpCustomers[] = await getBdayCustomers4UT(type, start, end);
        expect(customers.length).to.equal(0);
    });

});
