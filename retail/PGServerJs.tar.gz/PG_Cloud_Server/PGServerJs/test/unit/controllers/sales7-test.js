'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const faker = require('faker');
const profitGuruFaker = require('../../common/profitGuruFaker.js');
const logger = require('../../../common/Logger');
const utils = require('../../common/Utils.js');
const commonUtils = require('../../common/commonUtils');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
let salesController;
const contrUtils = require('../../../controllers/common/Utils');
const CLONE = contrUtils.clone;

describe('Sales Controller 7 Sale Edit UTS', function() {

    this.timeout(500000);
    this.slow(0);

    let allItems;
    let customerArray;
    let prevResponse;
    let prevSaleId;
    let prevInv = [];
    let prevCustomer = [];
    let prevTotal = 0;

    const curSession = profitGuruFaker.getFakerSession();
    let applicationSettings;

    before(async function() {
        let logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);

        let bResetDB = true;
        let resp = await couchDbManager.initCouchDb(bResetDB);
        applicationSettings = resp.applicationSettings;

        allItems = await commonUtils.createAllItemTypes();
        customerArray = await commonUtils.getPeople(2, 'customer');
        salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
    });

    after(function() {});

    async function addUniqueItem(index, uniqueIndex) {
        let stockKey = allItems[0].batches[index].stockKey;
        let uniqueDetails = allItems[0].inventory.stock[stockKey].uniqueDetails;
        let uniqueDetailsKeys = Object.keys(uniqueDetails);
        let curResponse = await salesController.additemRestApi({
            item: allItems[0].item_id,
            stockKey: stockKey,
            uniqueDetails: uniqueDetails[uniqueDetailsKeys[uniqueIndex]].info
        });

        return curResponse;
    }

    //inv transaction check missing
    it('make sale', async function() {
        let curResponse = await salesController.additemRestApi({
            item: allItems[1].item_id,
            stockKey: allItems[1].batches[0].stockKey
        });
        curResponse = await salesController.additemRestApi({
            item: allItems[1].item_id,
            stockKey: allItems[1].batches[0].stockKey
        });

        curResponse = await addUniqueItem(0, 0);
        curResponse = await addUniqueItem(1, 0);
        curResponse = await addUniqueItem(1, 1);
        curResponse = await addUniqueItem(2, 0);

        let cartItem = CLONE(curResponse.cart[0]);
        cartItem.price = 1000;
        await salesController.editItemRestApi(cartItem);
        cartItem = CLONE(curResponse.cart[1]);
        cartItem.price = 10000;
        await salesController.editItemRestApi(cartItem);
        cartItem = CLONE(curResponse.cart[2]);
        cartItem.price = 10;
        await salesController.editItemRestApi(cartItem);
        cartItem = CLONE(curResponse.cart[3]);
        cartItem.priceprice = 100;
        curResponse = await salesController.editItemRestApi(cartItem);

        let paymentParams = {
            payment_type: "Cash",
            amount_tendered: curResponse.amount_due / 2
        };

        curResponse = await salesController.add_paymentRestApi(paymentParams);

        let param = {
            customer_id: customerArray[0]
        };
        curResponse = await salesController.addCustomer2Sale(param);

        paymentParams = {
            payment_type: "Debit Card",
            amount_tendered: curResponse.amount_due
        };

        curResponse = await salesController.add_paymentRestApi(paymentParams);

        prevResponse = curResponse;
        prevInv.push(await couchDBUtils.getDoc('inventory_1', mainDBInstance));
        prevInv.push(await couchDBUtils.getDoc('inventory_2', mainDBInstance));
        prevCustomer.push(await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance));
        prevCustomer.push(await couchDBUtils.getDoc('customer_' + customerArray[1], mainDBInstance));

        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });
        prevSaleId = resp.id;

        await commonUtils.pgTimeOut(2000);

        let inv1 = await couchDBUtils.getDoc('inventory_1', mainDBInstance);
        expect(prevInv[0].quantity - inv1.quantity).to.equal(4);
        let stockKey = allItems[0].batches[0].stockKey;
        expect(prevInv[0].stock[stockKey].quantity - inv1.stock[stockKey].quantity).to.equal(1);
        let uniqueDetails = inv1.stock[stockKey].uniqueDetails;
        let uniqueDetailsKeys = Object.keys(uniqueDetails);
        expect(uniqueDetails[uniqueDetailsKeys[0]].sold).to.equal(true);
        stockKey = allItems[0].batches[1].stockKey;
        expect(prevInv[0].stock[stockKey].quantity - inv1.stock[stockKey].quantity).to.equal(2);
        uniqueDetails = inv1.stock[stockKey].uniqueDetails;
        uniqueDetailsKeys = Object.keys(uniqueDetails);
        expect(uniqueDetails[uniqueDetailsKeys[0]].sold).to.equal(true);
        expect(uniqueDetails[uniqueDetailsKeys[1]].sold).to.equal(true);
        stockKey = allItems[0].batches[2].stockKey;
        expect(prevInv[0].stock[stockKey].quantity - inv1.stock[stockKey].quantity).to.equal(1);
        uniqueDetails = inv1.stock[stockKey].uniqueDetails;
        uniqueDetailsKeys = Object.keys(uniqueDetails);
        expect(uniqueDetails[uniqueDetailsKeys[0]].sold).to.equal(true);
        prevInv[0] = inv1;

        let inv2 = await couchDBUtils.getDoc('inventory_2', mainDBInstance);
        expect(prevInv[1].quantity - inv2.quantity).to.equal(2);
        stockKey = allItems[1].batches[0].stockKey;
        expect(prevInv[1].stock[stockKey].quantity - inv2.stock[stockKey].quantity).to.equal(2);
        prevInv[1] = inv2;

        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        expect(custDoc.total - prevCustomer[0].total - resp.total).within(-0.001, 0.001);
        prevCustomer[0] = custDoc;
    });

    it('initSaleEdit', async function() {
        let curResponse = await salesController.initEditSalesSession({
            saleId: 'sale_' + prevSaleId
        });

        expect(utils.compareObject(prevResponse, curResponse, 0, ['email_receipt', 'bGDiscountPercent', 'slab', 'origTaxes', 'comment', 'returnAmt'])).to.equal(true);
    });

    it('edit sale', async function() {
        let curResponse = await salesController.delteItemFromCart({
            item: 2
        });
        curResponse = await salesController.removeItem({
            item: allItems[1].item_id,
            stockKey: allItems[1].batches[0].stockKey
        });
        curResponse.cart[2].price = 99;
        curResponse = await salesController.editItemRestApi(curResponse.cart[2]);

        curResponse = await addUniqueItem(1, 2);
        expect(curResponse.cart.length).to.equal(5);

        curResponse = await salesController.deletePayment({
            payment_id: "Debit Card"
        });

        let paymentParams = {
            payment_type: "Sale on credit",
            amount_tendered: curResponse.amount_due
        };

        curResponse = await salesController.add_paymentRestApi(paymentParams);

        let param = {
            customer_id: customerArray[1]
        };
        curResponse = await salesController.addCustomer2Sale(param);

        let commonWorker = require('../../../controllers/workers/commonWorker');
        // commonWorker.setFreeze(true);
        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world',
            saleIdToEdit: 'sale_' + prevSaleId
        });

        await commonUtils.pgTimeOut(2000);

        let inv1 = await couchDBUtils.getDoc('inventory_1', mainDBInstance);
        expect(prevInv[0].quantity - inv1.quantity).to.equal(0);
        let stockKey = allItems[0].batches[0].stockKey;
        expect(prevInv[0].stock[stockKey].quantity - inv1.stock[stockKey].quantity).to.equal(-1);
        let uniqueDetails = inv1.stock[stockKey].uniqueDetails;
        let uniqueDetailsKeys = Object.keys(uniqueDetails);
        expect(uniqueDetails[uniqueDetailsKeys[0]].sold).to.equal(false);
        stockKey = allItems[0].batches[1].stockKey;
        expect(prevInv[0].stock[stockKey].quantity - inv1.stock[stockKey].quantity).to.equal(1);
        uniqueDetails = inv1.stock[stockKey].uniqueDetails;
        uniqueDetailsKeys = Object.keys(uniqueDetails);
        expect(uniqueDetails[uniqueDetailsKeys[0]].sold).to.equal(true);
        expect(uniqueDetails[uniqueDetailsKeys[1]].sold).to.equal(true);
        expect(uniqueDetails[uniqueDetailsKeys[2]].sold).to.equal(true);
        stockKey = allItems[0].batches[2].stockKey;
        expect(prevInv[0].stock[stockKey].quantity - inv1.stock[stockKey].quantity).to.equal(0);
        uniqueDetails = inv1.stock[stockKey].uniqueDetails;
        uniqueDetailsKeys = Object.keys(uniqueDetails);
        expect(uniqueDetails[uniqueDetailsKeys[0]].sold).to.equal(true);
        prevInv[0] = inv1;

        let inv2 = await couchDBUtils.getDoc('inventory_2', mainDBInstance);
        expect(prevInv[1].quantity - inv2.quantity).to.equal(-1);
        stockKey = allItems[1].batches[0].stockKey;
        expect(prevInv[1].stock[stockKey].quantity - inv2.stock[stockKey].quantity).to.equal(-1);
        prevInv[1] = inv2;

        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        expect(custDoc.total - prevCustomer[0].total + prevTotal).within(-0.001, 0.001);
        custDoc = await couchDBUtils.getDoc('customer_' + customerArray[1], mainDBInstance);
        expect(custDoc.total - prevCustomer[1].total - resp.total).within(-0.001, 0.001);
        expect(custDoc.credit_balance - prevCustomer[1].credit_balance - paymentParams.amount_tendered).within(-0.001, 0.001);
    });

    it('make sale', async function() {
        let curResponse = await salesController.additemRestApi({
            item: allItems[1].item_id,
            stockKey: allItems[1].batches[0].stockKey
        });
        curResponse = await salesController.additemRestApi({
            item: allItems[1].item_id,
            stockKey: allItems[1].batches[0].stockKey
        });

        curResponse = await addUniqueItem(0, 0);
        curResponse = await addUniqueItem(1, 0);
        curResponse = await addUniqueItem(1, 1);
        curResponse = await addUniqueItem(2, 0);

        let cartItem = CLONE(curResponse.cart[0]);
        cartItem.price = 1000;
        await salesController.editItemRestApi(cartItem);
        cartItem = CLONE(curResponse.cart[1]);
        cartItem.price = 10000;
        await salesController.editItemRestApi(cartItem);
        cartItem = CLONE(curResponse.cart[2]);
        cartItem.price = 10;
        await salesController.editItemRestApi(cartItem);
        cartItem = CLONE(curResponse.cart[3]);
        cartItem.priceprice = 100;
        curResponse = await salesController.editItemRestApi(cartItem);

        let paymentParams = {
            payment_type: "Cash",
            amount_tendered: curResponse.amount_due / 2
        };

        curResponse = await salesController.add_paymentRestApi(paymentParams);

        let param = {
            customer_id: customerArray[0]
        };
        curResponse = await salesController.addCustomer2Sale(param);

        paymentParams = {
            payment_type: "Debit Card",
            amount_tendered: curResponse.amount_due
        };

        curResponse = await salesController.add_paymentRestApi(paymentParams);

        prevResponse = curResponse;

        curResponse = await salesController.suspendSale();
        prevSaleId = curResponse.sale_id;
    });

    it('delete suspended sale', async function() {
        let params = {
            suspended_sale_id: prevSaleId
        }
        let deleteResp = await salesController.deleteSuspendedSale(params);
        expect(deleteResp[0].ok).to.equal(true);
        try {
            let resp = await couchDBUtils.getDoc('suspendedSale_' + prevSaleId, mainDBInstance, "sale document not found");
        } catch (error) {
            expect(error).to.equal("sale document not found");
        }
    })

});