'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();

const profitGuruFaker = require('../../common/profitGuruFaker.js');
const utils = require('../../common/Utils.js');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();

let receivingsController;
const itemController = require('../../../controllers/Items');
const globalConfigController = require('../../../controllers/GlobalConfigurations');

const categoryCreateJson = {
    "name": "cat2",
    "subCat": []
};

let itemCreateJson = {
    "uniqueItemCode": "",
    "name": "round2",
    "item_number": "",
    "receiving_quantity": 0,
    "reorder_level": 0,
    "description": "",
    "expiry_date": "",
    "allow_alt_description": "0",
    "ItemType": "",
    "categoryId": 1547797370121,
    "purchasePrice": "",
    "sellingPrice": "",
    "mrp": "",
    "hasMeasurementUnit": false,
    "is_serialized": false,
    "hasExpiryDate": false,
    "purchaseTaxes": [
        1547796984532
    ],
    "salesTaxes": [
        1547796984532
    ],
    "reorderLevel": "",
    "reorderQuantity": "",
    "isNewBatch": false,
    "hasBatchNumber": false,
    "bOTG": false,
    "bPPTaxInclusive": true,
    "bSPTaxInclusive": true,
    "imeiCount": 0,
    "imeNumbers": [],
    "initialStock": [
        {
            "quantity": 100,
            "expiry": null,
            "uniqueDetails": [],
            "unitsInfo": {
                "1547796982249": {
                    "refUnitId": 1547796982249,
                    "factor": 1,
                    "purchasePrice": 2.15,
                    "mrp": 2.15,
                    "pProfilesData": {
                        "1547796983231": {
                            "sellingPrice": 2.15,
                            "discountId": ""
                        }
                    }
                }
            }
        }
    ],
    "unitsInfo": {
        "1547796982249": {
            "refUnitId": 1547796982249,
            "factor": 1,
            "purchasePrice": 2.15,
            "mrp": 2.15,
            "pProfilesData": {
                "1547796983231": {
                    "sellingPrice": 2.15,
                    "discountId": ""
                }
            }
        }
    },
    "hasVariants": false,
    "density": 0,
    "pricingProfiles": false,
    "multipleUnits": false,
    "itemNprice": 0,
    "baseUnitId": 1547796982249,
    "subCategories": [],
    "defaultPurchaseUnitId": 1547796982249,
    "defaultSellingUnitId": 1547796982249,
    "convPurchasePrice": null,
    "attributes": [],
    "isprepared": false,
    "issellable": false,
    "isbought": false,
    "is_deleted": "",
    "discount_expiry": null
};

let purAddItemJson = {
    "item": 1,
    "unitId": 1547796982249,
    "discountBy": "percent",
    "discount": 0,
    "uniqueDetails": [],
    "quantity": 0
};

let purItemEditJson = {
    "item_id": 1,
    "batchId": "",
    "item_location": 1,
    "line": 1,
    "name": "round1",
    "description": "",
    "unit": "Nos",
    "unitDocs": {
        "1547796982249": {
            "_id": "unit_1547796982249",
            "_rev": "1-c1e98456ff044a26fe77e49107b558d2",
            "name": "Nos",
            "description": "Unit",
            "id": 1547796982249
        }
    },
    "discount": 0,
    "discountBy": "percent",
    "bOTG": false,
    "bPPTaxInclusive": true,
    "bPPTempTaxInclusive": "true",
    "unitsInfo": {
        "1547796982249": {
            "refUnitId": 1547796982249,
            "factor": 1,
            "purchasePrice": 2.15,
            "mrp": 2.15,
            "pProfilesData": {
                "1547796983231": {
                    "sellingPrice": 2.15,
                    "discountId": ""
                }
            },
            "purchasePriceWithGDiscount": 2.1476
        }
    },
    "baseUnitId": 1547796982249,
    "unitId": 1547796982249,
    "hasExpiryDate": false,
    "is_serialized": false,
    "hasBatchNumber": false,
    "imeiCount": 0,
    "itemTaxList": [
        {
            "name": "CGST",
            "percent": 9,
            "Amt": 0.1638
        },
        {
            "name": "SGST",
            "percent": 9,
            "Amt": 0.1638
        }
    ],
    "origTaxes": [
        {
            "taxId": 1547796984532,
            "taxInfo": {
                "_id": "tax_1547796984532",
                "_rev": "1-220f96dc97eaced664666a7f09ea7dc6",
                "name": "GST",
                "percent": 18,
                "id": 1547796984532
            }
        }
    ],
    "hasVariants": false,
    "multipleUnits": false,
    "stockKey": "id_1_batch_1547797451527",
    "oldStock": {
        "location_id": 1,
        "unitsInfo": {
            "1547796982249": {
                "refUnitId": 1547796982249,
                "factor": 1,
                "purchasePrice": 2.15,
                "mrp": 2.15,
                "pProfilesData": {
                    "1547796983231": {
                        "sellingPrice": 2.15,
                        "discountId": ""
                    }
                }
            }
        },
        "batchId": "",
        "stockKey": "id_1_batch_1547797451527",
        "timeStamp": "1547797451528",
        "barcode": ":1",
        "locationId": 1
    },
    "quantity": 600,
    "purchasePriceExTax": 1.8220338983050848,
    "bReadyForCheckout": true,
    "totalTaxPercent": 18,
    "totalNoTaxNoDiscount": 1.82,
    "totalNoTaxWithDiscount": 1.82,
    "discounted_price": 0,
    "total": 2.1476,
    "totalNoGlobalDiscount": 2.15,
    "$$hashKey": "object:1215",
    "mrp": 0,
    "purchasePrice": 0,
    "sellingPrice": 0
};


describe('Purchase Controller 7 Purchase Edit UTS', function () {

    this.timeout(500000);
    this.slow(0);


    const curSession = profitGuruFaker.getFakerSession();
    let applicationSettings;
    let categoryId; //1547797370121
    let unitId; //1547796982249
    let pProfileId; //1547796983231
    let itemId; //1
    let taxId;//1547796984532

    before(async function () {
        let logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);

        let bResetDB = false;
        let resp = await couchDbManager.initCouchDb(bResetDB);
        applicationSettings = resp.applicationSettings;
        await createItem(false);
        applicationSettings.numberFormat.roundOffMethod = 'upward'

        receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);
    });

    async function createItem(bResetDB) {
        //create category
        if (bResetDB) {
            await globalConfigController.createCategory(categoryCreateJson);
        }

        //category
        let respArr = await couchDBUtils.getAllDocsByType('category', mainDBInstance, { limit: 1 }, false);
        categoryId = respArr[0].doc.id;
        //tax
        respArr = await couchDBUtils.getAllDocsByType('tax', mainDBInstance, undefined, false);
        for (let i = 0; i < respArr.length; i++) {
            if (respArr[i].doc.percent === 18) {
                taxId = respArr[i].doc.id;
            }
        }
        //unit
        respArr = await couchDBUtils.getAllDocsByType('unit', mainDBInstance, { limit: 1 }, false);
        unitId = respArr[0].doc.id;

        //pProfileId -> applicationsettings
        pProfileId = applicationSettings.salesConfig.pProfileId;


        //create item
        if (bResetDB) {
            itemCreateJson.categoryId = categoryId;
            let itemCreateJsonStr = JSON.stringify(itemCreateJson);
            let regexp = new RegExp(1547796982249, 'g');
            itemCreateJsonStr = itemCreateJsonStr.replace(regexp, parseInt(unitId));
            regexp = new RegExp(1547796983231, 'g');
            itemCreateJsonStr = itemCreateJsonStr.replace(regexp, parseInt(pProfileId));
            regexp = new RegExp(1547796984532, 'g');
            itemCreateJsonStr = itemCreateJsonStr.replace(regexp, parseInt(taxId));

            itemCreateJson = JSON.parse(itemCreateJsonStr);

            await itemController.createItem(itemCreateJson);
        }

        purAddItemJson.unitId = unitId;
        let purItemEditJsonStr = JSON.stringify(purItemEditJson);
        let regexp = new RegExp(1547796982249, 'g');
        purItemEditJsonStr = purItemEditJsonStr.replace(regexp, parseInt(unitId));
        regexp = new RegExp(1547796983231, 'g');
        purItemEditJsonStr = purItemEditJsonStr.replace(regexp, parseInt(pProfileId));
        regexp = new RegExp(1547796984532, 'g');
        purItemEditJsonStr = purItemEditJsonStr.replace(regexp, parseInt(taxId));

        purItemEditJson = JSON.parse(purItemEditJsonStr);
    }

    //inv transaction check missing
    it('make receiving', async function () {

        let resp = await receivingsController.additem(purAddItemJson);
        resp = await receivingsController.editItem(purItemEditJson);
        console.log(resp);
    });




});