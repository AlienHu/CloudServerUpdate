'use strict';
var BPromise = require('bluebird');
var profitGuruFakerExt = require('../../../common/profitGuruFakerExt.js');

var faker = require('faker');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;

let recivingsTestHelper = function(curSession, applicationSettings) {
    var receivingsController = require('../../../../controllers/Receivings')(curSession, applicationSettings);
    const itemsControllerLib = require('../../../../controllers/libraries/itemsControllerLib');
    const commonLib = require('../../../../controllers/libraries/commonLib');
    const computeUtils = require('../../../../controllers/common/computeUtils');
    const utils = require('../../../../controllers/common/Utils');
    const IS_EMPTY_OBJECT = utils.isEmptyObject;

    var foo = {};
    var _self = foo;

    let calculations = {
        total: 0,
        totalNoTax: 0,
        totalTax: 0,
        totalNoTaxNoDiscount: 0,
        totalNoTaxWithDiscount: 0,
        totalNoGlobalDiscount: 0,
        discount: {
            method: "onTotal",
            bPercent: true,
            percent: true,
            amount: true,
            value: 0
        },
        cart: []
    };

    function compute() {
        calculations = {
            total: 0,
            totalNoTax: 0,
            totalTax: 0,
            totalNoTaxNoDiscount: 0,
            totalNoTaxWithDiscount: 0,
            totalNoGlobalDiscount: 0,
            discount: {
                method: "onTotal",
                bPercent: true,
                percent: true,
                amount: true,
                value: 0
            },
            cart: calculations.cart
        };

        for (let i = 0; i < calculations.cart.length; i++) {
            calculations.total += calculations.cart[i].total;
            calculations.totalNoTax += calculations.cart[i].totalNoTax;
            calculations.totalTax += calculations.cart[i].totalTax;
        }
    }

    async function computeItem(cartItem, globalDiscountParam) {
        let item_id = cartItem.item_id;
        let quantity = cartItem.quantity;

        let itemInfo = await itemsControllerLib.getThisItemInfo({
            item_id: item_id,
            taxType: itemsControllerLib.enPurchaseTax
        });

        //todomumerge : review code for exclusive pp
        let pp = commonLib.getPPFromUInfo(cartItem.unitsInfo, cartItem.unitId);
        cartItem.purchasePriceExTax = pp;
        let baseUnitPrice;
        if (cartItem.bPPTempTaxInclusive) {
            //todoMumerge  : consider baseUnit
            baseUnitPrice = commonLib.getBaseUnitPrice(cartItem.purchasePriceExTax, cartItem.unitId, cartItem.baseUnitId, cartItem.unitsInfo);
            cartItem.totalTaxPercent = getTaxesForItem(cartItem.origTaxes, cartItem.slab, cartItem.itemTaxList, baseUnitPrice, cartItem.bPPTempTaxInclusive, undefined, globalDiscount.percent + cartItem.discount);
            cartItem.purchasePriceExTax = computeUtils.calculatePriceExcludingTax(pp, cartItem.totalTaxPercent);
            pp = cartItem.purchasePriceExTax;
        }

        let taxes = itemInfo.taxes;
        let itemTaxList = [];
        let discount = cartItem.discount ? cartItem.discount : 0;
        let discountAmt = discount * pp * 0.01;

        let totalNoTaxNoDiscount = pp * quantity;
        let totalNoTaxWithDiscount = (pp - discountAmt) * quantity;
        //todomumerge : consider baseunitprice
        baseUnitPrice = commonLib.getBaseUnitPrice(totalNoTaxWithDiscount / quantity, cartItem.unitId, cartItem.baseUnitId, cartItem.unitsInfo);
        let totalTaxPercent = getTaxesForItem(taxes, itemInfo.slab, itemTaxList, baseUnitPrice) * 0.01;

        let total = totalNoTaxWithDiscount * (1 + totalTaxPercent);

        if (globalDiscountParam.method == 'onTaxable') {
            totalNoTaxWithDiscount = totalNoTaxWithDiscount * (1 - globalDiscountParam.percent * 0.01);
            baseUnitPrice = commonLib.getBaseUnitPrice(totalNoTaxWithDiscount / quantity, cartItem.unitId, cartItem.baseUnitId, cartItem.unitsInfo);
            totalTaxPercent = getTaxesForItem(taxes, itemInfo.slab, itemTaxList, baseUnitPrice) * 0.01;
            total = totalNoTaxWithDiscount * (1 + totalTaxPercent);
        } else if (globalDiscountParam.method == 'onTotal') {
            total = total * (1 - globalDiscountParam.percent * 0.01);
            totalNoTaxWithDiscount = total / (1 + totalTaxPercent);
            baseUnitPrice = commonLib.getBaseUnitPrice(totalNoTaxWithDiscount / quantity, cartItem.unitId, cartItem.baseUnitId, cartItem.unitsInfo);
            totalTaxPercent = getTaxesForItem(taxes, itemInfo.slab, itemTaxList, baseUnitPrice) * 0.01;
            totalNoTaxNoDiscount = totalNoTaxWithDiscount / (1 - (globalDiscountParam.percent + discount) * 0.01);
        }

        return {
            itemInfo: itemInfo,
            total: total,
            totalNoTax: totalNoTaxNoDiscount,
            totalTax: totalNoTaxWithDiscount * totalTaxPercent
        };
    }

    function getTaxesForItem(taxes, slab, formattedTaxes, price, bPPTaxInclusive) {
        if (!IS_EMPTY_OBJECT(slab) && bPPTaxInclusive) {
            logger.error('tax slab and tax inclusive is not implemented');
            throw 'Internal Error';
        }

        let totalTaxPercent = 0;
        formattedTaxes.length = 0;
        let formattedTaxesCount = {};
        if (!IS_EMPTY_OBJECT(slab)) {
            let taxFromSlab = computeUtils.getTaxFromSlab(slab, price);

            if (taxFromSlab.percent !== 0) {
                formattedTaxes.push(taxFromSlab);
                formattedTaxesCount[taxFromSlab.name] = 1;
                totalTaxPercent += taxFromSlab.percent;
            }
        }
        let totalTaxWithoutSlab = 0
        for (let taxIdx in taxes) {
            let tax = taxes[taxIdx].taxInfo;
            if (!formattedTaxesCount[tax.name]) {
                let itemTaxInfo = {};
                itemTaxInfo.name = tax.name;
                itemTaxInfo.percent = tax.percent;
                totalTaxPercent += tax.percent;
                formattedTaxes.push(itemTaxInfo);
                formattedTaxesCount[tax.name] = 1;
                totalTaxWithoutSlab += tax.percent;
            }
        }

        computeUtils.formatGSTTaxes(formattedTaxes, curSession.settings.receivings.bLocalTax);

        return totalTaxPercent;
    }

    async function compareCartItemResponse(cartItem, globalDiscountParam) {
        let computeResp = await computeItem(cartItem, globalDiscountParam);
        calculations.cart.push(computeResp);
        // console.log('exit ' + +calculations.cart.length);
        expect(computeResp.total - cartItem.total).within(-1, 1);
        expect(computeResp.totalNoTax - cartItem.totalNoTaxNoDiscount).within(-0.001, 0.001);
    }

    foo.compareOverAllResponse = async function(response) {
        calculations.cart = [];
        for (let i = 0; i < response.cart.length; i++) {
            await compareCartItemResponse(response.cart[i], response.discount);
            // console.log(calculations.cart.length + '<>' + (i + 1));
        }
        compute();

        expect(calculations.total - response.total).within(-1, 1);
        expect(calculations.totalNoTax - response.totalNoTaxNoDiscount).within(-0.001, 0.001);
    }

    //can make foo function random
    foo.addItems2Cart = function(bBatch, indexesOf2, batchArray, itemsArray, retResponse) {

        if (bBatch === undefined) {
            bBatch = true;
        }

        var indexes = indexesOf2 ? indexesOf2 : [1, 2, 4, 2, 3, 3, 4];
        var tempBatchArr = batchArray.slice();

        return BPromise.each(indexes, function(itemIndex) {
            var params = {
                item: itemsArray[itemIndex].item_id
            };
            if (bBatch) {
                params.batchId = tempBatchArr.shift();
            }

            if (itemsArray[itemIndex].hasExpiryDate) {
                params.expiry = faker.date.future().toString();
            }
            params.uniqueDetails = [];

            // if () {
            //  for (var i = 0; i < cartItem.quantity; i++) {
            if (itemsArray[itemIndex].imeCount !== 0 || itemsArray[itemIndex].is_serialized) {
                var imeiNumbers = [];
                for (var j = 0; j < itemsArray[itemIndex].imeiCount; j++) {
                    imeiNumbers.push((faker.random.uuid()).toString());
                }
            }
            params.uniqueDetails.push({
                serialnumber: (faker.random.uuid()).toString(),
                imeiNumbers: imeiNumbers
            });
            //    }
            // }
            return receivingsController.additem(params).then(function(resp) {
                retResponse.value = resp;
                return retResponse;
            });
        }).then(function() {
            if (indexesOf2) {
                expect(retResponse.value.cart.length).to.equal(2);
            } else {
                expect(retResponse.value.cart.length).to.equal(4);
            }
            return _self.compareOverAllResponse(retResponse.value);
        }).then(function() {
            return retResponse;
        });
    }

    function pgTimeOut(time) {
        return new Promise(resolve => {
            setTimeout(function() {
                resolve();
            }, time)
        });
    }

    function getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min)) + min; //The maximum is exclusive and the minimum is inclusive
    }

    foo.editItem = async function(cartItem, batchId) {
        let discount = [10, 20, 30, 40, 50, 60, 70, 80, 90, 0];
        let params = {
            line: cartItem.line,
            description: cartItem.description,
            unitsInfo: cartItem.unitsInfo,
            quantity: parseFloat(cartItem.quantity),
            expiry: cartItem.expiry,
            itemLocation: cartItem.item_location,
            batchId: batchId,
            // discount: discount[(cartItem.line % discount.length) - 1]
            discount: getRandomInt(10, 90)
        };
        if (!cartItem.is_serialized && !cartItem.imeiCount) { // not unique items
            params.quantity *= 2;
        }
        let response;
        return receivingsController.editItem(params).then(function(resp) {
            response = resp;
            for (let i = 0; i < response.cart.length; i++) {
                if (response.cart[i].line === params.line) {
                    expect(response.cart[i].purchasePrice).to.equal(params.purchasePrice);
                    expect(response.cart[i].quantity).to.equal(params.quantity);
                    expect(response.cart[i].discount).to.equal(params.discount);
                }
            }
            return _self.compareOverAllResponse(response);
        }).then(function() {
            return response;
        });
    };

    foo.removeItemFromCart = async function(params) {
        let newResp = await receivingsController.removeItem(params);
        await _self.compareOverAllResponse(newResp);
        return newResp;
    }

    foo.addEditAdd = async function(item_id, i, retResponse) {
        let params = {
            item: item_id
        };

        retResponse.value = await receivingsController.additem(params);
        await _self.compareOverAllResponse(retResponse.value);
        params.batchId = (faker.random.alphaNumeric()).toString();
        retResponse.value = await _self.editItem(retResponse.value.cart[i], params.batchId);
        await _self.compareOverAllResponse(retResponse.value);
        retResponse.value = await receivingsController.additem(params);
        await _self.compareOverAllResponse(retResponse.value);
        return retResponse;
    }

    foo.addSupplier2Cart = async function(params) {
        let resp = await receivingsController.addSupplier(params);
        // .then(function(resp) {
        expect(resp.succs_supplier_id).to.equal(params.supplier_id);
        // });
    }

    foo.addPayment = async function(paymentParams) {

        let resp = await receivingsController.add_paymentRestApi(paymentParams);

        return resp;
    }

    foo.completeReceivings = async function(retResponse, bTimeout) {
        if (bTimeout === undefined) {
            bTimeout = 2000;
        }

        var params = {
            comment: 'hello world'
        };

        let resp = await receivingsController.completeReceivings(params);
        //    resp.receiving_id.substring(5, resp.receiving_id.length);
        // prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
        await pgTimeOut(bTimeout);
        expect(resp.comment).to.equal(params.comment);
        expect(resp.cart.length).to.equal(retResponse.value.cart.length);
        // maxRecId.value = parseInt(resp.receiving_id.substring(4));
        await _self.compareOverAllResponse(resp);

        return resp;
    }

    return foo;

};

module.exports = function(session, applicationSettings) {
    return recivingsTestHelper(session, applicationSettings);
};