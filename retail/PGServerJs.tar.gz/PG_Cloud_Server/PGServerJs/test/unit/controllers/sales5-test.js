'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const logger = require('../../../common/Logger');
const profitGuruFaker = require('../../common/profitGuruFaker.js');
const profitGuruFaker2 = require('../../common/profitGuruFaker2');
const faker = require('faker');

const cntrlrUtils = require('../../../controllers/common/Utils');
const ARRAY_LENGTH = cntrlrUtils.getArrayLength;
const commonTestUtils = require('../../common/commonUtils.js');
const utils = require('../../common/Utils.js');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const computeUtils = require('../../../controllers/common/computeUtils');
let itemControllerLib;
let commonLib;
let saleCntrlrLib;
let globalConfigurationsCntrlr;
let salesTestHelper;
let applicationSettings;

const couchDbManager = require('../../../dbManagers/couchDbManager');
let BPromise = require('bluebird');

let itemTypes;
let allProfiles;
let allSlabs;
let items;
let customerArray;
let prevSaleId = -1;
const curSession = profitGuruFaker.getFakerSession();
let salesController;
let commonWorker;
let curResponse;

let globalDiscountParam = {
    value: 0,
    bPercent: false,
    itemCount: 0,
    discountMethod: 'onTaxable'
};

describe('Sales Controller 5 UTS', function() {

    this.timeout(500000);
    this.slow(0);

    before(async function() {
        let logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);

        let bResetDB = true;
        let resp = await couchDbManager.initCouchDb(bResetDB);
        applicationSettings = resp.applicationSettings;
        commonWorker = require('../../../controllers/workers/commonWorker');
        if (!bResetDB) {
            return;
        }

        await Promise.all([commonTestUtils.createGlobalConfigs(5), commonTestUtils.getPeople(5, 'supplier')]);

        let promiseResults = await BPromise.props({
            allItems: commonTestUtils.getItems(2, true, 10, 3, true, true),
            allCustomers: commonTestUtils.getPeople(2, 'customer'),
            allProfiles: couchDBUtils.getAllDocsByType('profile', mainDBInstance, {}, true),
            allSlabs: couchDBUtils.getAllDocsByType('slab', mainDBInstance, {}, true)
        });
        items = promiseResults.allItems;
        let availableItemTypes = [];
        for (let i = 0; i < items.length; i++) {
            availableItemTypes.push(items[i].ItemType);
        }
        logger.info(availableItemTypes);

        customerArray = promiseResults.allCustomers;

        expect(customerArray.length).to.be.at.least(2);
        expect(items.length).to.be.at.least(2);
        allProfiles = promiseResults.allProfiles;
        allSlabs = promiseResults.allSlabs;
        expect(allProfiles.length).to.greaterThan(1);
        salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        itemControllerLib = require('../../../controllers/libraries/itemsControllerLib');
        commonLib = require('../../../controllers/libraries/commonLib');
        globalConfigurationsCntrlr = require('../../../controllers/GlobalConfigurations');
        saleCntrlrLib = require('../../../controllers/libraries/salesControllerLib')(curSession, applicationSettings);
        salesTestHelper = require('./testHelpers/salesTestHelper.js');
        salesTestHelper.set(itemControllerLib, commonLib, saleCntrlrLib, computeUtils, curSession, applicationSettings);
        itemTypes = Object.keys(applicationSettings.itemType);
        for (let i = 0; i < itemTypes.length; i++) {
            itemTypes[i] = itemTypes[i].toLowerCase();
        }
        let index = itemTypes.indexOf('Ingredient');
        if (index != -1) {
            itemTypes.splice(index, 1);
        }
    });

    after(function() {});

    it('get Tax from slab', function() {
        let taxSlab = profitGuruFaker2.getFakerTaxSlab();
        let price = 800;
        let tax = computeUtils.getTaxFromSlab(taxSlab, price);
        let bMatchFound = false;
        for (let i = 0; i < taxSlab.rates.length; i++) {
            let rangeMin = taxSlab.rates[i].min;
            let rangeMax = taxSlab.rates[i].max;
            if (rangeMax >= price && rangeMin <= price) {
                expect(tax.percent).to.equal(taxSlab.rates[i].percent);
                expect(tax.name).to.equal(taxSlab.taxName);
                bMatchFound = true;
                break;
            }
        }
        expect(bMatchFound).to.equal(true);
    });

    it('get item info', async function() {
        let item = items[0];
        let resp = await itemControllerLib.getThisItemInfo({
            item_id: item.item_id,
            stockKey: item.batches[0].stockKey
        });

        expect(item.purchaseTaxes.length).to.equal(resp.purchaseTaxes.length);
        for (let i = 0; i < resp.purchaseTaxes.length; i++) {
            let taxId = resp.purchaseTaxes[i].taxId;
            expect(item.purchaseTaxes.indexOf(taxId)).to.greaterThan(-1);
        }

        expect(item.salesTaxes.length).to.equal(resp.salesTaxes.length);
        for (let i = 0; i < resp.salesTaxes.length; i++) {
            let taxId = resp.salesTaxes[i].taxId;
            expect(item.salesTaxes.indexOf(taxId)).to.greaterThan(-1);
        }

        expect(item.salesSlab).to.equal(resp.salesSlab.id);
        expect(item.purchaseSlab).to.equal(resp.purchaseSlab.id);
        expect(item.batches[0].stockKey).to.equal(resp.batches[0].stockKey);
        for (let unitId in item.batches[0].unitsInfo) {
            let unitData = item.batches[0].unitsInfo[unitId];
            for (let profileId in unitData.pProfilesData) {
                expect(unitData.pProfilesData[profileId].discountId).to.equal(resp.batches[0].unitsInfo[unitId].pProfilesData[profileId].discount.id);
            }
        }
    });

    it('get profile info', async function() {
        let profileDoc = allProfiles[0];
        let resp = await globalConfigurationsCntrlr.getProfileInfo(profileDoc.id);
        for (let i = 0; i < itemTypes.length; i++) {
            let taxKey = itemTypes[i] + 'Taxes';
            for (let i = 0; i < ARRAY_LENGTH(profileDoc[taxKey]); i++) {
                expect('tax_' + profileDoc[taxKey][i]).to.equal(resp[taxKey][i]._id);
            }
        }

        if (profileDoc.slab) {
            expect('slab_' + profileDoc.slab).to.equal(resp.slab._id);
        }

        for (let i = 0; i < ARRAY_LENGTH(profileDoc.charges); i++) {
            expect('charge_' + profileDoc.charges[i]).to.equal(resp.charges[i]._id);
        }

    });

    it('getTaxesForItem', async function() {
        let taxes = [{
            taxInfo: {
                name: 'GST',
                percent: 5
            }
        }, {
            taxInfo: {
                name: 'Cess',
                percent: 0.5
            }
        }, {
            taxInfo: {
                name: 'VAT',
                percent: 20
            }
        }];

        let formattedTaxes = [];
        let formattedCharges = [];
        let bSPTaxInclusive = false;
        let price = 2200;
        await saleCntrlrLib.updateSalesProfileSettings(allProfiles[0].id);
        let totalTaxPercent = saleCntrlrLib.getTaxesForItem(taxes, allSlabs[0], price, formattedTaxes, formattedCharges, bSPTaxInclusive, 'Normal');

        let profile = await globalConfigurationsCntrlr.getProfileInfo(allProfiles[0].id);
        computeUtils.formatGSTTaxes(profile.preparedTaxes, true);
        expect(utils.compareArray(profile.preparedTaxes, formattedCharges)).to.equal(true);

        let taxCount = {};
        let refTaxes = [];
        let taxSlab = computeUtils.getTaxFromSlab(allSlabs[0], price);
        taxCount[taxSlab.name] = 1;
        refTaxes.push(taxSlab);

        for (let i = 0; i < taxes.length; i++) {
            let tax = taxes[i].taxInfo;
            if (!taxCount[tax.name]) {
                refTaxes.push(tax);
                taxCount[tax.name] = 1;
            }
        }

        for (let i = 0; i < profile.normalTaxes.length; i++) {
            let tax = profile.normalTaxes[i];
            if (!taxCount[tax.name]) {
                refTaxes.push(tax);
                taxCount[tax.name] = 1;
            }
        }
        computeUtils.formatGSTTaxes(refTaxes, true);

        expect(utils.compareArray(refTaxes, formattedTaxes)).to.equal(true);
        await saleCntrlrLib.updateSalesProfileSettings();
    });

    async function testAddItem(item_id, stockKey) {
        let resp = await salesController.additemRestApi({
            item: item_id,
            stockKey: stockKey
        });
        curResponse = resp;
        globalDiscountParam.itemCount++;
        for (let i = 0; i < resp.cart.length; i++) {
            let cartItem = resp.cart[i];
            expect(cartItem.quantity).to.equal(1);
        }
    }

    it('add 2 Items to Cart', async function() {
        let ids = [0, 1, 1, 1, 0, 0, 1, 1];
        let itemIds = [];

        for (let i = 0; i < ids.length; i++) {
            itemIds.push(items[ids[i]].item_id);
        }

        let index = 0;
        for (let i = 0; i < ids.length; i++, index++) {
            await testAddItem(itemIds[index], items[ids[i]].batches[0].stockKey);
            expect(curResponse.cart.length).to.equal(index + 1);
        }

        await salesTestHelper.compareOverAllResponse(curResponse, globalDiscountParam);
    });

    it('inter vs intra state taxes', async function() {
        function checkTaxNames(bLocal) {
            let notArray = ['GST', 'IGST'];
            if (!bLocal) {
                notArray = ['GST', 'CGST', 'SGST'];
            }

            for (let i = 0; i < curResponse.cart.length; i++) {
                let cartItem = curResponse.cart[i];
                for (let j = 0; j < cartItem.itemTaxList.length; j++) {
                    expect(notArray.indexOf(cartItem.itemTaxList[j].name.toUpperCase())).to.equal(-1);
                }
            }

            for (let key in curResponse.taxes) {
                expect(notArray.indexOf(key.toUpperCase())).to.equal(-1);
            }
        }

        checkTaxNames(true);

        curResponse = await salesController.setLocalTax({
            bLocalTax: false
        });

        checkTaxNames(false);

        curResponse = await salesController.setLocalTax({
            bLocalTax: true
        });

        checkTaxNames(true);
    });

    async function validate(foo, params) {
        let resp = await foo(params);

        await salesTestHelper.compareOverAllResponse(resp, globalDiscountParam);
        curResponse = resp;
    }

    it('global discount', async function() {

        globalDiscountParam.value = 100;
        await validate(salesController.setGlobalDiscount, globalDiscountParam);
        globalDiscountParam.value = 0;
        await validate(salesController.setGlobalDiscount, globalDiscountParam);
        globalDiscountParam.value = 10;
        globalDiscountParam.bPercent = true;
        await validate(salesController.setGlobalDiscount, globalDiscountParam);
        globalDiscountParam.value = 20;
        globalDiscountParam.bPercent = true;
        await validate(salesController.setGlobalDiscount, globalDiscountParam);
        await testAddItem(items[0].item_id, items[0].batches[0].stockKey);
        await salesTestHelper.compareOverAllResponse(curResponse, globalDiscountParam);
        globalDiscountParam.value = 200;
        globalDiscountParam.bPercent = false;
        await validate(salesController.setGlobalDiscount, globalDiscountParam);
        await testAddItem(items[0].item_id, items[0].batches[0].stockKey);
        await salesTestHelper.compareOverAllResponse(curResponse, globalDiscountParam);
        await testAddItem(items[1].item_id, items[1].batches[0].stockKey);
        await salesTestHelper.compareOverAllResponse(curResponse, globalDiscountParam);
        globalDiscountParam.value = 0;
        await validate(salesController.setGlobalDiscount, globalDiscountParam);
    });

    it('profiles (and charges) test', async function() {
        for (let i = 0; i < allProfiles.length; i++) {
            applicationSettings.taxProfile.id = allProfiles[i].id;
            await validate(salesController.getSales);
        }

        applicationSettings.taxProfile.id = '';
        await validate(salesController.getSales);
    });

    it('complete this sale', async function() {
        let paymentParams = {
            payment_type: "Cash",
            amount_tendered: curResponse.total
        };

        let resp = await salesController.add_paymentRestApi(paymentParams);
        expect(resp.cart.length).to.equal(11);
        let param = {
            customer_id: faker.random.arrayElement(customerArray)
        };
        resp = await salesController.addCustomer2Sale(param);

        resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });

        await salesTestHelper.compareOverAllResponse(resp, globalDiscountParam, true);

        // let saleIdLength = resp.sale_id.length;
        prevSaleId = resp.id; //sale_id.substring(4, saleIdLength);
        await commonTestUtils.pgTimeOut(1000);
    });

    it('reprint test', async function() {
        let params = {
            saleId: 'sale_' + prevSaleId
        };

        let resp = await salesController.rePrint(params);
        let excludeFields = ['item_number', 'is_serialized', 'hasBatchNumber', 'bOTG', 'hasExpiryDate', 'price', 'sellingPriceExcludingTax', 'reorder_level', 'imeiCount', 'origTaxes', 'slab', 'bReadyForCheckout', 'gDiscountValue', 'bGDiscountPercent', 'gDiscountPercent', 'gDiscountAmt', 'print_after_sale', 'globalDiscountInfo', 'profileId', 'baseUnitId', 'baseUnitPrice', 'totalPurchaseTaxPercent', 'unitsInfo', 'unitDocs', 'bLocalTax'];
        expect(utils.compareObject(curResponse, resp, 0.01, excludeFields)).to.equal(true);
    });

    xit('reverse transaction', async function() {
        prevSaleId = 1;
        commonWorker.setFreeze(true);
        await commonLib.reverseTransaction('receiving_1', true, 'hello');
        // commonWorker.setFreeze(false);
        // await commonTestUtils.pgTimeOut(2000);
    });

});