(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    const shelljs = require('shelljs');
    const path = require('path');
    const chai = require('chai');
    const faker = require('faker');
    const chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    const expect = chai.expect;

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const platform = /^win/.test(process.platform) ? "windows" : "linux";
    const env = process.env.ENVIRONMENT || "development";
    const config = require(path.join(__dirname, '..', '../../config', 'config.json'))[env];

    const utils = require('../../common/Utils.js');
    let commonTestUtils;
    let commonTestUtils2;
    const profitGuruFaker = require('../../common/profitGuruFaker.js');
    const profitGuruFakerExt = require('../../common/profitGuruFakerExt.js');
    const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    const backUpController = require('../../../controllers/backUpAndRestore');
    const couchDB = couchDBUtils.getMainCouchDB();
    const backUpBaseLocationDir = __dirname + '/../../../data';
    let backUpLength = 0;
    let backUpList = [];
    let backUpDBStates = [];

    describe('backUp Controller UTs  ', function(done) {
        this.timeout(10000000);

        before(async function() {
            try {
                //Set this flag to start the test fresh
                let bResetDB = true;
                if (bResetDB) {
                    let logDir = '.';
                    utils.deleteFilesOfType(logDir, ['log']);
                    shelljs.rm('-rf', backUpBaseLocationDir);
                }
                await couchDbManager.initCouchDb(bResetDB);
                let commonWorker = require('../../../controllers/workers/commonWorker');
                commonWorker.setFreeze(true);

                commonTestUtils = require('../../common/commonUtils.js');
                commonTestUtils2 = require('../../common/commonUtils2.js');

                await commonTestUtils2.createSomeData(bResetDB, true);

                backUpList = (await backUpController.getBackUpsList(backUpBaseLocationDir));
                backUpLength = backUpList.length; //Keeping track of backUp Length to see backups are really created
            } catch (error) {
                throw error;
            }
        });

        async function getCouchDatabaseState() {
            //Querying no of documents in maindb and salesdb. So that we can verify no of documents
            let dbSuffixes = ['maindb'];
            let dbState = {};

            for (let i = 0; i < dbSuffixes.length; i++) {
                dbState[dbSuffixes[i]] = await couchDBUtils.getNoOfDocs(dbSuffixes[i]);
            }
            console.log(dbState.maindb);

            return dbState;
        }

        async function takeBackUp() {
            //prepare backUp Config
            let backUpConfig = {
                reason4Backup: 'casual',
                backUpBaseLocationDir: backUpBaseLocationDir,
                couchConnectUrl: 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT
            };

            try {
                let resp = await backUpController.takeBackUp(backUpConfig);
                let length = shelljs.ls(backUpConfig.backUpLocation).length; //backUpLocation is filled by the code
                expect(length).to.equal(4);
                backUpLength++;
                let databaseState = await getCouchDatabaseState();
                backUpDBStates.push(databaseState);
            } catch (error) {
                console.log(error);
                expect(0).to.equal(1);
            }
        }

        async function restoreBackUp(restoreBaseLocationDir) {
            let backUpConfig = {
                reason4Backup: 'casual',
                backUpBaseLocationDir: backUpBaseLocationDir,
                backUpLocation2Restore: restoreBaseLocationDir,
                couchConnectUrl: 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT
            };

            await backUpController.restoreFromBackUp(backUpConfig);
            expect(shelljs.ls(backUpConfig.backUpLocation).length).to.be.at.least(1);
        }

        it('take BackUp', async function() {
            await takeBackUp();
        });

        it('create some data', async function() {
            await commonTestUtils2.createSomeData(false, true);
        });

        it('take backup', async function() {
            await takeBackUp();
        });

        it('Query Backup List', async function() {
            backUpList = await backUpController.getBackUpsList(backUpBaseLocationDir);
            expect(backUpList.length).to.equal(backUpLength);
        });

        it('Restore Backup State 1', async function() {
            let restoreDir = '';
            if (backUpList.length > 1) {
                restoreDir = backUpList[backUpList.length - 1];
                console.log(restoreDir);

                let databaseState = await getCouchDatabaseState();
                await restoreBackUp(restoreDir);
                await commonTestUtils.pgTimeOut(4000);

                databaseState = await getCouchDatabaseState();
                if (backUpDBStates.length > 1) {
                    let expectedDatabaseState = backUpDBStates[backUpDBStates.length - 2];
                    for (let dbSuffix in databaseState) {
                        expect(expectedDatabaseState[dbSuffix]).to.equal(databaseState[dbSuffix]);
                    }
                }
            }

        });

        it('Restore Backup State 2', async function() {
            let restoreDir = '';
            if (backUpList.length) {
                restoreDir = backUpList[backUpList.length - 2];
                console.log(restoreDir);

                let databaseState = await getCouchDatabaseState();
                await restoreBackUp(restoreDir);
                await commonTestUtils.pgTimeOut(4000);

                databaseState = await getCouchDatabaseState();
                if (backUpDBStates.length) {
                    let expectedDatabaseState = backUpDBStates[backUpDBStates.length - 1];
                    for (let dbSuffix in databaseState) {
                        expect(expectedDatabaseState[dbSuffix]).to.equal(databaseState[dbSuffix]);
                    }
                }
            }
        });

    });
})();