"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Appointment_1 = require("../../../controllers/Appointment");
const chai_1 = require("chai");
// if you used the '@types/mocha' method to install mocha type definitions, uncomment the following line
// import 'mocha';
describe('Hello function', () => {
    it('should return hello world', () => {
        let data = {};
        let out = Appointment_1.postAppointment(data);
        console.log(out);
        chai_1.expect(out).to.equal({ code: "skd", message: "skgkf" });
    });
});
