(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var userDBInstance = couchDBUtils.getUserCouchDB();
    const coreDBInstancce = couchDBUtils.getCoreCouchDB();
    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const migrationHandler = require('../../../couchDb/migrationHandler');

    describe('Elemets Controller UTs  ', function(done) {
        let APP_TYPE = process.env.APP_TYPE;
        this.timeout(100000);
        before(function() {
            return couchDbManager.initCouchDb(true);
        });

        //Todo: Delete all Fs created. Get proper path of logDir 
        after(function() {

        });

        beforeEach(function() {});
        it('down test', async function() {
            await migrationHandler.migrate('201708030000000-customerId.js');
            let allUsers = await couchDBUtils.getView('employees', 'all', {}, userDBInstance);
            var allUsersDoc = [];
            for (var i = 0; i < allUsers.length; i++) {

                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                // if (allUsers[i].value.roles[1] === 'admin') {
                // console.log(allUsers[i].value.roles[0].reports);
                expect(allUsers[i].value.roles[0].reports.hasOwnProperty('gstreports')).to.equal(false);
                expect(allUsers[i].value.roles[0].payments.hasOwnProperty('sendSms')).to.equal(false);
                expect(allUsers[i].value.roles[0].payments.hasOwnProperty('sendEmail')).to.equal(false);

                expect(allUsers[i].value.roles[0].customers.sendSms.hasOwnProperty('apis')).to.equal(false);
                expect(allUsers[i].value.roles[0].customers.sendSms.hasOwnProperty('common')).to.equal(false);
                expect(allUsers[i].value.roles[0].employees.sendSms.hasOwnProperty('apis')).to.equal(false);
                expect(allUsers[i].value.roles[0].employees.sendSms.hasOwnProperty('common')).to.equal(false);
                expect(allUsers[i].value.roles[0].suppliers.sendSms.hasOwnProperty('apis')).to.equal(false);
                expect(allUsers[i].value.roles[0].suppliers.sendSms.hasOwnProperty('common')).to.equal(false);
                expect(allUsers[i].value.roles[0].inProgress.placeorderToSuppliers.sendSms.hasOwnProperty('apis')).to.equal(false);
                expect(allUsers[i].value.roles[0].inProgress.placeorderToSuppliers.sendSms.hasOwnProperty('common')).to.equal(false);

            }
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
            expect(applicationSettings.hasOwnProperty('taxProfile')).to.equal(false);
            expect(applicationSettings.enableSMS.hasOwnProperty('afterSale')).to.equal(false);
            expect(applicationSettings.enableSMS.hasOwnProperty('afterPurchase')).to.equal(false);
            expect(applicationSettings.enableSMS.hasOwnProperty('toCustomer')).to.equal(false);
            expect(applicationSettings.enableSMS.hasOwnProperty('toOwner')).to.equal(false);
            expect(applicationSettings.enableSMS.hasOwnProperty('counter')).to.equal(false);
            expect(applicationSettings.enableSMS.hasOwnProperty('quota')).to.equal(false);

        });

        it('up test', async function() {
            await migrationHandler.migrate('201708090000000-applicationSettingsAndUserPermissions.js');
            let allUsers = await couchDBUtils.getView('employees', 'all', {}, userDBInstance);

            let bUpdate = false;
            for (var i = 0; i < allUsers.length; i++) {

                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                // console.log(allUsers[i].value.roles[0].reports);
                expect(allUsers[i].value.roles[0].reports.hasOwnProperty('gstreports')).to.equal(true);
                expect(allUsers[i].value.roles[0].payments.hasOwnProperty('sendSms')).to.equal(true);
                expect(allUsers[i].value.roles[0].payments.hasOwnProperty('sendEmail')).to.equal(true);

                expect(allUsers[i].value.roles[0].customers.sendSms.apis.indexOf('/common/sendSMS')).to.gte(0);
                expect(allUsers[i].value.roles[0].customers.sendSms.hasOwnProperty('common')).to.equal(true);
                expect(allUsers[i].value.roles[0].employees.sendSms.apis.indexOf('/common/sendSMS')).to.gte(0);
                expect(allUsers[i].value.roles[0].employees.sendSms.hasOwnProperty('common')).to.equal(true);
                expect(allUsers[i].value.roles[0].suppliers.sendSms.apis.indexOf('/common/sendSMS')).to.gte(0);
                expect(allUsers[i].value.roles[0].suppliers.sendSms.hasOwnProperty('common')).to.equal(true);
                expect(allUsers[i].value.roles[0].inProgress.placeorderToSuppliers.sendSms.apis.indexOf('/common/sendSMS')).to.gte(0);
                expect(allUsers[i].value.roles[0].inProgress.placeorderToSuppliers.sendSms.hasOwnProperty('common')).to.equal(true);

            }
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);

            expect(applicationSettings.hasOwnProperty('taxProfile')).to.equal(true);
            expect(applicationSettings.enableSMS.hasOwnProperty('afterSale')).to.equal(true);
            expect(applicationSettings.enableSMS.hasOwnProperty('afterPurchase')).to.equal(true);
            expect(applicationSettings.enableSMS.hasOwnProperty('toCustomer')).to.equal(true);
            expect(applicationSettings.enableSMS.hasOwnProperty('toOwner')).to.equal(true);
            expect(applicationSettings.enableSMS.hasOwnProperty('counter')).to.equal(true);
            expect(applicationSettings.enableSMS.hasOwnProperty('quota')).to.equal(true);

        });

    });

})();