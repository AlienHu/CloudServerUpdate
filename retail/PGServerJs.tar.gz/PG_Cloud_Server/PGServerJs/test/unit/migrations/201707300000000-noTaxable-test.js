(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const migrationHandler = require('../../../couchDb/migrationHandler');
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    const coreDBInstancce = couchDBUtils.getCoreCouchDB();
    const mainDBInstance = couchDBUtils.getMainCouchDB();

    /**
     * Note: In this test it is down-up
     * Creating data, going down, then going up
     * This way actual validations can happen
     */

    describe('NO Taxable Migration UTs  ', function(done) {

        this.timeout(100000);
        before(async function() {
            await couchDbManager.initCouchDb(true);
            let commonUtils2 = require('../../common/commonUtils2');
            //Creating some customers
            await commonUtils2.createElements('customer', {}, 10);
        });

        after(function() {

        });

        beforeEach(function() {});

        it('down test', async function() {
            await migrationHandler.migrate('201707261843000-licence.js');
            let allCustomers = await couchDBUtils.getAllDocsByType('customer', mainDBInstance);
            for (let i = 0; i < allCustomers.length; i++) {
                expect(allCustomers[i].doc.taxable).to.equal(1);
            }
            let appSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
            expect(appSettings.itemType.hasOwnProperty('Liquor')).to.equal(false);
        });

        it('up test', async function() {
            await migrationHandler.migrate('201707300000000-noTaxable.js');
            let allCustomers = await couchDBUtils.getAllDocsByType('customer', mainDBInstance);
            for (let i = 0; i < allCustomers.length; i++) {
                expect(allCustomers[i].doc.hasOwnProperty('taxable')).to.equal(false);
            }
            let appSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
            expect(appSettings.itemType.Liquor).to.equal('Liquor');
        });

    });

})();