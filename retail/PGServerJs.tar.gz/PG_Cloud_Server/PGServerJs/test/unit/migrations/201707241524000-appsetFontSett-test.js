(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var coreDBInstance = couchDBUtils.getCoreCouchDB();
    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const migrationHandler = require('../../../couchDb/migrationHandler');

    describe('Elemets Controller UTs  ', function(done) {

        this.timeout(100000);
        before(function() {
            migrationHandler.migrate('201707241524000-appsetFontSett.js');
        });

        //Todo: Delete all Fs created. Get proper path of logDir
        after(function() {

        });

        beforeEach(function() {});

        it('up test', async function() {
            //query appsettingjson and make sure key is presnet

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstance);
            expect(typeof applicationSettings.paperReceipt).equal('object');
            expect(applicationSettings.paperReceipt.headerFont).equal(12);
            expect(applicationSettings.paperReceipt.headerInfoFont).equal(12);
            expect(applicationSettings.paperReceipt.itemHeaderFont).equal(12);
            expect(applicationSettings.paperReceipt.itemInfoFont).equal(12);
            expect(applicationSettings.paperReceipt.footerHeaderFont).equal(12);
            expect(applicationSettings.paperReceipt.footerInfoFont).equal(12);
        });

        it('down test', async function() {
            await migrationHandler.migrate('201707201315000-appDistributorEmail.js');
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstance);
            expect(applicationSettings.paperReceipt.hasOwnProperty('headerFont')).equal(false);
            expect(applicationSettings.paperReceipt.hasOwnProperty('headerInfoFont')).equal(false);
            expect(applicationSettings.paperReceipt.hasOwnProperty('itemHeaderFont')).equal(false);
            expect(applicationSettings.paperReceipt.hasOwnProperty('itemInfoFont')).equal(false);
            expect(applicationSettings.paperReceipt.hasOwnProperty('footerHeaderFont')).equal(false);
            expect(applicationSettings.paperReceipt.hasOwnProperty('footerInfoFont')).equal(false);
        });

    });

})();