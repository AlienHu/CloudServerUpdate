(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const migrationHandler = require('../../../couchDb/migrationHandler');
    const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    const licenceDBInstance = couchDBUtils.getLicenceDB();

    describe('Licence Migration UTs  ', function(done) {

        this.timeout(100000);
        before(function() {

        });

        //Todo: Delete all Fs created. Get proper path of logDir
        after(function() {

        });

        beforeEach(function() {});

        it('up test', async function() {
            await migrationHandler.migrate('201707261843000-licence.js');
            let queryResponse = await licenceDBInstance.fetch({}, {
                startkey: 'l',
                endkey: 'm'
            });
            let allDocs = queryResponse[0].rows;
            for (let i = 0; i < allDocs.length; i++) {
                if (allDocs[i].doc.clientType === 'DeskTopApp') {
                    //checking if the docs are updated
                    expect(allDocs[i].doc.hasOwnProperty('createTimeStamp')).to.equal(true);
                }
            }
        });

        it('down test', async function() {
            await migrationHandler.migrate('201707241524000-appsetFontSett.js');
        });

    });

})();