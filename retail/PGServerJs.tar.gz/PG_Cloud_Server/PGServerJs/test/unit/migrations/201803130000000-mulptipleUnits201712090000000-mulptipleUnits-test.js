'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDb = couchDBUtils.getMainCouchDB();
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');
const utils = require('../../common/Utils');
const commonUtils = require('../../common/commonUtils');
let commonUtils2;

describe('Migration Tests', function() {
    this.timeout(200000);

    let prevItems;
    let prevPurchases;
    let curPurchases;
    let prevSales;
    let curSales;

    before(async function() {
        let bResetDB = true;
        await couchDbManager.initCouchDb(bResetDB);
        if (bResetDB) {
            commonUtils2 = require('../../common/commonUtils2');
            await commonUtils.createAllItemTypes(true, true);
            await commonUtils2.createSomeData(true, false, 3, 3);
            await commonUtils.pgTimeOut(20000);
            // process.exit(0);
        } else {

        }
        // process.exit(0);
    });

    it('down', async function() {
        var bExpect = false;
        await migrationHandler.migrate('201711271653000-printHeadNewOptions.js');
        let allItemsDocs = await couchDBUtils.getAllDocsByType('item', mainDb);
        for (var i = 0; i < allItemsDocs.length; i++) {
            expect(allItemsDocs[i].doc.info.hasOwnProperty('unitsInfo')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('sellingPrice')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('purchasePrice')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('sellingUnitId')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('purchaseUnitId')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('conversionFactor')).to.equal(true);

            expect(allItemsDocs[i].doc.info.hasOwnProperty('baseUnitId')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('defaultPurchaseUnitId')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('defaultSellingUnitId')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bAutoComputePurchasePrice')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bAutoComputeMRP')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bAutoComputeSellingPrice')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('unitsInfo')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bMultipleUnits')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bPProfiles')).to.equal(false);

            for (var j = 0; j < allItemsDocs[i].doc.batches.length; j++) {
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('mrp')).to.equal(true);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('sellingPrice')).to.equal(true);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('purchasePrice')).to.equal(true);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('discountId')).to.equal(true);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('unitsInfo')).to.equal(false);
            }
        }
        prevItems = await commonUtils.createAllItemTypes(true, true);
        // console.log(prevItems[0]);
        console.log(JSON.stringify(prevItems[0].batches[0]));
        console.log("====================================");

        /**
         * Purchse Multiple Units
         */
        let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', mainDb);
        for (var j = 0; j < allPurchaseDocs.length; j++) {
            for (var k = 0; k < allPurchaseDocs[j].doc.receiving_items.length; k++) {
                expect(allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('unitId')).to.equal(false);
                expect(allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('baseUnitId')).to.equal(false);
                expect(allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('unitsInfo')).to.equal(false);
            }
        }
        prevPurchases = allPurchaseDocs;

        /**
         * Sales Multiple Units
         */
        let allSalesDocs = await couchDBUtils.getAllDocsByType('sale', mainDb);
        for (var p = 0; p < allSalesDocs.length; p++) {
            expect(allSalesDocs[p].doc.sales_info.hasOwnProperty('pProfileId')).to.equal(false);
            for (var q = 0; q < allSalesDocs[p].doc.sale_items.length; q++) {
                expect(allSalesDocs[p].doc.sale_items[q].hasOwnProperty('unitId')).to.equal(false);
                expect(allSalesDocs[p].doc.sale_items[q].hasOwnProperty('baseUnitId')).to.equal(false);
                expect(allSalesDocs[p].doc.sale_items[q].hasOwnProperty('unitsInfo')).to.equal(false);
            }
        }
        prevSales = allSalesDocs;
    });

    it('up', async function() {
        //userentitlements
        //users
        await migrationHandler.migrate('201712090000000-mulptipleUnits.js');
        var bExpect = true;
        let allItemsDocs = await couchDBUtils.getAllDocsByType('item', mainDb);
        for (var i = 0; i < allItemsDocs.length; i++) {
            expect(allItemsDocs[i].doc.info.hasOwnProperty('unitsInfo')).to.equal(true);

            expect(allItemsDocs[i].doc.info.hasOwnProperty('sellingPrice')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('purchasePrice')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('sellingUnitId')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('purchaseUnitId')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('conversionFactor')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('category')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('discount')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('cost_price')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('unit_price')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('item_image')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('is_deleted')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('allow_alt_description')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('hasMeasurementUnit')).to.equal(false);

            expect(allItemsDocs[i].doc.info.hasOwnProperty('baseUnitId')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('defaultPurchaseUnitId')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('defaultSellingUnitId')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bAutoComputePurchasePrice')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bAutoComputeMRP')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bAutoComputeSellingPrice')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('unitsInfo')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bMultipleUnits')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bPProfiles')).to.equal(true);

            for (var j = 0; j < allItemsDocs[i].doc.batches.length; j++) {
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('mrp')).to.equal(false);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('sellingPrice')).to.equal(false);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('purchasePrice')).to.equal(false);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('discountId')).to.equal(false);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('unitsInfo')).to.equal(true);
            }
        }
        let upItems = await commonUtils.createAllItemTypes(true, true);
        console.log(JSON.stringify(upItems[0].batches[0]));
        console.log("====================================");

        /**
         * Purchse Multiple Units
         */
        let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', mainDb);
        for (var j = 0; j < allPurchaseDocs.length; j++) {
            for (var k = 0; k < allPurchaseDocs[j].doc.receiving_items.length; k++) {
                expect(allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('unitId')).to.equal(true);
                expect(allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('baseUnitId')).to.equal(true);
                expect(allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('unitsInfo')).to.equal(true);
            }
        }

        /**
         * Sales Multiple Units
         */
        let allSalesDocs = await couchDBUtils.getAllDocsByType('sale', mainDb);
        for (var p = 0; p < allSalesDocs.length; p++) {
            expect(allSalesDocs[p].doc.sales_info.hasOwnProperty('pProfileId')).to.equal(true);
            for (var q = 0; q < allSalesDocs[p].doc.sale_items.length; q++) {
                expect(allSalesDocs[p].doc.sale_items[q].hasOwnProperty('unitId')).to.equal(true);
                expect(allSalesDocs[p].doc.sale_items[q].hasOwnProperty('baseUnitId')).to.equal(true);
                expect(allSalesDocs[p].doc.sale_items[q].hasOwnProperty('unitsInfo')).to.equal(true);
            }
        }

    });

    it('down', async function() {
        var bExpect = false;
        await migrationHandler.migrate('201711271653000-printHeadNewOptions.js');
        let allItemsDocs = await couchDBUtils.getAllDocsByType('item', mainDb);
        for (var i = 0; i < allItemsDocs.length; i++) {
            expect(allItemsDocs[i].doc.info.hasOwnProperty('unitsInfo')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('sellingPrice')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('purchasePrice')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('sellingUnitId')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('purchaseUnitId')).to.equal(true);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('conversionFactor')).to.equal(true);

            expect(allItemsDocs[i].doc.info.hasOwnProperty('baseUnitId')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('defaultPurchaseUnitId')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('defaultSellingUnitId')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bAutoComputePurchasePrice')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bAutoComputeMRP')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bAutoComputeSellingPrice')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('unitsInfo')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bMultipleUnits')).to.equal(false);
            expect(allItemsDocs[i].doc.info.hasOwnProperty('bPProfiles')).to.equal(false);

            for (var j = 0; j < allItemsDocs[i].doc.batches.length; j++) {
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('mrp')).to.equal(true);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('sellingPrice')).to.equal(true);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('purchasePrice')).to.equal(true);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('discountId')).to.equal(true);
                expect(allItemsDocs[i].doc.batches[j].hasOwnProperty('unitsInfo')).to.equal(false);
            }
        }

        let curItems = await commonUtils.createAllItemTypes(true, true);
        let errorsArray = [];
        let resp = utils.compareArray(prevItems, curItems, 0, [], errorsArray, '');
        console.log(JSON.stringify(curItems[0].batches[0]));
        console.log("=========Items==========")
        console.log(errorsArray);
        console.log("====================================");

        expect(resp).to.equal(true);
        // setTimeout(async function() {
        /**
         * Purchse Multiple Units
         */
        let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', mainDb);
        for (var j = 0; j < allPurchaseDocs.length; j++) {
            for (var k = 0; k < allPurchaseDocs[j].doc.receiving_items.length; k++) {
                expect(allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('unitId')).to.equal(false);
                expect(allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('baseUnitId')).to.equal(false);
                expect(allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('unitsInfo')).to.equal(false);
            }
        }
        curPurchases = allPurchaseDocs;
        let purErrorsArray = [];
        let resp1 = utils.compareArray(prevPurchases, curPurchases, 0, ['rev', '_rev'], purErrorsArray, '');
        console.log("=========Purchase==========")
        console.log(purErrorsArray);
        console.log("=================")
        expect(resp1).to.equal(true);
        // }, 100);

        /**
         * Sales Multiple Units
         */
        // setTimeout(async function() {
        let allSalesDocs = await couchDBUtils.getAllDocsByType('sale', mainDb);
        for (var p = 0; p < allSalesDocs.length; p++) {
            expect(allSalesDocs[p].doc.sales_info.hasOwnProperty('pProfileId')).to.equal(false);
            for (var q = 0; q < allSalesDocs[p].doc.sale_items.length; q++) {
                expect(allSalesDocs[p].doc.sale_items[q].hasOwnProperty('unitId')).to.equal(false);
                expect(allSalesDocs[p].doc.sale_items[q].hasOwnProperty('baseUnitId')).to.equal(false);
                expect(allSalesDocs[p].doc.sale_items[q].hasOwnProperty('unitsInfo')).to.equal(false);
            }
        }
        curSales = allSalesDocs;
        let saleErrorsArray = [];
        let resp2 = utils.compareArray(prevSales, curSales, 0, ['rev', '_rev'], saleErrorsArray, '');
        console.log("=========Sales==========")
        console.log(saleErrorsArray);
        console.log("=================")
        expect(resp2).to.equal(true);
        // }, 100);
    });

});