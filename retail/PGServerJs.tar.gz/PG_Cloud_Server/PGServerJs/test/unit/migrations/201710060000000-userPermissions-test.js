   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   const coreDBInstancce = couchDBUtils.getCoreCouchDB();
   const usersDBInstance = couchDBUtils.getUserCouchDB();
   const couchDbManager = require('../../../dbManagers/couchDbManager');
   const migrationHandler = require('../../../couchDb/migrationHandler');

   describe('Migration Tests', function() {
       this.timeout(200000);
       before(async function() {
           await couchDbManager.initCouchDb(false);

       });

       it('down', async function() {
           await migrationHandler.migrate('201710041100000-invoiceNew.js');
           let params = {};
           let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
           for (var i = 0; i < allUsers.length; i++) {
               allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
               expect(allUsers[i].value.roles[0].sales.hasOwnProperty("apis")).to.equal(false);
               expect(allUsers[i].value.roles[0].purchases.hasOwnProperty("apis")).to.equal(false);
               expect(allUsers[i].value.roles[0].takeAway.hasOwnProperty("apis")).to.equal(false);
               if (allUsers[i].value.APP_TYPE === 'retail') {
                   expect(allUsers[i].value.roles[0].sales.makeSale.apis.indexOf("printSaleRestApi")).to.equal(-1);
                   expect(allUsers[i].value.roles[0].sales.makeReturn.apis.indexOf("printSaleRestApi")).to.equal(-1);
                   expect(allUsers[i].value.roles[0].hasOwnProperty('sales')).to.equal(true);
               }
               if (allUsers[i].value.APP_TYPE === 'restaurant') {
                   expect(allUsers[i].value.roles[0].hasOwnProperty('takeAway')).to.equal(true);
                   expect(allUsers[i].value.roles[0].hasOwnProperty('tables')).to.equal(true);
                   expect(allUsers[i].value.roles[0].takeAway.makeSale.apis.indexOf("printSaleRestApi")).to.equal(-1);
                   expect(allUsers[i].value.roles[0].takeAway.makeReturn.apis.indexOf("printSaleRestApi")).to.equal(-1);
               }
               if (allUsers[i].value.APP_TYPE === 'petrolbunk') {
                   expect(allUsers[i].value.roles[0].hasOwnProperty('petrolbunk')).to.equal(true);
               }
               if (allUsers[i].value.APP_TYPE === 'lodging') {
                   expect(allUsers[i].value.roles[0].hasOwnProperty('hotel')).to.equal(true);
               }

           }
       });

       it('up', async function() {
           await migrationHandler.migrate('201710060000000-userPermissions.js');
           let params = {};
           let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);

           for (var i = 0; i < allUsers.length; i++) {
               allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
               expect(allUsers[i].value.roles[0].sales.hasOwnProperty("apis")).to.equal(true);
               expect(allUsers[i].value.roles[0].takeAway.hasOwnProperty("apis")).to.equal(true);
               expect(allUsers[i].value.roles[0].purchases.hasOwnProperty("apis")).to.equal(true);
               expect(allUsers[i].value.roles[0].sales.apis.indexOf("getSalesRestApi")).to.not.equal(-1);
               expect(allUsers[i].value.roles[0].takeAway.apis.indexOf("getSalesRestApi")).to.not.equal(-1);
               expect(allUsers[i].value.roles[0].purchases.apis.indexOf("getReceivingsRestApi")).to.not.equal(-1);

               if (allUsers[i].value.APP_TYPE === 'restaurant') {
                   console.log(allUsers[i].value.name);
                   expect(allUsers[i].value.roles[0].takeAway.makeSale.apis.indexOf("printSaleRestApi")).to.not.equal(-1);
                   expect(allUsers[i].value.roles[0].takeAway.makeReturn.apis.indexOf("printSaleRestApi")).to.not.equal(-1);
               } else if (allUsers[i].value.APP_TYPE === 'retail') {
                   console.log(allUsers[i].value.name);
                   expect(allUsers[i].value.roles[0].sales.makeSale.apis.indexOf("printSaleRestApi")).to.not.equal(-1);
                   expect(allUsers[i].value.roles[0].sales.makeReturn.apis.indexOf("printSaleRestApi")).to.not.equal(-1);
               }

               if (allUsers[i].value.APP_TYPE !== 'retail') {
                   expect(allUsers[i].value.roles[0].hasOwnProperty('sales')).to.equal(false);
               }
               if (allUsers[i].value.APP_TYPE !== 'restaurant') {
                   expect(allUsers[i].value.roles[0].hasOwnProperty('takeAway')).to.equal(false);
                   expect(allUsers[i].value.roles[0].hasOwnProperty('tables')).to.equal(false);
               }
               if (allUsers[i].value.APP_TYPE !== 'petrolbunk') {
                   expect(allUsers[i].value.roles[0].hasOwnProperty('petrolbunk')).to.equal(false);
               }
               if (allUsers[i].value.APP_TYPE !== 'lodging') {
                   expect(allUsers[i].value.roles[0].hasOwnProperty('hotel')).to.equal(false);
               }

           }

       });

   });