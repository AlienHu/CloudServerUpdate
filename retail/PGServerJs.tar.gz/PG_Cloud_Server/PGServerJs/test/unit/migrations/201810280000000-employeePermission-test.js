'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
// let nanoClients = params.nanoClients;
// let nanoCore = nanoClients.coredb;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const coreDBInstancce = couchDBUtils.getCoreCouchDB();
const usersDBInstance = couchDBUtils.getUserCouchDB();
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');
const mainDBInstance = couchDBUtils.getMainCouchDB();
describe('Migration Tests', function() {
    this.timeout(200000);
    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    it('up', async function() {
        await migrationHandler.migrate('201807280000000-employeePermission.js');
        // var applicationSetting = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);

        // let allUsers = await couchDBUtils.getView('employees', 'all', {}, usersDBInstance);
        let allUsers = await couchDBUtils.getAllUserDocs(usersDBInstance, {}, true);
        let allUsersDoc = [];

        for (let i = 0; i < allUsers.length; i++) {
            if (!allUsers[i].roles[0]) continue;
            try {
                allUsers[i].roles[0] = JSON.parse(allUsers[i].roles[0]);
            } catch (error) {
                logger.error(error);
                continue;
            }

            let APP_TYPE = allUsers[i].APP_TYPE;

            // console.log(allUsers[i])
            let reportObj = allUsers[i].roles[0].reports;
            let tablesObject = allUsers[i].roles[0].tables;
            let hdObject = allUsers[i].roles[0].homeDelivery;
            let taObject = allUsers[i].roles[0].takeAway;
            let salesRestaurantObj = allUsers[i].roles[0].salesRestaurant;
            let salesObj = allUsers[i].roles[0].sales;
            let soObject = allUsers[i].roles[0].salesOrder;
            let sqObject = allUsers[i].roles[0].salesQuotation;

            if (APP_TYPE === "restaurant") {
                tableUMigrationTest();
                salesURestaurantMigrationTest();
                taUMigrationTest(taObject); // Take Away
                checkAddNewModuleObj(); // BOM | PP | US | AR  
            } else if (APP_TYPE === "retail") {
                taUMigrationTest(salesObj); // Sales for retail
            }

            if (APP_TYPE === "restaurant" || APP_TYPE === "retail") {
                hdUMigrationTest();
                reportUMigrationTest();
                checkCommonNewModule(); // Expenses
            }

            function checkDeleteModuleUObject(obj_field_Arr, object) {
                for (var i = 0; i < obj_field_Arr.length; i++) {
                    expect(object.hasOwnProperty(obj_field_Arr[i])).to.equal(false);
                }
            };

            function checkAddedObject(objArr, obj) {
                for (var i = 0; i < objArr.length; i++) {
                    expect(obj.hasOwnProperty(objArr[i])).to.equal(true);
                }
            };

            function tableUMigrationTest() {
                if (!tablesObject) {
                    return
                }

                const tablesFeature = ['createTable', 'deleteTable'];
                const tableApi = ["createtablerestapi", "deleteTableApiRestApi", "mergeTables", "changeTable"];
                const tab_obj_filed_arr = ["billSplit", "completeOrder", "takePayment", "editDiscounts", "editKot", "cancelOreder", "takeOrder", "editDiscount", "editPrice"];

                expect(tablesObject.hasOwnProperty('changeTable')).to.equal(true);
                expect(tablesObject.hasOwnProperty('mergeTable')).to.equal(true);
                checkDeletedApiFunc(tablesFeature, tablesObject);
                checkApiAddedFunc(tableApi, tablesObject.apis);
                checkDeleteModuleUObject(tab_obj_filed_arr, tablesObject);
            }

            function salesURestaurantMigrationTest() {
                const saleRestaurantApi = ["additemRestApi",
                    "add_paymentRestApi",
                    "completeSaleRestApi",
                    "getCartTaxes",
                    "addCustomer2SaleRestApi",
                    "receiptRestApi",
                    "printReceiptApi",
                    "setPrintAfterSaleRestApi",
                    "setInvoiceNumberEnabledRestApi",
                    "setInvoiceNumberRestApi",
                    "invoiceRestApi",
                    "DeleteItemFromCartRestApi",
                    "getItemsRestApi",
                    "checkAlreadyReservedRestApi",
                    "getReservationDetails",
                    "cancel_saleRestApi",
                    "saveTableOrderRestApi",
                    "getSalesRestApi",
                    "getItemsForTableOrderRestApi",
                    "loadAllOrderItemBeforeCheckOutRestApi",
                    "addEmployee2SaleRestApi",
                    "getOrderBill",
                    "loadKotToCartRestApi",
                    "editItemRestApi",
                    "deleteOrdersOfTableRestApi",
                    "deleteTableApiRestApi",
                    "changeTable",
                    "mergeTables",
                    "completeTakeOrderRestApi",
                    "addCustomer2OrdersRestApi",
                    "quickSaleRestApi",
                    "saveGlobalDiscount"
                ];

                const salesRestaurantObjArr = ['takeOrder', 'editPrice', 'editDiscount', 'editKot', 'takePayment', 'completeOrder',
                    'spotDiscount', 'printBill', 'deleteOrder', 'multiplePrintBill', 'kotReport'
                ];

                expect(allUsers[i].roles[0].hasOwnProperty('salesRestaurant')).to.equal(true);
                checkAddedObject(salesRestaurantObjArr, salesRestaurantObj);
                checkApiAddedFunc(saleRestaurantApi, salesRestaurantObj.takeOrder.apis);
            }

            function taUMigrationTest(commonObject) {
                const taFeature = ['editPrice', 'editDiscount', 'suspendSales', 'unsuspendSales'];
                const ta_salesHistory_Feature = ['view', 'update', 'delete'];
                const ta_makeSales = ["addEmployee2SaleRestApi",
                    "editItemRestApi",
                    "setGlobalDiscount",
                    "addCustomer2OrdersRestApi",
                    "quickSaleRestApi",
                    "suspendSaleRestApi",
                    "allSuspendedSalesRestApi",
                    "unsuspendSaleRestApi",
                    "update",
                    "delete_paymentRestApi",
                    "deleteSuspendedSale",
                    "setLocalTax",
                    "updateApplicationSettings"
                ];

                checkDeletedApiFunc(taFeature, commonObject);
                checkDeletedApiFunc(ta_salesHistory_Feature, commonObject.salesHistory);
                checkApiAddedFunc(ta_makeSales, commonObject.makeSale.apis);
                let index1 = commonObject.makeReturn.apis.indexOf('completeReturn');
                expect(index1 === -1).to.equal(false);
                expect(commonObject.hasOwnProperty('saleSetting')).to.equal(true);
                expect(commonObject.hasOwnProperty('globalDiscount')).to.equal(true);
                expect(commonObject.hasOwnProperty('viewOthersSuspendedSales')).to.equal(false);
            }

            function hdUMigrationTest() {
                // if (!hdObject) {
                //     return
                // }
                // const hdFeature = ['editOrder', 'completeDelivery', 'deleteOrder'];
                //const hd_obj_filed_arr = ['takeOrder', 'viewOrder', 'takeOrderPayment'];
                const addedObjArr = ['homeDelivery', 'sendSms', 'newOrder', 'printBill', 'editPrice', 'editDiscount', 'globalDiscount', 'saleSetting', 'editOrder', 'completeDelivery', 'deleteOrder']
                const hd_api_arr = [
                    "addCustomer2OrdersRestApi",
                    "saveDeliveryRetailRestApi",
                    "additemRestApi",
                    "cancel_saleRestApi",
                    "getCartTaxes",
                    "editItemRestApi",
                    "getEditRestApi",
                    "removeitemRestApi",
                    "getItemDiscountRestApi",
                    "DeleteItemFromCartRestApi",
                    "getItemsRestApi",
                    "getSalesRestApi",
                    "saveHDOrderRestApi",
                    "loadHDOrderRestApi",
                    "printHDOrderRestApi",
                    "addCustomer2SaleRestApi",
                    "add_paymentRestApi",
                    "completeHDOrder",
                    "quickHDOrder",
                    "setLocalTax",
                    "updateApplicationSettings"
                ];

                //checkDeleteModuleUObject(hd_obj_filed_arr, hdObject);
                //checkDeletedApiFunc(hdFeature, hdObject);
                checkAddedObject(addedObjArr, hdObject);
                checkApiAddedFunc(hd_api_arr, hdObject.homeDelivery.apis);
                expect(hdObject.sendSms.apis[0]).equal("/common/sendSMS");
                expect(hdObject.sendSms.common).equal(true);

            }

            function reportUMigrationTest() {
                const reportApi = ["common/sendEmailApi", "gstr1_12", "gstr2"]
                const reportFeature = ["purchases",
                    "items",
                    "employees",
                    "suppliers",
                    "sales",
                    "discounts",
                    "taxes",
                    "inventory",
                    "categories",
                    "payments",
                    "customers",
                    "gstreports"
                ]
                checkDeletedApiFunc(reportFeature, reportObj);
                checkApiAddedFunc(reportApi, reportObj.apis);
                expect(reportObj.sales.salesHistory.apis).to.equal(undefined);
                expect(reportObj.hasOwnProperty('editSale')).to.equal(true);
                expect(reportObj.hasOwnProperty('rejectSale')).to.equal(true);
                expect(reportObj.hasOwnProperty('deleteSale')).to.equal(true);
                expect(reportObj.hasOwnProperty('purchaseEdit')).to.equal(true);
                expect(reportObj.hasOwnProperty('purchaseReject')).to.equal(true);
                expect(reportObj.hasOwnProperty('purchaseDelete')).to.equal(true);
            }

            function checkDeletedApiFunc(salesFeature, salesObject) {
                for (var i = 0; i < salesFeature.length; i++) {
                    expect(salesObject[salesFeature[i]].apis).to.equal(undefined);
                }
            };

            function checkApiAddedFunc(addedApiArr, object) {
                for (var i = 0; i < addedApiArr.length; i++) {
                    let index = object.indexOf(addedApiArr[i]);
                    // console.log(index,addedApiArr[i]);
                    expect(index > -1).equal(true);
                }
            }

            function checkAddNewModuleObj() {
                expect(allUsers[i].roles[0].hasOwnProperty('bom')).equal(true);
                expect(allUsers[i].roles[0].hasOwnProperty('productionPlanning')).equal(true);
                expect(allUsers[i].roles[0].hasOwnProperty('updateStock')).equal(true);
            }

            function checkCommonNewModule() {
                expect(allUsers[i].roles[0].hasOwnProperty('autoReporter')).equal(true);
                let autoReportObj = allUsers[i].roles[0].autoReporter;
                expect(autoReportObj.apis[0]).equal("crm/autoReporter");

                expect(allUsers[i].roles[0].hasOwnProperty('expenses')).equal(true);
                checkSaleQuotationModule();
                // expect(allUsers[i].roles[0].hasOwnProperty('salesQuotation')).equal(true);
                expect(allUsers[i].roles[0].hasOwnProperty('tally')).equal(true);
                checkSalesOrderModule();
            }

            function checkSalesOrderModule() {

                let so_sales_api_arr = [
                    "addCustomer2OrdersRestApi",
                    "saveDeliveryRetailRestApi",
                    "saveDeliveryRestApi",
                    "additemRestApi",
                    "cancel_saleRestApi",
                    "getCartTaxes",
                    "editItemRestApi",
                    "getEditRestApi",
                    "removeitemRestApi",
                    "getItemDiscountRestApi",
                    "DeleteItemFromCartRestApi",
                    "getItemsRestApi",
                    "getSalesRestApi",
                    "addCustomer2SaleRestApi",
                    "add_paymentRestApi",
                    "setLocalTax",
                    "updateApplicationSettings",
                    "saveSOOrderRestApi",
                    "loadSOOrderRestApi",
                    "printSOOrderRestApi",
                    "completeSOOrderRestApi",
                    "quickSOOrderRestApi",
                    "addEmployee2SaleRestApi",
                    "setGlobalDiscount"
                ];

                let salesOrderObjArr = ['sales', 'sendSms', 'newOrder', 'editOrder', 'deleteOrder', 'printBill', 'editPrice', 'editDiscount', 'globalDiscount', 'saleSetting', 'checkOut', 'cancelOrder', 'advancePayment', 'editDeliveryInfo', 'report'];

                checkAddedObject(salesOrderObjArr, soObject);
                checkApiAddedFunc(so_sales_api_arr, soObject.sales.apis);
                expect(soObject.sendSms.apis[0]).equal("/common/sendSMS");
                expect(soObject.sendSms.common).equal(true);
            }

            function checkSaleQuotationModule() {

                let sq_api_arr = [
                    "saveSQRestApi",
                    "addCustomer2OrdersRestApi",
                    "saveDeliveryRetailRestApi",
                    "saveDeliveryRestApi",
                    "additemRestApi",
                    "cancel_saleRestApi",
                    "getCartTaxes",
                    "editItemRestApi",
                    "getEditRestApi",
                    "removeitemRestApi",
                    "getItemDiscountRestApi",
                    "DeleteItemFromCartRestApi",
                    "getItemsRestApi",
                    "getSalesRestApi",
                    "addCustomer2SaleRestApi",
                    "add_paymentRestApi",
                    "setLocalTax",
                    "updateApplicationSettings",
                    "saveSOOrderRestApi",
                    "loadSOOrderRestApi",
                    "printSOOrderRestApi",
                    "addEmployee2SaleRestApi",
                    "setGlobalDiscount"
                ];

                checkApiAddedFunc(sq_api_arr, sqObject.apis);
            }
        }

    });

    it('down', async function() {
        await migrationHandler.migrate('201807020000000-transformPurchaseDocs.js');
        // let allUsers = await couchDBUtils.getView('employees', 'all', {}, usersDBInstance);
        let allUsers = await couchDBUtils.getAllUserDocs(usersDBInstance, {}, true);
        let allUsersDoc = [];
        for (let i = 0; i < allUsers.length; i++) {
            if (!allUsers[i].roles[0]) continue;
            try {
                allUsers[i].roles[0] = JSON.parse(allUsers[i].roles[0]);
            } catch (error) {
                logger.error(error);
                continue;
            }

            let APP_TYPE = allUsers[i].APP_TYPE;

            let reportObj = allUsers[i].roles[0].reports;
            let tablesObject = allUsers[i].roles[0].tables;
            let hdObject = allUsers[i].roles[0].homeDelivery;
            let taObject = allUsers[i].roles[0].takeAway;
            let salesRestaurantObj = allUsers[i].roles[0].salesRestaurant;
            let salesObj = allUsers[i].roles[0].sales;

            if (APP_TYPE === "restaurant") {
                tableDMigrationTest();
                salesDRestaurantMigrationTest();
                taDMigrationTest(taObject); // Take Away
                checkDelNewModuleObj(); // BOM | PP | US | AR 
            } else if (APP_TYPE === "retail") {
                taDMigrationTest(salesObj); // Sales for retail
            }

            if (APP_TYPE === "restaurant" || APP_TYPE === "retail") {
                hdDMigrationTest();
                reportDMigrationTest();
                checkDelExpensesModule(); //Expenses
            }

            function tableDMigrationTest() {
                expect(tablesObject.apis).to.equal(undefined)
                const table_TO = ["additemRestApi",
                    "add_paymentRestApi",
                    "completeSaleRestApi",
                    "getCartTaxes",
                    "addCustomer2SaleRestApi",
                    "receiptRestApi",
                    "printReceiptApi",
                    "setPrintAfterSaleRestApi",
                    "setInvoiceNumberEnabledRestApi",
                    "setInvoiceNumberRestApi",
                    "invoiceRestApi",
                    "DeleteItemFromCartRestApi",
                    "getItemsRestApi",
                    "checkAlreadyReservedRestApi",
                    "getReservationDetails"
                ];
                const tableFeatureArr = ['changeTable', 'mergeTable'];
                const tablesFeature = {
                    "createTable": ["createTableRestApi"],
                    "deleteTable": ["deleteTableApiRestApi"],
                    "editPrice": ["editItemRestApi"],
                    "editDiscount": ["editItemRestApi"],
                    "cancelOreder": ["cancel_saleRestApi"],
                    "editKot": ["editSaveKOTRestApi"],
                    "editDiscounts": ["editItemRestApi"],
                    "takePayment": ["add_paymentRestApi"],
                    "completeOrder": ["completeTakeOrderRestApi"],
                    "billSplit": ["splitBillRestApi"],
                    "takeOrder": table_TO
                };

                checkDeleteObj(tableFeatureArr, tablesObject);
                checkAddApiFunc(tablesFeature, tablesObject);
            };

            function salesDRestaurantMigrationTest() {
                expect(allUsers[i].roles[0].salesRestaurant).to.equal(undefined);
            };

            function taDMigrationTest(commonDObj) {

                const taFeatureArr = ['saleSetting', 'globalDiscount'];
                const taFeature = {
                    "editPrice": ["editItemRestApi"],
                    "editDiscount": ["editItemRestApi", "getItemDiscountRestApi"],
                    "suspendSales": ["allSuspendedSalesRestApi", "suspendSaleRestApi"],
                    "unsuspendSales": ["unsuspendSaleRestApi"]
                }
                const ta_salesHistoryFeature = {
                    "view": ["handled@ClientSide", "manageRestApi"],
                    "update": ["update", "saveEditSalesRestApi"],
                    "delete": ["delete", "deleteSaleRestApi"]
                };

                const ta_makeSales = ["addEmployee2SaleRestApi",
                    "editItemRestApi",
                    "setGlobalDiscount",
                    "addCustomer2OrdersRestApi",
                    "quickSaleRestApi",
                    "suspendSaleRestApi",
                    "allSuspendedSalesRestApi",
                    "unsuspendSaleRestApi",
                    "update",
                    "delete_paymentRestApi",
                    "deleteSuspendedSale",
                    "setLocalTax",
                    "updateApplicationSettings"
                ];
                expect(commonDObj.hasOwnProperty('viewOthersSuspendedSales')).to.equal(true);

                checkDeleteObj(taFeatureArr, commonDObj);
                checkAddApiFunc(taFeature, commonDObj);
                checkAddApiFunc(ta_salesHistoryFeature, commonDObj.salesHistory);
                checkSpliceAddedApi(ta_makeSales, commonDObj.makeSale);
                let index1 = commonDObj.makeReturn.apis.indexOf('completeReturn');
                expect(index1 === -1).to.equal(true);
            }

            function hdDMigrationTest() {
                expect(hdObject.hasOwnProperty('takeOrderPayment')).equal(true);
                expect(hdObject.hasOwnProperty('takeOrder')).equal(true);
                expect(hdObject.hasOwnProperty('viewOrder')).equal(true);

                const hdFeatureArr = ['newOrder', 'homeDelivery', 'printBill', 'editPrice', 'editDiscount', 'globalDiscount', 'saleSetting'];
                const takeOrderApi = [
                    "addCustomer2OrdersRestApi",
                    "saveDeliveryRetailRestApi",

                    "additemRestApi",
                    "cancel_saleRestApi",
                    "getCartTaxes",
                    "editItemRestApi",
                    "getEditRestApi",
                    "removeitemRestApi",
                    "getItemDiscountRestApi",
                    "DeleteItemFromCartRestApi",

                    "getItemsRestApi"
                ];

                const hdFeature = {
                    "editOrder": ["getEditRestApi", "editItemRestApi"],
                    "viewOrder": ["allSuspendedSalesRestApi"],
                    "completeDelivery": ["completeDeliverySaleApiRestApi"],
                    "deleteOrder": ["deleteHomeDeliveryRestApi"],
                    "takeOrderPayment": ["add_paymentRestApi"],
                    "takeOrder": takeOrderApi
                }

                checkDeleteObj(hdFeatureArr, hdObject);
                checkAddApiFunc(hdFeature, hdObject);
            };

            function reportDMigrationTest() {
                const reportFeatureArr = ['editSale', 'rejectSale', 'deleteSale', 'purchaseEdit', 'purchaseReject', 'purchaseDelete']
                checkDeleteObj(reportFeatureArr, reportObj);
                const reportFeature = {
                    "purchases": ["DetailedEmpRestAPI"],
                    "items": ["graphicalSummaryItemGraphRestAPI", "SummaryItemRestAPI"],
                    "employees": ["graphicalSummaryEmployeeGraphRestAPI", "SummaryEmployeeRestAPI", "DetailedEmpRestAPI"],
                    "suppliers": ["graphicalSummarySupGraphRestAPI", "SummarySupplierRestAPI"],
                    "sales": ["graphicalSummarySaleGraphRestAPI", "SummarySaleRestAPI"],
                    "discounts": ["graphicalSummaryDiscountGraphRestAPI", "SummaryDiscountRestAPI", "DetailedDisRestAPI"],
                    "taxes": ["graphicalSummaryTaxGraphRestAPI", "SummaryDiscountRestAPI", "DetailedDisRestAPI"],
                    "inventory": ["LowInventoryRestAPI", "InventorySumRestAPI"],
                    "categories": ["graphicalSummaryCategoriesGraphRestAPI", "SummaryCategoryRestAPI"],
                    "payments": ["graphicalSummaryPaymentGraphRestAPI", "SummaryPaymentRestAPI"],
                    "customers": ["graphicalSummaryCustomerGraphRestAPI", "SummaryCustomerRestAPI", "DetailedCustRestAPI"],
                    "gstreports": ["gstr1_12", "gstr2"],
                };
                expect(reportObj.hasOwnProperty('apis')).equal(false);
                checkAddApiFunc(reportFeature, reportObj);
                let reportIndex = reportObj['sales'].salesHistory.apis.indexOf("DetailedSaleRestAPI");
                expect(reportIndex > -1).to.equal(true);
            }

            function checkDeleteObj(objectFeature, object) {
                for (var i = 0; i < objectFeature.length; i++) {
                    expect(object[objectFeature[i]]).to.equal(undefined)
                }
            };

            function checkAddApiFunc(salesFeature, salesObject) {
                for (let ele in salesFeature) {
                    let apis = salesObject[ele].apis;
                    for (var i = 0; i < apis.length; i++) {
                        let index = salesFeature[ele].indexOf(apis[i]);
                        expect(index > -1).to.equal(true);
                    }
                }
            }

            function checkSpliceAddedApi(addedApiArr, object) {
                for (let l = 0; l < addedApiArr.length; l++) {
                    let index = object.apis.indexOf(addedApiArr[l]);
                    // console.log(index,addedApiArr[l]);
                    expect(index === -1).to.equal(true);
                }
            }

            function checkDelNewModuleObj() {
                expect(allUsers[i].roles[0].hasOwnProperty("bom")).to.equal(false);
                expect(allUsers[i].roles[0].hasOwnProperty("productionPlanning")).to.equal(false);
                expect(allUsers[i].roles[0].hasOwnProperty("updateStock")).to.equal(false);
                expect(allUsers[i].roles[0].hasOwnProperty("autoReporter")).to.equal(false);

                expect(allUsers[i].roles[0].hasOwnProperty("salesOrder")).to.equal(false);
                expect(allUsers[i].roles[0].hasOwnProperty("salesQuotation")).to.equal(false);
                expect(allUsers[i].roles[0].hasOwnProperty("tally")).to.equal(false);
            }

            function checkDelExpensesModule() {
                expect(allUsers[i].roles[0].hasOwnProperty("expenses")).to.equal(false);
            }

        }

    });

});