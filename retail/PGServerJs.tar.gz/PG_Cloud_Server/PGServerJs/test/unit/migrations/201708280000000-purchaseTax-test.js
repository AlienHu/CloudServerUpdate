(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const migrationHandler = require('../../../couchDb/migrationHandler');
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    const coreDBInstancce = couchDBUtils.getCoreCouchDB();
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const testUtils = require('../../common/Utils');

    /**
     * Note: In this test it is down-up
     * Creating data, going down, then going up
     * This way actual validations can happen
     */

    describe('Purchase Migration UTs  ', function(done) {

        this.timeout(100000);
        before(async function() {
            await couchDbManager.initCouchDb(true);
            let commonUtils2 = require('../../common/commonUtils2');
            //Creating some customers
            await commonUtils2.createSomeData(true, true, 0, 21);
        });

        after(function() {

        });

        let taxList = [];

        it('down test', async function() {
            await migrationHandler.migrate('201708230000000-credit.js');

            let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance);
            for (let i = 0; i < allPurchaseDocs.length; i++) {
                let doc = allPurchaseDocs[i].doc;
                taxList.push(doc.receiving_item_taxes);
                for (let j = 0; j < doc.receiving_items.length; j++) {
                    expect(doc.receiving_items[j].hasOwnProperty('itemTaxList')).to.equal(false);
                }
            }

        });

        it('up test', async function() {
            await migrationHandler.migrate('201708280000000-purchaseTax.js');

            let newTaxList = [];
            let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance);
            for (let i = 0; i < allPurchaseDocs.length; i++) {
                let doc = allPurchaseDocs[i].doc;
                let tempTaxList = [];
                for (let j = 0; j < doc.receiving_items.length; j++) {
                    for (let k = 0; k < doc.receiving_items[j].itemTaxList.length; k++) {
                        tempTaxList.push({
                            name: doc.receiving_items[j].itemTaxList[k].name,
                            percent: doc.receiving_items[j].itemTaxList[k].percent,
                            item_id: doc.receiving_items[j].item_id,
                            stockKey: doc.receiving_items[j].stockKey
                        })
                    }
                }
                newTaxList.push(tempTaxList);
                console.log(tempTaxList.length);
            }

            expect(testUtils.compareArray(taxList, newTaxList)).to.equal(true);

        });

    });

})();