(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const migrationHandler = require('../../../couchDb/migrationHandler');
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    const coreDBInstancce = couchDBUtils.getCoreCouchDB();
    const mainDBInstance = couchDBUtils.getMainCouchDB();

    const utils = require('../../../controllers/common/Utils');
    const ARRAY_LENGTH = utils.getArrayLength;

    /**
     * Note: In this test it is down-up
     * Creating data, going down, then going up
     * This way actual validations can happen
     */

    describe('HSN ItemTypes Migration UTs  ', function(done) {

        this.timeout(100000);
        before(async function() {
            await couchDbManager.initCouchDb(true);
            let commonUtils2 = require('../../common/commonUtils2');
            //Creating some customers
            await commonUtils2.createSomeData(true, true);
        });

        after(function() {

        });

        beforeEach(function() {});

        it('down test', async function() {
            await migrationHandler.migrate('201707300000000-noTaxable.js');
            let allSaleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
            for (let i = 0; i < allSaleDocs.length; i++) {
                let sale_items = allSaleDocs[i].doc.sale_items;
                for (let j = 0; j < ARRAY_LENGTH(sale_items); j++) {
                    let item_id = sale_items[j].item_id;
                    expect(sale_items[j].hasOwnProperty('hsn')).to.equal(false);
                    expect(sale_items[j].hasOwnProperty('ItemType')).to.equal(false);
                }
            }
        });

        it('up test', async function() {
            await migrationHandler.migrate('201708020000000-hsnItemType.js');

            let allSaleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
            for (let i = 0; i < allSaleDocs.length; i++) {
                let sale_items = allSaleDocs[i].doc.sale_items;
                for (let j = 0; j < ARRAY_LENGTH(sale_items); j++) {
                    let item_id = sale_items[j].item_id;
                    expect(sale_items[j].hasOwnProperty('hsn')).to.equal(true);
                    expect(sale_items[j].hasOwnProperty('ItemType')).to.equal(true);
                    expect(sale_items[j].hasOwnProperty('chargesList')).to.equal(true);
                    expect(sale_items[j].hasOwnProperty('chargesTaxList')).to.equal(true);
                }
            }

            let appSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
            expect(appSettings.HSN.restaurant).to.equal('HSN/SAC');
        });

    });

})();