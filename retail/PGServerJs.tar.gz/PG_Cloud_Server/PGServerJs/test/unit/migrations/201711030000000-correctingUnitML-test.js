'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
var mainDBInstance = couchDBUtils.getMainCouchDB();
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');

describe('Migration Tests', function() {
    this.timeout(200000);

    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    it('items-variantData-test', async function() {

        let allItems = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
        let docsToUpdate = [];
        for (var i = 0; i < allItems.length; i++) {

            if (allItems[i].doc.info.hasVariants === false && allItems[i].doc.info.attributes.length !== 0) {
                console.log('bad data' + allItems[i].doc.item_id);
                expect(0).to.equal(1);

            }

        }
    });
    it('down', async function() {
        await migrationHandler.migrate('201711022030000-smsCounter.js');

        let allUnits = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);
        for (var i = 0; i < allUnits.length; i++) {
            if (allUnits[i].doc.name === 'ml') {
                expect(allUnits[i].doc.shortName).to.equal('mgs');
            }

        }
    });

    it('up', async function() {
        await migrationHandler.migrate('201711030000000-correctingUnitML.js');
        let allUnits = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);
        for (var i = 0; i < allUnits.length; i++) {
            if (allUnits[i].doc.name === 'ml') {
                expect(allUnits[i].doc.shortName).to.equal('ml');
            }

        }

        let allItems = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
        let docsToUpdate = [];
        for (var i = 0; i < allItems.length; i++) {

            if (allItems[i].doc.info.hasVariants === false && allItems[i].doc.info.attributes.length !== 0) {
                console.log('bad data' + allItems[i].doc.item_id);
                expect(0).to.equal(1);

            }

        }
    });

});