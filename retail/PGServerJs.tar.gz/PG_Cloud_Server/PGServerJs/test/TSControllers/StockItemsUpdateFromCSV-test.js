"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const fs = require("fs");
const nanoBlue = require("nano-blue");
const init_1 = require("../../init/init");
const StockItemsUpdateFromCSV_1 = require("../../TSControllers/StockItemsUpdateFromCSV");
const Utils_1 = require("../../common/Utils");
describe('XXXX UT', function () {
    this.timeout(99999999);
    let targetServerUrl = 'http://couchadmin:test@localhost:5894';
    let targetDBName = 'pg_maindb_18_1_10';
    let targetDBInstance;
    before(() => __awaiter(this, void 0, void 0, function* () {
        yield init_1.prepareDBConfig();
        const targetServerInstance = nanoBlue(targetServerUrl);
        targetDBInstance = targetServerInstance.use(targetDBName);
    }));
    function processRawCSVData(data) {
        var lines = data.split("\n");
        var headerLength = 0;
        var dataArr = [];
        for (var i = 0; i < lines.length; i++) {
            var strArr = lines[i].split(',');
            if (i === 0) {
                headerLength = strArr.length;
            }
            for (var j = 0; j < strArr.length; j++) {
                strArr[j] = strArr[j].trim();
            }
            if (strArr.length === headerLength) {
                dataArr.push(strArr);
            }
        }
        return dataArr;
    }
    it('update stock', () => __awaiter(this, void 0, void 0, function* () {
        let csvBuffer = fs.readFileSync('C:/Users/AlienHu/Downloads/copy1.csv');
        yield StockItemsUpdateFromCSV_1.stockUpdate({ employee_id: 'nadmin', dataArr: processRawCSVData(csvBuffer.toString()) }, {
            strRegistrationId: '10',
            strStoreCompanyId: '18_1'
        });
        yield Utils_1.pgTimeOut(5000);
    }));
});
//# sourceMappingURL=StockItemsUpdateFromCSV-test.js.map