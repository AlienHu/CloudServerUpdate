"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const couchDbManager = require("../../dbManagers/couchDbManager");
const couchDBApis = require("../../TSCouchDB/Common/couchDBApis");
const dbInstanceHelper_1 = require("../../TSCouchDB/Common/dbInstanceHelper");
const GlobalConfigurations_1 = require("../../test/TSData/GlobalConfigurations");
const Utils_1 = require("../../common/Utils");
const Utils_2 = require("../common/Utils");
const formatDocIds_1 = require("../../TSControllers/utils/formatDocIds");
const srcWriteHelper_1 = require("../../TSCouchDB/CommonChanges/libraries/srcWriteHelper");
const items_1 = require("../TSData/items");
const items_2 = require("../TSData/items");
const itemImport_1 = require("../TSData/itemImport");
describe('Sync Master UT', function () {
    this.timeout(9999999);
    let dbContext;
    before(function () {
        return __awaiter(this, void 0, void 0, function* () {
            let bResetDB = true;
            let resp = yield couchDbManager.initCouchDb(bResetDB);
            dbContext = resp.dbContext;
        });
    });
    function checkMasterdoc(syncTransactionDoc) {
        return __awaiter(this, void 0, void 0, function* () {
            let allDocsRespRowArr = yield couchDBApis.getAllDocsByType(dbContext, formatDocIds_1.MASTER_PREFIX, dbInstanceHelper_1.getLicenceDBInstance, false);
            const latestIndex = allDocsRespRowArr.length - 1; //latest doc
            const masterDoc = allDocsRespRowArr[latestIndex].doc;
            const expectedMasterDoc = srcWriteHelper_1.getMasterDocFromSyncTransactionDoc4UT(syncTransactionDoc, dbContext);
            let errorsArray = [];
            const bEqual = Utils_2.compareObject(expectedMasterDoc, masterDoc, 0, [], errorsArray);
            expect(bEqual).to.equal(true);
        });
    }
    it('Category Create From Sync Transaction', () => __awaiter(this, void 0, void 0, function* () {
        const syncTransactionDoc = GlobalConfigurations_1.categoryCreateSyncDoc;
        yield couchDBApis.createOrUpdate(dbContext, syncTransactionDoc, dbInstanceHelper_1.getMainDBInstance, 3, "Creating Sync Doc Failed.");
        yield srcWriteHelper_1.processSyncTransactionDoc(syncTransactionDoc, dbContext);
        let doc = syncTransactionDoc.paramsArr[0].doc;
        let dbDoc = yield couchDBApis.getDocEx(dbContext, doc._id, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, dbDoc, 0, ["_rev"], errorsArray);
        expect(bEqual).to.equal(true);
        yield Utils_1.pgTimeOut(1000);
        let errStr = "Sync Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(syncTransactionDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
        yield checkMasterdoc(syncTransactionDoc);
    }));
    it('Category Update From Sync Transaction', () => __awaiter(this, void 0, void 0, function* () {
        const syncTransactionDoc = GlobalConfigurations_1.categoryUpdateSyncDoc;
        yield couchDBApis.createOrUpdate(dbContext, syncTransactionDoc, dbInstanceHelper_1.getMainDBInstance, 3, "Creating Sync Doc Failed.");
        yield srcWriteHelper_1.processSyncTransactionDoc(syncTransactionDoc, dbContext);
        let doc = syncTransactionDoc.paramsArr[0].doc;
        let dbDoc = yield couchDBApis.getDocEx(dbContext, doc._id, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, dbDoc, 0, ["_rev"], errorsArray);
        if (errorsArray.length) {
            console.log(errorsArray);
        }
        expect(bEqual).to.equal(true);
        yield Utils_1.pgTimeOut(1000);
        let errStr = "Sync Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(syncTransactionDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
        yield checkMasterdoc(syncTransactionDoc);
    }));
    it('Category Delete From Sync Transaction', () => __awaiter(this, void 0, void 0, function* () {
        const syncTransactionDoc = GlobalConfigurations_1.categoryDeleteSyncDoc;
        yield couchDBApis.createOrUpdate(dbContext, syncTransactionDoc, dbInstanceHelper_1.getMainDBInstance, 3, "Creating Sync Doc Failed.");
        yield srcWriteHelper_1.processSyncTransactionDoc(syncTransactionDoc, dbContext);
        let docId = syncTransactionDoc.paramsArr[0].doc._id;
        let dbDoc = yield couchDBApis.getDocEx(dbContext, docId, dbInstanceHelper_1.getMainDBInstance);
        expect(dbDoc.deleted).to.equal("1");
        yield Utils_1.pgTimeOut(1000);
        let errStr = "Sync Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(syncTransactionDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
        yield checkMasterdoc(syncTransactionDoc);
    }));
    it('Item Create From Sync Transaction', () => __awaiter(this, void 0, void 0, function* () {
        const syncTransactionDoc = items_2.createItemSyncDoc;
        yield couchDBApis.createOrUpdate(dbContext, syncTransactionDoc, dbInstanceHelper_1.getMainDBInstance, 3, "Creating Sync Doc Failed.");
        yield srcWriteHelper_1.processSyncTransactionDoc(syncTransactionDoc, dbContext);
        let itemDoc = syncTransactionDoc.paramsArr[0].doc;
        let inventoryDoc = syncTransactionDoc.paramsArr[1].doc;
        let allDocsRespRowArr = yield couchDBApis.getAllDocs(dbContext, [itemDoc._id, inventoryDoc._id], dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(itemDoc, allDocsRespRowArr[0].doc, 0, ["_rev"], errorsArray);
        expect(bEqual).to.equal(true);
        bEqual = Utils_2.compareObject(inventoryDoc, allDocsRespRowArr[1].doc, 0, ["_rev"], errorsArray);
        expect(bEqual).to.equal(true);
        yield Utils_1.pgTimeOut(1000);
        let errStr = "Sync Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(syncTransactionDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
        yield checkMasterdoc(syncTransactionDoc);
    }));
    it('Item Update From Sync Transaction', () => __awaiter(this, void 0, void 0, function* () {
        const syncTransactionDoc = items_1.updateItemSyncDoc;
        yield couchDBApis.createOrUpdate(dbContext, syncTransactionDoc, dbInstanceHelper_1.getMainDBInstance, 3, "Creating Sync Doc Failed.");
        yield srcWriteHelper_1.processSyncTransactionDoc(syncTransactionDoc, dbContext);
        let allDocsRespRowArr = yield couchDBApis.getAllDocs(dbContext, [syncTransactionDoc.paramsArr[0].docId, syncTransactionDoc.paramsArr[1].docId], dbInstanceHelper_1.getMainDBInstance);
        //cheating here just checking if rev has changed to 2
        expect(allDocsRespRowArr[0].doc._rev.indexOf('2-')).to.equal(0);
        expect(allDocsRespRowArr[1].doc._rev.indexOf('2-')).to.equal(0);
        yield Utils_1.pgTimeOut(1000);
        let errStr = "Sync Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(syncTransactionDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
        yield checkMasterdoc(syncTransactionDoc);
    }));
    it('Item Delete From Sync Transaction', () => __awaiter(this, void 0, void 0, function* () {
        const syncTransactionDoc = items_1.deleteItemSyncDoc;
        yield couchDBApis.createOrUpdate(dbContext, syncTransactionDoc, dbInstanceHelper_1.getMainDBInstance, 3, "Creating Sync Doc Failed.");
        yield srcWriteHelper_1.processSyncTransactionDoc(syncTransactionDoc, dbContext);
        let allDocsRespRowArr = yield couchDBApis.getAllDocs(dbContext, [syncTransactionDoc.paramsArr[0].doc._id, syncTransactionDoc.paramsArr[1].doc._id], dbInstanceHelper_1.getMainDBInstance);
        expect(allDocsRespRowArr[0].doc.deleted).to.equal("1");
        expect(allDocsRespRowArr[1].doc.deleted).to.equal("1");
        yield Utils_1.pgTimeOut(1000);
        let errStr = "Sync Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(syncTransactionDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
        yield checkMasterdoc(syncTransactionDoc);
    }));
    it('Item Import From Sync Transaction', () => __awaiter(this, void 0, void 0, function* () {
        const syncTransactionDoc = itemImport_1.itemImportSyncTransactionDoc;
        yield couchDBApis.createOrUpdate(dbContext, syncTransactionDoc, dbInstanceHelper_1.getMainDBInstance, 3, "Creating Sync Doc Failed.");
        yield srcWriteHelper_1.processSyncTransactionDoc(syncTransactionDoc, dbContext);
        let docIdArr = [];
        const docsArr = syncTransactionDoc.paramsArr[0].docsArray;
        for (let i = 0; i < docsArr.length; i++) {
            docIdArr.push(docsArr[i]._id);
        }
        let allDocsRespRowArr = yield couchDBApis.getAllDocs(dbContext, docIdArr, dbInstanceHelper_1.getMainDBInstance);
        for (let i = 0; i < docsArr.length; i++) {
            let errorsArr = [];
            let bEqual = Utils_2.compareObject(docsArr[i], allDocsRespRowArr[i].doc, 0, ['_rev'], errorsArr);
            expect(bEqual).to.equal(true);
        }
        yield Utils_1.pgTimeOut(1000);
        let errStr = "Sync Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(syncTransactionDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
        yield checkMasterdoc(syncTransactionDoc);
    }));
});
//# sourceMappingURL=syncmaster-test.js.map