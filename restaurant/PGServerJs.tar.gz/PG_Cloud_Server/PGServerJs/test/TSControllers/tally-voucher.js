"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
// import couchDBUtils from '../../controllers/common/CouchDBUtils';
const couchDBUtils = require('../../controllers/common/CouchDBUtils');
const moment = require('moment');
// const mainDBInstance = couchDBUtils.getMainCouchDB();
const chai = require("chai");
const expect = chai.expect;
require("mocha");
const mapCustomer_1 = require("../../TSControllers/tally/mapAh2Tally/mapCustomer");
const mapItem_1 = require("../../TSControllers/tally/mapAh2Tally/mapItem");
const mapSale_1 = require("../../TSControllers/tally/mapAh2Tally/mapSale");
const saleComputation_1 = require("../../TSControllers/tally/computations/saleComputation");
const elementsCntrlr = require('../../controllers/Elements');
const commonLib = require('../../controllers/libraries/commonLib');
describe('XXXX UT', function () {
    this.timeout(100000);
    let salesConfig;
    let prevItemArr;
    let pProfileArr;
    let mainDBInstance;
    let allUnitArr;
    let allTaxArr;
    let allSlabArr;
    let allProfileArr;
    let allItemArr;
    let allCustomerArr;
    let saleDoc = {};
    let allCategoryArr;
    let applicationSettings;
    let allSaleArr;
    before(function () {
        return __awaiter(this, void 0, void 0, function* () {
            mainDBInstance = couchDBUtils.getMainCouchDB(); //simply added because the compiler was removing automatically
            let promise = [];
            let promiseResponse = [];
            promise.push(couchDBUtils.getAllDocsByType('unit', mainDBInstance, undefined, true));
            promise.push(couchDBUtils.getAllDocsByType('tax', mainDBInstance, undefined, true));
            promise.push(couchDBUtils.getAllDocsByType('slab', mainDBInstance, undefined, true));
            promise.push(couchDBUtils.getAllDocsByType('item', mainDBInstance, undefined, true));
            promise.push(elementsCntrlr.getNonDeleteCustomer());
            promise.push(couchDBUtils.getAllDocsByType('profile', mainDBInstance, undefined, true));
            promise.push(couchDBUtils.getAllDocsByType('category', mainDBInstance));
            promise.push(commonLib.getApplicationSettings());
            promise.push(couchDBUtils.getAllDocsByType('sale', mainDBInstance));
            promiseResponse = yield Promise.all(promise);
            allUnitArr = promiseResponse[0];
            allTaxArr = promiseResponse[1];
            allSlabArr = promiseResponse[2];
            allItemArr = promiseResponse[3];
            allCustomerArr = promiseResponse[4];
            allProfileArr = promiseResponse[5];
            allCategoryArr = promiseResponse[6];
            applicationSettings = promiseResponse[7];
            allSaleArr = promiseResponse[8];
        });
    });
    function checkCustomerData(tCustomer, pgCustomer) {
        expect(tCustomer.$.NAME).to.equal(pgCustomer.first_name);
        expect(tCustomer.PARENT[0]).to.equal('Sundry Debtors');
        expect(tCustomer['MAILINGNAME.LIST'][0].MAILINGNAME[0]).to.equal(pgCustomer.first_name);
        expect(tCustomer['CURRENCYNAME'][0]).to.equal('INR');
        pgCustomer.address_1 = pgCustomer.address_2 ? pgCustomer.address_1 + pgCustomer.address_2 : pgCustomer.address_1;
        if (pgCustomer.address_1) {
            expect(tCustomer['ADDRESS.LIST'][0].ADDRESS[0]).to.equal(pgCustomer.address_1);
        }
        expect(tCustomer['LANGUAGENAME.LIST'][0]['NAME.LIST'][0].NAME[0]).to.equal(pgCustomer.first_name);
        let aKey = ['zip', 'country', 'country', 'state'];
        let tKey = ['PINCODE', 'COUNTRYNAME', 'COUNTRYOFRESIDENCE', 'LEDSTATENAME'];
        checkCommonData(tKey, aKey, pgCustomer, tCustomer);
        if (!pgCustomer.gstin_number) {
            expect(tCustomer.GSTREGISTRATIONTYPE[0]).to.equal('Unregistered');
            expect(tCustomer.PARTYGSTIN).to.equal(undefined);
        }
        else {
            expect(tCustomer.PARTYGSTIN[0]).to.equal(pgCustomer.gstin_number);
        }
    }
    ;
    const checkCommonData = (tallyKey, alienhuKey, alienhuData, template) => {
        let length = tallyKey.length;
        for (let i = 0; i < length; i++) {
            if (!alienhuData[alienhuKey[i]]) {
                expect(alienhuData[alienhuKey[i]]).to.equal('');
            }
            expect(template[tallyKey[i]][0]).to.equal(alienhuData[alienhuKey[i]]);
        }
        return template;
    };
    it('CUSTOMER', function () {
        for (let i = 0; i < allCustomerArr.length; i++) {
            let tempCustomer = mapCustomer_1.default(allCustomerArr[i]);
            let customerInfo = clone(tempCustomer);
            checkCustomerData(customerInfo, allCustomerArr[i]);
        }
        ;
    });
    function checkCategoryData(tCategory, pgCategory) {
        expect(tCategory.$.NAME).to.equal(pgCategory.name);
        expect(tCategory['LANGUAGENAME.LIST'][0]['NAME.LIST'][0].NAME[0]).to.equal(pgCategory.name);
    }
    function checkItemData(tItem, pgItem, unitObjects, appSettings) {
        let info = pgItem.info;
        expect(tItem.$.NAME).to.equal(info.name);
        if (info.unit === "") {
            info.unit = "Nos";
        }
        let price = info.unitsInfo[info.baseUnitId].pProfilesData[appSettings.salesConfig.pProfileId].sellingPrice;
        let unitName = unitObjects['unit_' + info.baseUnitId];
        let gstPercent = 0;
        let cessPercent = 0;
        expect(tItem['PARENT'][0]).to.equal(info.categoryName);
        expect(tItem['DESCRIPTION'][0]).to.equal(info.description);
        expect(tItem.BASEUNITS[0]).to.equal(unitName);
        expect(tItem.VATBASEUNIT[0]).to.equal(unitName);
        info.quantity = info.quantity ? info.quantity : info.receiving_quantity;
        info.quantity = info.quantity ? info.quantity : 0;
        expect(tItem.OPENINGBALANCE[0]).to.equal('' + info.quantity + ' ' + unitName);
        let openingValue = price * (info.quantity ? info.quantity : 1);
        expect(tItem.OPENINGVALUE[0]).to.equal("" + openingValue);
        expect(tItem.OPENINGRATE[0]).to.equal(price);
        expect(tItem['LANGUAGENAME.LIST'][0]['NAME.LIST'][0].NAME[0]).to.equal(info.name);
        expect(tItem['BATCHALLOCATIONS.LIST'][0].OPENINGBALANCE[0]).to.equal('' + info.quantity + ' ' + unitName);
        expect(tItem['BATCHALLOCATIONS.LIST'][0].OPENINGVALUE[0]).to.equal("" + openingValue);
        expect(tItem['BATCHALLOCATIONS.LIST'][0].OPENINGRATE[0]).to.equal(price);
        let itemTaxList = pgItem.itemTaxList;
        let tlTaxList1 = [];
        for (let i = 0; i < itemTaxList.length; i++) {
            if (itemTaxList[i].name === 'GST') {
                gstPercent = itemTaxList[i].percent;
            }
            else if (itemTaxList[i].name === 'CGST') {
                gstPercent = itemTaxList[i].percent * 2;
            }
            else if (itemTaxList[i].name === 'CESS') {
                cessPercent = itemTaxList[i].percent;
            }
        }
        ;
        if (gstPercent || cessPercent) {
            let gstRateDetails = mapItem_1.getGSTTaxDetails(gstPercent, cessPercent);
            // expect(['GSTDETAILS.LIST'][0]['STATEWISEDETAILS.LIST'][0]['RATEDETAILS.LIST']).to.equal(gstRateDetails);
        }
        else {
            expect(tItem['GSTDETAILS.LIST'][0]['TAXABILITY'][0]).to.equal('Nil Rated');
        }
    }
    it('ITEM', function () {
        let dirtyCatObj = {};
        let categoryIndxObj = getCategoryIndex(allCategoryArr);
        let unitObjects = getUnitObj(allUnitArr);
        let taxObj = {};
        allTaxArr.forEach(tax => {
            let thisTaxDoc = {
                name: tax.name,
                percent: tax.percent
            };
            taxObj[tax.id] = thisTaxDoc;
        });
        for (let i = 0; i < allItemArr.length; i++) {
            let item = allItemArr[i];
            let categoryData = allCategoryArr[categoryIndxObj['category_' + item.info.categoryId]].doc;
            if (!dirtyCatObj[item.info.categoryId]) {
                dirtyCatObj[item.info.categoryId] = 1;
                let tempStockGroupInfo = mapItem_1.mapStockGroup(categoryData);
                checkCategoryData(tempStockGroupInfo, categoryData);
            }
            item.itemTaxList = [];
            let tax = {};
            // get tax and assign
            if (!false) { // sales tax
                for (let i = 0; i < item.info.salesTaxes.length; i++) {
                    let taxDoc = taxObj[item.info.salesTaxes[i]];
                    item.itemTaxList.push(taxDoc);
                }
            }
            else {
                // purchase tax
            }
            let tempItemInfo = mapItem_1.mapItem(item, unitObjects, applicationSettings);
            checkItemData(tempItemInfo, item, unitObjects, applicationSettings);
        }
        ;
    });
    function checkTaxLedgers(totalTaxes, ledgerEntryStruct, bPurchase) {
        let taxKeys = Object.keys(totalTaxes);
        let multiplier = bPurchase ? '-' : '';
        let len = ledgerEntryStruct.length - 1;
        for (let i = taxKeys.length - 1; i >= 0; i--) {
            let tmpLedger = clone(ledgerEntryStruct[len]);
            expect(tmpLedger.LEDGERNAME[0]).to.equal(taxKeys[i]);
            expect(tmpLedger.AMOUNT[0]).to.equal(multiplier + totalTaxes[taxKeys[i]]);
            expect(tmpLedger.VATEXPAMOUNT[0]).to.equal(multiplier + totalTaxes[taxKeys[i]]);
            checkDeletedFields(tmpLedger, ['BASICRATEOFINVOICETAX.LIST', 'METHODTYPE', 'CLASSRATE', 'POSPAYMENTTYPE']);
            len--;
        }
    }
    ;
    function checkDeletedFields(obj, fieldsArr) {
        for (let i = 0; i < fieldsArr.length; i++) {
            // expect(obj[fieldsArr[i]]).to.equal(undefined);
            expect(obj.hasOwnProperty(fieldsArr[i])).to.equal(false);
        }
    }
    function checkFillPaymentLedger(template, type, amount, posDate, voucehrInfo) {
        let ledgerEntries = template['LEDGERENTRIES.LIST'];
        for (let i = 0; i < ledgerEntries.length; i++) {
            let bankAllocations = ledgerEntries[i]['BANKALLOCATIONS.LIST'];
            let baInfo = bankAllocations[0];
            if (!ledgerEntries[i].POSPAYMENTTYPE) {
                continue;
            }
            let postPaymentType = ledgerEntries[i].POSPAYMENTTYPE[0];
            if (postPaymentType === type && baInfo.hasOwnProperty('AMOUNT')) {
                expect(ledgerEntries[i].AMOUNT[0]).to.equal((-1 * amount).toString());
                expect(ledgerEntries[i].LEDGERNAME[0]).to.equal(voucehrInfo.bankAccount);
                expect(baInfo.AMOUNT[0]).to.equal((-1 * amount).toString());
                expect(baInfo.DATE[0]).to.equal(posDate);
                expect(baInfo.INSTRUMENTDATE[0]).to.equal(posDate);
                expect(baInfo.INSTRUMENTNUMBER[0]).to.equal("132134"); //TODO
                break;
            }
            if (postPaymentType === 'Cash') {
                expect(ledgerEntries[i].AMOUNT[0]).to.equal((-1 * amount).toString());
                expect(ledgerEntries[i].LEDGERNAME[0]).to.equal(voucehrInfo.cashInHand);
                break;
            }
        }
    }
    function checkSaleData(tSaleData, pgSaleData, voucehrInfo, k, customerData) {
        let sales_info = pgSaleData.sales_info;
        // let posDate: string = moment(pgSaleData.sales_info.sale_time).format('YYYYMMDD');
        // tSaleData.DATE[0] = posDate;
        // const preId = "3fc37f06-72a4-4fd4-9439-ec9a79b55899-";
        // let id = preId + (k + 1).toLocaleString('en-US', { minimumIntegerDigits: 8, useGrouping: false });
        // tSaleData.$.REMOTEID = id;
        // tSaleData.GUID[0] = id;
        // tSaleData.STATENAME[0] = 'Karnataka';//NTD
        // tSaleData.NARRATION[0] = "To DO";//NTD
        // tSaleData.VOUCHERTYPENAME[0] = voucehrInfo.name; 
        // tSaleData.CLASSNAME[0] = voucehrInfo.name; 
        // tSaleData.POSCARDLEDGER[0]=voucehrInfo.name;
        // tSaleData.POSCASHLEDGER[0]=voucehrInfo.cashInHand;
        // tSaleData.POSCHEQUELEDGER[0]=voucehrInfo.bankAccount;
        // tSaleData.PARTYLEDGERNAME[0] = voucehrInfo.bankAccount;
        // let aKey : String[] = ['name','name','name','cashInHand','bankAccount','bankAccount'];
        // let tKey : String[] = ['VOUCHERTYPENAME','CLASSNAME','POSCARDLEDGER','POSCASHLEDGER','POSCHEQUELEDGER','PARTYLEDGERNAME'];
        // checkCommonData(tKey,aKey,voucehrInfo.voucherClass,tSaleData);
        // let payments: Payment[] = data.payments;
        let payments = pgSaleData.payments;
        let bCashFound = false;
        let bDebitCardFound = false;
        let bChequeFound = false;
        let ledgerEntries = tSaleData['LEDGERENTRIES.LIST'];
        for (let i = 0; i < payments.length; i++) {
            let amount = 0;
            let type = "";
            if (payments[i].payment_type === 'Cash') {
                // let summary: ComputeResponse = computeCart(data.sale_items, sales_info.round_off_method, 1);
                let summary = saleComputation_1.computeCart(pgSaleData.sale_items, sales_info.round_off_method, 1);
                amount = payments[i].payment_amount;
                expect(tSaleData.POSCASHRECEIVED[0]).to.equal((-1 * amount).toFixed(2));
                bCashFound = true;
                type = 'Cash';
            }
            else if (payments[i].payment_type === 'Debit Card' || payments[i].payment_type === 'Credit Card') {
                amount = payments[i].payment_amount;
                bDebitCardFound = true;
                type = 'Bank';
            }
            else if (payments[i].payment_type === 'Cheque') {
                expect(tSaleData.POSCHEQUENUMBER[0]).to.equal(pgSaleData.sales_info.checkNo);
                amount = payments[i].payment_amount;
                bChequeFound = true;
                type = 'Card';
            }
            // fillPaymentLedger(tSaleData, type, amount, '20180401',voucehrInfo)
            checkFillPaymentLedger(tSaleData, type, amount, '20180401', voucehrInfo.voucherClass);
        }
        let index = [];
        if (!bCashFound) {
            let fields2Delete = ['POSCASHRECEIVED', 'POSCASHLEDGER'];
            checkDeletedFields(tSaleData, fields2Delete);
            // delUnwantedPayType( ledgerEntries , 'Cash')
        }
        if (!bDebitCardFound) {
            let fields2Delete = ['POSCARDNUMBER', 'POSCARDLEDGER', 'PARTYLEDGERNAME'];
            checkDeletedFields(tSaleData, fields2Delete);
            // delUnwantedPayType(ledgerEntries, 'Bank')
        }
        if (!bChequeFound) {
            expect(tSaleData.hasOwnProperty('POSCHEQUELEDGER')).to.equal(false);
            // delUnwantedPayType(ledgerEntries, 'Card')
        }
        if (bCashFound && bDebitCardFound && bChequeFound) { //delete when discount integrate
            // delUnwantedPayType(ledgerEntries, undefined)
        }
        let customerInfo = customerData[pgSaleData.sales_info.customer_id];
        expect(tSaleData.PARTYNAME[0]).to.equal(customerInfo.first_name);
        expect(tSaleData.VOUCHERNUMBER[0]).to.equal(pgSaleData.sales_info.sale_id.toString());
        expect(tSaleData.BASICBUYERNAME[0]).to.equal(customerInfo.first_name);
        // tSaleData.PLACEOFSUPPLY[0] = 'Karnataka';//NTD
        // let items: SaleItem[] = data.sale_items;
        // let totalTaxes: Taxes = summary.taxes;
        let items = pgSaleData.sale_items;
        let summary = saleComputation_1.computeCart(items, sales_info.round_off_method, 1);
        let totalTaxes = summary.taxes;
        for (let i = 0; i < ledgerEntries.length; i++) {
            let ledgerName = ledgerEntries[i].LEDGERNAME[0];
            if (totalTaxes.hasOwnProperty(ledgerName)) {
                let taxValue = "" + totalTaxes[ledgerName];
                expect(ledgerEntries[i].AMOUNT[0]).to.equal(taxValue);
                if (ledgerEntries[i].VATEXPAMOUNT) {
                    expect(ledgerEntries[i].VATEXPAMOUNT[0]).to.equal(taxValue);
                }
            }
        }
        let bPurchase = false;
        // let taxLedger = getTaxLedgers(totalTaxes, ledgerEntries[0], bPurchase);
        // for(let k : number=1;k< 2;k++){ // partial done
        checkTaxLedgers(totalTaxes, ledgerEntries, false);
        // }
        // ledgerEntries.push(...taxLedger);
        let allInventories = tSaleData['ALLINVENTORYENTRIES.LIST'];
        // let allInventoriesTemplate = allInventories.shift();
        for (let i = 0; i < items.length; i++) {
            // let item = items[i] as ItemInfo;
            let item = items[i];
            if (item.bSPTaxInclusive) {
                // throw 'Inclusive Tax Not Yet Supported.';
                continue;
            }
            let tlItem = clone(allInventories[i]);
            let tempDiscount = item.discount_percent ? item.discount_percent : 0;
            expect(tlItem.DISCOUNT[0]).to.equal(tempDiscount);
            let billedQty = item.quantity_purchased + ' ' + item.unit;
            expect(tlItem.BILLEDQTY[0]).to.equal(billedQty);
            expect(tlItem.ACTUALQTY[0]).to.equal(billedQty);
            expect(tlItem.AMOUNT[0]).to.equal("" + item.computations.subTotal);
            expect(tlItem.RATE[0]).to.equal(item.sellingPrice + '/' + item.unit);
            expect(tlItem.STOCKITEMNAME[0]).to.equal(item.name);
            let voucherClassData = voucehrInfo.voucherClass;
            expect(tlItem['ACCOUNTINGALLOCATIONS.LIST'][0].LEDGERNAME[0]).to.equal(voucherClassData.salesAccount);
            expect(tlItem['ACCOUNTINGALLOCATIONS.LIST'][0].AMOUNT[0]).to.equal("" + item.computations.subTotal);
            expect(tlItem['ACCOUNTINGALLOCATIONS.LIST'][0].CLASSRATE[0]).to.equal("" + item.sellingPrice);
        }
    }
    ;
    it('SALE', function () {
        return __awaiter(this, void 0, void 0, function* () {
            let voucherData = {
                "ledgerArr": [{
                        "name": "BA89", "parent": "Bank Accounts"
                    }, {
                        "name": "Cash89", "parent": "Cash-in-Hand"
                    }, {
                        "name": "SA89", "parent": "Sales Accounts"
                    }, {
                        "name": "DT89", "parent": "Duties & Taxes"
                    }, {
                        "name": "CGST", "parent": "Duties & Taxes"
                    }, {
                        "name": "IGST", "parent": "Duties & Taxes"
                    }, {
                        "name": "SGST", "parent": "Duties & Taxes"
                    }, {
                        "name": "CESS", "parent": "Duties & Taxes"
                    }, {
                        "name": "VAT89", "parent": "Direct Expenses"
                    }],
                "voucherClass": {
                    "name": "sop89",
                    "salesAccount": "SA89",
                    "parent": "Sales",
                    "bankAccount": "BA89",
                    "cashInHand": "Cash89"
                }
            };
            let customerObj = getCustomerIDObj(allCustomerArr);
            for (let i = 0; i < allSaleArr.length; i++) {
                let saleInfo = allSaleArr[i].doc;
                if (saleInfo.bRejected) {
                    continue;
                }
                //below we are sending emmmpty dbContext .. not correct.. fix it while fixing the test
                let mapSaleInfo = mapSale_1.default(saleInfo, i, voucherData.voucherClass, customerObj, applicationSettings, {});
                let temp = clone(mapSaleInfo);
                checkSaleData(temp, saleInfo, voucherData, i, customerObj);
            }
            ;
        });
    });
    function getCategoryIndex(categoryArray) {
        let categoryDirtyObj = {};
        for (let i = 0; i < categoryArray.length; i++) {
            categoryDirtyObj[categoryArray[i].doc._id] = i;
        }
        return categoryDirtyObj;
    }
    ;
    function getUnitObj(unitArray) {
        let unitDirtyObj = {};
        for (let i = 0; i < unitArray.length; i++) {
            let unitObj = unitArray[i];
            unitDirtyObj[unitObj._id] = unitObj.name;
        }
        return unitDirtyObj;
    }
    ;
    function getCustomerIDObj(customerData) {
        let customerObj = {};
        for (let i = 0; i < customerData.length; i++) {
            customerObj[customerData[i].person_id] = customerData[i];
        }
        return customerObj;
    }
    function delUnwantedPayType(ledgerEntries, type) {
        for (let pt = 0; pt < ledgerEntries.length; pt++) {
            if (!ledgerEntries[pt].POSPAYMENTTYPE) {
                expect(ledgerEntries[pt]).to.equal(undefined);
                pt = -1;
                if (!type) { //delete when discount integrate
                    break;
                }
                continue;
            }
            if (ledgerEntries[pt].POSPAYMENTTYPE[0] === type) {
                expect(ledgerEntries[pt]).to.equal(undefined);
                ledgerEntries.splice(pt, 1);
                break;
            }
        }
    }
    function clone(obj) {
        if (null == obj || "object" != typeof obj) {
            return obj;
        }
        ;
        let copy = JSON.parse(JSON.stringify(obj));
        return copy;
    }
    ;
});
//# sourceMappingURL=tally-voucher.js.map