"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const Utils_1 = require("../common/Utils");
const couchDbManager = require("../../dbManagers/couchDbManager");
const couchDBApis = require("../../TSCouchDB/Common/couchDBApis");
const GlobalConfigurations_1 = require("../../controllers/GlobalConfigurations");
const GlobalConfigurations_2 = require("../TSData/GlobalConfigurations");
const dbInstanceHelper_1 = require("../../TSCouchDB/Common/dbInstanceHelper");
const general_1 = require("../../TSControllers/utils/general");
describe('Category UT', function () {
    this.timeout(100000);
    let dbContext;
    before(function () {
        return __awaiter(this, void 0, void 0, function* () {
            let bResetDB = true;
            let resp = yield couchDbManager.initCouchDb(bResetDB);
            dbContext = resp.dbContext;
        });
    });
    it('Create Category', () => __awaiter(this, void 0, void 0, function* () {
        const categoryData = general_1.CLONE(GlobalConfigurations_2.categoryCreateData);
        let resp = yield GlobalConfigurations_1.createCategory(categoryData, dbContext);
        let docId = 'category_' + resp.id;
        let doc = yield couchDBApis.getDocEx(dbContext, docId, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_1.compareObject(categoryData, doc, 0, [], errorsArray);
        if (errorsArray.length) {
            console.log(errorsArray);
        }
        expect(bEqual).to.equal(true);
    }));
});
//# sourceMappingURL=GlobalConfigurations-test.js.map