"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const licence = require("../../TSControllers/licence");
const profitGuruFaker = require("../common/profitGuruFaker");
const licenceDAO = require("../../DAO/licenceDAO");
const couchDbManager = require("../../dbManagers/couchDbManager");
const general_1 = require("../../TSControllers/utils/general");
//import { Licence, DeviceInfo, RegistrationName, DbInfo, LicenceReq, cloudDbs, cloudlLcenceDbs, productionIpArray } from '../../grantLicence/licence';
//import * as GrantLicence from '../../grantLicence/grantTitoLicence';
/**
 * Test the funcions in licence controller
 *
 * Create fake licences - 100/less - done
 *
 *
 * Compare mac address - done
 *  - same mac array
 *  - same but different order
 *  - all diffent
 *  - one is common
 *  - one less
 *  - one extra
 * Check the licence - expect licence with 7 days - doing
 * Check the licence after deleted - expect licence with 0 days
 * Create the licence after grant - expect with granted licence days
 *
 *
 */
describe('Licence test UT', function () {
    this.timeout(100000);
    let dbContext;
    before(function () {
        return __awaiter(this, void 0, void 0, function* () {
            let bResetDB = false;
            let resp = yield couchDbManager.initCouchDb(bResetDB);
            dbContext = resp.dbContext;
        });
    });
    it('compareArray test', () => {
        let macArray;
        let currentMacArr;
        let bArray;
        let mac1 = '8c-ec-4b-04-e4-2a';
        let mac2 = '8c-ec-4b-04-e4-21';
        let mac3 = '8c-ec-4b-04-e4-22';
        let dongle = '8c-ec-4b-04-e4-23';
        macArray = [mac1, mac2, mac3];
        currentMacArr = [mac1, mac2, mac3];
        bArray = general_1.compareMacArray(macArray, currentMacArr);
        expect(bArray).to.equal(true);
        macArray = [mac1, mac2, mac3];
        currentMacArr = [mac2, mac3, mac1];
        bArray = general_1.compareMacArray(macArray, currentMacArr);
        expect(bArray).to.equal(true);
        macArray = [mac1, mac2, mac3];
        currentMacArr = ['8c-ec-4b-04-e4-1ad', '8c-ec-4b-04-e4-212', '8c-ec-4b-014-e4-2a'];
        bArray = general_1.compareMacArray(macArray, currentMacArr);
        expect(bArray).to.equal(false);
        macArray = [mac2, mac3, dongle];
        currentMacArr = [dongle, '8c-ec-4b-04-e4-212', '8c-ec-4b-014-e4-2a'];
        bArray = general_1.compareMacArray(macArray, currentMacArr);
        expect(bArray).to.equal(false);
        macArray = [mac1, mac2, mac3];
        currentMacArr = [mac1, mac2];
        bArray = general_1.compareMacArray(macArray, currentMacArr);
        expect(bArray).to.equal(true);
        macArray = [mac1, mac2, mac3];
        currentMacArr = [mac1, mac2, , mac3, dongle];
        bArray = general_1.compareMacArray(macArray, currentMacArr);
        expect(bArray).to.equal(true);
    });
    function checkLogin() {
        return __awaiter(this, void 0, void 0, function* () {
            let licenceReq = {
                query: {
                    clientType: 'DeskTopApp',
                    dbContext: JSON.stringify(dbContext)
                },
                clientIp: '127.0.0.1',
                headers: {
                    'user-agent': ''
                }
            };
            let res = yield licence.checkLicence(licenceReq);
            expect(res.isAuthorized).to.equal(true);
            expect(res.isTrial).to.equal(true);
            expect(res.allowAccess).to.equal(true);
        });
    }
    it('check licence on first time', () => __awaiter(this, void 0, void 0, function* () {
        yield checkLogin();
    }));
    it('create fake licences', () => __awaiter(this, void 0, void 0, function* () {
        let lCount = 2;
        let bulkDocs = profitGuruFaker.getFakeLicences(lCount);
        bulkDocs.forEach((element) => __awaiter(this, void 0, void 0, function* () {
            yield licenceDAO.createOrUpdate(dbContext, element);
        }));
        let licenceArr = yield licenceDAO.getAllDocsByType(dbContext);
        expect(licenceArr.length).to.gt(1);
    }));
    it('check licence on second time', () => __awaiter(this, void 0, void 0, function* () {
        yield checkLogin();
    }));
    it("get all licence", () => __awaiter(this, void 0, void 0, function* () {
        let lList = yield licenceDAO.getAllDocsByType(dbContext);
        console.log(lList);
    }));
    // it.only('grant licence', async () => {
    //     try {
    //         let licenceReq = {
    //             registrationName: '1535628404600',
    //             licenceId: 'licence_1535775927392',
    //             validity: 300,
    //             isTrial: false
    //         }
    //         let licenceReq1: LicenceReq;
    //         licenceReq1 = licenceReq;
    //         console.log(await GrantLicence.grantLicence(licenceReq));
    //     } catch (ex) {
    //         console.log("exception");
    //         console.log(ex.error);
    //     }
    // });
    // it.only('validate licence', async () => {
    //     try {
    //         let licenceDoc = await licenceDAO.getDoc(dbContext, 'licence_1535775927392');
    //         console.log(licenceDoc);
    //     } catch (ex) {
    //         console.log("exception");
    //         console.log(ex.error);
    //     }
    // });
    //test with new clientID
    //if licence doc get deleted .. what should happen?
    /**
     *  - testing with diff pc
     *  - Allows access Api need to update
     *  - view all store licence in UI
     *  - Grant licence script.
     *  - cloud licence grant need to update.
     *  - cripto with different passward. (L)
     *
     */
});
//# sourceMappingURL=licence-test.js.map