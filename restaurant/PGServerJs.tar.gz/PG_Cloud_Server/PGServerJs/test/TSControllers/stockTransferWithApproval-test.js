"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const couchDbManager = require("../../dbManagers/couchDbManager");
const commonUtils = require("../common/commonUtils");
const genFakeData_1 = require("../TSCommon/genFakeData");
const stockTransfer_1 = require("../../TSControllers/interfaces/stockTransfer");
const moment = require("moment");
const serverDataInit_1 = require("../../TSCouchDB/serverDataInit");
const Utils_1 = require("../../common/Utils");
const couchDBApis_1 = require("../../TSCouchDB/Common/couchDBApis");
const formatDocIds_1 = require("../../TSControllers/utils/formatDocIds");
const dbInstanceHelper_1 = require("../../TSCouchDB/Common/dbInstanceHelper");
const stockTransfer_2 = require("../../TSControllers/stockTransfer");
const Utils_2 = require("../common/Utils");
const commonLibEx_1 = require("../../TSControllers/libraries/commonLibEx");
const autoIncrementHelper_1 = require("../../TSControllers/libraries/autoIncrementHelper");
const init_1 = require("../../TSCouchDB/CloudCouch/init");
const general_1 = require("../../TSControllers/utils/general");
let dummyEntitlements = {
    store: {
        disableAdminApproval: {
            allowed: false,
            desc: ''
        }
    }
};
const dummyUser = {
    _id: 'ut',
    name: 'ut',
    roles: [JSON.stringify(dummyEntitlements), ''],
    isDefaultAdmin: false
};
dummyEntitlements.store.disableAdminApproval.allowed = true;
const adminDummyUser = {
    _id: 'ut',
    name: 'ut',
    roles: [JSON.stringify(dummyEntitlements), ''],
    isDefaultAdmin: false
};
describe('StockTransfer UT', function () {
    this.timeout(9999999);
    let prevItemByStoreDocId = {}; //we have to have items from all stores
    let prevInventoryByStoreDocId = {}; //we have to have items from all stores
    let dbContext;
    let dbContextByStoreDocId = {};
    let storeDocIdArr;
    let curMainDBSeqByStoreDocId = {};
    ;
    ;
    before(() => __awaiter(this, void 0, void 0, function* () {
        let bResetDB = false;
        let resp = yield couchDbManager.initCouchDb(bResetDB);
        dbContext = resp.dbContext;
        if (bResetDB) {
            //local to cloud for some junk reason is taking time
            yield Utils_1.pgTimeOut(15000);
        }
        //create 3 stores
        storeDocIdArr = yield genFakeData_1.createStores(4, dbContext);
        dbContextByStoreDocId[storeDocIdArr[0]] = dbContext;
        //initializing the stores
        resp = yield couchDbManager.initStore(storeDocIdArr[1], dbContext);
        dbContextByStoreDocId[storeDocIdArr[1]] = resp.dbContext;
        resp = yield couchDbManager.initStore(storeDocIdArr[2], dbContext);
        dbContextByStoreDocId[storeDocIdArr[2]] = resp.dbContext;
        resp = yield couchDbManager.initStore(storeDocIdArr[3], dbContext);
        dbContextByStoreDocId[storeDocIdArr[3]] = resp.dbContext;
        commonUtils.setDBContext(dbContext);
        //create 3 items
        yield commonUtils.createAllItemTypes(false, false, false);
        if (bResetDB) {
            yield Utils_1.pgTimeOut(5000);
        }
        [prevItemByStoreDocId, prevInventoryByStoreDocId] = yield getLatestItemAndInvDocs();
        for (let i = 0; i < storeDocIdArr.length; i++) {
            const docId = storeDocIdArr[i];
            curMainDBSeqByStoreDocId[docId] = autoIncrementHelper_1.getNextSeq(dbContextByStoreDocId[docId]);
        }
    }));
    const getLatestItemAndInvDocs = () => __awaiter(this, void 0, void 0, function* () {
        let itemByStoreDocId = {};
        let inventoryByStoreDocId = {};
        for (let docId in dbContextByStoreDocId) {
            itemByStoreDocId[docId] = [];
            inventoryByStoreDocId[docId] = [];
            let respArr = yield couchDBApis_1.getAllDocsByType(dbContextByStoreDocId[docId], formatDocIds_1.ITEM_PREFIX, dbInstanceHelper_1.getMainDBInstance, undefined, false);
            for (let i = 0; i < respArr.length; i++) {
                itemByStoreDocId[docId].push(respArr[i].doc);
            }
            respArr = yield couchDBApis_1.getAllDocsByType(dbContextByStoreDocId[docId], formatDocIds_1.INVENTORY_PREFIX, dbInstanceHelper_1.getMainDBInstance, undefined, false);
            for (let i = 0; i < respArr.length; i++) {
                inventoryByStoreDocId[docId].push(respArr[i].doc);
            }
        }
        return [itemByStoreDocId, inventoryByStoreDocId];
    });
    /**
     * * create 3 stores
        * create 3 items
        * transferout 2 items
        * transferin 2 items
     */
    const addItem = (item, stockIndex, quantity) => {
        const stockInfo = Object.values(item.batches)[stockIndex];
        return {
            name: item.info.name,
            expiry: stockInfo.expiry,
            attributeInfo: stockInfo.attributeInfo,
            hasExpiryDate: item.info.hasExpiryDate,
            item_id: item.item_id,
            batchId: stockInfo.batchId,
            stockKey: stockInfo.stockKey,
            quantity: quantity,
            skuName: stockInfo.skuName,
            unitId: item.info.defaultSellingUnitId,
            baseUnitId: item.info.baseUnitId,
            unitsInfo: stockInfo.unitsInfo,
            uniqueDetails: []
        };
    };
    const addItems = (storeDocId) => {
        //if item has batches/variants .. add 2 times
        //Quantity 10
        //do the above for 2 items
        let transferItemArr = [];
        let quantity = 10;
        for (let i = 0; i < 2; i++) {
            const itemArr = prevItemByStoreDocId[storeDocId];
            let iStockLength = Object.keys(itemArr[i].batches).length;
            if (iStockLength > 1) {
                iStockLength = 2;
            }
            for (let j = 0; j < iStockLength; j++) {
                transferItemArr.push(addItem(itemArr[i], j, quantity));
            }
        }
        return transferItemArr;
    };
    const getStockTransferDoc_Request = (inStoreDocId, outStoreDocId) => {
        return {
            inStoreDocId: inStoreDocId,
            outStoreDocId: outStoreDocId,
            adminStoreDocId: undefined,
            info: {
                description: 'From UT',
                storeDocIdExpenseMapArr: {},
                status: stockTransfer_1.StockTransfer.REQUESTED,
                bEnableAdminApprovalForTransfer: undefined,
                statusHistoryArr: []
            },
            requested: {
                itemsArr: addItems(outStoreDocId),
                timestamp: moment().format('x'),
                employee: serverDataInit_1.ADMIN_USER,
                description: '',
                transStatus: undefined,
                bModifictaion: false
            },
            transferIn: undefined,
            transferOut: undefined,
            id: undefined,
            _id: undefined,
            _rev: undefined
        };
    };
    const getStockTransferDoc_TransferOut = (doc) => {
        doc.info.status = stockTransfer_1.StockTransfer.TRANSFER_OUT;
        doc.transferOut = general_1.CLONE(doc.requested);
        return doc;
    };
    const getStockTransferDoc_Approve = (doc) => {
        doc.info.status = stockTransfer_1.StockTransfer.APPROVED;
        return doc;
    };
    const getStockTransferDoc_Approve_Rejected = (doc) => {
        doc.info.status = stockTransfer_1.StockTransfer.APPROVAL_REJECTED;
        return doc;
    };
    const getStockTransferDoc_RejectTransferOut = (doc) => {
        doc.info.status = stockTransfer_1.StockTransfer.REJECTED_TRANSFER_OUT;
        return doc;
    };
    const getStockTransferDoc_Rejected = (doc) => {
        doc.info.status = stockTransfer_1.StockTransfer.REJECTED;
        return doc;
    };
    const getStockTransferDoc_AddExpense_OutStore = (doc) => {
        doc.info.storeDocIdExpenseMapArr[doc.outStoreDocId] = ['ex_1'];
        return doc;
    };
    const getStockTransferDoc_AddExpense_InStore = (doc) => {
        doc.info.storeDocIdExpenseMapArr[doc.inStoreDocId] = ['ex_2'];
        return doc;
    };
    const getStockTransferDoc_TransferIn = (doc) => {
        doc.info.status = stockTransfer_1.StockTransfer.TRANSFER_IN;
        doc.transferIn = general_1.CLONE(doc.requested);
        return doc;
    };
    const getOtherStoreDocId = (docIdArr) => {
        let otherStoreDocIdArr = [];
        for (let i = 0; i < storeDocIdArr.length; i++) {
            if (docIdArr.indexOf(storeDocIdArr[i]) === -1) {
                otherStoreDocIdArr.push(storeDocIdArr[i]);
            }
        }
        return otherStoreDocIdArr;
    };
    //change the order and send for transferout and transferin
    const validateInventoryDocs = (transferItemArr, lessInventoryDocArr, moreInventoryDocArr) => {
        for (let j = 0; j < lessInventoryDocArr.length; j++) {
            let totalQuantity = 0;
            for (let i = 0; i < transferItemArr.length; i++) {
                if (transferItemArr[i].item_id !== lessInventoryDocArr[j].item_id) {
                    continue;
                }
                const stockKey = transferItemArr[i].stockKey;
                const stockQuantity = transferItemArr[i].quantity;
                totalQuantity += stockQuantity;
                let prevQuantity = 0;
                if (lessInventoryDocArr[j].stock[stockKey]) {
                    prevQuantity = lessInventoryDocArr[j].stock[stockKey].quantity;
                }
                //checking quantity for that particular stockKey
                expect(moreInventoryDocArr[j].stock[stockKey].quantity - prevQuantity).to.equal(stockQuantity);
            }
            //checking overall quantity for the item
            expect(moreInventoryDocArr[j].quantity - lessInventoryDocArr[j].quantity).to.equal(totalQuantity);
        }
    };
    const validateItemDocs = (transferItemArr, itemDocArr) => {
        for (let i = 0; i < itemDocArr.length; i++) {
            let unitsInfo;
            for (let j = 0; j < transferItemArr.length; j++) {
                if (transferItemArr[j].item_id !== itemDocArr[i].item_id) {
                    continue;
                }
                const stockInfo = commonLibEx_1.getStockJsonFromItemData(transferItemArr[j]);
                let errorsArray = [];
                expect(itemDocArr[i].batches[stockInfo.stockKey] !== undefined).to.equal(true);
                let bEqual = Utils_2.compareObject(stockInfo, itemDocArr[i].batches[stockInfo.stockKey], 0, ['timestamp'], errorsArray);
                expect(bEqual).to.equal(true);
                unitsInfo = stockInfo.unitsInfo;
            }
            if (unitsInfo && Object.keys(itemDocArr[i].batches).length === 1) {
                let errorsArray = [];
                let bEqual = Utils_2.compareObject(unitsInfo, itemDocArr[i].info.unitsInfo, 0, [], errorsArray);
                expect(bEqual).to.equal(true);
            }
        }
    };
    const validateMasterSyncSlaveLockChanges = (stockTransferDocId, syncStoreDocId, otherStoreDocId1, otherStoreDocId2, bLockSync) => __awaiter(this, void 0, void 0, function* () {
        //doc should not be created in the 3rd store
        let otherStoreDocIdArr = getOtherStoreDocId([syncStoreDocId, otherStoreDocId1, otherStoreDocId2]);
        for (let i = 0; i < otherStoreDocIdArr.length; i++) {
            let bError = false;
            try {
                yield couchDBApis_1.getDoc(dbContextByStoreDocId[otherStoreDocIdArr[i]], stockTransferDocId, dbInstanceHelper_1.getMainDBInstance, 'propagate');
                bError = true;
                throw 'doc exist where it should not be. ' + otherStoreDocIdArr[i];
            }
            catch (error) {
                if (bError) {
                    expect(0).to.equal(1);
                }
            }
        }
        curMainDBSeqByStoreDocId[syncStoreDocId]++;
        const syncDocId = formatDocIds_1.formatSyncTransactionDocId(curMainDBSeqByStoreDocId[syncStoreDocId], dbContextByStoreDocId[syncStoreDocId].strStoreCompanyId);
        yield validateSyncDoc(syncStoreDocId, syncDocId);
        const masterDocId = formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(syncDocId);
        const slaveDocId = formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDocId);
        yield validateSlaveDoc(otherStoreDocId1, slaveDocId);
        yield validateSlaveDoc(otherStoreDocId2, slaveDocId);
        const masterDoc = yield couchDBApis_1.getDeletedDoc(dbContext, masterDocId, 0, dbInstanceHelper_1.getLicenceDBInstance);
        expect(masterDoc._rev.indexOf("3-")).to.equal(0);
        const lockDocId = formatDocIds_1.formatLockDocIdFromDocId(stockTransferDocId);
        if (bLockSync) {
            const lockSyncDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockDocId, 5, init_1.getCloudLicenceDBInstance);
            expect(lockSyncDoc.txDocId).to.equal(syncDocId);
            expect(lockSyncDoc.storeDocId).to.equal(syncStoreDocId);
        }
        const slaveLockDoc1 = yield couchDBApis_1.getDeletedDoc(dbContext, lockDocId, 1, init_1.getCloudLicenceDBInstance);
        expect(slaveLockDoc1.txDocId).to.equal(slaveDocId);
        const nonSyncStoreDocIdArr = [otherStoreDocId1, otherStoreDocId2];
        const lockStoreDocIdIndex = nonSyncStoreDocIdArr.indexOf(slaveLockDoc1.storeDocId);
        expect(lockStoreDocIdIndex > -1).to.equal(true);
        let remLockStoreDocId = otherStoreDocId2;
        if (nonSyncStoreDocIdArr[lockStoreDocIdIndex] === otherStoreDocId2) {
            remLockStoreDocId = otherStoreDocId1;
        }
        const slaveLockDoc2 = yield couchDBApis_1.getDeletedDoc(dbContext, lockDocId, 3, init_1.getCloudLicenceDBInstance);
        expect(slaveLockDoc2.txDocId).to.equal(slaveDocId);
        expect(slaveLockDoc2.storeDocId).to.equal(remLockStoreDocId);
    });
    const validateSlaveDoc = (otherStoreDocId, slaveDocId) => __awaiter(this, void 0, void 0, function* () {
        const slaveDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[otherStoreDocId], slaveDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(slaveDoc._deleted).to.equal(true);
        expect(slaveDoc._rev.indexOf("2-")).to.equal(0);
    });
    const validateSyncDoc = (storeDocId, syncDocId) => __awaiter(this, void 0, void 0, function* () {
        const syncDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[storeDocId], syncDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(syncDoc._deleted).to.equal(true);
        expect(syncDoc._rev.indexOf("2-")).to.equal(0);
    });
    const getStockTransferDocAndCompare = (doc, storeDocId, iExpectedRevNumber) => __awaiter(this, void 0, void 0, function* () {
        let otherStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[storeDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        expect(otherStoreDoc._rev.indexOf(iExpectedRevNumber + "-")).to.equal(0);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, otherStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(doc.txDocIdArr.length).to.equal(otherStoreDoc.txDocIdArr.length);
        expect(bEqual).to.equal(true);
        return otherStoreDoc;
    });
    const getOriginStockTransferDocAndCompare = (doc, syncStoreDocId, iExpectedRevNumber) => __awaiter(this, void 0, void 0, function* () {
        let syncStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[syncStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        expect(syncStoreDoc._rev.indexOf(iExpectedRevNumber + "-")).to.equal(0);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, syncStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        return syncStoreDoc;
    });
    const testStockTransfer_Request = (inStoreDocId, outStoreDocId) => __awaiter(this, void 0, void 0, function* () {
        console.log('testStockTransfer_Request');
        let doc = getStockTransferDoc_Request(inStoreDocId, outStoreDocId);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[inStoreDocId], dummyUser);
        //doc should be created in instore   
        let inStoreDoc = yield getOriginStockTransferDocAndCompare(doc, inStoreDocId, 1);
        //wait sometime 
        yield Utils_1.pgTimeOut(15000);
        //doc should be created in outstore
        let outStoreDoc = yield getStockTransferDocAndCompare(doc, outStoreDocId, 1);
        //doc should be created in adminStore
        let adminStoreDocId = doc.adminStoreDocId;
        let adminStoreDoc = yield getStockTransferDocAndCompare(doc, adminStoreDocId, 1);
        yield validateMasterSyncSlaveLockChanges(doc._id, inStoreDocId, outStoreDocId, adminStoreDocId, false);
        return [inStoreDoc, outStoreDoc, adminStoreDoc];
    });
    const testStockTransfer_Approve = (doc, iOutStoreRev, iInStoreRev, iAdminStoreRev) => __awaiter(this, void 0, void 0, function* () {
        console.log('testStockTransfer_Approve');
        doc = getStockTransferDoc_Approve(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.adminStoreDocId], adminDummyUser);
        //doc should be created in instore   
        let adminStoreDoc = yield getOriginStockTransferDocAndCompare(doc, doc.adminStoreDocId, iAdminStoreRev);
        //wait sometime 
        yield Utils_1.pgTimeOut(15000);
        //doc should be created in outstore
        let outStoreDoc = yield getStockTransferDocAndCompare(doc, doc.outStoreDocId, iOutStoreRev);
        let inStoreDoc = yield getStockTransferDocAndCompare(doc, doc.inStoreDocId, iInStoreRev);
        yield validateMasterSyncSlaveLockChanges(doc._id, doc.adminStoreDocId, doc.inStoreDocId, doc.outStoreDocId, true);
        return [inStoreDoc, outStoreDoc, adminStoreDoc];
    });
    const testStockTransfer_ApproveRejected = (doc, iOutStoreRev, iInStoreRev, iAdminStoreRev) => __awaiter(this, void 0, void 0, function* () {
        console.log('testStockTransfer_Approve');
        doc = getStockTransferDoc_Approve_Rejected(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.adminStoreDocId], adminDummyUser);
        //doc should be created in instore   
        let adminStoreDoc = yield getOriginStockTransferDocAndCompare(doc, doc.adminStoreDocId, iAdminStoreRev);
        //wait sometime 
        yield Utils_1.pgTimeOut(15000);
        //doc should be created in outstore
        let outStoreDoc = yield getStockTransferDocAndCompare(doc, doc.outStoreDocId, iOutStoreRev);
        let inStoreDoc = yield getStockTransferDocAndCompare(doc, doc.inStoreDocId, iInStoreRev);
        yield validateMasterSyncSlaveLockChanges(doc._id, doc.adminStoreDocId, doc.inStoreDocId, doc.outStoreDocId, true);
        return [inStoreDoc, outStoreDoc, adminStoreDoc];
    });
    const testStockTransfer_TransferOut = (doc) => __awaiter(this, void 0, void 0, function* () {
        console.log('testStockTransfer_TransferOut');
        doc = getStockTransferDoc_TransferOut(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.outStoreDocId], dummyUser);
        //doc should be created in instore 
        let outStoreDoc = yield getOriginStockTransferDocAndCompare(doc, doc.outStoreDocId, 3);
        let [itemByStoreDocId, inventoryByStoreDocId] = yield getLatestItemAndInvDocs();
        validateInventoryDocs(doc.transferOut.itemsArr, inventoryByStoreDocId[doc.outStoreDocId], prevInventoryByStoreDocId[doc.outStoreDocId]);
        prevItemByStoreDocId = itemByStoreDocId;
        prevInventoryByStoreDocId = inventoryByStoreDocId;
        //wait sometime 
        yield Utils_1.pgTimeOut(15000);
        //doc should be created in outstore
        let inStoreDoc = yield getStockTransferDocAndCompare(doc, doc.inStoreDocId, 2);
        //doc should be created in adminStore
        let adminStoreDocId = doc.adminStoreDocId;
        let adminStoreDoc = yield getStockTransferDocAndCompare(doc, adminStoreDocId, 2);
        yield validateMasterSyncSlaveLockChanges(doc._id, doc.outStoreDocId, doc.inStoreDocId, adminStoreDocId, true);
        return [inStoreDoc, outStoreDoc, adminStoreDoc];
    });
    const testStockTransfer_RejectTransferOut = (doc, iOutStoreRev, iInStoreRev, iAdminStoreRev) => __awaiter(this, void 0, void 0, function* () {
        console.log('testStockTransfer_RejectTransferOut');
        doc = getStockTransferDoc_RejectTransferOut(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.outStoreDocId], dummyUser);
        //doc should be created in outstore        
        let outStoreDoc = yield getOriginStockTransferDocAndCompare(doc, doc.outStoreDocId, iOutStoreRev);
        let [itemByStoreDocId, inventoryByStoreDocId] = yield getLatestItemAndInvDocs();
        validateInventoryDocs(doc.transferOut.itemsArr, prevInventoryByStoreDocId[doc.outStoreDocId], inventoryByStoreDocId[doc.outStoreDocId]);
        prevItemByStoreDocId = itemByStoreDocId;
        prevInventoryByStoreDocId = inventoryByStoreDocId;
        //wait sometime 
        yield Utils_1.pgTimeOut(15000);
        //doc should be created in outstore
        let inStoreDoc = yield getStockTransferDocAndCompare(doc, doc.inStoreDocId, iInStoreRev);
        //doc should be created in adminStore
        let adminStoreDocId = doc.adminStoreDocId;
        let adminStoreDoc = yield getStockTransferDocAndCompare(doc, adminStoreDocId, iAdminStoreRev);
        yield validateMasterSyncSlaveLockChanges(doc._id, doc.outStoreDocId, doc.inStoreDocId, adminStoreDocId, true);
        return [inStoreDoc, outStoreDoc, adminStoreDoc];
    });
    const testStockTransfer_RejectTransferOut_frominstore = (doc, iOutStoreRev, iInStoreRev, iAdminStoreRev) => __awaiter(this, void 0, void 0, function* () {
        console.log('testStockTransfer_RejectTransferOut_frominstore');
        doc = getStockTransferDoc_RejectTransferOut(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.inStoreDocId], dummyUser);
        //doc should be created in instore  
        let inStoreDoc = yield getOriginStockTransferDocAndCompare(doc, doc.inStoreDocId, iInStoreRev);
        //wait sometime 
        yield Utils_1.pgTimeOut(15000);
        //doc should be created in outstore
        let outStoreDoc = yield getStockTransferDocAndCompare(doc, doc.outStoreDocId, iOutStoreRev);
        //doc should be created in adminStore
        let adminStoreDocId = doc.adminStoreDocId;
        let adminStoreDoc = yield getStockTransferDocAndCompare(doc, adminStoreDocId, iAdminStoreRev);
        let [itemByStoreDocId, inventoryByStoreDocId] = yield getLatestItemAndInvDocs();
        validateInventoryDocs(doc.transferOut.itemsArr, prevInventoryByStoreDocId[doc.outStoreDocId], inventoryByStoreDocId[doc.outStoreDocId]);
        prevItemByStoreDocId = itemByStoreDocId;
        prevInventoryByStoreDocId = inventoryByStoreDocId;
        yield validateMasterSyncSlaveLockChanges(doc._id, doc.inStoreDocId, doc.outStoreDocId, adminStoreDocId, true);
        return [inStoreDoc, outStoreDoc, adminStoreDoc];
    });
    const testStockTransfer_Rejected = (doc, iOutStoreRev, iInStoreRev, iAdminStoreRev) => __awaiter(this, void 0, void 0, function* () {
        console.log('testStockTransfer_Rejected');
        doc = getStockTransferDoc_Rejected(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.outStoreDocId], dummyUser);
        //doc should be created in instore        
        let outStoreDoc = yield getOriginStockTransferDocAndCompare(doc, doc.outStoreDocId, iOutStoreRev);
        //wait sometime 
        yield Utils_1.pgTimeOut(15000);
        //doc should be created in outstore
        let inStoreDoc = yield getStockTransferDocAndCompare(doc, doc.inStoreDocId, iInStoreRev);
        //doc should be created in adminStore
        let adminStoreDocId = doc.adminStoreDocId;
        let adminStoreDoc = yield getStockTransferDocAndCompare(doc, adminStoreDocId, iAdminStoreRev);
        yield validateMasterSyncSlaveLockChanges(doc._id, doc.outStoreDocId, doc.inStoreDocId, adminStoreDocId, true);
        return [inStoreDoc, outStoreDoc, adminStoreDoc];
    });
    const testStockTransfer_TransferOutAddExpense = (doc) => __awaiter(this, void 0, void 0, function* () {
        console.log('testStockTransfer_TransferOutAddExpense');
        doc = getStockTransferDoc_AddExpense_OutStore(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.outStoreDocId], dummyUser);
        //doc should be created in outstore        
        let outStoreDoc = yield getOriginStockTransferDocAndCompare(doc, doc.outStoreDocId, 4);
        //wait sometime 
        yield Utils_1.pgTimeOut(15000);
        //doc should be created in instore
        let inStoreDoc = yield getStockTransferDocAndCompare(doc, doc.inStoreDocId, 3);
        //doc should be created in adminStore
        let adminStoreDocId = doc.adminStoreDocId;
        let adminStoreDoc = yield getStockTransferDocAndCompare(doc, adminStoreDocId, 3);
        yield validateMasterSyncSlaveLockChanges(doc._id, doc.outStoreDocId, doc.inStoreDocId, adminStoreDocId, true);
        return [inStoreDoc, outStoreDoc, adminStoreDoc];
    });
    const testStockTransfer_TransferOutAddExpenseFromOtherStore = (doc, iOutStoreRev, iInStoreRev, iAdminStoreRev) => __awaiter(this, void 0, void 0, function* () {
        console.log('testStockTransfer_TransferOutAddExpenseFromOtherStore');
        doc = getStockTransferDoc_AddExpense_InStore(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.inStoreDocId], dummyUser);
        //doc should be created in instore        
        let inStoreDoc = yield getOriginStockTransferDocAndCompare(doc, doc.inStoreDocId, iInStoreRev);
        //wait sometime 
        yield Utils_1.pgTimeOut(15000);
        //doc should be created in outstore
        let outStoreDoc = yield getStockTransferDocAndCompare(doc, doc.outStoreDocId, iOutStoreRev);
        //doc should be created in adminStore
        let adminStoreDocId = doc.adminStoreDocId;
        let adminStoreDoc = yield getStockTransferDocAndCompare(doc, adminStoreDocId, iAdminStoreRev);
        yield validateMasterSyncSlaveLockChanges(doc._id, doc.inStoreDocId, doc.outStoreDocId, adminStoreDocId, true);
        return [inStoreDoc, outStoreDoc, adminStoreDoc];
    });
    const testStockTransfer_Rejected_frominstore = (doc, iOutStoreRev, iInStoreRev, iAdminStoreRev) => __awaiter(this, void 0, void 0, function* () {
        console.log('testStockTransfer_Rejected_frominstore');
        doc = getStockTransferDoc_Rejected(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.inStoreDocId], dummyUser);
        //doc should be created in instore        
        let inStoreDoc = yield getOriginStockTransferDocAndCompare(doc, doc.inStoreDocId, iInStoreRev);
        //wait sometime 
        yield Utils_1.pgTimeOut(15000);
        //doc should be created in outstore
        let outStoreDoc = yield getStockTransferDocAndCompare(doc, doc.outStoreDocId, iOutStoreRev);
        //doc should be created in adminStore
        let adminStoreDocId = doc.adminStoreDocId;
        let adminStoreDoc = yield getStockTransferDocAndCompare(doc, adminStoreDocId, iAdminStoreRev);
        yield validateMasterSyncSlaveLockChanges(doc._id, doc.inStoreDocId, doc.outStoreDocId, adminStoreDocId, true);
        return [inStoreDoc, outStoreDoc, adminStoreDoc];
    });
    const testStockTransfer_TransferIn = (doc, iOutStoreRev, iInStoreRev, iAdminStoreRev) => __awaiter(this, void 0, void 0, function* () {
        console.log('testStockTransfer_TransferIn');
        doc = getStockTransferDoc_TransferIn(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.inStoreDocId], dummyUser);
        //doc should be created in instore        
        let inStoreDoc = yield getOriginStockTransferDocAndCompare(doc, doc.inStoreDocId, iInStoreRev);
        let [itemByStoreDocId, inventoryByStoreDocId] = yield getLatestItemAndInvDocs();
        validateInventoryDocs(doc.transferIn.itemsArr, prevInventoryByStoreDocId[doc.inStoreDocId], inventoryByStoreDocId[doc.inStoreDocId]);
        validateItemDocs(doc.transferIn.itemsArr, itemByStoreDocId[doc.inStoreDocId]);
        prevItemByStoreDocId = itemByStoreDocId;
        prevInventoryByStoreDocId = inventoryByStoreDocId;
        //wait sometime 
        yield Utils_1.pgTimeOut(15000);
        //doc should be created in outstore
        let outStoreDoc = yield getStockTransferDocAndCompare(doc, doc.outStoreDocId, iOutStoreRev);
        //doc should be created in adminStore
        let adminStoreDocId = doc.adminStoreDocId;
        let adminStoreDoc = yield getStockTransferDocAndCompare(doc, adminStoreDocId, iAdminStoreRev);
        yield validateMasterSyncSlaveLockChanges(doc._id, doc.inStoreDocId, doc.outStoreDocId, adminStoreDocId, true);
        return [inStoreDoc, outStoreDoc, adminStoreDoc];
    });
    it('tests with approval', () => __awaiter(this, void 0, void 0, function* () {
        console.log('1st flow');
        // //request
        let iInStoreRev = 1;
        let iOutStoreRev = 1;
        let iAdminStoreRev = 1;
        let [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_Request(storeDocIdArr[2], storeDocIdArr[1]);
        //transferout
        iInStoreRev++;
        iOutStoreRev += 2;
        iAdminStoreRev++;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_TransferOut(outStoreDoc);
        iInStoreRev += 1;
        iOutStoreRev += 1;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_TransferOutAddExpense(outStoreDoc);
        //approve
        iInStoreRev++;
        iOutStoreRev += 1;
        iAdminStoreRev++;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_Approve(adminStoreDoc, iOutStoreRev, iInStoreRev, iAdminStoreRev);
        // //transfer in
        iInStoreRev += 1;
        iOutStoreRev += 1;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_TransferOutAddExpenseFromOtherStore(inStoreDoc, iOutStoreRev, iInStoreRev, iAdminStoreRev);
        iInStoreRev += 2;
        iOutStoreRev += 1;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_TransferIn(inStoreDoc, iOutStoreRev, iInStoreRev, iAdminStoreRev);
    }));
    it('2nd flow', () => __awaiter(this, void 0, void 0, function* () {
        console.log('2nd flow');
        // //request 
        let iInStoreRev = 1;
        let iOutStoreRev = 1;
        let iAdminStoreRev = 1;
        let [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_Request(storeDocIdArr[2], storeDocIdArr[1]);
        // //transferout
        iInStoreRev += 1;
        iOutStoreRev += 2;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_TransferOut(outStoreDoc);
        //reject transfer out
        iInStoreRev += 1;
        iOutStoreRev += 2;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_RejectTransferOut(outStoreDoc, iOutStoreRev, iInStoreRev, iAdminStoreRev);
        //rejected
        iInStoreRev += 1;
        iOutStoreRev += 1;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_Rejected(outStoreDoc, iOutStoreRev, iInStoreRev, iAdminStoreRev);
        //transferout delete
    }));
    it('3rd flow', () => __awaiter(this, void 0, void 0, function* () {
        console.log('3rd flow');
        // //request 
        let iInStoreRev = 1;
        let iOutStoreRev = 1;
        let iAdminStoreRev = 1;
        let [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_Request(storeDocIdArr[2], storeDocIdArr[1]);
        // //transferout
        iInStoreRev++;
        iOutStoreRev += 2;
        iAdminStoreRev++;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_TransferOut(outStoreDoc);
        //approve rejected
        iInStoreRev++;
        iOutStoreRev += 1;
        iAdminStoreRev++;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_ApproveRejected(adminStoreDoc, iOutStoreRev, iInStoreRev, iAdminStoreRev);
        //reject transfer out
        iInStoreRev += 1;
        iOutStoreRev += 2;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_RejectTransferOut(outStoreDoc, iOutStoreRev, iInStoreRev, iAdminStoreRev);
        //rejected
        iInStoreRev += 1;
        iOutStoreRev += 1;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_Rejected(outStoreDoc, iOutStoreRev, iInStoreRev, iAdminStoreRev);
        //transferout delete
    }));
    it('4th flow', () => __awaiter(this, void 0, void 0, function* () {
        console.log('4th flow');
        //request 
        let iInStoreRev = 1;
        let iOutStoreRev = 1;
        let iAdminStoreRev = 1;
        let [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_Request(storeDocIdArr[2], storeDocIdArr[1]);
        //transferout
        iInStoreRev += 1;
        iOutStoreRev += 2;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_TransferOut(outStoreDoc);
        //approve
        iInStoreRev += 1;
        iOutStoreRev += 1;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_Approve(adminStoreDoc, iOutStoreRev, iInStoreRev, iAdminStoreRev);
        //reject transfer out
        iInStoreRev += 1;
        iOutStoreRev += 2;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_RejectTransferOut_frominstore(inStoreDoc, iOutStoreRev, iInStoreRev, iAdminStoreRev);
        //rejected
        iInStoreRev += 1;
        iOutStoreRev += 1;
        iAdminStoreRev += 1;
        [inStoreDoc, outStoreDoc, adminStoreDoc] = yield testStockTransfer_Rejected_frominstore(inStoreDoc, iOutStoreRev, iInStoreRev, iAdminStoreRev);
        //transferout delete
    }));
});
//# sourceMappingURL=stockTransferWithApproval-test.js.map