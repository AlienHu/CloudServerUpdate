import { load } from 'dotenv-safe';
load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

import * as chai from 'chai';
const expect = chai.expect;

import * as couchDbManager from '../../dbManagers/couchDbManager';
import * as couchDBUtils from '../../controllers/common/CouchDBUtils';
import * as commonUtils from '../common/commonUtils';
import * as salesController from '../../TSControllers/SalesEx';
import { ComputeSale } from '../../TSControllers/interfaces/computeSaleDoc';

describe('Sales Ex UT', function () {
    this.timeout(100000);
    let applicationSettings;
    let salesConfig;
    let prevItems;
    let pProfiles;
    let customerArray;

    before(async function () {
        let bResetDB: boolean = true;
        let resp = await couchDbManager.initCouchDb(bResetDB);
        applicationSettings = resp.applicationSettings;
        salesConfig = applicationSettings.salesConfig;
        prevItems = await commonUtils.createAllItemTypes(true, true);
        pProfiles = await commonUtils.getAllPProfiles();
        customerArray = await commonUtils.getPeople(2, 'customer');
        couchDBUtils.getMainCouchDB(); //simply added because the compiler was removing automatically
    });

    it('XXXXXX', function () {

    });

});