import { load } from 'dotenv-safe';
load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});

import * as moment from 'moment';
import * as chai from 'chai';
const expect = chai.expect;

import * as couchDbManager from '../../dbManagers/couchDbManager';
import * as couchDBUtils from '../../controllers/common/CouchDBUtils';
import * as commonUtils from '../common/commonUtils';

import * as profitGuruFaker from '../common/profitGuruFaker';
const curSession = profitGuruFaker.getFakerSession();

import { PurchaseOrder } from '../../TSControllers/interfaces/purchaseOrder';
import PurchaseOrderDoc = PurchaseOrder.UpdatePurchaseOrder;
import OrderItemInfo = PurchaseOrder.PurchaseOrderCartItemDoc;

import { ApplicationSettings } from '../../TSControllers/interfaces/applicationSettings';
import { DocId } from '../../TSControllers/interfaces/common';
import { addPOToCart } from '../../TSControllers/SalesPO';

describe('Sales Ex UT', function () {
    this.timeout(100000);
    let applicationSettings: ApplicationSettings;
    let prevItemArr;
    let customerArray;
    let mainDBInstance;

    before(async function () {
        let bResetDB: boolean = false;
        let resp = await couchDbManager.initCouchDb(bResetDB);
        applicationSettings = resp.applicationSettings;
        prevItemArr = await commonUtils.createAllItemTypes(true, true);
        customerArray = await commonUtils.getPeople(2, 'customer');
        mainDBInstance = couchDBUtils.getMainCouchDB(); //simply added because the compiler was removing automatically
    });

    function addOrderItem(itemDocId: DocId, quantity: number, price: number, doc: PurchaseOrderDoc): void {
        doc.orderItems.push({
            "itemId": itemDocId,
            "itemName": "aaaa",
            "requestedPrice": price,
            "isPriceAbsolute": false,
            "requestedQuantity": quantity
        });
    }

    function initPurchaseOrderDoc(): PurchaseOrderDoc {
        return {
            "_id": "purchaseOrder_seller_15402765729389872_1544273738660",
            "_rev": "5-3c384d29a002eeb812dcaeb31fbe84c5",
            "orderText": "",
            "orderTime": "0",
            "media": undefined,
            "saleReferences": [],
            "shopId": "seller_15402765729389872",
            "address": "",
            "mode": "pickup",
            "orderItems": [],
            "alienId": "1003",
            "customerId": undefined,
            "customerName": "dpk",
            "status": [
                {
                    "STATUS_NUMBER": 10,
                    "STATUS_NAME": "NEW ORDER",
                    "bChangedBySeller": false,
                    "timestamp": 1544273738659
                },
                {
                    "STATUS_NUMBER": 37,
                    "STATUS_NAME": "COMPLETED",
                    "bChangedBySeller": true,
                    "timestamp": 1544276907576
                }
            ],
            "comments": [
                {
                    "timestamp": 1544275362187,
                    "status": "",
                    "message": "",
                    "author": "seller_15402765729389872"
                },
                {
                    "timestamp": 1544276104600,
                    "status": "",
                    "message": "hii",
                    "author": "seller_15402765729389872"
                },
                {
                    "timestamp": 1544276139576,
                    "status": "",
                    "message": "Hello",
                    "author": "1003"
                }
            ],
            "idWithoutPrefix": 1544273738660,
            "lastUpdated": 1544276907658
        };
    }

    function addCustomerId(customerId: string, doc: PurchaseOrderDoc): void {
        doc.customerId = customerId;
    }

    function getPrice(item): number {
        const unitId: string = item.baseUnitId;
        const pProfileId: string = Object.keys(item.unitsInfo[unitId].pProfilesData)[0];
        return item.batches[0].unitsInfo[unitId].pProfilesData[pProfileId].sellingPrice;
    }

    it('fill data', async () => {
        let doc: PurchaseOrderDoc = initPurchaseOrderDoc();
        addCustomerId(customerArray[0], doc);

        addOrderItem('item_748282', 10, 100, doc);
        addOrderItem(prevItemArr[0]._id, prevItemArr[0].inventory.quantity + 100, getPrice(prevItemArr[0]), doc);
        addOrderItem(prevItemArr[1]._id, 10, getPrice(prevItemArr[1]), doc);
        addOrderItem(prevItemArr[2]._id, 10, 1000, doc);

        await addPOToCart(doc, curSession, applicationSettings);
    });


    //cases
    //more than 1 item in cart
    //plain
    //batches
    //variants
    //batches and variants
    //item not found
    //price different
    //outofstock



});