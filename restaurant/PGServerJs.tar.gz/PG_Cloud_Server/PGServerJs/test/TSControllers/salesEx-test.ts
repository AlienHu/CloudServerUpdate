import { load } from 'dotenv-safe';
load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});

import * as moment from 'moment';
import * as chai from 'chai';
const expect = chai.expect;

import * as couchDbManager from '../../dbManagers/couchDbManager';
import * as couchDBUtils from '../../controllers/common/CouchDBUtils';
import * as commonUtils from '../common/commonUtils';
import * as salesController from '../../TSControllers/SalesEx';
import { Payment } from '../../TSControllers/interfaces/payments';

import { Form } from '../../TSControllers/interfaces/formItem';
import FormItem = Form.Item;
import FormStockInfo = Form.StockInfo;

import { ComputeSale } from '../../TSControllers/interfaces/computeSaleDoc';
import ComputeSaleDoc = ComputeSale.SaleDoc;
import ComputeSaleItem = ComputeSale.SaleItem;
import ComputeSalesInfo = ComputeSale.SalesInfo;
import Computation = ComputeSale.Computation;

import { UnitInfo, UnitDoc } from '../../TSControllers/interfaces/unitsInfo';
import { UniqueDetailInfo } from '../../TSControllers/interfaces/uniqueDetails';
import { getPriceTaxEx } from '../../controllers/common/computeUtils';
import { doComputation4UT, assignTaxesForItem4UT, addPercent4UT } from '../../TSControllers/libraries/SalesEx';
import { TaxProfileEx } from '../../TSControllers/interfaces/TaxProfile';
import { TaxInfo, Slab } from '../../TSControllers/interfaces/taxCommon';
import { Id } from '../../TSControllers/interfaces/common';
import { TransStatus } from '../../TSControllers/interfaces/inventoryTransStatus';
import { ApplicationSettings } from '../../TSControllers/interfaces/applicationSettings';

describe('Sales Ex UT', function () {
    this.timeout(100000);
    let applicationSettings: ApplicationSettings;
    let salesConfig;
    let prevItemArr;
    let pProfileArr;
    let customerArray;
    let allUnitArr: UnitDoc[];
    let allTaxArr: TaxInfo[];
    let allSlabArr: Slab[];
    let allProfileArr: TaxProfileEx[];
    let saleDoc: ComputeSaleDoc = {} as ComputeSaleDoc;
    let mainDBInstance;

    before(async function () {
        let bResetDB: boolean = false;
        let resp = await couchDbManager.initCouchDb(bResetDB);
        applicationSettings = resp.applicationSettings;
        salesConfig = applicationSettings.salesConfig;
        prevItemArr = await commonUtils.createAllItemTypes(true, true);
        pProfileArr = await commonUtils.getAllPProfiles();
        customerArray = await commonUtils.getPeople(2, 'customer');
        mainDBInstance = couchDBUtils.getMainCouchDB(); //simply added because the compiler was removing automatically
        allUnitArr = await couchDBUtils.getAllDocsByType('unit', mainDBInstance, undefined, true);
        allTaxArr = await couchDBUtils.getAllDocsByType('tax', mainDBInstance, undefined, true);
        allSlabArr = await couchDBUtils.getAllDocsByType('slab', mainDBInstance, undefined, true);
        allProfileArr = await couchDBUtils.getAllDocsByType('profile', mainDBInstance, undefined, true);
    });

    function initializeStruct(): ComputeSaleDoc {
        let employee = {
            name: 'admin',
            first_name: 'admin',
            last_name: 'admin'
        };

        return {
            sales_info: { //Client
                pProfileId: applicationSettings.salesConfig.pProfileId,
                sale_time: parseInt(moment().format('x')),
                customer_id: undefined,
                employee_id: employee.name,
                comment: '',
                round_off_method: applicationSettings.numberFormat.roundOffMethod,
                globalDiscountInfo: {
                    amt: 0,
                    percent: 0,
                    discountMethod: applicationSettings.salesConfig.discountMethod
                }
            } as ComputeSalesInfo,
            ui: {
                print_after_sale: applicationSettings.serverPrinter.printReceiptByDefault,
                allIMEINumbers: [],
                allSerialnumbers: [],
                maxLine: 0
            }, //Client
            fullInfo: {
                employeeFullName: 'admin',
                profile: allProfileArr[findIndexOfId(allProfileArr, applicationSettings.taxProfile.id.toString())],
                customer: undefined,
                applicationSettings: applicationSettings
            }, //Client
            temp: {} as ComputeSale.Temp,
            bSuccess: false,
            message: '',
            payments: [], //Client
            sale_items: [], //Client
            computation: {} as ComputeSale.GComputation,
            _id: undefined,
            _rev: undefined,
            sale_id: 0,
            status: {} as TransStatus
        };
    }

    interface InfoParams {
        sale_time?: number;
        employee_id?: string;
        customer_id?: number;
    }

    function initializeStructFromDoc(doc: ComputeSaleDoc, info?: InfoParams) {
        if (!info) {
            info = {};
        }

        let { employee_id, sale_time, customer_id }: InfoParams = info;
        if (!employee_id) {
            employee_id = doc.sales_info.employee_id;
        }
        if (!sale_time) {
            sale_time = doc.sales_info.sale_time;
        }
        if (!customer_id) {
            customer_id = doc.sales_info.customer_id;
        }

        return {
            sales_info: {
                pProfileId: applicationSettings.salesConfig.pProfileId,
                customer_id: customer_id,
                employee_id: employee_id,
                sale_time: sale_time
            },
            payments: [],
            sale_items: [],
            computation: {}
        } as ComputeSaleDoc;
    }

    function findIndexInItems(sale_items: ComputeSaleItem[], item_id, stockKey, uniqueDetailKey): number {
        if (uniqueDetailKey) {
            //when editing this is not correct we should not return -1
            return -1;
        }

        let index: number = -1;
        for (let i: number = 0; i < sale_items.length; i++) {
            if (sale_items[i].item_id === item_id && sale_items[i].stockKey === stockKey) {
                index = i;
                break;
            }
        }

        return index;
    }

    function findStockKeyIndex(batches, stockKey: string): number {
        let index: number = -1;
        for (let i: number = 0; i < batches.length; i++) {
            if (batches[i].stockKey === stockKey) {
                index = i;
                break;
            }
        }

        return index;
    }

    function findIndexOfId(allDocs, id: Id) {
        let index = -1;
        for (let i: number = 0; i < allDocs.length; i++) {
            if (allDocs[i].id.toString() === id.toString()) {
                index = i;
                break;
            }
        }

        return index;
    }

    //getting some details from database may be required
    //find some efficient way. Make the client do it
    //only readonly properties we should add .. rest is autocomputed
    function fillDefaultItemData(dbItem: FormItem, stockInfo: FormStockInfo, uniqueDetailInfo: UniqueDetailInfo, line: number, quantity_purchased: number): ComputeSaleItem {
        let unitId: Id = dbItem.defaultSellingUnitId;
        let unitInfo: UnitInfo = stockInfo.unitsInfo[unitId];
        let pProfileId: number = saleDoc.sales_info.pProfileId;

        let unitIndex: number = findIndexOfId(allUnitArr, unitId);
        let origTaxesList: TaxInfo[] = [];
        for (let i: number = 0; i < dbItem.salesTaxes.length; i++) {
            origTaxesList.push(allTaxArr[findIndexOfId(allTaxArr, dbItem.salesTaxes[i])]);
        }

        let purchaseTaxesList: TaxInfo[] = [];
        for (let i: number = 0; i < dbItem.purchaseTaxes.length; i++) {
            purchaseTaxesList.push(allTaxArr[findIndexOfId(allTaxArr, dbItem.salesTaxes[i])]);
        }

        let salesSlab: Slab = allSlabArr[findIndexOfId(allSlabArr, dbItem.salesSlab)];
        let purchaseSlab: Slab = allSlabArr[findIndexOfId(allSlabArr, dbItem.purchaseSlab)];

        //make this as a function .. get price, get discount percent, ... so we change in 1 place everywhere it is taken care
        let item: ComputeSaleItem = {
            name: dbItem.name,
            hsn: dbItem.hsn,
            item_id: dbItem.item_id,
            ItemType: dbItem.ItemType,
            baseUnitId: dbItem.baseUnitId,
            description: dbItem.description,
            bSPTaxInclusive: dbItem.bSPTaxInclusive,
            bPPTaxInclusive: dbItem.bPPTaxInclusive,
            slab: salesSlab,
            hasBatchNumber: dbItem.hasBatchNumber,
            bOTG: dbItem.bOTG,
            hasExpiryDate: dbItem.hasExpiryDate,
            is_serialized: dbItem.is_serialized,
            imeiCount: dbItem.imeiCount,
            origTaxesList: origTaxesList,
            unitId: unitId,
            purchaseTaxes: purchaseTaxesList,
            purchaseSlab: purchaseSlab,

            stockKey: stockInfo.stockKey,
            batchId: stockInfo.batchId,
            unitsInfo: stockInfo.unitsInfo,
            attributeInfo: stockInfo.attributeInfo,
            skuName: stockInfo.skuName,

            stock_name: 'India',
            item_location: 1,

            unit: allUnitArr[unitIndex].name,
            discount_percent: unitInfo.pProfilesData[pProfileId].discountId, //get discount
            purchasePrice: unitInfo.purchasePrice,
            sellingPrice: unitInfo.pProfilesData[pProfileId].sellingPrice,
            mrp: unitInfo.mrp,
            expiry: stockInfo.expiry, //don't know this name

            line: line,
            serialnumber: uniqueDetailInfo.serialnumber,
            imeiNumbers: uniqueDetailInfo.imeiNumbers,

            quantity_purchased: quantity_purchased++,


            //need not fill
            gDiscountPercent: 0,
            itemTaxList: [],
            chargesList: [],
            chargesTaxList: [],
            computation: undefined
        };

        return item;
    }

    function fillItem(sale_items: ComputeSaleItem[], dbItem: any, batch: any, uniqueDetailKey: string): void {

        let stockKey: string = batch.stockKey;
        let uniqueDetailInfo: UniqueDetailInfo = {} as UniqueDetailInfo;

        let line: number = sale_items.length + 1;
        let quantity_purchased: number = 4;
        if (uniqueDetailKey) {
            uniqueDetailInfo = dbItem.inventory.stock[stockKey].uniqueDetails[uniqueDetailKey].info;
            quantity_purchased = 1;
        }

        let item: ComputeSaleItem = fillDefaultItemData(dbItem, batch, uniqueDetailInfo, line, quantity_purchased);
        sale_items.push(item);
    }

    function isSerialized(item) {
        return item.is_serialized || item.imeiCount;
    }

    function getUniqueDetailKey(itemIndex, stockKey, uniqueDetailKeyIndex) {
        let item = prevItemArr[itemIndex];
        let uniqueDetailKey;
        if (isSerialized(item)) {
            uniqueDetailKey = Object.keys(item.inventory.stock[stockKey].uniqueDetails)[uniqueDetailKeyIndex];
        }

        return uniqueDetailKey;
    }

    function fillSomeItems() {
        let sale_items = saleDoc.sale_items;
        let itemIndex = 0;
        let uniqueDetailKeyIndex = 4;
        let batchIndex = 0;
        let item = prevItemArr[itemIndex];
        let stockKey = item.batches[batchIndex].stockKey;
        fillItem(sale_items, item, item.batches[batchIndex], getUniqueDetailKey(itemIndex, stockKey, uniqueDetailKeyIndex));
        if (item.batches.length > 1) {
            batchIndex = 1;
            stockKey = item.batches[batchIndex].stockKey;
        }
        uniqueDetailKeyIndex = 5;
        fillItem(sale_items, item, item.batches[batchIndex], getUniqueDetailKey(itemIndex, stockKey, uniqueDetailKeyIndex));

        itemIndex = 1;
        uniqueDetailKeyIndex = 2;
        batchIndex = 0;
        item = prevItemArr[itemIndex];
        stockKey = item.batches[batchIndex].stockKey;
        fillItem(sale_items, item, item.batches[batchIndex], getUniqueDetailKey(itemIndex, stockKey, uniqueDetailKeyIndex));
        if (item.batches.length > 1) {
            batchIndex = 1;
            stockKey = item.batches[batchIndex].stockKey;
        }
        uniqueDetailKeyIndex = 1;
        fillItem(sale_items, item, item.batches[batchIndex], getUniqueDetailKey(itemIndex, stockKey, uniqueDetailKeyIndex));

        itemIndex = 2;
        uniqueDetailKeyIndex = 0;
        batchIndex = 0;
        item = prevItemArr[itemIndex];
        stockKey = item.batches[batchIndex].stockKey;
        fillItem(sale_items, item, item.batches[batchIndex], getUniqueDetailKey(itemIndex, stockKey, uniqueDetailKeyIndex));
        if (item.batches.length > 1) {
            batchIndex = 1;
            stockKey = item.batches[batchIndex].stockKey;
        }
        uniqueDetailKeyIndex = 1;
        fillItem(sale_items, item, item.batches[batchIndex], getUniqueDetailKey(itemIndex, stockKey, uniqueDetailKeyIndex));
    }

    function fillCustomer(): void {
        //add some customer -- cases (interstate/intrastate/unregistered)
        initializeStructFromDoc(saleDoc, { customer_id: customerArray[0] });
    }

    function fillEmployee(): void {
        //hardcoded need to get
        initializeStructFromDoc(saleDoc, { employee_id: 'admin' });
    }

    function fillPProfile(): void {
        //change some other profile
    }

    function setTaxProfile(): void {
        //use some tax profile        
    }

    function setTime(): void {
        //time //time will not be moment time so convert it 
        initializeStructFromDoc(saleDoc, { sale_time: parseInt(moment().format('x')) });
    }

    //Do this after computation
    //Or if you know already do it
    function addPayments(): void {
        let payments: Payment[] = saleDoc.payments;
        //payments
    }

    function addGlobalDiscount(): void {
        //global discount -- cases (amt/percent/onTotal/onPayable)
    }


    //converts item to SaleItem
    function fillData() {
        saleDoc = initializeStruct();
        fillSomeItems();
        fillCustomer();
        fillEmployee();
        fillPProfile();
        setTaxProfile();
        setTime();
        addGlobalDiscount();
        addPayments();
    }

    it('fill data', function () {
        fillData();
    });


    it('complete sale', function () {

    });

    it('give receipt', function () {

    });

});