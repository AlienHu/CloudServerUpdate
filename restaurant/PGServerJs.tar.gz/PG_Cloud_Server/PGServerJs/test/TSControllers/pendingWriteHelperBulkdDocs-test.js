"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const pendingWriteHelper_1 = require("../../TSCouchDB/CommonChanges/libraries/pendingWriteHelper");
const pendingWrite_1 = require("../TSData/pendingWrite");
const Utils_1 = require("../common/Utils");
describe('Pending WriteHelper BulkdDocs UT', function () {
    this.timeout(9999999);
    let dbContext = {
        strRegistrationId: '10',
        strStoreCompanyId: '1_1'
    };
    before(function () {
        return __awaiter(this, void 0, void 0, function* () {
        });
    });
    it('addPendingDocIdArrForBulkDocs', () => {
        let params = pendingWrite_1.getBulkDocsParams('sy_a_b_c', dbContext);
        params.iCompletedIndexArr = [1, 3];
        let docIdTransDocIdMap = {};
        pendingWriteHelper_1.addPendingDocIdArrForBulkDocs4UT(params, docIdTransDocIdMap, 2, 4);
        expect(Object.keys(docIdTransDocIdMap).length).to.equal(2);
        let errorsArray = [];
        let bEqual = Utils_1.compareObject({ paramIndex: 2, docIndex: 4, iBulkDocArrIndex: 0 }, docIdTransDocIdMap[params.docsArray[0]._id], 0, [], errorsArray);
        expect(bEqual).to.equal(true);
        bEqual = Utils_1.compareObject({ paramIndex: 2, docIndex: 4, iBulkDocArrIndex: 2 }, docIdTransDocIdMap[params.docsArray[2]._id], 0, [], errorsArray);
        expect(bEqual).to.equal(true);
    });
});
//# sourceMappingURL=pendingWriteHelperBulkdDocs-test.js.map