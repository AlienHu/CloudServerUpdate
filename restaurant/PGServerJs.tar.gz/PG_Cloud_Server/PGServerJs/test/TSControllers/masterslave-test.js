"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const couchDbManager = require("../../dbManagers/couchDbManager");
const couchDBApis = require("../../TSCouchDB/Common/couchDBApis");
const dbInstanceHelper_1 = require("../../TSCouchDB/Common/dbInstanceHelper");
const GlobalConfigurations_1 = require("../../test/TSData/GlobalConfigurations");
const Utils_1 = require("../../common/Utils");
const Utils_2 = require("../common/Utils");
const formatDocIds_1 = require("../../TSControllers/utils/formatDocIds");
const items_1 = require("../TSData/items");
const itemImport_1 = require("../TSData/itemImport");
const itemSyncWorker_1 = require("../../TSControllers/workers/itemSyncWorker");
describe('Master Slave UT', function () {
    this.timeout(9999999);
    let dbContext;
    before(function () {
        return __awaiter(this, void 0, void 0, function* () {
            let bResetDB = true;
            let resp = yield couchDbManager.initCouchDb(bResetDB);
            dbContext = resp.dbContext;
        });
    });
    it('Category Create From Master', () => __awaiter(this, void 0, void 0, function* () {
        const masterDoc = GlobalConfigurations_1.categoryCreateMasterDoc;
        yield couchDBApis.createOrUpdate(dbContext, masterDoc, dbInstanceHelper_1.getLicenceDBInstance, 3, "Creating Master Doc Failed.");
        yield Utils_1.pgTimeOut(2000);
        let doc = masterDoc.changeParamsArr[0].doc;
        let dbDoc = yield couchDBApis.getDocEx(dbContext, doc._id, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, dbDoc, 0, ["_rev"], errorsArray);
        if (errorsArray.length) {
            console.log(errorsArray);
        }
        expect(bEqual).to.equal(true);
        let errStr = "Salve Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
    }));
    it('Category Update From Master', () => __awaiter(this, void 0, void 0, function* () {
        const masterDoc = GlobalConfigurations_1.categoryUpdateMasterDoc;
        yield couchDBApis.createOrUpdate(dbContext, masterDoc, dbInstanceHelper_1.getLicenceDBInstance, 3, "Creating Master Doc Failed.");
        yield Utils_1.pgTimeOut(2000);
        let doc = masterDoc.changeParamsArr[0].doc;
        let dbDoc = yield couchDBApis.getDocEx(dbContext, doc._id, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, dbDoc, 0, ["_rev"], errorsArray);
        if (errorsArray.length) {
            console.log(errorsArray);
        }
        expect(bEqual).to.equal(true);
        let errStr = "Salve Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
    }));
    it('Category Delete From Master', () => __awaiter(this, void 0, void 0, function* () {
        const masterDoc = GlobalConfigurations_1.categoryDeleteMasterDoc;
        yield couchDBApis.createOrUpdate(dbContext, masterDoc, dbInstanceHelper_1.getLicenceDBInstance, 3, "Creating Master Doc Failed.");
        yield Utils_1.pgTimeOut(2000);
        let docId = masterDoc.changeParamsArr[0].doc._id;
        let dbDoc = yield couchDBApis.getDocEx(dbContext, docId, dbInstanceHelper_1.getMainDBInstance);
        expect(dbDoc.deleted).to.equal("1");
        let errStr = "Salve Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
    }));
    it('Item Create From Master', () => __awaiter(this, void 0, void 0, function* () {
        const masterDoc = items_1.createItemMasterDoc;
        yield couchDBApis.createOrUpdate(dbContext, masterDoc, dbInstanceHelper_1.getLicenceDBInstance, 3, "Creating Master Doc Failed.");
        yield Utils_1.pgTimeOut(2000);
        let itemDoc = masterDoc.changeParamsArr[0].doc;
        itemDoc.storeDocId = formatDocIds_1.getStoreDocIdFromDBContext(dbContext);
        itemSyncWorker_1.stripBatches(itemDoc);
        let inventoryDoc = masterDoc.changeParamsArr[1].doc;
        inventoryDoc.storeDocId = formatDocIds_1.getStoreDocIdFromDBContext(dbContext);
        itemSyncWorker_1.stripStock(inventoryDoc);
        let allDocsRespRowArr = yield couchDBApis.getAllDocs(dbContext, [itemDoc._id, inventoryDoc._id], dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(itemDoc, allDocsRespRowArr[0].doc, 0, ["_rev"], errorsArray);
        expect(bEqual).to.equal(true);
        bEqual = Utils_2.compareObject(inventoryDoc, allDocsRespRowArr[1].doc, 0, ["_rev"], errorsArray);
        expect(bEqual).to.equal(true);
        let errStr = "Salve Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
    }));
    it('Item Update From Master', () => __awaiter(this, void 0, void 0, function* () {
        const masterDoc = items_1.updateItemMasterDoc;
        yield couchDBApis.createOrUpdate(dbContext, masterDoc, dbInstanceHelper_1.getLicenceDBInstance, 3, "Creating Master Doc Failed.");
        yield Utils_1.pgTimeOut(2000);
        let allDocsRespRowArr = yield couchDBApis.getAllDocs(dbContext, [masterDoc.changeParamsArr[0].docId, masterDoc.changeParamsArr[1].docId], dbInstanceHelper_1.getMainDBInstance);
        //cheating here just checking if rev has changed to 2
        expect(allDocsRespRowArr[0].doc._rev.indexOf('2-')).to.equal(0);
        expect(allDocsRespRowArr[1].doc._rev.indexOf('2-')).to.equal(0);
        let errStr = "Salve Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
    }));
    it('Item Delete From Master', () => __awaiter(this, void 0, void 0, function* () {
        const masterDoc = items_1.deleteItemMasterDoc;
        yield couchDBApis.createOrUpdate(dbContext, masterDoc, dbInstanceHelper_1.getLicenceDBInstance, 3, "Creating Master Doc Failed.");
        yield Utils_1.pgTimeOut(2000);
        let allDocsRespRowArr = yield couchDBApis.getAllDocs(dbContext, [masterDoc.changeParamsArr[0].doc._id, masterDoc.changeParamsArr[1].doc._id], dbInstanceHelper_1.getMainDBInstance);
        expect(allDocsRespRowArr[0].doc.deleted).to.equal("1");
        expect(allDocsRespRowArr[1].doc.deleted).to.equal("1");
        let errStr = "Salve Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
    }));
    it('Item Import From Master', () => __awaiter(this, void 0, void 0, function* () {
        const masterDoc = itemImport_1.itemImportMasterDoc;
        yield couchDBApis.createOrUpdate(dbContext, masterDoc, dbInstanceHelper_1.getLicenceDBInstance, 3, "Creating Master Doc Failed.");
        yield Utils_1.pgTimeOut(2000);
        let docIdArr = [];
        const docsArr = masterDoc.changeParamsArr[0].docsArray;
        for (let i = 0; i < docsArr.length; i++) {
            docIdArr.push(docsArr[i]._id);
        }
        let allDocsRespRowArr = yield couchDBApis.getAllDocs(dbContext, docIdArr, dbInstanceHelper_1.getMainDBInstance);
        for (let i = 0; i < docsArr.length; i++) {
            let errorsArr = [];
            let bEqual = Utils_2.compareObject(docsArr[i], allDocsRespRowArr[i].doc, 0, ['_rev'], errorsArr);
            expect(bEqual).to.equal(true);
        }
        let errStr = "Salve Transaction Doc should Have been deleted.";
        try {
            yield couchDBApis.getDocEx(dbContext, formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDoc._id), dbInstanceHelper_1.getMainDBInstance);
            throw errStr;
        }
        catch (error) {
            expect(error).to.not.equal(errStr);
            expect(error.reason).to.equal('deleted');
        }
    }));
});
//# sourceMappingURL=masterslave-test.js.map