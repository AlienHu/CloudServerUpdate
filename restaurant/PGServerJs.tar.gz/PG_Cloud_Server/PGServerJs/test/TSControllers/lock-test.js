"use strict";
/**
 * 1. Lock
 * 2. UnLock
 * 3. Lock
 * 4. Lock
 * 5. Lock After waiting some time
 * 6. unlock
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const Utils_1 = require("../../common/Utils");
const couchDbManager = require("../../dbManagers/couchDbManager");
const lock_1 = require("../TSData/lock");
const couchDBApis_1 = require("../../TSCouchDB/Common/couchDBApis");
const dbInstanceHelper_1 = require("../../TSCouchDB/Common/dbInstanceHelper");
const dstWriteHelper_1 = require("../../TSCouchDB/CommonChanges/libraries/dstWriteHelper");
const init_1 = require("../../TSCouchDB/CloudCouch/init");
const Store_1 = require("../../TSControllers/interfaces/Store");
describe('XXXX UT', function () {
    this.timeout(100000);
    let dbContext;
    before(() => __awaiter(this, void 0, void 0, function* () {
        let bResetDB = true;
        let resp = yield couchDbManager.initCouchDb(bResetDB);
        dbContext = resp.dbContext;
    }));
    it('lock and unlock', () => __awaiter(this, void 0, void 0, function* () {
        const slaveDoc = lock_1.lockSlaveDoc;
        yield couchDBApis_1.createOrUpdate(dbContext, slaveDoc, dbInstanceHelper_1.getMainDBInstance);
        yield dstWriteHelper_1.processSlaveTransactionDoc(slaveDoc, dbContext);
        yield Utils_1.pgTimeOut(1000);
        //slave doc should have been deleted -> rev 2
        //lock document should have been created and deleted -> rev 2
        const deletedSlaveDoc = yield couchDBApis_1.getDeletedDoc(dbContext, slaveDoc._id, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(deletedSlaveDoc._deleted).to.equal(true);
        expect(deletedSlaveDoc._rev.indexOf("2-")).to.equal(0);
        const lockDocId = slaveDoc.paramsArr[0].docId;
        const lockDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockDocId, 1, init_1.getCloudLicenceDBInstance);
        expect(lockDoc.txDocId).to.equal(slaveDoc._id);
        expect(lockDoc.storeDocId).to.equal(Store_1.DEFAULT_STORE_DOCID);
        expect(lockDoc._rev.indexOf("1-")).to.equal(0);
    }));
    it('delete lock, lock and unlock', () => __awaiter(this, void 0, void 0, function* () {
        yield couchDBApis_1.createOrUpdate(dbContext, lock_1.lockDoc, init_1.getCloudLicenceDBInstance);
        const slaveDoc = lock_1.lockSlaveDoc2;
        yield couchDBApis_1.createOrUpdate(dbContext, slaveDoc, dbInstanceHelper_1.getMainDBInstance);
        yield dstWriteHelper_1.processSlaveTransactionDoc(slaveDoc, dbContext);
        yield Utils_1.pgTimeOut(1000);
        //slave doc should have been deleted -> rev 2
        //lock document should have been created and deleted -> rev 2
        const deletedSlaveDoc = yield couchDBApis_1.getDeletedDoc(dbContext, slaveDoc._id, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(deletedSlaveDoc._deleted).to.equal(true);
        expect(deletedSlaveDoc._rev.indexOf("2-")).to.equal(0);
        const lockDocId = slaveDoc.paramsArr[0].docId;
        const lockDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockDocId, 1, init_1.getCloudLicenceDBInstance);
        expect(lockDoc.txDocId).to.equal(slaveDoc._id);
        expect(lockDoc.storeDocId).to.equal(Store_1.DEFAULT_STORE_DOCID);
        expect(lockDoc._rev.indexOf("3-")).to.equal(0);
    }));
});
//# sourceMappingURL=lock-test.js.map