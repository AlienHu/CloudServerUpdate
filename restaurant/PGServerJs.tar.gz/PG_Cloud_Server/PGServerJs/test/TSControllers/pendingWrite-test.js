"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const testUtils = require("../common/Utils");
var compareArray = testUtils.compareArray;
const Utils_1 = require("../../common/Utils");
const couchDbManager = require("../../dbManagers/couchDbManager");
const pendingWrite_1 = require("../TSData/pendingWrite");
const couchDBApis_1 = require("../../TSCouchDB/Common/couchDBApis");
const dbInstanceHelper_1 = require("../../TSCouchDB/Common/dbInstanceHelper");
const couchdb_1 = require("../../TSControllers/interfaces/couchdb");
const formatDocIds_1 = require("../../TSControllers/utils/formatDocIds");
const formatCouchDBUrlAndName_1 = require("../../TSControllers/utils/formatCouchDBUrlAndName");
const init_1 = require("../../init/init");
const pendingWriteHelper_1 = require("../../TSCouchDB/CommonChanges/libraries/pendingWriteHelper");
const srcWriteHelper_1 = require("../../TSCouchDB/CommonChanges/libraries/srcWriteHelper");
const dstWriteHelper_1 = require("../../TSCouchDB/CommonChanges/libraries/dstWriteHelper");
const dbConfig_1 = require("../../TSControllers/interfaces/dbConfig");
describe('XXXX UT', function () {
    this.timeout(100000);
    let dbContext;
    let prevMainDBSeq;
    let prevLicenceDBSeq;
    let strFullMainDBName;
    let strFullLicenceDBName;
    before(() => __awaiter(this, void 0, void 0, function* () {
        init_1.setSkipForUT(true);
        let bResetDB = true;
        let resp = yield couchDbManager.initCouchDb(bResetDB);
        dbContext = resp.dbContext;
        strFullMainDBName = formatCouchDBUrlAndName_1.getFullDBName(dbContext, dbConfig_1.dbConfig.onStoreSelect[couchdb_1.MAIN_DB_PREFIX], dbConfig_1.dbConfig.dbPrefix);
        strFullLicenceDBName = formatCouchDBUrlAndName_1.getFullDBName(dbContext, dbConfig_1.dbConfig.onRegistrationId[couchdb_1.LICENCE_DB_PREFIX], dbConfig_1.dbConfig.dbPrefix);
        prevMainDBSeq = yield getMainDBSeq();
        prevLicenceDBSeq = yield getLicenceDBSeq();
    }));
    function getMainDBSeq() {
        return couchDBApis_1.getUpdateSeq(dbConfig_1.dbConfig, strFullMainDBName);
    }
    function getLicenceDBSeq() {
        return couchDBApis_1.getUpdateSeq(dbConfig_1.dbConfig, strFullLicenceDBName);
    }
    function syncDocTestCase0() {
        return __awaiter(this, void 0, void 0, function* () {
            //create
            let doc = yield pendingWrite_1.getCase0SyncDoc(dbContext, prevMainDBSeq);
            prevMainDBSeq = yield getMainDBSeq();
            prevLicenceDBSeq = yield getLicenceDBSeq();
            const resp = yield couchDBApis_1.create(dbContext, doc, dbInstanceHelper_1.getMainDBInstance);
            doc._rev = resp["0"].rev;
            yield srcWriteHelper_1.processSyncTransactionDoc(doc, dbContext);
            yield Utils_1.pgTimeOut(2000);
            doc = (yield couchDBApis_1.getDeletedDoc(dbContext, doc._id, 0, dbInstanceHelper_1.getMainDBInstance));
            expect(doc._deleted).to.equal(true);
            const masterDoc = yield couchDBApis_1.getDoc(dbContext, formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(doc._id), dbInstanceHelper_1.getLicenceDBInstance);
            const bEqual = compareArray(doc.changeParamsArr, masterDoc.changeParamsArr);
            expect(bEqual).to.equal(true);
            const mainDBSeq = yield getMainDBSeq();
            expect(prevMainDBSeq + 20).to.equal(mainDBSeq); //This implies expected number of writes have happened
            prevMainDBSeq = mainDBSeq;
            const respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(0);
            const licenceDBSeq = yield getLicenceDBSeq();
            expect(prevLicenceDBSeq + 1).to.equal(licenceDBSeq);
            prevLicenceDBSeq = licenceDBSeq;
        });
    }
    function syncDocTestCase1() {
        return __awaiter(this, void 0, void 0, function* () {
            let doc = yield pendingWrite_1.getCase0SyncDoc(dbContext, prevMainDBSeq);
            prevMainDBSeq = yield getMainDBSeq();
            prevLicenceDBSeq = yield getLicenceDBSeq();
            const resp = yield couchDBApis_1.create(dbContext, doc, dbInstanceHelper_1.getMainDBInstance);
            doc._rev = resp["0"].rev;
            let respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(1);
            yield pendingWriteHelper_1.processPendingWriteDocs(dbContext);
            yield Utils_1.pgTimeOut(3000);
            doc = (yield couchDBApis_1.getDeletedDoc(dbContext, doc._id, 0, dbInstanceHelper_1.getMainDBInstance));
            expect(doc._deleted).to.equal(true);
            const masterDoc = yield couchDBApis_1.getDoc(dbContext, formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(doc._id), dbInstanceHelper_1.getLicenceDBInstance);
            const bEqual = compareArray(doc.changeParamsArr, masterDoc.changeParamsArr);
            expect(bEqual).to.equal(true);
            const mainDBSeq = yield getMainDBSeq();
            expect(prevMainDBSeq + 20).to.equal(mainDBSeq); //This implies expected number of writes have happened
            prevMainDBSeq = mainDBSeq;
            respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(0);
            const licenceDBSeq = yield getLicenceDBSeq();
            expect(prevLicenceDBSeq + 1).to.equal(licenceDBSeq);
            prevLicenceDBSeq = licenceDBSeq;
        });
    }
    function syncDocTestCase2() {
        return __awaiter(this, void 0, void 0, function* () {
            let doc = yield pendingWrite_1.getCase2SyncDoc(dbContext, prevMainDBSeq);
            prevMainDBSeq = yield getMainDBSeq();
            prevLicenceDBSeq = yield getLicenceDBSeq();
            const resp = yield couchDBApis_1.create(dbContext, doc, dbInstanceHelper_1.getMainDBInstance);
            doc._rev = resp["0"].rev;
            let respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(1);
            yield pendingWriteHelper_1.processPendingWriteDocs(dbContext);
            yield Utils_1.pgTimeOut(3000);
            doc = (yield couchDBApis_1.getDeletedDoc(dbContext, doc._id, 0, dbInstanceHelper_1.getMainDBInstance));
            expect(doc._deleted).to.equal(true);
            const masterDoc = yield couchDBApis_1.getDoc(dbContext, formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(doc._id), dbInstanceHelper_1.getLicenceDBInstance);
            const bEqual = compareArray(doc.changeParamsArr, masterDoc.changeParamsArr);
            expect(bEqual).to.equal(true);
            const mainDBSeq = yield getMainDBSeq();
            expect(prevMainDBSeq + 11).to.equal(mainDBSeq); //This implies expected number of writes have happened
            prevMainDBSeq = mainDBSeq;
            respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(0);
            const licenceDBSeq = yield getLicenceDBSeq();
            expect(prevLicenceDBSeq + 1).to.equal(licenceDBSeq);
            prevLicenceDBSeq = licenceDBSeq;
        });
    }
    function syncDocTestCase3() {
        return __awaiter(this, void 0, void 0, function* () {
            let doc = yield pendingWrite_1.getCase3SyncDoc(dbContext, prevMainDBSeq);
            prevMainDBSeq = yield getMainDBSeq();
            prevLicenceDBSeq = yield getLicenceDBSeq();
            const resp = yield couchDBApis_1.create(dbContext, doc, dbInstanceHelper_1.getMainDBInstance);
            doc._rev = resp["0"].rev;
            let respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(1);
            yield pendingWriteHelper_1.processPendingWriteDocs(dbContext);
            yield Utils_1.pgTimeOut(3000);
            doc = (yield couchDBApis_1.getDeletedDoc(dbContext, doc._id, 0, dbInstanceHelper_1.getMainDBInstance));
            expect(doc._deleted).to.equal(true);
            const masterDoc = yield couchDBApis_1.getDoc(dbContext, formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(doc._id), dbInstanceHelper_1.getLicenceDBInstance);
            const bEqual = compareArray(doc.changeParamsArr, masterDoc.changeParamsArr);
            expect(bEqual).to.equal(true);
            const mainDBSeq = yield getMainDBSeq();
            expect(prevMainDBSeq + 2).to.equal(mainDBSeq); //This implies expected number of writes have happened
            prevMainDBSeq = mainDBSeq;
            respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(0);
            const licenceDBSeq = yield getLicenceDBSeq();
            expect(prevLicenceDBSeq + 1).to.equal(licenceDBSeq);
            prevLicenceDBSeq = licenceDBSeq;
        });
    }
    function syncDocTestCase4() {
        return __awaiter(this, void 0, void 0, function* () {
            let doc = yield pendingWrite_1.getCase3SyncDoc(dbContext, prevMainDBSeq);
            let resp = yield couchDBApis_1.create(dbContext, doc, dbInstanceHelper_1.getMainDBInstance);
            doc._rev = resp["0"].rev;
            let masterDoc = srcWriteHelper_1.getMasterDocFromSyncTransactionDoc4UT(doc, dbContext);
            resp = yield couchDBApis_1.create(dbContext, masterDoc, dbInstanceHelper_1.getLicenceDBInstance);
            doc._rev = resp["0"].rev;
            let respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(1);
            prevMainDBSeq = yield getMainDBSeq();
            prevLicenceDBSeq = yield getLicenceDBSeq();
            yield pendingWriteHelper_1.processPendingWriteDocs(dbContext);
            yield Utils_1.pgTimeOut(3000);
            doc = (yield couchDBApis_1.getDeletedDoc(dbContext, doc._id, 0, dbInstanceHelper_1.getMainDBInstance));
            expect(doc._deleted).to.equal(true);
            masterDoc = yield couchDBApis_1.getDoc(dbContext, formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(doc._id), dbInstanceHelper_1.getLicenceDBInstance);
            const bEqual = compareArray(doc.changeParamsArr, masterDoc.changeParamsArr);
            expect(bEqual).to.equal(true);
            const mainDBSeq = yield getMainDBSeq();
            expect(prevMainDBSeq + 1).to.equal(mainDBSeq); //This implies expected number of writes have happened
            prevMainDBSeq = mainDBSeq;
            respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(0);
            const licenceDBSeq = yield getLicenceDBSeq();
            expect(prevLicenceDBSeq + 0).to.equal(licenceDBSeq);
            prevLicenceDBSeq = licenceDBSeq;
        });
    }
    function slaveDocTestCase0() {
        return __awaiter(this, void 0, void 0, function* () {
            //create
            let doc = yield pendingWrite_1.getCase0SlaveDoc(dbContext, prevMainDBSeq);
            prevMainDBSeq = yield getMainDBSeq();
            const resp = yield couchDBApis_1.create(dbContext, doc, dbInstanceHelper_1.getMainDBInstance);
            doc._rev = resp["0"].rev;
            yield dstWriteHelper_1.processSlaveTransactionDoc(doc, dbContext);
            yield Utils_1.pgTimeOut(2000);
            doc = (yield couchDBApis_1.getDeletedDoc(dbContext, doc._id, 0, dbInstanceHelper_1.getMainDBInstance));
            expect(doc._deleted).to.equal(true);
            const mainDBSeq = yield getMainDBSeq();
            expect(prevMainDBSeq + 20).to.equal(mainDBSeq); //This implies expected number of writes have happened
            prevMainDBSeq = mainDBSeq;
            const respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(0);
        });
    }
    function slaveDocTestCase1() {
        return __awaiter(this, void 0, void 0, function* () {
            let doc = yield pendingWrite_1.getCase0SlaveDoc(dbContext, prevMainDBSeq);
            prevMainDBSeq = yield getMainDBSeq();
            const resp = yield couchDBApis_1.create(dbContext, doc, dbInstanceHelper_1.getMainDBInstance);
            doc._rev = resp["0"].rev;
            let respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(1);
            yield pendingWriteHelper_1.processPendingWriteDocs(dbContext);
            yield Utils_1.pgTimeOut(3000);
            doc = (yield couchDBApis_1.getDeletedDoc(dbContext, doc._id, 0, dbInstanceHelper_1.getMainDBInstance));
            expect(doc._deleted).to.equal(true);
            const mainDBSeq = yield getMainDBSeq();
            expect(prevMainDBSeq + 20).to.equal(mainDBSeq); //This implies expected number of writes have happened
            prevMainDBSeq = mainDBSeq;
            respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(0);
        });
    }
    function slaveDocTestCase2() {
        return __awaiter(this, void 0, void 0, function* () {
            let doc = yield pendingWrite_1.getCase2SlaveDoc(dbContext, prevMainDBSeq);
            prevMainDBSeq = yield getMainDBSeq();
            const resp = yield couchDBApis_1.create(dbContext, doc, dbInstanceHelper_1.getMainDBInstance);
            doc._rev = resp["0"].rev;
            let respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(1);
            yield pendingWriteHelper_1.processPendingWriteDocs(dbContext);
            yield Utils_1.pgTimeOut(3000);
            doc = (yield couchDBApis_1.getDeletedDoc(dbContext, doc._id, 0, dbInstanceHelper_1.getMainDBInstance));
            expect(doc._deleted).to.equal(true);
            const mainDBSeq = yield getMainDBSeq();
            expect(prevMainDBSeq + 11).to.equal(mainDBSeq); //This implies expected number of writes have happened
            prevMainDBSeq = mainDBSeq;
            respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(0);
        });
    }
    function slaveDocTestCase3() {
        return __awaiter(this, void 0, void 0, function* () {
            let doc = yield pendingWrite_1.getCase3SlaveDoc(dbContext, prevMainDBSeq);
            prevMainDBSeq = yield getMainDBSeq();
            const resp = yield couchDBApis_1.create(dbContext, doc, dbInstanceHelper_1.getMainDBInstance);
            doc._rev = resp["0"].rev;
            let respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(1);
            yield pendingWriteHelper_1.processPendingWriteDocs(dbContext);
            yield Utils_1.pgTimeOut(3000);
            doc = (yield couchDBApis_1.getDeletedDoc(dbContext, doc._id, 0, dbInstanceHelper_1.getMainDBInstance));
            expect(doc._deleted).to.equal(true);
            const mainDBSeq = yield getMainDBSeq();
            expect(prevMainDBSeq + 2).to.equal(mainDBSeq); //This implies expected number of writes have happened
            prevMainDBSeq = mainDBSeq;
            respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(0);
        });
    }
    function slaveDocTestCase4() {
        return __awaiter(this, void 0, void 0, function* () {
            let doc = yield pendingWrite_1.getCase3SlaveDoc(dbContext, prevMainDBSeq);
            let resp = yield couchDBApis_1.create(dbContext, doc, dbInstanceHelper_1.getMainDBInstance);
            doc._rev = resp["0"].rev;
            let respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(1);
            prevMainDBSeq = yield getMainDBSeq();
            yield pendingWriteHelper_1.processPendingWriteDocs(dbContext);
            yield Utils_1.pgTimeOut(3000);
            doc = (yield couchDBApis_1.getDeletedDoc(dbContext, doc._id, 0, dbInstanceHelper_1.getMainDBInstance));
            expect(doc._deleted).to.equal(true);
            const mainDBSeq = yield getMainDBSeq();
            expect(prevMainDBSeq + 1).to.equal(mainDBSeq); //This implies expected number of writes have happened
            prevMainDBSeq = mainDBSeq;
            respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(0);
        });
    }
    function syncSlaveDocTestCase22() {
        return __awaiter(this, void 0, void 0, function* () {
            let doc1 = yield pendingWrite_1.getCase2SyncDoc(dbContext, prevMainDBSeq);
            let doc2 = yield pendingWrite_1.getCase2SyncDoc(dbContext, prevMainDBSeq);
            let doc3 = yield pendingWrite_1.getCase2SlaveDoc(dbContext, prevMainDBSeq);
            let doc4 = yield pendingWrite_1.getCase2SlaveDoc(dbContext, prevMainDBSeq);
            const resp = yield couchDBApis_1.bulkDocs(dbContext, [doc1, doc2, doc3, doc4], dbInstanceHelper_1.getMainDBInstance);
            let respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(4);
            prevMainDBSeq = yield getMainDBSeq();
            prevLicenceDBSeq = yield getLicenceDBSeq();
            yield pendingWriteHelper_1.processPendingWriteDocs(dbContext);
            yield Utils_1.pgTimeOut(10000);
            let allDocsRespArr = yield couchDBApis_1.getAllDocs(dbContext, [doc1._id, doc2._id, doc3._id, doc4._id], dbInstanceHelper_1.getMainDBInstance);
            for (let i = 0; i < allDocsRespArr.length; i++) {
                expect(allDocsRespArr[i].value.deleted).to.equal(true);
            }
            allDocsRespArr = yield couchDBApis_1.getAllDocs(dbContext, [formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(doc1._id), formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(doc2._id)], dbInstanceHelper_1.getLicenceDBInstance);
            let bEqual = compareArray(doc1.changeParamsArr, allDocsRespArr[0].doc.changeParamsArr);
            expect(bEqual).to.equal(true);
            bEqual = compareArray(doc2.changeParamsArr, allDocsRespArr[1].doc.changeParamsArr);
            expect(bEqual).to.equal(true);
            const mainDBSeq = yield getMainDBSeq();
            expect(prevMainDBSeq + 10 * 4).to.equal(mainDBSeq); //This implies expected number of writes have happened
            prevMainDBSeq = mainDBSeq;
            respArr = yield pendingWriteHelper_1.getAllPendingTransactions4UT(dbContext);
            expect(respArr.length).to.equal(0);
            const licenceDBSeq = yield getLicenceDBSeq();
            expect(prevLicenceDBSeq + 2).to.equal(licenceDBSeq);
            prevLicenceDBSeq = licenceDBSeq;
        });
    }
    //get pending transactions
    //check with seq number that only those which are required got executed
    it('case 0: syncdoc all is well. no pending writes', () => __awaiter(this, void 0, void 0, function* () {
        yield syncDocTestCase0();
    }));
    it('case 1: syncdoc  None executed', () => __awaiter(this, void 0, void 0, function* () {
        yield syncDocTestCase1();
    }));
    it('case 2: syncdoc  few executed', () => __awaiter(this, void 0, void 0, function* () {
        yield syncDocTestCase2();
    }));
    it('case 3: syncdoc  All executed but master didnt get created', () => __awaiter(this, void 0, void 0, function* () {
        yield syncDocTestCase3();
    }));
    it('case 4: syncdoc  All executed and master got created', () => __awaiter(this, void 0, void 0, function* () {
        yield syncDocTestCase4();
    }));
    it('case 0: slavedoc all is well. no pending writes', () => __awaiter(this, void 0, void 0, function* () {
        yield slaveDocTestCase0();
    }));
    it('case 1: slavedoc  None executed', () => __awaiter(this, void 0, void 0, function* () {
        yield slaveDocTestCase1();
    }));
    it('case 2: slavedoc  few executed', () => __awaiter(this, void 0, void 0, function* () {
        yield slaveDocTestCase2();
    }));
    it('case 3: slavedoc  All executed but master didnt get created', () => __awaiter(this, void 0, void 0, function* () {
        yield slaveDocTestCase3();
    }));
    it('case 4: slavedoc  All executed and master got created', () => __awaiter(this, void 0, void 0, function* () {
        yield slaveDocTestCase4();
    }));
    it('case 2-2: syncdoc and slavedoc  few executed', () => __awaiter(this, void 0, void 0, function* () {
        yield syncSlaveDocTestCase22();
    }));
});
//# sourceMappingURL=pendingWrite-test.js.map