'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;
const moment = require('moment');
const faker = require('faker');
const profitGuruFaker = require('../../common/profitGuruFaker.js');
const logger = require('../../../common/Logger');
const utils = require('../../common/Utils.js');
const commonUtils = require('../../common/commonUtils');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const lytyCntrlr = require('../../../controllers/loyalty');
let salesEx;
const mainDBInstance = couchDBUtils.getMainCouchDB();
let salesController;
let itemsLib;
let commonLib;
let appSettingsHandler;
const computeUtils = require('../../../controllers/common/computeUtils');
let salesTestHelper;
const contrUtils = require('../../../controllers/common/Utils');
const saleDAO = require('../../../DAO/saleDAO');
const saleReturnDAO = require('../../../DAO/saleReturnDAO');

const CLONE = contrUtils.clone;
let bloyaltyExist;

describe('Sales-loyalty UTS', function() {

    this.timeout(500000);
    this.slow(0);

    let prevItems;
    let pProfiles;
    let curItems;
    let cart = {};
    let customerArray;
    let prevResponse;
    let prevSaleId;
    let timeStamp;
    let prevCustomer = [];
    let prevTotal = 0;
    let bSaleEdit = false;

    let globalDiscountParam = {
        value: 0,
        bPercent: false,
        itemCount: 1111,
        discountMethod: 'onTaxable'
    };

    const curSession = profitGuruFaker.getFakerSession();
    let applicationSettings;
    let salesConfig;

    before(async function() {
        let logDir = '.';
        // utils.deleteFilesOfType(logDir, ['log']);

        let bResetDB = false;
        let resp = await couchDbManager.initCouchDb(bResetDB);
        applicationSettings = resp.applicationSettings;
        salesConfig = applicationSettings.salesConfig;

        prevItems = await commonUtils.createAllItemTypes(true, true);
        pProfiles = await commonUtils.getAllPProfiles();
        customerArray = await commonUtils.getPeople(2, 'customer');
        salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        salesEx = require('../../../TSControllers/SalesEx');
        itemsLib = require('../../../controllers/libraries/itemsControllerLib');
        salesTestHelper = require('./testHelpers/salesTestHelper.js');
        commonLib = require('../../../controllers/libraries/commonLib');
        appSettingsHandler = require('../../../couchDb/applicationSettingsCouchHandler')();
        salesTestHelper.set(itemsLib, commonLib, salesController.getSaleLib(), computeUtils, curSession, applicationSettings);

        bloyaltyExist = lytyCntrlr.getLoyalty();
        if (!bloyaltyExist) {
            let loyaltyDoc = profitGuruFaker.getFakeLoyaltyDoc();
            await lytyCntrlr.save(loyaltyDoc);
        }

    });
    it('get loyalty for 200 rs', async function() {
        let expectedloyalty = await salesEx.getLoyaltyPnts(200);
        expect(expectedloyalty).to.equal(20);
    });

    async function doSale() {
        let itemIndex = 0;
        let stockIndex = 0;
        let uniqueIndex = 0;
        let stockKey = prevItems[itemIndex].batches[stockIndex].stockKey;
        let uniqueDetails = prevItems[itemIndex].inventory.stock[stockKey].uniqueDetails;
        let uniqueDetailsKeys = Object.keys(uniqueDetails);

        let params = {
            item: prevItems[itemIndex].item_id,
            stockKey: stockKey
        };

        if (uniqueDetailsKeys.length) {
            params.uniqueDetails = uniqueDetails[uniqueDetailsKeys[uniqueIndex]].info;
        }
        prevResponse = await salesController.additemRestApi(params);
        let param = {
            customer_id: customerArray[0]
        };
        let total = prevResponse.total;

        prevResponse = await salesController.addCustomer2Sale(param);
        expect(prevResponse.loyaltyPnts).to.equal(total / 10);
        let expectedloyalty = await salesEx.getLoyaltyPnts(prevResponse.total);
        expect(prevResponse.loyaltyPnts).to.equal(expectedloyalty);

        let paymentParams = {
            payment_type: "Cash",
            amount_tendered: prevResponse.amount_due
        };

        prevResponse = await salesController.add_paymentRestApi(paymentParams);
        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });
        prevSaleId = resp.id;

        await commonUtils.pgTimeOut(2000);
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        if (!prevCustomer[0].loyaltyPnts) {
            prevCustomer[0].loyaltyPnts = 0;
        }
        console.log("before doing sale, customer lyt is " + prevCustomer[0].loyaltyPnts + " after completing sale its " + custDoc.loyaltyPnts);
        let expectedCusLyt = prevCustomer[0].loyaltyPnts + expectedloyalty;
        console.log("expected is " + expectedCusLyt);
        expect(custDoc.loyaltyPnts - prevCustomer[0].loyaltyPnts - expectedloyalty).within(-0.1, 0.1);
        prevCustomer[0] = custDoc;
        // await initEditSale();
        // await salesController.cancel_saleRestApi();
    }

    function getJsonForReturnAPI(origSaleDoc) {
        let saleDoc = CLONE(origSaleDoc);

        let salesInfo = saleDoc.sales_info;
        saleDoc.parentId = saleDoc.sale_id;
        delete saleDoc.mods;
        delete salesInfo.sale_id;
        delete saleDoc.sale_id;
        delete saleDoc._id
        delete saleDoc.sales_info;
        delete saleDoc.status;
        if (saleDoc.mods) {
            delete saleDoc.mods;
        }

        saleDoc.items = saleDoc.sale_items;
        delete saleDoc.sale_items;
        let items = saleDoc.items;
        for (let i = 0; i < items.length; i++) {
            items[i].quantity = items[i].quantity_purchased;
            items[i].discount = items[i].discount_percent;
            items[i].price = items[i].sellingPrice;
            delete items[i].quantity_purchased;
            delete items[i].discount_percent;
            delete items[i].sellingPrice;
        }

        for (let key in salesInfo) {
            saleDoc[key] = salesInfo[key];
        }
        saleDoc.creditAmt = saleDoc.pending_amount;
        delete saleDoc.pending_amount;
        delete saleDoc.invoice_number;
        delete saleDoc.sale_time;
        saleDoc.timeStamp = moment().format('x');

        return saleDoc;
    }
    it('sale with cash', async function() {
        prevCustomer.push(await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance));
        prevCustomer.push(await couchDBUtils.getDoc('customer_' + customerArray[1], mainDBInstance));
        await doSale();
    });
    it('sale return', async function() {
        let saleDoc = await saleDAO.getDoc(prevSaleId, mainDBInstance);
        // let saleDoc = await couchDBUtils.getDoc('sale_' + prevSaleId, mainDBInstance);

        // saleDoc = commonLib.transformSaleDoc(saleDoc);
        let resp = await salesController.completeReturn(getJsonForReturnAPI(saleDoc));
        prevSaleId = resp.data.id;

        await commonUtils.pgTimeOut(2000);
        let loyalty = 0;
        if (saleDoc.sales_info.loyaltyEarned) {
            loyalty += saleDoc.sales_info.loyaltyEarned;
        }
        if (saleDoc.sales_info.rmPnts) {
            loyalty += saleDoc.sales_info.rmPnts; // redeemed sale cannot be return
        }
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        console.log('prevCustomer[0].loyaltyPnts ' + prevCustomer[0].loyaltyPnts + ' loyalty ' + loyalty + ' custDoc.loyaltyPnts ' + custDoc.loyaltyPnts);
        expect(prevCustomer[0].loyaltyPnts - loyalty - custDoc.loyaltyPnts).within(-0.1, 0.1);
        prevCustomer[0] = custDoc;

    });
    it('reject the returned sale', async function() {
        console.log(prevSaleId);
        let saleDoc = await saleReturnDAO.getDoc(prevSaleId, mainDBInstance); //await couchDBUtils.getDoc('saleReturn_' + prevSaleId, mainDBInstance);
        let resp = await salesController.rejectSale({
            id: 'saleReturn_' + prevSaleId,
            bReject: false,
            reason: 'test'
        });

        await commonUtils.pgTimeOut(2000);
        let loyalty = 0;
        if (saleDoc.info.rmPnts) {
            loyalty += saleDoc.info.rmPnts;
        }
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        expect(custDoc.loyaltyPnts - prevCustomer[0].loyaltyPnts - loyalty).within(-0.1, 0.1);
        prevCustomer[0] = custDoc;

    });
    it('sale reject', async function() {
        await doSale();
        let saleDoc = await saleDAO.getDoc(prevSaleId, mainDBInstance); // await couchDBUtils.getDoc('sale_' + prevSaleId, mainDBInstance);
        let resp = await salesController.rejectSale({
            id: 'sale_' + prevSaleId,
            bReject: false,
            reason: 'test'
        });

        await commonUtils.pgTimeOut(2000);
        let loyalty = 0;
        if (saleDoc.sales_info.loyaltyEarned) {
            loyalty += saleDoc.sales_info.loyaltyEarned;
        }
        if (saleDoc.sales_info.rmPnts) {
            loyalty -= saleDoc.sales_info.rmPnts;
        }
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        expect(prevCustomer[0].loyaltyPnts - loyalty - custDoc.loyaltyPnts).within(-0.1, 0.1);
        prevCustomer[0] = custDoc;

    });
    it('sale delete', async function() {

        await doSale();
        let saleDoc = await saleDAO.getDoc(prevSaleId, mainDBInstance); //await couchDBUtils.getDoc('sale_' + prevSaleId, mainDBInstance);
        let resp = await salesController.deleteSaleById(['sale_' + prevSaleId]);

        await commonUtils.pgTimeOut(2000);
        let loyalty = 0;
        if (saleDoc.sales_info.loyaltyEarned) {
            loyalty += saleDoc.sales_info.loyaltyEarned;
        }
        if (saleDoc.sales_info.rmPnts) {
            loyalty -= saleDoc.sales_info.rmPnts;
        }
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        expect(prevCustomer[0].loyaltyPnts - loyalty - custDoc.loyaltyPnts).within(-0.1, 0.1);
        prevCustomer[0] = custDoc;

    });
    it('Sale and redeem full customer loyalty', async function() {
        let itemIndex = 0;
        let stockIndex = 0;
        let uniqueIndex = 0;
        let stockKey = prevItems[itemIndex].batches[stockIndex].stockKey;
        let uniqueDetails = prevItems[itemIndex].inventory.stock[stockKey].uniqueDetails;
        let uniqueDetailsKeys = Object.keys(uniqueDetails);

        let params = {
            item: prevItems[itemIndex].item_id,
            stockKey: stockKey
        };

        if (uniqueDetailsKeys.length) {
            params.uniqueDetails = uniqueDetails[uniqueDetailsKeys[uniqueIndex]].info;
        }
        prevResponse = await salesController.additemRestApi(params);
        let param = {
            customer_id: customerArray[0]
        };
        prevResponse = await salesController.addCustomer2Sale(param);
        console.log("prevResponse.total " + prevResponse.total);
        console.log("cust loy " + prevCustomer[0].loyaltyPnts);
        let cartItem = CLONE(prevResponse.cart[0]);

        let redeemMoney = prevResponse.redeemMoney;
        console.log("Redeem money is " + redeemMoney);
        expect(redeemMoney).to.equals(prevCustomer[0].loyaltyPnts * 10);
        expect(redeemMoney).to.greaterThan(0);
        cartItem.price = redeemMoney * 2;
        cartItem.discount = 0;
        prevResponse = await salesController.editItemRestApi(cartItem);
        expect(prevResponse.total).to.gte(redeemMoney * 2);

        let expectedloyalty = await salesEx.getLoyaltyPnts(prevResponse.total);
        expect(prevResponse.loyaltyPnts).to.equal(expectedloyalty);

        let paymentParams = {
            payment_type: "Redeem",
            amount_tendered: redeemMoney
        };

        prevResponse = await salesController.add_paymentRestApi(paymentParams);
        expect(prevResponse.amount_due).to.equals(redeemMoney);
        expect(prevResponse.amount_due).to.greaterThan(0);
        expect(prevResponse.amount_due - redeemMoney).to.gte(0);

        let cashLoyalty = await salesEx.getLoyaltyPnts(prevResponse.amount_due);
        expect(cashLoyalty).to.greaterThan(0);

        paymentParams = {
            payment_type: "Cash",
            amount_tendered: prevResponse.amount_due
        };
        prevResponse = await salesController.add_paymentRestApi(paymentParams);

        expect(prevResponse.amount_due).within(-0.01, 0.01);

        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });
        prevSaleId = resp.id;

        await commonUtils.pgTimeOut(2000);
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        console.log("before redeem sale, customer loyalty is " + prevCustomer[0].loyaltyPnts + " got loyalty from this sale is " + cashLoyalty);
        console.log("expected customer loyalty is " + cashLoyalty);
        console.log("current cus lyt is " + custDoc.loyaltyPnts);
        expect(custDoc.loyaltyPnts - cashLoyalty).to.within(-0.01, 0.01);
        prevCustomer[0] = custDoc;

    });
    async function doCashAndRedeem() {
        let itemIndex = 0;
        let stockIndex = 0;
        let uniqueIndex = 0;
        let stockKey = prevItems[itemIndex].batches[stockIndex].stockKey;
        let uniqueDetails = prevItems[itemIndex].inventory.stock[stockKey].uniqueDetails;
        let uniqueDetailsKeys = Object.keys(uniqueDetails);

        let params = {
            item: prevItems[itemIndex].item_id,
            stockKey: stockKey
        };

        if (uniqueDetailsKeys.length) {
            params.uniqueDetails = uniqueDetails[uniqueDetailsKeys[uniqueIndex]].info;
        }
        prevResponse = await salesController.additemRestApi(params);
        let param = {
            customer_id: customerArray[0]
        };
        prevResponse = await salesController.addCustomer2Sale(param);
        let expectedloyalty = await salesEx.getLoyaltyPnts(prevResponse.total);
        expect(prevResponse.loyaltyPnts).to.equal(expectedloyalty);

        let cashLoyalty = await salesEx.getLoyaltyPnts(prevResponse.amount_due / 2);
        let paymentParams = {
            payment_type: "Cash",
            amount_tendered: prevResponse.amount_due / 2
        };
        prevResponse = await salesController.add_paymentRestApi(paymentParams);
        expect(prevResponse.payments.length).to.equal(1);

        let deductedLyt = 0;
        if (prevCustomer[0].loyaltyPnts) {
            paymentParams = {
                payment_type: "Redeem",
                amount_tendered: prevResponse.amount_due
            };
            prevResponse = await salesController.add_paymentRestApi(paymentParams);
            expect(prevResponse.payments.length).to.equal(2);
            deductedLyt = await salesEx.convertAmtToPnts(prevResponse.payments[1].payment_amount);

        }

        if (prevResponse.amount_due) {

            paymentParams = {
                payment_type: "Cash",
                amount_tendered: prevResponse.amount_due
            };
            prevResponse = await salesController.add_paymentRestApi(paymentParams);
            cashLoyalty = await salesEx.getLoyaltyPnts(prevResponse.payments[0].payment_amount);
        }

        expect(prevResponse.amount_due).within(-0.01, 0.01);

        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });
        prevSaleId = resp.id;

        await commonUtils.pgTimeOut(2000);
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        let saleDoc = await saleDAO.getDoc(prevSaleId, mainDBInstance); // await couchDBUtils.getDoc('sale_' + prevSaleId, mainDBInstance);
        expect(saleDoc.sales_info.loyaltyEarned).to.equal(cashLoyalty);
        prevTotal = resp.total;
        let temp = prevCustomer[0].loyaltyPnts + cashLoyalty - deductedLyt;
        console.log("b4 sale cus lyt is " + prevCustomer[0].loyaltyPnts + " expected after sale customer lyt is " + temp);
        expect(prevCustomer[0].loyaltyPnts - custDoc.loyaltyPnts - deductedLyt + cashLoyalty).within(-0.1, 0.1);
        // console.log('Prev loyalty<' + prevCustomer[0].loyaltyPnts + '> After Sale loyalty<' + custDoc.loyaltyPnts + '> Cashloyalty Earned<' + cashLoyalty + '> DeductedLyt<' + deductedLyt + '>')
        prevCustomer[0] = custDoc;
    }
    it('Sale with redeem & cash', async function() {
        await doCashAndRedeem();
    });
    it('Edit of sale and remove customer', async function() {
        // await doSale();
        await initEditSale();
        let param = {
            customer_id: undefined
        };
        prevResponse = await salesController.addCustomer2Sale(param);
        let cashLoyalty = await salesEx.getLoyaltyPnts(prevResponse.payments[0].payment_amount);
        let rmPnts = await salesEx.convertAmtToPnts(prevResponse.payments[1].payment_amount);
        let total = prevResponse.total;
        console.log("prevSaleId is " + prevSaleId);

        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world',
            saleIdToEdit: 'sale_' + prevSaleId
        });
        prevSaleId = resp.id;
        await commonUtils.pgTimeOut(2000);

        /** Old customer 
         * deducting the earned point
         * adding the redeemed point
         */
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        console.log(prevCustomer[0].total, total);
        let exTotal = prevCustomer[0].total - total;
        expect(exTotal).to.equal(custDoc.total);

        let temp = prevCustomer[0].loyaltyPnts - cashLoyalty + rmPnts;
        console.log("before sale old cus loyalty is " + prevCustomer[0].loyaltyPnts + " after sale expected lyt : " + temp);
        console.log("got loyalty : " + custDoc.loyaltyPnts);
        expect(prevCustomer[0].loyaltyPnts + rmPnts - custDoc.loyaltyPnts - cashLoyalty).within(-0.01, 0.01);
        prevCustomer[0] = custDoc;
    });
    async function initEditSale() {
        // console.log('Previous Sale Id <' + prevSaleId + '>');
        let curResponse = await salesController.initEditSalesSession({
            saleId: 'sale_' + prevSaleId
        });

        let errorsArray = [];
        let bEqual = utils.compareObject(prevResponse, curResponse, 0, ['email_receipt', 'bGDiscountPercent', 'slab', 'origTaxes', 'comment', 'wcInfo', 'sale_time', 'shippingDetails', 'checkNo', 'state_name'], errorsArray)
        if (!bEqual) {
            // console.log(errorsArray);
        }
        expect(bEqual).to.equal(false); // so many mismatch, fix this by sai

    }

    async function initSale2(factor) {
        await initEditSale();
        let cartItem = CLONE(prevResponse.cart[0]);
        console.log("total before " + prevResponse.total);
        console.log("loyalty before " + prevCustomer[0].loyaltyPnts);
        cartItem.price = cartItem.price + (100 * factor);
        cartItem.discount = 0;
        prevResponse = await salesController.editItemRestApi(cartItem);

        let prevCash = prevResponse.payments[0].payment_amount;
        console.log("total after " + prevResponse.total);
        let cashLoyalty = await salesEx.getLoyaltyPnts(prevResponse.payments[0].payment_amount); // 120= 12
        console.log("already earned loyalty is " + cashLoyalty);
        let paymentParams = {
            payment_type: "Cash",
            amount_tendered: prevResponse.amount_due //-20
        };
        prevResponse = await salesController.add_paymentRestApi(paymentParams);
        cashLoyalty = await salesEx.getLoyaltyPnts(prevResponse.payments[0].payment_amount) - cashLoyalty; //10 - 12 =-2
        console.log("earned loyalty after edit is " + cashLoyalty);
        let curCash = prevResponse.payments[0].payment_amount;
        // console.log('prevCash<' + prevCash + '> curCash<' + curCash + '>');

        expect(prevResponse.amount_due).within(-0.01, 0.01);

        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });

        prevSaleId = resp.id;
        await commonUtils.pgTimeOut(2000);
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        // console.log('cus pnts ' + custDoc.loyaltyPnts + 'prev cus' + prevCustomer[0].loyaltyPnts + 'deductedLyt' + deductedLyt);
        // console.log('Prev loyalty<' + prevCustomer[0].loyaltyPnts + '> After Sale loyalty<' + custDoc.loyaltyPnts + '> Cashloyalty Earned<' + cashLoyalty + '>')
        //Need to fix
        // expect(prevCustomer[0].loyaltyPnts - custDoc.loyaltyPnts + cashLoyalty).within(-0.01, 0.01);

        console.log("b4 edit cus lyt is " + prevCustomer[0].loyaltyPnts + " after edit " + custDoc.loyaltyPnts);
        let temp = prevCustomer[0].loyaltyPnts + cashLoyalty;
        console.log("expecting " + temp);
        expect(temp - custDoc.loyaltyPnts).within(-0.01, 0.01);
        prevCustomer[0] = custDoc;
    }

    it('Edit of cash sale with increased price', async function() {
        //call the edit
        //increase price
        //make cash payment of balance
        //check loyalty 
        //customer loyalty after checkout which should be equal to balance cash payment
        await doCashAndRedeem();
        await initSale2(1);
    });

    it('Edit of cash sale with decreased price', async function() {
        //call the edit
        //decrease price
        //make negative cash payment of balance
        //check loyalty 
        //customer loyalty after checkout which should be equal to balance cash payment (loyalty should decrease)
        await initSale2(-1);
    });

    it('Edit of redeemed sale with no change', async function() {
        //call the edit
        //remove loyalty payment
        //add half of the prev loyalty paymentto
        //make cash payment
        //customer loyalty += balancecashpyament + half of prev loyalty payment
        await initEditSale();
        let params = {
            payment_id: 'Redeem'
        }
        prevResponse = await salesController.deletePayment(params);
        let paymentParams = {
            payment_type: "Redeem",
            amount_tendered: prevResponse.amount_due
        };
        prevResponse = await salesController.add_paymentRestApi(paymentParams);

        expect(prevResponse.amount_due).within(-0.01, 0.01);
        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });
        prevSaleId = resp.id;
        await commonUtils.pgTimeOut(2000);
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        // console.log('cus pnts ' + custDoc.loyaltyPnts + 'prev cus' + prevCustomer[0].loyaltyPnts + 'deductedLyt' + deductedLyt);
        expect(prevCustomer[0].loyaltyPnts - custDoc.loyaltyPnts).within(-0.01, 0.01);
        prevCustomer[0] = custDoc;
    });

    it('Edit of redeemed wih delete payment', async function() {
        //call the edit
        //remove loyalty payment
        //add half of the prev loyalty paymentto
        //make cash payment
        //customer loyalty += balancecashpyament + half of prev loyalty payment
        await initEditSale();
        let params = {
            payment_id: 'Redeem'
        }

        let rmPnts = salesEx.convertAmtToPnts(prevResponse.payments[1].payment_amount);
        console.log("last sale he redeemed : " + rmPnts);
        prevResponse = await salesController.deletePayment(params);
        let paymentParams = {
            payment_type: "Redeem",
            amount_tendered: prevResponse.amount_due / 2
        };
        prevResponse = await salesController.add_paymentRestApi(paymentParams);
        rmPnts = rmPnts - salesEx.convertAmtToPnts(prevResponse.payments[1].payment_amount);
        let cashLoyalty = await salesEx.getLoyaltyPnts(prevResponse.payments[0].payment_amount);
        paymentParams = {
            payment_type: "Cash",
            amount_tendered: prevResponse.amount_due
        };
        prevResponse = await salesController.add_paymentRestApi(paymentParams);
        cashLoyalty = await salesEx.getLoyaltyPnts(prevResponse.payments[0].payment_amount) - cashLoyalty;

        expect(prevResponse.amount_due).within(-0.01, 0.01);
        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });
        prevSaleId = resp.id;
        await commonUtils.pgTimeOut(2000);
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        console.log("earned point by edit " + cashLoyalty + " earned point by reducing redeem pnt : " + rmPnts);
        console.log("old loyalty point " + prevCustomer[0].loyaltyPnts + " after edit new loyalty point is " + custDoc.loyaltyPnts);
        expect(prevCustomer[0].loyaltyPnts + cashLoyalty + rmPnts - custDoc.loyaltyPnts).within(-0.01, 0.01);
        prevCustomer[0] = custDoc;
    });
    it('Edit of redeemed sale and redeem again', async function() {

        await initEditSale();
        let rmPnts = salesEx.convertAmtToPnts(prevResponse.payments[1].payment_amount); // points which is redeemed
        let cartItem = CLONE(prevResponse.cart[0]);
        console.log("total before " + prevResponse.total);
        cartItem.price = cartItem.price + 100;
        cartItem.discount = 0;
        prevResponse = await salesController.editItemRestApi(cartItem);
        console.log("total after " + prevResponse.total);
        let paymentParams = {
            payment_type: "Redeem",
            amount_tendered: prevResponse.amount_due
        };
        prevResponse = await salesController.add_paymentRestApi(paymentParams);
        rmPnts = await salesEx.convertAmtToPnts(prevResponse.payments[1].payment_amount) - rmPnts;

        expect(prevResponse.amount_due).within(-0.01, 0.01);
        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });
        prevSaleId = resp.id;
        await commonUtils.pgTimeOut(2000);
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        let temp = prevCustomer[0].loyaltyPnts - rmPnts;
        console.log("old loyalty is " + prevCustomer[0].loyaltyPnts + " newly redeemed " + rmPnts + " expected loyalty is " + temp);
        console.log("got loyalty of customer is " + custDoc.loyaltyPnts);
        expect(prevCustomer[0].loyaltyPnts - rmPnts - custDoc.loyaltyPnts).within(-0.01, 0.01);
        prevCustomer[0] = custDoc;
    });

    it('Edit of redeemed sale and payment', async function() {
        //call the edit
        //change customer
        //if any payment was added by loyalty remove it
        //try to make equal amount of loyalty payment
        //balance cash payment
        //new customer loyalty = total cash payment - redeemed loyalty
        //old customer = add redeemed loaylaity - total prev cash payment

        await initEditSale();
        let params = {
            payment_id: 'Redeem'
        }

        let rmPnts = salesEx.convertAmtToPnts(prevResponse.payments[1].payment_amount); // points which is redeemed
        prevResponse = await salesController.deletePayment(params);
        let cashLoyalty = await salesEx.getLoyaltyPnts(prevResponse.payments[0].payment_amount);
        let paymentParams = {
            payment_type: "Cash",
            amount_tendered: prevResponse.amount_due
        };
        prevResponse = await salesController.add_paymentRestApi(paymentParams);
        cashLoyalty = await salesEx.getLoyaltyPnts(prevResponse.payments[0].payment_amount) - cashLoyalty;

        expect(prevResponse.amount_due).within(-0.01, 0.01);
        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world',
            saleIdToEdit: 'sale_' + prevSaleId
        });
        prevSaleId = resp.id;
        await commonUtils.pgTimeOut(2000);
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        console.log('prev cus ' + prevCustomer[0].loyaltyPnts + ' now cus pnts ' + custDoc.loyaltyPnts);
        let temp = prevCustomer[0].loyaltyPnts + cashLoyalty + rmPnts;
        console.log("expected : " + temp);
        expect(prevCustomer[0].loyaltyPnts + cashLoyalty + rmPnts - custDoc.loyaltyPnts).within(-0.01, 0.01);
        prevCustomer[0] = custDoc;
    });
    it('Edit of sale and change customer', async function() {

        await initEditSale();
        let param = {
            customer_id: customerArray[1]
        };
        prevResponse = await salesController.addCustomer2Sale(param);
        let cashLoyalty = await salesEx.getLoyaltyPnts(prevResponse.payments[0].payment_amount);
        let total = prevResponse.total;
        console.log("prevSaleId is " + prevSaleId);

        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world',
            saleIdToEdit: 'sale_' + prevSaleId
        });
        prevSaleId = resp.id;
        await commonUtils.pgTimeOut(2000);

        /** New Customer 
         * execting 
         * adding earned point 
         * deducting redeemed points
         */
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[1], mainDBInstance);
        let temp2 = prevCustomer[1].loyaltyPnts + cashLoyalty;
        console.log(" before sale new cus lyt is " + prevCustomer[1].loyaltyPnts + "after sale expected is  " + temp2);
        console.log("got loyalty : " + custDoc.loyaltyPnts);
        if (!prevCustomer[1].loyaltyPnts) {
            prevCustomer[1].loyaltyPnts = 0;
        }
        expect(prevCustomer[1].loyaltyPnts + cashLoyalty - custDoc.loyaltyPnts).within(-0.01, 0.01);
        prevCustomer[1] = custDoc;

        /** Old customer 
         * deducting the earned point
         * adding the redeemed point
         */
        custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        console.log(prevCustomer[0].total, total);
        let exTotal = prevCustomer[0].total - total;
        expect(exTotal).to.equal(custDoc.total);

        let temp = prevCustomer[0].loyaltyPnts - cashLoyalty;
        console.log("before sale old cus loyalty is " + prevCustomer[0].loyaltyPnts + " after sale expected lyt : " + temp);
        console.log("got loyalty : " + custDoc.loyaltyPnts);
        expect(prevCustomer[0].loyaltyPnts - custDoc.loyaltyPnts - cashLoyalty).within(-0.01, 0.01);
        prevCustomer[0] = custDoc;
    });
    it('Sale on credit with no earn', async function() {
        let itemIndex = 0;
        let stockIndex = 0;
        let uniqueIndex = 0;
        let stockKey = prevItems[itemIndex].batches[stockIndex].stockKey;
        let uniqueDetails = prevItems[itemIndex].inventory.stock[stockKey].uniqueDetails;
        let uniqueDetailsKeys = Object.keys(uniqueDetails);
        bloyaltyExist.startDate = new Date(parseInt(bloyaltyExist.startDate));
        console.log(bloyaltyExist.startDate, bloyaltyExist._rev);
        let loyaltyDoc = bloyaltyExist;
        loyaltyDoc.earnOnCredit = false;
        await lytyCntrlr.save(loyaltyDoc);
        let params = {
            item: prevItems[itemIndex].item_id,
            stockKey: stockKey
        };

        if (uniqueDetailsKeys.length) {
            params.uniqueDetails = uniqueDetails[uniqueDetailsKeys[uniqueIndex]].info;
        }
        prevResponse = await salesController.additemRestApi(params);
        let param = {
            customer_id: customerArray[0]
        };
        let total = prevResponse.total;

        prevResponse = await salesController.addCustomer2Sale(param);
        expect(prevResponse.loyaltyPnts).to.equal(total / 10);

        let paymentParams = {
            payment_type: "Sale on credit",
            amount_tendered: prevResponse.amount_due
        };

        prevResponse = await salesController.add_paymentRestApi(paymentParams);
        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });
        console.log(prevResponse.payments[0].payment_type);
        prevSaleId = resp.id;

        await commonUtils.pgTimeOut(2000);
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        console.log("before doing sale, customer lyt is " + prevCustomer[0].loyaltyPnts + " after completing sale its " + custDoc.loyaltyPnts);
        console.log("expected is " + prevCustomer[0].loyaltyPnts);
        expect(custDoc.loyaltyPnts - prevCustomer[0].loyaltyPnts).within(-0.1, 0.1);
        prevCustomer[0] = custDoc;

    });

    it('Sale on credit with earn', async function() {
        let itemIndex = 0;
        let stockIndex = 0;
        let uniqueIndex = 0;
        let stockKey = prevItems[itemIndex].batches[stockIndex].stockKey;
        let uniqueDetails = prevItems[itemIndex].inventory.stock[stockKey].uniqueDetails;
        let uniqueDetailsKeys = Object.keys(uniqueDetails);
        let loyaltyDoc = await lytyCntrlr.get();
        loyaltyDoc.startDate = new Date(parseInt(bloyaltyExist.startDate));
        console.log(loyaltyDoc.startDate, loyaltyDoc._rev);
        loyaltyDoc.earnOnCredit = true;
        await lytyCntrlr.save(loyaltyDoc);
        let params = {
            item: prevItems[itemIndex].item_id,
            stockKey: stockKey
        };

        if (uniqueDetailsKeys.length) {
            params.uniqueDetails = uniqueDetails[uniqueDetailsKeys[uniqueIndex]].info;
        }
        prevResponse = await salesController.additemRestApi(params);
        let param = {
            customer_id: customerArray[0]
        };
        let total = prevResponse.total;

        prevResponse = await salesController.addCustomer2Sale(param);
        expect(prevResponse.loyaltyPnts).to.equal(total / 10);

        let paymentParams = {
            payment_type: "Sale on credit",
            amount_tendered: prevResponse.amount_due
        };
        let expectedLyt = await salesEx.getLoyaltyPnts(prevResponse.total);
        prevResponse = await salesController.add_paymentRestApi(paymentParams);
        let resp = await salesController.completeSaleRestApi({
            comment: 'hello world'
        });
        console.log(prevResponse.payments[0].payment_type);
        prevSaleId = resp.id;

        await commonUtils.pgTimeOut(2000);
        let custDoc = await couchDBUtils.getDoc('customer_' + customerArray[0], mainDBInstance);
        prevTotal = resp.total;
        console.log("before doing sale, customer lyt is " + prevCustomer[0].loyaltyPnts + " after completing sale its " + custDoc.loyaltyPnts);
        let temp = prevCustomer[0].loyaltyPnts + expectedLyt;
        console.log("expected is " + temp);
        expect(custDoc.loyaltyPnts - expectedLyt - prevCustomer[0].loyaltyPnts).within(-0.1, 0.1);
        prevCustomer[0] = custDoc;
    })
});