/*
const cmp = {
    "_id": "cmp_1519027377726",
    "_rev": "4-230a19a3f65c99208bb4b7ad8c3e00ed",
    "customers": [
        "customer_1518010807646",
        "customer_1518259219614",
        "customer_1518259263127",
        "customer_1518171919719",
        "customer_1518264466931",
        "customer_1518264559275"
    ],
    "templateType": {
        "$index": 5,
        "name": "yes",
        "templates": [
            {
                "name": "custom",
                "message": "my sms3"
            },
            {
                "name": "custom",
                "message": "sgasgts"
            }
        ],
        "_id": "ct_1518764865193",
        "_rev": "1-1e73b5b2651b43771629aaf9bf006581"
    },
    "message": "sgasgts",
    "isTemplate": true,
    "eventDateTime": "2018-02-19T08:02:57.706Z",
    "status": "pending",
    "type": "cmp_",
    "template": {
        "name": "custom",
        "message": "sgasgts"
    },
    "nextTime": "1519027620123",
    "retryCount": 3
}
*/

const expect = require('chai').expect;
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

describe('Elemets Controller UTs  ', function() {

    this.timeout(500000);

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const commonUtils = require('../../common/commonUtils');
    const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const profitGuruFaker3 = require('../../common/profitGuruFaker3');
    let crm;
    let scheduler;
    let COMPLETED;

    let customerArray = [];
    let campaignCount;

    before(async function() {
        await couchDbManager.initCouchDb(false);
        crm = require('../../../controllers/crm');
        scheduler = require('../../../controllers/libraries/scheduler');
        scheduler.setJobFrequency(1);
        COMPLETED = crm.COMPLETED;
        customerArray = await commonUtils.getPeople(10, 'customer');
        expect(customerArray.length).to.equal(10);
        await commonUtils.pgTimeOut(10000);
        campaignCount = (await couchDBUtils.getAllDocsByType('cmp', mainDBInstance)).length;
    });

    after(function() {

    });

    xit('scheduler should have stopped as no tasks', function() {
        expect(scheduler.isRunning()).to.equal(false);
    });

    async function testCampaignPart1(msg, bAddInvalidPh, bNow) {
        campaignCount++;
        let cmpData = await profitGuruFaker3.getFakerCampaign(bAddInvalidPh, bNow);
        if (msg)
            cmpData.message = msg;
        scheduler.pause();
        let resp = await crm.create(cmpData);
        expect(resp.msg).to.equal('campaign create success');
        expect(scheduler.isRunning()).to.equal(true);
        let allCmpDocs = await couchDBUtils.getAllDocsByType('cmp', mainDBInstance);
        expect(allCmpDocs.length).to.equal(campaignCount);
        scheduler.play();
        let timeToWait = 60;
        if (bNow) {
            timeToWait = 15;
        }
        await commonUtils.pgTimeOut(timeToWait * 1000);
        expect(scheduler.isRunning()).to.equal(false);
        allCmpDocs = await couchDBUtils.getAllDocsByType('cmp', mainDBInstance);
        expect(allCmpDocs.length).to.equal(campaignCount);
        return allCmpDocs;
    }

    async function testCampaign(msg) {
        let allCmpDocs = await testCampaignPart1(msg);
        for (let i = 0; i < allCmpDocs.length; i++) {
            let doc = allCmpDocs[i].doc;
            expect(doc.status).to.equal('completed');
            for (let j = 0; j < doc.customers.length; j++) {
                expect(doc.customers[j].status).to.equal('completed');
            }
        }
    }
    async function testCampaign2(msg, bAddInvalidPh, bNow) {
        let allCmpDocs = await testCampaignPart1(msg, bAddInvalidPh, bNow);

        let i = campaignCount - 1;
        let doc = allCmpDocs[i].doc;

        for (let j = 0; j < doc.customers.length; j++) {
            if (j === 1 || j === 2) {
                expect(doc.customers[j].status).to.equal('pending');
                continue;
            }
            expect(doc.customers[j].status).to.equal('completed');
        }
        expect(doc.status).to.equal('pending');

    }

    /**
     *  
     */
    it('create campaign', async function() {
        await testCampaign();
        // await testCampaign();
    });
    it('create campaign without template', async function() {
        await testCampaign("hi hello");
    });
    it.only('create campaign 3 valid and 2 invalid cus', async function() {
        /**
         * create campaign .. send now only
         * sleep 20 s
         * get the campaign doc .. status pending and 3 customers completed 2 customers pending
         * also retry count should be maximum
         * scheduler should have killed itself
         */
        await testCampaign2("hi hello", true); // bulk
        await testCampaign2("", true, true); //individual

    });
});