// loop mocha tests https://github.com/rstacruz/mocha-repeat

//all_transactions .. the below view has been removed because it is used only for test purpose
//fix the test
// function: function(doc) {
//     var refBookingId = doc.refBookingId;

//     if (refBookingId) {
//         emit(refBookingId);
//     }
// }

'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const mdescribe = require('mocha-repeat');
const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const faker = require('faker');
const moment = require('moment');
const logger = require('../../../common/Logger');

const cntrlrUtils = require('../../../controllers/common/Utils');
const ARRAY_LENGTH = cntrlrUtils.getArrayLength;
const CLONE = cntrlrUtils.clone;
const commonTestUtils = require('../../common/commonUtils.js');
const utils = require('../../common/Utils.js');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();

const couchDbManager = require('../../../dbManagers/couchDbManager');
let roomCntrlr;

let testParamsArray = [{
    docPrefix: 'tariff',
    fakerFun: 'getFakerRoomTariff',
    bFakerFunPromise: false,
    bResetDB: true
}, {
    docPrefix: 'addOn',
    fakerFun: 'getFakerRoomAddOnTariff',
    bFakerFunPromise: false,
    bResetDB: false
}, {
    docPrefix: 'room',
    fakerFun: 'getFakerRoom',
    bFakerFunPromise: true,
    bResetDB: false
}];

mdescribe('Room CRUD UTS', testParamsArray, function(testParams) {

    this.timeout(500000);
    this.slow(0);

    let fakerData;
    let prevId;
    let profitGuruFaker3;

    before(async function() {
        if (testParams.bResetDB) {
            let logDir = '.';
            utils.deleteFilesOfType(logDir, ['log']);
        }

        await couchDbManager.initCouchDb(testParams.bResetDB);
        roomCntrlr = require('../../../controllers/Rooms.js');
        profitGuruFaker3 = require('../../common/profitGuruFaker3.js');
    });

    after(function() {});

    it('create', async function() {
        if (testParams.bFakerFunPromise) {
            fakerData = await profitGuruFaker3[testParams.fakerFun]();
        } else {
            fakerData = profitGuruFaker3[testParams.fakerFun]();
        }
        let resp = await roomCntrlr.create(fakerData, testParams.docPrefix);
        let queryResponse = await couchDBUtils.getDoc(testParams.docPrefix + '_' + resp.data.id, mainDBInstance);
        expect(utils.compareObject(fakerData, queryResponse)).to.equal(true);
        prevId = resp.data.id;
        delete fakerData.id;
        delete fakerData._id;
    });

    it('duplicate', async function() {
        if (testParams.bSkipDuplicateTest) {
            return;
        }

        let bCreated = false;
        try {
            let resp = await roomCntrlr.create(fakerData, testParams.docPrefix);
            bCreated = true;
            throw 'Duplicate Created';
        } catch (error) {
            if (bCreated) {
                throw error;
            }
            expect(error.error.indexOf('Enter Unique Values') >= 0).to.equal(true);
        }
    });

    it('update', async function() {
        fakerData.updated = 1;
        fakerData.id = prevId;
        let resp = await roomCntrlr.update(fakerData, testParams.docPrefix);
        let queryResponse = await couchDBUtils.getDoc(testParams.docPrefix + '_' + resp.data.id, mainDBInstance);
        expect(utils.compareObject(fakerData, queryResponse)).to.equal(true);
    });

    it('delete', async function() {
        let resp = await roomCntrlr.delete({
            id: prevId
        }, testParams.docPrefix);
        let queryResponse = await couchDBUtils.getDoc(testParams.docPrefix + '_' + resp.data.id, mainDBInstance);
        expect(queryResponse.deleted).to.equal('1');
    });

});

describe('Reservation Tests', function(done) {
    this.timeout(500000);
    this.slow(0);

    let fakerData;
    let prevId;
    let prevRev;
    let profitGuruFaker3;
    let maxPaymentId;

    before(async function() {
        let bReset = true;

        await couchDbManager.initCouchDb(bReset);
        roomCntrlr = require('../../../controllers/Rooms.js');
        profitGuruFaker3 = require('../../common/profitGuruFaker3.js');
        if (bReset) {
            let commonTestUtils = require('../../common/commonUtils');
            await commonTestUtils.createRoomConfig();
        }

        let autoIncrementHelper = require('../../../controllers/common/autoIncrementHelper');
        maxPaymentId = autoIncrementHelper.getMaxPaymentId();
    });

    it('make reservation test', async function() {
        fakerData = await profitGuruFaker3.getReservationForm();
        let refFakerData = CLONE(fakerData);
        for (let i = 0; i < refFakerData.bookingInfo.payments.length; i++) {
            refFakerData.bookingInfo.payments[i].id = ++maxPaymentId;
        }

        let resp = await roomCntrlr.updateBooking(fakerData);
        prevId = resp.data.id;
        let queryResponse = await couchDBUtils.getDoc('roomTrans_' + prevId, mainDBInstance);
        prevRev = queryResponse._rev;
        refFakerData.bookingInfo.refBookingId = prevId;
        expect(utils.compareObject(queryResponse, refFakerData.bookingInfo, 0, ['_id', '_rev', 'customerId'])).to.equal(true);
        queryResponse = await couchDBUtils.getView('all_room_data', 'all_transactions', {
            key: prevId,
            include_docs: true
        }, mainDBInstance);
        expect(queryResponse.length).to.equal(1);
    });

    it('update reservation test', async function() {
        fakerData = await profitGuruFaker3.getReservationForm();
        fakerData.bookingInfo.refBookingId = prevId;
        fakerData.bookingInfo._rev = prevRev;

        let refFakerData = CLONE(fakerData);
        for (let i = 0; i < refFakerData.bookingInfo.payments.length; i++) {
            refFakerData.bookingInfo.payments[i].id = ++maxPaymentId;
        }
        let resp = await roomCntrlr.updateBooking(fakerData);
        let queryResponse = await couchDBUtils.getDoc('roomTrans_' + prevId, mainDBInstance);
        prevRev = queryResponse._rev;

        refFakerData.bookingInfo.refBookingId = prevId;
        expect(utils.compareObject(queryResponse, refFakerData.bookingInfo, 0, ['_id', '_rev', 'customerId'])).to.equal(true);
        queryResponse = await couchDBUtils.getView('all_room_data', 'all_transactions', {
            key: prevId,
            include_docs: true
        }, mainDBInstance);
        expect(queryResponse.length).to.equal(1);
    });

    it('cancel reservation test', async function() {
        let queryResponse = await couchDBUtils.getView('all_room_data', 'all_transactions', {
            key: prevId,
            include_docs: true
        }, mainDBInstance);

        expect(queryResponse.length).to.equal(1);

        let params = {
            bookingInfo: await couchDBUtils.getDoc('roomTrans_' + prevId, mainDBInstance)
        };
        params.bookingInfo.status = 3;

        let totalPaid = 0;
        for (let i = 0; i < params.bookingInfo.payments.length; i++) {
            totalPaid += params.bookingInfo.payments[i].payment_amount;
        }

        ++maxPaymentId;

        params.bookingInfo.payments.push({
            bReverse: true,
            payment_type: 'Cash',
            payment_amount: totalPaid * 0.8
        });

        let resp = await roomCntrlr.updateBooking(params);

        let docIds = [];
        for (let i = 0; i < queryResponse.length; i++) {
            docIds.push(queryResponse[i].id);
        }

        queryResponse = await couchDBUtils.getDoc('roomTrans_' + prevId, mainDBInstance);
        expect(queryResponse.status).to.equal(3);
        expect(utils.compareObject(queryResponse, params.bookingInfo, 0, ['_id', '_rev', 'customerId'])).to.equal(true);
    });

    it('make reservation test', async function() {
        fakerData = await profitGuruFaker3.getReservationForm();
        let refFakerData = CLONE(fakerData);
        for (let i = 0; i < refFakerData.bookingInfo.payments.length; i++) {
            refFakerData.bookingInfo.payments[i].id = ++maxPaymentId;
        }
        let resp = await roomCntrlr.updateBooking(fakerData);
        prevId = resp.data.id;
        let queryResponse = await couchDBUtils.getDoc('roomTrans_' + prevId, mainDBInstance);
        prevRev = queryResponse._rev;
        refFakerData.bookingInfo.refBookingId = prevId;
        expect(utils.compareObject(queryResponse, refFakerData.bookingInfo, 0, ['_id', '_rev', 'customerId'])).to.equal(true);
        queryResponse = await couchDBUtils.getView('all_room_data', 'all_transactions', {
            key: prevId,
            include_docs: true
        }, mainDBInstance);
        expect(queryResponse.length).to.equal(1);
    });

    it('checkin', async function() {
        let bookingInfo = await couchDBUtils.getDoc('roomTrans_' + prevId, mainDBInstance);
        bookingInfo.status = 1;
        bookingInfo.payments.push(profitGuruFaker3.getFakerPayments());
        let resp = await roomCntrlr.updateBooking({
            bookingInfo: bookingInfo
        });
        prevId = resp.data.id;
        let queryResponse = await couchDBUtils.getDoc('roomTrans_' + prevId, mainDBInstance);
        prevRev = queryResponse._rev;
        expect(utils.compareObject(queryResponse, bookingInfo, 0, ['_id', '_rev'])).to.equal(true);
        queryResponse = await couchDBUtils.getView('all_room_data', 'all_transactions', {
            key: prevId,
            include_docs: true
        }, mainDBInstance);
        expect(queryResponse.length).to.equal(1);
    });

    it('checkout', async function() {
        let bookingInfo = await couchDBUtils.getDoc('roomTrans_' + prevId, mainDBInstance);
        bookingInfo.status = 1;
        bookingInfo.payments.push(profitGuruFaker3.getFakerPayments());

        await roomCntrlr.checkOut({
            bookingInfo: bookingInfo
        });

        let queryResponse = await couchDBUtils.getDoc('roomTrans_' + prevId, mainDBInstance);
        expect(utils.compareObject(queryResponse, bookingInfo, 0, ['_id', '_rev'])).to.equal(true);
        queryResponse = await couchDBUtils.getView('all_room_data', 'all_transactions', {
            key: prevId,
            include_docs: true
        }, mainDBInstance);
        expect(queryResponse.length).to.equal(2);
        expect(utils.compareObject(queryResponse[1].doc, bookingInfo, 0, ['_id', '_rev'])).to.equal(true);
    });

});