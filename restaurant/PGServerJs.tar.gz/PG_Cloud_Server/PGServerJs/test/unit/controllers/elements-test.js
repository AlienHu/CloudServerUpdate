// var type = [];
// type[0] = "supplier";
// type[1] = "customer";
// for (var element = 0; element < type.length; element++) {

(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });
    var utils = require('../../common/Utils.js');
    var cntrlUtils = require('../../../controllers/common/Utils.js');
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var mainDBInstance = couchDBUtils.getMainCouchDB();
    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    var chaiFiles = require('chai-files');
    chai.use(chaiFiles);
    var file = chaiFiles.file;
    chai.should();
    var expect = chai.expect;
    var type = 'supplier';
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    var faker = require('faker');
    var profitGuruFaker = require('../../common/profitGuruFaker.js');

    /**
     * CommitTodo 
     * 1. Write all the tests in a loop -> run once for customer, run once for supplier. 
     *        CouchDB Views are also different
     *        Because validations may be different.
     *        Example GSTIN is not mandatory for customer but mandatory for supplier     *          * 
     * */

    describe('Elemets Controller UTs  ', function(done) {

        this.timeout(100000);
        var elementsController = require('../../../controllers/Elements');

        var personData;
        if (type === 'customer') {
            personData = profitGuruFaker.getFakerCustomer();
        } else {
            personData = profitGuruFaker.getFakerSupplier();
        }
        var email = personData.email;

        var createdPersonID = -1;

        before(function() {
            return couchDbManager.initCouchDb(true);
        });

        //Todo: Delete all Fs created. Get proper path of logDir
        after(function() {
            var logDir = '.';
            utils.deleteFilesOfType(logDir, ['log']);
        });

        beforeEach(function() {});

        /**
         *  
         */
        it('createCustomerOrSupplier ', function() {

            personData.type = type + '_'; //type[element] + '_';
            return elementsController.create(personData).then(function(resp) {
                /**
                 * {
                 *  statusCode: 200,
                 *  message: 'Sai Chaitanya Created Successfully',
                 * data: {
                 * id: 3},
                 * error: null
                 *  }
                 */
                expect(resp.message).to.equal(personData.first_name + ' ' + personData.last_name + ' Created Successfully');
                expect(resp.error).to.equal(null);
                expect(resp.data).to.not.equal(null)
                expect(resp.data.id).to.not.equal(undefined);
                createdPersonID = resp.data.id;

                return couchDBUtils.getDoc(personData.type + createdPersonID, mainDBInstance);
            }).then(function(personDoc) {
                expect(utils.compareObject(personData, personDoc)).to.equal(true);
            }).catch(function(error) {
                expect(1).to.equal(0);
            });
        });

        it('update2 ', function() {
            personData.first_name = "vijay";
            personData.last_name = 'Chhetry';
            personData.company_name = 'AlienHu';
            //   var customerData = utils.mergeObjects([faker_person, faker_customer_config]);
            personData.person_id = createdPersonID;
            // personData.type = "customer_";
            var personType = personData.type === "customer_" ? "Customer" : "Supplier";
            return elementsController.update(personData).then(function(resp) {
                expect(resp.message).to.equal(personType + ' update successfully');
                expect(resp.error).to.equal(null);
                expect(resp.data).to.not.equal(null)
                expect(resp.data.id).to.equal(createdPersonID);

                delete personData._rev;

                return couchDBUtils.getDoc(personData.type + createdPersonID, mainDBInstance);
            }).then(function(personDoc) {
                expect(utils.compareObject(personData, personDoc)).to.equal(true);
            }).catch(function(error) {
                console.log(error);
                expect(1).to.equal(0);
            });
        });

        it('create duplicate ', function() {
            delete personData.person_id;
            delete personData._id;
            return elementsController.create(personData).then(function(resp) {
                expect(1).to.equal(0);
            }).catch(function(error) {
                console.log(error);
                expect(error.error).to.not.equal(null);
            });
        });

        it('create duplicate only phone number ', function() {

            personData.email = 'ab1c@gmail.com';
            return elementsController.create(personData).then(function(resp) {
                expect(1).to.equal(0);
            }).catch(function(error) {
                console.log(error);
                expect(error.error).to.not.equal(null);
            });
        });

        it('create duplicate only email ', function() {
            personData.phone_number = '11233';
            personData.email = email;
            return elementsController.create(personData).then(function(resp) {
                expect(1).to.equal(0);
            }).catch(function(error) {
                console.log(error);
                expect(error.error).to.not.equal(null);
            });
        });

        it('delete ', function() {
            personData.person_id = createdPersonID;
            var personType = personData.type === "customer_" ? "Customer" : "Supplier";
            return elementsController.delete(personData).then(function(resp) {
                expect(resp.message).to.equal(personType + ' deleted successfully');
                expect(resp.error).to.equal(null);
                expect(resp.data).to.not.equal(null)
                expect(resp.data.id).to.equal(createdPersonID);
                return couchDBUtils.getDoc(personData.type + createdPersonID, mainDBInstance);
            }).then(function(personDoc) {
                expect(personDoc.deleted).to.equal('1');
            }).catch(function(error) {
                expect(1).to.equal(0);
            });
        });

        function deleteAllPersons(personsInfoArray) {
            var type = type; //type[element];
            if (personsInfoArray === undefined || (personsInfoArray && personsInfoArray.length === 0)) {
                return couchDBUtils.getAllDocsByType(type, mainDBInstance).then(function(resp) {
                    var nonDeletedPersonsArray = [];
                    for (var i = 0; i < resp.length; i++) {
                        console.log(resp[i].doc);
                        if (!resp[i].doc.deleted) {
                            nonDeletedPersonsArray.push(resp[i].doc);
                        }
                    }
                    if (nonDeletedPersonsArray.length === 0) {
                        return true;
                    } else {
                        console.log("deleting");
                        console.log(nonDeletedPersonsArray.length);
                        return deleteAllPersons(nonDeletedPersonsArray);
                    }
                });
            } else {
                var param = {
                    person_id: personsInfoArray[0].person_id,
                    type: type + '_'
                };
                console.log(param.person_id);
                personsInfoArray.shift();
                return elementsController.delete(param).then(function() {
                    console.log("deleted 1");
                    return deleteAllPersons(personsInfoArray);
                });
            }
        }

        it('deleteAllCustomerTest', function() {
            return deleteAllPersons().then(function(resp) {
                expect(resp).to.equal(true);
            }).catch(function(error) {
                console.log(error);
                expect(0).to.equal(1);
            });
        });

        it('import ', function() {
            //creating customers data to write to a file
            var allPersons = [];
            for (var i = 0; i < 10; i = i + 2) {
                var data = profitGuruFaker.getFakerPersonData();
                allPersons.push(data);

                var newData = cntrlUtils.clone(data);
                newData.first_name = faker.name.firstName();
                newData.last_name = faker.name.lastName();
                newData.type = type + '_'; // type[element] + "_";
                allPersons.push(newData);
            }

            return elementsController.import(allPersons, type).then(function(resp) {
                //todo write validation for each customer
                /*{
                    message:"7 passed 3 failed",
                    data:{
                        passed:[{
                            lineNo: 1,
                            name: 'sai c',
                            id: '2017091893'
                        }],//
                        failed:[{
                            lineNo: 3,
                            name: 'vijay c',
                            reason: 'Phone Number Should be Unique'
                        }]
                    }

                }*/
                expect(resp.message).to.equal('5 Passed 5 Failed');
                expect(resp.data).to.not.equal(null);
                expect(resp.error).to.equal(null);
                expect(resp.data.passed.length).to.equal(5);
                expect(resp.data.failed.length).to.equal(5);
                for (var i = 0; i < resp.data.failed.length; i++) {
                    expect(resp.data.failed[i].lineNo).to.equal(2 + i * 2);
                    console.log(resp.data.failed[i]);
                }
                for (var i = 0; i < resp.data.passed.length; i++) {
                    expect(resp.data.passed[i].lineNo).to.equal(1 + i * 2);
                }
                //CreditsTodo write bulk get 
            }).catch(function(error) {
                console.log(error);
                expect(0).to.equal(1);
            });

        });

        //the assumption of the test is there is no previous customers using above test to delete all the customers
        // it('import customers', function() {
        //     //creating customers data to write to a file
        //     var allCustomers = [];
        //     for (var i = 0; i < 10; i = i + 2) {
        //         var data = profitGuruFaker.getFakerPersonData();
        //         allCustomers.push(data);

        //         var newData = cntrlUtils.clone(data);
        //         newData.first_name = faker.name.firstName();
        //         newData.last_name = faker.name.lastName();
        //         allCustomers.push(newData);
        //     }

        //     return elementsController.importCustomers(allCustomers).then(function(resp) {
        //         //todo write validation for each customer
        //         /*{
        //             message:"7 passed 3 failed",
        //             data:{
        //                 passed:[{
        //                     lineNo: 1,
        //                     name: 'sai c',
        //                     id: '2017091893'
        //                 }],//
        //                 failed:[{
        //                     lineNo: 3,
        //                     name: 'vijay c',
        //                     reason: 'Phone Number Should be Unique'
        //                 }]
        //             }

        //         }*/
        //         expect(resp.message).to.equal('5 Passed 5 Failed');
        //         expect(resp.data).to.not.equal(null);
        //         expect(resp.error).to.equal(null);
        //         expect(resp.data.passed.length).to.equal(5);
        //         expect(resp.data.failed.length).to.equal(5);
        //         for (var i = 0; i < resp.data.failed.length; i++) {
        //             expect(resp.data.failed[i].lineNo).to.equal(2 + i * 2);
        //             console.log(resp.data.failed[i]);
        //         }
        //         for (var i = 0; i < resp.data.passed.length; i++) {
        //             expect(resp.data.passed[i].lineNo).to.equal(1 + i * 2);
        //         }
        //         //CreditsTodo write bulk get 
        //     }).catch(function(error) {
        //         console.log(error);
        //         expect(0).to.equal(1);
        //     });

        // });

    });

})();
// }

/**
 * CreditsTodo
 * 1. Change the response of crud of customers in server => change in dapp and mapp
 * 2. response format changed for importCustomers
 */