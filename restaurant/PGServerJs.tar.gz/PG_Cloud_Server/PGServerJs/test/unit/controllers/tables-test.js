(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });
    var q = require('q');
    var faker = require('faker');
    var chai = require("chai");
    var chaiAsPromised = require("chai-as-promised");
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var assert = chai.assert;

    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var logger = require('../../../common/Logger');
    var couchDB = couchDBUtils.getMainCouchDB();

    describe('Tables Controller UTs  ', function(done) {
        this.timeout(50000000);
        var tablesController = require('../../../controllers/Tables');
        let maxTableNo = 1;
        var params = {
            key: ['_id', 'table_no'],
            reduce: true
        }

        before(async function() {
            // get max table id from couch
            try {
                await couchDbManager.initCouchDb(true)
                maxTableNo = await couchDBUtils.getReduceValue('all_tables_data', 'max_table_number', couchDB);
                maxTableNo = maxTableNo + 1;
            } catch (error) {
                logger.error(error);
                throw 'Quering max id failed';
            }
        });

        beforeEach(function() {});

        it('create table', function() {
            var tableData = {
                table_no: maxTableNo,
                desc: faker.lorem.word()
            };

            return tablesController.createTable(tableData).then(function(resp) {
                expect(resp.hasOwnProperty('status')).to.equal(true);
                expect(resp.status).to.equal('success');
                return couchDB.get('table_' + maxTableNo.toString());
            }).then(function(resp) {
                expect(resp[0].table_no).to.equal(maxTableNo);
            });
        });

        it('create table with same id should fail', function() {
            var tableData = {
                table_no: maxTableNo,
                desc: faker.lorem.word()
            };

            return tablesController.createTable(tableData).then(function(resp) {
                expect(resp.hasOwnProperty('status')).to.equal(true);
                expect(resp.status).to.equal('exists');
            });
        });

        it('create table with id <= 0 should fail', function() {
            var tableData = {
                table_no: 0,
                desc: faker.lorem.word()
            };

            return tablesController.createTable(tableData).then(function(resp) {
                expect(resp.hasOwnProperty('status')).to.equal(true);
                expect(resp.status).to.equal('invalid table no');
            });
        });

        it('get tables', function() {
            return tablesController.getTables().then(function(resp) {
                expect(resp.tables.length).to.not.equal(0);
                var bFoundTableNo = false;
                for (var i = 0; i < resp.tables.length; i++) {
                    if (resp.tables[i].table_no == maxTableNo) {
                        bFoundTableNo = true;
                        break;
                    }
                }
                expect(bFoundTableNo).to.equal(true);
            });
        });

        it('delete table', function() {
            return tablesController.deleteTable({
                table_no: maxTableNo
            }).then(function(resp) {
                expect(resp.status).to.equal('success');
                return couchDB.get('table_' + maxTableNo.toString());
            }).then(function(resp) {
                expect(1).to.equal(0);
            }).catch(function(err) {
                //couchdb query comes here
                expect(err.cause.reason).to.equal('deleted');
            });
        });

    });

})();