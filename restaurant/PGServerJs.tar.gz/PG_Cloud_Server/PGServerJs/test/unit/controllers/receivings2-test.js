   'use strict';
   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");

   var commonTestUtils = require('../../common/commonUtils.js');
   var faker = require('faker');

   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;

   const couchDbManager = require('../../../dbManagers/couchDbManager');
   var BPromise = require('bluebird');
   var profitGuruFaker = require('../../common/profitGuruFaker.js');
   var curSession = profitGuruFaker.getFakerSession();

   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   var mainDBInstance = couchDBUtils.getMainCouchDB();

   var applicationSettings = {};

   describe('Purchase 2  Credits UTS', function() {

       this.timeout(500000);
       var suppliersTransactions;
       var suppliersArray = [];
       var maxRecCreditId = 0;

       /**
        * Prerequisite: run sales-test.js complete sale with partial credit
        */
       before(function() {
           return couchDbManager.initCouchDb(false).then(function(resp) {
               applicationSettings = resp.applicationSettings;
               return commonTestUtils.getAllPendingTransactionsAndMaxCreditId('receiving');
           }).then(function(resp) {
               suppliersTransactions = resp[0];
               maxRecCreditId = resp[1];
               var bUseful = false;
               for (var id in suppliersTransactions) {
                   expect(suppliersTransactions[id].pendingTransactions.length).to.greaterThan(0);
                   suppliersArray.push(id);
                   bUseful = true;
               }
               expect(bUseful).to.equal(true);
               expect(suppliersArray.length).to.greaterThan(0);
           });

       });

       /**
        * CreditsTodo: Change all the reports and filter by type
        */

       after(function() {});

       function cleanUpSupplierTransactions() {
           for (id in suppliersTransactions) {
               if (suppliersTransactions[id].pending_amount <= 0) {
                   delete suppliersTransactions[id];
               }
           }
           suppliersArray = Object.keys(suppliersTransactions);
       }

       async function validate(params) {
           var receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);

           var parentIds = [];
           var totalPaid = 0;
           var excessPayment = 0;

           let supplierDocId = 'supplier_' + params.supplierId;
           let prevSupplierDoc = await couchDBUtils.getDoc(supplierDocId, mainDBInstance);
           let resp = await receivingsController.makeCreditPaymentForSupplier(params)
           maxRecCreditId = maxRecCreditId + 1;
           resp = await couchDBUtils.getDoc('receivingCredit_' + maxRecCreditId, mainDBInstance);

           expect(resp).to.not.equal(null);
           expect(resp.receivings_info.supplier_id).to.equal(params.supplierId);
           var paymentTypeArray = Object.keys(params.paymentsView).length;
           expect(resp.payments.length).to.equal(paymentTypeArray);
           for (var i = 0; i < paymentTypeArray.length; i++) {
               expect(resp.payments[i].payment_type).to.equal(paymentTypeArray[i]);
           }
           expect(resp.parentIds.length).to.greaterThan(0);

           excessPayment = resp.receivings_info.pending_amount * -1;

           for (var i = 0; i < resp.payments.length; i++) {
               var paymentInfo = resp.payments[i];
               var paymentAmount = paymentInfo.payment_amount;
               totalPaid += paymentAmount;
               //paymentsView
               for (var j = 0; j < params.paymentsView.length; j++) {
                   if (params.paymentsView[j].payment_type === paymentInfo.payment_type) {
                       expect(params.paymentsView[j].payment_amount).to.equal(paymentAmount);
                   }
               }

           }

           parentIds = resp.parentIds;

           await commonTestUtils.pgTimeOut(10000);

           let curSupplierDoc = await couchDBUtils.getDoc(supplierDocId, mainDBInstance);
           expect(prevSupplierDoc.credit_balance - (curSupplierDoc.credit_balance + totalPaid)).within(-0.001, 0.001);

           let newReceivingsDoc = await couchDBUtils.getAllDocs(parentIds.map(function(id) {
               return 'receiving_' + id;
           }), mainDBInstance);

           expect(parentIds.length).to.equal(newReceivingsDoc.length);
           var parentInfo = {};

           for (var i = 0; i < params.pendingTransactions.length; i++) {
               var index = parentIds.indexOf(params.pendingTransactions[i].receivings_info.receiving_id);
               if (index >= 0) {
                   parentInfo[parentIds[index]] = {
                       oldDoc: params.pendingTransactions[i],
                       newDoc: newReceivingsDoc[index].doc
                   };
               }
           }

           var total = 0;
           for (id in parentInfo) {
               var oldDoc = parentInfo[id].oldDoc;
               var newDoc = parentInfo[id].newDoc;
               var paidAmount = oldDoc.receivings_info.pending_amount - newDoc.receivings_info.pending_amount;
               total += paidAmount;
               var newPaymentsLength = newDoc.payments.length;
               expect(newPaymentsLength).to.equal(oldDoc.payments.length + 1);
               newDoc.payments[newPaymentsLength - 1].payment_amount = paidAmount;
               newDoc.payments[newPaymentsLength - 1].payment_receiving_id = maxRecCreditId;
           }

           expect(Math.abs(total + excessPayment - totalPaid)).to.lessThan(0.00001);

           //Updating the data
           for (var i = 0; i < params.pendingTransactions.length; i++) {
               var index = parentIds.indexOf(params.pendingTransactions[i].receivings_info.receiving_id);
               if (index >= 0) {
                   params.pendingTransactions[i] = newReceivingsDoc[index].doc;
               }
           }

           suppliersTransactions[params.supplierId].pending_amount -= totalPaid;
           cleanUpSupplierTransactions();

       }

       it('make less payment', function() {

           var selectedsupplierId = faker.random.arrayElement(suppliersArray);
           var selectedSupplierHistory = suppliersTransactions[selectedsupplierId];
           var params = {
               supplierId: selectedsupplierId,
               paymentsView: [{
                   payment_type: "Cash",
                   payment_amount: selectedSupplierHistory.pending_amount * 0.3,
                   ref_no: ""
               }, {
                   payment_type: "Cheque",
                   payment_amount: selectedSupplierHistory.pending_amount * 0.2,
                   ref_no: "00000"
               }],
               pendingTransactions: selectedSupplierHistory.pendingTransactions,
               comment: 'hello world',
               employeeId: 'admin'
           };

           return validate(params);

       });

       it('make exact payment', function() {

           var receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);
           var selectedsupplierId = faker.random.arrayElement(suppliersArray);
           var selectedSupplierHistory = suppliersTransactions[selectedsupplierId];
           var params = {
               supplierId: selectedsupplierId,
               paymentsView: [{
                   payment_type: "Cash",
                   payment_amount: selectedSupplierHistory.pending_amount * 0.7,
                   ref_no: ""
               }, {
                   payment_type: "Cheque",
                   payment_amount: selectedSupplierHistory.pending_amount * 0.3,
                   ref_no: "00000"
               }],
               pendingTransactions: selectedSupplierHistory.pendingTransactions,
               comment: 'hello world',
               employeeId: 'admin'
           };

           return validate(params);
       });

       it('make more payment', function() {

           var receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);
           var selectedsupplierId = faker.random.arrayElement(suppliersArray);
           var selectedSupplierHistory = suppliersTransactions[selectedsupplierId];
           var params = {
               supplierId: selectedsupplierId,
               paymentsView: [{
                   payment_type: "Cash",
                   payment_amount: selectedSupplierHistory.pending_amount * 1.3,
                   ref_no: ""
               }, {
                   payment_type: "Cheque",
                   payment_amount: selectedSupplierHistory.pending_amount * 0.2,
                   ref_no: "00000"
               }],
               pendingTransactions: selectedSupplierHistory.pendingTransactions,
               comment: 'hello world',
               employeeId: 'admin'
           };

           return validate(params);
       });

       it('payment type is 1', function() {

           var receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);
           var selectedsupplierId = faker.random.arrayElement(suppliersArray);
           var selectedSupplierHistory = suppliersTransactions[selectedsupplierId];
           var params = {
               supplierId: selectedsupplierId,
               paymentsView: [{
                   payment_type: "Cash",
                   payment_amount: selectedSupplierHistory.pending_amount * 0.3,
                   ref_no: ""
               }],
               pendingTransactions: selectedSupplierHistory.pendingTransactions,
               comment: 'hello world',
               employeeId: 'admin'
           };

           return validate(params);
       });

   });