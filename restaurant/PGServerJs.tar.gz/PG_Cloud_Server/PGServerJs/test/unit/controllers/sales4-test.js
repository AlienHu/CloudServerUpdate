/**
 * Todo: write a sales/receivings common class for tests
 */

'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

/**
 *  Todo: Items and other required elements can be created once. No need to drop everytime. Consumes too much time.
 */

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
var profitGuruFaker = require('../../common/profitGuruFaker.js');
var commonTestUtils = require('../../common/commonUtils.js');
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
var mainDBInstance = couchDBUtils.getMainCouchDB();
let itemController;
let itemControllerLib;
var faker = require('faker');

chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
const couchDbManager = require('../../../dbManagers/couchDbManager');
var BPromise = require('bluebird');
var itemList;
let items;
var applicationSettings = {};
var curSession = profitGuruFaker.getFakerSession();
var customerArray;
var prevSaleId = -1;
var suspendedSaleId = -1;
var curResponse = {};

describe('Sales Controller 4 UTS', function() {

    this.timeout(500000);
    this.slow(0);

    before(function() {
        return couchDbManager.initCouchDb(true).then(function(resp) {
            applicationSettings = resp.applicationSettings;
            itemController = require('../../../controllers/Items');
            itemControllerLib = require('../../../controllers/libraries/itemsControllerLib');
            return Promise.all([commonTestUtils.createGlobalConfigs(5), commonTestUtils.getPeople(5, 'supplier')]);
        }).then(function(resp) {
            return BPromise.props({
                allItems: commonTestUtils.getItems(2, true),
                allCustomers: commonTestUtils.getPeople(2, 'customer')
            }).then(function(promiseResults) {
                itemList = promiseResults.allItems;
                customerArray = promiseResults.allCustomers;
                expect(customerArray.length).to.be.at.least(2);
                expect(itemList.length).to.be.at.least(2);
            });
        });
    });

    after(function() {});

    function deleteItem(itemsArray) {
        return BPromise.each(itemsArray, function(item) {
            var params = {
                item_id: item.item_id
            };

            return itemController.deleteItem(params).then(function(resp) {
                console.log(resp);
            }).catch(function(err) {
                console.log(err);
                expect(1).to.equal(0);
            });
        });
    }

    it('delete item', function() {

        return deleteItem(itemList);

    });

    async function create2Items() {

        try {

            try {
                let resp = await deleteItem(itemList);

            } catch (error) {
                console.log(error);
            }
            try {
                items = await commonTestUtils.getItems(2, true);
            } catch (error) {
                console.log(error);

            }
        } catch (error) {
            console.log(error);
        }

    }

    it('add 2 Items to Cart', function() {
        curSession = profitGuruFaker.getFakerSession();
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);

        //uncomment if you want to create delete existing items and create two new items
        // return create2Items().then(function(resp) {
        // console.log(resp);
        items = itemList;
        expect(items.length).greaterThan(1);

        var ids = [0, 1];
        var itemIds = [];

        for (var i = 0; i < ids.length; i++) {
            console.log("items are " + items[ids[i]].name);
            itemIds.push(items[ids[i]].item_id);
        }
        var cartLength = [1, 2];
        var quantity = [1, 1];
        var index = 0;

        function testAddItem(id) {
            return salesController.additemRestApi({
                item: itemIds[index],
                stockKey: items[id].batches[0].stockKey
            }).then(function(resp) {
                curResponse = resp;
                expect(resp.cart.length).to.equal(cartLength[index]);
                for (var i = 0; i < resp.cart.length; i++) {
                    if (itemIds[index] === resp.cart[i].item_id) {
                        expect(resp.cart[i].quantity).to.equal(quantity[index]);
                    }
                }
                index = index + 1;
            });
        }

        return BPromise.each(ids, testAddItem);
        // });
    });

    it('complete this sale', function(done) {
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);

        var paymentParams = {
            payment_type: "Cash",
            amount_tendered: curResponse.total
        };
        salesController.add_paymentRestApi(paymentParams).then(function(resp) {
            expect(resp.cart.length).to.equal(2);
            var param = {
                customer_id: faker.random.arrayElement(customerArray)
            };
            return salesController.addCustomer2Sale(param);
        }).then(function(resp) {
            return salesController.completeSaleRestApi({
                comment: 'hello world'
            });
        }).then(function(resp) {
            console.log(resp);
            //var saleIdLength = resp.sale_id.length;
            prevSaleId = resp.id; // resp.sale_id.substring(4, saleIdLength);
            setTimeout(function() {
                done();
            }, 1000);
        });
    });

    it('compare sale item details', async function() {
        //prevSaleId
        let promiseLevel = 0;

        promiseLevel = 1;
        let resp = await commonTestUtils.getSaleDetails(prevSaleId);
        console.log("Hello people , testing sales data");

        var saleItems = resp.sale_items;

        for (var item in saleItems) {
            for (var idx in items) {
                var salesTaxes = saleItems[item].itemTaxList;
                if (saleItems[item].item_id === items[idx].item_id) {
                    for (var batch in items[idx].batches) {

                        if (items[idx].batches[batch].stockKey === saleItems[item].stockKey) {
                            var discountId = "discount_" + items[idx].batches[batch].unitsInfo[saleItems[item].unitId].pProfilesData[applicationSettings.salesConfig.pProfileId].discountId;
                            promiseLevel = 2;
                            resp = await couchDBUtils.getDoc(discountId, mainDBInstance);
                            console.log(resp);
                            items[idx].batches[batch].unitsInfo[saleItems[item].unitId].pProfilesData[applicationSettings.salesConfig.pProfileId].discountPercent = resp.discount;
                            expect(saleItems[item].sellingPrice).to.equal(items[idx].batches[batch].unitsInfo[saleItems[item].unitId].pProfilesData[applicationSettings.salesConfig.pProfileId].sellingPrice);
                            expect(saleItems[item].discount_percent).to.equal(items[idx].batches[batch].unitsInfo[saleItems[item].unitId].pProfilesData[applicationSettings.salesConfig.pProfileId].discountPercent);
                            // if (saleItems[item].sellingPrice !== items[idx].batches[batch].sellingPrice || saleItems[item].discount_percent !== items[idx].batches[batch].discountPercent) {
                            //     console.log('item details doesn\'t matches');

                            // } else {
                            if (salesTaxes.length !== 0 && items[idx].salesTaxes.length !== 0) {
                                for (var j = 0; j < salesTaxes.length; j++) {
                                    if (salesTaxes[j].item_id === items[idx].item_id) {
                                        for (var k = 0; k < items[idx].salesTaxes.length; k++) {
                                            var taxId = "tax_" + items[idx].salesTaxes[k];
                                            promiseLevel = 3;
                                            resp = await couchDBUtils.getDoc(taxId, mainDBInstance);
                                            var Itemtax = resp;
                                            if (salesTaxes[j].name === Itemtax.name)
                                                expect(salesTaxes[j].percent === Itemtax.percent).to.equal(true);
                                            // if (salesTaxes[j].percent !== Itemtax.percent && salesTaxes[j].name === Itemtax.name) {
                                            //     console.log('item details doesn\'t matches');

                                            // } else {
                                            //     console.log('Hi all good');
                                            // }

                                        }

                                    }
                                }

                                // } 
                                // else if (items[idx].salesTaxes.length !== 0 && salesTaxes.length === 0) {
                                //     console.log('item details doesn\'t matches');
                                // } else {
                                //     console.log('Hi all good');
                                // }

                            }

                        }
                    }

                }
            }

        }
    });

    xit('reset sales data', async function() {
        let salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        let resp = await salesController.resetSalesInfo();
        let saleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
        let inventoryDocs = await couchDBUtils.getAllDocsByType('inventory', mainDBInstance);
        let invUpdateDocs = [];
        for (let j = 0; j < inventoryDocs.length; j++) {
            for (let trans in inventoryDocs[j].doc.transactions) {
                let type = inventoryDocs[j].doc.transactions[trans].trans_comment.substring(0, 3);
                if (type === 'POS') {
                    expect(0).to.equal(1);
                }
            }
        }

        let saleReturnDocs = await couchDBUtils.getAllDocsByType('saleReturn', mainDBInstance);
        let returnInventoryDocs = await couchDBUtils.getAllDocsByType('inventory', mainDBInstance);
        for (let j = 0; j < returnInventoryDocs.length; j++) {
            for (let trans in returnInventoryDocs[j].doc.transactions) {
                let type = returnInventoryDocs[j].doc.transactions[trans].trans_comment.substring(0, 4);
                if (type === 'POSR') {
                    expect(0).to.equal(1);
                }
            }
        }
        expect(saleDocs.length).to.equal(0);
        expect(saleReturnDocs.length).to.equal(0);

    })

    xit('delete sale by id', async function() {
        let salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        try {
            let resp = await salesController.deleteSaleById('sale_' + 1);
            let saleDocs = await couchDBUtils.getDoc('sale_' + 1, mainDBInstance, 'Failed to fetch the sales documnet');

            let inventoryDocs = await couchDBUtils.getAllDocsByType('inventory', mainDBInstance);
            let invUpdateDocs = [];
            for (let j = 0; j < inventoryDocs.length; j++) {
                for (let trans in inventoryDocs[j].doc.transactions) {
                    let saleIdLength = inventoryDocs[j].doc.transactions[trans].trans_comment.length;
                    let invSaleId = inventoryDocs[j].doc.transactions[trans].trans_comment.substring(4, saleIdLength);
                    if (invSaleId === saleId) {
                        expect(0).to.equal(1);
                    }
                }
            }
            if (saleDocs) {
                expect(0).equal.toString(1);
            }
        } catch (error) {
            expect(error.error).to.equal('Transaction Doesnot exist');
        }

    })

});