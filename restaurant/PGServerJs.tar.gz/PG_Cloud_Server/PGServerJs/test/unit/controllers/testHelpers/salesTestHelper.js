const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

let helper = function() {
    let _self = this;
    let itemControllerLib, commonLib, saleCntrlrLib, computeUtils, curSession, applicationSettings;

    this.set = function(_itemControllerLib, _commonLib, _saleCntrlrLib, _computeUtils, _curSession, _applicationSettings) {
        itemControllerLib = _itemControllerLib;
        commonLib = _commonLib;
        saleCntrlrLib = _saleCntrlrLib;
        computeUtils = _computeUtils;
        curSession = _curSession;
        applicationSettings = _applicationSettings;
    };

    let calculations = {
        total: 0,
        totalNoDiscountNoChargesNoTax: 0,
        totalNoChargesNoTax: 0,
        totalNoTax: 0,
        totalDiscount: 0,
        totalCharges: 0,
        totalTax: 0,
        globalDiscount: 0,
        globalDiscountPercent: 0,
        cart: []
    };

    async function computeItem(item_id, stockKey, quantity, inpPrice, unitId, iAddGlobalDiscount, globalDiscountParam) {
        if (iAddGlobalDiscount === undefined) {
            iAddGlobalDiscount = 1;
        }

        let itemInfo = await itemControllerLib.getThisItemInfo({
            item_id: item_id,
            stockKey: stockKey
        });

        let curPProfileData = await saleCntrlrLib.getPProfileData(itemInfo.batches[0].unitsInfo[unitId].pProfilesData);

        let taxes = [];
        let chargesTaxes = [];
        if (!inpPrice) {
            inpPrice = curPProfileData.sellingPrice;
        }
        let baseUnitPrice = commonLib.getBaseUnitPrice(inpPrice, unitId, itemInfo.baseUnitId, itemInfo.batches[0].unitsInfo);
        saleCntrlrLib.getTaxesForItem(itemInfo.salesTaxes, itemInfo.salesSlab, baseUnitPrice, taxes, chargesTaxes, itemInfo.bSPTaxInclusive, itemInfo.ItemType);
        let charges = [];
        if (curSession.settings.sales.profile) {
            charges = curSession.settings.sales.profile.charges;
        }

        let totalTaxPercent = computeUtils.getTotalTaxPercent2(taxes) * 0.01;
        let totalChargesPercent = computeUtils.getTotalTaxPercent2(charges) * 0.01;
        let totalChargesTaxesPercent = computeUtils.getTotalTaxPercent2(chargesTaxes) * 0.01;

        let price = computeUtils.getPriceTaxEx(inpPrice, itemInfo.bSPTaxInclusive);
        let gDiscountPercent = globalDiscountParam.value;
        if (!globalDiscountParam.bPercent) {
            let curItemDiscount = globalDiscountParam.value / globalDiscountParam.itemCount;
            gDiscountPercent = 100 * curItemDiscount / (price * quantity)
        }

        let discount = 0;
        if (curPProfileData.discount) {
            discount = curPProfileData.discount.discount
        }
        discount = (discount + gDiscountPercent * iAddGlobalDiscount) * 0.01;

        return {
            total: ((price * quantity * (1 - discount) * (1 + totalTaxPercent)) + (price * quantity * (1 - discount) * totalChargesPercent * (1 + totalChargesTaxesPercent))),
            totalNoDiscountNoChargesNoTax: price * quantity,
            totalNoChargesNoTax: price * quantity * (1 - discount),
            totalNoTax: price * quantity * (1 - discount) * (1 + totalChargesPercent),
            totalDiscount: price * quantity * discount,
            totalCharges: price * quantity * (1 - discount) * totalChargesPercent,
            totalTax: ((price * quantity * (1 - discount) * totalTaxPercent) + (price * quantity * (1 - discount) * totalChargesPercent * totalChargesTaxesPercent))
        };
    }

    function compute(globalDiscountParam) {
        calculations = {
            total: 0,
            totalNoDiscountNoChargesNoTax: 0,
            totalNoChargesNoTax: 0,
            totalNoTax: 0,
            totalDiscount: 0,
            totalCharges: 0,
            totalTax: 0,
            globalDiscount: 0,
            globalDiscountPercent: 0,
            cart: calculations.cart
        };

        for (let i = 0; i < calculations.cart.length; i++) {
            calculations.total += calculations.cart[i].total;
            calculations.totalNoDiscountNoChargesNoTax += calculations.cart[i].totalNoDiscountNoChargesNoTax;
            calculations.totalNoChargesNoTax += calculations.cart[i].totalNoChargesNoTax;
            calculations.totalNoTax += calculations.cart[i].totalNoTax;
            calculations.totalDiscount += calculations.cart[i].totalDiscount;
            calculations.totalCharges += calculations.cart[i].totalCharges;
            calculations.totalTax += calculations.cart[i].totalTax;
        }

        if (globalDiscountParam.bPercent) {
            calculations.globalDiscount = calculations.totalNoDiscountNoChargesNoTax * globalDiscountParam.value * 0.01;
            calculations.globalDiscountPercent = globalDiscountParam.value;
        } else {
            calculations.globalDiscountPercent = (100 * globalDiscountParam.value) / calculations.totalNoDiscountNoChargesNoTax;
            calculations.globalDiscount = globalDiscountParam.value;
        }
    }

    this.compareOverAllResponse = async function(response, globalDiscountParam, bIgnoreGlobalComparison) {

        //This has been added because global discount is excluded in cart calculations
        calculations.cart = [];
        for (let i = 0; i < response.cart.length; i++) {
            let cartItem = response.cart[i];
            let computeResp = await computeItem(cartItem.item_id, cartItem.stockKey, cartItem.quantity, cartItem.price, cartItem.unitId, 0, globalDiscountParam);
            expect(computeResp.total - cartItem.totalWithTax).within(-1, 1);
            expect(computeResp.totalNoDiscountNoChargesNoTax - cartItem.total).within(-0.01, 0.01);
            expect(computeResp.totalNoChargesNoTax - cartItem.discounted_total).within(-0.01, 0.01);
            expect(computeResp.totalNoTax - cartItem.totalAfterDisAndCharges).within(-0.01, 0.01);
            expect(computeResp.totalDiscount - cartItem.discounted_price).within(-0.01, 0.01);
            //because in the each cart global discount is not considered but in total.. it is considered
            calculations.cart.push(await computeItem(cartItem.item_id, cartItem.stockKey, cartItem.quantity, cartItem.price, cartItem.unitId, 1, globalDiscountParam));
        }

        compute(globalDiscountParam);
        //totalNoDiscountNoChargesNoTax, totalNoTax, totalCharges, totalTax not available
        expect(calculations.total - response.total).within(-1, 1);
        expect(calculations.totalNoChargesNoTax - response.tax_exclusive_subtotal).within(-0.01, 0.01);
        expect(calculations.totalDiscount - response.discount).within(-0.01, 0.01);
        if (!bIgnoreGlobalComparison) {
            expect(calculations.globalDiscount - response.globalDiscountInfo.amt).within(-0.01, 0.01);
            expect(calculations.globalDiscountPercent - response.globalDiscountInfo.percent).within(-1, 1);
        }
    };
}

module.exports = new helper();