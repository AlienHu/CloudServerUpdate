let foo = function() {
    var chai = require("chai");
    const chaiAsPromised = require("chai-as-promised");
    chai.use(chaiAsPromised);
    chai.should();
    const expect = chai.expect;

    const utils = require('../../../common/Utils.js');
    const couchDBUtils = require('../../../../controllers/common/CouchDBUtils');
    const couchDB = couchDBUtils.getMainCouchDB();

    //unused arg uniqueKey
    this.validateConfigData = function(resp, data, docPrefix, uniqueKey) {
        expect(resp.status).to.equal(0);

        return couchDB.get(docPrefix + '_' + resp.id).spread(function(body, header) {
            expect(utils.compareObject(data, body)).to.equal(true);
            return resp.id;
        }).catch(function(error) {
            console.log(error);
            expect(0).to.equal(1);
        });
    };

    this.validateConfigDelete = function(id, docPrefix) {
        return couchDB.get(docPrefix + '_' + id).spread(function(body, header) {
            expect(body.deleted).to.equal('1');
        });
    };

};

module.exports = new foo();