'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

/**
 *  Todo: Items and other required elements can be created once. No need to drop everytime. Consumes too much time.
 */

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
var profitGuruFaker = require('../../common/profitGuruFaker.js');
var commonTestUtils = require('../../common/commonUtils.js');
var faker = require('faker');

let couchDBUtils = require('../../../controllers/common/CouchDBUtils');
let mainDBInstance = couchDBUtils.getMainCouchDB();

chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
const couchDbManager = require('../../../dbManagers/couchDbManager');
var BPromise = require('bluebird');
var itemList;
var applicationSettings = {};
var curSession = profitGuruFaker.getFakerSession();
var customerArray;
var prevSaleId = -1;
var suspendedSaleId = -1;
var itemInfo = {};
var inventoryIndex = {};
var previousInventoryDocs;
var currentInventoryDocs;
var salesController;
var previousitemQuantity;

describe('Sales Controller UTS', function() {

    this.timeout(500000);

    before(function() {
        return couchDbManager.initCouchDb(false).then(function(resp) {
            applicationSettings = resp.applicationSettings;
            //TODO BK depricate Models.profitGuru_app_config.initConfig()
            return Promise.all([commonTestUtils.createGlobalConfigs(5), commonTestUtils.getPeople(5, 'supplier')]);
        }).then(function(resp) {
            return BPromise.props({
                allItems: commonTestUtils.getItems(7, false),
                allCustomers: commonTestUtils.getPeople(5, 'customer')
            }).then(function(promiseResults) {
                // //console.log(promiseResults);
                itemList = promiseResults.allItems;
                customerArray = promiseResults.allCustomers;
                expect(customerArray.length).to.be.at.least(5);
                expect(itemList.length).to.be.at.least(7);
                // appSettings: Models.profitGuru_app_config.findAll()
                // promiseResults.appSettings.forEach(function(settingsElement) {
                //     applicationSettings[settingsElement.key] = settingsElement.value;
                // });
                ////console.log('Number of Items create=', allItem.length);
            });
        });

    });

    after(function() {});
    var salesController;
    it('add Item to Cart', function() {
        curSession = profitGuruFaker.getFakerSession();
        salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        expect(itemList.length).greaterThan(4);

        var ids = [0, 2, 3, 0, 1, 4, 2, 2, 3];
        var itemIds = [];
        for (var i = 0; i < ids.length; i++) {
            itemIds.push(itemList[ids[i]].item_id);
        }
        var cartLength = [1, 2, 3, 3, 4, 5, 5, 5, 5];
        var quantity = [1, 1, 1, 2, 1, 1, 2, 3, 2];
        var index = 0;

        function testAddItem(id) {
            return salesController.additemRestApi({
                item: itemIds[index],
                stockKey: itemList[id].batches[0].stockKey
            }).then(function(resp) {
                expect(resp.cart.length).to.equal(cartLength[index]);
                for (var i = 0; i < resp.cart.length; i++) {
                    if (itemIds[index] === resp.cart[i].item_id) {
                        expect(resp.cart[i].quantity).to.equal(quantity[index]);
                    }
                }
                index = index + 1;
            });
        }

        return BPromise.each(ids, testAddItem);
    });

    it('make Payments', function() {
        curSession = profitGuruFaker.getFakerSession();
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        expect(itemList.length).greaterThan(0);

        return salesController.additemRestApi({
            item: itemList[0].item_id,
            stockKey: itemList[0].batches[0].stockKey
        }).then(function(resp) {

            expect(resp.cart.length).to.equal(1);
            var paymentParams = {
                payment_type: "Cash",
                amount_tendered: resp.amount_due
            };
            return salesController.add_paymentRestApi(paymentParams);
        }).then(function(resp) {
            //console.log(resp);
            expect(resp.amount_due).to.equal(0);
        });
    });

    it('add customer to sale', function() {
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        var param = {
            customer_id: faker.random.arrayElement(customerArray)
        };

        return salesController.addCustomer2Sale(param).then(function(resp) {
            expect(resp.succs_customer_id).to.equal(param.customer_id);
        });
    });

    it('Save SO Order', async function() {
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);

        // let resp = await salesController.saveSOOrder();
        // let resp1 = await salesController.loadSOOrder();
        // let resp1 = await salesController.completeSOOrder();
        // let resp1 = await salesController.quickSOOrder();

        // let resp = await salesController.loadSaleQuotation({
        //     _id: "sq_3"
        // });
        // let resp = await salesController.saveSaleQuotation();
        let resp = await salesController.printSaleQuotation({
            _id: "sq_3"
        });

        console.log("resp", resp);
    });

});