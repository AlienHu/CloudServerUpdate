"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const scheduleCampaignHelper_1 = require("../../../controllers/libraries/scheduleCampaignHelper");
const scheduler_1 = require("../../../controllers/libraries/scheduler");
const couchDbManager = require("../../../dbManagers/couchDbManager");
const commonUtils = require("../../common/commonUtils");
const sms = require("../../../sms/sms");
const smsDAO = require("../../../sms/smsDAO");
const applicationSettingsDAO = require("../../../DAO/applicationSettingsDAO");
const couchDBApis = require('../../../TSCouchDB/Common/couchDBApis');
const getCoreDBInstance = require('../../../TSCouchDB/Common/dbInstanceHelper').getCoreDBInstance;
const getMainDBInstance = require('../../../TSCouchDB/Common/dbInstanceHelper').getMainDBInstance;
const profitGuruFaker3 = require('../../common/profitGuruFaker3');
const scheduler = require("../../../controllers/libraries/scheduler");
const crm = require("../../../controllers/crm");
const moment = require("moment");
describe('CRM UT', function () {
    this.timeout(100000);
    let dbContext;
    let customerArray;
    let applicationSettings;
    let campaignCount;
    let smsCount = 0;
    before(function () {
        return __awaiter(this, void 0, void 0, function* () {
            scheduler.setJobFrequency(1);
            const resp = yield couchDbManager.initCouchDb(false);
            applicationSettings = Object.assign({}, resp.applicationSettings);
            smsCount = applicationSettings.smsCounter.transCounter;
            console.log("count before is " + applicationSettings.smsCounter.transCounter);
            dbContext = resp.dbContext;
            profitGuruFaker3.setDBContext(dbContext);
            commonUtils.setDBContext(dbContext);
            customerArray = yield commonUtils.getPeople(2, 'customer');
            sms.disableSMSForUT();
            let res = yield couchDBApis.getAllDocsByType(dbContext, 'cmp', getMainDBInstance);
            campaignCount = res.length;
            console.log("campaign count is " + campaignCount);
        });
    });
    it('testing generateSchedules4UT', () => {
        let startTime = moment().format();
        let endTime = moment().add('days', 7).format();
        let data = {
            "message": "linto hello",
            "customers": [
                {
                    "_id": 'customer_' + customerArray[0],
                    "status": "pending"
                }
            ],
            "dayOfWeekArr": [
                0, 1, 2, 3, 4, 5, 6
            ],
            "timeOfDayArr": [
                "1970-01-01T12:00:00.000Z"
            ],
            "startDate": startTime,
            "endDate": endTime,
            "status": "pending"
        };
        scheduleCampaignHelper_1.generateSchedules(data);
        expect(data.scheduleStatusArr.length).to.equal(8);
        let firstTime = moment(data.startDate).startOf('day');
        let dayNumber = 0;
        data.scheduleStatusArr.forEach(function (sch) {
            data.timeOfDayArr.forEach(function (time) {
                let schTime = new Date(time);
                let hours = schTime.getHours();
                let minutes = schTime.getMinutes();
                let ts = moment(firstTime).startOf('day').add(dayNumber, 'day').add(hours, 'h').add(minutes, 'm').format('x');
                expect(sch.timestamp).to.equal(ts);
            });
            dayNumber += 1;
        });
    });
    it('testing processWisher4UT', () => {
        let startTime = moment('2018-03-19');
        let data = {
            "message": "linto hello",
            "customers": [
                {
                    "_id": "customer_1521046268402",
                    "status": "pending"
                }
            ],
            "dayOfWeekArr": [
                0, 1, 2, 3, 4, 5, 6
            ],
            "timeOfDayArr": [
                "1970-01-01T20:00:00.000Z"
            ],
            daysBefore: 20,
            type: 'birth_day',
            "status": "pending"
        };
        scheduler_1.processWisher4UT(dbContext);
    });
    it('testing getBdayCustomers4UT', () => __awaiter(this, void 0, void 0, function* () {
        let start = moment().startOf('day').toISOString();
        let end = moment().add(4, 'days').endOf('day').toISOString();
        let type = 'birth_day';
        let customers = yield scheduler_1.getBdayCustomers4UT(type, start, end, dbContext);
        expect(customers.length).to.equal(0);
    }));
    /**
     * CRM missing test cases
     *
     * - Send SMS : sms.js
     * - Get SMS stats : smsDAO
     * - Send E-Mail --ignore
     * - Create campaign
     *      - sms  --exists
     *      - email
     *      - both
     * - Create feedback campaign
     * - Deactivate campaign
     * - Create sheduler
     *      - Every days --exists
     *      - Selected days
     * - Deactivate scheduler
     * - Create auto wisher
     *      - On day
     *      - Before the day --exists
     * - Deacivate auto wisher
     * - Create template
     * - Update template
     * - Create feedback form
     * - Update feeedback form
     *
     * How to check SMS is send?
     * Ans :- check the sms counts and returns how many sms send.
     */
    function getSendSMSCount() {
        return __awaiter(this, void 0, void 0, function* () {
            let num = 0;
            let newSettingsDoc = yield applicationSettingsDAO.getApplcationSettings(dbContext);
            console.log("New count is " + newSettingsDoc.smsCounter.transCounter + " old is " + smsCount);
            num = newSettingsDoc.smsCounter.transCounter - smsCount;
            smsCount = newSettingsDoc.smsCounter.transCounter;
            return num;
        });
    }
    it('Send SMS', () => __awaiter(this, void 0, void 0, function* () {
        let params = {
            To: '9916586068',
            Msg: 'sms message test',
            Multiple: true,
            Type: 'TRANS',
            From: 'ALINHU'
        };
        yield sms.sendSMS(params, dbContext);
        let smsCount = yield getSendSMSCount();
        expect(smsCount).to.equal(1);
    }));
    it('Get sms offers', () => __awaiter(this, void 0, void 0, function* () {
        let smsOffer = yield smsDAO.get(dbContext);
        expect(smsOffer).property('_id');
    }));
    function testCampaignPart1(msg, bAddInvalidPh, bNow) {
        return __awaiter(this, void 0, void 0, function* () {
            campaignCount++;
            let cmpData = yield profitGuruFaker3.getFakerCampaign(bAddInvalidPh, bNow);
            if (msg)
                cmpData.message = msg;
            scheduler.pause();
            let resp = yield crm.createCampaign(cmpData, dbContext);
            console.log(resp);
            expect(resp.msg).to.equal('campaign create success');
            expect(scheduler.isRunning()).to.equal(true);
            yield commonUtils.pgTimeOut(2000);
            let allCmpDocs = yield couchDBApis.getAllDocsByType(dbContext, 'cmp', getMainDBInstance);
            expect(allCmpDocs.length).to.equal(campaignCount);
            scheduler.play();
            let timeToWait = 60;
            if (bNow) {
                timeToWait = 15;
            }
            yield commonUtils.pgTimeOut(timeToWait * 1000);
            expect(scheduler.isRunning()).to.equal(false);
            allCmpDocs = yield couchDBApis.getAllDocsByType(dbContext, 'cmp', getMainDBInstance);
            expect(allCmpDocs.length).to.equal(campaignCount);
            return allCmpDocs;
        });
    }
    function testCampaign(msg) {
        return __awaiter(this, void 0, void 0, function* () {
            let allCmpDocs = yield testCampaignPart1(msg);
            for (let i = 0; i < allCmpDocs.length; i++) {
                let doc = allCmpDocs[i].doc;
                expect(doc.status).to.equal('completed');
                for (let j = 0; j < doc.customers.length; j++) {
                    expect(doc.customers[j].status).to.equal('completed');
                }
            }
        });
    }
    it('create campaign', function () {
        return __awaiter(this, void 0, void 0, function* () {
            yield testCampaign();
        });
    });
});
//# sourceMappingURL=crmts-test.js.map