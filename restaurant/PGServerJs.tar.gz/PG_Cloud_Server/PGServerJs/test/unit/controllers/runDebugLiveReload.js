#!/usr/bin/env node

require('shelljs/global');
var log = console.log;
var chalk = require('chalk');
var argv = require('yargs')
	.alias('t', 'test')
	.describe('t', 'UT to Debug')
	.help('h')
	.alias('h', 'help')
	.argv;

var debugTarget = argv.t || 'UT_sales.js';
debugTarget = process.env.PWD + '/' + debugTarget;

if (!which('nodemon')) {
	log(chalk.magenta('Installing nodemon'));
	exec('npm install -g --force nodemon');
}

if (!which('concurrently')) {

	log(chalk.magenta('Installing concurrently'));
	exec('npm install -g concurrently');
	log(chalk.magenta('Resatrt the bootStrap.js script'));
	exit(0);
}

if (!which('node-inspector')) {
	//If you get Error in the debugger try uninstall and re-installing the node-inspector
	log(chalk.magenta('Installing node-inspector'));
	exec('npm install node-inspector -g');
}

log(chalk.magenta('Running Configurations'));

//var launchProfitGuruNodeServer = 'concurrently "node-debug --web-port 9090 --no-preload " "nodemon --debug-brk app.js"';
//var launchProfitGuruNodeServer = 'concurrently "node-debug --web-port 9090 " "nodemon --debug-brk node_modules/mocha/bin/_mocha" test/unit/controllers/UT_sales.js"';
//var launchProfitGuruNodeServer = 'concurrently "node-debug --web-port 9090 " "nodemon --debug-brk /home/balakrishna/profitGuru-master/PGServerJs/node_modules/mocha/bin/_mocha" "UT_items.js"';
var launchProfitGuruNodeServer = 'concurrently "node-debug --web-port 9090 " "nodemon --debug-brk /home/balakrishna/profitGuru-master/PGServerJs/node_modules/mocha/bin/_mocha ./UT_sales.js"';
log(chalk.yellow(launchProfitGuruNodeServer));
exec(launchProfitGuruNodeServer);