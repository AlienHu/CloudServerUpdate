let globalConfigController = require('../../../controllers/GlobalConfigurations');
let couchDBUtils = require('../../../controllers/common/CouchDBUtils');
var utils = require('../../../controllers/common/Utils');
var mainDBInstance = couchDBUtils.getMainCouchDB();
const CLONE = utils.clone;
let _self = this;

this.getcustomizeData = async function(userData) {
    let pProfilesData = {};
    let unitsInfo = {};

    userData.categoryId = await _self.checkDocExist(userData.category_name, 'category');
    userData.defaultPurchaseUnitId = await _self.checkDocExist(userData.sellingUnit, 'unit');
    userData.defaultSellingUnitId = await _self.checkDocExist(userData.purchaseUnit, 'unit');
    if (userData.purchaseTax && userData.purchaseTax.name) {
        userData.purchaseTaxes.push(await _self.getDiscountOrTaxId(userData.purchaseTax, 'tax'));
    }
    if (userData.salesTax && userData.salesTax.name) {
        userData.salesTaxes.push(await _self.getDiscountOrTaxId(userData.salesTax, 'tax'));
    }
    userData.discountId = "";
    if (userData.discount && userData.discount.name) {
        userData.discountId = await _self.getDiscountOrTaxId(userData.discount, 'discount');
    }

    let pProfileId = await _self.getAllConfigDocsByType('pProfile');
    userData.baseUnitId = userData.defaultSellingUnitId;
    pProfilesData[pProfileId] = {
        sellingPrice: userData.sellingPrice,
        discountId: userData.discountId
    }
    unitsInfo[userData.baseUnitId] = {
        refUnitId: userData.baseUnitId,
        factor: userData.factor,
        purchasePrice: userData.purchasePrice,
        mrp: userData.mrp,
        pProfilesData: pProfilesData
    }
    userData.unitsInfo = unitsInfo;
    delete userData.sellingUnit;
    delete userData.purchaseUnit;
    delete userData.category_name;
    delete userData.discount;
    delete userData.purchaseTax;
    delete userData.salesTax;
    return userData;
}

this.checkDocExist = async function(docName, type) {
    let resp;
    let viewType = 'item-settings_unique_' + type;
    docName = docName.toLowerCase();
    let categorys = await couchDBUtils.getView('all_items_data', viewType, {
        key: docName
    }, mainDBInstance);
    if (categorys.length) {
        resp = parseInt(categorys[0].id.split('_')[1]);
        return resp;
    }
    try {
        let responce = {};
        let doc = {
            name: docName,
            description: 'Test ' + type
        };
        switch (type) {
            case 'unit':
                responce = await globalConfigController.createUnit(doc);
                break;
            default:
                responce = await globalConfigController.createCategory(doc);
        }
        console.log(responce.msg + responce.id)
        resp = responce.id;
        return resp;
    } catch (err) {
        console.log(err);
        console.log('error in item creation');
    }
}

this.getAllConfigDocsByType = async function(type) {
    let pProfiles = await globalConfigController.getAllConfigDocsByType(type);
    return pProfiles[0].doc.id;
}
this.getDiscountOrTaxId = async function(doc, type) {
    let resp;
    let viewType = 'item-settings_unique_' + type;
    doc.name = doc.name.toLowerCase();
    let key
    if (type == 'discount') {
        key = doc.name + "_" + doc.discount;
    } else {
        key = doc.name + "_" + doc.percent;
    }
    let categorys = await couchDBUtils.getView('all_items_data', viewType, {}, mainDBInstance);
    for (let x = 0; x < categorys.length; x++) {
        if (categorys[x].key == key.toLowerCase()) {
            resp = parseInt(categorys[x].id.split('_')[1]);
            return resp;
        }
    }
    try {
        let responce = {};
        switch (type) {
            case 'discount':
                responce = await globalConfigController.createDiscount(doc);
                break;
            default:
                responce = await globalConfigController.createTax(doc);
        }
        console.log(responce.msg + responce.id)
        return responce.id;
    } catch (err) {
        console.log(err);
        console.log('error in item creation');
        throw err;
    }
}