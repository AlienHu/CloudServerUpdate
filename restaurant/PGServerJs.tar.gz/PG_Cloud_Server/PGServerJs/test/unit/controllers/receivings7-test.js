'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const faker = require('faker');
const profitGuruFaker = require('../../common/profitGuruFaker.js');
const logger = require('../../../common/Logger');
const utils = require('../../common/Utils.js');
const CLONE = utils.clone;
const commonUtils = require('../../common/commonUtils');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
let receivingsController;
let receivingsTestHelper;
let itemLib;
let commonLib;
let commonWorker;
let bReceivingEdit = false;

/**
 * 1. no batches, nothing
 * 2. batches/variants/serial - no mu + pp
 * 3. batches/variants
 * 
 * in case of no batches warning saying price details are changed
 * 
 * add/edit
 * payment credit
 * 
 * computations in the above cases
 * 
 * verification
 * stock increase according to factor
 * inventory transaction
 * item price details saved correctly
 * default price changed correctly
 * 
 * edit
 * validation for mu
 * stock change according to factor
 * item price details changed correctly..
 * default price changed correctly
 * imei changed to itemAvailable false
 * itemAvailable - sold === stock
 */

describe('Purchase Controller 7 Purchase Edit UTS', function() {

    this.timeout(500000);
    this.slow(0);

    let curItems;
    let prevItems;
    let allVariants;
    let supplierArray;
    let prevResponse;
    let prevReceivingId;
    let timeStamp;
    let prevInv = [];
    let prevItem = [];
    let prevSupplier = [];
    let prevTotal = 0;
    let cart = [];

    const curSession = profitGuruFaker.getFakerSession();
    let applicationSettings;

    before(async function() {
        let logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);

        let bResetDB = true;
        let resp = await couchDbManager.initCouchDb(bResetDB);
        applicationSettings = resp.applicationSettings;
        commonWorker = require('../../../controllers/workers/commonWorker');
        // commonWorker.setFreeze(true);

        prevItems = await commonUtils.createAllItemTypes(true, true);
        supplierArray = await commonUtils.getPeople(2, 'supplier');
        allVariants = await couchDBUtils.getAllDocsByType('variant', mainDBInstance, {}, true);
        receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);
        receivingsTestHelper = require('./testHelpers/receivingsTestHelper')(curSession, applicationSettings);
        itemLib = require('../../../controllers/libraries/itemsControllerLib');
        commonLib = require('../../../controllers/libraries/commonLib');
    });

    after(function() {});

    function getStockKey(item_id, batchId, attributeInfo, hasBatchNumber, hasVariants) {
        let stockKey = itemLib.formatStockKey(item_id, batchId, attributeInfo);
        if (!hasBatchNumber && !hasVariants) {
            stockKey = prevItems[item_id - 1].batches[0].stockKey;
        }

        return stockKey;
    }

    function updateFactor(response) {
        for (let i = 0; i < response.cart.length; i++) {
            let cartItem = response.cart[i];
            let itemIndex = cartItem.item_id - 1;
            let stockKey = getStockKey(cartItem.item_id, cartItem.batchId, cartItem.attributeInfo, cartItem.hasBatchNumber, cartItem.hasVariants);
            cart[itemIndex].stock[stockKey].factor = commonLib.getFactor(cartItem.unitsInfo, cartItem.unitId, cartItem.baseUnitId);
            cart[itemIndex].stock[stockKey].unitsInfo = cartItem.unitsInfo;
        }
    }

    async function deleteItem(line, response) {
        let params = {
            item: line
        };

        let resp = getCartItemIndex(line, response);
        let cartItem = resp.cartItem;
        let stockKey = getStockKey(cartItem.item_id, cartItem.batchId, cartItem.attributeInfo, cartItem.hasBatchNumber, cartItem.hasVariants);
        if (bReceivingEdit) {
            cart[cartItem.item_id - 1].stock[stockKey].returnedUniqueDetails = CLONE(cart[cartItem.item_id - 1].stock[stockKey].uniqueDetails);
        }
        cart[cartItem.item_id - 1].stock[stockKey].uniqueDetails = [];
        cart[cartItem.item_id - 1].stock[stockKey].quantity = 0;
        response = await receivingsController.delteItemFromCart(params);
        await receivingsTestHelper.compareOverAllResponse(response);

        return response;
    }

    async function addItem(itemIndex, response, line, bRemove) {
        if (itemIndex === undefined) {
            itemIndex = response.cart[line - 1].item_id - 1;
        }

        let params = {
            item: prevItems[itemIndex].item_id
        };

        params.uniqueDetails = [];

        if (prevItems[itemIndex].imeiCount !== 0 || prevItems[itemIndex].is_serialized) {
            if (bRemove) {
                let subLines = Object.keys(response.cart[line - 1].uniqueDetails);
                let detail = response.cart[line - 1].uniqueDetails[subLines[0]];
                params.uniqueDetails.push({
                    serialnumber: detail.serialnumber,
                    imeiNumbers: detail.imeiNumbers
                });
            } else {
                params.quantity = 4;
                for (let i = 0; i < 4; i++) {
                    let imeiNumbers = [];
                    for (let j = 0; j < prevItems[itemIndex].imeiCount; j++) {
                        imeiNumbers.push((faker.random.uuid()).toString());
                    }

                    params.uniqueDetails.push({
                        serialnumber: (faker.random.uuid()).toString(),
                        imeiNumbers: imeiNumbers
                    });
                }
            }
        }

        if (response) {
            params.attributeInfo = response.cart[line - 1].attributeInfo;
            params.skuName = response.cart[line - 1].skuName;
            params.batchId = response.cart[line - 1].batchId;
        } else if (prevItems[itemIndex].hasVariants) {
            params.skuName = '';
            params.attributeInfo = {};
            for (let i = 0; i < prevItems[itemIndex].attributes.length; i++) {
                let attrId = prevItems[itemIndex].attributes[i];
                let attributeValues = Object.keys(allVariants[attrId - 1].values);
                let randAttributeValue = faker.random.arrayElement(attributeValues)
                params.attributeInfo[attrId.toString()] = randAttributeValue;
                params.skuName += '/' + allVariants[attrId - 1].values[randAttributeValue].name;
            }
            params.unitsInfo = changeUnitsInfo(CLONE(prevItems[itemIndex].unitsInfo));

            if (prevItems[itemIndex].hasExpiryDate) {
                params.expiry = faker.date.future().toString();
            }

            if (prevItems[itemIndex].hasBatchNumber) {
                params.batchId = faker.random.alphaNumeric();
            }

        }

        if (!cart[itemIndex]) {
            cart[itemIndex] = {
                stock: {}
            }
        }

        let stockKey = getStockKey(params.item, params.batchId, params.attributeInfo, prevItems[itemIndex].hasBatchNumber, prevItems[itemIndex].hasVariants);
        if (!bRemove) {
            response = await receivingsController.additem(CLONE(params));
        } else {
            params.line = line;
            response = await receivingsController.removeItem(CLONE(params));
        }
        if (!cart[itemIndex].stock[stockKey]) {
            cart[itemIndex].stock[stockKey] = {
                quantity: 0,
                uniqueDetails: [],
                returnedUniqueDetails: []
            }
        }

        if (!params.quantity) {
            params.quantity = 1;
        }
        if (bRemove) {
            params.quantity *= -1;
        }
        cart[itemIndex].stock[stockKey].quantity += params.quantity;

        if (!bRemove) {
            for (let i = 0; i < params.uniqueDetails.length; i++) {
                cart[itemIndex].stock[stockKey].uniqueDetails.push(params.uniqueDetails[i].serialnumber);
            }
        } else {
            let detail = cart[itemIndex].stock[stockKey].uniqueDetails.shift();
            if (bReceivingEdit) {
                if (detail) {
                    cart[itemIndex].stock[stockKey].returnedUniqueDetails.push(detail);
                }
            }
        }

        await receivingsTestHelper.compareOverAllResponse(response);

        return response;
    }

    function getCartItemIndex(line, response) {
        let cartItem;
        let cartIndex = -1;
        for (let i = 0; i < response.cart.length; i++) {
            if (response.cart[i].line === line) {

                cartItem = response.cart[i];
                cartIndex = i;
                break;
            }
        }

        return {
            cartIndex: cartIndex,
            cartItem: cartItem
        }
    }

    function changeUnitsInfo(unitsInfo) {
        for (let unitId in unitsInfo) {
            unitsInfo[unitId].purchasePrice *= 1.1;
            unitsInfo[unitId].mrp *= 1.1;
            if (unitsInfo[unitId].factor !== 1) {
                unitsInfo[unitId].factor *= 1.1;
            }
            for (let pProfileId in unitsInfo[unitId].pProfilesData) {
                unitsInfo[unitId].pProfilesData[pProfileId].sellingPrice *= 1.1;
            }
        }
    }

    async function editItem(line, response) {
        let res = getCartItemIndex(line, response);
        let cartItem = res.cartItem;
        let cartIndex = res.cartIndex;
        let itemIndex = cartItem.item_id - 1;

        let params = {
            line: cartItem.line,
            description: cartItem.description,
            unitsInfo: CLONE(cartItem.unitsInfo),
            quantity: cartItem.quantity * 2.2,
            expiry: cartItem.expiry,
            itemLocation: cartItem.item_location,
            batchId: cartItem.batchId,
            bPPTempTaxInclusive: !cartItem.bPPTempTaxInclusive
        };

        for (var unitId in params.unitsInfo) {
            delete params.unitsInfo[unitId].purchasePriceWithGDiscount;
        }

        if (cartItem.slab) {
            params.bPPTempTaxInclusive = false;
        }

        if (cartItem.is_serialized || cartIndex.imeiCount) {
            params.quantity = cartItem.quantity;
        }

        //change all the unitsinfo.. factors.. and all... 
        changeUnitsInfo(params.unitsInfo);

        let stockKey = getStockKey(cartItem.item_id, cartItem.batchId, cartItem.attributeInfo, cartItem.hasBatchNumber, cartItem.hasVariants);
        if (prevItems[itemIndex].hasBatchNumber) {
            //during receiving edit ..changing batch id and seeing what happens
            params.batchId = faker.random.alphaNumeric();
        }

        if (prevItems[itemIndex].hasExpiryDate && !params.expiry) {
            params.expiry = faker.date.future().toString();
        }

        response = await receivingsController.editItem(CLONE(params));
        if (!cartItem.hasBatchNumber) {
            expect(!response.cart[params.line - 1]).to.equal(false);
        }
        let newStockKey = getStockKey(cartItem.item_id, cartItem.batchId, cartItem.attributeInfo, cartItem.hasBatchNumber, cartItem.hasVariants);

        if (!cart[itemIndex].stock[newStockKey]) {
            cart[itemIndex].stock[newStockKey] = {
                quantity: 0,
                uniqueDetails: [],
                returnedUniqueDetails: []
            }
        }

        cart[itemIndex].stock[newStockKey].quantity = params.quantity;
        cart[itemIndex].stock[newStockKey].uniqueDetails = cart[itemIndex].stock[stockKey].uniqueDetails;
        if (bReceivingEdit) {
            cart[itemIndex].stock[newStockKey].returnedUniqueDetails = cart[itemIndex].stock[stockKey].returnedUniqueDetails;
        }
        if (newStockKey !== stockKey) {
            delete cart[itemIndex].stock[stockKey];
        }
        let errArray = [];
        let compObject = utils.compareObject(params, response.cart[cartIndex], 0, ['itemLocation'], errArray);
        console.log(errArray);
        expect(compObject).to.equal(true);
        await receivingsTestHelper.compareOverAllResponse(response);
        return response;
    }

    async function updateUnit(line, response) {
        let res = getCartItemIndex(line, response);
        let cartItem = res.cartItem;
        let unitId = '';
        let unitIdArray = Object.keys(cartItem.unitsInfo);
        let i = 0;
        for (i; i < unitIdArray.length; i++) {
            if (unitIdArray[i] === cartItem.unitId) {
                i = i + 1;
                break;
            }
        }

        if (i >= unitIdArray.length - 1) {
            i = 0;
        }
        unitId = unitIdArray[i];

        response = await receivingsController.updateUnit({
            line: line,
            unitId: unitId
        });

        await receivingsTestHelper.compareOverAllResponse(response);

        return response;
    }

    async function validateStock() {
        curItems = await commonUtils.createAllItemTypes();

        let itemIndexes = Object.keys(cart);
        for (let itemIndex in cart) {
            checkInventoryDoc(parseInt(itemIndex));
        }

        //  prevItems = curItems;
    }

    //todomultipleunits whether default unitsinfo changs? or in what cases does it change
    function validateItemInfo() {
        for (let itemIndex in cart) {
            itemIndex = parseInt(itemIndex);
            for (let stockKey in cart[itemIndex].stock) {
                let bFound = false;
                for (let i = 0; i < curItems[itemIndex].batches.length; i++) {
                    if (curItems[itemIndex].batches[i].stockKey === stockKey) {
                        let errArray = [];
                        let compObject = utils.compareObject(cart[itemIndex].stock[stockKey].unitsInfo, curItems[itemIndex].batches[i].unitsInfo, 0.001, [], errArray);
                        console.log(errArray);
                        expect(compObject).to.equal(true);
                        bFound = true;
                        break;
                    }
                }
                expect(bFound).to.equal(true);
            }
            if (!curItems[itemIndex].hasBatchNumber && !curItems[itemIndex].hasVariants) {
                expect(utils.compareObject(curItems[itemIndex].batches[0].unitsInfo, curItems[itemIndex].unitsInfo)).to.equal(true);
            }
        }
    }

    function checkInventoryDoc(itemIndex) {
        let quantity = 0;
        for (let stockKey in cart[itemIndex].stock) {
            quantity += checkStockByKey(itemIndex, stockKey);
        }
        expect(curItems[itemIndex].inventory.quantity - prevItems[itemIndex].inventory.quantity - quantity).within(-0.0001, 0.001);
    }

    function checkStockByKey(itemIndex, stockKey) {
        let quantity = cart[itemIndex].stock[stockKey].quantity * cart[itemIndex].stock[stockKey].factor;
        let prevQuantity = 0;
        if (prevItems[itemIndex].inventory.stock[stockKey]) {
            prevQuantity = prevItems[itemIndex].inventory.stock[stockKey].quantity;
        }
        expect(curItems[itemIndex].inventory.stock[stockKey].quantity - prevQuantity - quantity).within(-0.0001, 0.001);
        let uniqueDetails = cart[itemIndex].stock[stockKey].uniqueDetails;

        for (let i = 0; i < uniqueDetails.length; i++) {
            expect(curItems[itemIndex].inventory.stock[stockKey].uniqueDetails[uniqueDetails[i]].itemAvailable).to.equal(true);
        }

        uniqueDetails = cart[itemIndex].stock[stockKey].returnedUniqueDetails;

        for (let i = 0; i < uniqueDetails.length; i++) {
            if (curItems[itemIndex].inventory.stock[stockKey].uniqueDetails[uniqueDetails[i]]) {
                expect(curItems[itemIndex].inventory.stock[stockKey].uniqueDetails[uniqueDetails[i]].itemAvailable).to.equal(false);
            }
        }

        let transKey = itemLib.formatInvTransKey(timeStamp, stockKey);
        if (quantity) {
            expect(curItems[itemIndex].inventory.transactions[transKey].trans_inventory - quantity).within(-0.0001, 0.001);
        }

        return quantity;
    }

    //inv transaction check missing
    it('make receiving', async function() {

        let curResponse;
        curResponse = await addItem(0);
        expect(curResponse.cart.length).to.equal(1);
        curResponse = await updateUnit(1, curResponse);
        curResponse = await addItem(0, curResponse, 1);
        expect(curResponse.cart.length).to.equal(1);
        curResponse = await updateUnit(1, curResponse);
        curResponse = await editItem(1, curResponse);
        expect(curResponse.cart.length).to.equal(1);
        curResponse = await updateUnit(1, curResponse);
        curResponse = await addItem(1);
        expect(curResponse.cart.length).to.equal(2);
        curResponse = await addItem(1);
        expect(curResponse.cart.length).to.equal(2);
        curResponse = await updateUnit(2, curResponse);
        curResponse = await addItem(2);
        expect(curResponse.cart.length).to.equal(3);
        curResponse = await addItem(2, curResponse, 3);
        expect(curResponse.cart.length).to.equal(3);
        curResponse = await editItem(3, curResponse);
        curResponse = await updateUnit(3, curResponse);
        curResponse = await addItem(0);
        expect(curResponse.cart.length).to.equal(4);
        curResponse = await editItem(4, curResponse);
        curResponse = await addItem(1);
        expect(curResponse.cart.length).to.equal(4);
        curResponse = await editItem(2, curResponse);
        curResponse = await addItem(2);
        expect(curResponse.cart.length).to.equal(5);
        curResponse = await editItem(5, curResponse);
        curResponse = await updateUnit(5, curResponse);
        curResponse = await addItem(1);
        expect(curResponse.cart.length).to.equal(5);

        let paymentParams = {
            payment_type: "Cash",
            amount_tendered: curResponse.amountDue / 2
        };

        curResponse = await receivingsController.add_paymentRestApi(paymentParams);
        paymentParams = {
            payment_type: "Debit Card",
            amount_tendered: curResponse.amountDue
        };

        let param = {
            supplier_id: supplierArray[0]
        };
        curResponse = await receivingsController.addSupplier(param);

        curResponse = await receivingsController.add_paymentRestApi(paymentParams);
        updateFactor(curResponse);
        prevResponse = curResponse;

        prevSupplier.push(await couchDBUtils.getDoc('supplier_' + supplierArray[0], mainDBInstance));
        prevSupplier.push(await couchDBUtils.getDoc('supplier_' + supplierArray[1], mainDBInstance));

        let resp = await receivingsController.completeReceivings({
            comment: 'hello world'
        });

        prevReceivingId = resp.receiving_id.substr(5);
        let doc = await couchDBUtils.getDoc('receiving_' + prevReceivingId, mainDBInstance);
        timeStamp = doc.receivings_info.receiving_time;

        await commonUtils.pgTimeOut(4000);

        await validateStock();
        validateItemInfo();

        let supDoc = await couchDBUtils.getDoc('supplier_' + supplierArray[0], mainDBInstance);
        prevTotal = resp.total;
        expect(supDoc.total - prevSupplier[0].total - resp.total).within(-0.001, 0.001);
        prevSupplier[0] = supDoc;
    });

    async function initPurchaseEdit() {
        let curResponse = await receivingsController.initEditPurchaseSession({
            receivingId: 'receiving_' + prevReceivingId
        });
        var errArray = [];
        var comparResult = utils.compareObject(prevResponse, curResponse, 0, ['timeStamp', 'oldStock', 'origTaxes', 'info', 'comment'], errArray);
        console.log(errArray);
        expect(comparResult).to.equal(true);

    }

    it('initReceivingEdit', async function() {
        await initPurchaseEdit();
    });

    async function makePurchaseEdit() {
        bReceivingEdit = true;
        let curResponse;
        curResponse = await addItem(0);
        expect(curResponse.cart.length).to.equal(6);
        curResponse = await addItem(undefined, curResponse, 2, true);
        curResponse = await updateUnit(2, curResponse);
        expect(curResponse.cart.length).to.equal(6);
        curResponse = await addItem(undefined, curResponse, 1, true);
        curResponse = await updateUnit(3, curResponse);
        expect(curResponse.cart.length).to.equal(6);
        curResponse = await addItem(undefined, curResponse, 1, true);
        expect(curResponse.cart.length).to.equal(6);
        curResponse = await editItem(1, curResponse);
        curResponse = await editItem(5, curResponse);
        curResponse = await updateUnit(5, curResponse);
        curResponse = await editItem(6, curResponse);
        curResponse = await addItem(2);
        expect(curResponse.cart.length).to.equal(7);
        curResponse = await addItem(2, curResponse, 7);
        curResponse = await addItem(2, curResponse, 7);
        expect(curResponse.cart.length).to.equal(7);
        curResponse = await editItem(7, curResponse);
        curResponse = await updateUnit(7, curResponse);
        curResponse = await addItem(1);
        curResponse = await deleteItem(4, curResponse);

        expect(curResponse.cart.length).to.equal(6);

        curResponse = await receivingsController.deletePayment({
            paymment_id: "Debit Card"
        });

        let paymentParams = {
            payment_type: "Purchase On Credit",
            amount_tendered: curResponse.amountDue
        };

        let param = {
            supplier_id: supplierArray[1]
        };
        curResponse = await receivingsController.addSupplier(param);

        curResponse = await receivingsController.add_paymentRestApi(paymentParams);
        updateFactor(curResponse);

        // commonWorker.setFreeze(true);
        let resp = await receivingsController.completeReceivings({
            comment: 'hello world',
            purchaseIdToEdit: 'receiving_' + prevReceivingId
        });

        prevReceivingId = resp.receiving_id.substr(5);
        let doc = await couchDBUtils.getDoc('receiving_' + prevReceivingId, mainDBInstance);
        timeStamp = doc.receivings_info.receiving_time;

        await commonUtils.pgTimeOut(4000);

        await validateStock();
        validateItemInfo();

        let supDoc = await couchDBUtils.getDoc('supplier_' + supplierArray[0], mainDBInstance);
        expect(supDoc.total - prevSupplier[0].total + prevTotal).within(-0.001, 0.001);
        supDoc = await couchDBUtils.getDoc('supplier_' + supplierArray[1], mainDBInstance);
        expect(supDoc.total - prevSupplier[1].total - resp.total).within(-0.001, 0.001);
        expect(supDoc.credit_balance - prevSupplier[1].credit_balance - paymentParams.amount_tendered).within(-0.001, 0.001);
    }

    /**
     * line-item_id-quantity
     * 1-1-8
     * 2-2-4
     * 3-3-2
     * 4-1-4
     * 5-3-1
     */
    it('edit receiving', async function() {
        await makePurchaseEdit();
    });

    async function changeItemDataAndTestEdit(changeItemsData, failStep) {
        let itemDocs = await couchDBUtils.getAllDocsByType('item', mainDBInstance, undefined, true);
        let prevItemDocs = [];
        for (let i = 0; i < itemDocs.length; i++) {
            delete itemDocs[i]._rev;
            prevItemDocs.push(CLONE(itemDocs[i]));
        }

        changeItemsData(itemDocs);
        for (let i = 0; i < itemDocs.length; i++) {
            if (itemDocs[i].bChanged) {
                await couchDBUtils.update(itemDocs[i], mainDBInstance);
            }
        }
        let _error = "";
        let curStep = 0;
        try {
            curStep = 1;
            await initPurchaseEdit();
            curStep = 2;
            await makePurchaseEdit();
        } catch (error) {
            _error = error;
        } finally {
            for (let i = 0; i < itemDocs.length; i++) {
                //for purchase this doesn't work..because doing purchase will update item doc also.. so write a reverse changefun also
                await couchDBUtils.update(prevItemDocs[i], mainDBInstance);
            }
        }

        expect(_error !== "").to.equal(failStep > 0);
        if (failStep) {
            expect(curStep).to.equal(failStep);
        }
    }

    it('purchase edit fails if baseUnitId doesnt match', async function() {
        await changeItemDataAndTestEdit(function(itemDocs) {
            itemDocs[1].bChanged = true;
            for (let key in itemDocs[1].info.unitsInfo) {
                if (key !== itemDocs[1].info.baseUnitId) {
                    itemDocs[1].info.baseUnitId = key;
                    break;
                }
            }
        }, 1);
        await changeItemDataAndTestEdit(function(itemDocs) {
            itemDocs[2].bChanged = true;
            for (let key in itemDocs[2].info.unitsInfo) {
                if (key !== itemDocs[2].info.baseUnitId) {
                    itemDocs[2].info.baseUnitId = key;
                    break;
                }
            }
        }, 1);
    });

    //todomultipleunits let's say I do recv edit and change batchid.. see that all is well
    //todomultipleunits negative receiving cases

});