'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

var utils = require('../../common/Utils.js');
var chai = require('chai');
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
var chaiFiles = require('chai-files');
chai.use(chaiFiles);
var file = chaiFiles.file;
chai.should();
var expect = chai.expect;
var q = require('q');
var fs = require('fs');

describe('SendEmail Controller UTs  ', function(done) {
    this.timeout(100000);
    var sendEMail = require('../../../controllers/SendEmail');

    //The e-mail id for testing is read from env variable
    //var customerEmailId = process.env.TEST_EMAIL_ID;
    //console.log("Sending e-mail to Email ID to %s", customerEmailId);

    var requestData = {};
    requestData = {
        email: process.env.TEST_EMAIL_ID
    };
    console.log("Sending e-mail to Email ID to %s", requestData.email);

    after(function() {
        var logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);
    });

    beforeEach(function() {});

    it('Email : test send email functionality', function() {
        var response = {};

        //return sendEMail(customerEmailId, response).then(function(resp) {
        return sendEMail(requestData, response).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
        });
    });
});