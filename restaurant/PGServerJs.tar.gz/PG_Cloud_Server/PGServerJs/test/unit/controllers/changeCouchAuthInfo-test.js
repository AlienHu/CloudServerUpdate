'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

var chai = require('chai');
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
var chaiFiles = require('chai-files');
chai.use(chaiFiles);
chai.should();

describe('SendSMS Controller UTs  ', function () {
    this.timeout(100000);
    const couchDBUtils2 = require('../../../couchDb/couchDBUtils2')
    var couchAuthChanger = require('../../../common/couchAuthChanger');
    console.log(couchAuthChanger);
    let updateAuth = {
        username: 'Diwakar',//process.env.USERNAME;
        passcode: 'Raj'//moment().format('x');
    };
    let curAuth = {
        username: 'couchadmin',
        passcode: 'test'
    }
    // beforeEach(function () {
    // });

    it('CouchAuth : test CouchPasscode Change by Api hit', function () {
        couchDBUtils2.isCouch2().then((resp) => {
            let bCouch2 = resp;
            var response = {};

            return couchAuthChanger.changeCouchPassword(curAuth, updateAuth, bCouch2).then(function (resp) {
                console.log(resp);
            }).catch(function (err) {
                console.log(err);
            });
        });
    });

    it.only('check password', async () => {
        try {
            let resp = await couchAuthChanger.checkPassword();
            console.log(resp);
            console.log('success');
        } catch (error) {
            console.log(error);
            console.log('catch block');
        }
    });


});