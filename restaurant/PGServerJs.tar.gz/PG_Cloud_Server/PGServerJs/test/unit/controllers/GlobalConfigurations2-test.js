(function() {
    'use strict';

    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    let chai = require("chai");
    const chaiAsPromised = require("chai-as-promised");
    chai.use(chaiAsPromised);
    chai.should();
    const expect = chai.expect;
    const assert = chai.assert;

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    let profitGuruFaker2 = require('../../common/profitGuruFaker2.js');

    describe('Global Configurations Controller UTs  ', function() {
        this.timeout(50000);

        var commonTestUtils = require('../../common/commonUtils.js');
        const globalConfigController = require('../../../controllers/GlobalConfigurations');
        const helper = require('./testHelpers/GlobalConfigurationsHelper');
        let itemController;
        let configData = {};
        let configId = -1;

        before(async function() {
            await couchDbManager.initCouchDb(false);
        });

        beforeEach(function() {});

        it('charge create', async function() {
            configData = await profitGuruFaker2.getFakerCharge();
            let resp = await globalConfigController.createCharge(configData);
            configId = await helper.validateConfigData(resp, configData, 'charge', 'name');
        });

        it('duplicate charge create', async function() {
            configData.name = configData.name.toUpperCase();
            let bException = false;
            try {
                let resp = await globalConfigController.createCharge(configData);
                bException = true;
                throw 'Unique Constraint Failed';
            } catch (error) {
                if (bException) {
                    throw error;
                }
            }
        });

        it('charge update', async function() {
            configData.name = configData.name.toUpperCase();
            configData.id = configId;
            let resp = await globalConfigController.updateCharge(configData);
            configId = await helper.validateConfigData(resp, configData, 'charge', 'name');
        });

        it('charge delete', async function() {
            let resp = await globalConfigController.deleteCharge(configData);
            configId = await helper.validateConfigDelete(configId, 'charge');
        });

        it('tax slabs  create', async function() {
            configData = await profitGuruFaker2.getFakerTaxSlab();
            let resp = await globalConfigController.createSlab(configData);
            configId = await helper.validateConfigData(resp, configData, 'slab', 'name');
        });

        it('duplicate tax slabs  create', async function() {
            configData.name = configData.name.toUpperCase();
            let bException = false;
            try {
                let resp = await globalConfigController.createSlab(configData);
                bException = true;
                throw 'Unique Constraint Failed';
            } catch (error) {
                if (bException) {
                    throw error;
                }
            }
        });

        it('tax slabs  update', async function() {
            configData.name = configData.name.toUpperCase();
            configData.id = configId;
            let resp = await globalConfigController.updateSlab(configData);
            configId = await helper.validateConfigData(resp, configData, 'slab', 'name');
        });

        it('tax slabs  delete', async function() {
            let resp = await globalConfigController.deleteSlab(configData);
            configId = await helper.validateConfigDelete(configId, 'slab');
        });

        it('create global configs', async function() {
            await commonTestUtils.createGlobalConfigs(5);
        });

        it('tax profiles create', async function() {
            configData = await profitGuruFaker2.getFakerProfile();
            let resp = await globalConfigController.createProfile(configData);
            configId = await helper.validateConfigData(resp, configData, 'profile', 'name');
        });

        it('duplicate tax profiles create', async function() {
            configData.name = configData.name.toUpperCase();
            let bException = false;
            try {
                let resp = await globalConfigController.createProfile(configData);
                bException = true;
                throw 'Unique Constraint Failed';
            } catch (error) {
                if (bException) {
                    throw error;
                }
            }
        });

        it('tax profiles update', async function() {
            configData.liquorTaxes.splice(0, 1);
            configData.id = configId;
            let resp = await globalConfigController.updateProfile(configData);
            configId = await helper.validateConfigData(resp, configData, 'profile', 'name');
        });

        it('tax profiles delete', async function() {
            let resp = await globalConfigController.deleteProfile(configData);
            configId = await helper.validateConfigDelete(configId, 'profile');
        });

    });
})();