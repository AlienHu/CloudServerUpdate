/**
 * Todo: write a sales/receivings common class for tests
 */

'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

/**
 *  Todo: Items and other required elements can be created once. No need to drop everytime. Consumes too much time.
 */

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
var profitGuruFaker = require('../../common/profitGuruFaker.js');
var commonTestUtils = require('../../common/commonUtils.js');
var utils = require('../../common/Utils.js');
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
var mainDBInstance = couchDBUtils.getMainCouchDB();
let itemController;
let itemControllerLib;
var faker = require('faker');
var logger = require('../../../common/Logger');
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
const couchDbManager = require('../../../dbManagers/couchDbManager');
var BPromise = require('bluebird');
var itemList;
let items;
var applicationSettings = {};
var curSession = profitGuruFaker.getFakerSession();
var customerArray;
var prevSaleId = -1;
var suspendedSaleId = -1;
var curResponse = {};

describe('Sales Controller 3 UTS', function() {

    this.timeout(500000);
    this.slow(0);

    before(async function() {
        let resp = await couchDbManager.initCouchDb(true);
        applicationSettings = resp.applicationSettings;
        await commonTestUtils.createGlobalConfigs(5);
        await commonTestUtils.getPeople(5, 'supplier');
        itemController = require('../../../controllers/Items');
        itemControllerLib = require('../../../controllers/libraries/itemsControllerLib');

        itemList = await commonTestUtils.getItems(7, true);
        customerArray = await commonTestUtils.getPeople(2, 'customer');
        expect(customerArray.length).to.be.at.least(2);
        expect(itemList.length).to.be.at.least(2);

    });

    after(function() {});

    it('add Item to Cart', function() {
        curSession = profitGuruFaker.getFakerSession();
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        expect(itemList.length).greaterThan(4);

        var ids = [0, 2, 3, 0, 1, 4, 2, 2, 3];
        var itemIds = [];
        for (var i = 0; i < ids.length; i++) {
            itemIds.push(itemList[ids[i]].item_id);
        }
        var cartLength = [1, 2, 3, 4, 5, 6, 7, 8, 9];
        var quantity = [1, 1, 1, 1, 1, 1, 1, 1, 1];
        var index = 0;

        function testAddItem(id) {
            return salesController.additemRestApi({
                item: itemIds[index],
                stockKey: itemList[id].batches[0].stockKey
            }).then(function(resp) {
                curResponse = resp;
                expect(resp.cart.length).to.equal(cartLength[index]);
                for (var i = 0; i < resp.cart.length; i++) {
                    if (itemIds[index] === resp.cart[i].item_id) {
                        expect(resp.cart[i].quantity).to.equal(quantity[index]);
                    }
                }
                index = index + 1;
            });
        }

        return BPromise.each(ids, testAddItem);
    });

    /**
     *  Query from couchdb and do it properly
     */
    it('add serial number info', function() {
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);

        return BPromise.each(curResponse.cart, function(cartItem) {
            var imeiNumbers = [];
            if (cartItem.imeiCount !== 0) {
                for (var i = 0; i < cartItem.imeiCount; i++) {
                    imeiNumbers.push((faker.random.uuid()).toString());
                }
            }
            var params = {
                line: cartItem.line,
                description: cartItem.description,
                serialnumber: (faker.random.uuid()).toString(),
                imeiNumbers: imeiNumbers,
                price: cartItem.price,
                quantity: cartItem.quantity,
                discount: cartItem.discount
            };

            return salesController.editItemRestApi(params).then(function(resp) {
                curResponse = resp;
            }).catch(function(err) {
                console.log(err);
                expect(1).to.equal(0);
            });
        });
    });

    it('complete sale', function(done) {
        var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);

        var paymentParams = {
            payment_type: "Cash",
            amount_tendered: curResponse.total
        };
        salesController.add_paymentRestApi(paymentParams).then(function(resp) {
            expect(resp.cart.length).to.equal(9);
            var param = {
                customer_id: faker.random.arrayElement(customerArray)
            };
            return salesController.addCustomer2Sale(param);
        }).then(function(resp) {
            return salesController.completeSaleRestApi({
                comment: 'hello world'
            });
        }).then(function(resp) {
            // console.log(resp);
            logger.info("complete sale resp");
            curResponse = resp;
            // var saleIdLength = resp.sale_id.length;
            prevSaleId = resp.id; //resp.sale_id.substring(4, saleIdLength);
            setTimeout(function() {
                done();
            }, 1000);
        });
    });

    it('reprint test', async function() {
        let salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        let posId = curResponse.id;
        // let sale_id = parseInt(posId.substring(4, posId.length));
        let params = {
            saleId: 'sale_' + posId
        };

        let resp = await salesController.rePrint(params);
        let excludeFields = ['item_number', 'is_serialized', 'hasBatchNumber', 'bOTG', 'hasExpiryDate', 'price', 'sellingPriceExcludingTax', 'reorder_level', 'imeiCount', 'origTaxes', 'slab', 'bReadyForCheckout', 'gDiscountValue', 'bGDiscountPercent', 'gDiscountPercent', 'gDiscountAmt', 'print_after_sale', 'globalDiscountInfo', 'profileId', 'baseUnitId', 'baseUnitPrice', 'totalPurchaseTaxPercent', 'unitsInfo', 'unitDocs', 'bLocalTax'];
        let errorsArray = [];
        let compResult = utils.compareObject(curResponse, resp, 0.01, excludeFields, errorsArray);
        console.log(errorsArray);
        expect(compResult).to.equal(true);

    });

});