(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    //mocha -R spec UT_giftcards.js  --timeout 200000  
    var Sequelize = require("sequelize");
    var chai = require("chai");
    var chaiAsPromised = require("chai-as-promised");

    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var assert = chai.assert;

    var profitGuruFaker = require('../../common/profitGuruFaker.js');
    var utils = require('../../common/Utils.js');
    var elementsController = require('../../../controllers/Elements');
    var cuustomerLoyalityController = require('../../../controllers/customersLoyality');
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    var cuustomerLoyalityModel = Models.profitGuru_customersLoyality;
    var appConfigModel = Models.profitGuru_app_config;

    describe('Giftcard Controller UTs  ', function(done) {
        this.timeout(100000);
        var createdCustomerID = -1;
        var createdGiftcardID = -1;
        var allCreatedGiftcardIDs = [];

        before(function() {
            return couchDbManager.initCouchDb(true).then(function(resp) {
                return appConfigModel.findById('loyalityValidity');
            }).then(function(resp) {
                var dataJson = {
                    key: 'loyalityValidity',
                    value: '30'
                };

                var params = {
                    where: {
                        key: 'loyalityValidity'
                    }
                };

                if (resp) {
                    return appConfigModel.update(dataJson, params);
                } else {
                    return appConfigModel.create(dataJson);
                }
            });
        });

        beforeEach(function() {});

        /* it('create customer', function() {
             var customerData = profitGuruFaker.getFakerCustomer();
             return elementsController.create(customerData).then(function(resp) {
                 expect(resp.hasOwnProperty('customer_id')).to.equal(true);
                 createdCustomerID = resp.customer_id;
             });
         });

         it('create giftcard without customer', function() {
             var customerLoydalityData = profitGuruFaker.getFakerGiftcard();
             return cuustomerLoyalityController.saveGiftcard(customerLoydalityData).then(function(resp) {
                 expect(resp.hasOwnProperty('giftcard_id')).to.equal(true);
                 createdGiftcardID = resp.giftcard_id;
                 allCreatedGiftcardIDs.push(createdGiftcardID);
                 return cuustomerLoyalityModel.findById(createdGiftcardID);
             }).then(function(resp) {
                 expect(resp).to.not.equal(null);
                 expect(resp.value).to.equal(customerLoydalityData.giftcardvalue);
                 expect(resp.customer_id).to.equal(null);
             });
         });

         it('create giftcard with customer', function() {
             var customerLoydalityData = profitGuruFaker.getFakerGiftcard();
             customerLoydalityData.customer = createdCustomerID;
             return cuustomerLoyalityController.saveGiftcard(customerLoydalityData).then(function(resp) {
                 expect(resp.hasOwnProperty('giftcard_id')).to.equal(true);
                 createdGiftcardID = resp.giftcard_id;
                 allCreatedGiftcardIDs.push(createdGiftcardID);
                 return cuustomerLoyalityModel.findById(createdGiftcardID);
             }).then(function(resp) {
                 expect(resp).to.not.equal(null);
                 expect(resp.value).to.equal(customerLoydalityData.giftcardvalue);
                 expect(resp.customer_id).to.equal(createdCustomerID);
             });
         });

         it('updating giftcard with extra value', function() {
             var customerLoydalityData = {};
             return cuustomerLoyalityModel.findById(createdGiftcardID).then(function(resp) {
                 expect(resp).to.not.equal(null);
                 customerLoydalityData.prevalue = resp.value;
                 customerLoydalityData.giftcardvalue = 1000;
                 customerLoydalityData.customer = resp.customer_id;
                 customerLoydalityData.giftcard_id = resp.giftcard_id;
                 return cuustomerLoyalityController.saveGiftcard(customerLoydalityData);
             }).then(function(resp) {
                 expect(resp.hasOwnProperty('giftcard_id')).to.equal(true);
                 expect(createdGiftcardID).to.equal(resp.giftcard_id);
                 return cuustomerLoyalityModel.findById(createdGiftcardID);
             }).then(function(resp) {
                 expect(resp).to.not.equal(null);
                 expect(resp.value).to.equal(customerLoydalityData.giftcardvalue + customerLoydalityData.prevalue);
                 expect(resp.customer_id).to.equal(createdCustomerID);
             });
         });

         it('updating giftcard with extra value. Negative Value (probably for deduction)', function() {
             var customerLoydalityData = {};
             return cuustomerLoyalityModel.findById(createdGiftcardID).then(function(resp) {
                 expect(resp).to.not.equal(null);
                 customerLoydalityData.prevalue = resp.value;
                 customerLoydalityData.giftcardvalue = -1000;
                 customerLoydalityData.customer = resp.customer_id;
                 customerLoydalityData.giftcard_id = resp.giftcard_id;
                 return cuustomerLoyalityController.saveGiftcard(customerLoydalityData);
             }).then(function(resp) {
                 expect(resp.hasOwnProperty('giftcard_id')).to.equal(true);
                 expect(createdGiftcardID).to.equal(resp.giftcard_id);
                 return cuustomerLoyalityModel.findById(createdGiftcardID);
             }).then(function(resp) {
                 expect(resp).to.not.equal(null);
                 expect(resp.value).to.equal(customerLoydalityData.giftcardvalue + customerLoydalityData.prevalue);
                 expect(resp.customer_id).to.equal(createdCustomerID);
             });
         });

         it('updating giftcard with extra value. Validity Check', function() {
             var customerLoydalityData = {};
             var dataJson = {
                 key: 'loyalityValidity',
                 value: '-1'
             };

             var params = {
                 where: {
                     key: 'loyalityValidity'
                 }
             };
             return appConfigModel.update(dataJson, params).then(function(resp) {
                 return cuustomerLoyalityModel.findById(createdGiftcardID);
             }).then(function(resp) {
                 expect(resp).to.not.equal(null);
                 customerLoydalityData.prevalue = resp.value;
                 customerLoydalityData.giftcardvalue = 1000;
                 customerLoydalityData.customer = resp.customer_id;
                 customerLoydalityData.giftcard_id = resp.giftcard_id;
                 return cuustomerLoyalityController.saveGiftcard(customerLoydalityData);
             }).then(function(resp) {
                 expect(resp.hasOwnProperty('giftcard_id')).to.equal(true);
                 expect(createdGiftcardID).to.equal(resp.giftcard_id);
                 return cuustomerLoyalityModel.findById(createdGiftcardID);
             }).then(function(resp) {
                 expect(resp).to.not.equal(null);
                 expect(resp.value).to.equal(customerLoydalityData.giftcardvalue);
                 expect(resp.customer_id).to.equal(createdCustomerID);
             });
         });

         it('quering all giftcards', function() {
             return cuustomerLoyalityController.getAllGiftCards().then(function(resp) {
                 expect(resp.hasOwnProperty('giftcards')).to.equal(true);
                 expect(resp.giftcards.length).to.equal(2);
             });
         });

         it('get giftcards for customer', function() {
             return cuustomerLoyalityController.giftCrdAmt4Customer({
                 customer_id: createdCustomerID
             }).then(function(resp) {
                 expect(resp.hasOwnProperty('giftcards')).to.equal(true);
                 expect(resp.giftcards.length).to.equal(1);
             });
         });

         it('deleting giftcards', function() {
             return cuustomerLoyalityController.deleteGiftCard({
                 ids: allCreatedGiftcardIDs
             }).then(function(resp) {
                 var params = {};
                 params.where = {};
                 params.$or = [];
                 for (var i = 0; i < allCreatedGiftcardIDs.length; i++)
                     params.$or.push({
                         giftcard_id: allCreatedGiftcardIDs[i]
                     });
                 return cuustomerLoyalityModel.findAll(params);
             }).then(function(resp) {
                 expect(resp.length).to.equal(0);
             });
         });*/

    });

})();