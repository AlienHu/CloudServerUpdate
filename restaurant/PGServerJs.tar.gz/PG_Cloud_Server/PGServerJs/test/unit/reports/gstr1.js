'use strict';

var gstr1 = function() {
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const _self = this;

    this.head_12 = async function() {
        try {
            var params = {
                include_docs: true
            };
            var resp = await couchDBUtils.getView('all_sales_info', 'sales_info', params, mainDBInstance);
            var rows = {};
            for (var i = 0; i < resp.length; i++) {
                var doc = resp[i].doc;
                for (var j = 0; j < doc.sale_items.length; j++) {
                    //var uqc = resp[i].sale_items[j].uqc;
                    var hsn = doc.sale_items[j].hsn;
                    var tmp = ('hsn_' + hsn);
                    if (!rows[tmp]) {
                        rows[tmp] = {};
                        rows[tmp].hsn = hsn;
                        rows[tmp].uqc = doc.sale_items[j].unit;
                        rows[tmp].description = doc.sale_items[j].description;
                        rows[tmp].quantity = 1;
                        var cal = await this.calculatePriceHandler(doc.sale_items[j]);
                        // console.log(doc.sale_items[j]);
                        for (var z = 0; z < cal.itemTaxList.length; z++) {
                            if (cal.itemTaxList[z].name == 'CGST') {
                                rows[tmp].cgst = cal.itemTaxList[z].amount;
                            } else if (cal.itemTaxList[z].name == 'SGST') {
                                rows[tmp].sgst = cal.itemTaxList[z].amount;
                            } else if (cal.itemTaxList[z].name == 'IGST') {
                                rows[tmp].igst = cal.itemTaxList[z].amount;
                            }
                        }
                        rows[tmp].totalValue = cal.totalValue;
                        rows[tmp].totalTaxableValue = cal.totalNoTax;
                        // console.log(rows);
                    } else {
                        rows[tmp].quantity++;
                        var cal = await this.calculatePriceHandler(doc.sale_items[j]);

                        for (var z = 0; z < cal.itemTaxList.length; z++) {
                            if (cal.itemTaxList[z].name == 'CGST') {
                                rows[tmp].cgst += cal.itemTaxList[z].amount;
                            } else if (cal.itemTaxList[z].name == 'SGST') {
                                rows[tmp].sgst += cal.itemTaxList[z].amount;
                            } else if (cal.itemTaxList[z].name == 'IGST') {
                                rows[tmp].igst += cal.itemTaxList[z].amount;
                            }
                        }
                        rows[tmp].totalValue += cal.totalValue;
                        rows[tmp].totalTaxableValue += cal.totalNoTax;
                    }
                }
            }
            console.log(rows);
            return rows;
        } catch (err) {
            throw err;
        }
    }

    this.calculatePrice = async function(saleDoc) {
        // console.log(saleDoc);
        saleDoc.quantity = saleDoc.quantity_purchased;
        var result = {};
        var discount = 0.01 * saleDoc.discount_percent;

        var sellingPriceExTax = saleDoc.sellingPrice;
        var taxList = [];
        var totalTaxPercent = 0;
        var totalTaxAmount = 0;
        if (!saleDoc.uqc) {
            saleDoc.uqc = 'DPK';
        }
        if (!saleDoc.itemTaxList) {
            saleDoc.itemTaxList = {};
        }
        if (!saleDoc.chargesTaxList) {
            saleDoc.chargesTaxList = {};
        }
        if (!saleDoc.chargesList) {
            saleDoc.chargesList = {};
        }
        for (var i = 0; i < saleDoc.itemTaxList.length; i++) {
            totalTaxPercent += saleDoc.itemTaxList[i].percent;
            totalTaxAmount += (sellingPriceExTax * saleDoc.itemTaxList[i].percent) / 100;
            taxList.push({
                name: saleDoc.itemTaxList[i].name,
                amount: (sellingPriceExTax * saleDoc.itemTaxList[i].percent) / 100
            })
        }
        result.itemTaxList = taxList;
        result.totalTaxAmount = totalTaxAmount;
        result.totalTaxPercent = totalTaxPercent;

        var tax = 0.01 * totalTaxPercent;

        var totalChargePercent = 0;
        var totalChargeAmount = 0;
        var chargeList = [];
        for (var i = 0; i < saleDoc.chargesList.length; i++) {
            totalChargePercent += saleDoc.chargesList[i].percent;
            totalChargeAmount += (sellingPriceExTax * saleDoc.chargesList[i].percent) / 100;
            chargeList.push({
                name: saleDoc.chargesList[i].name,
                amount: (sellingPriceExTax * saleDoc.chargesList[i].percent) / 100
            })
        }
        result.chargeList = chargeList;
        result.totalChargeAmount = totalChargeAmount;
        result.totalChargePercent = totalChargePercent;

        var charges = 0.01 * totalChargePercent;

        var totalChargeTaxPercent = 0;
        var totalChargeTaxAmount = 0;
        var chargeTaxList = [];
        for (var i = 0; i < saleDoc.chargesTaxList.length; i++) {
            totalChargeTaxPercent += saleDoc.chargesTaxList[i].percent;
            totalChargeTaxAmount += (totalChargeAmount * saleDoc.chargesTaxList[i].percent) / 100;
            chargeTaxList.push({
                name: saleDoc.chargesTaxList[i].name,
                amount: (totalChargeAmount * saleDoc.chargesTaxList[i].percent) / 100
            })
        }
        result.chargeTaxList = chargeTaxList;
        result.totalChargeTaxAmount = totalChargeTaxAmount;
        result.totalChargeTaxPercent = totalChargeTaxPercent;

        var chargesTax = 0.01 * totalChargeTaxPercent;

        result.totalValue = sellingPriceExTax * saleDoc.quantity * (1 - discount) * (1 + tax) + sellingPriceExTax * saleDoc.quantity * (1 - discount) * charges * (1 + chargesTax);
        result.totalNoDiscountNoChargesNoTax = sellingPriceExTax * saleDoc.quantity;
        result.totalNoChargesNoTax = sellingPriceExTax * saleDoc.quantity * (1 - discount);
        result.totalNoTax = sellingPriceExTax * saleDoc.quantity * (1 - discount) * (1 + charges);
        result.totalDiscount = sellingPriceExTax * saleDoc.quantity * discount;
        result.totalCharges = sellingPriceExTax * saleDoc.quantity * (1 - discount) * (charges);
        result.totalTax = sellingPriceExTax * saleDoc.quantity * (1 - discount) * (tax) + sellingPriceExTax * saleDoc.quantity * (1 - discount) * (charges) * chargesTax;
        result.totalChargesTaxPercent = sellingPriceExTax * saleDoc.quantity * (1 - discount) * (charges) * chargesTax;

        return result;
    }

    this.calculatePriceHandler = async function(saleDoc) {
        if (saleDoc.bSPTaxInclusive == false)
            return this.calculatePrice(saleDoc);
        else {
            var totalTaxPercent = 0;
            for (var i = 0; i < saleDoc.itemTaxList.length; i++) {
                totalTaxPercent += saleDoc.itemTaxList[i].percent;
            }

            var sellingPriceExTax = ((saleDoc.sellingPrice) / (1 + (0.01 * totalTaxPercent)));
            saleDoc.sellingPrice = sellingPriceExTax;
            return this.calculatePrice(saleDoc);
        }
    }

};

module.exports = new gstr1();

/*

sellingPriceExTax
total
totalNoDiscountNoChargesNoTax
totalNoChargesNoTax
totalNoTax
totalDiscount
totalCharges
totalTax
totalChargesTaxPercent



sellingPriceExTax
total = sellingPriceExTax*quantity*(1-discount)*(1+tax) + sellingPriceExTax*quantity*(1-discount)*charges*(1+chargesTax)
totalNoDiscountNoChargesNoTax = sellingPriceExTax*quantity
totalNoChargesNoTax = sellingPriceExTax*quantity*(1-discount)
totalNoTax = sellingPriceExTax*quantity*(1-discount)*(1+charges)
totalDiscount = sellingPriceExTax*quantity*discount
totalCharges = sellingPriceExTax*quantity*(1-discount)*(charges)
totalTax = sellingPriceExTax*quantity*(1-discount)*(tax) + sellingPriceExTax*quantity*(1-discount)*(charges)*chargesTax
totalChargesTaxPercent = sellingPriceExTax*quantity*(1-discount)*(charges)*chargesTax


if(inc) {
    sp - tax
} else {
    sp
}



function initHSN(hsn) {
   if(!result.hasOwnProperty(hsn)){
       result[hsn] = {
           total: 0,
           taxableTotal: 0
       };
   }
}

let result = {};

for(let i = 0; i < allSaleDocs.length; i++) {
   let sale_items = allSaleDocs[i];
   for(let j = 0; j < sale_items.length; j++) {
       let item = sale_items[i];
       let hsn = item.hsn;
       initHSN(hsn);
       result[hsn].total += item.sellingPriceExTax * item.quantity;
       result[hsn].taxableTotal += result[hsn].total*(1-(item.discount*0.01));
   }
}

return Object.values(result)
*/