'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');
const maindb = couchDBUtils.getMainCouchDB();
const Utils = require('../../../controllers/common/Utils');
const CLONE = Utils.clone;

describe('Migration Tests', function() {
    this.timeout(200000);

    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    it('down', async function() {
        await migrationHandler.migrate('2018092070000000-changeCustmerTagsID.js');
        // let tags = await couchDBUtils.getDoc(OLD_TAGS_ID, mainDBInstance);
        // expect(tags.hasOwnProperty('tags')).to.equal(true);
    });

    it('up', async function() {
        const commonLib = require('../../../controllers/libraries/commonLib');
        const utils = require('../../../controllers/common/Utils');
        var computeUtils = require('../../../controllers/common/computeUtils');

        await migrationHandler.migrate('201809210000000-purchaseReturnTaxTotalIssue.js');

        function getTaxTotal(items) {

            for (let i = 0; i < items.length; i++) {
                expect(items[i].taxes.hasOwnProperty('Total')).to.equal(true);
                let item = CLONE(items[i]);
                let total = 0;
                item.taxes.Total = 0;
                for (let w in item.taxes) {
                    total += item.taxes[w];
                }
                item.taxes.Total = total;
                expect(item.taxes.Total).to.equal(items[i].taxes.Total);
                // expect(item.taxes.Total).to.be.closeTo(items[i].taxes.Total);
                console.log('all is well');
            }
        }
        async function computeItemTotal(items, globalDiscount) {
            for (var i = 0; i < items.length; i++) {
                var item = CLONE(items[i]);
                item.totalTaxPercent = 0;

                for (var j = 0; j < item.itemTaxList.length; j++) {
                    var tax = item.itemTaxList[j];
                    // totalTaxPercent += tax.percent;
                    item.totalTaxPercent += tax.percent;
                }

                item.purchasePrice = commonLib.getPPFromUInfo(item.unitsInfo, item.unitId);
                var price = computeUtils.getPriceTaxEx(item.purchasePrice, item.bPPTaxInclusive, item.totalTaxPercent);
                item.purchasePriceExTax = price;
                item.quantity = item.quantity ? item.quantity : item.quantity_purchased;
                item.total = price * item.quantity;
                delete item.quantity_purchased;

                item.totalNoTaxNoDiscount = item.purchasePriceExTax * item.quantity;
                item.discount = item.discount ? item.discount : 0;
                item.totalNoTaxWithDiscount = item.totalNoTaxNoDiscount * (1 - item.discount * 0.01);

                item.totalWithTax = item.total;
                item.total = item.totalNoTaxWithDiscount * (1 + item.totalTaxPercent * 0.01);

                if (globalDiscount && globalDiscount.hasOwnProperty('method')) {
                    if (globalDiscount.method == 'onTaxable') {
                        item.totalNoTaxWithDiscount = item.totalNoTaxNoDiscount * (1 - (globalDiscount.percent + item.discount) * 0.01);
                        item.total = item.totalNoTaxWithDiscount * (1 + item.totalTaxPercent * 0.01);
                    } else if (globalDiscount.method == 'onTotal') {
                        item.total = item.total * (1 - (globalDiscount.percent) * 0.01);
                        item.totalNoTaxWithDiscount = item.total / ((1 + item.totalTaxPercent * 0.01));
                        item.totalNoTaxNoDiscount = item.totalNoTaxWithDiscount / (1 - ((globalDiscount.percent + item.discount) * 0.01));
                        // item.total = item.totalNoTaxWithDiscount * (1 + item.totalTaxPercent * 0.01);
                    }
                }
                expect(items[i].total).to.equal(item.total);
            }
        }
        // let docsToPush = [];
        let paramObject = {
            include_docs: true // waste
        }
        let allPurchaseRetunDocs = await couchDBUtils.getAllDocIdsByType('receivingReturn', maindb, paramObject);
        for (let k = 0; k < allPurchaseRetunDocs.length; k++) {

            allPurchaseRetunDocs[k].doc = commonLib.transformSaleDoc(allPurchaseRetunDocs[k].doc, 'purchaseReturn');
            console.log("id=" + allPurchaseRetunDocs[k].doc.id);
            getTaxTotal(allPurchaseRetunDocs[k].doc.items);
            await computeItemTotal(allPurchaseRetunDocs[k].doc.items, allPurchaseRetunDocs[k].doc.info.discount);
        }
        console.log('all is well');

    });

});