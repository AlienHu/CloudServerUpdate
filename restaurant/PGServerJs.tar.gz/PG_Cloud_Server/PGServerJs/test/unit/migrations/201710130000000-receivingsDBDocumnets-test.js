   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   const coreDBInstancce = couchDBUtils.getCoreCouchDB();
   const maindb = couchDBUtils.getMainCouchDB();
   const couchDbManager = require('../../../dbManagers/couchDbManager');
   const migrationHandler = require('../../../couchDb/migrationHandler');

   describe('Migration Tests', function() {
       this.timeout(200000);

       before(async function() {
           let bResetDB = false;
           if (!bResetDB) {
               await couchDbManager.initCouchDb(false);
           } else {
               await couchDbManager.initCouchDb(true);
               let commonUtils2 = require('../../common/commonUtils2');

               await commonUtils2.createSomeData(true, true, 0, 21);
               let timeOut = require('../../common/commonUtils').pgTimeOut;
               await timeOut(10000);
               process.exit(0);
           }
       });

       it('down', async function() {

           await migrationHandler.migrate('201710110000000-salesPetrolbunkPermission.js');
           let purchaseDocs = await couchDBUtils.getAllDocsByType('receiving', maindb);
           let docsToUpdate = [];
           for (let i = 0; i < purchaseDocs.length; i++) {
               expect(purchaseDocs[i].doc.receivings_info.hasOwnProperty('amount_tendered')).to.equal(false);

               for (var j = 0; j < purchaseDocs[i].doc.receiving_items.length; j++) {
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('unit')).to.equal(false);
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('is_serialized')).to.equal(false);
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('hasBatchNumber')).to.equal(false);
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('imeiCount')).to.equal(false);
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('hasExpiryDate')).to.equal(false);
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('hasVariants')).to.equal(false);

               }
           }

           let purchaseReturnsDocs = await couchDBUtils.getAllDocsByType('receivingReturn', maindb);

           for (let l = 0; l < purchaseReturnsDocs.length; l++) {
               expect(purchaseReturnsDocs[l].doc.receivings_info.hasOwnProperty('amount_tendered')).to.equal(false);

               for (var m = 0; m < purchaseReturnsDocs[l].doc.receiving_items.length; m++) {
                   expect(purchaseReturnsDocs[l].doc.receiving_items[m].hasOwnProperty('is_serialized')).to.equal(false);
                   expect(purchaseReturnsDocs[l].doc.receiving_items[m].hasOwnProperty('hasBatchNumber')).to.equal(false);
                   expect(purchaseReturnsDocs[l].doc.receiving_items[m].hasOwnProperty('imeiCount')).to.equal(false);
                   expect(purchaseReturnsDocs[l].doc.receiving_items[m].hasOwnProperty('hasExpiryDate')).to.equal(false);
                   expect(purchaseReturnsDocs[l].doc.receiving_items[m].hasOwnProperty('hasVariants')).to.equal(false);

               }
           }

       });

       it('up', async function() {
           await migrationHandler.migrate('201710130000000-receivingsDBDocumnets.js');

           let purchaseDocs = await couchDBUtils.getAllDocsByType('receiving', maindb);
           let docsToUpdate = [];
           for (let i = 0; i < purchaseDocs.length; i++) {
               expect(purchaseDocs[i].doc.receivings_info.hasOwnProperty('amount_tendered')).to.equal(true);

               for (var j = 0; j < purchaseDocs[i].doc.receiving_items.length; j++) {
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('unit')).to.equal(true);
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('is_serialized')).to.equal(true);
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('hasBatchNumber')).to.equal(true);
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('imeiCount')).to.equal(true);
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('hasExpiryDate')).to.equal(true);
                   expect(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('hasVariants')).to.equal(true);

               }
           }

           let purchaseReturnsDocs = await couchDBUtils.getAllDocsByType('receivingReturn', maindb);

           for (let l = 0; l < purchaseReturnsDocs.length; l++) {
               expect(purchaseReturnsDocs[l].doc.receivings_info.hasOwnProperty('amount_tendered')).to.equal(true);

               for (var m = 0; m < purchaseReturnsDocs[l].doc.receiving_items.length; m++) {
                   expect(purchaseReturnsDocs[l].doc.receiving_items[m].hasOwnProperty('is_serialized')).to.equal(true);
                   expect(purchaseReturnsDocs[l].doc.receiving_items[m].hasOwnProperty('hasBatchNumber')).to.equal(true);
                   expect(purchaseReturnsDocs[l].doc.receiving_items[m].hasOwnProperty('imeiCount')).to.equal(true);
                   expect(purchaseReturnsDocs[l].doc.receiving_items[m].hasOwnProperty('hasExpiryDate')).to.equal(true);
                   expect(purchaseReturnsDocs[l].doc.receiving_items[m].hasOwnProperty('hasVariants')).to.equal(true);

               }
           }

       });

   });