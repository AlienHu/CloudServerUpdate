'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const coreDBInstancce = couchDBUtils.getCoreCouchDB();
const usersDBInstance = couchDBUtils.getUserCouchDB();
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');

describe('Migration Tests', function() {
    this.timeout(200000);

    before(function() {
        return couchDbManager.initCouchDb(false);
    });
    it('down', async function() {
        await migrationHandler.migrate('201804111100000-crm-entitlements.js')
        var params = {};
        let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
        for (var i = 0; i < allUsers.length; i++) {
            allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
            expect(allUsers[i].value.roles[0].hasOwnProperty('homeDelivery')).to.equal(false);
        }
        let allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', coreDBInstancce, 'propogate');
        expect(allowedFeatures.hasOwnProperty('homeDelivery')).to.equal(false);
    });

    it('up', async function() {
        await migrationHandler.migrate('201804230000000-sms.js')
        var params = {};
        let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
        var homeDeliveryObj = JSON.parse(allUsers[0].value.roles[0]);
        var homedeliveryKeys = Object.keys(homeDeliveryObj.homeDelivery);
        expect(homedeliveryKeys.length).to.be.gt(0);
        for (var i = 0; i < allUsers.length; i++) {
            allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
            expect(allUsers[i].value.roles[0].hasOwnProperty('homeDelivery')).to.equal(true);
            for (var j = 0; j < homedeliveryKeys.length; j++) {
                expect(allUsers[i].value.roles[0].homeDelivery.hasOwnProperty(homedeliveryKeys[j])).to.equal(true);
            }
        }

        let allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', coreDBInstancce, 'propogate');
        expect(allowedFeatures.hasOwnProperty('homeDelivery')).to.equal(true);
    });

});