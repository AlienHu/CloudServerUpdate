   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   const coreDBInstancce = couchDBUtils.getCoreCouchDB();
   const usersDBInstance = couchDBUtils.getUserCouchDB();
   const couchDbManager = require('../../../dbManagers/couchDbManager');
   const migrationHandler = require('../../../couchDb/migrationHandler');

   describe('Migration Tests', function() {
       this.timeout(200000);

       before(function() {
           return couchDbManager.initCouchDb(false);
       });

       it('down', async function() {
           await migrationHandler.migrate('201710100000000-convFactor.js');
           var params = {};
           let allUsersDoc = [];
           let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
           for (var i = 0; i < allUsers.length; i++) {
               allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
               console.log('hello');
               console.log(allUsers[i].value.roles[0].sales);
               expect(allUsers[i].value.roles[0].hasOwnProperty('sales')).to.equal(false);
               console.log(allUsers[i].value.roles[0].sales);
           }

       });

       it('up', async function() {
           //userentitlements
           //users
           await migrationHandler.migrate('201710110000000-salesPetrolbunkPermission.js');

           var params = {};
           let allUsersDoc = [];
           let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
           for (var i = 0; i < allUsers.length; i++) {
               allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
               expect(allUsers[i].value.roles[0].hasOwnProperty('sales')).to.equal(true);
               if (allUsers[i].value.roles[1] === 'admin') {
                   expect(allUsers[i].value.roles[0].sales.allowAll).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.viewOnMenu).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.sendEmail.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.makeSale.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.makeReturn.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.editPrice.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.editDiscount.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.suspendSales.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.unsuspendSales.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.viewOthersSuspendedSales.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.unsuspendOthersSales.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.deleteOthersSuspendedSales.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.salesHistory.view.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.salesHistory.update.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].sales.salesHistory.delete.allowed).to.equal(true);

               }
           }

       });

   });