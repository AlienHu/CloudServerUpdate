'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');

describe('Migration Tests', function() {
    this.timeout(200000);

    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    xit('down', async function() {
        await migrationHandler.migrate('201812010000000-updateStockUserPermission.js');
        expect(1).to.equal(1);
    });

    it('up', async function() {
        const migrationFile = require('../../../../PGServerJs/couchDBMigrations/201812220000000-storeBarcodeInDb');
        const logger = require('../../../../PGServerJs/common/Logger');
        const serverInstance = require('nano-blue')('http://couchadmin:test@127.0.0.1:5984');
        const mainDBInstance = serverInstance.use('pg_collection_restaurant_maindb');

        let params = {
            nanoClients: {
                maindb: mainDBInstance
            },
            logger: logger,
            migrationsBasePath: __dirname + '/../../../../PGServerJs/couchDBMigrations'
        };

        await migrationFile.up(params).catch(() => {
            console.log('failed');
            process.exit(1);
        });
        const bSuccess = await testBarcodeUp(params);
        expect(bSuccess).to.equal(true);

        console.log('done');
        process.exit(0);

    });

});

const testBarcodeUp = async (params) => {
    let bSuccess = false;
    let migrationsBasePath = params.migrationsBasePath;
    const appRootPath = migrationsBasePath + '/../';
    const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
    try {
        await batchProcess(1000, 'item', processItemsChunk, {
            dbInstance: params.nanoClients.maindb,
            couchDBUtils: couchDBUtils,
            logger: params.logger
        });
        bSuccess = true;
    } catch (err) {
        console.error(err);
    }
    return bSuccess;
}

const processItemsChunk = (itemsList) => {
    // read all items and batch and check barcode is not empty and matching with attributes as well
    for (let i = 0; i < itemsList.length; i++) {
        let thisItem = itemsList[i].doc;
        const batchKeys = Object.keys(thisItem.batches);
        for (let j = 0; j < batchKeys.length; j++) {
            let thisBatch = thisItem.batches[batchKeys[j]];
            const matched = (thisBatch.barcode === getSystemGeneratedBarcode(thisItem.item_id, thisBatch));
            if (!matched) {
                throw "Barcode didnt match";
            }
        }
    }
}

const getSystemGeneratedBarcode = (item_id, batch) => {
    let barcode = ':' + item_id;
    let attributeInfo = batch.attributeInfo;
    if (attributeInfo) {
        for (let attributeId in attributeInfo) {
            barcode += ':' + attributeInfo[attributeId];
        }
    }
    return barcode;
}