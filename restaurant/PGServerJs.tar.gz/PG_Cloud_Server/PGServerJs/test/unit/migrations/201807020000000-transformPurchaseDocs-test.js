'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const coreDBInstancce = couchDBUtils.getCoreCouchDB();
const usersDBInstance = couchDBUtils.getUserCouchDB();
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');
const mainDBInstance = couchDBUtils.getMainCouchDB();

describe('Migration Tests', function() {
    this.timeout(200000);

    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    it('down', async function() {
        await migrationHandler.migrate('201806220000000-transformSaleDocs.js');
        let allPurchases = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance);
        for (let i = 0; i < allPurchases.length; i++) {
            let purchaseDoc = allPurchases[i].doc;
            expect(typeof purchaseDoc.receivings_info).to.equal('object');
            expect(typeof purchaseDoc.payments).to.equal('object');
            for (let j = 0; j < purchaseDoc.receiving_items.length; j++) {
                expect(typeof purchaseDoc.receiving_items[j]).to.equal('object');
            }
        }

        let allPurchaseReturnDocs = await couchDBUtils.getAllDocsByType('receivingReturn', mainDBInstance);
        for (var q = 0; q < allPurchaseReturnDocs.length; q++) {
            let purchaseReturnDoc = allPurchaseReturnDocs[iq].doc;
            expect(typeof purchaseReturnDoc.info).to.equal('object');
            expect(typeof purchaseReturnDoc.payments).to.equal('object');
            for (let j = 0; j < purchaseReturnDoc.items.length; j++) {
                expect(typeof purchaseReturnDoc.items[j]).to.equal('object');
            }
        }
    });

    it('up', async function() {
        await migrationHandler.migrate('201807020000000-transformPurchaseDocs.js');
        let allPurchases = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance);
        for (let i = 0; i < allPurchases.length; i++) {
            let purchaseDoc = allPurchases[i].doc;
            expect(typeof purchaseDoc.receivings_info).to.equal('string');
            expect(typeof purchaseDoc.payments).to.equal('string');
            for (let j = 0; j < purchaseDoc.receiving_items.length; j++) {
                expect(typeof purchaseDoc.receiving_items[j]).to.equal('string');
            }
        }

        let allPurchaseReturnDocs = await couchDBUtils.getAllDocsByType('receivingReturn', mainDBInstance);
        for (var q = 0; q < allPurchaseReturnDocs.length; q++) {
            let purchaseReturnDoc = allPurchaseReturnDocs[iq].doc;
            expect(typeof purchaseReturnDoc.info).to.equal('string');
            expect(typeof purchaseReturnDoc.payments).to.equal('string');
            for (let j = 0; j < purchaseReturnDoc.items.length; j++) {
                expect(typeof purchaseReturnDoc.items[j]).to.equal('string');
            }
        }
    });

});