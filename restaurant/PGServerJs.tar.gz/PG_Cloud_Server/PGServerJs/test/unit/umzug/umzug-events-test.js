'use strict';

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const shelljs = require('shelljs');
const Umzug = require('umzug');

describe('Elements UTs', function() {
    this.timeout(10000000);

    let params = {
        storage: 'json',
        storageOptions: {
            path: __dirname + '/meta.json'
        },
        migrations: {
            path: __dirname + '/migrations/',
            pattern: /\.js$/
        }
    };
    let umzug;

    before(function() {
        umzug = new Umzug(params);
        umzug.on('migrating', function(name, migrations) {
            console.log('migrating ' + name);
            // console.log(migrations);
        });
        umzug.on('migrated', function(name, migrations) {
            console.log('migrated ' + name);
            // console.log(migrations);
        });
        umzug.on('reverting', function(name, migrations) {
            console.log('reverting ' + name);
            // console.log(migrations);
        });
        umzug.on('reverted', function(name, migrations) {
            console.log('reverted ' + name);
            // console.log(migrations);
        });
    });

    it('up umzug', async function() {
        try {
            await umzug.up({});
        } catch (error) {
            console.log(error);
        }
    });

    it('down to specific migration', async function() {
        await umzug.down({
            to: '2'
        });
    });

    it('down umzug', async function() {
        await umzug.down(0);
    });

    it('2 different objects umzug utils test', function() {
        let umzugUtils1 = require('../../../common/umzugUtils')(params);
        let umzugUtils2 = require('../../../common/umzugUtils')(params);
        umzugUtils1.a = 2;
        umzugUtils2.a = 3;
        expect(umzugUtils1.a).to.equal(2);
        expect(umzugUtils2.a).to.equal(3);
    });

    it('syncdatabase test', async function() {
        let umzugUtils = require('../../../common/umzugUtils')(params);
        await umzugUtils.syncDatabase();
        let pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(0);
        await umzugUtils.syncDatabase('2.js', false);
        pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(1);
        expect(pendingMigrations.findIndex(i => i.file === '3.js')).to.equal(0);
        await umzugUtils.syncDatabase('3.js', false);
        pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(0);
        await umzugUtils.syncDatabase('1.js', true);
        pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(2);
        expect(pendingMigrations.findIndex(i => i.file === '2.js')).to.equal(0);
        expect(pendingMigrations.findIndex(i => i.file === '3.js')).to.equal(1);
        await umzugUtils.syncDatabase('1.js', false);
        pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(2);
        expect(pendingMigrations.findIndex(i => i.file === '2.js')).to.equal(0);
        expect(pendingMigrations.findIndex(i => i.file === '3.js')).to.equal(1);
        await umzugUtils.syncDatabase('2.js', false);
        pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(1);
        expect(pendingMigrations.findIndex(i => i.file === '3.js')).to.equal(0);
    });

    it('isRunMigrationsTest', async function() {
        let umzugUtils = require('../../../common/umzugUtils')(params);
        expect(await umzugUtils.isRunMigrations()).to.equal(1);
        await umzugUtils.syncDatabase();
        let pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(0);

        let executedMigrations = await umzugUtils.getExecutedMigrations();
        expect(executedMigrations.length).to.equal(3);

        expect(await umzugUtils.isRunMigrations()).to.equal(0);

        expect(await umzugUtils.isRunMigrations('2.js')).to.equal(-1);
        await umzugUtils.syncDatabase('2.js', false);
        pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(1);

        expect(await umzugUtils.isRunMigrations()).to.equal(1);

        expect(pendingMigrations.findIndex(i => i.file === '3.js')).to.equal(0);
        expect(await umzugUtils.isRunMigrations('3.js')).to.equal(1);
        await umzugUtils.syncDatabase('3.js', false);
        pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(0);

        expect(await umzugUtils.isRunMigrations()).to.equal(0);

        expect(await umzugUtils.isRunMigrations('1.js')).to.equal(-1);
        await umzugUtils.syncDatabase('1.js', true);
        pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(2);

        expect(await umzugUtils.isRunMigrations()).to.equal(1);

        expect(pendingMigrations.findIndex(i => i.file === '2.js')).to.equal(0);
        expect(pendingMigrations.findIndex(i => i.file === '3.js')).to.equal(1);
        expect(await umzugUtils.isRunMigrations('1.js')).to.equal(0);
        await umzugUtils.syncDatabase('1.js', false);
        pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(2);
        expect(await umzugUtils.isRunMigrations()).to.equal(1);

        expect(pendingMigrations.findIndex(i => i.file === '2.js')).to.equal(0);
        expect(pendingMigrations.findIndex(i => i.file === '3.js')).to.equal(1);
        expect(await umzugUtils.isRunMigrations('2.js')).to.equal(1);
        await umzugUtils.syncDatabase('2.js', false);
        pendingMigrations = await umzugUtils.getPendingMigrations();
        expect(pendingMigrations.length).to.equal(1);
        expect(await umzugUtils.isRunMigrations()).to.equal(1);

        expect(pendingMigrations.findIndex(i => i.file === '3.js')).to.equal(0);

    });

    it('get latest migration name', async function() {
        let umzugUtils = require('../../../common/umzugUtils')(params);
        expect(umzugUtils.getLatestMigrationName()).to.equal('3.js');
    });

});