'use strict';

module.exports = {
    up: async function(params) {
        console.log('up ' + __filename);
        return __filename;
    },

    down: async function(params) {
        console.log('down ' + __filename);
        return __filename;
    }
};