'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

var chai = require('chai');
var expect = chai.expect;
const logger = require('../../../common/Logger');

describe('Couch DB KT Session UT', function() {
    this.timeout(1000000000);

    var utils = require('../../common/Utils.js');
    var cntrlrUtils = require('../../../controllers/common/Utils');
    var couchUtils = require('../../../controllers/common/CouchDBUtils');
    var mainDBInstance = couchUtils.getMainCouchDB();
    let userdbInstance = couchUtils.getUserCouchDB();

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const moment = require('moment');

    // let nanoWithPromises = require('nano-blue')('localhost:5984');
    let nanoWithPromises = require('nano-blue')('http://couchadmin:test@localhost:5984');
    let dbName = 'alienhu';
    let resp;
    // resp = await nanoWithPromises.db.create(dbName);
    // console.log(resp);

    let db = nanoWithPromises.use(dbName);
    let doc = {
        _id: 'item_' + moment().format('x'),
        name: 'apple',
        price: 100
    };

    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    after(function() {

    });

    it('test', async function() {

        resp = await db.insert(doc);
        console.log(resp);

        resp = await nanoWithPromises.db.get(dbName);
        console.log(resp);
    });

    it('test2', async function() {
        resp = await db.head(doc._id);

        console.log(resp);
        doc._rev = JSON.parse(resp[1].etag);
        resp = await db.insert(doc);
        console.log(resp);

        resp = await nanoWithPromises.db.get(dbName);
        console.log(resp);
    });

    it('test2', async function() {
        resp = await db.head(doc._id);

        console.log(resp);
        doc._rev = JSON.parse(resp[1].etag);
        doc._deleted = true;
        resp = await db.insert(doc);
        console.log(resp);

        resp = await nanoWithPromises.db.get(dbName);
        console.log(resp);
    });

});