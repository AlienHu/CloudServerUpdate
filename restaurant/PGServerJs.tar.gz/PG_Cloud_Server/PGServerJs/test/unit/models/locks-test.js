   'use strict';

   // https://www.npmjs.com/package/lockfile
   var chai = require('chai');
   var expect = chai.expect;

   describe('Locks Test UT', function() {
       this.timeout(100000);

       var lockUtils = require('../../../common/lockUtils.js');
       var utils = require('../../common/Utils.js');
       var cntrlrUtils = require('../../../controllers/common/Utils');
       var path = __dirname + '/locks';
       lockUtils.createLockDir(path);
       var lockOptions = {
           stale: 5000,
           retries: 4,
           retryWait: 1000
       };

       after(function() {
           utils.deleteDir(path);
       });

       it('test', function() {
           return lockUtils.unlockAsync('abcsai.lock').then(function(resp) {
               console.log(resp);
           });
       });

       it('test1', function() {
           var lockPath = path + '/abc1.lock';
           var bException = false;

           return lockUtils.lockAsync(lockPath, cntrlrUtils.clone(lockOptions)).then(function() {
               return lockUtils.lockAsync(lockPath, cntrlrUtils.clone(lockOptions)).then(function() {

                   bException = true;
                   expect(1).to.equal(0);

               }).catch(function(err) {

                   if (bException) {
                       console.log('failed');
                       expect(1).to.equal(0);
                   }

               });
           });

       });

       it('test2', function() {
           var lockPath = path + '/abc2.lock';
           var bException = false;

           return lockUtils.lockAsync(lockPath, cntrlrUtils.clone(lockOptions)).then(function() {
               setTimeout(function() {
                   console.log('calling unlockAsync');
                   lockUtils.unlockAsync(lockPath).then(function(resp) {
                       console.log('unlockAsync returned <' + resp + '>');
                   });
               }, 2000);

               return lockUtils.lockAsync(lockPath, cntrlrUtils.clone(lockOptions)).then(function() {
                   console.log('created lock');
               }).catch(function(err) {
                   console.log('failed');
                   expect(1).to.equal(0);
               });

           });

       });

       it.only('delete lock without creating', async function() {
           var lockPath = path + '/sai.lock';
           try {
               await lockUtils.unlockAsync(lockPath);
           } catch (error) {
               console.log(error);
           }
       });

   });