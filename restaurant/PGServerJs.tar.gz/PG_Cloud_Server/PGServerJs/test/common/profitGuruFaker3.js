const faker = require('faker');
faker.locale = 'en_IND';

const profitGuruFakerExt = require('./profitGuruFakerExt');
const profitGuruFaker = require('./profitGuruFaker');
const moment = require('moment');

const couchDBUtils = require('../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();

let foo = function() {
    let _self = this;

    let roomTypesArray;
    this.getFakerRoomTariff = function() {
        if (!roomTypesArray) {
            roomTypesArray = ['Deluxe', 'AC Deluxe', 'Double Bed Room', 'Single Room', 'AC with food', 'Dormitory', 'Tents'];
        } else if (roomTypesArray.length === 0) {
            throw 'Out of names';
        }

        let data = {
            name: roomTypesArray.shift(),
            description: faker.random.word(),
            price: faker.random.number({
                min: 0,
                max: 500
            }) * 100,
            discount: faker.random.number({
                min: 0,
                max: 75
            }),
            count: faker.random.number({
                min: 1,
                max: 10
            }),
            pricingProfile: faker.random.number({
                min: 0,
                max: 1
            })
        };

        return data;
    };

    let roomAddOnTariffArray;
    this.getFakerRoomAddOnTariff = function() {
        if (!roomAddOnTariffArray) {
            roomAddOnTariffArray = ['Cot', 'Pillow', 'Fan', 'Laundry', 'AC Cot', 'AC Pillow'];
        } else if (roomAddOnTariffArray.length === 0) {
            throw 'Out of names';
        }

        let data = {
            name: roomAddOnTariffArray.shift(),
            description: faker.random.word(),
            price: faker.random.number({
                min: 0,
                max: 500
            }),
            count: faker.random.number({
                min: 1,
                max: 10
            })
        };

        return data;
    };

    async function getTypeFromDB(type, bUniqueByName) {

        let queryResponse = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
        let response = [];

        if (!bUniqueByName) {
            for (var i = 0; i < queryResponse.length; i++) {
                response.push(queryResponse[i].doc.id);
            }
        } else {
            throw 'Not Implemented';
        }

        return response;
    }

    let tariffArray = [];
    this.getFakerRoom = async function() {
        if (!tariffArray.length) {
            tariffArray = await getTypeFromDB('tariff');
            if (tariffArray.length < 1) {
                throw 'Create Room Tariff first';
            }
        }

        let data = {
            name: faker.random.number({
                min: 1,
                max: 500
            }),
            tariffId: tariffArray.shift(),
            beds: faker.random.number({
                min: 1,
                max: 20
            })

        };

        return data;
    };

    let source = [];
    let roomIds;
    this.getReservationForm = async function() {
        if (!source.length) {
            source = ['Internet', 'MakemyTrip', 'Reference', 'AutoRickshaw'];
        }

        if (!roomIds) {
            roomIds = await getTypeFromDB('room');
        }

        let data = {
            customerInfo: {
                first_name: faker.name.firstName(),
                last_name: faker.name.lastName(),
                phone_number: faker.phone.phoneNumber(),
                docs: {
                    type: "EDAG32",
                    value: "dfasdfs"
                },
                address: faker.address.streetName()
            },
            bookingInfo: {
                source: source.shift(),
                checkInDate: moment().add(faker.random.number({
                    min: 1,
                    max: 90
                }, 'days')).format('x'),
                roomsInfo: [{
                    roomId: faker.random.arrayElement(roomIds),
                    price: 0,
                    discount: 10
                }],
                status: 0,
                comment: faker.lorem.word(),
                personCount: {
                    chargeables: faker.random.number({
                        min: 1,
                        max: 30
                    }),
                    nonChargeables: faker.random.number({
                        min: 1,
                        max: 10
                    })
                },
                payments: [{
                        payment_type: 'Cash',
                        timeStamp: 1231323,
                        payment_amount: faker.random.number({
                            min: 100,
                            max: 10000
                        }),
                        bReverse: false // cancel payment
                    },
                    {
                        payment_type: 'Card',
                        timeStamp: 1231323,
                        payment_amount: faker.random.number({
                            min: 100,
                            max: 10000
                        }),
                        bReverse: false // cancel payment
                    }
                ]
            }
        };

        data.bookingInfo.checkOutDate = moment(parseInt(data.bookingInfo.checkInDate)).add(faker.random.number({
            min: 1,
            max: 6
        })).format('x');

        return data;
    };

    this.getFakerPayments = function() {
        return {
            payment_type: 'Card',
            timeStamp: 1231323,
            payment_amount: faker.random.number({
                min: 100,
                max: 10000
            }),
            bReverse: false // cancel payment
        };
    };

    this.getFakerCampaign = async function(bAddInvalidPh, bNow) {
        let allCustomers = await couchDBUtils.getAllDocsByType('customer', mainDBInstance);
        if (allCustomers.length < 5) {
            throw 'Create Customers First';
        }

        let allCTs = await couchDBUtils.getAllDocsByType('ct', mainDBInstance);
        if (allCTs.length < 2) {
            throw 'Create CTs first';
        }

        let customerIds = [];
        if (!bAddInvalidPh) {
            for (let i = 0; i < 5; i++) {
                customerIds.push({
                    _id: allCustomers[i].doc._id,
                    status: 'pending'
                });
            }
        } else {
            customerIds.push({
                _id: allCustomers[0].doc._id,
                status: 'pending'
            });
            customerIds.push({
                _id: allCustomers[6].doc._id,
                status: 'pending'
            });
            customerIds.push({
                _id: allCustomers[7].doc._id,
                status: 'pending'
            });
            customerIds.push({
                _id: allCustomers[1].doc._id,
                status: 'pending'
            });
            customerIds.push({
                _id: allCustomers[4].doc._id,
                status: 'pending'
            });
        }

        let templateType = faker.random.arrayElement(allCTs).doc;
        let template = faker.random.arrayElement(templateType.templates);
        // let minuteToAdd = faker.random.number({
        //     min: 1,
        //     max: 3
        // });
        let secondsToAdd = 30;
        if (bNow) {
            secondsToAdd = 0;
        }

        let cmp = {
            "customers": customerIds,
            "templateType": templateType,
            "message": template.message + '-alien',
            "isTemplate": faker.random.arrayElement([true, false]),
            "eventDateTime": moment().add(secondsToAdd, 'seconds'), //.toISOString(),
            "status": "pending",
            "type": "cmp_",
            "template": template
        };

        if (cmp.message.length > 100) {
            cmp.message = cmp.message.substr(0, 100);
        }

        return cmp;
    };

};

module.exports = new foo();