'use strict';
var faker = require('faker');
faker.locale = 'en_IND';
//faker::Config.locale = 'en-US';
var path = require('path');

var chance = require('chance')();
const moment = require('moment');
const globalConfigCntrlr = require('../../controllers/GlobalConfigurations');
const pharmaData = require('../data/pharma.json');
let iReadCount = 0;

var profitGuruFakerElementsData = function() {
    var _self = this;
    // let ConfigIds = [];

    function getRandomBoolean(bValue, bTrue) {

        var bRetValue = bValue;
        if (bTrue && bRetValue === undefined) {
            bRetValue = true;
        } else if (bRetValue === undefined) {
            bRetValue = faker.random.boolean();
        }

        return bRetValue;
    }

    function getRandomNumber(value, minValue, maxValue) {
        if (minValue == undefined) {
            minValue = 1;
        }
        if (maxValue === undefined) {
            maxValue = 1000;
        }

        var retValue = value;
        if (retValue === undefined) {
            retValue = faker.random.number({
                min: minValue,
                max: maxValue
            });
        }

        return retValue;
    }

    function getRandomArrayValue(value, array, defaultValue) {
        if (value !== undefined) {
            return value;
        }
        if (array != undefined && array.length) {
            return faker.random.arrayElement(array);
        }
        return defaultValue;
    }

    async function getSuppliersDB(type) {
        var couchDBUtils = require('../../controllers/common/CouchDBUtils');
        var mainDBInstance = couchDBUtils.getMainCouchDB();
        let resp = await couchDBUtils.getAllDocsByType('supplier', mainDBInstance);

        let suppliersResp = [];
        for (var i = 0; i < resp.length; i++) {
            suppliersResp.push(resp[i].doc.person_id);
        }
        return suppliersResp;
    }

    this.getConfigsFromDB = async function(type, bUniqueByName) {

        let resp = await globalConfigCntrlr.getAllConfigDocsByType(type);
        let configResponse = [];

        if (!bUniqueByName) {
            for (var i = 0; i < resp.length; i++) {
                configResponse.push(resp[i].doc.id);
            }
        } else {
            let taxes = {};
            for (let i = 0; i < resp.length; i++) {
                let name = resp[i].doc.name;
                if (!taxes.hasOwnProperty(name)) {
                    taxes[name] = [];
                };

                taxes[name].push(resp[i].doc.id);
            }

            for (let name in taxes) {
                configResponse.push(faker.random.arrayElement(taxes[name]));
            }
        }
        return configResponse;
    };

    async function getConfigs(type, item, bFillAll, bFill, params) {
        if (type === 'tax') {
            if (bFillAll) {
                item.purchaseTaxes = [];

                let configsArray = await _self.getConfigsFromDB(type, true);
                var bNumTaxes = faker.random.number({
                    min: 1,
                    max: configsArray.length
                });
                for (var i = 0; i < bNumTaxes; i++) {
                    item.purchaseTaxes.push(configsArray[i]);
                }
            }
            if (bFillAll) {
                let configsArray = await _self.getConfigsFromDB(type, true);
                var bNumTaxes = faker.random.number({
                    min: 1,
                    max: configsArray.length
                });
                for (var i = 0; i < bNumTaxes; i++) {
                    item.salesTaxes.push(configsArray[i]);
                }
            }

            return;
        }

        let configsArray = await _self.getConfigsFromDB(type);
        if (type === 'unit') {
            item.unitsInfo = {};
            if (item.bMultipleUnits) {
                item.unitsInfo[configsArray[0]] = {
                    refUnitId: configsArray[1],
                    factor: 10
                };
                item.unitsInfo[configsArray[1]] = {
                    refUnitId: configsArray[2],
                    factor: 20
                };
            }
            item.unitsInfo[configsArray[2]] = {
                refUnitId: configsArray[2],
                factor: 1
            };
            let units = Object.keys(item.unitsInfo);
            item.baseUnitId = units[units.length - 1];
            item.defaultPurchaseUnitId = faker.random.arrayElement(units);
            item.defaultSellingUnitId = faker.random.arrayElement(units);
        }
        if (type === 'category') {

            item.categoryId = faker.random.arrayElement(configsArray);
        }

        if (type === 'slab') {
            let bSalesTaxSlab = getRandomBoolean(params.bTaxSlab, bFillAll);
            let bPurchaseTaxSlab = getRandomBoolean(params.bTaxSlab, bFillAll);

            if (bPurchaseTaxSlab) {
                item.bSPTaxInclusive = false;
                item.purchaseSlab = faker.random.arrayElement(configsArray);
            }
            if (bSalesTaxSlab) {
                item.bPPTaxInclusive = false;
                item.salesSlab = faker.random.arrayElement(configsArray);
            }
        }

        if (type === 'brand') {
            if (bFill || bFillAll) {
                item.brandId = faker.random.arrayElement(configsArray);
            }
        }

        configsArray = [];
    }

    /**
     *  bFillAll: All the values will be filled (true)
     */
    this.getFakerItem = async function(params) {
        var bFillAll = getRandomBoolean(params.bFillAll);
        var bMultipleUnits = params.bMultipleUnits === undefined ? false : params.bMultipleUnits;
        var bPProfiles = params.bPProfiles === undefined ? false : params.bPProfiles;
        var bHasBatchNumber = getRandomBoolean(params.bHasBatchNumber, bFillAll);
        var bHasExpiryDate = getRandomBoolean(params.bHasExpiryDate, bFillAll);
        var bSerialized = getRandomBoolean(params.bSerialized, bFillAll);
        var bIMEINumber = getRandomBoolean(params.bIMEINumber, bFillAll);
        var bSPTaxInclusive = getRandomBoolean(params.bSPTaxInclusive, bFillAll);
        var bPPTaxInclusive = getRandomBoolean(params.bPPTaxInclusive, bFillAll);
        var bHasInitialStock = getRandomBoolean(params.bHasInitialStock, bFillAll);
        //now conversionFactor -> factor
        var conversionFactor = getRandomNumber(params.conversionFactor);
        if (conversionFactor === 1) {
            //switching of multiple units
            bMultipleUnits = false;
        }
        var iAttributeCount = getRandomNumber(params.iAttributeCount, 0, 5);
        let itemTypes = ['Prepared', 'Ingredient', 'Normal', 'Liquor'];
        if (params.bNoIngredient) {
            itemTypes = ['Prepared', 'Normal', 'Liquor'];
        }
        var itemType = getRandomArrayValue(params.itemType, itemTypes, 'Normal');
        let maxCategories = params.maxCategories ? params.maxCategories : 5;
        let maxUnits = params.maxUnits ? params.maxUnits : 5;
        let maxTaxes = params.maxTaxes ? params.maxTaxes : 5;
        let maxAttributes = params.maxAttributes ? params.maxAttributes : 5;

        var item = {
            name: faker.commerce.productName(),
            // name: pharmaData[iReadCount++].name,
            ItemType: itemType,
            hsn: faker.random.number(),
            categoryId: faker.random.number({
                min: 1,
                max: maxCategories
            }),
            is_serialized: bSerialized,
            imeiCount: bIMEINumber ? faker.random.number({
                min: 1,
                max: 5
            }) : 0,
            hasExpiryDate: bHasExpiryDate,
            hasVariants: iAttributeCount !== 0,
            hasBatchNumber: bHasBatchNumber,
            bSPTaxInclusive: bSPTaxInclusive,
            bPPTaxInclusive: bPPTaxInclusive,
            bOTG: false,
            bMultipleUnits: bMultipleUnits,
            bPProfiles: bPProfiles,
            //During real item creation we would be taking this from session object created after login
            employeeId: 'admin',
            purchaseTaxes: [],
            salesTaxes: [],
            initialStock: {}
        };

        var bFill = faker.random.boolean();

        bFill = faker.random.boolean();
        if (bFill || bFillAll) {
            item.item_number = faker.random.number();
        }
        bFill = faker.random.boolean();
        if (bFill || bFillAll) {
            item.description = faker.random.word();
        }
        bFill = faker.random.boolean();
        if (bFill || bFillAll) {
            item.reorderLevel = faker.random.number({
                min: 10,
                max: 200
            });

            bFill = faker.random.boolean();
            if (bFill || bFillAll) {
                item.reorderQuantity = faker.random.number({
                    min: 0,
                    max: 500
                });
            }
        }

        item.attributes = [];
        for (var i = 0; i < iAttributeCount; i++) {
            item.attributes.push(i + 1);
        }

        var configs = ['unit', 'category', 'brand', 'tax', 'slab'];
        for (var i = 0; i < configs.length; i++) {
            var type = configs[i];

            await getConfigs(type, item, bFillAll, bFill, params);

        }
        let pProfiles = await _self.getConfigsFromDB('pProfile');
        let pProfilesLength = 1;
        if (bPProfiles) {
            pProfilesLength = 3;
        }
        if (pProfiles.length < pProfilesLength) {
            let resp = await globalConfigCntrlr.createPriceProfile({
                name: 'non-ac'
            });
            resp = await globalConfigCntrlr.createPriceProfile({
                name: 'ac',
                refId: resp.id,
                delta: 50
            });
            resp = await globalConfigCntrlr.createPriceProfile({
                name: 'garden',
                refId: resp.id,
                deltaPercent: 10
            });
            resp = await globalConfigCntrlr.createPriceProfile({
                name: 'p2',
                refId: resp.id,
                delta: -10
            });
            resp = await globalConfigCntrlr.createPriceProfile({
                name: 'p3',
                refId: resp.id,
                deltaPercent: -10
            });
            resp = await globalConfigCntrlr.createPriceProfile({
                name: 'p1',
                refId: resp.id,
                delta: 100
            });

            pProfiles = await _self.getConfigsFromDB('pProfile')
        }

        let discountsArray = await _self.getConfigsFromDB('discount');

        let unitsArray = Object.keys(item.unitsInfo);
        let cf;
        for (let i = 0; i < unitsArray.length; i++) {
            if (!cf) {
                cf = 1;
            }
            let info = item.unitsInfo[unitsArray[i]];
            info.pProfilesData = {};
            info.purchasePrice = 1000.77 / cf;
            info.mrp = 1200.55 / cf;
            for (let j = 0; j < pProfilesLength; j++) {
                info.pProfilesData[pProfiles[j]] = {
                    sellingPrice: (1100.33 + 10 * j) / cf,
                    discountId: discountsArray[j]
                };
            }

            cf *= info.factor;
        }
        item.bAutoComputePurchasePrice = true;
        item.bAutoComputeMRP = true;
        item.bAutoComputeSellingPrice = true;

        if (bHasInitialStock) {
            item.initialStock = [];

            if (iAttributeCount === 0) {
                item.initialStock.push(await _self.getFakerBatch(bHasExpiryDate, bHasBatchNumber, bSerialized, item.imeiCount, undefined, item.unitsInfo));
            } else {
                for (var i = 0; i < 3; i++) {
                    var attributeInfo = {};
                    for (var j = 0; j < item.attributes.length; j++) {
                        attributeInfo[item.attributes[j]] = i;
                    }

                    item.initialStock.push(await _self.getFakerBatch(bHasExpiryDate, bHasBatchNumber, bSerialized, item.imeiCount, attributeInfo, item.unitsInfo));
                }
            }

        }

        return item;
    };

    this.getFakerBatch = async function(bHasExpiryDate, bHasBatchNumber, bSerialized, imeiCount, attributeInfo, unitsInfo) {

        var batch = {
            quantity: faker.random.number({
                min: 10,
                max: 1000
            }),
            //During real item creation we would be taking this from session object created after login
            employeeId: 'admin',
            location_id: 1
        };

        if (bHasExpiryDate) {
            batch.expiry = faker.date.future().toString();
        }

        if (bHasBatchNumber) {
            batch.batchId = (faker.random.alphaNumeric()).toString();
        }

        batch.uniqueDetails = [];
        if (bSerialized || imeiCount) {
            for (var i = 0; i < batch.quantity; i++) {
                var uniqueDetails = {};
                if (bSerialized) {
                    uniqueDetails.serialnumber = (faker.random.uuid()).toString();
                }

                uniqueDetails.imeiNumbers = [];
                for (var j = 0; j < imeiCount; j++) {
                    uniqueDetails.imeiNumbers.push(faker.random.number({
                        min: 100000000000000,
                        max: 999999999999999
                    }));
                }
                batch.uniqueDetails.push(uniqueDetails);
            }
        }

        if (attributeInfo) {
            batch.attributeInfo = attributeInfo;
        }

        batch.unitsInfo = unitsInfo;

        return batch;
    };

    this.getFakeUniqueDetails = function(imeiCount, bSerialized) {
        var uniqueDetails = {
            imeiNumbers: []
        };

        if (bSerialized) {
            uniqueDetails.serialnumber = (faker.random.uuid()).toString();
        }

        for (var i = 0; i < imeiCount; i++) {
            uniqueDetails.imeiNumbers.push(faker.random.number({
                min: 100000000000000,
                max: 999999999999999
            }));
        }

        return uniqueDetails;
    };

    this.getFakerRandomAttribute = function() {
        var attributeData = {
            name: faker.commerce.productAdjective(),
            values: []
        }

        var iRandomAttributeValuesLength = faker.random.number({
            min: 7,
            max: 8
        });

        for (var i = 1; i < iRandomAttributeValuesLength + 1; i++) {
            var valueData = {};
            valueData = {
                name: faker.commerce.productMaterial() + "" + i, //faker gives random not necessarily unique. So introducing uniqueness by adding i
                code: faker.commerce.productMaterial()
            }
            attributeData.values.push(valueData);
        }

        return attributeData;
    }

    /**
     * values length is atleast 10
     */
    this.getFakerRandomAttributeUpdate = function(attributeData, bChangeAll) {
        attributeData.name = faker.commerce.productAdjective();

        var values = attributeData.values;
        var valueIds = Object.keys(values);
        //Remove some.. make sure no item is using it
        var bNumberToRemove = faker.random.number({
            min: 1,
            max: 5
        });

        for (var i = 0; i < bNumberToRemove; i++) {
            var randomIdToRemove = faker.random.arrayElement(valueIds);
            //delete values[randomIdToRemove];
            //var index = valueIds.indexOf(randomIdToRemove);
            // valueIds.splice(index, 0);
            attributeData.values[randomIdToRemove].deleted = 1
        }

        //Edit some
        var bNumberToEdit = faker.random.number({
            min: 5,
            max: 8
        });
        for (var i = 0; i < bNumberToEdit; i++) {
            var randomIdToEdit = faker.random.arrayElement(valueIds);
            values[randomIdToEdit].name += randomIdToEdit + "" + i;
        }

        //Add some
        var bNumberToAdd = faker.random.number({
            min: 9,
            max: 12
        });
        for (var i = 0; i < bNumberToAdd; i++) {
            values['new' + i] = {
                name: faker.commerce.productMaterial() + "" + i,
                code: faker.commerce.productMaterial()
            };
        }

        // var iRandomAttributeValuesLength = faker.random.number({
        //     min: 2,
        //     max: 5
        // });

        // for (var i = 1; i < iRandomAttributeValuesLength + 1; i++) {
        //     var valueData = {};
        //     valueData = {
        //         name: faker.commerce.productMaterial(),
        //         code: faker.commerce.productMaterial()
        //     }
        //     attributeData.values.push(valueData);
        // }

        return attributeData;
    }

    this.getPaymentType = function() {
        return {
            'payment_type': faker.random.arrayElement(["Cash", "Cheque", "Debit Card", "Credit Card"]),
        }
    };

    let applicationSettings;
    this.getApplicationSettings = async function() {
        if (!applicationSettings) {
            var couchDBUtils = require('../../controllers/common/CouchDBUtils');
            var coredbInstance = couchDBUtils.getCoreCouchDB();
            applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coredbInstance);
        }

        return applicationSettings;
    };

};

module.exports = new profitGuruFakerElementsData();