var Utils = function() {
    'use strict';

    var q = require('q');
    var fs = require('fs');
    require('errors');
    var _self = this;
    var shelljs = require('shelljs');
    const contlrUtils = require('../../controllers/common/Utils');
    this.clone = contlrUtils.clone;
    const commonUtils = require('../../common/Utils');

    this.compareObject = commonUtils.compareObject;

    this.compareArray = commonUtils.compareArray;

    this.compareFields = function(refValue, insValue) {
        if (refValue !== insValue) {
            return false;

        }

        return true;
    };

    this.mergeObjects = function(objArray) {
        var mergedObj = {};
        for (var i = 0; i < objArray.length; i++) {
            var obj = objArray[i];
            for (var attrname in obj) {
                if (obj.hasOwnProperty(attrname))
                    mergedObj[attrname] = obj[attrname];
            }
        }

        return mergedObj;
    };

    this.deleteFilesOfType = function(dirPath, fileTypeArray) {
        fs
            .readdirSync(dirPath)
            .filter(function(file) {
                var bTypeMatches = false;
                for (var i = 0; i < fileTypeArray.length; i++) {
                    if (file.indexOf('.' + fileTypeArray[i]) > -1) {
                        bTypeMatches = true;
                        break;
                    }
                }
                return bTypeMatches;
            })
            .forEach(function(file) {
                try {
                    //console.log('deleting ' + file);
                    fs.unlinkSync(file);
                } catch (error) {
                    //console.log('delete failed ' + file);
                }
            });
    };

    this.deleteDir = function(dirPath) {
        shelljs.rm('-r', dirPath);
    };

};
module.exports = new Utils();