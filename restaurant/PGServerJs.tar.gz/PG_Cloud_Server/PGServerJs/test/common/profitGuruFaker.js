var faker = require('faker');
faker.locale = 'en_IND';
//faker::Config.locale = 'en-US';
var path = require('path');
var allUserEntitlements = require(path.join(__dirname, '../../config', 'profitguruCoreConfig', 'profitGuruUsersAllEntitlements.json'));
var chance = require('chance')();

// var defaultDailyLikeliHood = {
//     Prepared: 50,
//     FastFood: 25,
//     Ingrediant: 25
// };

var profitGuruFakerElementsData = function() {
    var _self = this;
    this.getFakerSession = function() {
        return {
            sale_mode: 'sale',
            location_id: 1,
            user: {
                name: 'admin',
                first_name: 'couch',
                last_name: 'admin'
            }
        };
    };

    //Deprecated:: This will work with node_migration branch
    this.getFakerItem = function(itemType, appType, includePhpTaxFields) {
        var item = {
            "name": faker.commerce.productName(),
            "item_number": faker.random.number(),
            "cost_price": faker.random.number(),
            "unit_price": faker.random.number(),
            "quantity": "",
            "category": faker.lorem.word(),
            "supplier_id": null,
            "item_image": "",
            "is_serialized": "0",
            "imeiCount": 0,
            "is_deleted": "0",
            "itemNprice": "0",
            "allow_alt_description": "0"
        };

        //Restaurant Item Creations
        var randomItemType;
        if (process.env.APP_TYPE === "restaurant" && !itemType) {

            var itemTypeList = ['Prepared', 'FastFood', 'Ingrediant'];
            randomItemType = chance.pickone(itemTypeList);

            item.itemType = randomItemType;

            if (randomItemType === 'Prepared') {
                item.isprepared = true;
                item.issellable = true;
                item.isbought = false;

            } else if (randomItemType === 'FastFood') {
                item.isprepared = false;
                item.issellable = true;
                item.isbought = true;

            } else { // Ingrediant
                item.isprepared = false;
                item.issellable = false;
                item.isbought = true;
                item.itemNprice = "0";
            }

        } else { //Retail
            itemItemType = "Prepared";
            item.isprepared = false;
            item.issellable = false;
            item.isbought = false;

        }

        item.expiry_date = faker.date.future();
        item.discount_expiry = faker.date.future();

        if (!item.itemNprice) { // should item price is on the Go?
            item.itemNprice = chance.bool({
                likelihood: 15
            });
        }
        item.location_id = 1;
        item.reorder_level = faker.random.number({
            min: 0,
            max: 2000
        });
        item.quantity = faker.random.number({
            min: 0,
            max: 10000
        });
        item.receiving_quantity = faker.random.number({
            min: 0,
            max: 10000
        });
        item.loyaltyPerc = faker.finance.amount(0, 10, 2);

        item.description = faker.lorem.word();
        item.discount = faker.finance.amount(0, 70, 2);

        //During real item creation we would be taking this from session object created after login
        item.employeeId = 'admin';
        return item;
    };

    this.getFakerBatch = function(bFillAll, bHasExpiryDate, bHasBatchNumber) {
        var batch = {
            purchasePrice: faker.random.number({
                min: 10,
                max: 1000
            }),
            sellingPrice: faker.random.number({
                min: 10,
                max: 1000
            }),
            mrp: faker.random.number({
                min: 10,
                max: 1000
            }),
            quantity: faker.random.number({
                min: 10,
                max: 1000
            }),
            //During real item creation we would be taking this from session object created after login
            employeeId: 'admin'
        };

        var bFill = faker.random.boolean();
        if (bFill || bFillAll) {
            batch.discountId = faker.random.number({
                min: 1,
                max: 5
            });
        }

        if (bHasExpiryDate) {
            batch.expiry = faker.date.future().toString();
        }

        if (bHasBatchNumber) {
            batch.batchId = faker.random.alphaNumeric().toString();
        }

        return batch;
    };

    this.getPhpItemData = function() {
        return {

            "isprepared": true,
            "issellable": true,
            "isbought": false,
            "quantity": "",

            "item_id": "",
            "name": faker.commerce.productName(),
            "item_number": faker.random.number(),
            "cost_price": faker.random.number(),
            "unit_price": faker.random.number(),
            "1_quantity": faker.random.number(),
            "receiving_quantity": faker.random.number(),
            "reorder_level": "0",
            "loyaltyPerc": "0",
            "description": "",
            "discount": "",
            "category": "",
            "supplier_id": "",
            "item_image": "",
            "is_serialized": "0",
            "imeiCount": faker.random.number({
                min: 0,
                max: 4
            }),
            "is_deleted": "0",
            "itemNprice": "0",
            "expiry": "",
            "allow_alt_description": "0",
            "ItemType": "Prepared",
            "custom1": 0,
            "custom2": 0,
            "custom3": 0,
            "custom4": 0,
            "custom5": 0,
            "custom6": 0,
            "custom7": 0,
            "custom8": 0,
            "custom9": 0,
            "custom10": 0
        };
    };

    this.getFakerCustomer = function() {
        return {
            // "person_id": "",
            "type": 'customer_',
            "first_name": faker.name.firstName(),
            "last_name": faker.name.lastName(),
            "gender": faker.random.arrayElement(['M', 'F']),
            "email": faker.internet.email(),
            "phone_number": phoneNumbers.shift(),
            "address_1": faker.address.streetName(),
            "address_2": faker.address.streetAddress(),
            "city": faker.address.city(),
            "state": faker.address.state(),
            "zip": faker.address.zipCode(),
            "country": faker.address.country(),
            "comments": "",
            "account_number": (faker.random.number()).toString(), //"",
            "company_name": faker.company.companyName(),
            "loyaltyPnts": 0,
            "allow_credit": true,
            "credit_balance": 100,
            "docs": {
                panCard: "EDAG32",
                drivingLic: "dfasdfs"
            },
            "birth_date": faker.date.past().toString(),
            "anniversary": faker.date.past().toString()
        };
    };

    this.getFakerPersonData = function() {
        return {
            // "person_id": "",
            "first_name": faker.name.firstName(),
            "last_name": faker.name.lastName(),
            "gender": faker.random.arrayElement(['M', 'F']),
            "email": faker.internet.email(),
            "phone_number": faker.phone.phoneNumber(),
            "address_1": faker.address.streetName(),
            "address_2": faker.address.streetAddress(),
            "city": faker.address.city(),
            "state": faker.address.state(),
            "zip": faker.address.zipCode(),
            "country": faker.address.country(),
            "comments": "",
            "account_number": (faker.random.number()).toString(), //"",
            "company_name": faker.company.companyName(),
            "loyalty": faker.random.arrayElement([0, 1])
        };
    };

    this.getFakerPersonWithCredit = function() {
        return {
            // "person_id": "",
            "first_name": faker.name.firstName(),
            "last_name": faker.name.lastName(),
            "gender": faker.random.arrayElement(['M', 'F']),
            "email": faker.internet.email(),
            "phone_number": phoneNumbers.shift(),
            "address_1": faker.address.streetName(),
            "address_2": faker.address.streetAddress(),
            "city": faker.address.city(),
            "state": faker.address.state(),
            "zip": faker.address.zipCode(),
            "country": faker.address.country(),
            "comments": "",
            "account_number": (faker.random.number()).toString(), //"",
            "company_name": faker.company.companyName(),
            "loyalty": faker.random.arrayElement([0, 1]),
            "allow_credit": faker.random.arrayElement(['Allow', '']),
            "credit_balance": faker.random.number({
                min: 0,
                max: 100
            }),
            "credit_limit": faker.random.number({
                min: 0,
                max: 100000
            }),
            "payment_terms": faker.random.arrayElement(['days', 'weeks', 'months', '']),
            "by_weeks": faker.random.number({
                min: 0,
                max: 8
            }),
            "by_days": faker.random.number({
                min: 0,
                max: 365
            }),
            "by_months": faker.random.number({
                min: 0,
                max: 3
            })
        };
    };

    let phoneNumbers = ['9742998737', '9916586068', '8884828596', '9491989743', '8861119199', '874299837', '816586068', '7884828596', '7491989743', '5861119199'];

    this.getFakerPerson = function() {
        return {
            "first_name": faker.name.firstName(),
            "last_name": faker.name.lastName(),
            "gender": faker.random.arrayElement(['M', 'F']),
            "address_1": faker.address.streetName(),
            "address_2": faker.address.streetAddress(),
            "city": faker.address.city(),
            "state": faker.address.state(),
            "zip": faker.address.zipCode(),
            "country": faker.address.country(),
            "comments": ""
        };
    };

    this.getFakerCustomerConfig = function() {
        return {
            "company_name": faker.company.companyName(),
            "account_number": faker.random.number(),
            "email": faker.internet.email(),
            "phone_number": faker.phone.phoneNumber(),
            "loyalty": faker.random.arrayElement([0, 1])
        };
    };
    this.getFakerStockLoaction = function() {
        return {
            location_id: 1,
            location_name: faker.company.companyName()
        };

    };

    function setDefaultPermission(role, revokePermission) {
        if (revokePermission) {
            role.allowNone = true;
            role.viewOnMenu = true;
            role.allowAll = false;
            return;
        }
        role.allowNone = false;
        role.viewOnMenu = true;
        role.allowAll = true;
        return;
    }

    function enableAllEntitlements(allUserEntitlements) {
        for (var role in allUserEntitlements) {
            setDefaultPermission(allUserEntitlements[role], false);
            for (var grant in allUserEntitlements[role]) {
                if (typeof allUserEntitlements[role][grant].allowed !== 'undefined') {
                    allUserEntitlements[role][grant].allowed = true;
                }
            }
        }
    }

    this.getFakerExpressUserCouchEmployee = function(appName) {
        appName = appName ? appName : process.env.APP_TYPE;
        var phpServerEmployee = _self.getFakerEmployee();
        phpServerEmployee.name = phpServerEmployee.username;
        delete phpServerEmployee.username;
        phpServerEmployee.roles = [];
        var userEntitlements = allUserEntitlements;
        enableAllEntitlements(userEntitlements);

        if (userEntitlements.appSpecific && userEntitlements.appSpecific[appName]) {
            var appSepecificEntitlements = userEntitlements.appSpecific[appName];
            delete userEntitlements.appSpecific;
            //entitlementsFormatted = userEntitlements;
            for (var entitlement in appSepecificEntitlements) {
                userEntitlements[entitlement] = appSepecificEntitlements[entitlement]
            }

        }
        phpServerEmployee.roles.push(JSON.stringify(userEntitlements));
        phpServerEmployee.roles.push('admin');
        phpServerEmployee.profile = 'adminProfile';
        return phpServerEmployee;
    };

    this.getFakerPhpAndExpressUserCouchEmployee = function() {

        var phpServerEmployee = _self.getFakerEmployee();
        phpServerEmployee.grants = _self.getAllGrantsOrRoles();
        //IMP
        phpServerEmployee['myPermissions[]'] = phpServerEmployee.grants;
        phpServerEmployee.name = phpServerEmployee.username;
        //  delete phpServerEmployee.username;
        phpServerEmployee.roles = _self.getAllGrantsOrRoles();
        phpServerEmployee.roles.push('admin');
        return phpServerEmployee;
    };

    this.getFakerNewUserOrEmployee = function() {
        var phpServerEmployee = _self.getFakerEmployee();
        phpServerEmployee.grants = _self.getAllGrantsOrRoles();
        return phpServerEmployee;
    };

    this.getAllGrantsOrRoles = function() {
        return ['reports_customers',
            'reports_receivings',
            'reports_items',
            'reports_inventory',
            'reports_employees',
            'reports_suppliers',
            'reports_sales',
            'reports_discounts',
            'reports_taxes',
            'reports_categories',
            'reports_payments',
            'customers',
            'create_customers',
            'edit_customers',
            'view_customers',
            'delete_customers',
            'employees',
            'employees_create',
            'employees_edit',
            'employees_view',
            'employees_delete',
            'giftcards',
            'giftcards_create',
            'giftcards_edit',
            'giftcards_view',
            'giftcards_delete',
            'items',
            'items_create',
            'items_edit',
            'items_view',
            'items_delete',
            'item_kits',
            'item_kits_create',
            'item_kits_edit',
            'item_kits_view',
            'item_kits_delete',
            'receivings',
            'reports',
            'sales',
            'config',
            'items_stock',
            'sales_stock',
            'receivings_stock',
            'loyalty',
            'homedelivery',
            'takeAway',
            'restaurant',
            'orderCounter',
            'paymentCounter',
            'editKot',
            'Reservation',
            'createTable',
            'home',
            'suppliers',
            'suppliers_create',
            'suppliers_edit',
            'suppliers_view',
            'suppliers_delete',
            'placeorder'
        ];
    };
    this.getFakerEmployee = function() {
        var firstName = faker.name.firstName();
        return {
            "person_id": "",
            "username": firstName,
            "password": firstName,
            "password_again": firstName,
            "first_name": firstName,
            "last_name": faker.name.lastName(),
            "gender": "",
            "email": faker.internet.email(),
            "phone_number": faker.phone.phoneNumber(),
            "address_1": faker.address.streetName(),
            "address_2": faker.address.streetAddress(),
            "city": faker.address.city(),
            "state": faker.address.state(),
            "zip": faker.address.zipCode(),
            "country": faker.address.country(),
            "comments": ""
        };
    };

    this.getFakerSupplier = function() {
        return {
            "type": 'supplier_',
            "company_name": faker.company.companyName(),
            "agency_name": faker.company.companyName(),
            "first_name": faker.name.firstName(),
            "last_name": faker.name.lastName(),
            "gender": "",
            "email": faker.internet.email(),
            "phone_number": faker.phone.phoneNumber(),
            "address_1": faker.address.streetName(),
            "address_2": faker.address.streetAddress(),
            "city": faker.address.city(),
            "state": faker.address.state(),
            "zip": faker.address.zipCode(),
            "country": faker.address.country(),
            "comments": "",
            "account_number": faker.finance.account(),
            "allow_credit": true,
            "credit_balance": 100
        };
    };

    this.getFakerGiftcard = function() {
        return {
            giftcardvalue: (faker.random.number({
                min: 0,
                max: 20
            })) * 500
        };
    };

    this.getFakerCategory = function() {
        var data = {
            name: faker.random.word()
        };

        var bDescription = faker.random.arrayElement([false, true]);
        if (bDescription) {
            data.description = faker.lorem.word();
        }

        return data;
    };

    this.getFakerBrand = function() {
        var data = {
            name: faker.random.word()
        };

        var bDescription = faker.random.arrayElement([false, true]);
        if (bDescription) {
            data.description = faker.lorem.word();
        }

        return data;
    };

    this.getFakerDiscount = function() {
        var data = {
            discount: faker.random.number({
                min: 0,
                max: 100
            }),
            name: faker.random.word()
        };

        var bRandom = faker.random.arrayElement([false, true]);
        if (bRandom) {
            data.expiry = faker.date.future().toString();
        }

        bRandom = faker.random.arrayElement([false, true]);
        if (bRandom) {
            data.maxUnits = faker.random.number({
                min: 0,
                max: 1000
            });
        }

        return data;
    };

    this.getFakerUnit = function() {
        var data = {
            name: faker.random.word(),
            shortName: faker.random.word()
        };

        var bDescription = faker.random.arrayElement([false, true]);
        if (bDescription) {
            data.description = faker.lorem.word();
        }

        return data;
    };

    let allTaxes = [];
    this.getFakerTax = function() {
        if (allTaxes.length === 0) {
            allTaxes = ['VAT', 'GST', 'Cess'];
        }
        var data = {
            name: allTaxes.shift()
        };

        let max = 5;
        let min = 0;
        if (data.name === 'GST') {
            max = 29;
        } else if (data.name === 'VAT') {
            min = 5;
            max = 15;
        }

        data.percent = faker.random.number({
            min: min,
            max: max
        });

        return data;
    };

    this.getFakerLoyalty = function() {
        var data = {
            percent: faker.random.number({
                min: 0,
                max: 100
            }),
            name: faker.random.word()
        };

        return data;
    };

    this.getFakeLoyaltyDoc = function() {
        return {
            "startDate": "Tue May 08 2018 13:07:20 GMT+0530 (IST)",
            "pointRuleArray": [{
                    "min": 0,
                    "max": 1000,
                    "amount": 10,
                    "point": 1
                },
                {
                    "min": 1000,
                    "max": 2000,
                    "amount": 10,
                    "point": 1
                },
                {
                    "min": 2000,
                    "max": 99999999999999999999999999999,
                    "amount": 10,
                    "point": 1
                }
            ],
            "redeemRule": {
                "point": 1,
                "amount": 10
            },
            "earnOnCredit": false,
            "name": "sale loyalty",
            "endDate": null,
            "description": "desc",
            "isActive": true
        };
    }

};

module.exports = new profitGuruFakerElementsData();