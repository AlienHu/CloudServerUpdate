var jsonDiff = require('deep-diff');

var compareNodeVsPhpResults = function() {

    this.compareCommonSalesResponse = function(phpResponse, nodeResponse) {

        //converting PHP side strings to numbers/floats
        phpResponse.stock_location = parseInt(phpResponse.stock_location);
        phpResponse.subtotal = parseFloat(phpResponse.subtotal);
        phpResponse.tax_exclusive_subtotal = parseFloat(phpResponse.tax_exclusive_subtotal);
        phpResponse.discount = parseFloat(phpResponse.discount);
        phpResponse.total = parseFloat(phpResponse.total);
        phpResponse.payments_total = parseFloat(phpResponse.payments_total);
        phpResponse.amount_due = parseFloat(phpResponse.amount_due);
        //As of now ignoring following properties from responses

        function prefilter(path, key) {
            return (['cart', 'payments', 'taxes', 'taxesArray', 'items_module_allowed', 'stock_locations', 'invoice_number', 'warning'].indexOf(key) >= 0);
        }
        return jsonDiff(phpResponse, nodeResponse, prefilter);

    };

    this.compareSingleCartItemTax = function(phpItemTaxes, nodeItemTaxes) {
        phpItemTaxes.forEach(function(tax, index) {
            tax.percent = +parseFloat(tax.percent).toFixed(2);
            tax.Amt = +parseFloat(tax.Amt).toFixed(2);
            phpItemTaxes[index] = tax;
        });

        function prefilter(path, key) {
            return (['item_id'].indexOf(key) >= 0);
        }
        return jsonDiff(phpItemTaxes, nodeItemTaxes, prefilter);
    };

    this.compareSalesCarts = function(phpCart, nodeCart) {

        phpCart.in_stock = parseInt(phpCart.in_stock);
        phpCart.item_id = parseInt(phpCart.item_id);
        phpCart.item_location = parseInt(phpCart.item_location);

        phpCart.discounted_total = +parseFloat(phpCart.discounted_total).toFixed(2);
        phpCart.discounted_price = +parseFloat(phpCart.discounted_price).toFixed(2);
        phpCart.discount = +parseFloat(phpCart.discount).toFixed(2);
        phpCart.loyaltyPerc = +parseFloat(phpCart.loyaltyPerc).toFixed(2);

        phpCart.price = +parseFloat(phpCart.price).toFixed(2);
        phpCart.total = +parseFloat(phpCart.total).toFixed(2);

        function prefilter(path, key) {
            return (['itemTaxList', 'reorder_level', 'cost_price', 'allow_alt_description', 'is_serialized', 'stock_name'].indexOf(key) >= 0);
        }
        return jsonDiff(phpCart, nodeCart, prefilter);
    };

    this.comparePayments = function(phpCart, nodeCart) {
        var phpPayments = phpCart.payments;
        var nodePayments = nodeCart.payments[0];

        function prefilter(path, key) {
            return ([''].indexOf(key) >= 0);
        }
        return jsonDiff(phpPayments, nodePayments);
    };

    this.completeSaleComparePayments = function(phpCart, nodeCart) {
        var phpPayments = phpCart.payments['Cash'];
        phpPayments.payment_amount = parseFloat(phpPayments.payment_amount);

        var nodePayments = nodeCart.payments[0];

        return jsonDiff(phpPayments, nodePayments);
    };
};
module.exports = new compareNodeVsPhpResults();