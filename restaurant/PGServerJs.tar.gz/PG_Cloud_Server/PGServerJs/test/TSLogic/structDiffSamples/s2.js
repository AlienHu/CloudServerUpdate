"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    "cart": [
        {
            "item_id": 2,
            "batchId": "",
            "ItemType": "Prepared",
            "stockKey": "id_2_batch_1520301187370",
            "item_location": 1,
            "stock_name": "India",
            "line": 1,
            "name": "Intelligent Plastic Hat",
            "item_number": 34847,
            "description": "generate",
            "serialnumber": "",
            "imeiNumbers": [],
            "is_serialized": false,
            "hasBatchNumber": false,
            "bOTG": false,
            "hsn": 89755,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Tue Jul 03 2018 14:52:56 GMT+0530 (India Standard Time)",
            "unit": "Nos",
            "unitDocs": {
                "1520301177350": {
                    "_id": "unit_1520301177350",
                    "_rev": "1-a19f05f50c33ee41ce5abd84122813d8",
                    "name": "Nos",
                    "description": "Unit",
                    "id": 1520301177350
                },
                "1520301177484": {
                    "_id": "unit_1520301177484",
                    "_rev": "1-6688af2c199a5dcf8114f6f86990c7d6",
                    "name": "Kg",
                    "description": "Kilograms",
                    "shortName": "kgs",
                    "id": 1520301177484
                },
                "1520301178588": {
                    "_id": "unit_1520301178588",
                    "_rev": "1-2a91800d4202984810797be1ca62f8ea",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1520301178588
                }
            },
            "unitId": "1520301177350",
            "baseUnitId": "1520301178588",
            "quantity": 7,
            "discount": 19,
            "price": 1100.33,
            "baseUnitPrice": 5.50165,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 17,
            "totalPurchaseTaxPercent": 5,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 196,
            "imeiCount": 0,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1520301177350": {
                    "refUnitId": 1520301177484,
                    "factor": 10,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 1100.33,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 1110.33,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 1120.33,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                },
                "1520301177484": {
                    "refUnitId": 1520301178588,
                    "factor": 20,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 110.03299999999999,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 111.03299999999999,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 112.03299999999999,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 100.077,
                    "mrp": 120.05499999999999
                },
                "1520301178588": {
                    "refUnitId": 1520301178588,
                    "factor": 1,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 5.50165,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 5.5516499999999995,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 5.601649999999999,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 5.00385,
                    "mrp": 6.00275
                }
            },
            "itemTaxList": [
                {
                    "name": "CGST",
                    "percent": 8.5,
                    "Amt": 530.3040435
                },
                {
                    "name": "SGST",
                    "percent": 8.5,
                    "Amt": 530.3040435
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1520301175337,
                    "taxInfo": {
                        "_id": "tax_1520301175337",
                        "_rev": "1-8b2b00e3175d1fb53e679c14ea502898",
                        "name": "GST",
                        "percent": 5,
                        "id": 1520301175337
                    }
                }
            ],
            "slab": {
                "_id": "slab_1520301181450",
                "_rev": "1-c60f818294dc30bd4a3669f6f85de70c",
                "name": "calculate",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 17
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 28
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 22
                    }
                ],
                "id": 1520301181450
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 50.038500000000006,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 7702.3099999999995,
            "discounted_total": 6238.871099999999,
            "discounted_price": 1463.4388999999999,
            "totalAfterDisAndCharges": 6238.871099999999,
            "totalWithTax": 7299.479187
        },
        {
            "item_id": 1,
            "batchId": "p",
            "ItemType": "Normal",
            "stockKey": "id_1_batch_p_1_0_2_0_3_0",
            "item_location": 1,
            "stock_name": "India",
            "line": 2,
            "name": "Licensed Cotton Hat",
            "item_number": 36820,
            "description": "Officer",
            "serialnumber": "e8fe8d7a-f627-496b-9992-7011daa8e5cf",
            "imeiNumbers": [
                860398679948411,
                241311203152872,
                513080394756980
            ],
            "is_serialized": true,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 70708,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Sat Aug 04 2018 22:04:35 GMT+0530 (India Standard Time)",
            "unit": "gms",
            "unitDocs": {
                "1520301178588": {
                    "_id": "unit_1520301178588",
                    "_rev": "1-2a91800d4202984810797be1ca62f8ea",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1520301178588
                }
            },
            "unitId": "1520301178588",
            "baseUnitId": "1520301178588",
            "quantity": 1,
            "discount": 19,
            "price": 10000,
            "baseUnitPrice": 10000,
            "sellingPriceExcludingTax": 10000,
            "totalTaxPercent": 44,
            "totalPurchaseTaxPercent": 43,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 21,
            "imeiCount": 3,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1520301178588": {
                    "refUnitId": 1520301178588,
                    "factor": 1,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 1100.33,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                }
            },
            "attributeInfo": {
                "1": 0,
                "2": 0,
                "3": 0
            },
            "itemTaxList": [
                {
                    "name": "VAT",
                    "percent": 15,
                    "Amt": 1215
                },
                {
                    "name": "CGST",
                    "percent": 14.5,
                    "Amt": 1174.5
                },
                {
                    "name": "SGST",
                    "percent": 14.5,
                    "Amt": 1174.5
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1520301175337,
                    "taxInfo": {
                        "_id": "tax_1520301175337",
                        "_rev": "1-8b2b00e3175d1fb53e679c14ea502898",
                        "name": "GST",
                        "percent": 5,
                        "id": 1520301175337
                    }
                },
                {
                    "taxId": 1520301180589,
                    "taxInfo": {
                        "_id": "tax_1520301180589",
                        "_rev": "1-ca241e46cb4dc9819dfcba48dbed7536",
                        "name": "VAT",
                        "percent": 15,
                        "id": 1520301180589
                    }
                }
            ],
            "slab": {
                "_id": "slab_1520301181361",
                "_rev": "1-b286b500831737735620c8b6fa632de2",
                "name": "Bahraini Dinar",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 18
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 23
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 29
                    }
                ],
                "id": 1520301181361
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 430.3311,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 10000,
            "discounted_total": 8100,
            "discounted_price": 1900,
            "totalAfterDisAndCharges": 8100,
            "totalWithTax": 11664
        },
        {
            "item_id": 1,
            "batchId": "1",
            "ItemType": "Normal",
            "stockKey": "id_1_batch_1_1_1_2_1_3_1",
            "item_location": 1,
            "stock_name": "India",
            "line": 3,
            "name": "Licensed Cotton Hat",
            "item_number": 36820,
            "description": "Officer",
            "serialnumber": "d9c7a83f-08fb-475a-93a3-d14ce7257ae5",
            "imeiNumbers": [
                516845627175644,
                597768707154318,
                277635084325447
            ],
            "is_serialized": true,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 70708,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Sun Apr 08 2018 05:18:14 GMT+0530 (India Standard Time)",
            "unit": "gms",
            "unitDocs": {
                "1520301178588": {
                    "_id": "unit_1520301178588",
                    "_rev": "1-2a91800d4202984810797be1ca62f8ea",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1520301178588
                }
            },
            "unitId": "1520301178588",
            "baseUnitId": "1520301178588",
            "quantity": 1,
            "discount": 19,
            "price": 10,
            "baseUnitPrice": 10,
            "sellingPriceExcludingTax": 10,
            "totalTaxPercent": 33,
            "totalPurchaseTaxPercent": 43,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 21,
            "imeiCount": 3,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1520301178588": {
                    "refUnitId": 1520301178588,
                    "factor": 1,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 1100.33,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                }
            },
            "attributeInfo": {
                "1": 1,
                "2": 1,
                "3": 1
            },
            "itemTaxList": [
                {
                    "name": "VAT",
                    "percent": 15,
                    "Amt": 1.2149999999999999
                },
                {
                    "name": "CGST",
                    "percent": 9,
                    "Amt": 0.729
                },
                {
                    "name": "SGST",
                    "percent": 9,
                    "Amt": 0.729
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1520301175337,
                    "taxInfo": {
                        "_id": "tax_1520301175337",
                        "_rev": "1-8b2b00e3175d1fb53e679c14ea502898",
                        "name": "GST",
                        "percent": 5,
                        "id": 1520301175337
                    }
                },
                {
                    "taxId": 1520301180589,
                    "taxInfo": {
                        "_id": "tax_1520301180589",
                        "_rev": "1-ca241e46cb4dc9819dfcba48dbed7536",
                        "name": "VAT",
                        "percent": 15,
                        "id": 1520301180589
                    }
                }
            ],
            "slab": {
                "_id": "slab_1520301181361",
                "_rev": "1-b286b500831737735620c8b6fa632de2",
                "name": "Bahraini Dinar",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 18
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 23
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 29
                    }
                ],
                "id": 1520301181361
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 430.3311,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 10,
            "discounted_total": 8.1,
            "discounted_price": 1.9000000000000001,
            "totalAfterDisAndCharges": 8.1,
            "totalWithTax": 10.772999999999998
        },
        {
            "item_id": 1,
            "batchId": "1",
            "ItemType": "Normal",
            "stockKey": "id_1_batch_1_1_1_2_1_3_1",
            "item_location": 1,
            "stock_name": "India",
            "line": 4,
            "name": "Licensed Cotton Hat",
            "item_number": 36820,
            "description": "Officer",
            "serialnumber": "9e6832fb-9cc0-4cc7-9b78-76395be77cd8",
            "imeiNumbers": [
                282356241368688,
                634303163317963,
                972203137050382
            ],
            "is_serialized": true,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 70708,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Sun Apr 08 2018 05:18:14 GMT+0530 (India Standard Time)",
            "unit": "gms",
            "unitDocs": {
                "1520301178588": {
                    "_id": "unit_1520301178588",
                    "_rev": "1-2a91800d4202984810797be1ca62f8ea",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1520301178588
                }
            },
            "unitId": "1520301178588",
            "baseUnitId": "1520301178588",
            "quantity": 1,
            "discount": 19,
            "price": 1100.33,
            "baseUnitPrice": 1100.33,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 38,
            "totalPurchaseTaxPercent": 43,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 21,
            "imeiCount": 3,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1520301178588": {
                    "refUnitId": 1520301178588,
                    "factor": 1,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 1100.33,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                }
            },
            "attributeInfo": {
                "1": 1,
                "2": 1,
                "3": 1
            },
            "itemTaxList": [
                {
                    "name": "VAT",
                    "percent": 15,
                    "Amt": 133.69009499999999
                },
                {
                    "name": "CGST",
                    "percent": 11.5,
                    "Amt": 102.4957395
                },
                {
                    "name": "SGST",
                    "percent": 11.5,
                    "Amt": 102.4957395
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1520301175337,
                    "taxInfo": {
                        "_id": "tax_1520301175337",
                        "_rev": "1-8b2b00e3175d1fb53e679c14ea502898",
                        "name": "GST",
                        "percent": 5,
                        "id": 1520301175337
                    }
                },
                {
                    "taxId": 1520301180589,
                    "taxInfo": {
                        "_id": "tax_1520301180589",
                        "_rev": "1-ca241e46cb4dc9819dfcba48dbed7536",
                        "name": "VAT",
                        "percent": 15,
                        "id": 1520301180589
                    }
                }
            ],
            "slab": {
                "_id": "slab_1520301181361",
                "_rev": "1-b286b500831737735620c8b6fa632de2",
                "name": "Bahraini Dinar",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 18
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 23
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 29
                    }
                ],
                "id": 1520301181361
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 430.3311,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 1100.33,
            "discounted_total": 891.2673,
            "discounted_price": 209.06269999999998,
            "totalAfterDisAndCharges": 891.2673,
            "totalWithTax": 1229.9488739999997
        },
        {
            "item_id": 1,
            "batchId": "k",
            "ItemType": "Normal",
            "stockKey": "id_1_batch_k_1_2_2_2_3_2",
            "item_location": 1,
            "stock_name": "India",
            "line": 5,
            "name": "Licensed Cotton Hat",
            "item_number": 36820,
            "description": "Officer",
            "serialnumber": "6093fa31-8c3b-48b9-af43-5ad2815115aa",
            "imeiNumbers": [
                294176197960041,
                114149469998665,
                139781091432087
            ],
            "is_serialized": true,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 70708,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Thu Jun 14 2018 14:43:08 GMT+0530 (India Standard Time)",
            "unit": "gms",
            "unitDocs": {
                "1520301178588": {
                    "_id": "unit_1520301178588",
                    "_rev": "1-2a91800d4202984810797be1ca62f8ea",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1520301178588
                }
            },
            "unitId": "1520301178588",
            "baseUnitId": "1520301178588",
            "quantity": 1,
            "discount": 19,
            "price": 1100.33,
            "baseUnitPrice": 1100.33,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 38,
            "totalPurchaseTaxPercent": 43,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 21,
            "imeiCount": 3,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1520301178588": {
                    "refUnitId": 1520301178588,
                    "factor": 1,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 1100.33,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                }
            },
            "attributeInfo": {
                "1": 2,
                "2": 2,
                "3": 2
            },
            "itemTaxList": [
                {
                    "name": "VAT",
                    "percent": 15,
                    "Amt": 133.69009499999999
                },
                {
                    "name": "CGST",
                    "percent": 11.5,
                    "Amt": 102.4957395
                },
                {
                    "name": "SGST",
                    "percent": 11.5,
                    "Amt": 102.4957395
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1520301175337,
                    "taxInfo": {
                        "_id": "tax_1520301175337",
                        "_rev": "1-8b2b00e3175d1fb53e679c14ea502898",
                        "name": "GST",
                        "percent": 5,
                        "id": 1520301175337
                    }
                },
                {
                    "taxId": 1520301180589,
                    "taxInfo": {
                        "_id": "tax_1520301180589",
                        "_rev": "1-ca241e46cb4dc9819dfcba48dbed7536",
                        "name": "VAT",
                        "percent": 15,
                        "id": 1520301180589
                    }
                }
            ],
            "slab": {
                "_id": "slab_1520301181361",
                "_rev": "1-b286b500831737735620c8b6fa632de2",
                "name": "Bahraini Dinar",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 18
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 23
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 29
                    }
                ],
                "id": 1520301181361
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 430.3311,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 1100.33,
            "discounted_total": 891.2673,
            "discounted_price": 209.06269999999998,
            "totalAfterDisAndCharges": 891.2673,
            "totalWithTax": 1229.9488739999997
        },
        {
            "item_id": 3,
            "batchId": "3",
            "ItemType": "Liquor",
            "stockKey": "id_3_batch_3_1_0_2_0_3_0",
            "item_location": 1,
            "stock_name": "India",
            "line": 6,
            "name": "Unbranded Concrete Towels",
            "item_number": 70488,
            "description": "Developer",
            "serialnumber": "",
            "imeiNumbers": [],
            "is_serialized": false,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 69632,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Tue Mar 05 2019 16:47:26 GMT+0530 (India Standard Time)",
            "unit": "Nos",
            "unitDocs": {
                "1520301177350": {
                    "_id": "unit_1520301177350",
                    "_rev": "1-a19f05f50c33ee41ce5abd84122813d8",
                    "name": "Nos",
                    "description": "Unit",
                    "id": 1520301177350
                },
                "1520301177484": {
                    "_id": "unit_1520301177484",
                    "_rev": "1-6688af2c199a5dcf8114f6f86990c7d6",
                    "name": "Kg",
                    "description": "Kilograms",
                    "shortName": "kgs",
                    "id": 1520301177484
                },
                "1520301178588": {
                    "_id": "unit_1520301178588",
                    "_rev": "1-2a91800d4202984810797be1ca62f8ea",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1520301178588
                }
            },
            "unitId": "1520301177350",
            "baseUnitId": "1520301178588",
            "quantity": 6,
            "discount": 19,
            "price": 1100.33,
            "baseUnitPrice": 5.50165,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 5,
            "totalPurchaseTaxPercent": 33,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 47,
            "imeiCount": 0,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1520301177350": {
                    "refUnitId": 1520301177484,
                    "factor": 10,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 1100.33,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 1110.33,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 1120.33,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                },
                "1520301177484": {
                    "refUnitId": 1520301178588,
                    "factor": 20,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 110.03299999999999,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 111.03299999999999,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 112.03299999999999,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 100.077,
                    "mrp": 120.05499999999999
                },
                "1520301178588": {
                    "refUnitId": 1520301178588,
                    "factor": 1,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 5.50165,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 5.5516499999999995,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 5.601649999999999,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 5.00385,
                    "mrp": 6.00275
                }
            },
            "attributeInfo": {
                "1": 0,
                "2": 0,
                "3": 0
            },
            "itemTaxList": [
                {
                    "name": "CGST",
                    "percent": 2.5,
                    "Amt": 133.690095
                },
                {
                    "name": "SGST",
                    "percent": 2.5,
                    "Amt": 133.690095
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1520301175337,
                    "taxInfo": {
                        "_id": "tax_1520301175337",
                        "_rev": "1-8b2b00e3175d1fb53e679c14ea502898",
                        "name": "GST",
                        "percent": 5,
                        "id": 1520301175337
                    }
                }
            ],
            "slab": {
                "_id": "slab_1520301181549",
                "_rev": "1-6ada47de7b568f15fd3019dd4bbcd887",
                "name": "back up",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 5
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 17
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 12
                    }
                ],
                "id": 1520301181549
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 330.2541,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 6601.98,
            "discounted_total": 5347.6038,
            "discounted_price": 1254.3762,
            "totalAfterDisAndCharges": 5347.6038,
            "totalWithTax": 5614.98399
        },
        {
            "item_id": 3,
            "batchId": "1",
            "ItemType": "Liquor",
            "stockKey": "id_3_batch_1_1_1_2_1_3_1",
            "item_location": 1,
            "stock_name": "India",
            "line": 7,
            "name": "Unbranded Concrete Towels",
            "item_number": 70488,
            "description": "Developer",
            "serialnumber": "",
            "imeiNumbers": [],
            "is_serialized": false,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 69632,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Tue Dec 18 2018 07:28:13 GMT+0530 (India Standard Time)",
            "unit": "Nos",
            "unitDocs": {
                "1520301177350": {
                    "_id": "unit_1520301177350",
                    "_rev": "1-a19f05f50c33ee41ce5abd84122813d8",
                    "name": "Nos",
                    "description": "Unit",
                    "id": 1520301177350
                },
                "1520301177484": {
                    "_id": "unit_1520301177484",
                    "_rev": "1-6688af2c199a5dcf8114f6f86990c7d6",
                    "name": "Kg",
                    "description": "Kilograms",
                    "shortName": "kgs",
                    "id": 1520301177484
                },
                "1520301178588": {
                    "_id": "unit_1520301178588",
                    "_rev": "1-2a91800d4202984810797be1ca62f8ea",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1520301178588
                }
            },
            "unitId": "1520301177350",
            "baseUnitId": "1520301178588",
            "quantity": 7,
            "discount": 19,
            "price": 1100.33,
            "baseUnitPrice": 5.50165,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 5,
            "totalPurchaseTaxPercent": 33,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 47,
            "imeiCount": 0,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1520301177350": {
                    "refUnitId": 1520301177484,
                    "factor": 10,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 1100.33,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 1110.33,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 1120.33,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                },
                "1520301177484": {
                    "refUnitId": 1520301178588,
                    "factor": 20,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 110.03299999999999,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 111.03299999999999,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 112.03299999999999,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 100.077,
                    "mrp": 120.05499999999999
                },
                "1520301178588": {
                    "refUnitId": 1520301178588,
                    "factor": 1,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 5.50165,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 5.5516499999999995,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 5.601649999999999,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 5.00385,
                    "mrp": 6.00275
                }
            },
            "attributeInfo": {
                "1": 1,
                "2": 1,
                "3": 1
            },
            "itemTaxList": [
                {
                    "name": "CGST",
                    "percent": 2.5,
                    "Amt": 155.9717775
                },
                {
                    "name": "SGST",
                    "percent": 2.5,
                    "Amt": 155.9717775
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1520301175337,
                    "taxInfo": {
                        "_id": "tax_1520301175337",
                        "_rev": "1-8b2b00e3175d1fb53e679c14ea502898",
                        "name": "GST",
                        "percent": 5,
                        "id": 1520301175337
                    }
                }
            ],
            "slab": {
                "_id": "slab_1520301181549",
                "_rev": "1-6ada47de7b568f15fd3019dd4bbcd887",
                "name": "back up",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 5
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 17
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 12
                    }
                ],
                "id": 1520301181549
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 330.2541,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 7702.3099999999995,
            "discounted_total": 6238.871099999999,
            "discounted_price": 1463.4388999999999,
            "totalAfterDisAndCharges": 6238.871099999999,
            "totalWithTax": 6550.814654999999
        },
        {
            "item_id": 3,
            "batchId": "1",
            "ItemType": "Liquor",
            "stockKey": "id_3_batch_1_1_2_2_2_3_2",
            "item_location": 1,
            "stock_name": "India",
            "line": 8,
            "name": "Unbranded Concrete Towels",
            "item_number": 70488,
            "description": "Developer",
            "serialnumber": "",
            "imeiNumbers": [],
            "is_serialized": false,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 69632,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Sat Nov 24 2018 12:13:01 GMT+0530 (India Standard Time)",
            "unit": "Nos",
            "unitDocs": {
                "1520301177350": {
                    "_id": "unit_1520301177350",
                    "_rev": "1-a19f05f50c33ee41ce5abd84122813d8",
                    "name": "Nos",
                    "description": "Unit",
                    "id": 1520301177350
                },
                "1520301177484": {
                    "_id": "unit_1520301177484",
                    "_rev": "1-6688af2c199a5dcf8114f6f86990c7d6",
                    "name": "Kg",
                    "description": "Kilograms",
                    "shortName": "kgs",
                    "id": 1520301177484
                },
                "1520301178588": {
                    "_id": "unit_1520301178588",
                    "_rev": "1-2a91800d4202984810797be1ca62f8ea",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1520301178588
                }
            },
            "unitId": "1520301177350",
            "baseUnitId": "1520301178588",
            "quantity": 6,
            "discount": 19,
            "price": 1100.33,
            "baseUnitPrice": 5.50165,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 5,
            "totalPurchaseTaxPercent": 33,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 47,
            "imeiCount": 0,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1520301177350": {
                    "refUnitId": 1520301177484,
                    "factor": 10,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 1100.33,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 1110.33,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 1120.33,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                },
                "1520301177484": {
                    "refUnitId": 1520301178588,
                    "factor": 20,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 110.03299999999999,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 111.03299999999999,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 112.03299999999999,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 100.077,
                    "mrp": 120.05499999999999
                },
                "1520301178588": {
                    "refUnitId": 1520301178588,
                    "factor": 1,
                    "pProfilesData": {
                        "1520301176346": {
                            "sellingPrice": 5.50165,
                            "discountId": 1520301180039,
                            "discount": {
                                "_id": "discount_1520301180039",
                                "_rev": "1-c0883f54a1a2fe25a16408acaabbc28f",
                                "discount": 19,
                                "name": "lime",
                                "maxUnits": 383,
                                "id": 1520301180039
                            }
                        },
                        "1520301186151": {
                            "sellingPrice": 5.5516499999999995,
                            "discountId": 1520301180165,
                            "discount": {
                                "_id": "discount_1520301180165",
                                "_rev": "1-c0fe387ad59e44273dc2e7ed7b307b76",
                                "discount": 84,
                                "name": "Fundamental",
                                "expiry": "Sat Jan 12 2019 22:01:06 GMT+0530 (India Standard Time)",
                                "maxUnits": 977,
                                "id": 1520301180165
                            }
                        },
                        "1520301186370": {
                            "sellingPrice": 5.601649999999999,
                            "discountId": 1520301180296,
                            "discount": {
                                "_id": "discount_1520301180296",
                                "_rev": "1-2c1e69be00eb2a283eb88c5ff204eae5",
                                "discount": 42,
                                "name": "deposit",
                                "id": 1520301180296
                            }
                        }
                    },
                    "purchasePrice": 5.00385,
                    "mrp": 6.00275
                }
            },
            "attributeInfo": {
                "1": 2,
                "2": 2,
                "3": 2
            },
            "itemTaxList": [
                {
                    "name": "CGST",
                    "percent": 2.5,
                    "Amt": 133.690095
                },
                {
                    "name": "SGST",
                    "percent": 2.5,
                    "Amt": 133.690095
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1520301175337,
                    "taxInfo": {
                        "_id": "tax_1520301175337",
                        "_rev": "1-8b2b00e3175d1fb53e679c14ea502898",
                        "name": "GST",
                        "percent": 5,
                        "id": 1520301175337
                    }
                }
            ],
            "slab": {
                "_id": "slab_1520301181549",
                "_rev": "1-6ada47de7b568f15fd3019dd4bbcd887",
                "name": "back up",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 5
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 17
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 12
                    }
                ],
                "id": 1520301181549
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 330.2541,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 6601.98,
            "discounted_total": 5347.6038,
            "discounted_price": 1254.3762,
            "totalAfterDisAndCharges": 5347.6038,
            "totalWithTax": 5614.98399
        }
    ],
    "discount": 7755.66,
    "totalNoSpotDiscount": 39214.93,
    "addedRoundOffValue": -0.0025700000041979365,
    "bLocalTax": true,
    "charges": {},
    "taxesWithPercents": {
        "CGST @8.5%": 530.3,
        "SGST @8.5%": 530.3,
        "VAT @15%": 1483.6,
        "CGST @14.5%": 1174.5,
        "SGST @14.5%": 1174.5,
        "CGST @9%": 0.73,
        "SGST @9%": 0.73,
        "CGST @11.5%": 204.99,
        "SGST @11.5%": 204.99,
        "CGST @2.5%": 423.35,
        "SGST @2.5%": 423.35
    },
    "taxDetailed": {
        "9": {
            "taxable": 8.1,
            "CGST": 0.729,
            "SGST": 0.729
        },
        "15": {
            "taxable": 9890.6346,
            "VAT": 1483.5951899999998
        },
        "8.5": {
            "taxable": 6238.871099999999,
            "CGST": 530.3040435,
            "SGST": 530.3040435
        },
        "14.5": {
            "taxable": 8100,
            "CGST": 1174.5,
            "SGST": 1174.5
        },
        "11.5": {
            "taxable": 1782.5346,
            "CGST": 204.991479,
            "SGST": 204.991479
        },
        "2.5": {
            "taxable": 16934.0787,
            "CGST": 423.3519675,
            "SGST": 423.3519675
        }
    },
    "taxNames": {
        "CGST": true,
        "SGST": true,
        "VAT": true
    },
    "hsnTaxes": {
        "69632": {
            "CGST": {
                "2.5": 423.3519675
            },
            "taxable": 16934.0787,
            "SGST": {
                "2.5": 423.3519675
            }
        },
        "70708": {
            "VAT": {
                "15": 1483.5951899999998
            },
            "taxable": 2673.8019,
            "CGST": {
                "9": 0.729,
                "14.5": 1174.5,
                "11.5": 204.991479
            },
            "SGST": {
                "9": 0.729,
                "14.5": 1174.5,
                "11.5": 204.991479
            }
        },
        "89755": {
            "CGST": {
                "8.5": 530.3040435
            },
            "taxable": 6238.871099999999,
            "SGST": {
                "8.5": 530.3040435
            }
        }
    },
    "taxes": {
        "CGST": 2333.88,
        "SGST": 2333.88,
        "VAT": 1483.6
    },
    "total": 39214.93,
    "payments": [
        {
            "payment_type": "Cash",
            "payment_amount": 19607.47
        },
        {
            "payment_type": "Debit Card",
            "payment_amount": 19607.46
        }
    ],
    "saleOnCreditAmt": 0,
    "amount_due": 0,
    "totalQuantity": 30,
    "subtotal": 33063.5844,
    "discounted_subtotal": 33063.5844,
    "totalWithoutTax": 40819.24,
    "tax_exclusive_subtotal": 33063.5844,
    "receipt_title": "Sales Receipt",
    "comments": "hello world",
    "amount_change": 0,
    "employee": "couch admin",
    "company_info": {
        "0": "Bangalore",
        "1": "123456789",
        "3": "AlienHu"
    },
    "company_address": "Bangalore",
    "company_phone": "123456789",
    "company_name": "AlienHu",
    "globalDiscountInfo": {
        "amt": 0,
        "percent": 0,
        "discountMethod": "onTotal"
    },
    "customer_compnay_name": "Gupta - Dubashi",
    "customer": "Eekalabya Iyer",
    "customer_id": 1520301188933,
    "customer_address": "Baladitya Glens",
    "customer_location": "O2G 8W8 Goswameefort",
    "account_number": "64189",
    "phone_number": "+91571-634-7732",
    "customer_info": {
        "0": "Eekalabya Iyer",
        "1": "Baladitya Glens",
        "2": "O2G 8W8 Goswameefort",
        "3": "64189",
        "5": "+91571-634-7732"
    },
    "sale_id": "POS 1",
    "transaction_time": "2018-03-06 07:23:22",
    "transaction_date": "2018-03-06",
    "print_after_sale": false
};
//# sourceMappingURL=s2.js.map