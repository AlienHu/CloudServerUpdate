"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    "cart": [
        {
            "item_id": 2,
            "batchId": "",
            "ItemType": "Prepared",
            "stockKey": "id_2_batch_1519975322394",
            "item_location": 1,
            "stock_name": "India",
            "line": 1,
            "name": "Intelligent Granite Table",
            "item_number": 1994,
            "description": "violet",
            "serialnumber": "",
            "imeiNumbers": [],
            "is_serialized": false,
            "hasBatchNumber": false,
            "bOTG": false,
            "hsn": 28336,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Tue Mar 06 2018 08:59:48 GMT+0530 (India Standard Time)",
            "unit": "Nos",
            "unitDocs": {
                "1519975313128": {
                    "_id": "unit_1519975313128",
                    "_rev": "1-a3539ea09a8fee34729ef243da5c9306",
                    "name": "Nos",
                    "description": "Unit",
                    "id": 1519975313128
                },
                "1519975313242": {
                    "_id": "unit_1519975313242",
                    "_rev": "1-3764aeff750d9075e2e87543b3504c7e",
                    "name": "Kg",
                    "description": "Kilograms",
                    "shortName": "kgs",
                    "id": 1519975313242
                },
                "1519975313344": {
                    "_id": "unit_1519975313344",
                    "_rev": "1-d793f72690c2930b41a15be19f3fa0f7",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1519975313344
                }
            },
            "unitId": "1519975313128",
            "baseUnitId": "1519975313344",
            "quantity": 7,
            "discount": 32,
            "price": 1100.33,
            "baseUnitPrice": 5.50165,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 3,
            "totalPurchaseTaxPercent": 28,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 199,
            "imeiCount": 0,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1519975313128": {
                    "refUnitId": 1519975313242,
                    "factor": 10,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 1100.33,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 1110.33,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 1120.33,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                },
                "1519975313242": {
                    "refUnitId": 1519975313344,
                    "factor": 20,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 110.03299999999999,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 111.03299999999999,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 112.03299999999999,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 100.077,
                    "mrp": 120.05499999999999
                },
                "1519975313344": {
                    "refUnitId": 1519975313344,
                    "factor": 1,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 5.50165,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 5.5516499999999995,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 5.601649999999999,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 5.00385,
                    "mrp": 6.00275
                }
            },
            "itemTaxList": [
                {
                    "name": "CGST",
                    "percent": 1.5,
                    "Amt": 78.56356199999999
                },
                {
                    "name": "SGST",
                    "percent": 1.5,
                    "Amt": 78.56356199999999
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1519975311263,
                    "taxInfo": {
                        "_id": "tax_1519975311263",
                        "_rev": "1-c0f5012ecd9fdedaa93b2ab906050d95",
                        "name": "GST",
                        "percent": 12,
                        "id": 1519975311263
                    }
                }
            ],
            "slab": {
                "_id": "slab_1519975317026",
                "_rev": "1-c571ec6f86120c7d491e38b0b5cfaa34",
                "name": "port",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 3
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 17
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 21
                    }
                ],
                "id": 1519975317026
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 280.2156,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 7702.3099999999995,
            "discounted_total": 5237.5707999999995,
            "discounted_price": 2464.7392,
            "totalAfterDisAndCharges": 5237.5707999999995,
            "totalWithTax": 5394.697924
        },
        {
            "item_id": 1,
            "batchId": "x",
            "ItemType": "Ingredient",
            "stockKey": "id_1_batch_x_1_0_2_0_3_0",
            "item_location": 1,
            "stock_name": "India",
            "line": 2,
            "name": "Practical Wooden Pizza",
            "item_number": 28087,
            "description": "Maharashtra",
            "serialnumber": "18bb7213-4ed7-4765-8cad-faddfd00a326",
            "imeiNumbers": [
                102718166960403
            ],
            "is_serialized": true,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 42041,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Fri Apr 20 2018 10:00:29 GMT+0530 (India Standard Time)",
            "unit": "gms",
            "unitDocs": {
                "1519975313344": {
                    "_id": "unit_1519975313344",
                    "_rev": "1-d793f72690c2930b41a15be19f3fa0f7",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1519975313344
                }
            },
            "unitId": "1519975313344",
            "baseUnitId": "1519975313344",
            "quantity": 1,
            "discount": 32,
            "price": 10000,
            "baseUnitPrice": 10000,
            "sellingPriceExcludingTax": 10000,
            "totalTaxPercent": 34,
            "totalPurchaseTaxPercent": 24,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 36,
            "imeiCount": 1,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1519975313344": {
                    "refUnitId": 1519975313344,
                    "factor": 1,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 1100.33,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                }
            },
            "attributeInfo": {
                "1": 0,
                "2": 0,
                "3": 0
            },
            "itemTaxList": [
                {
                    "name": "VAT",
                    "percent": 6,
                    "Amt": 408
                },
                {
                    "name": "CGST",
                    "percent": 14,
                    "Amt": 952.0000000000001
                },
                {
                    "name": "SGST",
                    "percent": 14,
                    "Amt": 952.0000000000001
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1519975311494,
                    "taxInfo": {
                        "_id": "tax_1519975311494",
                        "_rev": "1-bb9ee947ee9bc31c275ad5d100f192da",
                        "name": "GST",
                        "percent": 28,
                        "id": 1519975311494
                    }
                },
                {
                    "taxId": 1519975316312,
                    "taxInfo": {
                        "_id": "tax_1519975316312",
                        "_rev": "1-3e7d8dbb606728a3f80476bd0fd47dc0",
                        "name": "VAT",
                        "percent": 6,
                        "id": 1519975316312
                    }
                }
            ],
            "slab": {
                "_id": "slab_1519975317124",
                "_rev": "1-06840d9a7fc58c830466d10bb87c8ce7",
                "name": "Keys",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 10
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 24
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 28
                    }
                ],
                "id": 1519975317124
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 240.1848,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 10000,
            "discounted_total": 6800,
            "discounted_price": 3200,
            "totalAfterDisAndCharges": 6800,
            "totalWithTax": 9112
        },
        {
            "item_id": 1,
            "batchId": "d",
            "ItemType": "Ingredient",
            "stockKey": "id_1_batch_d_1_1_2_1_3_1",
            "item_location": 1,
            "stock_name": "India",
            "line": 3,
            "name": "Practical Wooden Pizza",
            "item_number": 28087,
            "description": "Maharashtra",
            "serialnumber": "25990250-8df1-4957-a9f4-152b16ce5a36",
            "imeiNumbers": [
                823843041039072
            ],
            "is_serialized": true,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 42041,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Sun Nov 11 2018 08:38:19 GMT+0530 (India Standard Time)",
            "unit": "gms",
            "unitDocs": {
                "1519975313344": {
                    "_id": "unit_1519975313344",
                    "_rev": "1-d793f72690c2930b41a15be19f3fa0f7",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1519975313344
                }
            },
            "unitId": "1519975313344",
            "baseUnitId": "1519975313344",
            "quantity": 1,
            "discount": 32,
            "price": 10,
            "baseUnitPrice": 10,
            "sellingPriceExcludingTax": 10,
            "totalTaxPercent": 16,
            "totalPurchaseTaxPercent": 24,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 36,
            "imeiCount": 1,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1519975313344": {
                    "refUnitId": 1519975313344,
                    "factor": 1,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 1100.33,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                }
            },
            "attributeInfo": {
                "1": 1,
                "2": 1,
                "3": 1
            },
            "itemTaxList": [
                {
                    "name": "VAT",
                    "percent": 6,
                    "Amt": 0.408
                },
                {
                    "name": "CGST",
                    "percent": 5,
                    "Amt": 0.34
                },
                {
                    "name": "SGST",
                    "percent": 5,
                    "Amt": 0.34
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1519975311494,
                    "taxInfo": {
                        "_id": "tax_1519975311494",
                        "_rev": "1-bb9ee947ee9bc31c275ad5d100f192da",
                        "name": "GST",
                        "percent": 28,
                        "id": 1519975311494
                    }
                },
                {
                    "taxId": 1519975316312,
                    "taxInfo": {
                        "_id": "tax_1519975316312",
                        "_rev": "1-3e7d8dbb606728a3f80476bd0fd47dc0",
                        "name": "VAT",
                        "percent": 6,
                        "id": 1519975316312
                    }
                }
            ],
            "slab": {
                "_id": "slab_1519975317124",
                "_rev": "1-06840d9a7fc58c830466d10bb87c8ce7",
                "name": "Keys",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 10
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 24
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 28
                    }
                ],
                "id": 1519975317124
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 240.1848,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 10,
            "discounted_total": 6.8,
            "discounted_price": 3.2,
            "totalAfterDisAndCharges": 6.8,
            "totalWithTax": 7.888
        },
        {
            "item_id": 1,
            "batchId": "d",
            "ItemType": "Ingredient",
            "stockKey": "id_1_batch_d_1_1_2_1_3_1",
            "item_location": 1,
            "stock_name": "India",
            "line": 4,
            "name": "Practical Wooden Pizza",
            "item_number": 28087,
            "description": "Maharashtra",
            "serialnumber": "be6e46e5-0abc-416d-bede-a0ae5155b11f",
            "imeiNumbers": [
                727139331004582
            ],
            "is_serialized": true,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 42041,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Sun Nov 11 2018 08:38:19 GMT+0530 (India Standard Time)",
            "unit": "gms",
            "unitDocs": {
                "1519975313344": {
                    "_id": "unit_1519975313344",
                    "_rev": "1-d793f72690c2930b41a15be19f3fa0f7",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1519975313344
                }
            },
            "unitId": "1519975313344",
            "baseUnitId": "1519975313344",
            "quantity": 1,
            "discount": 32,
            "price": 1100.33,
            "baseUnitPrice": 1100.33,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 30,
            "totalPurchaseTaxPercent": 24,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 36,
            "imeiCount": 1,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1519975313344": {
                    "refUnitId": 1519975313344,
                    "factor": 1,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 1100.33,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                }
            },
            "attributeInfo": {
                "1": 1,
                "2": 1,
                "3": 1
            },
            "itemTaxList": [
                {
                    "name": "VAT",
                    "percent": 6,
                    "Amt": 44.893463999999994
                },
                {
                    "name": "CGST",
                    "percent": 12,
                    "Amt": 89.78692799999999
                },
                {
                    "name": "SGST",
                    "percent": 12,
                    "Amt": 89.78692799999999
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1519975311494,
                    "taxInfo": {
                        "_id": "tax_1519975311494",
                        "_rev": "1-bb9ee947ee9bc31c275ad5d100f192da",
                        "name": "GST",
                        "percent": 28,
                        "id": 1519975311494
                    }
                },
                {
                    "taxId": 1519975316312,
                    "taxInfo": {
                        "_id": "tax_1519975316312",
                        "_rev": "1-3e7d8dbb606728a3f80476bd0fd47dc0",
                        "name": "VAT",
                        "percent": 6,
                        "id": 1519975316312
                    }
                }
            ],
            "slab": {
                "_id": "slab_1519975317124",
                "_rev": "1-06840d9a7fc58c830466d10bb87c8ce7",
                "name": "Keys",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 10
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 24
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 28
                    }
                ],
                "id": 1519975317124
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 240.1848,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 1100.33,
            "discounted_total": 748.2244,
            "discounted_price": 352.1056,
            "totalAfterDisAndCharges": 748.2244,
            "totalWithTax": 972.6917199999999
        },
        {
            "item_id": 1,
            "batchId": "l",
            "ItemType": "Ingredient",
            "stockKey": "id_1_batch_l_1_2_2_2_3_2",
            "item_location": 1,
            "stock_name": "India",
            "line": 5,
            "name": "Practical Wooden Pizza",
            "item_number": 28087,
            "description": "Maharashtra",
            "serialnumber": "075572fa-6972-412f-87be-a431b7ad77aa",
            "imeiNumbers": [
                144921235716901
            ],
            "is_serialized": true,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 42041,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Sun Dec 23 2018 01:31:36 GMT+0530 (India Standard Time)",
            "unit": "gms",
            "unitDocs": {
                "1519975313344": {
                    "_id": "unit_1519975313344",
                    "_rev": "1-d793f72690c2930b41a15be19f3fa0f7",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1519975313344
                }
            },
            "unitId": "1519975313344",
            "baseUnitId": "1519975313344",
            "quantity": 1,
            "discount": 32,
            "price": 1100.33,
            "baseUnitPrice": 1100.33,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 30,
            "totalPurchaseTaxPercent": 24,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 36,
            "imeiCount": 1,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1519975313344": {
                    "refUnitId": 1519975313344,
                    "factor": 1,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 1100.33,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                }
            },
            "attributeInfo": {
                "1": 2,
                "2": 2,
                "3": 2
            },
            "itemTaxList": [
                {
                    "name": "VAT",
                    "percent": 6,
                    "Amt": 44.893463999999994
                },
                {
                    "name": "CGST",
                    "percent": 12,
                    "Amt": 89.78692799999999
                },
                {
                    "name": "SGST",
                    "percent": 12,
                    "Amt": 89.78692799999999
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1519975311494,
                    "taxInfo": {
                        "_id": "tax_1519975311494",
                        "_rev": "1-bb9ee947ee9bc31c275ad5d100f192da",
                        "name": "GST",
                        "percent": 28,
                        "id": 1519975311494
                    }
                },
                {
                    "taxId": 1519975316312,
                    "taxInfo": {
                        "_id": "tax_1519975316312",
                        "_rev": "1-3e7d8dbb606728a3f80476bd0fd47dc0",
                        "name": "VAT",
                        "percent": 6,
                        "id": 1519975316312
                    }
                }
            ],
            "slab": {
                "_id": "slab_1519975317124",
                "_rev": "1-06840d9a7fc58c830466d10bb87c8ce7",
                "name": "Keys",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 10
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 24
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 28
                    }
                ],
                "id": 1519975317124
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 240.1848,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 1100.33,
            "discounted_total": 748.2244,
            "discounted_price": 352.1056,
            "totalAfterDisAndCharges": 748.2244,
            "totalWithTax": 972.6917199999999
        },
        {
            "item_id": 3,
            "batchId": "y",
            "ItemType": "Prepared",
            "stockKey": "id_3_batch_y_1_0_2_0_3_0",
            "item_location": 1,
            "stock_name": "India",
            "line": 6,
            "name": "Small Plastic Car",
            "item_number": 36946,
            "description": "Island",
            "serialnumber": "",
            "imeiNumbers": [],
            "is_serialized": false,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 67683,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Tue Oct 09 2018 01:22:50 GMT+0530 (India Standard Time)",
            "unit": "Nos",
            "unitDocs": {
                "1519975313128": {
                    "_id": "unit_1519975313128",
                    "_rev": "1-a3539ea09a8fee34729ef243da5c9306",
                    "name": "Nos",
                    "description": "Unit",
                    "id": 1519975313128
                },
                "1519975313242": {
                    "_id": "unit_1519975313242",
                    "_rev": "1-3764aeff750d9075e2e87543b3504c7e",
                    "name": "Kg",
                    "description": "Kilograms",
                    "shortName": "kgs",
                    "id": 1519975313242
                },
                "1519975313344": {
                    "_id": "unit_1519975313344",
                    "_rev": "1-d793f72690c2930b41a15be19f3fa0f7",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1519975313344
                }
            },
            "unitId": "1519975313128",
            "baseUnitId": "1519975313344",
            "quantity": 6,
            "discount": 32,
            "price": 1100.33,
            "baseUnitPrice": 5.50165,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 40,
            "totalPurchaseTaxPercent": 10,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 81,
            "imeiCount": 0,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1519975313128": {
                    "refUnitId": 1519975313242,
                    "factor": 10,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 1100.33,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 1110.33,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 1120.33,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                },
                "1519975313242": {
                    "refUnitId": 1519975313344,
                    "factor": 20,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 110.03299999999999,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 111.03299999999999,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 112.03299999999999,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 100.077,
                    "mrp": 120.05499999999999
                },
                "1519975313344": {
                    "refUnitId": 1519975313344,
                    "factor": 1,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 5.50165,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 5.5516499999999995,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 5.601649999999999,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 5.00385,
                    "mrp": 6.00275
                }
            },
            "attributeInfo": {
                "1": 0,
                "2": 0,
                "3": 0
            },
            "itemTaxList": [
                {
                    "name": "VAT",
                    "percent": 14,
                    "Amt": 628.508496
                },
                {
                    "name": "CGST",
                    "percent": 13,
                    "Amt": 583.6150319999999
                },
                {
                    "name": "SGST",
                    "percent": 13,
                    "Amt": 583.6150319999999
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1519975311099,
                    "taxInfo": {
                        "_id": "tax_1519975311099",
                        "_rev": "1-db8e12fed13ac9dc1d45d02cfbbb7ac2",
                        "name": "GST",
                        "percent": 5,
                        "id": 1519975311099
                    }
                },
                {
                    "taxId": 1519975316618,
                    "taxInfo": {
                        "_id": "tax_1519975316618",
                        "_rev": "1-ff42b4a950f4570ac02a62461ba4ce65",
                        "name": "VAT",
                        "percent": 14,
                        "id": 1519975316618
                    }
                }
            ],
            "slab": {
                "_id": "slab_1519975316922",
                "_rev": "1-56124fedb9eb082dfb60bf820fcec581",
                "name": "Supervisor",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 26
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 17
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 24
                    }
                ],
                "id": 1519975316922
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 100.07700000000001,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 6601.98,
            "discounted_total": 4489.346399999999,
            "discounted_price": 2112.6336,
            "totalAfterDisAndCharges": 4489.346399999999,
            "totalWithTax": 6285.084959999999
        },
        {
            "item_id": 3,
            "batchId": "u",
            "ItemType": "Prepared",
            "stockKey": "id_3_batch_u_1_1_2_1_3_1",
            "item_location": 1,
            "stock_name": "India",
            "line": 7,
            "name": "Small Plastic Car",
            "item_number": 36946,
            "description": "Island",
            "serialnumber": "",
            "imeiNumbers": [],
            "is_serialized": false,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 67683,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Tue Jul 24 2018 12:10:44 GMT+0530 (India Standard Time)",
            "unit": "Nos",
            "unitDocs": {
                "1519975313128": {
                    "_id": "unit_1519975313128",
                    "_rev": "1-a3539ea09a8fee34729ef243da5c9306",
                    "name": "Nos",
                    "description": "Unit",
                    "id": 1519975313128
                },
                "1519975313242": {
                    "_id": "unit_1519975313242",
                    "_rev": "1-3764aeff750d9075e2e87543b3504c7e",
                    "name": "Kg",
                    "description": "Kilograms",
                    "shortName": "kgs",
                    "id": 1519975313242
                },
                "1519975313344": {
                    "_id": "unit_1519975313344",
                    "_rev": "1-d793f72690c2930b41a15be19f3fa0f7",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1519975313344
                }
            },
            "unitId": "1519975313128",
            "baseUnitId": "1519975313344",
            "quantity": 7,
            "discount": 32,
            "price": 1100.33,
            "baseUnitPrice": 5.50165,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 40,
            "totalPurchaseTaxPercent": 10,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 81,
            "imeiCount": 0,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1519975313128": {
                    "refUnitId": 1519975313242,
                    "factor": 10,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 1100.33,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 1110.33,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 1120.33,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                },
                "1519975313242": {
                    "refUnitId": 1519975313344,
                    "factor": 20,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 110.03299999999999,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 111.03299999999999,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 112.03299999999999,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 100.077,
                    "mrp": 120.05499999999999
                },
                "1519975313344": {
                    "refUnitId": 1519975313344,
                    "factor": 1,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 5.50165,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 5.5516499999999995,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 5.601649999999999,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 5.00385,
                    "mrp": 6.00275
                }
            },
            "attributeInfo": {
                "1": 1,
                "2": 1,
                "3": 1
            },
            "itemTaxList": [
                {
                    "name": "VAT",
                    "percent": 14,
                    "Amt": 733.259912
                },
                {
                    "name": "CGST",
                    "percent": 13,
                    "Amt": 680.884204
                },
                {
                    "name": "SGST",
                    "percent": 13,
                    "Amt": 680.884204
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1519975311099,
                    "taxInfo": {
                        "_id": "tax_1519975311099",
                        "_rev": "1-db8e12fed13ac9dc1d45d02cfbbb7ac2",
                        "name": "GST",
                        "percent": 5,
                        "id": 1519975311099
                    }
                },
                {
                    "taxId": 1519975316618,
                    "taxInfo": {
                        "_id": "tax_1519975316618",
                        "_rev": "1-ff42b4a950f4570ac02a62461ba4ce65",
                        "name": "VAT",
                        "percent": 14,
                        "id": 1519975316618
                    }
                }
            ],
            "slab": {
                "_id": "slab_1519975316922",
                "_rev": "1-56124fedb9eb082dfb60bf820fcec581",
                "name": "Supervisor",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 26
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 17
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 24
                    }
                ],
                "id": 1519975316922
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 100.07700000000001,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 7702.3099999999995,
            "discounted_total": 5237.5707999999995,
            "discounted_price": 2464.7392,
            "totalAfterDisAndCharges": 5237.5707999999995,
            "totalWithTax": 7332.599119999999
        },
        {
            "item_id": 3,
            "batchId": "n",
            "ItemType": "Prepared",
            "stockKey": "id_3_batch_n_1_2_2_2_3_2",
            "item_location": 1,
            "stock_name": "India",
            "line": 8,
            "name": "Small Plastic Car",
            "item_number": 36946,
            "description": "Island",
            "serialnumber": "",
            "imeiNumbers": [],
            "is_serialized": false,
            "hasBatchNumber": true,
            "bOTG": false,
            "hsn": 67683,
            "hasExpiryDate": true,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "expiry": "Sat May 26 2018 21:51:46 GMT+0530 (India Standard Time)",
            "unit": "Nos",
            "unitDocs": {
                "1519975313128": {
                    "_id": "unit_1519975313128",
                    "_rev": "1-a3539ea09a8fee34729ef243da5c9306",
                    "name": "Nos",
                    "description": "Unit",
                    "id": 1519975313128
                },
                "1519975313242": {
                    "_id": "unit_1519975313242",
                    "_rev": "1-3764aeff750d9075e2e87543b3504c7e",
                    "name": "Kg",
                    "description": "Kilograms",
                    "shortName": "kgs",
                    "id": 1519975313242
                },
                "1519975313344": {
                    "_id": "unit_1519975313344",
                    "_rev": "1-d793f72690c2930b41a15be19f3fa0f7",
                    "name": "Gm",
                    "description": "Grams",
                    "shortName": "gms",
                    "id": 1519975313344
                }
            },
            "unitId": "1519975313128",
            "baseUnitId": "1519975313344",
            "quantity": 6,
            "discount": 32,
            "price": 1100.33,
            "baseUnitPrice": 5.50165,
            "sellingPriceExcludingTax": 1100.33,
            "totalTaxPercent": 40,
            "totalPurchaseTaxPercent": 10,
            "purchasePrice": 1000.77,
            "mrp": 1200.55,
            "reorder_level": 81,
            "imeiCount": 0,
            "chargesList": [],
            "chargesTaxList": [],
            "unitsInfo": {
                "1519975313128": {
                    "refUnitId": 1519975313242,
                    "factor": 10,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 1100.33,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 1110.33,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 1120.33,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 1000.77,
                    "mrp": 1200.55
                },
                "1519975313242": {
                    "refUnitId": 1519975313344,
                    "factor": 20,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 110.03299999999999,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 111.03299999999999,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 112.03299999999999,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 100.077,
                    "mrp": 120.05499999999999
                },
                "1519975313344": {
                    "refUnitId": 1519975313344,
                    "factor": 1,
                    "pProfilesData": {
                        "1519975312114": {
                            "sellingPrice": 5.50165,
                            "discountId": 1519975315691,
                            "discount": {
                                "_id": "discount_1519975315691",
                                "_rev": "1-3707fd8e520c35431115b931499bcb3b",
                                "discount": 32,
                                "name": "Dong",
                                "maxUnits": 95,
                                "id": 1519975315691
                            }
                        },
                        "1519975321235": {
                            "sellingPrice": 5.5516499999999995,
                            "discountId": 1519975315810,
                            "discount": {
                                "_id": "discount_1519975315810",
                                "_rev": "1-0722aa114407b5f76015157e120faaf6",
                                "discount": 54,
                                "name": "database",
                                "expiry": "Tue Jun 26 2018 23:37:47 GMT+0530 (India Standard Time)",
                                "id": 1519975315810
                            }
                        },
                        "1519975321389": {
                            "sellingPrice": 5.601649999999999,
                            "discountId": 1519975315933,
                            "discount": {
                                "_id": "discount_1519975315933",
                                "_rev": "1-d28f0a9ea0d1c1d6bfac4fd4bd2d33ef",
                                "discount": 82,
                                "name": "Nicaragua",
                                "expiry": "Sat Jan 26 2019 07:57:49 GMT+0530 (India Standard Time)",
                                "id": 1519975315933
                            }
                        }
                    },
                    "purchasePrice": 5.00385,
                    "mrp": 6.00275
                }
            },
            "attributeInfo": {
                "1": 2,
                "2": 2,
                "3": 2
            },
            "itemTaxList": [
                {
                    "name": "VAT",
                    "percent": 14,
                    "Amt": 628.508496
                },
                {
                    "name": "CGST",
                    "percent": 13,
                    "Amt": 583.6150319999999
                },
                {
                    "name": "SGST",
                    "percent": 13,
                    "Amt": 583.6150319999999
                }
            ],
            "origTaxes": [
                {
                    "taxId": 1519975311099,
                    "taxInfo": {
                        "_id": "tax_1519975311099",
                        "_rev": "1-db8e12fed13ac9dc1d45d02cfbbb7ac2",
                        "name": "GST",
                        "percent": 5,
                        "id": 1519975311099
                    }
                },
                {
                    "taxId": 1519975316618,
                    "taxInfo": {
                        "_id": "tax_1519975316618",
                        "_rev": "1-ff42b4a950f4570ac02a62461ba4ce65",
                        "name": "VAT",
                        "percent": 14,
                        "id": 1519975316618
                    }
                }
            ],
            "slab": {
                "_id": "slab_1519975316922",
                "_rev": "1-56124fedb9eb082dfb60bf820fcec581",
                "name": "Supervisor",
                "taxName": "GST",
                "rates": [
                    {
                        "min": 0,
                        "max": 1000,
                        "percent": 26
                    },
                    {
                        "min": 1000,
                        "max": 2000,
                        "percent": 17
                    },
                    {
                        "min": 2000,
                        "max": 9999999,
                        "percent": 24
                    }
                ],
                "id": 1519975316922
            },
            "bReadyForCheckout": true,
            "gDiscountValue": 0,
            "bGDiscountPercent": false,
            "purchaseTax": 100.07700000000001,
            "gDiscountPercent": 0,
            "gDiscountAmt": 0,
            "total": 6601.98,
            "discounted_total": 4489.346399999999,
            "discounted_price": 2112.6336,
            "totalAfterDisAndCharges": 4489.346399999999,
            "totalWithTax": 6285.084959999999
        }
    ],
    "discount": 13062.16,
    "totalNoSpotDiscount": 36362.74,
    "addedRoundOffValue": 0.001596000001882203,
    "bLocalTax": true,
    "charges": {},
    "taxesWithPercents": {
        "CGST @1.5%": 78.56,
        "SGST @1.5%": 78.56,
        "VAT @6%": 498.19,
        "CGST @14%": 952,
        "SGST @14%": 952,
        "CGST @5%": 0.34,
        "SGST @5%": 0.34,
        "CGST @12%": 179.57,
        "SGST @12%": 179.57,
        "VAT @14%": 1990.28,
        "CGST @13%": 1848.11,
        "SGST @13%": 1848.11
    },
    "taxDetailed": {
        "5": {
            "taxable": 6.8,
            "CGST": 0.34,
            "SGST": 0.34
        },
        "6": {
            "taxable": 8303.2488,
            "VAT": 498.194928
        },
        "12": {
            "taxable": 1496.4488,
            "CGST": 179.57385599999998,
            "SGST": 179.57385599999998
        },
        "13": {
            "taxable": 14216.263599999998,
            "CGST": 1848.1142679999998,
            "SGST": 1848.1142679999998
        },
        "14": {
            "taxable": 16526.9172,
            "CGST": 952.0000000000001,
            "SGST": 952.0000000000001,
            "VAT": 1990.2769039999998
        },
        "1.5": {
            "taxable": 5237.5707999999995,
            "CGST": 78.56356199999999,
            "SGST": 78.56356199999999
        }
    },
    "taxNames": {
        "CGST": true,
        "SGST": true,
        "VAT": true
    },
    "hsnTaxes": {
        "28336": {
            "CGST": {
                "1.5": 78.56356199999999
            },
            "taxable": 5237.5707999999995,
            "SGST": {
                "1.5": 78.56356199999999
            }
        },
        "42041": {
            "VAT": {
                "6": 498.194928
            },
            "taxable": 2244.6731999999997,
            "CGST": {
                "5": 0.34,
                "12": 179.57385599999998,
                "14": 952.0000000000001
            },
            "SGST": {
                "5": 0.34,
                "12": 179.57385599999998,
                "14": 952.0000000000001
            }
        },
        "67683": {
            "VAT": {
                "14": 1990.2769039999998
            },
            "taxable": 23943.1808,
            "CGST": {
                "13": 1848.1142679999998
            },
            "SGST": {
                "13": 1848.1142679999998
            }
        }
    },
    "taxes": {
        "CGST": 3058.59,
        "SGST": 3058.59,
        "VAT": 2488.47
    },
    "total": 36362.74,
    "payments": [
        {
            "payment_type": "Cash",
            "payment_amount": 18181.37
        },
        {
            "payment_type": "Debit Card",
            "payment_amount": 18181.37
        }
    ],
    "saleOnCreditAmt": 0,
    "amount_due": 0,
    "totalQuantity": 30,
    "subtotal": 27757.083199999997,
    "discounted_subtotal": 27757.083199999997,
    "totalWithoutTax": 40819.24,
    "tax_exclusive_subtotal": 27757.083199999997,
    "receipt_title": "Sales Receipt",
    "comments": "hello world",
    "amount_change": 0,
    "employee": "couch admin",
    "company_info": {
        "0": "Bangalore",
        "1": "123456789",
        "3": "AlienHu"
    },
    "company_address": "Bangalore",
    "company_phone": "123456789",
    "company_name": "AlienHu",
    "globalDiscountInfo": {
        "amt": 0,
        "percent": 0,
        "discountMethod": "onTotal"
    },
    "customer_compnay_name": "Guneta Brothers",
    "customer": "Dhara Khatri",
    "customer_id": 1519975323313,
    "customer_address": "Achari Land",
    "customer_location": "T7R 6A3 East Ameyatmamouth",
    "account_number": "19986",
    "phone_number": "+91843-937-5486",
    "customer_info": {
        "0": "Dhara Khatri",
        "1": "Achari Land",
        "2": "T7R 6A3 East Ameyatmamouth",
        "3": "19986",
        "5": "+91843-937-5486"
    },
    "sale_id": "POS 1",
    "transaction_time": "2018-03-02 12:52:21",
    "transaction_date": "2018-03-02",
    "print_after_sale": false
};
//# sourceMappingURL=s1.js.map