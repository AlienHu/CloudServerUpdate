'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const chai = require("chai");
const expect = chai.expect;
const Utils_1 = require("../../common/Utils");
const Utils_2 = require("../../common/Utils");
const Utils_3 = require("../../controllers/common/Utils");
const s1_1 = require("./structDiffSamples/s1");
const s2_1 = require("./structDiffSamples/s2");
describe('Structure Difference Test UT', function () {
    this.timeout(100000);
    after(function () {
    });
    it('convert obj to array', function () {
        let a = {
            "1": {
                b: {
                    "33": 1,
                    "4423": 89383
                },
                c: {
                    "33322": 1,
                    "44232323": 89383
                }
            },
            "222": {
                b: {
                    "311113": 1,
                    "4423456783": 89383
                },
                c: 4
            }
        };
        let aCopy = [{
                b: [1, 89383],
                c: [1, 89383]
            }, {
                b: [1, 89383],
                c: 4
            }];
        let b = Utils_1.convertDynamicObjectPropertiesToArray(a);
        let errorsArray = [];
        console.log(b);
        let bSame = Utils_2.compareObject(aCopy, b, 0, [], errorsArray);
        console.log(errorsArray);
        expect(bSame).to.equal(true);
    });
    it('same jsons should not give any error', function () {
        let errorsArray = [];
        let tempS1 = Utils_1.convertDynamicObjectPropertiesToArray(Utils_3.clone(s1_1.default));
        let bSame = Utils_1.findStructDiffAndCopy(tempS1, tempS1, ['maxUnits', 'CGST', 'SGST'], errorsArray, false);
        console.log(errorsArray);
        expect(errorsArray.length).to.equal(0);
        expect(bSame).to.equal(true);
    });
    it('diff jsons should give any error', function () {
        let s1Clone = Utils_3.clone(s1_1.default);
        let saleReceipt = s1Clone;
        delete saleReceipt.cart[0].stockKey;
        saleReceipt.cart[1].stockKey = {};
        saleReceipt.cart[2].stockKey = 1111;
        delete saleReceipt.globalDiscountInfo.amt;
        delete saleReceipt.cart[0].unitDocs['1519975313344'].name;
        delete saleReceipt.cart[6].unitsInfo['1519975313242'].purchasePrice;
        delete saleReceipt.cart[6].unitsInfo['1519975313242'].pProfilesData["1519975321235"].sellingPrice;
        saleReceipt.cart[6].unitsInfo['1519975313242'].pProfilesData["1519975321389"].sellingPrice = "3";
        let tempS1 = Utils_1.convertDynamicObjectPropertiesToArray(Utils_3.clone(s1_1.default));
        let tempS2 = Utils_1.convertDynamicObjectPropertiesToArray(Utils_3.clone(s1Clone));
        let errorsArray = [];
        let bSame = Utils_1.findStructDiffAndCopy(tempS1, tempS2, ['maxUnits', 'CGST', 'SGST'], errorsArray, false);
        console.log(errorsArray);
        expect(errorsArray.length).to.equal(8);
        expect(bSame).to.equal(false);
    });
    it('diff jsons should not give any error', function () {
        let errorsArray = [];
        let tempS1 = Utils_1.convertDynamicObjectPropertiesToArray(Utils_3.clone(s1_1.default));
        let tempS2 = Utils_1.convertDynamicObjectPropertiesToArray(Utils_3.clone(s2_1.default));
        let bSame = Utils_1.findStructDiffAndCopy(tempS1, tempS2, ['maxUnits', 'taxesWithPercents', 'CGST', 'SGST'], errorsArray, false);
        console.log(errorsArray);
        expect(errorsArray.length).to.equal(0);
        expect(bSame).to.equal(true);
    });
});
//# sourceMappingURL=structdiff-test.js.map