'use strict';

import * as chai from 'chai';
const expect = chai.expect;
import { findStructDiffAndCopy, convertDynamicObjectPropertiesToArray } from '../../common/Utils';
import { compareObject } from '../../common/Utils'
import { clone } from '../../controllers/common/Utils';
import s1 from './structDiffSamples/s1';
import s2 from './structDiffSamples/s2';

describe('Structure Difference Test UT', function () {
    this.timeout(100000);

    after(function () {

    });

    it('convert obj to array', function () {
        let a = {
            "1": {
                b: {
                    "33": 1,
                    "4423": 89383
                },
                c: {
                    "33322": 1,
                    "44232323": 89383
                }
            },
            "222": {
                b: {
                    "311113": 1,
                    "4423456783": 89383
                },
                c: 4
            }
        };
        let aCopy = [{
            b: [1, 89383],
            c: [1, 89383]
        }, {
            b: [1, 89383],
            c: 4
        }]
        let b = convertDynamicObjectPropertiesToArray(a);
        let errorsArray: string[] = [];
        console.log(b);
        let bSame: boolean = compareObject(aCopy, b, 0, [], errorsArray);
        console.log(errorsArray);
        expect(bSame).to.equal(true);
    });

    it('same jsons should not give any error', function () {
        let errorsArray: string[] = [];
        let tempS1 = convertDynamicObjectPropertiesToArray(clone(s1));
        let bSame: boolean = findStructDiffAndCopy(tempS1, tempS1, ['maxUnits', 'CGST', 'SGST'], errorsArray, false);
        console.log(errorsArray);
        expect(errorsArray.length).to.equal(0);
        expect(bSame).to.equal(true);
    });

    it('diff jsons should give any error', function () {
        let s1Clone = clone(s1);
        let saleReceipt = s1Clone;
        delete saleReceipt.cart[0].stockKey;
        saleReceipt.cart[1].stockKey = {};
        saleReceipt.cart[2].stockKey = 1111;
        delete saleReceipt.globalDiscountInfo.amt;
        delete saleReceipt.cart[0].unitDocs['1519975313344'].name;
        delete saleReceipt.cart[6].unitsInfo['1519975313242'].purchasePrice;
        delete saleReceipt.cart[6].unitsInfo['1519975313242'].pProfilesData["1519975321235"].sellingPrice;
        saleReceipt.cart[6].unitsInfo['1519975313242'].pProfilesData["1519975321389"].sellingPrice = "3";

        let tempS1 = convertDynamicObjectPropertiesToArray(clone(s1));
        let tempS2 = convertDynamicObjectPropertiesToArray(clone(s1Clone));
        let errorsArray: string[] = [];
        let bSame: boolean = findStructDiffAndCopy(tempS1, tempS2, ['maxUnits', 'CGST', 'SGST'], errorsArray, false);
        console.log(errorsArray);
        expect(errorsArray.length).to.equal(8);
        expect(bSame).to.equal(false);
    });

    it('diff jsons should not give any error', function () {
        let errorsArray: string[] = [];
        let tempS1 = convertDynamicObjectPropertiesToArray(clone(s1));
        let tempS2 = convertDynamicObjectPropertiesToArray(clone(s2));
        let bSame: boolean = findStructDiffAndCopy(tempS1, tempS2, ['maxUnits', 'taxesWithPercents', 'CGST', 'SGST'], errorsArray, false);
        console.log(errorsArray);
        expect(errorsArray.length).to.equal(0);
        expect(bSame).to.equal(true);
    });

});