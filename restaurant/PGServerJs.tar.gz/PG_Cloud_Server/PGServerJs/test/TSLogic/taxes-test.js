"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const testUtils = require("../common/Utils");
var compareObject = testUtils.compareObject;
var compareArray = testUtils.compareArray;
const SalesEx_1 = require("../../TSControllers/libraries/SalesEx");
const commonLib = require("../../controllers/libraries/commonLib");
const computeUtils = require("../../controllers/common/computeUtils");
var getPriceTaxEx = computeUtils.getPriceTaxEx;
const commonLibEx_1 = require("../../TSControllers/libraries/commonLibEx");
describe('assignTaxesForItem UT', function () {
    this.timeout(100000);
    let unitsInfo = {
        "1": {
            factor: 1,
            refUnitId: 1,
            purchasePrice: 0,
            mrp: 0,
            pProfilesData: {}
        },
        "2": {
            factor: 10,
            refUnitId: 1,
            purchasePrice: 0,
            mrp: 0,
            pProfilesData: {}
        },
        "3": {
            factor: 10,
            refUnitId: 2,
            purchasePrice: 0,
            mrp: 0,
            pProfilesData: {}
        },
        "4": {
            factor: 100,
            refUnitId: 5,
            purchasePrice: 0,
            mrp: 0,
            pProfilesData: {}
        },
        "5": {
            factor: 1,
            refUnitId: 5,
            purchasePrice: 0,
            mrp: 0,
            pProfilesData: {}
        }
    };
    let item = {
        unitId: "1",
        baseUnitId: "1",
        unitsInfo: unitsInfo,
        origTaxesList: [{
                name: 'GST',
                percent: 5
            }, {
                name: 'Cess',
                percent: 0.5
            }, {
                name: 'VAT',
                percent: 20
            }],
        slab: {
            name: 'temp',
            taxName: 'GST',
            rates: [{
                    min: 0,
                    max: 1000,
                    percent: 0
                }, {
                    min: 1000,
                    max: 2000,
                    percent: 12
                }, {
                    min: 2000,
                    max: 9999,
                    percent: 28
                }]
        },
        ItemType: 'Normal',
        bSPTaxInclusive: false,
    };
    let taxProfileEx = {
        name: 'default',
        description: 'hello',
        slab: {
            name: 'tempTaxProfileSlab',
            taxName: 'GST',
            rates: [{
                    min: 0,
                    max: 1000,
                    percent: 10
                }, {
                    min: 1000,
                    max: 2000,
                    percent: 20
                }, {
                    min: 2000,
                    max: 9999,
                    percent: 30
                }]
        },
        normalTaxes: [{
                name: 'GST',
                percent: 5.2
            }, {
                name: 'Extra Tax',
                percent: 5
            }, {
                name: 'VAT',
                percent: 5.4
            }],
        preparedTaxes: [{
                name: 'GST',
                percent: 6.2
            }, {
                name: 'Cess',
                percent: 6.6
            }, {
                name: 'VAT',
                percent: 6.4
            }],
        liquorTaxes: [{
                name: 'GST',
                percent: 8.2
            }, {
                name: 'Cess',
                percent: 8.6
            }, {
                name: 'VAT',
                percent: 8.4
            }],
        charges: [{
                name: 'Service Charge',
                percent: 20
            }]
    };
    it('get base unit price', function () {
        expect(commonLib.getBaseUnitPrice(1000, "1", "1", unitsInfo)).to.equal(1000);
        expect(commonLib.getBaseUnitPrice(1000, "2", "1", unitsInfo)).to.equal(100);
        expect(commonLib.getBaseUnitPrice(1000, "3", "1", unitsInfo)).to.equal(10);
        expect(commonLib.getBaseUnitPrice(1000, "4", "1", unitsInfo)).to.equal(1000);
    });
    it('get slab first slab', function () {
        let taxFromSlab = computeUtils.getTaxFromSlab(item.slab, 900);
        let expectedTax = {
            name: 'GST',
            percent: 0
        };
        let errorsArray = [];
        let bSame = compareObject(expectedTax, taxFromSlab, 0, []);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });
    it('get slab second slab', function () {
        let taxFromSlab = computeUtils.getTaxFromSlab(item.slab, 1900);
        let expectedTax = {
            name: 'GST',
            percent: 12
        };
        let errorsArray = [];
        let bSame = compareObject(expectedTax, taxFromSlab, 0, []);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });
    it('formatting taxes local', () => {
        let taxArr = [{
                name: 'GST',
                percent: 10
            }];
        computeUtils.formatGSTTaxes(taxArr, true);
        let expectedTaxArr = [{
                name: 'CGST',
                percent: 5
            }, {
                name: 'SGST',
                percent: 5
            }];
        let errorsArray = [];
        let bSame = compareObject(expectedTaxArr, taxArr, 0, []);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });
    it('formatting taxes inter', () => {
        let taxArr = [{
                name: 'GST',
                percent: 10
            }];
        computeUtils.formatGSTTaxes(taxArr, false);
        let expectedTaxArr = [{
                name: 'IGST',
                percent: 10
            }];
        let errorsArray = [];
        let bSame = compareObject(expectedTaxArr, taxArr, 0, []);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });
    it('getTaxesFromProfile', () => {
        let taxArr = commonLibEx_1.getTaxesFromProfile(taxProfileEx, 'Normal');
        let errorsArray = [];
        let bSame = compareArray(taxProfileEx.normalTaxes, taxArr, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
        taxArr = commonLibEx_1.getTaxesFromProfile(taxProfileEx, 'Prepared');
        errorsArray = [];
        bSame = compareArray(taxProfileEx.preparedTaxes, taxArr, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
        taxArr = commonLibEx_1.getTaxesFromProfile(taxProfileEx, 'Liquor');
        errorsArray = [];
        bSame = compareArray(taxProfileEx.liquorTaxes, taxArr, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });
    it('with item slab', function () {
        return __awaiter(this, void 0, void 0, function* () {
            let totalTaxPercent = SalesEx_1.assignTaxesForItem4UT(item, taxProfileEx, true, 900);
            expect(totalTaxPercent).to.equal(25.5);
            expect(item.itemTaxList.length).to.equal(5);
            let expectedItemTaxArr = [{
                    name: 'Cess',
                    percent: 0.5
                }, {
                    name: 'VAT',
                    percent: 20
                }, {
                    name: 'Extra Tax',
                    percent: 5
                }, {
                    name: 'CGST',
                    percent: 0
                }, {
                    name: 'SGST',
                    percent: 0
                }];
            let errorsArray = [];
            let bSame = compareArray(expectedItemTaxArr, item.itemTaxList, 0, [], errorsArray);
            if (!bSame) {
                console.log(errorsArray);
            }
            expect(bSame).to.equal(true);
        });
    });
    it('without item slab', function () {
        return __awaiter(this, void 0, void 0, function* () {
            let key = 'slab';
            delete item[key]; //cheating because it is a readonly property
            let totalTaxPercent = SalesEx_1.assignTaxesForItem4UT(item, taxProfileEx, true, 900);
            expect(totalTaxPercent).to.equal(35.5);
            expect(item.itemTaxList.length).to.equal(5);
            let expectedItemTaxArr = [{
                    name: 'Cess',
                    percent: 0.5
                }, {
                    name: 'VAT',
                    percent: 20
                }, {
                    name: 'Extra Tax',
                    percent: 5
                }, {
                    name: 'CGST',
                    percent: 5
                }, {
                    name: 'SGST',
                    percent: 5
                }];
            let errorsArray = [];
            let bSame = compareArray(expectedItemTaxArr, item.itemTaxList, 0, [], errorsArray);
            if (!bSame) {
                console.log(errorsArray);
            }
            expect(bSame).to.equal(true);
        });
    });
    it('without slab', function () {
        return __awaiter(this, void 0, void 0, function* () {
            let key = 'slab';
            delete taxProfileEx[key]; //cheating because it is a readonly property
            let totalTaxPercent = SalesEx_1.assignTaxesForItem4UT(item, taxProfileEx, true, 900);
            expect(totalTaxPercent).to.equal(30.5);
            expect(item.itemTaxList.length).to.equal(5);
            let expectedItemTaxArr = [{
                    name: 'Cess',
                    percent: 0.5
                }, {
                    name: 'VAT',
                    percent: 20
                }, {
                    name: 'Extra Tax',
                    percent: 5
                }, {
                    name: 'CGST',
                    percent: 2.5
                }, {
                    name: 'SGST',
                    percent: 2.5
                }];
            let errorsArray = [];
            let bSame = compareArray(expectedItemTaxArr, item.itemTaxList, 0, [], errorsArray);
            if (!bSame) {
                console.log(errorsArray);
            }
            expect(bSame).to.equal(true);
        });
    });
    it('getPriceTaxEx test', function () {
        //including tax test
        let priceExTax = getPriceTaxEx(100, true, 10);
        expect(priceExTax - 90.9).to.within(-0.01, 0.01);
        //excluding tax test
        priceExTax = getPriceTaxEx(100, false, 10);
        expect(priceExTax).to.equal(100);
    });
});
//# sourceMappingURL=taxes-test.js.map