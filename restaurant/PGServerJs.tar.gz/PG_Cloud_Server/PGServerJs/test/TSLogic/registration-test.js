"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const library_1 = require("../../Registration/libraries/library");
const controller_1 = require("../../Registration/controller");
const formatDocIds_1 = require("../../TSControllers/utils/formatDocIds");
const dbInstanceHelper_1 = require("../../TSCouchDB/Common/dbInstanceHelper");
const couchDBApis_1 = require("../../TSCouchDB/Common/couchDBApis");
const commonUtils = require("../common/commonUtils");
const init_1 = require("../../TSCouchDB/CloudCouch/init");
const init_2 = require("../../init/init");
const validateInstaller_1 = require("../../TSCouchDB/validateInstaller");
const couchDBUtils = require("../../controllers/common/CouchDBUtils");
const version_1 = require("../../TSControllers/interfaces/version");
describe('XXXX UT', function () {
    this.timeout(99999999);
    const tempRegDoc = {
        name: 'regtest',
        ip: '127.0.0.1'
    };
    before(function () {
    });
    it('xxxxxxxxxx', () => __awaiter(this, void 0, void 0, function* () {
        try {
            const doc = yield library_1.getRegistrationId("1531727540746");
            console.log(doc);
        }
        catch (error) {
            console.log(error);
            console.log("I printed from catch block");
        }
    }));
    it('Helper Test', () => __awaiter(this, void 0, void 0, function* () {
        try {
            const doc = yield controller_1.getRegistrationDoc(tempRegDoc);
            console.log(doc);
        }
        catch (error) {
            console.log(error);
            console.log("I printed from catch block");
        }
    }));
    it('Stress Test For Registration Id', () => __awaiter(this, void 0, void 0, function* () {
        init_2.setSkipForUT(true);
        for (let i = 0; i < 100; i++) {
            console.log('Count<' + i + '>');
            yield controller_1.getRegistrationDoc(tempRegDoc);
        }
    }));
    it('Stress Test For Store', () => __awaiter(this, void 0, void 0, function* () {
        init_2.setSkipForUT(true);
        let session;
        let prevICounter = couchDBUtils.getCounter();
        for (let i = 0; i < 100; i++) {
            const registrationDoc = yield controller_1.getRegistrationDoc(tempRegDoc);
            let iCounter = couchDBUtils.getCounter();
            console.log('No Of Apis<' + (iCounter - prevICounter) + '>');
            prevICounter = iCounter;
            const dbContext = formatDocIds_1.getDBContext(registrationDoc._id);
            console.log('Count<' + i + '>');
            let storeDoc = yield couchDBApis_1.getDoc(dbContext, 'store_1_1', dbInstanceHelper_1.getLicenceDBInstance);
            yield init_2.onStoreSelectInit(storeDoc, session);
            iCounter = couchDBUtils.getCounter();
            console.log('No Of Apis<' + (iCounter - prevICounter) + '>');
            prevICounter = iCounter;
        }
    }));
    it.only('Version control test', () => __awaiter(this, void 0, void 0, function* () {
        let session;
        init_2.setSkipForUT(true);
        let dbContext;
        const couchDbManager = require('../../dbManagers/couchDbManager');
        let resp = yield couchDbManager.initCouchDb(false);
        dbContext = resp.dbContext;
        commonUtils.setDBContext(dbContext);
        let cloudDb = init_1.getCloudLicenceDBInstance(dbContext);
        let cloudallDocs = yield couchDBUtils.getAllDocsByType('version', cloudDb);
        let delArray = [];
        for (let i = 0; i < cloudallDocs.length; i++) {
            let del = cloudallDocs[i].doc;
            del._deleted = true;
            delArray.push(del);
        }
        yield couchDBUtils.bulkDocs(delArray, cloudDb);
        let allDocs = yield couchDBApis_1.getAllDocsByType(dbContext, 'version', dbInstanceHelper_1.getLicenceDBInstance);
        for (let i = 0; i < allDocs.length; i++) {
            let del = allDocs[i].doc;
            yield couchDBApis_1.deleteApi(dbContext, del, dbInstanceHelper_1.getLicenceDBInstance);
        }
        // fresh install sync should start...
        let bIsSyncNeedToStart = yield validateInstaller_1.isSyncNeedToStart(dbContext);
        console.log("compare first true=" + bIsSyncNeedToStart);
        expect(bIsSyncNeedToStart).to.equal(true);
        let vDoc = {
            version: '1.0.1-25',
            _id: "version_ab_cd_ed",
            syncStatus: version_1.Version.SyncStatus.PAUSED
        };
        // await versionInfo.save(vDoc, dbContext);
        yield couchDBUtils.create(vDoc, cloudDb);
        yield commonUtils.pgTimeOut(2000);
        // second store is add with higer version continue...
        bIsSyncNeedToStart = yield validateInstaller_1.isSyncNeedToStart(dbContext);
        console.log("Current store version is less then other store");
        console.log("compare two version true=" + bIsSyncNeedToStart);
        expect(bIsSyncNeedToStart).to.equal(true);
        bIsSyncNeedToStart = yield validateInstaller_1.isSyncNeedToStart(dbContext);
        console.log("compare two version true=" + bIsSyncNeedToStart);
        expect(bIsSyncNeedToStart).to.equal(true);
        try {
            vDoc = yield couchDBUtils.getDoc('version_ab_cd_ed', cloudDb);
        }
        catch (ex) {
            console.log(ex);
        }
        vDoc.version = '1.0.0-10';
        vDoc.syncStatus = version_1.Version.SyncStatus.ACTIVE;
        yield couchDBUtils.createOrUpdate(vDoc, cloudDb, 3);
        bIsSyncNeedToStart = yield validateInstaller_1.isSyncNeedToStart(dbContext);
        console.log("cloud version is less then current <>  update false=" + bIsSyncNeedToStart);
        expect(bIsSyncNeedToStart).to.equal(false);
        vDoc = yield couchDBUtils.getDoc('version_14-18-77-c5-80-a4', cloudDb);
        expect(vDoc.syncStatus).to.equal(version_1.Version.SyncStatus.PAUSED);
    }));
});
//# sourceMappingURL=registration-test.js.map