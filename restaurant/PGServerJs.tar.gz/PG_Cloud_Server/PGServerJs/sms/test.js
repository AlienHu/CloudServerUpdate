const httpUtils = require('../common/httpUtils');
const smsConfig = {
    "gupshup": {
        "value": false,
        "url": 'http://enterprise.smsgupshup.com/GatewayAPI/rest',
        "query": {
            "msg_type": 'TEXT',
            "userid": 2000178071,
            "auth_scheme": 'plain',
            "password": 'alienhu@123',
            "format": 'JSON',
            "method": 'SendMessage',
            "override_dnd": false,
            "v": '1.1'
        }
    }
};

async function run() {
    let q1 = {
        send_to: '99',
        msg: 'hello chittoor',
        mask: 'ALINHU'
    }

    let query = Object.assign(smsConfig.gupshup.query, q1);
    let requestBuilder = {
        url: smsConfig.gupshup.url,
        method: "GET",
        json: true,
        qs: query,
        headers: {
            "Content-Type": "application/json"
        }
    };

    try {
        let response = await httpUtils.http(requestBuilder); // sending sms to 2factor or gupshup
        console.log(response.body.response);
        console.log('im here');
    } catch (error) {
        console.log(error);
        console.log('im in error');
    }
}

run();