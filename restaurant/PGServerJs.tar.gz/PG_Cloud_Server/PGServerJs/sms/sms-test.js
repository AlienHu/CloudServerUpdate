   'use strict';
   require('dotenv-safe').load({
       path: __dirname + '/../.env',
       sample: __dirname + '/../env.example'
   });

   const chai = require("chai");
   const chaiAsPromised = require("chai-as-promised");

   const faker = require('faker');

   chai.use(chaiAsPromised);
   chai.should();
   const expect = chai.expect;

   const couchDbManager = require('../dbManagers/couchDbManager');
   const couchDBUtils = require('../controllers/common/CouchDBUtils');
   const coreDBInstance = couchDBUtils.getCoreCouchDB();

   let testUtils;
   let appSettings;

   describe('Elements UTs', function() {

       this.timeout(50000000);

       before(async function() {
           appSettings = await couchDbManager.initCouchDb(false);
           testUtils = require('./sms.js');
       });

       it('send sms', async function() {
           var json = {};
           json.To = '9572362138';
           json.Msg = 'testing SMS UT';
           json.app = process.env.APP_TYPE;

           var resp = await testUtils(json);
           console.log(resp);
           expect(1).to.equal(1);
       });
   });