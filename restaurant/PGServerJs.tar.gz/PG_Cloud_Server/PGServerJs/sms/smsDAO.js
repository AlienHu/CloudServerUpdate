"use strict";
/**
 * DAO for smsOffer
 * Author : Linto thomas
 * Created : 28-Mar-18
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const crypto = require("../controllers/libraries/crypto");
const couchDBUtils = require("../controllers/common/CouchDBUtils.js");
const logger = require("../common/Logger");
const licenceDBInstance = couchDBUtils.getLicenceDB();
exports.SMS_INFO_DOC_NAME = 'smsOffer';
function save(doc) {
    return __awaiter(this, void 0, void 0, function* () {
        logger.info("*** smsDAO.save");
        let smsOffer = {
            _id: doc._id,
            encrypt: crypto.encrypt(doc),
            version: "2.0"
        };
        yield couchDBUtils.create(smsOffer, licenceDBInstance);
    });
}
exports.save = save;
function get() {
    return __awaiter(this, void 0, void 0, function* () {
        logger.info("*** smsDAO.get");
        try {
            let smsOffer = yield couchDBUtils.getDocEx(exports.SMS_INFO_DOC_NAME, licenceDBInstance);
            let smsInfo = crypto.decrypt(smsOffer.encrypt);
            return smsInfo;
        }
        catch (e) {
            if (!(e.reason === 'missing' || e.reason === 'deleted')) {
                logger.error("error from smsDAO" + JSON.stringify(e));
            }
            throw e;
        }
    });
}
exports.get = get;
function decrypt(smsOffer) {
    let plain = crypto.decrypt(smsOffer.encrypt);
    return plain;
}
exports.decrypt = decrypt;
//# sourceMappingURL=smsDAO.js.map