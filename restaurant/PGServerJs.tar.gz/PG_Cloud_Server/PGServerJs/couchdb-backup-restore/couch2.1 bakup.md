####################### Backup for 2.1############################
* node module is  @cloudant/couchbackup 
* send bCouch2 true from .env 
* backup is working for all 
    1. licence db
    2. main db
    3. core db
    4. _users db 
* restore is woring for 
    1. licence db
    2. main db
    3. core db
* code need to be improved 
* using time out if posible remove it 
* for couch 1.6.1 remove  bCouch2 from .env
