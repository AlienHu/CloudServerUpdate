require('errors');

var bodyParser = require('body-parser');
var featureRouter = require('express').Router();

featureRouter.use(bodyParser.urlencoded({
    extended: true
}));
featureRouter.use(bodyParser.json());

//TODO 
/*
1) This featureRouter should carry alternative authentication model
as the end customer should not be having access to these Apis.

2) Encrypt this document as well 
*/

featureRouter.get('/getAllowedFeatures', function(req, res, next) {
    var featuresCouchHandler = require('../couchDb/featuresCouchHandler')();
    var appName = req.query.appName === undefined ? process.env.APP_TYPE : req.query.appName.toLowerCase();
    featuresCouchHandler.getAllowedApplicationFeatures(appName).then(function(RestApis) {
        res.send(RestApis);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

featureRouter.put('/updateAllowedFeatures', function(req, res, next) {
    var featuresCouchHandler = require('../couchDb/featuresCouchHandler')();
    var appName = req.query.appName === undefined ? process.env.APP_TYPE : req.query.appName.toLowerCase();
    featuresCouchHandler.updateAllowedApplicationFeatures(appName, req.body).then(function(RestApis) {
        res.send(RestApis);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

module.exports = featureRouter;