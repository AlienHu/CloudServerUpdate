var express = require('express');
var router = express.Router();
var itemsController = require('../controllers/Items');
var fs = require("fs");

router.post('/create', function(req, res) {
    var newItemData = req.body.item;
    newItemData.employeeId = req.session.user.name;

    if (newItemData.hasBatchNumber === undefined) {
        newItemData.hasBatchNumber = true;
    }
    if (newItemData.initialStock === undefined) {
        newItemData.initialStock = {};
    }

    itemsController.createItem(newItemData).then(function(resp) {
        console.log('Successfully added Item', resp);
        res.send(resp);
        res.end();

    }).catch(function(reason) {
        var error = new Error(reason);
        // error.message = reason.error;
        res.send(error);
        res.end();
    });

});

router.put('/update', function(req, res) {
    var requestData = req.body.item;
    requestData.employeeId = req.session.user.name;

    itemsController.updateItem(requestData).then(function(resp) {
        console.log('Successfully updated Item', resp);
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        //res.sendStatus(300);
        var error = new Error(reason);
        // error.message = reason.error;
        res.send(error);
        res.end();
    });

});

/**
 *  var params = {
             item_id: 1,
             batchId: 2,
             newQuantity: -10,
             comment: 'Missing Stock',
             employeeId: 'admin',
             locationId: 1,
         };
 */
router.put('/saveInventoryRestApi', function(req, res) {
    var requestData = req.body;
    requestData.employeeId = req.session.user.name;
    requestData.employee = req.session.user.first_name + req.session.user.first_name;
    itemsController.updateStock(requestData).then(function(resp) {
        console.log('saveInventoryRestApi', resp);
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });
});

/**
 *  {
 *      item_id: 4,
 *      batchId: '45',
 *      quantity: 400,
 *      purchasePrice: 200,
 *      sellingPrice: 300,
 *      mrp: 310,
 *      expiry: '25-10-2015',
 *      discountId: 3
 *  }
 */
router.post('/createBatch', function(req, res) {
    var data = req.body.item;
    data.employeeId = req.session.user.name;

    itemsController.createNewBatch(data).then(function(resp) {
        console.log('Successfully added Batch', resp);
        res.send(resp);
        res.end();

    }).catch(function(reason) {
        console.log(reason);
        res.send(reason);
        res.end();
    });

});

/**
 *  This api is for batch details update. Quantity is not considered
 *  {
 *      item_id: 4,
 *      batchId: '45',
 *      quantity: 0,   //Whatever value sent here is not considered 
 *      purchasePrice: 200,
 *      sellingPrice: 300,
 *      mrp: 310,
 *      expiry: '25-10-2015', //Send this only if item.hasExpiryDate is true
 *      discountId: 3 //Discount is optional
 *  }
 */
router.put('/updateBatch', function(req, res) {
    var data = req.body.item;
    data.employeeId = req.session.user.name;

    itemsController.updateBatch(data).then(function(resp) {
        console.log('Successfully updated Batch', resp);
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        //res.sendStatus(300);
        res.send(reason);
        res.end();
    });

});

router.delete('/delete', function(req, res) {
    var requestData = req.body.item;
    requestData.employeeId = req.session.user.name;

    itemsController.deleteItem(requestData).then(function(resp) {
        console.log('Successfully updated Item', resp);
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        //res.sendStatus(300);
        res.send(reason);
        res.end();
    });
});

router.post('/import', function(req, res) {
    var newItemData = req.body.data;
    var employee = req.session.user.name;
    itemsController.importItems(newItemData, employee).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        //res.sendStatus(300);
        res.send(reason);
        res.end();
    });

});
router.post('/importItems2', function(req, res) {
    var itemsImporter = require('../controllers/importItemsCsv');
    itemsImporter.runImport(req.body.data, req.app.locals.applicationSettings).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        //res.sendStatus(300);
        var error = new Error(reason);
        error.message = reason;
        res.send(error);
        res.end();
    });
})

router.post('/export', function(req, res) {
    itemsController.exportItems().then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        //res.sendStatus(300);
        res.send(reason);
        res.end();
    });

});

router.post('/validateUniqueDetails', function(req, res) {
    var itemsValidator = require('../controllers/validatiors/Items');
    itemsValidator.validateUniqueNumbers(req.body.uids).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });
});

router.post('/validateBulkUniqueDetails', function(req, res) {
    var itemsValidator = require('../controllers/validatiors/Items');
    itemsValidator.validateBulkUniqueNumbers(req.body.uids).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });
});
router.post('/validateSingleUniqueNumber', function(req, res) {
    var itemsValidator = require('../controllers/validatiors/Items');
    itemsValidator.validateSingleUniqueNumber(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });
});

module.exports = router;