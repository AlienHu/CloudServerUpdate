var controller = require('../controllers/Tables.js');
var bodyParser = require('body-parser');
require('errors');
var router = require('express').Router();
router.use(bodyParser.urlencoded({
    extended: true
}));
router.use(bodyParser.json());
var logger = require('../common/Logger');

//http://racksburg.com/choosing-an-http-status-code/

router.post('/createTableRestApi', function(req, res, next) {
    controller.createTable(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

//TODO Ganesh delete method should be changed to delete ; we shouldnt use post for deleting
router.post('/deleteTableApiRestApi', function(req, res, next) {
    controller.deleteTable(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.put('/changeTable', function(req, res) {
    var salesController = require('../TSControllers/SalesEx');
    salesController.changeTableOrder(req.body).then(function(resp) {
        logger.silly('success: Table order get changed');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function(reason) {
        logger.error('Table order change');
        logger.error(reason);

        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    });
});

router.put('/mergeTables', function(req, res) {
    var salesController = require('../TSControllers/SalesEx');
    salesController.mergeTables(req.body).then(function(resp) {
        logger.silly('success: Merge');
        logger.silly(resp);
        res.send(resp);
        res.end();

    }).catch(function(reason) {
        logger.error('Merging Table');
        logger.error(reason);

        var error = new Error(reason);
        error.message = reason.message;
        res.status(500).send(error);
        res.end();
    });
});

module.exports = router;