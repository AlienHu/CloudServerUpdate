var roomController = require('../controllers/Rooms.js');
var bodyParser = require('body-parser');
require('errors');
var router = require('express').Router();
router.use(bodyParser.urlencoded({
    extended: true
}));
router.use(bodyParser.json());

//http://racksburg.com/choosing-an-http-status-code/

router.post('/createTarrif', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.create(req.body, 'tariff');
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.post('/getAllReservations', async function(req, res, next) {
    //TODO
    try {
        let resp = await roomController.getAllReservations();
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.post('/createRoom', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.create(req.body, 'room');
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});
router.post('/createExtra', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.create(req.body, 'addOn');
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});
router.post('/updateExtra', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.update(req.body, 'addOn');
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});
router.post('/deleteExtra', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.delete(req.body, 'addOn');
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});
router.post('/updateSettings', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.updateSettings(req.body);
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.post('/updateRoom', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.update(req.body, 'room');
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});
router.post('/deleteRoom', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.delete(req.body, 'room');
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});
router.post('/updateTarrif', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.update(req.body, 'tariff');
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});
router.post('/deleteTarrif', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.delete(req.body, 'tariff');
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.post('/createReservation', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.updateBooking(req.body);
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.post('/updateReservation', async function(req, res, next) {
    //TODO
    var doc = req.body;
    try {
        let resp = await roomController.updateBooking(req.body);
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

module.exports = router;