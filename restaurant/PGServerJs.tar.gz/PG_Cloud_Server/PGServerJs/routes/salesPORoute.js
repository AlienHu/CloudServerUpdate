let express = require('express');
let router = express.Router();
const salesPOCtlr = require('../TSControllers/SalesPO');



router.post('/addPOtoCart', function (req, res) {
    salesPOCtlr.addPOToCart(req.body.param, req.session, req.app.locals.applicationSettings).then(function (resp) {
        res.send(resp);
        res.end();
    }).catch(function (reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

module.exports = router;
