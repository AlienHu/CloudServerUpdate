var express = require('express');
var router = express.Router();
var receipeController = require('../TSControllers/Receipe');

router.put('/saveBOM', async function (req, res, next) {
    try {
        let resp = await receipeController.getItemByDocId(req.body);
        res.send(resp);
        res.end();
    } catch (reason) {
        //#bom .. throw error if it fails
        res.send(reason);
        res.end();
    }
});

router.put('/updateProductionPlan', async function (req, res, next) {
    try {
        let resp = await receipeController.updateProductionPlan(req.body);
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.delete('/deleteProductionPlan', async function (req, res, next) {
    try {
        let resp = await receipeController.updateProductionPlan(req.body, receipeController.Option.Delete);
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.put('/approveProductionPlan', async function (req, res, next) {
    try {
        let resp = await receipeController.approveProductionPlan(req.body, receipeController.Option.Delete);
        res.send(resp);
        res.end();
    } catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.put('/stockEntry', async function (req, res, next) {
    try {
        let resp = await receipeController.stockEntry(req.body, receipeController.Option.Delete);
        res.send(resp);
        res.end();
    } catch (reason) {
        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    }
});

module.exports = router;