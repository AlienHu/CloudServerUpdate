var lytyCntrlr = require('../controllers/loyalty');
var bodyParser = require('body-parser');
require('errors');
var router = require('express').Router();
router.use(bodyParser.urlencoded({
    extended: true
}));
router.use(bodyParser.json());

router.post('/save', function(req, res, next) {
    console.log("*** loyaltyRoute.save");
    var campaign = req.body;
    lytyCntrlr.save(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.status(406).send(reason);
        res.end();
    });
});

router.delete('/delete', function(req, res, next) {
    console.log("*** loyaltyRoute.delete");
    var campaign = req.body;
    lytyCntrlr.deleteLyty(campaign).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.status(406).send(reason);
        res.end();
    });
});

// router.get('/get', function(req, res, next) {
//     console.log("*** loyaltyRoute.get");
//     lytyCntrlr.get().then(function(resp) {
//         res.send(resp);
//         res.end();
//     }).catch(function(reason) {
//         res.status(406).send(reason);
//         res.end();
//     });
// });

module.exports = router;