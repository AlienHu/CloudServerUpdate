var express = require('express');
var router = express.Router();
var controller = require('../TSControllers/Expenses');

router.put('/saveExpenseCategory', async function (req, res, next) {
    try {
        let resp = await controller.saveExpenseCategory(req.body);
        res.send(resp);
        res.end();
    } catch (reason) {
        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    }
});

router.put('/saveExpense', async function (req, res, next) {
    try {
        let resp = await controller.saveExpense(req.body);
        res.send(resp);
        res.end();
    } catch (reason) {
        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    }
});

router.get('/getExpenses', async function (req, res, next) {
    try {
        let resp = await controller.getExpenses(req.query);
        res.send(resp);
        res.end();
    } catch (reason) {
        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    }
});

router.get('/getExpensesForCatArr', async function (req, res, next) {
    try {
        let resp = await controller.getExpensesForCatArr(req.query);
        res.send(resp);
        res.end();
    } catch (reason) {
        var error = new Error(reason);
        error.message = reason.message;
        res.send(error);
        res.end();
    }
});

module.exports = router;