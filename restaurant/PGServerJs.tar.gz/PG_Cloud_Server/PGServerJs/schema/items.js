const getJSON = require('./common').getJSON;

var item = {
    name: getJSON('string', false, ''),
    ItemType: getJSON('string', false, '')

}

// {
//    "_id": "item_20",
//    "_rev": "1-34bc1c351b3373e4b483d09a863e2793",
//    "item_id": 20,
//    "info": {
//        "name": "Tasty Metal Bike",
//        "ItemType": "Ingredient",
//        "categoryId": 1,
//        "purchasePrice": 700,
//        "sellingPrice": 238,
//        "mrp": 384,
//        "is_serialized": true,
//        "imeiCount": 3,
//        "hasExpiryDate": true,
//        "hasBatchNumber": true,
//        "bSPTaxInclusive": true,
//        "bPPTaxInclusive": true,
//        "bOTG": false,
//        "purchaseUnitId": 4,
//        "sellingUnitId": 2,
//        "conversionFactor": 614,
//        "supplier_id": 2,
//        "purchaseTaxes": [
//            1
//        ],
//        "salesTaxes": [
//            1,
//            2
//        ],
//        "brandId": 4,
//        "item_number": 92910,
//        "description": "withdrawal",
//        "reorderLevel": 113,
//        "reorderQuantity": 355,
//        "attributes": [
//        ]
//    },
//    "batches": {
//        "id_20_batch_1498052557816": {
//            "purchasePrice": 714,
//            "sellingPrice": 399,
//            "mrp": 920,
//            "discountId": 5,
//            "location_id": 1,
//            "expiry": "Wed Jan 17 2018 16:00:57 GMT+0530 (India Standard Time)",
//            "batchId": "a",
//            "stockKey": "id_20_batch_1498052557816",
//            "locationId": 1
//        }
//    }
// }