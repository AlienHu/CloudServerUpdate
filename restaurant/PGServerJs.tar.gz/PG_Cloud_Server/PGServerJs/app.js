console.log('Starting app for following ENVIRONMENT=', process.env.ENVIRONMENT, 'And APP_TYPE=', process.env.APP_TYPE, ' on Port:', process.env.PROFITGURU_SERVER_PORT);
var express = require('express');
var path = require('path');

var logger = require('morgan');
var winston_logger = require("./common/Logger");
var bodyParser = require('body-parser');

var app = express();
app.disable('etag');
const getCouchauthInfo = require('./common/getCouchAuthInfo');
getCouchauthInfo.getCouchAuthInfo().then(() => {
    init();
});

async function init() {
    //var errors = require('errors');
    var session = require('express-session');
    var sessionstore = require('./pg_nm/sessionstore');
    var authorizer = require('./middleWares/authorizers');
    var clientDeviceProcessor = require('./middleWares/clientDeviceProcessor');
    var appLockProcessor = require('./middleWares/appLocksProcessor');
    var requestIp = require('request-ip');
    //var device = require('express-device');
    //for passPort auth
    //var routes = require('./routes/index');
    //var users = require('./routes/index');
    //var passport = require('passport');
    var cors = require('cors');
    var bonjourService = require('./common/bonjourServer.js');
    var ON_DEATH = require('death'); //this is intentionally ugly
    var helmet = require('helmet');

    app.use(helmet());
    app.set('trust proxy', 1);
    app.use(cors({
        credentials: true,
        origin: true
    }));

    // load our routes and pass in our app and fully configured passport

    var appConfig = require('./config/configProfitGuruNodeServer.js');

    var couchUsersDbUrl = 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT + '/_users';
    var express_user_couch_config = {
        users: couchUsersDbUrl,
        adminRoles: ['admin'],
        /**Todo: Ideal way to assign fields to safeUserFields is to fetching EmployeeElementsJson and Applying it here ; then remove these hardcoded fields*/
        safeUserFields: 'name email roles desc password password_again first_name last_name gender phone_number address_1 address_2 city state zip country comments profile'
    };
    var expressUserCouchDb = require('./employees/express-user-couchdb');

    var profitGuruMAPP = path.resolve(__dirname + '/profitGuruMAPP');
    app.use(express.static(profitGuruMAPP));

    appConfig.initProfitGuruServer(appConfig).then(function(promiseResults) {
        const alienPrinter = require('./alienPrinter')(promiseResults.applicationSettings);
        bonjourService.setLocationNameAndStartBonjourServer(promiseResults.applicationSettings.locationName.value);

        var items = require('./routes/itemsRoute');
        var suppliersRoute = require('./routes/suppliersRoute');
        var customersRoute = require('./routes/customersRoute');
        var salesRoute = require('./routes/salesRoute');
        var salesPO = require('./routes/salesPORoute');
        var customersLoyalityRoute = require('./routes/customersLoyalityRoute');
        var tablesRoute = require('./routes/tablesRoute');
        var feedbackRoute = require('./routes/feedbackRoutes');
        var crmRoute = require('./routes/crmRoute');
        var loyaltyRoute = require('./routes/loyaltyRoute');
        var reservationsRoute = require('./routes/reservationsRoute');
        var notesRoute = require('./routes/notesRoute');
        var coresRoute = require('./routes/coresRoute.js');
        var featureRoute = require('./routes/featuresRoute.js');
        var applicationSettingsRoute = require('./routes/applicationSettingsRoute.js');
        var receivingsRoute = require('./routes/receivingsRoute.js');
        var globalConfigsRoute = require('./routes/globalConfigsRoute.js');
        var commonRoute = require('./routes/commonPGRoute.js');
        var hotelRoute = require('./routes/hotelRoute.js');
        var receipeRoute = require('./routes/receipeManagementRoute.js');
        var expenseRoute = require('./routes/expensesRoute.js');
        var tally = require('./routes/tallyRoute.js');

        //For Hosted APP
        //var MAPPAccessRoute = require('./routes/MAPPRoutes.js');
        var noUpdateRoute = require('./routes/updateInfoRoute');
        var reportRoute = require('./routes/reports.js');

        var sessionDbName = promiseResults.sessionDbName;
        app.locals.applicationSettings = promiseResults.applicationSettings;

        //initialize passport for user login using couchdb
        //  require('./users/passportConfig.js')(passport, argv.environment, argv.nodeApp); // pass passport for configuration

        app.use(logger('dev'));
        app.use(bodyParser.json({
            limit: '16mb'
        }));
        app.use(bodyParser.urlencoded({
            extended: false
        }));

        const couchConfig = promiseResults.config.localCouch;
        // app.use(device.capture());
        app.use(session({
            store: sessionstore.createSessionStore({
                type: 'couchdb',
                host: couchConfig.Host, // optional
                port: couchConfig.Port, // optional
                dbName: sessionDbName, // optional
                collectionName: 'sessions', // optional
                timeout: 10000, // optional,
                options: {
                    auth: {
                        username: couchConfig.UserName,
                        password: couchConfig.Password
                    }
                }
            }, function(err, resp) {
                if (err) {
                    winston_logger.error(err);
                } else {
                    winston_logger.info('session init without error');
                }
                //console.log(resp);
            }),
            //store: sessionstore.createSessionStore(),
            resave: false,
            saveUninitialized: false,
            secret: 'alienHu'
        }));
        app.use(requestIp.mw());
        app.use(authorizer.loginAuthorizer());
        //Done with this middleware Enable this after setting the respective module apis in entitlement doc
        app.use(authorizer.entitlementsAuthorizer());
        app.use(authorizer.featuresAuthorizer(promiseResults.allowedApplicationFeatures));
        app.use(authorizer.licenceAuthorizer());
        //Used for Locking all the requests
        //Locks the server while taking backup / software update
        app.use(appLockProcessor());
        app.use(clientDeviceProcessor());

        // app.use(session({
        // 	secret: 'ilovescotchscotchyscotchscotch',
        // 	resave: false,
        // 	saveUninitialized: false
        // })); // session secret

        // app.use(passport.initialize());
        //app.use(passport.session()); // persistent login sessions
        //app.use(flash());
        //require('./routes/index')(app, passport);
        //  app.use(isLoggedIn);

        //Application Routes
        app.use('/items', items);
        app.use('/itemManagement', globalConfigsRoute);
        app.use('/suppliers', suppliersRoute);
        app.use('/customers', customersRoute);
        app.use('/customersLoyality', customersLoyalityRoute);
        app.use('/tables', tablesRoute);
        app.use('/tableReservations', reservationsRoute);
        app.use('/hotel', hotelRoute);
        app.use('/notes', notesRoute);
        app.use('/sales', salesRoute);
        app.use('/salesPO', salesPO);
        app.use('/feedback', feedbackRoute);
        app.use('/crm', crmRoute);
        app.use('/loyalty', loyaltyRoute);
        app.use('/purchases', receivingsRoute);
        //app.use('/employee', employeeOrUserRoute);
        app.use('/core', coresRoute);
        app.use('/common', commonRoute);
        app.use('/reports', reportRoute);
        app.use('/receipe', receipeRoute);
        app.use('/expenses', expenseRoute);
        app.use('/tally', tally);

        //app.use('/mobileApp_retail', MAPPAccessRoute);
        //app.use('/mobileApp_restaurant', MAPPAccessRoute);
        // Before requiring licenceRouter we need app to be initialized
        var licenceRouter = require('./routes/licenceRoute.js');
        app.use('/licence', licenceRouter);

        app.use('/features', featureRoute);
        app.use('/applicationSettings', applicationSettingsRoute);

        app.use(expressUserCouchDb(express_user_couch_config));

        //Adding Update Route    
        console.log('process.env.enableSelfUpdate=', process.env.enableSelfUpdate);
        app.use('/profitGuruUpdate', noUpdateRoute);
        var socketServer = app.get('socketServer');
        if (process.env.enableSelfUpdate === 'true') {
            process.env.UpdaterDir = process.env.UpdaterDir ? process.env.UpdaterDir : __dirname + '/../profitGuruUpdater';
            var updaterRoute = require(process.env.UpdaterDir + '/routes/updateRoute.js');
            updaterRoute.setSocketServer(socketServer);
            //Update Route
            app.use('/profitGuruUpdate', updaterRoute);
        } else {
            app.use('/profitGuruUpdate', noUpdateRoute);
        }

        var cntrlrUtils = require('./controllers/common/Utils.js');
        cntrlrUtils.setSocketServer(socketServer);

        //Routes that should exists on development environment
        if (process.env.ENVIRONMENT === 'development' || (process.env.IS_DEMO_APP).toLowerCase() === 'yes') {

            //For creating the DemoUser
            var demoEmployee = require('./demoApp/demoEmployeeRoute');
            app.use('/demoApp/createDemoEmployee', demoEmployee);

            //For resetting the Databases
            var dbResetRoute = require('./demoApp/dbManagerRoute');
            app.use('/demoApp/resetProfitGuruDbs', dbResetRoute);

            //For Data creation TimeMachine
            var timeMachine = require('./demoApp/timeMachineRoute');
            app.use('/demoApp/timeMachine', timeMachine);
        }

        //app.use(errors.errorHandler());

        // app.use(methodOverride());
        // app.use(logErrors);
        // app.use(clientErrorHandler);
        // app.use(errorHandler);

        // function logErrors(err, req, res, next) {
        // 	console.error(err.stack);
        // 	next(err);
        // }

        // function clientErrorHandler(err, req, res, next) {
        // 	if (req.xhr) {
        // 		res.status(500).send({
        // 			error: 'Something failed!'
        // 		});
        // 	} else {
        // 		next(err);
        // 	}
        // }

        // function errorHandler(err, req, res, next) {
        // 	res.status(500);
        // 	res.render('error', {
        // 		error: err
        // 	});
        // }
        // catch 404 and forward to error handler

        app.emit("PGuruNodeServerStarted");
        app.use(function(req, res, next) {
            var err = new Error('Not Found');
            err.status = 404;
            next(err);
        });

    }).catch(function(error) {
        winston_logger.error(error);
        process.exit(1);
    });

    ON_DEATH(function(signal, err) {
        console.log('Cleaning Up profitGuruServer');
        //This should be last cleanUp handler as its exits the process    
        bonjourService.stopBonjourServiceInstance().then(function(resp) {
            process.exit(0);
        }).catch(function(err) {
            process.exit(1);
        })
    });

}

// error handler
// no stacktraces leaked to user unless in development environment
// app.use(function(err, req, res, next) {
// 	res.status(err.status || 500);
// 	res.render('error', {
// 		message: err.message,
// 		error: (app.get('env') === 'development') ? err : {}
// 	});
// });

module.exports = app;