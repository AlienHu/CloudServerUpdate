// require plugins

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .example('$0 combo', 'ProgitGuru Node Server')
    .alias('env', 'environment')
    .default('env', 'development')
    .describe('env', 'One of the available environments [development,production]')
    .alias('iDemo', 'isDemoApp')
    .default('iDemo', 'no')
    .alias('d', 'debug')
    .describe('d', 'Debug target File')
    .alias('cs', 'cloudServer')
    .describe('cs', 'cloudServer')
    .default('cs', false)
    .alias('b', 'brk')
    .alias('t', 'test')
    .default('t', false)
    .describe('t', 'is It UT')
    .describe('b', 'break on firstline while dubugging')
    .default('b', false)
    .alias('r', 'release')
    .default('r', false)
    .alias('v', 'version')
    .default('v', false)
    .alias('type', 'versionType')
    .default('type', 'prerelease')
    .alias('bENM', 'bExcludeNodeModules')
    .describe('bENM', 'exclude node modules in the build')
    .default('bENM', false)
    .boolean('bENM')
    .alias('ni', 'bNpmInstall')
    .describe('ni', 'npm install while creating install')
    .default('ni', false)
    .boolean('ni')
    .alias('ec', 'enableNpmCache')
    .describe('ec', 'Use npm-cache')
    .default('ec', true)
    .boolean('ec')
    .help('h')
    .alias('h', 'help')
    .argv;

var bump = require('gulp-bump');
var gulp = require('gulp');
var minify = require('gulp-uglify-es').default;
var rename = require('gulp-rename');
var plumber = require('gulp-plumber');
var jshint = require('gulp-jshint');

var concat = require('gulp-concat');
var gutil = require('gulp-util');
var gcopy = require('gulp-copy');
var gulpif = require('gulp-if');
var shelljs = require('shelljs');
var zip = require('gulp-zip');
var replace = require('gulp-replace');
// require('dotenv-safe').load({
//     path: __dirname + '/.env',
//     sample: __dirname + '/env.example'
// });
//For debugging PGServerJS,yo can edit the code in debugger itself
//Its much faster way

const ts = require("gulp-typescript");
const tsProject = ts.createProject("tsconfig.json");
var gulpSequence = require('gulp-sequence');
var del = require('del');
var fs = require('fs');
var COPY_NM = require('./common/npmUtils').copyNPM;

var stripDebug = require('gulp-strip-debug');
var install = require('gulp-install');
var ENVIRONMENT = process.env.ENVIRONMENT || argv.env || 'development';
var isDemoApp = process.env.IS_DEMO_APP || argv.isDemoApp || 'yes';

//'!./migrations/**/*'
var paths = {
    srcDir: ['!./profitGuruMAPP/**/*', './**/*.js', '!./test/**/*', '!./archive/**/*', '!./timeMachine/**/*', '!./node_modules/**/*', '!runIstanbulCodeCoverage.js', '!startComboServers.js', '!gulpfile.js', '!codeRunner.js', '!./builds/**/*', '!./demoApp/createItemsFromFile.js', '!./nmCache/**/*'],
    buildDir: 'builds/' + ENVIRONMENT + '/PGServerJs',
    otherSrcs: ['*.bat', 'env.example', '*.sh', 'package.json', './config/**/*.json', './config/**/*.xml', './sms/smsCount.json', './couchDBMigrations/profitguruCoreConfig/20170311001304-version-0/*.json', 'startComboServers.js', './profitGuruMAPP/**/*', './**/*.sql', './timeMachine/**/*', './**/*.ejs', '!./nmCache/**/*', '!./node_modules/**/*', '!./archive/**/*', '!./builds/**/*', '!./dbManagers/scripts/**']
};
//TODO add './node_modules/**/*', to extraSrcs
var del = require('del');

gulp.task('create-softlinks', function (done) {
    var cwd = shelljs.pwd();
    //PGServerJs
    shelljs.ln('-sf', cwd + '/../profitGuruCore/Config', cwd + '/config/profitguruCoreConfig');
    shelljs.ln('-sf', cwd + '/../profitGuruCore/ClientDeviceProcessor', cwd + '/middleWares/clientDeviceProcessor');
    shelljs.ln('-sf', cwd + '/../profitGuruCore/appLocksProcessor', cwd + '/middleWares/appLocksProcessor');
    shelljs.ln('-sf', cwd + '/.env', cwd + '/dbManagers/.env');
    shelljs.ln('-sf', cwd + '../terminalNodeServer/common/httpUtils.js', cwd + '/common/httpUtils.js');

    done();
});

gulp.task('npm-install', function (done) {
    gulp.src(['./package.json'])
        .pipe(install());
    done();
});

gulp.task('clean', function () {
    return del.sync([paths.buildDir]);
});

gulp.task('bump', function () {
    /// <summary>
    /// It bumps revisions
    /// Usage:
    /// 1. gulp bump : bumps the package.json etc to the next minor revision.
    ///   i.e. from 0.1.1 to 0.1.2
    /// 2. gulp bump --version 1.1.1 : bumps/sets the package.json etc to the 
    ///    specified revision.
    /// 3. gulp bump --type major       : bumps 1.0.0 
    ///    gulp bump --type minor       : bumps 0.1.0
    ///    gulp bump --type patch       : bumps 0.0.2
    ///    gulp bump --type prerelease  : bumps 0.0.1-2
    /// </summary>

    if (argv.release && !argv.version) {
        console.error('WARNING:For Release build version is compulsory,(So Can not procees)');
        process.exit(1);
    }
    var msg = 'ProfitGuru App updated ';
    var type = argv.type;
    var version = argv.version;
    var bumpOptions = {};
    if (version) {
        bumpOptions.version = version;
    } else {
        bumpOptions.type = type;
    }

    console.log(bumpOptions);
    return gulp
        .src(['./version.json'])
        .pipe(bump(bumpOptions))
        .pipe(gulp.dest('./'));
});

gulp.task('copyversion', function () {
    var versionJson = JSON.parse(fs.readFileSync('./version.json', 'utf8'));
    var packageJson = JSON.parse(fs.readFileSync(paths.buildDir + '/package.json', 'utf8'));
    packageJson.version = versionJson.version;
    packageJson = JSON.stringify(packageJson);
    fs.writeFileSync(paths.buildDir + '/package.json', packageJson);
});

gulp.task('copy', function () {

    var bDevelopment = true;
    if (ENVIRONMENT === 'development' || isDemoApp === 'yes') {
        paths.otherSrcs.push('./test/**/*');
    } else if (ENVIRONMENT === 'production') {
        bDevelopment = false;
        paths.otherSrcs.push('./test/common/profitGuruFaker.js');
        paths.otherSrcs.push('./test/common/commonUtils.js');
    }

    return gulp.src(paths.otherSrcs, {
        follow: true
    })
        .pipe(gcopy(paths.buildDir));

});

gulp.task('copyNM', function () {
    if (argv.bExcludeNodeModules) {
        return;
    }

    COPY_NM('production', 'NO', __dirname, true, __dirname + '/' + paths.buildDir);
});

gulp.task('jshint', function () {
    return gulp.src(gulp.src(paths.srcDir, {
        follow: true
    }))
        .pipe(jshint())
        .pipe(jshint.reporter('default'));
});

var onError = function (err) {
    gutil.beep();
    gutil.log(gutil.colors.green(err));
};
gulp.task('cleanAndCopyConfigs', gulpSequence('clean', 'copy', 'bump', 'copyversion', 'copyNM'));

gulp.task('zip', function () {
    if (shelljs.test('-d', 'archive')) {
        shelljs.mkdir('archive');
    }
    var zipPath = paths.buildDir + '/../**/*';
    if (argv.cs) {
        zipPath = '[' + paths.buildDir + '/../**/*', '!paths.buildDir/node_modules/**', '!paths.buildDir/nmCache/**]';
    }
    gulp.src(paths.buildDir + '/licencer/licenceHelper.js')
        .pipe(replace('var isServerRunningOnProfitGuruCloud=!1', 'var isServerRunningOnProfitGuruCloud=1'))
        .pipe(gulp.dest(paths.buildDir + '/licencer/'));
    var archivePath = shelljs.pwd() + '/archive';

    return gulp.src(zipPath)
        .pipe(zip('PGServerJs.zip'))
        .pipe(gulp.dest(archivePath));

});

gulp.task('buildAndZip', gulpSequence('build', 'zip'));

gulp.task('installLocalNodeModules', function () {
    if (!argv.bNpmInstall) {
        return;
    }

    shelljs.exec('nvm use 8.11.2');
    if (argv.enableNpmCache) {
        shelljs.exec('npm-cache install');
    } else {
        shelljs.exec('npm install');
    }
    shelljs.exec('nvm use 6.11.0');
});

gulp.task('build', ['installLocalNodeModules', 'cleanAndCopyConfigs', 'build-ts'], function () {
    return gulp.src(paths.srcDir, {
        follow: true
    })
        .pipe(plumber({
            errorHandler: onError
        }))
        // .pipe(gulpif(ENVIRONMENT === 'production', stripDebug()))
        // .pipe(minify()).on('error', console.log)
        // .pipe(concat('PGServerJs.js'))
        // .pipe(gulpif(ENVIRONMENT === 'production', rename({
        //     suffix: '.min'
        // })))
        .pipe(gulp.dest(paths.buildDir));
});

gulp.task('build-ts', function () {
    return tsProject.src()
        .pipe(tsProject())
        // .pipe(minify())
        .pipe(gulp.dest(paths.buildDir));
});

gulp.task('test2', function () {
    return gulp.src(paths.srcDir, {
        follow: true
    })
        .pipe(plumber({
            errorHandler: onError
        }))
        // .pipe(minify()).on('error', console.log)
        .pipe(concat('PGServerJs.js'))
        .pipe(gulp.dest(paths.buildDir));
});

var debugTarget = argv.d || 'bin/PGServerJs.js';
debugTarget = process.env.PWD + '/' + debugTarget;

// var debugParams = argv.b === false ? '--debug' : '--debug-brk';

// debugParams = argv.t ? '_mocha ' + debugParams : debugParams;

console.log('debugTarget=', debugTarget);

gulp.task('nodemon', function () {
    var nodemon = require('gulp-nodemon');
    nodemon({
        script: debugTarget, // location of webserver module
        ext: '',
        tasks: ['jshint'], // any task you want to run before refreshing the server, TODO
        nodeArgs: ['--debug', '--debug-brk'], //important must pass the debug flag to work,
        verbose: true
    });
});
//nodeArgs: ['--debug', '--debug-brk', '/home/balakrishna/.nvm/v4.4.0/bin/_mocha'], //important must pass the debug flag to work,
// nodeArgs: ['--debug-brk'], //important must pass the debug flag to work,
// nodeArgs: ['--debug'], //important must pass the debug flag to work,
gulp.task('inspector', ['nodemon'], function () {
    var nodeInspector = require('gulp-node-inspector');
    gulp.src(['bin/PGServerJS.js'])
        .pipe(nodeInspector({
            debugPort: 5858,
            webHost: '0.0.0.0',
            webPort: 8080,
            saveLiveEdit: true,
            preload: false,
            inject: true,
            hidden: [/node_modules/i],
            stackTraceLimit: 50,
            sslKey: '',
            sslCert: ''
        }));
});

gulp.task('default', function () {
    gulp.start('inspector');
});

gulp.task('debug', function () {
    gulp.start('inspector');
});

var DEBUG = ENVIRONMENT === 'debug',
    CI = process.env.CI === 'true';

gulp.task('test-debug', function () {
    var mocha = require('gulp-spawn-mocha');
    return gulp.src(['test/*/*/UT_*.js'], {
        read: false
    })
        .pipe(mocha({
            debugBrk: false,
            // r: 'test/unit/controllers/UT_items.js',
            R: CI ? 'spec' : 'nyan',
            istanbul: !DEBUG
        }));
});