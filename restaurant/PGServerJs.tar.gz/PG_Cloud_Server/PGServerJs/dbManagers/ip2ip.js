// CROSS CHECK TARGET IP ADDRESS
// CROSS CHECK TARGET IP ADDRESS
let targetIP = ''; // CROSS CHECK IT 4 TIMES
// CROSS CHECK TARGET IP ADDRESS
// CROSS CHECK TARGET IP ADDRESS 

let srcIP = 'localhost';
let appName = 'crm'; //retail
let dbSufix = 'maindb';
let localDbName = 'pg_collection_' + appName + '_' + dbSufix;

return sync();

async function sync() {
    let nano = require('nano-blue')('http://couchadmin:test@' + targetIP + ':5984');
    try {
        await nano.db.destroy(localDbName);
    } catch (error) {
        console.log('Failed to delete ' + targetIP + ' ' + localDbName + ' db');
    }

    let srcURL = 'http://couchadmin:test@' + srcIP + ':5984/' + localDbName;
    let targetURL = 'http://couchadmin:test@' + targetIP + ':5984/' + localDbName;

    await replicateDB(nano, srcURL, targetURL);
}

function replicateDB(sourceCouchDdClient, sourceDBUrl, targetDBUrl) {
    return new Promise((resolve, reject) => {
        sourceCouchDdClient.db.replicate(sourceDBUrl, targetDBUrl, {
                create_target: true
            },
            function(err, resp) {
                if (!err) {
                    console.log('couchDb', resp);
                    resolve(resp);
                } else {
                    console.log('Replcaition failed ', err);
                    reject(err);
                }
            });
    });
}