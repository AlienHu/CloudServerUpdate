'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});

const couchDbManager = require('./../../dbManagers/couchDbManager');
const couchDBUtils = require('../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const globalConfigController = require('../../controllers/GlobalConfigurations');

var itemsArray = [];
var csv = require('csvtojson')
console.log("Hello ");
csv()
    .fromFile(__dirname + '/importResturantData.csv')
    .on('json', (jsonObj) => {
        itemsArray.push(jsonObj);
    })
    .on('done', (error) => {
        console.log(itemsArray.length);
        console.log('end');
        console.log(error);
        return run();
    });

async function createConfig(key) {

    let foo = '';
    if (key === 'Category Name') {
        foo = 'createCategory';
    } else if (key === 'Discount %') {
        foo = 'createDiscount';
    } else if (key.indexOf("Purchase Taxes%") != -1) {
        foo = 'createTax';
    } else if (key.indexOf("Sales Taxes%") != -1) {
        salesTaxesHeaderNameArr.push(key);
        foo = 'createTax';
    }

    //process is to get unique config names
    let count = {};
    for (let i = 0; i < itemsArray.length; i++) {

        let configName = itemsArray[i][key];

        if (!configName) {
            // To ignore empty category / subCategory
            continue;
        }
        console.log("configName:" + configName);
        count[configName] = 1;
    }

    //here creating config
    let namesArray = Object.keys(count);
    for (let i = 0; i < namesArray.length; i++) {

        let info;
        if (key === 'Category Name') {
            info = {
                name: namesArray[i],
                description: "Default Categories"
            };
        } else if (key === 'Discount %') {
            info = {
                name: "discount",
                discount: parseFloat(namesArray[i]),
                description: "Default Discount",

            };
        } else if (key.indexOf("Purchase Taxes%") != -1 || key.indexOf("Sales Taxes%") != -1) {

            let spacePosition = key.indexOf(' ');
            let tempName = key.substr(0, spacePosition);
            info = {
                name: tempName,
                percent: parseFloat(namesArray[i]),
                description: tempName + " Tax",

            };
        }
        try {
            await globalConfigController[foo](info);
            console.log("item created namesArray[i]" + namesArray[i]);
        } catch (error) {
            console.log(namesArray[i] + ' already exist' + " error:");
        }
    }
}
async function prepare() {
    await createConfig('Category Name');
    // await createConfig('unit');
    // await createConfig('tax');
    // // await createConfig('Attributes');

}

let categoryObj = {};
let unitObj = {};
// let taxObj = {};
async function getIds() {
    //tax, category, saleUnit, purchaseUnit

    let categoryArray = [];
    let unitArray = [];
    try {
        categoryArray = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
        unitArray = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);
    } catch (error) {
        console.log("getIds:" + error);
    }

    for (let i = 0; i < categoryArray.length; i++) {
        categoryObj[categoryArray[i].doc.name] = categoryArray[i].doc.id;
        // categoryObj[categoryArray[i].doc.name] = categoryArray[i].doc.id;
    }
    for (let i = 0; i < unitArray.length; i++) {
        unitObj[unitArray[i].doc.name] = unitArray[i].doc.id;
    }
    // for (let i = 0; i < taxArray.length; i++) {
    //     taxObj[taxArray[i].doc.name + '-' + taxArray[i].doc.percent] = taxArray[i].doc.id;
    // }

}

async function setDefaultValues(pgItem) {

    //uniqueItemCode
    pgItem.uniqueItemCode = "";

    //item_number
    pgItem.item_number = "";

    //purchaseTaxes
    pgItem.purchaseTaxes = [];

    //salesTaxes
    pgItem.salesTaxes = [];

    // reorderLevel
    pgItem.reorderLevel = "";

    pgItem.reorderQuantity = "";

    //is_serialized
    pgItem.is_serialized = false;

    //hasExpiryDate
    pgItem.hasExpiryDate = false;

    //receiving_quantity 
    pgItem.receiving_quantity = 0;

    //reorder_level 
    pgItem.reorder_level = 0;

    //expiry_date
    pgItem.expiry_date = "";

    // allow_alt_description
    pgItem.allow_alt_description = "0";

    //purchasePrice 
    pgItem.purchasePrice = "";

    //sellingPrice
    pgItem.sellingPrice = "";

    //mrp
    pgItem.mrp = "",

        // isNewBatch 
        pgItem.isNewBatch = false;

    //hasBatchNumber
    pgItem.hasBatchNumber = false;
    //hasMeasurementUnit 
    pgItem.hasMeasurementUnit = false;

    //imeiCount 
    pgItem.imeiCount = 0;

    //imeNumbers 
    pgItem.imeNumbers = [];

    // convPurchasePrice
    pgItem.convPurchasePrice = 0;

    // density
    pgItem.density = 0;

    // pricingProfiles 
    pgItem.pricingProfiles = false;

    // multipleUnits
    pgItem.multipleUnits = false;

    // itemNprice 
    pgItem.itemNprice = 0;

    // purchaseUnitId 
    pgItem.purchaseUnitId = 0;

    // sellingUnitId 
    pgItem.sellingUnitId = 0;

    // isprepared 
    pgItem.isprepared = true;

    // issellable 
    pgItem.issellable = true;

    // isbought 
    pgItem.isbought = false;

    // is_deleted
    pgItem.is_deleted = "";

    pgItem.cost_price = "";
    pgItem.unit_price = "";

    pgItem["1_quantity"] = 1;
    pgItem.quantity = 1;
    pgItem.category = "";
    pgItem.discount = "";
    pgItem.conversionFactor = 1;
    // discount_expiry 
    pgItem.discount_expiry = null;

    // hasVariants
    pgItem.hasVariants = false;

    pgItem.bSPTaxInclusive = false;
    pgItem.bPPTaxInclusive = false;

    pgItem.attributes = [];

    pgItem.ItemType = "Prepared";
    pgItem.custom1 = 0;
    pgItem.custom2 = 0;
    pgItem.custom3 = 0;
    pgItem.custom4 = 0;
    pgItem.custom5 = 0;
    pgItem.custom6 = 0;
    pgItem.custom7 = 0;
    pgItem.custom8 = 0;
    pgItem.custom9 = 0;
    pgItem.custom10 = 0;

    pgItem.tax_name_1 = "";
    pgItem.tax_name_2 = "";
    pgItem.tax_percent_1 = "";
    pgItem.tax_percent_2 = "";

    pgItem.tax_names = ["", ""];
    pgItem.tax_percents = ["", ""];

    pgItem.loyaltyPerc = 0;
    pgItem.itemTaxes = {};

    pgItem.item_image = "";

    pgItem.is_deleted = "0";
    // employeeId 
    pgItem.employeeId = "admin_restaurant";

}

let firstLevelFields = {
    "uniqueItemCode": "Item Code",
    "name": "Name",
    "item_number": "Barcode",
    "description": "Description",
    "bPPTaxInclusive": "PP Tax Inclusive",
    "bSPTaxInclusive": "SP Tax Inclusive",
    "reorderLevel": "Reorder Level",
    "reorderQuantity": "Reorder Quantity",
    "bOTG": "OTG",
    "hsn": "HSN"
};

async function createItemArray() {
    let itemController = require('../../controllers/Items');

    for (let i = 0; i < itemsArray.length; i++) {
        let pgItem = {
            initialStock: []
        };

        //set common default values
        setDefaultValues(pgItem);

        pgItem["name"] = itemsArray[i]["Name"];
        pgItem["description"] = itemsArray[i]["Description"];

        if (itemsArray[i]["OTG"].toLowerCase() === "no") {
            pgItem["bOTG"] = false;
        } else {
            pgItem["bOTG"] = true;
        }

        pgItem.categoryId = parseInt(categoryObj[itemsArray[i]["Category Name"]]);

        pgItem.sellingPrice = parseFloat(itemsArray[i]["Selling Price"]);
        pgItem.mrp = parseFloat(itemsArray[i]["MRP"]);
        pgItem.purchasePrice = 0;
        pgItem.item_number = 1001;

        let initObj = {};

        initObj["quantity"] = 0;
        initObj["purchasePrice"] = pgItem.purchasePrice;
        initObj["sellingPrice"] = pgItem.sellingPrice;
        initObj["mrp"] = pgItem.mrp;
        initObj["expiry"] = null;
        initObj["uniqueDetails"] = [];

        pgItem.initialStock.push(initObj);

        // pgItem.quantity = 1;
        pgItem.sellingUnitId = 1;
        pgItem.purchaseUnitId = 1;

        console.log("\n\nPgItem:" + JSON.stringify(pgItem));
        console.log("\n");
        try {
            await itemController.createItem(pgItem);
            console.log("created Successfully:" + pgItem.name);
            console.log("\n\n");
        } catch (error) {
            console.log("\n\nItemCreate error" + JSON.stringify(error));
            console.log("\n\n");
        }
    }
}

async function run() {
    // //mandatory to initialize the server -> equivalent to node bin/PGServerJs.js
    await couchDbManager.initCouchDb(true);

    console.log("calling prepare method");
    await prepare();

    console.log("calling getIds method");
    await getIds();

    console.log("calling createItemArray method");
    await createItemArray();
    // // console.log(uniqueItemCodes);
    console.log('done');
    // process.exit(0);
}