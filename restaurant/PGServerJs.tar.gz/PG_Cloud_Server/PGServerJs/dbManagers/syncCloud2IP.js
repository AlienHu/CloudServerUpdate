// let productionHost = '51.15.244.27';
// let trialHost = '51.15.133.206';
//aws '52.66.110.58'
//let cloudIp ="cloud ip"  //'51.15.244.27';
// trupti :20-e6-17-03-48-8c
//dpk 'd4-be-d9-52-c4-f7'
//vijay lakshmo 'a98c4530-d044-423d-869b-923cc3f13df0'
//ganesh 54-53-ed-23-c4-ef
//http://couchadmin:test@51.15.133.206:5984/pg_collection_cloud_retail_maindb_54-53-ed-23-c4-ef

let serverid = 'SERVER_ID';
let appName = 'restaurant';
let dbSufix = 'maindb'; // _users for userdb
let targetDbName = 'pg_collection_' + appName + '_' + dbSufix;
if (dbSufix === '_users') targetDbName = '_users';
let productionDbName = 'pg_collection_cloud_' + appName + '_' + dbSufix + '_' + serverid;
let productionIp = "PRODUCTION_IP"; // cloud ip
let targetIP = "LOCALHOST_OR_DEDICATED_IP"; //dedicated ip

function run() {
    return sync();
}
run();
async function sync() {
    let nanoTarget = require('nano-blue')("http://couchadmin:test@" + targetIP + ":5984");
    // let nanoProduction = require('nano-blue')("http://couchadmin:test@" + productionIp + ":5984"); // no use ???

    try {
        await nanoTarget.db.destroy(targetDbName);
    } catch (error) {
        console.log('Failed to delete local db');
    }

    let productionCloudCouchUrl = 'http://couchadmin:test@' + productionIp + ':5984/' + productionDbName
    let targetCouchUrl = 'http://couchadmin:test@' + targetIP + ':5984/' + targetDbName;

    await replicateDB(nanoTarget, productionCloudCouchUrl, targetCouchUrl);
}

function replicateDB(targetCouchDdClient, sourceDBUrl, targetDBUrl) {
    return new Promise((resolve, reject) => {
        targetCouchDdClient.db.replicate(sourceDBUrl, targetDBUrl, {
                create_target: true
            },
            function(err, resp) {
                if (!err) {
                    console.log('couchDb', resp);
                    resolve(resp);
                } else {
                    console.log('Replcaition to cloud failed ', err);
                    reject(err);
                }
            });
    });
}