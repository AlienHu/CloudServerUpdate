//http://couchadmin:test@51.15.133.206:5984/pg_collection_cloud_retail_maindb_54-53-ed-23-c4-ef
const moment = require('moment');
const fs = require('fs');

const currentMoment = moment();
let results = {
    "0": []
};
let errorIpsArr = [];
let zeroActivityArr = [];

async function iterateIps() {
    let ipsJson = require('./ips');
    let ipsArr = ipsJson.ips;
    let whitelist = ipsJson.whitelist;
    //ips.length
    // ips excludes    TITO-production:"51.15.206.208",<deleted>old production: 51.15.200.57,163.172.166.242,51.15.254.39
    for (let i = 0; i < ipsArr.length; i++) {
        if (whitelist.indexOf(ipsArr[i]) > -1) {
            continue;
        }
        let resp = await getLatestTransDoc(ipsArr[i]);
        if (!resp) {
            continue;
        }

        let key = Object.keys(resp)[0];
        results[key].push(resp[key]);
        console.log('processed <' + i + '> ip<' + ipsArr[i] + '> <' + JSON.stringify(resp[key]) + '>');
    }
    let csvData = 'ip,appType,startDate\n\r';
    for (let j = 0; j < results["0"].length; j++) {
        csvData += results["0"][j].ip + ',' + results["0"][j].app + ',' + results["0"][j].date + '\n\r';
    }
    fs.writeFile('my.csv', csvData, (err) => {
        if (err) throw err;
        console.log('my.csv saved.');
    });
    fs.writeFileSync('results.csv', csvData, (e) => {
        if (e) {
            console.log(e);
        }
    });
    fs.writeFileSync('results.json', JSON.stringify(results));
    fs.writeFileSync('zeroResults.json', JSON.stringify(zeroActivityArr));
    fs.writeFileSync('errors.json', JSON.stringify(errorIpsArr));

    parseResults();

}

async function getLatestTransDoc(ip) {
    try {
        let db = require('nano-blue')("http://couchadmin:test@" + ip + ":5984");
        let getlist = await db.db.list();
        let dbList = getlist[0];
        if (dbList.length > 25) {
            throw 'ip<' + ip + '> DBCount<' + dbList.length + '>';
        }

        let out = {
            iTotalDocs: 0,
            lastActiveTimestamp: 0,
            lastActiveDocId: ''
        };

        let totalMainDBS = 0;
        let errorsArr = [];
        for (let j = 0; j < dbList.length; j++) {
            if (dbList[j].indexOf('maindb') === -1) {
                continue;
            }

            totalMainDBS++;

            let maindbInstance = db.use(dbList[j]);
            let resp;
            let appType = '';
            try {
                resp = await db_calls(maindbInstance, dbList[j]);
            } catch (error) {
                errorsArr.push(error);
                continue;
            }
            let prefix = 'pg_collection_';
            if (dbList[j].indexOf('maindb') > -1) {
                resp.app = dbList[j].substring(prefix.length, dbList[j].indexOf('_maindb'));
            }
            // resp.app = appType;
            out = resp;
        }

        if (totalMainDBS && totalMainDBS === errorsArr.length) {
            throw errorsArr;
        }

        if (!out.firstTimestamp) {
            zeroActivityArr.push(ip);
            return;
        }


        out.ip = ip;
        return {
            ['0']: out
        };

    } catch (err) {
        errorIpsArr.push({
            [ip]: JSON.stringify(err)
        });
    }

}

async function db_calls(maindbInstance, dbName) {

    try {
        let response = await getLastTimestampForDocType(maindbInstance, 'unit');
        return response;

    } catch (err) {
        throw err;
    }
}

async function getLastTimestampForDocType(dbInstance, docType) {
    let params = {
        startkey: docType + '_',
        endkey: docType + '_z'
    };

    const docsQueryResp = await dbInstance.fetch({}, params);
    const length = docsQueryResp[0].rows.length;
    if (length) {
        const docId = docsQueryResp[0].rows[0].id;
        let timestamp = docId.substr(docId.indexOf('_') + 1, docId.length);

        return {
            firstTimestamp: parseInt(timestamp),
            date: (new Date(parseInt(timestamp))).toString(),
            firstDocId: docId
        };
    }

    return {
        firstTimestamp: 0,
        firstDocId: '',
        date: ''
    };
}


function parseResults() {
    let arrayFirst = [];
    let allArr = [];

    for (let i = 0; i < results["0"].length; i++) {
        arrayFirst.push(results["0"][i].ip);
        allArr.push(results["0"][i].ip);
    }
    fs.writeFileSync('firstDocs.json', JSON.stringify(arrayFirst));
    fs.writeFileSync('allarr.json', JSON.stringify(allArr));
}

return iterateIps();

//which returns last active date.
//{60: [{ip: lastactivedoc, totaldocs:}], 45, 30, 15}
//60 days
//45 days
//30 days
//15 days
// have a json ip -> crm -> retail, restaurant, saloon 
// number of docs, sale, purchase, cmp, appointment
//autoreporter wisher schedule cmp
// unit doc