require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .alias('d', 'dropCouchDbs')
    .default('d', true)
    .alias('c', 'createCouchDbs')
    .default('c', false)
    .alias('s', 'serverId')
    .default('s', '')
    .alias('t', 'isTrial')
    .default('t', false)
    .alias('BL', 'backUpLocation')
    .default('BL', "C:/ProgramData/PGServerJs/backUps")
    .alias('env', 'environment')
    .default('env', 'development')
    .describe('env', 'One of the available environments [development,production]')
    .alias('nodeApp', 'nodeAppType')
    .describe('nodeApp', 'One of the available nodeApp appTypes [combo,cloud,retail,restaurant,pharmacy,crm]')
    .help('h')
    .alias('h', 'help')
    .argv;

var couchDbManager = require('./couchDbManager');

if (argv.d && argv.c) {
    couchDbManager.initCouchDb(true, argv.s, argv.t, argv.BL)
        .then(function(resp) {
            console.log('Done!!');
            process.exit(0);
        }).catch(function(reason) {
            console.log(reason);
        });
} else if (argv.d) {
    couchDbManager.dropAllCouchDBs(argv.s, argv.t, argv.BL)
        .then(function(resp) {
            console.log('Done!!');
            process.exit(0);
        }).catch(function(reason) {
            console.log(reason);
        });
} else if (argv.c) {
    //Todo: check if we can just create tables without dropping data 
    couchDbManager.initCouchDb()
        .then(function(resp) {
            console.log('Done!!');
            process.exit(0);
        }).catch(function(reason) {
            console.log(reason);
        });
} else {
    console.log('Error:Apss proper arguments!!!!(Help -h)');
    process.exit(0);
}