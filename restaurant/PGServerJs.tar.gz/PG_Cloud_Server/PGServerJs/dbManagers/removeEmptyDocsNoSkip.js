'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const CHUNK = 1000;
async function run() {

    let params = {
        limit: CHUNK,
        skip: 0,
        include_docs: true
    };
    let dummyDocs = [];
    let ctr = 0;

    while (1) {
        const resp = await mainDBInstance.list(params);
        const docs = resp[0].rows;
        params.skip += docs.length;
        if (docs.length !== CHUNK) break;
        for (let i = 0; i < docs.length; i++) {

            const thisDoc = docs[i].doc;
            if (Object.keys(thisDoc).length === 2) {
                // store it in an array
                thisDoc._deleted = true;
                dummyDocs.push(thisDoc);
                console.log("dummy found " + (++ctr) + " : " + thisDoc._id);
                // await couchDBUtils.delete(resp[i].doc, mainDBInstance);
            }

        }
    }

    const resp = await mainDBInstance.bulk({
        docs: dummyDocs
    });
    console.log(resp);

    // read from array for all dummy
    // delete at once

}

run().then(() => {
    // process.exit(0);
    console.log("success");
}).catch(function(err) {
    console.error(err);
    console.error("something failed");
});