// let productionHost = '51.15.244.27';
// let trialHost = '51.15.133.206';
//aws '52.66.110.58'
//let cloudIp ="cloud ip"  //'51.15.244.27';
// trupti :20-e6-17-03-48-8c
//dpk 'd4-be-d9-52-c4-f7'
//vijay lakshmo 'a98c4530-d044-423d-869b-923cc3f13df0'
//ganesh 54-53-ed-23-c4-ef
//http://couchadmin:test@51.15.133.206:5984/pg_collection_cloud_retail_maindb_54-53-ed-23-c4-ef

let ip = "localhost"; //dedicated ip
let appName = 'restaurant';
let dbSufix = '_users'; // _users for userdb
let dbName = 'pg_collection_' + appName + '_' + dbSufix;
let isProduction = false;
if (dbSufix === '_users') dbName = dbSufix;
let serverId = '00-e0-4c-a3-86-0b'; // no need if localhost or dedicated ip
if (isProduction) dbName = 'pg_collection_cloud_' + appName + '_' + dbSufix + '_' + serverId;
let fullDoc = false; // see full doc
let designName = "";
let viewName = "";

function run() {
    return getData();
}
run();

async function getData() {
    let nano = require('nano-blue')("http://couchadmin:test@" + ip + ":5984");
    let db = nano.use(dbName);
    let param = {};
    if (fullDoc) {
        param.include_docs = true;
    }
    try {
        let resp;
        if (designName && viewName)
            resp = await db.view(designName, viewName);
        else
            resp = await db.list(dbName);
        let rows = resp[0].rows;
        console.log('rows: ' + rows.length);
        for (let i = 0; i < rows.length; i++) {
            if (!fullDoc || rows[0].id.indexOf('_design') > -1) {
                console.log((i + 1) + '.: ' + JSON.stringify(rows[0]) + '\n');
            } else {
                let doc = await db.get(rows[i].id, param);
                console.log((i + 1) + '.: ' + JSON.stringify(doc[0]) + '\n');
            }
        }
    } catch (err) {
        console.error('Error occurred');
        console.error(err);
    }
}