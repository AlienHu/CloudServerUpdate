//http://couchadmin:test@51.15.133.206:5984/pg_collection_cloud_retail_maindb_54-53-ed-23-c4-ef
const moment = require('moment');
const fs = require('fs');

const currentMoment = moment();
let results = {
    "0": [],
    "1": [],
    "5": [],
    "15": [],
    "30": [],
    "45": [],
    "60": []
};
let errorIpsArr = [];
let zeroActivityArr = [];

async function iterateIps() {
    let ipsJson = require('./ips');
    let ipsArr = ipsJson.ips;
    let whitelist = ipsJson.whitelist;
    //ips.length
    // ips excludes    TITO-production:"51.15.206.208",<deleted>old production: 51.15.200.57,163.172.166.242,51.15.254.39
    for (let i = 0; i < ipsArr.length; i++) {
        if (whitelist.indexOf(ipsArr[i]) > -1) {
            continue;
        }
        let resp = await getLatestTransDoc(ipsArr[i]);
        if (!resp) {
            continue;
        }

        let key = Object.keys(resp)[0];
        results[key].push(resp[key]);
        console.log('processed <' + i + '> ip<' + ipsArr[i] + '> <' + JSON.stringify(resp[key]) + '>');
    }

    fs.writeFileSync('results.json', JSON.stringify(results));
    fs.writeFileSync('zeroResults.json', JSON.stringify(zeroActivityArr));
    fs.writeFileSync('errors.json', JSON.stringify(errorIpsArr));
    parseResults();
}

async function getLatestTransDoc(ip) {
    try {
        let db = require('nano-blue')("http://couchadmin:test@" + ip + ":5984");
        let getlist = await db.db.list();
        let dbList = getlist[0];
        if (dbList.length > 25) {
            throw 'ip<' + ip + '> DBCount<' + dbList.length + '>';
        }

        let out = {
            iTotalDocs: 0,
            lastActiveTimestamp: 0,
            lastActiveDocId: ''
        };

        let totalMainDBS = 0;
        let errorsArr = [];
        for (let j = 0; j < dbList.length; j++) {
            if (dbList[j].indexOf('maindb') === -1) {
                continue;
            }

            totalMainDBS++;

            let maindbInstance = db.use(dbList[j]);
            let resp;
            try {
                resp = await db_calls(maindbInstance, dbList[j]);
            } catch (error) {
                errorsArr.push(error);
                continue;
            }
            if (resp.lastActiveTimestamp > out.lastActiveTimestamp) {
                out = resp;
            }
        }

        if (totalMainDBS && totalMainDBS === errorsArr.length) {
            throw errorsArr;
        }

        if (!out.lastActiveTimestamp) {
            zeroActivityArr.push(ip);
            return;
        }

        const diffDays = currentMoment.diff(moment(parseInt(out.lastActiveTimestamp)), 'day');
        let key = "0";
        if (diffDays > 60) {
            key = "60";
        } else if (diffDays > 45) {
            key = "45";
        } else if (diffDays > 30) {
            key = "30";
        } else if (diffDays > 15) {
            key = "15";
        } else if (diffDays > 5) {
            key = "5";
        } else if (diffDays > 1) {
            key = "1";
        } else {
            key = "0";
        }

        out.ip = ip;
        return {
            [key]: out
        };

    } catch (err) {
        errorIpsArr.push({
            [ip]: JSON.stringify(err)
        });
    }

}

async function db_calls(maindbInstance, dbName) {

    let response;
    try {
        let resp;
        if (dbName.indexOf('crm') > -1) {
            resp = await checkCRM(maindbInstance);
        } else {
            resp = await checkRetRest(maindbInstance)
        }
        if (resp.lastActiveTimestamp) {
            response = resp;

        } else {
            //check unittimestamp and send
            response = await getLastTimestampForDocType(maindbInstance, 'unit');
        }

        resp = await getLastTimestampForDocType(maindbInstance, 'customer');
        if (response.lastActiveTimestamp < resp.lastActiveTimestamp) {
            response = resp;
        }
        resp = await getLastTimestampForDocType(maindbInstance, 'supplier');
        if (response.lastActiveTimestamp < resp.lastActiveTimestamp) {
            response = resp;
        }
        resp = await getLastTimestampForDocType(maindbInstance, 'category');
        if (response.lastActiveTimestamp < resp.lastActiveTimestamp) {
            response = resp;
        }
        resp = await getLastTimestampForDocType(maindbInstance, 'tax');
        if (response.lastActiveTimestamp < resp.lastActiveTimestamp) {
            response = resp;
        }
        resp = await getLastTimestampForDocType(maindbInstance, 'subCategory');
        if (response.lastActiveTimestamp < resp.lastActiveTimestamp) {
            response = resp;
        }
        resp = await getLastTimestampForDocType(maindbInstance, 'discount');
        if (response.lastActiveTimestamp < resp.lastActiveTimestamp) {
            response = resp;
        }

        return response;

    } catch (err) {
        throw err;
    }
}

async function checkRetRest(maindbInstance) {
    let respSales = await checkSales(maindbInstance);
    let respPur = await checkPurchases(maindbInstance);

    if (respSales.lastActiveTimestamp > respPur.lastActiveTimestamp) {
        return respSales;
    } else {
        return respPur;
    }
}

async function checkPurchases(maindbInstance) {
    let params = {
        limit: 1,
        descending: true
    };

    let docsQueryResp = await maindbInstance.view('all_receivings_info', 'all_time', params);
    if (docsQueryResp[0].rows.length) {
        return {
            lastActiveTimestamp: docsQueryResp[0].rows[0].key,
            lastActiveDocId: docsQueryResp[0].rows[0].id
        };
    }

    return {
        lastActiveTimestamp: 0,
        lastActiveDocId: ''
    };
}

async function checkSales(maindbInstance) {
    let designDocName = 'all_sales_info';
    let viewName = "all_time";
    let params = {
        limit: 1,
        descending: true
    };

    let docsQueryResp = await maindbInstance.view(designDocName, viewName, params);

    if (docsQueryResp[0].rows.length) {
        return {
            lastActiveTimestamp: docsQueryResp[0].rows[0].key,
            lastActiveDocId: docsQueryResp[0].rows[0].id
        };
    }

    return {
        lastActiveDocId: '',
        lastActiveTimestamp: 0
    }

}

async function checkCRM(maindbInstance) {

    let lastActiveTimestamp = 0;
    let lastActiveDocId = '';
    const docTypeArr = ['cmp', 'schedule', 'wisher', 'autoreporter'];

    for (let i = 0; i < docTypeArr.length; i++) {
        let resp = await getLastTimestampForDocType(maindbInstance, docTypeArr[i]);
        if (resp.lastActiveTimestamp > lastActiveTimestamp) {
            lastActiveTimestamp = resp.lastActiveTimestamp;
            lastActiveDocId = resp.lastActiveDocId;
        }
    }

    return {
        lastActiveTimestamp: lastActiveTimestamp,
        lastActiveDocId: lastActiveDocId
    };

}

async function getLastTimestampForDocType(dbInstance, docType) {
    let params = {
        startkey: docType + '_',
        endkey: docType + '_z'
    };

    const docsQueryResp = await dbInstance.fetch({}, params);
    const length = docsQueryResp[0].rows.length;
    if (length) {
        const docId = docsQueryResp[0].rows[length - 1].id;
        let timestamp = docId.substr(docId.indexOf('_') + 1, docId.length);

        return {
            lastActiveTimestamp: parseInt(timestamp),
            lastActiveDocId: docId
        };
    }

    return {
        lastActiveTimestamp: 0,
        lastActiveDocId: ''
    };
}

function parseResults() {
    let arr60 = [];
    let arr45 = [];
    let arr30 = [];
    let allArr = [];

    for (let i = 0; i < results["60"].length; i++) {
        arr60.push(results["60"][i].ip);
        allArr.push(results["60"][i].ip);
    }

    for (let i = 0; i < results["45"].length; i++) {
        arr45.push(results["45"][i].ip);
        allArr.push(results["45"][i].ip);
    }

    for (let i = 0; i < results["30"].length; i++) {
        arr30.push(results["30"][i].ip);
        allArr.push(results["30"][i].ip);
    }

    fs.writeFileSync('60arr.json', JSON.stringify(arr60));
    fs.writeFileSync('45arr.json', JSON.stringify(arr45));
    fs.writeFileSync('30arr.json', JSON.stringify(arr30));
    fs.writeFileSync('allarr.json', JSON.stringify(allArr));
}

return iterateIps();

//which returns last active date.
//{60: [{ip: lastactivedoc, totaldocs:}], 45, 30, 15}
//60 days
//45 days
//30 days
//15 days
// have a json ip -> crm -> retail, restaurant, saloon 
// number of docs, sale, purchase, cmp, appointment
//autoreporter wisher schedule cmp
// unit doc