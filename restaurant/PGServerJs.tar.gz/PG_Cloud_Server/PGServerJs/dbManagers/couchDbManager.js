var couchDbMain = require('../couchDb/couchDBMain.js');

var couchDbManager = function() {
    var _self = this;

    this.initCouchDb = function(bDropAndRecreate, sId, bTrial, backUpLocation) {
        return couchDbMain.initAllCouchDBs(bDropAndRecreate, sId, bTrial, backUpLocation).then(function(resp) {
            console.log('Created all The couchDbs and its Views');
            return resp;
        }).catch(function(reason) {
            console.log(reason)
        });
    };

    this.dropAllCouchDBs = function(sId, bTrial, applicationSettings, backUpLocation) {
        return couchDbMain.dropAllCouchDBs(sId, bTrial, applicationSettings, backUpLocation).then(function() {
            console.log('Dropped all The couchDbs and its Views');

        }).catch(function(reason) {
            console.log(reason)
        });
    };

    this.compareDBs = function(sId) {
        return couchDbMain.compareDBs(sId).then(function(resp) {
            console.log('Difference calculated');
            return resp;
        }).catch(function(reason) {
            console.log(reason)
        });
    };

    this.grantFeaturesModuleUpdatePermission = function(appName) {
        appName = appName ? appName : process.env.APP_TYPE;
        var myFeatutres;

        return couchDbMain.initAllCouchDBs().then(function() {
            var featuresCouchHandler = require('../couchDb/featuresCouchHandler')(couchDbMain);
            var profitGuruAllFeatures = require('../config/profitguruCoreConfig/profitGuruAllowedFeatures.json');
            if (profitGuruAllFeatures.appSpecific && profitGuruAllFeatures.appSpecific[appName]) {
                var appSepecificFeatures = profitGuruAllFeatures.appSpecific[appName];
                delete profitGuruAllFeatures.appSpecific;
                myFeatutres = profitGuruAllFeatures;
                for (var feature in appSepecificFeatures) {
                    myFeatutres[feature] = appSepecificFeatures[feature]
                }
            }
            profitGuruAllFeatures.features = {
                "enabled": true,
                "desc": "This feature allows access to Features Modification"
            };
            return featuresCouchHandler.updateAllowedApplicationFeatures(appName, profitGuruAllFeatures);

        }).catch(function(reason) {
            console.log(reason)
        });
    };

};

module.exports = new couchDbManager();