/*
Read sql pouch data from profitguru temp
and inserts to couchdb
:dpk

npm install pouchdb
npm install pouchdb-adapter-websql
npm install pouchdb-adapter-node-websql

copy 1, 2, 3, 4 in the current folder
check INDBFILENAME [2-coredb, 3-maindb, 4-userdb], [1-license not required]

node pouchSQL2couch.js
*/
var INDBFILENAME = '2'; // change 2, 3, 4 for core, main and userdb

var PouchDB = require('pouchdb');
PouchDB.plugin(require('pouchdb-adapter-node-websql'));
var OUTDB = '';
switch (INDBFILENAME) {
    case '1':
        OUTDB = 'pg_collection_retail_licencedb';
        break;
    case '2':
        OUTDB = 'pg_collection_retail_coredb';
        break;
    case '3':
        OUTDB = 'pg_collection_retail_maindb';
        break;
    case '4':
        OUTDB = '_users';
        break;
}
if (!OUTDB || !INDBFILENAME) {
    console.log('db name not given');
    return;
} else {
    console.log('##');
    console.log(INDBFILENAME);
    console.log(OUTDB);
}
var db = new PouchDB(INDBFILENAME, {
    adapter: 'websql'
});

var couchdb = new PouchDB('couchadmin:test@http://localhost:5984/' + OUTDB);
db.allDocs().then(function(resp) {
    // console.log(resp);
    for (let i = 0; i < resp.rows.length; i++) {
        if (resp.rows[i].id.indexOf('_design') > -1) continue;
        // console.log(resp.rows[i].id);
        db.get(resp.rows[i].id).then(async function(data) {
            couchdb.get(resp.rows[i].id).then(function(existingData) {
                // update
                let rev = existingData._rev;
                data._rev = rev;
                couchdb.put(data).then(function(res) {
                    console.log(res);
                }).catch(function(err) {
                    console.log(err);
                });
            }).catch(function(err) {
                // insert
                couchdb.put(data).then(function(res) {
                    console.log(res);
                }).catch(function(err) {
                    console.log(err);
                });
            })

        }).catch(function(err) {
            console.log('err reding doc');
            console.log(err);
        });
    }
}).catch(function(error) {
    console.log(error);
})