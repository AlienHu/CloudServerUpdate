require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .alias('t', 'type')
    .describe('t', 'run query')
    .demand('t')
    .alias('n', 'name')
    .default('n', '')
    .describe('n', 'migration name example 20170311001304-version-0.js')
    .help('h')
    .alias('h', 'help')
    .argv;

function run() {
    if (argv.type === 'run') {
        var migrationHandler = require('../couchDb/migrationHandler');
        return migrationHandler.migrate(argv.n).then(function() {
            process.exit(0);
        }).catch(function(error) {
            process.exit(0);
        });
    }

    if (argv.type === 'query') {
        var umzugUtils = require('../common/umzugUtils')();
        let migrationsBasePath = __dirname + '/../couchDBMigrations';
        console.log(umzugUtils.getLatestMigrationName(migrationsBasePath));
    }
}
run();