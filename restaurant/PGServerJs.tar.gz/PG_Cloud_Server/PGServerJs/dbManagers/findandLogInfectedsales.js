'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const fs = require('fs');
const moment = require('moment');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const userdb = couchDBUtils.getUserCouchDB();
const utils = require('../controllers/common/Utils');
const CLONE = utils.clone;
let saleItemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
let purchaseItemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
let SalesInfoFields = ['_id', 'num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts'];
let saleReturnInfoFields = ['_id', 'num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts'];
let PurInfoFields = ['_id', 'receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
let PurReturnInfoFields = ['_id', 'time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];

let allItems, allCategories, allCustomers, allEmployees, allSales, allSalesReturns, allPurchase, allRecivingReturns;

// let updateItems, updateCategories, updateCustomers, updateEmployees, allUpdatedSale, allUpdatedSaleReturn, allUpdatedPurchase, allUpdatedRecivingReturns;
let errorsArray = [];
let errorsPurArray = [];

printInfectedIds();
async function printInfectedIds() {
    await getAlldocs();
    await iterateSales();
    await iteratePurchases();
    await writeAllInfectedIds();
    process.exit(0);
};
async function getAlldocs() {
    // allItems = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
    // allCategories = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
    // allCustomers = await couchDBUtils.getAllDocsByType('customer', mainDBInstance);
    // allEmployees = await couchDBUtils.getAllDocsByType('org.couchdb.user:', userdb);
    allSales = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
    allSalesReturns = await couchDBUtils.getAllDocsByType('saleReturn', mainDBInstance);
    allPurchase = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance);
    allRecivingReturns = await couchDBUtils.getAllDocsByType('receivingReturn', mainDBInstance);
    //    console.log(allItems, allCategories, allCustomers, allEmployees)
};
async function iterateSales() {
    allSales.forEach(function(sale, index) {
        let tempItems = sale.doc.sale_items;
        tempItems.forEach(function(item, index) {
            let splitedArray = item.split(';');
            if ((saleItemFields.length + 1) !== splitedArray.length) {
                errorsArray.push('<sale  id:' + sale.doc._id + '> <index:' + index + '>');
            }
        });
        let splitedSalesDoc = sale.doc.sales_info.split(';');
        if ((SalesInfoFields.length + 1) !== splitedSalesDoc.length) {
            errorsArray.push('Sales Error : <sale  id:' + sale.doc._id + '> \n');
        }
    });
    allSalesReturns.forEach(function(sale, index) {
        let tempItems = sale.doc.items;
        tempItems.forEach(function(item, index) {
            let splitedArray = item.split(';');
            if ((saleItemFields.length + 1) != splitedArray.length) {
                errorsArray.push('<Sale return  id:' + sale.doc._id + '> <index:' + index + '>');
            }
        });
        let splitedSalesDoc = sale.doc.info.split(';');
        if ((saleReturnInfoFields.length + 1) !== splitedSalesDoc.length) {
            errorsArray.push('Sales Error : <sale  id:' + sale.doc._id + '> \n');
        }
    });
};

async function iteratePurchases() {
    allPurchase.forEach(function(purchase, index) {
        let tempPurItem = purchase.doc.receiving_items;
        tempPurItem.forEach(function(item, index) {
            let splitedPurArray = item.split(';');
            if ((purchaseItemFields.length + 1) != splitedPurArray.length) {
                errorsPurArray.push('<Purchase  id:' + purchase.doc._id + '> <index:' + index + '>');

            }
        });
        let splitedSalesDoc = purchase.doc.receivings_info.split(';');
        if ((PurInfoFields.length + 1) !== splitedSalesDoc.length) {
            errorsPurArray.push('Purchase Error : <Purchase  id:' + purchase.doc._id + '> \n');
        }
    });
    allRecivingReturns.forEach(function(purchase, index) {
        let tempPurItem = purchase.doc.items;
        tempPurItem.forEach(function(item, index) {
            let splitedPurArray = item.split(';');
            if ((purchaseItemFields.length + 1) != splitedPurArray.length) {
                errorsPurArray.push('<Purchase return  id:' + purchase.doc._id + '> <index:' + index + '>');
            }
        });
        let splitedSalesDoc = purchase.doc.info.split(';');
        if ((PurReturnInfoFields.length + 1) !== splitedSalesDoc.length) {
            errorsPurArray.push('Purchase Return Error : <Purchase  id:' + purchase.doc._id + '> \n');
        }
    });
};
async function writeAllInfectedIds() {
    let errorString;
    // let filename = 'Infected_' + moment().format('DD-MM-YYYY') + ' ' + moment().format('LTS') + '.txt'
    let filename = __dirname + '\\..\\logs\\infcteded' + moment().unix() + '.txt';
    console.log(filename);
    errorsArray.forEach(function(item) {
        errorString += item
    });
    errorsPurArray.forEach(function(item) {
        errorString += item
    });
    fs.writeFileSync(filename, errorString);
    console.log("success");

}