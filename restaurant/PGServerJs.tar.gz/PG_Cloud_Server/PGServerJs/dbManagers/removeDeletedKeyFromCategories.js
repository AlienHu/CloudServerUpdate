'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();

async function run() {

    let resp = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
    let updateDocs = [];
    for (let i = 0; i < resp.length; i++) {
        let thisCategory = resp[i].doc;
        if (thisCategory.deleted) {
            delete(thisCategory.deleted);
            updateDocs.push(thisCategory);
        }
    }
    if (updateDocs.length) {
        console.log("found: " + updateDocs.length);
        const resp = await couchDBUtils.bulkDocs(updateDocs, mainDBInstance);
        console.log(resp);
    } else {
        console.log("No Categories found with positive deleted");
    }
}

run().then(() => {
    // process.exit(0);
});