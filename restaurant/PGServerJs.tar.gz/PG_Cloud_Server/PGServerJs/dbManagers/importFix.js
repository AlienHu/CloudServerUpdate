require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .alias('s', 'cleanSalesInfo')
    .default('s', true)
    .alias('p', 'cleanPurchaseInfo')
    .default('p', true)
    .help('h')
    .alias('h', 'help')
    .argv;

var curSession = {};
var applicationSettings = {};
const logger = require('../common/Logger');
var couchDBUtils = require('../controllers/common/CouchDBUtils');

var mainDBInstance = couchDBUtils.getMainCouchDB();

async function updateDocs() {
    try {

        let itemDocs = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
        let docsToUpdate = [];
        for (let j = 0; j < itemDocs.length; j++) {
            for (let idx in itemDocs[j].doc.batches) {
                itemDocs[j].doc.batches[idx].purchasePrice = itemDocs[j].doc.batches[idx].purchasePrice === 0 ? itemDocs[j].doc.info.purchasePrice : itemDocs[j].doc.batches[idx].purchasePrice;
                itemDocs[j].doc.batches[idx].mrp = itemDocs[j].doc.batches[idx].mrp === 0 ? itemDocs[j].doc.info.mrp : itemDocs[j].doc.batches[idx].mrp;
            }

            docsToUpdate.push(itemDocs[j].doc);
        }
        let updateItemsResp = await couchDBUtils.bulkInsert(mainDBInstance, docsToUpdate);
        let saleDocsToUpdate = [];
        let allItemDocs = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
        let saleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);

        if (saleDocs.length !== 0) {
            for (let l = 0; l < saleDocs.length; l++) {
                for (var m = 0; m < saleDocs[l].doc.sale_items.length; m++) {
                    if (saleDocs[l].doc.sale_items[m].purchasePrice === 0 && saleDocs[l].doc.sale_items[m]) {
                        for (var n = 0; n < allItemDocs.length; n++) {
                            if (allItemDocs[n].doc.item_id === saleDocs[l].doc.sale_items[m].item_id) {
                                saleDocs[l].doc.sale_items[m].purchasePrice = allItemDocs[n].doc.batches[saleDocs[l].doc.sale_items[m].stockKey].purchasePrice;
                                saleDocs[l].doc.sale_items[m].mrp = allItemDocs[n].doc.batches[saleDocs[l].doc.sale_items[m].stockKey].mrp;
                            }
                        }
                    }

                }
                saleDocsToUpdate.push(saleDocs[l].doc);
                // if(saleDocs[i].doc.sale_items)
                // saleDocs[i].doc._deleted = true;
                // saleDocsToUpdate.push(saleDocs[i].doc);
            }
        }
        let updateResp = await couchDBUtils.bulkInsert(mainDBInstance, saleDocsToUpdate);
        logger.info('Sales Done!!');
        return;
    } catch (error) {
        logger.error(error);
        throw 'ResetSalesInfo Failed';
    }
}

let promisesArray = [];
promisesArray.push(updateDocs());

function run() {
    return Promise.all(promisesArray).then(function() {
        process.exit(0);
    }).catch(function(error) {
        process.exit(1);
    })
}
run();
// });