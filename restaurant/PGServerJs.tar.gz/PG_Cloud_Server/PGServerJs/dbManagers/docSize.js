let appName = 'retail'; //retail
let dbSufix = 'maindb';
let localDbName = 'pg_collection_' + appName + '_' + dbSufix;

return run();

async function run() {
    let db = require('nano-blue')("http://couchadmin:test@127.0.0.1:5984/" + localDbName);
    try {
        // let docs = await mainDB.get('sale_29');
        // let doc = await mainDB.get('sale_29');
        let params = {};
        let type = 'sale'
        params.startkey = type + '_';
        params.endkey = type + '_z';
        params.include_docs = true;

        return db.fetch({}, params).spread(function(body, header) {
            let resp = [];
            for (let i = 0; i < body.rows.length; i++) {
                resp.push(body.rows[i].doc);
            }
            let docSize = memorySizeOf(resp);
            console.log(docSize);
            // return resp;

        }).catch(function(err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        });

    } catch (error) {
        console.log('Failed to delete local db');
    }

}

function memorySizeOf(obj) {
    var bytes = 0;

    function sizeOf(obj) {
        if (obj !== null && obj !== undefined) {
            switch (typeof obj) {
                case 'number':
                    bytes += 8;
                    break;
                case 'string':
                    bytes += obj.length * 2;
                    break;
                case 'boolean':
                    bytes += 4;
                    break;
                case 'object':
                    var objClass = Object.prototype.toString.call(obj).slice(8, -1);
                    if (objClass === 'Object' || objClass === 'Array') {
                        for (var key in obj) {
                            if (!obj.hasOwnProperty(key)) continue;
                            sizeOf(obj[key]);
                        }
                    } else bytes += obj.toString().length * 2;
                    break;
            }
        }
        return bytes;
    };

    function formatByteSize(bytes) {
        if (bytes < 1024) return bytes + " bytes";
        else if (bytes < 1048576) return (bytes / 1024).toFixed(3) + " KiB";
        else if (bytes < 1073741824) return (bytes / 1048576).toFixed(3) + " MiB";
        else return (bytes / 1073741824).toFixed(3) + " GiB";
    };

    return formatByteSize(sizeOf(obj));
};