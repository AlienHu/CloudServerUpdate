/*
THIS SCRIPT IS NOT GENERIC
- db reset required
- valid format required
*/

(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../.env',
        sample: __dirname + '/../env.example'
    });

    const couchDbManager = require('../dbManagers/couchDbManager');
    const couchDBUtils = require('../controllers/common/CouchDBUtils');
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const globalConfigController = require('../controllers/GlobalConfigurations');

    var csv = require('csvtojson');
    var itemArray = [];
    csv()
        .fromFile(__dirname + '/saloon_Packages_1.csv')
        .on('json', (jsonObj) => {
            itemArray.push(jsonObj);
        })
        .on('done', (error) => {
            console.log('rows found from csv: ' + itemArray.length);
            if (error) {
                console.log('error in reading csv');
                console.log(error);
                return;
            }
            return run();
        });
    var bulkArray = [];

    async function createItemArray() {
        let itemController = require('../controllers/Items');
        console.log('creating item started...');

        for (let iteration = 0; iteration < 2; iteration++) {
            for (let i = 0; i < itemArray.length; i++) {
                if (isDependencyItemType(getItemType(itemArray[i]['Item Type'])) == !iteration) { // create dependency item first
                    let item = {
                        _id: 'item_' + (i + 1),
                        id: i + 1,
                        ItemType: await getItemType((itemArray[i]['Item Type'])),
                        bPPTaxInclusive: await getFormattedFBoolean(itemArray[i]['PP Tax Inclusive']),
                        brandName: await filterNAData(itemArray[i]['Brand Name']),
                        bSPTaxInclusive: await getFormattedFBoolean(itemArray[i]['SP Tax Inclusive']),
                        categoryId: await getId(itemArray[i].category, 'category'),
                        // conversionFactor: itemArray[i].conversionFactor ? parseInt(itemArray[i].conversionFactor) : 1,
                        conversionFactor: 1, //manually setting 1
                        name: await filterNAData(itemArray[i]['Name']),
                        // discount: await getId(await removePercenet(itemArray[i].discount), 'discount'),
                        batchId: parseInt(itemArray[i]['BatchId'] ? itemArray[i]['BatchId'] : 0),
                        hasBatchNumber: await getFormattedFBoolean(itemArray[i]['Has BatchNumber']),
                        hsn: await filterNAData(itemArray[i]['HSN']),
                        description: "",
                        mrp: parseFloat(itemArray[i].MRP ? itemArray[i].MRP : 0),
                        purchasePrice: parseFloat(itemArray[i]['Purchase Price'] ? itemArray[i]['Purchase Price'] : 0),
                        // purchaseTaxes: [await getTax(await removePercenet(itemArray[i]['purchase tax']))],
                        purchaseTaxes: [],
                        purchaseUnitId: await getId(itemArray[i]['Purchase Unit Name'], 'unit'),
                        quantity: itemArray[i].quantity ? parseInt(itemArray[i].Quantity) : 0,
                        reorderLevel: itemArray[i].reorderLevel ? parseInt(itemArray[i].reorderLevel) : 0,
                        sellingPrice: parseFloat(itemArray[i]['SELLING PRICE'] ? itemArray[i]['SELLING PRICE'] : 0),
                        // salesTaxes: [await getTax(await removePercenet(itemArray[i]['SP Tax Inclusive%']))],
                        salesTaxes: [],
                        // sellingUnitId: await getId(itemArray[i]['SELLING UNIT NAME'], ''), // doing after loop
                        supplier_id: await getId(itemArray[i].supplier, 'supplier'),
                        receiving_quantity: 0,
                        hasExpiryDate: false,
                        hasVariants: false,
                        is_serialized: false,
                        imeiCount: 0
                    }
                    item.sellingUnitId = item.purchaseUnitId;
                    let batchParam = {
                        batchId: item.batchId,
                        expiry: null,
                        uniqueDetails: [],
                        purchasePrice: item.purchasePrice,
                        sellingPrice: item.sellingPrice,
                        mrp: item.mrp,
                        quantity: item.quantity,
                        discountId: item.discount
                    }
                    item.initialStock = [batchParam];

                    let requiredFields = ["name", "uniqueItemCode", "description", "purchasePrice", "sellingPrice", "mrp", "reorderLevel", "reorderQuantity", "is_serialized", "imeiCount", "isprepared", "issellable", "isbought", "hasExpiryDate", "conversionFactor", "discountId", "hasBatchNumber", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive", "hasVariants", "attributes", "ItemType", "hsn", "salesSlab", "purchaseSlab", "density", "quantity"];
                    for (let r = 0; r < requiredFields.length; r++) {
                        item[requiredFields[r]] = (item[requiredFields[r]] !== undefined) ? item[requiredFields[r]] : "";
                    }
                    if (iteration) {
                        let services = await getServiceForPackage(item.name);
                        item.services = services;
                    }
                    try {
                        await itemController.createItem(item);
                        console.log((i + 1) + '. ' + item.name + ' created succesfully');
                    } catch (err) {
                        console.log((i + 1) + '. ' + item.name + ' creation failed');
                        console.error(err);
                    }
                    // bulkArray.push(item);
                }
            }
        }

    }

    function getItemType(type) {
        if (!type) type = 'Normal';
        let types = ['Normal', 'Service', 'Package', 'Membership'];
        for (let i = 0; i < types.length; i++) {
            if (types[i].toLowerCase() === type.toLowerCase()) return types[i];
        }
        return 'Normal'; // no need
    }

    function getIndexOfDelimeters(text, symbol) {
        let indices = [];
        for (let i = 0; i < text.length; i++) {
            if (text[i] === symbol) indices.push(i);
        }
        return indices;
    }

    function commaSeperatedValuesFromCell(cellValue) {
        let commaIndices = getIndexOfDelimeters(cellValue, ',');
        if (!commaIndices || !commaIndices.length) return [cellValue];
        let values = [];
        let lastTrackedIndex = 0;
        for (let i = 0; i < commaIndices.length + 1; i++) {
            let thisValue = cellValue.substr(lastTrackedIndex, (commaIndices[i] - lastTrackedIndex) ? (commaIndices[i] - lastTrackedIndex) : cellValue.length);
            let formattedValue = removeCommaAndSpace(thisValue);
            if (formattedValue) values.push(formattedValue);
            lastTrackedIndex = commaIndices[i];
        }
        return values;
    }

    function removeCommaAndSpace(value) {
        value = value.trim();
        if (value[0] === ',') value = value.toString().substr(1, value.length);
        value = value.trim();
        return value;
    }

    function isDependencyItemType(itemType) {
        //todo: which has has more priority membership or package
        let types = ['Service', 'Normal'];
        for (let i = 0; i < types.length; i++) {
            if (itemType === types[i]) return true;
        }
        return false;
    }

    async function getPackageIdByIndex(index) {
        let itemDoc = await couchDBUtils.getDoc('item_' + index, mainDBInstance);
        console.log(itemDoc);
        return itemDoc.info;
    }

    async function handleMultipleUnis(delimitedString, defaultUnit) {
        if (!delimitedString) return "";
        let units = delimitedString.split("/");
        let resp = {};
        let id = "";
        for (let j = 0; j < units.length; j++) {
            resp = await getId(units[j], 'unit');
            if (defaultUnit == units[j]) return resp;
        }
    }

    async function formatId(id) {
        let index = id.toString().indexOf('_');
        return parseInt(id.substr(index + 1));
    }
    async function getTax(tax) {
        let resp = {};
        let id = ""
        try {
            resp = await couchDBUtils.getAllDocsByType('tax', mainDBInstance);
        } catch (err) {
            console.error(err);
        }
        for (let i = 0; i < resp.length; i++) {
            if (resp[i].doc.percent == tax) {
                id = resp[i].doc.id;
            }
        }
        return id;
    }

    async function getServiceForPackage(packageName) {
        let services = [];
        for (let i = 0; i < itemArray.length; i++) {
            let itemPackageNames = itemArray[i]['Package Name'];
            let packages = commaSeperatedValuesFromCell(itemPackageNames);
            for (let j = 0; j < packages.length; j++) {
                if (packages[j] === packageName) {
                    let itemDoc = await getPackageIdByIndex(i);
                    services.push(itemDoc);
                }
            }
        }
        return services;
    }

    async function getId(string, type) {
        let id = undefined;
        let foo = '';
        let resp = {};
        if (type === 'category') {
            foo = 'createCategory';
        } else if (type === 'unit') {
            foo = 'createUnit';
        } else if (type === 'discount') {
            foo = 'createDiscount';
        } else if (type === 'supplier') {
            foo = 'createSupplier';
            // return createSupplier(string);
        }
        let params = {};

        try {
            resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
        } catch (err) {
            console.error(err);
        }
        // resp = await globalConfigController.getAll(type);
        for (let i = 0; i < resp.length; i++) {
            if (resp[i].doc.name == string || (type == 'discount' && resp[i].doc.discount == string) || (type == 'supplier' && resp[i].doc.company_name == string)) {
                id = await formatId(resp[i].doc._id);
            }
        }
        if (!id) { //not matched

            let doc;
            if (type === 'category') {
                doc = {
                    name: string,
                    type: type + '_',
                    description: '',
                    id: Date.now()
                };
                doc._id = doc.type + doc.id;
            } else if (type === 'unit') {
                doc = {
                    name: string,
                    type: type + '_',
                    shortName: '',
                    id: Date.now()
                }
                doc._id = doc.type + doc.id;
            } else if (type === 'discount') {
                doc = {
                    type: type + '_',
                    discount: string,
                    name: 'D',
                    id: Date.now()
                }
                doc._id = doc.type + doc.id;
            } else if (type === 'supplier') {
                doc = {
                    "company_name": string,
                    "agency_name": string,
                    "first_name": string,
                    "last_name": string,
                    "gender": "0",
                    "email": "admin@alienhu.com",
                    "phone_number": "5000000000",
                    "address_1": "",
                    "address_2": "",
                    "city": "",
                    "state": "Madhya Pradesh",
                    "zip": "",
                    "country": "",
                    "comments": "",
                    "credit_balance": 0,
                    "credit_limit": 1000,
                    "pan_number": "",
                    "allow_credit": "Allow",
                    "payment_terms": "months",
                    "by_months": 1,
                    "state_name": "MADHYAPRADESH",
                    "pin_code": "",
                    "type": "supplier_",
                    "total": 0,
                    "person_id": Date.now()
                }
                doc._id = doc.type + doc.person_id;
            }
            try {
                // if (type == 'supplier') {
                resp = await couchDBUtils.create(doc, mainDBInstance);
                // return await formatId(resp[0].id);
                id = await formatId(resp[0].id);
                // }
                // resp = await globalConfigController[foo](doc);
                // id = resp.id;
            } catch (error) {
                console.error(error);
            }
        }
        return id;
    }

    async function filterNAData(data) {
        data = (data == 'N/A' || data === undefined || data === null) ? "" : data;
        return data;
    }
    async function getFormattedFBoolean(data) {
        data = data ? data : "false";
        let index = data.indexOf("true") >= 0;
        index = index || (data.indexOf("yes") >= 0);
        return index;
    }
    async function removePercenet(data) {
        if (!data) data = '0';
        let isDirty = data.indexOf('%');
        if (isDirty >= 0) {
            data = data.substr(0, isDirty);
        }
        return data;
    }

    async function deleteType(type) {
        let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
        console.log(type + ' <' + resp.length + '> found');
        let bulkDocs = [];
        for (let i = 0; i < resp.length; i++) {
            resp[i].doc._deleted = true;
            bulkDocs.push(resp[i].doc);
        }

        if (bulkDocs.length) {
            await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
        }
    }

    async function deleteHandler() {
        console.log('cleaning up started');
        await deleteType('item');
        await deleteType('category');
        await deleteType('inventory');
        console.log('cleaning up done.');
    }

    async function run() {
        await couchDbManager.initCouchDb(false);
        await deleteHandler();
        await createItemArray();
        console.log('import of items done.');
        process.exit(0);
    }
})();