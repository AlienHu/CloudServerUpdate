const fs = require('fs');
const httpUtils = require("../common/httpUtils")
const commonUtils = require("../common/Utils")

testApi();
async function testApi() {
    // await correctSaleIds();
    await callApiAndCheckResponse();
    process.exit(0);
}

async function callAndTestApi(arrFileNames) {

    try {
        if (arrFileNames.method == 'GET') {
            try {
                const response = await httpUtils.httpGet(arrFileNames.api)
                const bResposeCorrect = commonUtils.compareObject(arrFileNames.response, response.body);
                console.log('compared response ' + bResposeCorrect + ' response is ' + response.body);

            } catch (err) {
                console.error(err);
            }
        } else {
            try {
                if (!arrFileNames.requestParam) {
                    arrFileNames.requestParam = {};
                }
                const response = await httpUtils.httpPost(arrFileNames.api, arrFileNames.requestParam);
                console.log(response);
                const bResposeCorrect = commonUtils.compareObject(arrFileNames.response, response.body);
                console.log('compared response ' + bResposeCorrect + ' response is ' + response);

            } catch (err) {
                console.error(err);
            }

        }

    } catch (error) {
        console.log(error);
    }

}

async function readFileAndcallApi(arrFileNames) {
    const path = __dirname + '/../../profitGuruDAPP/' + 'ApiLogs/';

    if (!arrFileNames.length) {
        return;
    }
    try {
        for (var i = 0; i < arrFileNames.length; i++) {
            var apiInfo = JSON.parse(fs.readFileSync(path + fileName, 'utf8'));
            await (apiInfo);
        }
    } catch (err) {}

}

async function readFileAndcallApi(arrFileNames) {
    const path = __dirname + '/../../profitGuruDAPP/' + 'ApiLogs/';

    if (!arrFileNames.length) {
        return;
    }
    try {
        for (var i = 0; i < arrFileNames.length; i++) {
            var apiInfo = JSON.parse(fs.readFileSync(path + arrFileNames[i], 'utf8'));
            await callAndTestApi(apiInfo);
        }
    } catch (err) {}

}

async function callApiAndCheckResponse() {
    try {
        const apiFiles = await getApiLogsFile();
        await readFileAndcallApi(apiFiles);
    } catch (error) {
        console.log(error);
    }

}
async function getApiLogsFile() {
    const path = __dirname + '/../../profitGuruDAPP/' + 'ApiLogs';
    // JSON.parse(fs.readFileSync(, 'utf8')).then(function(resp) {
    //     return resp;
    // }).catch(function() {
    //     throw 'No File Or Folder Of Api Logs';
    // })
    let arrFileNames = []
    try {
        fs.readdirSync(path).forEach(file => {
            arrFileNames.push(file);
        })
        return arrFileNames;
    } catch (err) {
        throw 'No ApiLogs Folder Found'
    }

}