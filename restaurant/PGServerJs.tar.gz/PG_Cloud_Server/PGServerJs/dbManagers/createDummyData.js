'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDbManager = require('./couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const utils = require('../controllers/common/Utils');
const moment = require('moment');
const CLONE = utils.clone;
var faker = require('faker');
faker.locale = 'en_IND';

cleanTransactions();
async function cleanTransactions() {
    // await createSalesDocs();
    await createItems();

    process.exit(0);
}

function randomDate(start, end) {
    return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}
// let itemNames = ["patanjali herbal facial foam 60g","container 3no","dove hair therapy"];
// let categories = ["facial foam","container"];

async function createItems() {
    let itemControllers = require('../controllers/Items');
    let itemCount = 50;
    let offset = 151;
    let promiseArray = [];
    var itemJson = {
        "uniqueItemCode": "",
        "name": "",
        "item_number": "",
        "receiving_quantity": 0,
        "reorder_level": 0,
        "description": "",
        "expiry_date": "",
        "allow_alt_description": "0",
        "ItemType": "",
        "categoryId": 1543227314691,
        "purchasePrice": "",
        "sellingPrice": "",
        "mrp": "",
        "hasMeasurementUnit": false,
        "is_serialized": false,
        "hasExpiryDate": false,
        "purchaseTaxes": [],
        "salesTaxes": [],
        "reorderLevel": "",
        "reorderQuantity": "",
        "isNewBatch": false,
        "hasBatchNumber": false,
        "bOTG": false,
        "bPPTaxInclusive": false,
        "bSPTaxInclusive": false,
        "imeiCount": 0,
        "imeNumbers": [],
        "initialStock": [{
            "quantity": 0,
            "expiry": null,
            "uniqueDetails": [],
            "unitsInfo": {
                "1543044850046": {
                    "refUnitId": 1543044850046,
                    "factor": 1,
                    "purchasePrice": 100,
                    "mrp": 300,
                    "pProfilesData": {
                        "1543060926258": {
                            "sellingPrice": 200,
                            "discountId": ""
                        }
                    }
                }
            }
        }],
        "unitsInfo": {
            "1543044850046": {
                "refUnitId": 1543044850046,
                "factor": 1,
                "purchasePrice": 100,
                "mrp": 300,
                "pProfilesData": {
                    "1543060926258": {
                        "sellingPrice": 200,
                        "discountId": ""
                    }
                }
            }
        },
        "hasVariants": false,
        "density": 0,
        "pricingProfiles": false,
        "multipleUnits": false,
        "itemNprice": 0,
        "baseUnitId": 1543044850046,
        "defaultPurchaseUnitId": 1543044850046,
        "defaultSellingUnitId": 1543044850046,
        "convPurchasePrice": "",
        "attributes": [],
        "isprepared": false,
        "issellable": false,
        "isbought": false,
        "is_deleted": "",
        "discount_expiry": null
    }
    /**
     * ,
        "subCategories": [{
            "id": 1543227217176,
            "name": "sub-1"
        }, {
            "id": 1543227222953,
            "name": "sub-2"
        }],
        "subCategoryId": 1543227222953
     */
    for (let i = offset; i < (offset + itemCount); i++) {
        if (i % 10 === 0) console.log(i + ' Items So far')
        let itemData = CLONE(itemJson);
        itemData.name = 'items' + i // faker.commerce.productName();
        // promiseArray.push(itemControllers.createItem(itemData));
        let itemResp = itemControllers.createItem(itemData, i);
        await itemResp;
    }
    // return await Promise.all(promiseArray);

}
async function createSalesDocs() {
    var saleDoc = {
        "_id": "sale_SALEID",
        "sale_id": 'SALEID',
        "sales_info": "sale_SALEID;SALENUM;POS ;1;SALEDATE;;;;1507901660584;ganesh; bbb bbbb;ganesh mogare;;;;304;253.38983050847457;{\"CGST\":25.31,\"SGST\":25.31,\"Total\":50.62};{\"18\":{\"taxable\":203.38983050847457,\"CGST\":18.30508474576271,\"SGST\":18.30508474576271},\"28\":{\"taxable\":50,\"CGST\":7,\"SGST\":7}};230.17306673728814;23.216763771186436;4;0;;;0;1;;;none;;{\"amt\":0,\"percent\":0,\"discountMethod\":\"onTotal\"};;1525670022645;;0;0;",
        "payments": "[{\"payment_type\":\"Cash\",\"payment_amount\":304,\"returnAmt\":0}]",
        "sale_items": ["patanjali herbal facial foam 60g;facial foam;;1085;;Normal;id_1085_batch_1506751583359;;;;1506179428731;1506179428731;{\"1506179428731\":{\"refUnitId\":1506179428731,\"factor\":1,\"pProfilesData\":{\"1525670022645\":{\"sellingPrice\":60}},\"purchasePrice\":42.61,\"mrp\":60}};1;1;0;0;33.2890625;60;60;1;true;true;{\"CGST\":6.562500000000001,\"SGST\":6.562500000000001,\"Total\":13.125000000000002};[{\"name\":\"CGST\",\"percent\":14},{\"name\":\"SGST\",\"percent\":14}];;;India;[];[];;;60;46.875;33.2890625;13.5859375;[];;", "container 3no;container;;1267;;Normal;id_1267_batch_1506917672185;;;;1506179428731;1506179428731;{\"1506179428731\":{\"refUnitId\":1506179428731,\"factor\":1,\"pProfilesData\":{\"1525670022645\":{\"sellingPrice\":120}},\"purchasePrice\":115,\"mrp\":120}};2;1;0;0;97.45762711864407;120;120;1;true;true;{\"CGST\":9.152542372881355,\"SGST\":9.152542372881355,\"Total\":18.30508474576271};[{\"name\":\"CGST\",\"percent\":9},{\"name\":\"SGST\",\"percent\":9}];;;India;[];[];;;120;101.69491525423729;97.45762711864407;4.237288135593218;[];;", "container 2;container;;1268;;Normal;id_1268_batch_1506917764537;;;;1506179428731;1506179428731;{\"1506179428731\":{\"refUnitId\":1506179428731,\"factor\":1,\"pProfilesData\":{\"1525670022645\":{\"sellingPrice\":120}},\"purchasePrice\":115,\"mrp\":120}};3;1;0;0;97.45762711864407;120;120;1;true;true;{\"CGST\":9.152542372881355,\"SGST\":9.152542372881355,\"Total\":18.30508474576271};[{\"name\":\"CGST\",\"percent\":9},{\"name\":\"SGST\",\"percent\":9}];;;India;[];[];;;120;101.69491525423729;97.45762711864407;4.237288135593218;[];;", "dove hair therapy;container;;2050;;Normal;id_2050_batch_1509195727848;;;;1506179428731;1506179428731;{\"1506179428731\":{\"refUnitId\":1506179428731,\"factor\":1,\"pProfilesData\":{\"1525670022645\":{\"sellingPrice\":4}},\"purchasePrice\":2.52,\"mrp\":4}};4;1;0;0;1.96875;4;4;1;true;true;{\"CGST\":0.43750000000000006,\"SGST\":0.43750000000000006,\"Total\":0.8750000000000001};[{\"name\":\"CGST\",\"percent\":14},{\"name\":\"SGST\",\"percent\":14}];;;India;[];[];;;4;3.125;1.96875;1.15625;[];;"],
        "status": {
            "status": 0,
            "inventoryTrans": {
                "inventory_1085": {
                    "status": 0
                },
                "inventory_1267": {
                    "status": 0
                },
                "inventory_1268": {
                    "status": 0
                },
                "inventory_2050": {
                    "status": 0
                }
            },
            "customers": {
                "customer_1507901660584": {
                    "status": 0,
                    "v": 1
                }
            }
        }
    }

    var startId = 12000;
    var count = 20000;
    var num = 12000;
    var ts = moment(randomDate(new Date(2012, 0, 1), new Date())).format('x');

    for (let i = 0; i < count; i++) {
        ts = moment(randomDate(new Date(2012, 0, i), new Date())).format('x');
        let id = startId + i;
        num = num + i;
        saleDoc.sales_info = saleDoc.sales_info.replace(/SALEID/g, id);
        saleDoc.sales_info = saleDoc.sales_info.replace("SALENUM", num);
        saleDoc.sales_info = saleDoc.sales_info.replace("SALEDATE", ts);
        saleDoc._id = 'sale_' + id;
        saleDoc.sale_id = id;

        await couchDBUtils.create(saleDoc, mainDBInstance, 3, 'Sales Transaction Failed. Try Again');
        if (i % 1000 === 0) {
            console.log(i + ' Done');
        }
    }

}

//"function(doc, req) {    var doctype, uidx;    if (doc._id && (uidx = doc._id.indexOf('_')) > 0) {        doctype = doc._id.substring(0, uidx);        if (doctype === 'item' || doctype === 'inventory' || doctype ==='category' || doctype ==='unit' || doctype ==='discount' || doctype ==='tax' || doctype ==='variant') {            return true;        }    }    return false;}"

//delete items
//delete supplier