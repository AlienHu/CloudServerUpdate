pm2 start cleanTrialCouch.sh  --cron "* 0 * * 0"
#25 15 * * 0 pm2 start cleanTrialCouch.sh