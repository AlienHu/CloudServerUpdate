var couchDbManager = require('./couchDbManager.js');

module.exports = {
    couchDbManager: couchDbManager
};