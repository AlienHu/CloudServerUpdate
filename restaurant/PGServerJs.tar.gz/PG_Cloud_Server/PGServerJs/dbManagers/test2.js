'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDbManager = require('./couchDbManager');

async function test() {
    console.log('hello1');
    await couchDbManager.initCouchDb(false);
    ''
    var couchUtils = require('../controllers/common/CouchDBUtils');
    let userdbInstance = couchUtils.getUserCouchDB();
    console.log('hello2');
    try {
        console.log('hello3');
        let resp = await couchUtils.getView('employees', 'all', {}, userdbInstance);
        console.log('hello4');
        // let resp = await couchUtils.getAllDocsByType('org.user.couchdb', userdbInstance);
        console.log(resp);
    } catch (error) {
        console.log(error);
    }
}

console.log('testing');

function runClean() {
    return test();
}
runClean();