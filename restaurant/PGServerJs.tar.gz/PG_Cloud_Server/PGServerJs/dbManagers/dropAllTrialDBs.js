const nano = require("nano-blue")("http://couchadmin:test@51.15.213.105:5984");

let deletedDbs = [];
let failedDBs = [];
let skippedDBs = [];

const getAllDBs = async () => {
    try {
        const dbs = await nano.db.list();
        return dbs[0];
    } catch (err) {
        throw err;
    }
}

const deleteDB = async (dbName) => {
    try {
        const resp = await nano.db.destroy(dbName);
        // console.log(resp[0].ok);
        console.log(deletedDbs.length + 1 + '. ' + dbName + " is deleted.");
        deletedDbs.push(dbName);
    } catch (err) {
        // console.error(err);
        console.log(dbName + "failed to delete");
        failedDBs.push(dbName);
    }
}

const deleteAllDBs = async () => {
    const dbs = await getAllDBs();
    for (let i = dbs.length; i > 0; i--) {
        const thisDBName = dbs[i - 1];
        if (thisDBName.indexOf('_licencedb_') === -1 && thisDBName.indexOf('_retail_') !== -1) {
            try {
                await deleteDB(thisDBName);
            } catch (err) {
                console.error(err);
            }
        } else {
            console.log("skipping " + thisDBName);
            skippedDBs.push(thisDBName);
        }
    }
}

deleteAllDBs().then(function() {
    console.log('done');
}).catch(function(err) {
    console.log('failed');
    console.log(err);
})