var path = require('path');
var allAppProfilesData = require(path.join(__dirname, '../config/profitguruCoreConfig', 'ProfitGuruElements', 'profitGuruProfiles.json'));

var EmployeeProfiles = function () {

    var profilesArray = [];
    prepareAppProfilesWithAppSpecifics(allAppProfilesData);

    function prepareAppProfilesWithAppSpecifics(allAppProfilesData) {

        if (allAppProfilesData.appSpecific && allAppProfilesData.appSpecific[process.env.APP_TYPE]) {
            var appSepecificElements = allAppProfilesData.appSpecific[process.env.APP_TYPE];
            delete allAppProfilesData.appSpecific;

            for (var element in appSepecificElements) {
                allAppProfilesData[element] = appSepecificElements[element]
            }
        }

        for (var profile in allAppProfilesData) {
            profilesArray.push(profile.toLowerCase());
        }
    }

    function grantProfileEntitlements(role, revokePermission) {
        if (revokePermission) {
            role.allowNone = true;
            role.viewOnMenu = false;
            role.allowAll = false;
            return;
        }
        role.allowNone = false;
        role.viewOnMenu = true;
        role.allowAll = true;
        return;
    }
    this.adminRolePermissions = function (roles) {

        for (var role in roles) {
            grantProfileEntitlements(roles[role], false);
            for (var grant in roles[role]) {
                if (typeof roles[role][grant].allowed !== 'undefined') {
                    roles[role][grant].allowed = true;
                } else if (typeof roles[role][grant].allowAll !== 'undefined') {
                    roles[role][grant].allowAll = true;
                }
            }
        }
        return roles;

    };
    this.processEntitlements = function (createOrUpdateEmployeeData) {
        createOrUpdateEmployeeData.roles[0] = createOrUpdateEmployeeData.roles[0];

        if (createOrUpdateEmployeeData.profile && profilesArray.indexOf(createOrUpdateEmployeeData.profile.toLowerCase()) >= 0) {
            switch (createOrUpdateEmployeeData.profile) {
                case "adminProfile":
                    this.adminRolePermissions(createOrUpdateEmployeeData.roles[0]);
                    // for (var role in createOrUpdateEmployeeData.roles[0]) {
                    //     grantProfileEntitlements(createOrUpdateEmployeeData.roles[0][role], false);
                    //     for (var grant in createOrUpdateEmployeeData.roles[0][role]) {
                    //         if (typeof createOrUpdateEmployeeData.roles[0][role][grant].allowed !== 'undefined') {
                    //             createOrUpdateEmployeeData.roles[0][role][grant].allowed = true;
                    //         } else if (typeof createOrUpdateEmployeeData.roles[0][role][grant].allowAll !== 'undefined') {
                    //             createOrUpdateEmployeeData.roles[0][role][grant].allowAll = true;
                    //         }
                    //     }
                    // }
                    break;
                default:

                    var modulesAllowed4ThisProfile = allAppProfilesData[createOrUpdateEmployeeData.profile];
                    for (var role in createOrUpdateEmployeeData.roles[0]) {
                        if (modulesAllowed4ThisProfile.indexOf(role) >= 0) {
                            grantProfileEntitlements(createOrUpdateEmployeeData.roles[0][role], false);

                            for (var grant in createOrUpdateEmployeeData.roles[0][role]) {
                                if (typeof createOrUpdateEmployeeData.roles[0][role][grant].allowed !== 'undefined') {
                                    // grantProfileEntitlements(createOrUpdateEmployeeData.roles[0][role], false);
                                    createOrUpdateEmployeeData.roles[0][role][grant].allowed = true;

                                    if (createOrUpdateEmployeeData.profile === "salesPerson" && role === "salesRestaurant" && grant === "multiplePrintBill") {
                                        createOrUpdateEmployeeData.roles[0][role].allowAll = false;
                                        createOrUpdateEmployeeData.roles[0][role][grant].allowed = false;
                                    }
                                }
                            }
                        } else {
                            grantProfileEntitlements(createOrUpdateEmployeeData.roles[0][role], true);
                        }
                    }

            }
        } else {
            for (var role in createOrUpdateEmployeeData.roles[0]) {
                // if (createOrUpdateEmployeeData.roles[0][role].viewOnMenu) {
                if (createOrUpdateEmployeeData.roles[0][role].allowNone) {
                    createOrUpdateEmployeeData.roles[0][role].allowAll = false;
                    for (var permission in createOrUpdateEmployeeData.roles[0][role]) {
                        if (typeof createOrUpdateEmployeeData.roles[0][role][permission].allowed !== 'undefined') {
                            createOrUpdateEmployeeData.roles[0][role][permission].allowed = false;
                        }
                    }
                } else if (createOrUpdateEmployeeData.roles[0][role].allowAll) {
                    createOrUpdateEmployeeData.roles[0][role].allowNone = false;
                    for (var grant in createOrUpdateEmployeeData.roles[0][role]) {
                        if (typeof createOrUpdateEmployeeData.roles[0][role][grant].allowed !== 'undefined') {
                            createOrUpdateEmployeeData.roles[0][role][grant].allowed = true;
                        } else if (typeof createOrUpdateEmployeeData.roles[0][role][grant].allowAll !== 'undefined') {
                            createOrUpdateEmployeeData.roles[0][role][grant].allowAll = true;
                        }
                    }
                }
                // }

            }
        }

        //Adding Admin role
        if (createOrUpdateEmployeeData.roles[0].employees && !createOrUpdateEmployeeData.roles[0].employees.allowNone && (createOrUpdateEmployeeData.roles[0].employees.allowAll || createOrUpdateEmployeeData.roles[0].employees.create.allowed || createOrUpdateEmployeeData.roles[0].employees.update.allowed || createOrUpdateEmployeeData.roles[0].employees.delete.allowed)) {
            createOrUpdateEmployeeData.roles[1] = 'admin';
        } else {
            createOrUpdateEmployeeData.roles[1] = createOrUpdateEmployeeData.profile;
        }

        delete createOrUpdateEmployeeData.roles[0].inProgress;

        createOrUpdateEmployeeData.roles[0] = JSON.stringify(createOrUpdateEmployeeData.roles[0]);

        return createOrUpdateEmployeeData.roles;
    };
};

module.exports = new EmployeeProfiles();