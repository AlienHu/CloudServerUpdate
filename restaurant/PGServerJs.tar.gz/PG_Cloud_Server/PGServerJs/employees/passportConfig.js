// load all the things we need
var LocalStrategy = require('passport-local').Strategy;
var path = require("path");
// load up the user model

// expose this function to our app using module.exports
module.exports = function(passport, environment, nodeApp) {
    var _self = this;
    var config = require(path.join(__dirname, '..', 'config', 'config.json'))[environment][nodeApp];
    _self.couch = require('./couchDbUser.js')(config);
    // =========================================================================
    // passport session setup ==================================================
    // =========================================================================
    // required for persistent login sessions
    // passport needs ability to serialize and unserialize users out of session

    // used to serialize the user for the session
    passport.serializeUser(function(user, done) {
        done(null, user._id);
    });

    passport.deserializeUser(function(id, done) {
        _self.couch.findUser(id).then(function(user) {
            done(null, user[0]);
        }).catch(function(reason) {
            done(reason, null);
        });
    });

    // =========================================================================
    // LOCAL SIGNUP ============================================================
    // =========================================================================
    // we are using named strategies since we have one for login and one for signup
    // by default, if there was no name, it would just be called 'local'

    passport.use('local-signup', new LocalStrategy({
            // by default, local strategy uses username and password, we will override with username
            usernameField: 'username',
            passwordField: 'password', //,
            passReqToCallback: true // allows us to pass back the entire request to the callback
        },
        // function(req, username, password, done) {
        function(req, username, password, done) {
            // asynchronous
            // User.findOne wont fire unless data is sent back
            process.nextTick(function() {
                // find a user whose username is the same as the forms username
                // we are checking to see if the user trying to login already exists
                _self.couch.findUser(
                    username).then(
                    function(user) {

                        // check to see if theres already a user with that username
                        return done(null, false, 'signupMessage: That username is already taken.');
                    }).catch(function() {
                    _self.couch.createUser(req.body).then(function(createdUser) {
                        return done(null, createdUser[0]);
                    }).catch(function(reason) {
                        return done(reason);
                    });

                });

            });

        }));

    // =========================================================================
    // LOCAL LOGIN =============================================================
    // =========================================================================
    // we are using named strategies since we have one for login and one for signup
    // by default, if there was no name, it would just be called 'local'

    passport.use('local-login', new LocalStrategy(
        function(username, password, done) {
            process.nextTick(function() {
                _self.couch.login(username, password).then(function(user) {
                    if (user[0].name) {
                        _self.couch.findUser(user[0].name).then(function(loggedInUser) {
                            return done(null, loggedInUser[0]);
                        }).catch(function(reason) {
                            return done(reason);
                        });
                    } else {

                        return done(null, user[0]);
                    }
                }).catch(function(reason) {
                    return done(reason);
                });

            });
        }
    ));

    passport.deleteUser = function(user) {
        return _self.couch.deleteUser(user);
    };

    passport.updateUser = function(user) {
        return _self.couch.updateUser(user);
    };
};