/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;

        let maindb = nanoClients.maindb;

        try {

            var params = {};
            var newDocs = [];
            let allElementsDocs = await couchDBUtils.getAllDocsByType('customer', maindb);
            for (let i = 0; i < allElementsDocs.length; i++) {
                allElementsDocs[i].doc.company_name = '';
                allElementsDocs[i].doc.agency_name = '';
                newDocs.push(allElementsDocs[i].doc);
            }
            await couchDBUtils.bulkInsert(maindb, newDocs);

        } catch (error) {
            logger.error(error);
            throw migrationName + 'up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let maindb = nanoClients.maindb;

        try {

            var params = {};
            let docsToUpdate = [];

            let allElementsDocs = await couchDBUtils.getAllDocsByType('customer', maindb);

            for (let i = 0; i < allElementsDocs.length; i++) {

                if (allElementsDocs[i].doc.hasOwnProperty('company_name')) {
                    console.log('.......hiiii');
                    delete allElementsDocs[i].doc.company_name;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('company_name property not found');
                }
                if (allElementsDocs[i].doc.hasOwnProperty('agency_name')) {
                    delete allElementsDocs[i].doc.agency_name;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('agency_name property not found');
                }
                docsToUpdate.push(allElementsDocs[i].doc);
            }
            await couchDBUtils.bulkInsert(maindb, docsToUpdate);

        } catch (error) {
            logger.error(error);
            logger.error('customers company  update failed');
            throw migrationName + "DOwN Failed";
        }
    }
};