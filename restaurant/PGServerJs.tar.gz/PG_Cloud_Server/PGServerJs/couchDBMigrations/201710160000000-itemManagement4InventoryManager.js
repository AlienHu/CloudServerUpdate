/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;
        try {
            var params = {};
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            var allUsersDoc = [];

            for (var i = 0; i < allUsers.length; i++) {

                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                // allUsers[i].value.roles[0].itemManagement.add = allUsers[i].value.roles[0].itemManagement['add '];
                if (allUsers[i].value.roles[0].itemManagement) {
                    allUsers[i].value.roles[0].itemManagement.add = Object.assign({}, allUsers[i].value.roles[0].itemManagement['add ']);

                    if (allUsers[i].value.roles[1] === 'inventoryManager') {
                        allUsers[i].value.roles[0].itemManagement.allowAll = true;
                        allUsers[i].value.roles[0].itemManagement.viewOnMenu = true;
                        allUsers[i].value.roles[0].itemManagement.add.allowed = true;
                        allUsers[i].value.roles[0].itemManagement.view.allowed = true;
                        allUsers[i].value.roles[0].itemManagement.delete.allowed = true;
                        allUsers[i].value.roles[0].itemManagement.update.allowed = true;
                    }

                    delete allUsers[i].value.roles[0].itemManagement['add '];
                }

                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);

                allUsersDoc.push(allUsers[i].value);
            }
            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            var params = {};
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            var allUsersDoc = [];

            for (var i = 0; i < allUsers.length; i++) {
                console.log("hello");
                try {
                    allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                    // allUsers[i].value.roles[0].itemManagement['add '] = allUsers[i].value.roles[0].itemManagement.add;
                    if (allUsers[i].value.roles[0].itemManagement) {
                        allUsers[i].value.roles[0].itemManagement['add '] = Object.assign({}, allUsers[i].value.roles[0].itemManagement.add);

                        if (allUsers[i].value.roles[1] === 'inventoryManager') {
                            allUsers[i].value.roles[0].itemManagement.allowAll = false;
                            allUsers[i].value.roles[0].itemManagement.viewOnMenu = false;
                            allUsers[i].value.roles[0].itemManagement['add '].allowed = false;
                            allUsers[i].value.roles[0].itemManagement.view.allowed = false;
                            allUsers[i].value.roles[0].itemManagement.delete.allowed = false;
                            allUsers[i].value.roles[0].itemManagement.update.allowed = false;
                        }

                        delete allUsers[i].value.roles[0].itemManagement.add;
                    }
                    allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);

                    allUsersDoc.push(allUsers[i].value);
                } catch (error) {
                    logger.error(error);
                    continue;
                }

            }
            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);
        } catch (error) {
            logger.error(error);
            logger.error('item Management permissions for Inventoey manager down migration failed');
            throw error;
        }
    }
};