/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function (params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);

            applicationSettings.invoiceSettings.companyHeadWidth = (applicationSettings.invoiceSettings.headInfoWidth) ? applicationSettings.invoiceSettings.headInfoWidth : 40;
            applicationSettings.invoiceSettings.customerHeadWidth = (applicationSettings.invoiceSettings.headInfoWidth) ? applicationSettings.invoiceSettings.headInfoWidth : 40;
            applicationSettings.invoiceSettings.companyHeadTextAlign = (applicationSettings.invoiceSettings.headTextAlign) ? applicationSettings.invoiceSettings.headTextAlign : "left";
            applicationSettings.invoiceSettings.customerHeadTextAlign = (applicationSettings.invoiceSettings.headTextAlign) ? applicationSettings.invoiceSettings.headTextAlign : "left";

            if (applicationSettings.invoiceSettings.headTextAlign) delete (applicationSettings.invoiceSettings.headTextAlign);
            if (applicationSettings.invoiceSettings.headInfoWidth) delete (applicationSettings.invoiceSettings.headInfoWidth);
            await couchDBUtils.update(applicationSettings, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' invoiceSettings new up migration failed';
        }
    },

    down: async function (params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            let newKeys = ["companyHeadWidth", "customerHeadWidth", "companyHeadTextAlign", "customerHeadTextAlign"];
            for (var i = 0; i < newKeys.length; i++) {
                if (applicationSettings.invoiceSettings[newKeys[i]]) delete (applicationSettings.invoiceSettings[newKeys[i]]);
            }
            applicationSettings.invoiceSettings.headTextAlign = "left";
            applicationSettings.invoiceSettings.headInfoWidth = 40;
            await couchDBUtils.update(applicationSettings, nanoCore);
        } catch (err) {
            logger.error(err);
            throw migrationName + ' invoiceSettings new setting down migration failed';
        }
    }
};