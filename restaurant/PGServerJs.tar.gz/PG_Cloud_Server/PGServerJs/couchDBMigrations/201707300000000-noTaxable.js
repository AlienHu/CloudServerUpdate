/**
 */

'use strict';

var path = require('path');
let migrationName = path.basename(__filename, '.js');
let errMsg = migrationName + ' Migration Failed';

/**
 * we removed salesdb from config.json. So salesdb is undefined in nanoclients 
 * hardcoding here
 */

module.exports = {
    up: async function (params) {
        const appRootPath = params.migrationsBasePath + '/../';
        const configState = require(appRootPath + 'common/configState');
        const couchDBUtils2 = require(appRootPath + 'couchDb/couchDBUtils2');
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let logger = params.logger;

        try {
            let nanoCore = params.nanoClients.coredb;
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            applicationSettings.itemType.Liquor = 'Liquor';
            await couchDBUtils.update(applicationSettings, nanoCore, 2);
        } catch (error) {
            logger.error(error);
            throw errMsg;
        }

        let config = configState.getAppConfig();
        let dbUrl = couchDBUtils2.getCouchUrl(config.localCouch);
        let dbName = couchDBUtils2.getDBName('pg_collection', process.env.APP_TYPE, 'salesdb', true);

        try {
            await couchDBUtils2.deleteDb(dbUrl, dbName);
        } catch (error) {
            logger.error(error);
            logger.error('Benefit of doubt, db would not have been created');
        }

        try {
            let mainDBInstance = params.nanoClients.maindb;
            let newDocs = [];
            let allCustomersDocs = await couchDBUtils.getAllDocsByType('customer', mainDBInstance);
            for (let i = 0; i < allCustomersDocs.length; i++) {
                let doc = allCustomersDocs[i].doc;
                delete doc.taxable;
                newDocs.push(doc);
            }
            if (newDocs.length) {
                await couchDBUtils.bulkInsert(mainDBInstance, newDocs);
            }
        } catch (error) {
            logger.error(error);
            throw errMsg;
        }
    },

    // Not creating the salesdb, because no 1 was using it + 
    // Whoever uses it will be creating it while starting
    down: async function (params) {
        let logger = params.logger;
        const appRootPath = params.migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        try {
            let nanoCore = params.nanoClients.coredb;
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            delete applicationSettings.itemType.Liquor;
            await couchDBUtils.update(applicationSettings, nanoCore, 2);
        } catch (error) {
            logger.error(error);
            throw errMsg;
        }

        try {
            let mainDBInstance = params.nanoClients.maindb;
            let newDocs = [];
            let allCustomersDocs = await couchDBUtils.getAllDocsByType('customer', mainDBInstance);
            for (let i = 0; i < allCustomersDocs.length; i++) {
                let doc = allCustomersDocs[i].doc;
                doc.taxable = 1;
                newDocs.push(doc);
            }

            if (newDocs.length) {
                await couchDBUtils.bulkInsert(mainDBInstance, newDocs);
            }
        } catch (error) {
            logger.error(error);
            throw errMsg;
        }
    }
};