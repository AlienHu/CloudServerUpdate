/**
 * copy of 201808080000000-changeDueFix.js 
 * need to run this migration because of bug(creation of empty docs - changed docs were not getting updated) in 201808080000000-changeDueFix.js (now bug is fixed in original)
 */
'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
            let logger = params.logger;
            let migrationsBasePath = params.migrationsBasePath;

            const appRootPath = migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            const couchDBUtils2 = require('../couchDb/couchDBUtils2');
            const utils = require('../controllers/common/Utils');
            const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
            const CLONE = utils.clone;

            let migrationName = path.basename(__filename, '.js');
            params.migrationName = migrationName;
            let nanoClients = params.nanoClients;
            let maindb = nanoClients.maindb;
            let coredb = nanoClients.coredb;
            //returnAmt
            try {
                const commonLib = require('../controllers/libraries/commonLib');

                function add(a, b) {
                    return (a + b);
                };

                function multiply(a, b) {
                    return (a * b);
                }

                function subtract(a, b) {
                    return (a - b);
                };

                function getPaymentsTotal(payments) {
                    var total = 0;
                    for (var i = 0; i < payments.length; i++) {
                        if (payments[i].dp) {
                            continue;
                        }
                        total += payments[i].payment_amount;
                    }
                    return total;
                }

                /**sales Docs */
                // let allSalesDocs = await couchDBUtils.getAllDocsByType('sale', maindb);
                await batchProcess(1000, 'sale', processSaleBatch, {
                    dbInstance: maindb,
                    couchDBUtils: couchDBUtils,
                    logger: logger
                });

                async function processSaleBatch(allSalesDocs) {
                    let docsToPush = [];
                    for (let j = 0; j < allSalesDocs.length; j++) {

                        let sale_info = allSalesDocs[j].doc.sales_info
                        if (sale_info) {
                            if (sale_info.type === 3) {
                                continue;
                            }
                        }

                        allSalesDocs[j].doc = commonLib.transformSaleDoc(allSalesDocs[j].doc, 'sale');
                        var paymentTotal = getPaymentsTotal(allSalesDocs[j].doc.payments);
                        var changeDue = subtract(paymentTotal, allSalesDocs[j].doc.sales_info.total);
                        let bCashPaymentExists = false;
                        let cashPIndex = -1;
                        for (var p = 0; p < allSalesDocs[j].doc.payments.length; p++) {
                            if (allSalesDocs[j].doc.payments[p].returnAmt) {
                                delete allSalesDocs[j].doc.payments[p].returnAmt;
                            }
                            if (allSalesDocs[j].doc.payments[p].payment_type === 'Cash') {
                                bCashPaymentExists = true;
                                cashPIndex = p;
                            }
                        }
                        if (bCashPaymentExists) {
                            allSalesDocs[j].doc.payments[cashPIndex].returnAmt = changeDue;
                        } else {
                            if (allSalesDocs[j].doc.payments.length > 1) {
                                if (allSalesDocs[j].doc.payments[0].payment_type !== 'Sale on credit') {
                                    allSalesDocs[j].doc.payments[0].returnAmt = changeDue;

                                } else {
                                    allSalesDocs[j].doc.payments[1].returnAmt = changeDue;

                                }
                            } else if (allSalesDocs[j].doc.payments.length === 1) {
                                if (allSalesDocs[j].doc.payments[0].payment_type !== 'Sale on credit') {
                                    allSalesDocs[j].doc.payments[0].returnAmt = changeDue;

                                } else {
                                    allSalesDocs[j].doc.payments[0].payment_amount -= changeDue;
                                    allSalesDocs[j].doc.sales_info.pending_amount -= changeDue;
                                }
                            }
                        }
                        allSalesDocs[j].doc = await commonLib.encodeTransDoc(allSalesDocs[j].doc, 'sale');
                        docsToPush.push(allSalesDocs[j].doc);
                    }
                    await couchDBUtils.bulkInsert(maindb, docsToPush);
                }

                //sales return 
                // let allSaleRetunDocs = await couchDBUtils.getAllDocsByType('saleReturn', maindb);
                await batchProcess(1000, 'saleReturn', processSaleRetunBatch, {
                    dbInstance: maindb,
                    couchDBUtils: couchDBUtils,
                    logger: logger
                });

                async function processSaleRetunBatch(allSaleRetunDocs) {
                    let returnDocs2Puch = [];

                    for (var k = 0; k < allSaleRetunDocs.length; k++) {
                        allSaleRetunDocs[k].doc = commonLib.transformSaleDoc(allSaleRetunDocs[k].doc, 'saleReturn');
                        var totalPaid = getPaymentsTotal(allSaleRetunDocs[k].doc.payments);
                        var changeDue = subtract(totalPaid, allSaleRetunDocs[k].doc.info.total);

                        let bCashPaymentExists = false;
                        let cashPIndex = -1;
                        for (var p = 0; p < allSaleRetunDocs[k].doc.payments.length; p++) {
                            if (allSaleRetunDocs[k].doc.payments[p].returnAmt) {
                                delete allSaleRetunDocs[k].doc.payments[p].returnAmt;
                            }
                            if (allSaleRetunDocs[k].doc.payments[p].payment_type === 'Cash') {
                                bCashPaymentExists = true;
                                cashPIndex = p;
                            }
                        }
                        if (bCashPaymentExists) {
                            allSaleRetunDocs[k].doc.payments[cashPIndex].returnAmt = changeDue;
                        } else {
                            if (allSaleRetunDocs[k].doc.payments.length > 1) {
                                if (allSaleRetunDocs[k].doc.payments[0].payment_type !== 'Sale on credit') {
                                    allSaleRetunDocs[k].doc.payments[0].returnAmt = changeDue;

                                } else {
                                    allSaleRetunDocs[k].doc.payments[1].returnAmt = changeDue;

                                }
                            } else if (allSaleRetunDocs[k].doc.payments.length === 1) {
                                if (allSaleRetunDocs[k].doc.payments[0].payment_type !== 'Sale on credit') {
                                    allSaleRetunDocs[k].doc.payments[0].returnAmt = changeDue;

                                } else {
                                    allSaleRetunDocs[k].doc.payments[0].payment_amount -= changeDue;
                                    allSaleRetunDocs[k].doc.info.pending_amount -= changeDue;
                                }
                            }
                        }
                        allSaleRetunDocs[k].doc = await commonLib.encodeTransDoc(allSaleRetunDocs[k].doc, 'saleReturn');
                        returnDocs2Puch.push(allSaleRetunDocs[k].doc);
                    }
                    await couchDBUtils.bulkInsert(maindb, returnDocs2Puch);
                }

            } catch (err) {
                logger.error(err);
                throw migrationName + ' up migration failed';
            }
        },

        down: async function(params) {
            let logger = params.logger;
            let migrationName = path.basename(__filename, '.js');
            params.migrationName = migrationName;
            let migrationsBasePath = params.migrationsBasePath;
            const appRootPath = migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            const couchDBUtils2 = require('../couchDb/couchDBUtils2');
            let nanoClients = params.nanoClients;
            let maindb = nanoClients.maindb;
            let nanoUsers = nanoClients._users;

            try {
                //as if now down migration is not required
                //todo write code if down is rquired
            } catch (err) {
                logger.error(err);
                throw migrationName + ' down migration failed';
            }
        }
};