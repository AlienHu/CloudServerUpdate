/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

export const up = async function (params) {
    let logger = params.logger;
    let migrationsBasePath = params.migrationsBasePath;

    const appRootPath = migrationsBasePath + '/../';
    const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
    const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;

    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let maindb = nanoClients.maindb;
    try {

        function subtract(a, b) {
            return (a - b);
        };

        function getPaymentsTotal(payments) {
            var total = 0;
            for (var i = 0; i < payments.length; i++) {
                total += payments[i].payment_amount;
            }
            return total;
        }

        /**sales Multiple units */
        // let allSalesDocs = await couchDBUtils.getAllDocsByType('sale', maindb);
        await batchProcess(1000, 'sale', saleBatchProcess, {
            dbInstance: maindb,
            couchDBUtils: couchDBUtils,
            logger: logger
        });

        async function saleBatchProcess(allSalesDocs) {
            let docsToPush = [];
            for (let j = 0; j < allSalesDocs.length; j++) {
                if (typeof allSalesDocs[j].doc.sales_info === 'string') {
                    continue;
                }
                var paymentTotal = getPaymentsTotal(allSalesDocs[j].doc.payments);
                var changeDue = subtract(paymentTotal, allSalesDocs[j].doc.sales_info.total);
                for (var p = 0; p < allSalesDocs[j].doc.payments.length; p++) {
                    if (allSalesDocs[j].doc.payments[p].payment_type === 'Cash') {
                        allSalesDocs[j].doc.payments[p].returnAmt = changeDue;
                    }
                }
                docsToPush.push(allSalesDocs[j].doc);
            }
            await couchDBUtils.bulkInsert(maindb, docsToPush);
        }

        //sales return 
        // let allSaleRetunDocs = await couchDBUtils.getAllDocsByType('saleReturn', maindb);
        await batchProcess(1000, 'saleReturn', processSaleReturns, {
            dbInstance: maindb,
            couchDBUtils: couchDBUtils,
            logger: logger
        });

        async function processSaleReturns(allSaleRetunDocs) {
            let docsToPush = [];
            for (var k = 0; k < allSaleRetunDocs.length; k++) {
                if (typeof allSaleRetunDocs[k].doc.info === 'string') {
                    continue;
                }
                var totalPaid = getPaymentsTotal(allSaleRetunDocs[k].doc.payments);
                var changeAmt = subtract(totalPaid, allSaleRetunDocs[k].doc.info.total);
                for (var p = 0; p < allSaleRetunDocs[k].doc.payments.length; p++) {
                    if (allSaleRetunDocs[k].doc.payments[p].payment_type === 'Cash') {
                        allSaleRetunDocs[k].doc.payments[p].returnAmt = changeAmt;
                    }
                }

                docsToPush.push(allSaleRetunDocs[k].doc);
            }
            await couchDBUtils.bulkInsert(maindb, docsToPush);
        }

    } catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }
};

export const down = async function () {

}
