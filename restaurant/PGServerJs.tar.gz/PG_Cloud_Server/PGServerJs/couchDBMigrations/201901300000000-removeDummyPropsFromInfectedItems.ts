/**
 */

'use strict';

import * as path from 'path';

export const up = async (params) => {
    const logger = params.logger;

    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let dbInstance = nanoClients.maindb;

    let skip = 0;
    let totalDeleted = 0;



    try {
        while (true) {
            let resp = (await dbInstance.fetch({}, {
                include_docs: true,
                limit: 1000,
                skip: skip,
                startkey: "item_",
                endkey: "item_z"
            }))[0];

            if (resp.rows.length === 0) {
                break;
            }

            let docs2UpdateArr = [];
            for (let i = 0; i < resp.rows.length; i++) {
                let curedItemJson = removeDummyPropsFromItem(resp.rows[i].doc)

                if (curedItemJson)
                    docs2UpdateArr.push(curedItemJson);
            }

            if (docs2UpdateArr.length) {
                await dbInstance.bulk({
                    docs: docs2UpdateArr
                });
            }

            skip += resp.rows.length;
            totalDeleted += docs2UpdateArr.length;
            logger.silly('skip<' + skip + '> totaldelted<' + totalDeleted + '>');
        }
    } catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }
};

export const down = async () => {
    //nothing required
    return;
};

const removeDummyPropsFromItem = (itemJson) => {
    let bCuredNeeded: boolean = false
    if (itemJson.info.category) {
        bCuredNeeded = true;
        delete itemJson.info.category;
    }
    if (itemJson.info.purchaseUnit) {
        bCuredNeeded = true;
        delete itemJson.info.purchaseUnit;
    }
    if (itemJson.info.sellingUnit) {
        bCuredNeeded = true;
        delete itemJson.info.sellingUnit;
    }
    if (itemJson.info.batches) {
        bCuredNeeded = true;
        delete itemJson.info.batches;
    }
    if (itemJson.info.batch) {
        bCuredNeeded = true;
        delete itemJson.info.batch;
    }
    if (itemJson.info.batchInfo) {
        bCuredNeeded = true;
        delete itemJson.info.batchInfo;
    }
    if (itemJson.info.stockKey) {
        bCuredNeeded = true;
        delete itemJson.info.stockKey;
    }

    let unitsInfo = itemJson.unitsInfo;
    for (let uId in unitsInfo) {
        if (unitsInfo[uId].purchasePriceWithGDiscount) {
            bCuredNeeded = true;
            delete unitsInfo[uId].purchasePriceWithGDiscount;
        }
    }
    if (bCuredNeeded) {
        return itemJson;
    }
}