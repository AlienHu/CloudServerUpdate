/**
 */

'use strict';
var path = require('path');
let migrationName = path.basename(__filename, '.js');
module.exports = {
    up: async function(params) {
        let logger = params.logger;

        try {
            let nanoClients = params.nanoClients;
            let nanoCore = nanoClients.coredb;
            const appRootPath = params.migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            if (applicationSettings.hasOwnProperty('paperReceipt')) {
                if (!applicationSettings.paperReceipt.hasOwnProperty('headerFont')) {
                    applicationSettings.paperReceipt.headerFont = 12;
                }
                if (!applicationSettings.paperReceipt.hasOwnProperty('headerInfoFont')) {
                    applicationSettings.paperReceipt.headerInfoFont = 12;
                }
                if (!applicationSettings.paperReceipt.hasOwnProperty('itemHeaderFont')) {
                    applicationSettings.paperReceipt.itemHeaderFont = 12;
                }
                if (!applicationSettings.paperReceipt.hasOwnProperty('itemInfoFont')) {
                    applicationSettings.paperReceipt.itemInfoFont = 12;
                }
                if (!applicationSettings.paperReceipt.hasOwnProperty('footerHeaderFont')) {
                    applicationSettings.paperReceipt.footerHeaderFont = 12;
                }
                if (!applicationSettings.paperReceipt.hasOwnProperty('footerInfoFont')) {
                    applicationSettings.paperReceipt.footerInfoFont = 12;
                }
            }
            await couchDBUtils.update(applicationSettings, nanoCore, 2);
        } catch (error) {
            logger.error(error);
            logger.error('application settings update font setting failed');
            throw migrationName + " failed";
        }
    },
    down: async function(params) {
        let logger = params.logger;
        try {
            let nanoClients = params.nanoClients;
            let nanoCore = nanoClients.coredb;
            const appRootPath = params.migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);

            if (applicationSettings.paperReceipt.hasOwnProperty('headerFont')) {
                delete applicationSettings.paperReceipt.headerFont;
            }
            if (applicationSettings.paperReceipt.hasOwnProperty('headerInfoFont')) {
                delete applicationSettings.paperReceipt.headerInfoFont;
            }
            if (applicationSettings.paperReceipt.hasOwnProperty('itemHeaderFont')) {
                delete applicationSettings.paperReceipt.itemHeaderFont;
            }
            if (applicationSettings.paperReceipt.hasOwnProperty('itemInfoFont')) {
                delete applicationSettings.paperReceipt.itemInfoFont;
            }
            if (applicationSettings.paperReceipt.hasOwnProperty('footerHeaderFont')) {
                delete applicationSettings.paperReceipt.footerHeaderFont;
            }
            if (applicationSettings.paperReceipt.hasOwnProperty('footerInfoFont')) {
                delete applicationSettings.paperReceipt.footerInfoFont;
            }
            await couchDBUtils.update(applicationSettings, nanoCore, 2);
        } catch (error) {
            logger.error(error);
            logger.error('application settings update font setting failed');
            throw migrationName + " failed";
        }
    }
};