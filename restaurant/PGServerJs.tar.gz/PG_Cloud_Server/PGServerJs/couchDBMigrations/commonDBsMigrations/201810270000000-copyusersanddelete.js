/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var path = require('path');
exports.up = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = params.logger;
        const usersDBInstance = params.nanoClients.users;
        let migrationName = path.basename(__filename, '.js');
        try {
            let allUsers = yield getAllUserDocs(usersDBInstance, {}, true, logger);
            let docs2Update = [];
            for (let i = 0; i < allUsers.length; i++) {
                let prevUserDoc = allUsers[i];
                if (!prevUserDoc.roles[0]) {
                    continue;
                }
                let newUserDoc = Object.assign({}, prevUserDoc);
                delete newUserDoc._rev;
                newUserDoc._id = newUserDoc.name;
                newUserDoc.password = newUserDoc.name;
                prevUserDoc._deleted = true;
                docs2Update.push(prevUserDoc);
                docs2Update.push(newUserDoc);
            }
            if (docs2Update.length) {
                yield bulkInsert(usersDBInstance, docs2Update, logger);
            }
        }
        catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    });
};
exports.down = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
    });
};
function getAllUserDocs(db, params, bOnlyDocs, logger) {
    return __awaiter(this, void 0, void 0, function* () {
        var type = "org.couchdb.user";
        params = params || {};
        params.startkey = type + '';
        params.endkey = type + '_';
        params.include_docs = true;
        try {
            let [body, header] = yield db.fetch({}, params);
            if (!bOnlyDocs) {
                return body.rows;
            }
            else {
                //This is just wasting of 1 for loop for the inconvinience of having to write body.rows[i].doc everytime
                //Bad don't use it
                let resp = [];
                for (let i = 0; i < body.rows.length; i++) {
                    if (body.rows[i].doc.APP_TYPE === process.env.APP_TYPE || body.rows[i].doc.strRegistrationId) {
                        let doc = body.rows[i].doc;
                        resp.push(doc);
                    }
                }
                return resp;
            }
        }
        catch (err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        }
    });
}
function bulkInsert(db, docsArray, logger) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let resp = yield db.bulk({
                docs: docsArray
            });
            return resp;
        }
        catch (error) {
            logger.error(error);
            throw 'Bulk Update Failed';
        }
    });
}
;
//# sourceMappingURL=201810270000000-copyusersanddelete.js.map