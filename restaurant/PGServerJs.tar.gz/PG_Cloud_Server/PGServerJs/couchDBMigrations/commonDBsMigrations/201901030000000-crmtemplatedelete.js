/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var path = require('path');
exports.up = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = params.logger;
        const licencedBInstance = params.nanoClients.licencedb;
        let migrationName = path.basename(__filename, '.js');
        try {
            let docs2Update = [];
            yield getAllTemplatesToDelete(licencedBInstance, logger, docs2Update);
            yield getAllStoresToUpdate(licencedBInstance, logger, docs2Update);
            if (docs2Update.length) {
                yield bulkInsert(licencedBInstance, docs2Update, logger);
            }
        }
        catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    });
};
exports.down = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
    });
};
function getAllTemplatesToDelete(db, logger, docs2Update) {
    return __awaiter(this, void 0, void 0, function* () {
        var type = "ct";
        let params = {
            startkey: type + '_',
            endkey: type + '_x',
            include_docs: true
        };
        try {
            let [body, header] = yield db.fetch({}, params);
            for (let i = 0; i < body.rows.length; i++) {
                if (!body.rows[i].doc.strStoreCompanyId) {
                    let doc = body.rows[i].doc;
                    doc._deleted = true;
                    docs2Update.push(doc);
                }
            }
        }
        catch (err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        }
    });
}
function getAllStoresToUpdate(db, logger, docs2Update) {
    return __awaiter(this, void 0, void 0, function* () {
        var type = "store";
        let params = {
            startkey: type + '_',
            endkey: type + '_x',
            include_docs: true
        };
        try {
            let [body, header] = yield db.fetch({}, params);
            for (let i = 0; i < body.rows.length; i++) {
                if (!body.rows[i].doc.strStoreCompanyId) {
                    let doc = body.rows[i].doc;
                    doc.appType = process.env.APP_TYPE;
                    docs2Update.push(doc);
                }
            }
        }
        catch (err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        }
    });
}
function bulkInsert(db, docsArray, logger) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let resp = yield db.bulk({
                docs: docsArray
            });
            return resp;
        }
        catch (error) {
            logger.error(error);
            throw 'Bulk Update Failed';
        }
    });
}
;
//# sourceMappingURL=201901030000000-crmtemplatedelete.js.map