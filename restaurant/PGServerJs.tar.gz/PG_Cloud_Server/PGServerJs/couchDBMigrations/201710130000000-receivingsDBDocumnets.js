/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        const itemUtil = require(appRootPath + 'controllers/libraries/itemUtil');
        const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
        try {

            await batchProcess(10, 'receiving', process, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            await batchProcess(10, 'receivingReturn', process, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });

            async function process(purchaseDocs, params) {
                let docsToUpdate = [];
                for (let i = 0; i < purchaseDocs.length; i++) {

                    let info = purchaseDocs[i].doc.receivings_info;
                    if (!info) {
                        info = purchaseDocs[i].doc.info;
                    }

                    if (info && !info.amount_tendered) {
                        info.amount_tendered = 0;
                        //time machine doesn't have payments
                        for (var j = 0; info.payments && j < info.payments.length; j++) {
                            info.amount_tendered += info.payments[j].payment_amount;
                        }
                    }

                    let items = purchaseDocs[i].doc.receiving_items;
                    if (!items) {
                        items = purchaseDocs[i].doc.items;
                    }

                    for (var k = 0;
                        (items && k < items.length); k++) {
                        var itemQueryParams = {
                            item_id: items[k].item_id,
                            stockKey: items[k].stockKey,
                            taxType: itemUtil.enPurchaseTax
                        };
                        let itemInfo = await itemUtil.getThisItemInfo(itemQueryParams, couchDBUtils, maindb);
                        if (itemInfo.purchaseUnit.shortName) {
                            items[k].unit = itemInfo.purchaseUnit.shortName;
                        } else {
                            items[k].unit = '';
                        }
                        items[k].hasExpiryDate = items[k].hasExpiryDate ? true : false;
                        items[k].is_serialized = items[k].is_serialized ? true : false;
                        items[k].hasBatchNumber = items[k].hasBatchNumber ? true : false;
                        items[k].imeiCount = items[k].imeiCount ? items[k].imeiCount : 0;
                        items[k].hasVariants = items[k].hasVariants ? true : false;
                        /**
                         * hasExpiryDate
                         is_serialized
                         hasBatchNumber
                         imeiCount
                         hasVariants
                         */
                    }

                    docsToUpdate.push(purchaseDocs[i].doc);

                }

                if (docsToUpdate.length) {
                    let updateResp = await couchDBUtils.bulkInsert(maindb, docsToUpdate);
                }
            }

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;

        try {
            // var params = {};
            // let purchaseDocs = await couchDBUtils.getAllDocsByType('receiving', maindb);
            // let docsToUpdate = [];
            // for (let i = 0; i < purchaseDocs.length; i++) {
            //     if (purchaseDocs[i].doc.receivings_info.hasOwnProperty('amount_tendered')) {
            //         delete purchaseDocs[i].doc.receivings_info.amount_tendered;
            //     }
            //     //purchase credit
            //     if (purchaseDocs[i].doc.receiving_items) {
            //         for (var j = 0; j < purchaseDocs[i].doc.receiving_items.length; j++) {
            //             if (purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('hasExpiryDate')); {
            //                 delete purchaseDocs[i].doc.receiving_items[j].hasExpiryDate;
            //             }
            //             console.log(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('is_serialized'));
            //             if (purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('is_serialized')) {
            //                 delete purchaseDocs[i].doc.receiving_items[j].is_serialized;
            //             }
            //             console.log(purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('is_serialized'));
            //             if (purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('hasBatchNumber')) {
            //                 delete purchaseDocs[i].doc.receiving_items[j].hasBatchNumber;
            //             }
            //             if (purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('imeiCount')) {
            //                 delete purchaseDocs[i].doc.receiving_items[j].imeiCount;
            //             }
            //             if (purchaseDocs[i].doc.receiving_items[j].hasOwnProperty('hasVariants')) {
            //                 delete purchaseDocs[i].doc.receiving_items[j].hasVariants;
            //             }

            //         }
            //     }
            //     docsToUpdate.push(purchaseDocs[i].doc);
            // }

            // let purchaseReturnsDocs = await couchDBUtils.getAllDocsByType('receivingReturn', maindb);

            // for (let l = 0; l < purchaseReturnsDocs.length; l++) {
            //     if (purchaseReturnsDocs[l].doc.receivings_info.hasOwnProperty('amount_tendered')) {
            //         delete purchaseReturnsDocs[l].doc.receivings_info.amount_tendered;
            //     }
            //     if (purchaseReturnsDocs[l].doc.items) {
            //         for (var m = 0; m < purchaseReturnsDocs[l].doc.items.length; m++) {
            //             if (purchaseReturnsDocs[l].doc.items[m].hasOwnProperty('hasExpiryDate')); {
            //                 delete purchaseReturnsDocs[l].doc.items[m].hasExpiryDate;
            //             }
            //             if (purchaseReturnsDocs[l].doc.items[m].hasOwnProperty('is_serialized')) {
            //                 delete purchaseReturnsDocs[l].doc.items[m].is_serialized;
            //             }
            //             if (purchaseReturnsDocs[l].doc.items[m].hasOwnProperty('hasBatchNumber')) {
            //                 delete purchaseReturnsDocs[l].doc.items[m].hasBatchNumber;
            //             }
            //             if (purchaseReturnsDocs[l].doc.items[m].hasOwnProperty('imeiCount')) {
            //                 delete ppurchaseReturnsDocs[l].doc.items[m].imeiCount;
            //             }
            //             if (purchaseReturnsDocs[l].doc.items[m].hasOwnProperty('hasVariants')) {
            //                 delete purchaseReturnsDocs[l].doc.items[m].hasVariants;
            //             }

            //         }
            //     }
            //     docsToUpdate.push(purchaseReturnsDocs[l].doc);
            // }

            // let updateResp = await couchDBUtils.bulkInsert(maindb, docsToUpdate);

            //
            await batchProcess(10, 'receiving', process, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            await batchProcess(10, 'receivingReturn', process, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });

            async function process(purchaseDocs, params) {
                let docsToUpdate = [];

                for (let i = 0; i < purchaseDocs.length; i++) {

                    let info = purchaseDocs[i].doc.receivings_info;
                    if (!info) {
                        info = purchaseDocs[i].doc.info;
                    }

                    if (info.hasOwnProperty('amount_tendered')) {
                        delete info.amount_tendered;
                    }

                    let items = purchaseDocs[i].doc.receiving_items;
                    if (!items) {
                        items = purchaseDocs[i].doc.items;
                    }

                    for (var k = 0;
                        (items && k < items.length); k++) {
                        if (items[k].hasOwnProperty('unit')) {
                            delete items[k].unit;
                        }
                        if (items[k].hasOwnProperty('hasExpiryDate')) {
                            delete items[k].hasExpiryDate;
                        }
                        if (items[k].hasOwnProperty('is_serialized')) {
                            delete items[k].is_serialized;
                        }
                        if (items[k].hasOwnProperty('hasBatchNumber')) {
                            delete items[k].hasBatchNumber;
                        }
                        if (items[k].hasOwnProperty('imeiCount')) {
                            delete items[k].imeiCount;
                        }
                        if (items[k].hasOwnProperty('hasVariants')) {
                            delete items[k].hasVariants;
                        }

                    }

                    docsToUpdate.push(purchaseDocs[i].doc);

                }

                if (docsToUpdate.length) {
                    let updateResp = await couchDBUtils.bulkInsert(maindb, docsToUpdate);
                }
            }

        } catch (error) {
            logger.error(error);
            logger.error('purchase reprint down migration failed');
            throw error;
        }
    }
};