## Observations
* Sale docs process in batch
* Rotating memory
  * Customer and Users keep 1000 in memory rotating
  * Items keep 1000 in memory rotating
  * Category and others keep 1000 in memory

## Performance Considerations  
* CouchDB Query is costly. Have as little calls as possible  
* Memory is constraint. Plan well.
* Plan something across migrations as well. This will speed up.
* Sorted Array is better than Json

## Rotating memory Sales Items Example - 20k sales, 13k items
1000 Items can be in memory
Have Empty Array - itemDocsArray
A. Loop through sales, get close to 1000 items. 
B. migrate the sales.
C. Loop through sales, get close to 1000 items.
D. Check How many of them needs to be queried, query the rest - remove unwanted.
E. migrate the sales.
F. Repeat C-E untill all the sales are over


## Migrations New Flow
* Let's say 6 Migrations are pending. 4 of them deal with sales.
* Order is important so .. no of cases are too many.