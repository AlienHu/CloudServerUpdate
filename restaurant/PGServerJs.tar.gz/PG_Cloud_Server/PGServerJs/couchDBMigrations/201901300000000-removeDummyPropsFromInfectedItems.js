/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
exports.up = (params) => __awaiter(this, void 0, void 0, function* () {
    const logger = params.logger;
    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let dbInstance = nanoClients.maindb;
    let skip = 0;
    let totalDeleted = 0;
    try {
        while (true) {
            let resp = (yield dbInstance.fetch({}, {
                include_docs: true,
                limit: 1000,
                skip: skip,
                startkey: "item_",
                endkey: "item_z"
            }))[0];
            if (resp.rows.length === 0) {
                break;
            }
            let docs2UpdateArr = [];
            for (let i = 0; i < resp.rows.length; i++) {
                let curedItemJson = removeDummyPropsFromItem(resp.rows[i].doc);
                if (curedItemJson)
                    docs2UpdateArr.push(curedItemJson);
            }
            if (docs2UpdateArr.length) {
                yield dbInstance.bulk({
                    docs: docs2UpdateArr
                });
            }
            skip += resp.rows.length;
            totalDeleted += docs2UpdateArr.length;
            logger.silly('skip<' + skip + '> totaldelted<' + totalDeleted + '>');
        }
    }
    catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }
});
exports.down = () => __awaiter(this, void 0, void 0, function* () {
    //nothing required
    return;
});
const removeDummyPropsFromItem = (itemJson) => {
    let bCuredNeeded = false;
    if (itemJson.info.category) {
        bCuredNeeded = true;
        delete itemJson.info.category;
    }
    if (itemJson.info.purchaseUnit) {
        bCuredNeeded = true;
        delete itemJson.info.purchaseUnit;
    }
    if (itemJson.info.sellingUnit) {
        bCuredNeeded = true;
        delete itemJson.info.sellingUnit;
    }
    if (itemJson.info.batches) {
        bCuredNeeded = true;
        delete itemJson.info.batches;
    }
    if (itemJson.info.batch) {
        bCuredNeeded = true;
        delete itemJson.info.batch;
    }
    if (itemJson.info.batchInfo) {
        bCuredNeeded = true;
        delete itemJson.info.batchInfo;
    }
    if (itemJson.info.stockKey) {
        bCuredNeeded = true;
        delete itemJson.info.stockKey;
    }
    let unitsInfo = itemJson.unitsInfo;
    for (let uId in unitsInfo) {
        if (unitsInfo[uId].purchasePriceWithGDiscount) {
            bCuredNeeded = true;
            delete unitsInfo[uId].purchasePriceWithGDiscount;
        }
    }
    if (bCuredNeeded) {
        return itemJson;
    }
};
//# sourceMappingURL=201901300000000-removeDummyPropsFromInfectedItems.js.map