/**
 */

'use strict';

import * as path from 'path';
import * as moment from 'moment';

export const up = async (params) => {
    const logger = params.logger;

    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let dbInstance = nanoClients.maindb;

    try {

        let resp = (await dbInstance.fetch({}, {
            include_docs: true,
            startkey: 'ct_',
            endkey: 'ct_x'
        }))[0];

        if (resp.rows.length === 0) {
            return;
        }

        let docs2UpdateArr = [];
        for (let i = 0; i < resp.rows.length; i++) {
            let doc: TemplateType = resp.rows[i].doc;
            for (let i: number = 0; i < doc.templates.length; i++) {
                doc.templates[i].bApproved = true;
                doc.templates[i].modifiedTs = moment().format('x');
            }
            doc.iPendingCount = 0;
            docs2UpdateArr.push(doc);
        }

        if (docs2UpdateArr.length) {
            await dbInstance.bulk({
                docs: docs2UpdateArr
            });
        }



    } catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }
};

export const down = async (params) => {
    const logger = params.logger;

    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let dbInstance = nanoClients.maindb;

    try {

        let resp = (await dbInstance.fetch({}, {
            include_docs: true,
            startkey: 'ct_',
            endkey: 'ct_x'
        }))[0];

        if (resp.rows.length === 0) {
            return;
        }

        let docs2UpdateArr = [];
        for (let i = 0; i < resp.rows.length; i++) {
            let doc: TemplateType = resp.rows[i].doc;
            for (let i: number = 0; i < doc.templates.length; i++) {
                delete doc.templates[i].bApproved;
                delete doc.templates[i].modifiedTs;
            }
            delete doc.iPendingCount;
            docs2UpdateArr.push(doc);
        }

        if (docs2UpdateArr.length) {
            await dbInstance.bulk({
                docs: docs2UpdateArr
            });
        }



    } catch (err) {
        logger.error(err);
        throw migrationName + ' down migration failed';
    }
};

interface TemplateType {
    _id: string;
    _rev?: string;
    name: string; //Birthday, Christmas
    templates: Template[];
    iPendingCount: number; //This is a cheating variable. Update only for doc in maindb. For licencedb it is  0
    isUpdate?: boolean;
    deleted?: string;
    _deleted?: boolean;
}

interface Template {
    message: string;
    modifiedTs: Timestamp;
    bApproved: boolean;
}

type Timestamp = string;