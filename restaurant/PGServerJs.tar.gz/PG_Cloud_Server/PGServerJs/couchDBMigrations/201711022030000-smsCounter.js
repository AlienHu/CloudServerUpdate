/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;

        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            let props = ['transCounter', 'promoCounter', 'transQuota', 'promoQuota'];
            applicationSettings.smsCounter = {};
            for (let i = 0; i < props.length; i++) {
                applicationSettings.smsCounter[props[i]] = applicationSettings.enableSMS[props[i]];
                delete applicationSettings.enableSMS[props[i]];
            }
            await couchDBUtils.update(applicationSettings, nanoCore);
        } catch (err) {
            logger.error(err);
            throw migrationName + ' setting migration failed';
        }

    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;

        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            let props = ['transCounter', 'promoCounter', 'transQuota', 'promoQuota'];
            for (let i = 0; i < props.length; i++) {
                applicationSettings.enableSMS[props[i]] = applicationSettings.smsCounter[props[i]];
                delete applicationSettings.smsCounter[props[i]];
            }
            await couchDBUtils.update(applicationSettings, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' enableSMS setting down migration failed';
        }
    }
};