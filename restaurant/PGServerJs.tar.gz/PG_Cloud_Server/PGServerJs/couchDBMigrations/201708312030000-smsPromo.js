/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;
        try {
            var params = {};
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            var allUsersDoc = [];
            var json = {
                "desc": "promotions",
                "allowNone": false,
                "allowAll": false,
                "viewOnMenu": false,
                "sendSMS": {
                    "apis": ["/common/sendSMS"],
                    "common": true,
                    "allowed": false,
                    "desc": "Allows to send promo sms"
                }
            };
            for (var i = 0; i < allUsers.length; i++) {
                try {
                    allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                } catch (error) {
                    logger.error(error);
                    continue;
                }

                if (allUsers[i].value.roles[1] === 'admin') {
                    json.allowAll = true;
                    json.viewOnMenu = true;
                    json.sendSMS.allowed = true;
                }
                allUsers[i].value.roles[0].promo = {};
                allUsers[i].value.roles[0].promo = json;

                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);

                allUsersDoc.push(allUsers[i].value);
            }

            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);

        } catch (error) {
            logger.error(error);
            throw migrationName + ' roles migration failed';
        }
        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            applicationSettings.enableSMS.creditSMS = "Dear CUSTOMER, Please pay due bill of Rs. AMOUNT before DATE";
            applicationSettings.enableSMS.saleSMS = "Dear CUSTOMER, Your bill is Rs. AMOUNT against Invoice SALEID. Thanks for shopping with COMPANY";
            applicationSettings.enableSMS.promoSMS = "Dear customer, thanks for shopping with us.";
            await couchDBUtils.update(applicationSettings, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' setting migration failed';
        }
        // entitlements are in profitGuruUsersAllEntitlements.json
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            var params = {};
            let allUsersDoc = [];
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            for (var i = 0; i < allUsers.length; i++) {
                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                if (allUsers[i].value.roles[0].hasOwnProperty('promo')) {
                    delete allUsers[i].value.roles[0].promo;
                    allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                    allUsersDoc.push(allUsers[i].value);
                } else {
                    logger.error('Not expected to come here');
                    logger.error('promo property not found in takeAway');
                }
            }
            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);
        } catch (error) {
            logger.error(error);
            logger.error('roles down migration failed');
            throw error;
        }
        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            if (applicationSettings.enableSMS.hasOwnProperty('creditSMS')) {
                delete applicationSettings.enableSMS.creditSMS;
            } else {
                logger.error('Not expected to come here');
                logger.error('enableSMS property not found');
            }
            if (applicationSettings.enableSMS.hasOwnProperty('promoSMS')) {
                delete applicationSettings.enableSMS.promoSMS;
            } else {
                logger.error('Not expected to come here');
                logger.error('promoSMS property not found');
            }
            if (applicationSettings.enableSMS.hasOwnProperty('saleSMS')) {
                delete applicationSettings.enableSMS.saleSMS;
            } else {
                logger.error('Not expected to come here');
                logger.error('sale property not found');
            }
            await couchDBUtils.update(applicationSettings, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' enableSMS setting down migration failed';
        }
    }
};