/**
 */

'use strict';

import * as path from 'path';
import * as crypto from "crypto";
let logger;
const alg = 'aes192';
let serverId = '';
export const up = async (params) => {
    logger = params.logger;

    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let dbInstance = nanoClients.licencedb;


    try {
        let serverLicenceDoc = await dbInstance.get('profitGuruServerLicence_');
        serverId = serverLicenceDoc[0].clientId;
        let resp = await dbInstance.get('smsOffer');
        let smsDoc = resp[0];
        smsDoc.encrypt = decrypt(smsDoc.encrypt);

        smsDoc.encrypt = encrypt(smsDoc.encrypt);
        smsDoc.version = "2.0";
        await dbInstance.insert(smsDoc);

    } catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }
};

export const down = async (params) => {


};



function decrypt(data) {
    let decipher = crypto.createDecipher(alg, 'password');
    let decrypted = decipher.update(data, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return JSON.parse(decrypted);
}

export function encrypt(data) {
    let enSMSInfo = JSON.stringify(data);
    let cipher = crypto.createCipher(alg, serverId);
    let encrypted = cipher.update(enSMSInfo, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}
