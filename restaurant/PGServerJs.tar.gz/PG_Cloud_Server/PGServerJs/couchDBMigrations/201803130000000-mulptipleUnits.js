/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require('fs');
var path = require('path');
const moment = require('moment');
const P_PROFILE_PREFIX = 'pProfile';
exports.up = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const utils = require('../controllers/common/Utils');
        const CLONE = utils.clone;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        let coredb = nanoClients.coredb;
        let defaultProfileId = yield createOrGetDefaultPriceProfile(couchDBUtils, maindb);
        try {
            let allItemsDocs = yield couchDBUtils.getAllDocsByType('item', maindb);
            var docsToPush = [];
            for (var i = 0; i < allItemsDocs.length; i++) {
                if (!allItemsDocs[i].doc.info.hasOwnProperty('sellingUnitId')) {
                    continue;
                }
                if (allItemsDocs[i].doc.info.sellingUnitId !== allItemsDocs[i].doc.info.purchaseUnitId) {
                    let ProfilesData = {};
                    allItemsDocs[i].doc.info.unitsInfo = {};
                    let profileInfo = {
                        "sellingPrice": 0,
                        "discountId": allItemsDocs[i].doc.info.discountId
                    };
                    let unitInfo = {
                        "refUnitId": allItemsDocs[i].doc.info.sellingUnitId,
                        "factor": allItemsDocs[i].doc.info.conversionFactor,
                        "pProfilesData": {},
                        "purchasePrice": 0,
                        "mrp": 0
                    };
                    /**
                     * line 1
                     */
                    ProfilesData[defaultProfileId] = CLONE(profileInfo);
                    ProfilesData[defaultProfileId].sellingPrice = allItemsDocs[i].doc.info.sellingPrice * allItemsDocs[i].doc.info.conversionFactor;
                    ProfilesData[defaultProfileId].discountid = allItemsDocs[i].doc.info.discountId;
                    unitInfo.pProfilesData = CLONE(ProfilesData);
                    unitInfo.purchasePrice = allItemsDocs[i].doc.info.purchasePrice;
                    unitInfo.mrp = allItemsDocs[i].doc.info.mrp * allItemsDocs[i].doc.info.conversionFactor;
                    allItemsDocs[i].doc.info.unitsInfo[allItemsDocs[i].doc.info.purchaseUnitId] = CLONE(unitInfo);
                    /**
                     * line 2
                     */
                    //It is the same object .. so changing here changes the previous one also
                    ProfilesData = {};
                    ProfilesData[defaultProfileId] = CLONE(profileInfo);
                    ProfilesData[defaultProfileId].sellingPrice = allItemsDocs[i].doc.info.sellingPrice;
                    ProfilesData[defaultProfileId].discountid = allItemsDocs[i].doc.info.discountId;
                    //discountId
                    unitInfo.pProfilesData = CLONE(ProfilesData);
                    //conversion factor should be 1
                    unitInfo.purchasePrice = allItemsDocs[i].doc.info.purchasePrice / allItemsDocs[i].doc.info.conversionFactor;
                    unitInfo.mrp = allItemsDocs[i].doc.info.mrp;
                    unitInfo.factor = 1;
                    allItemsDocs[i].doc.info.unitsInfo[allItemsDocs[i].doc.info.sellingUnitId] = CLONE(unitInfo);
                    for (var batch in allItemsDocs[i].doc.batches) {
                        let ProfilesData = {};
                        allItemsDocs[i].doc.batches[batch].unitsInfo = {};
                        let profileInfo = {
                            "sellingPrice": 0,
                            "discountId": allItemsDocs[i].doc.batches[batch].discountId
                        };
                        let unitInfo = {
                            "refUnitId": allItemsDocs[i].doc.info.sellingUnitId,
                            "factor": allItemsDocs[i].doc.info.conversionFactor,
                            "pProfilesData": {},
                            "purchasePrice": 0,
                            "mrp": 0
                        };
                        /**
                         * line 1
                         */
                        ProfilesData[defaultProfileId] = CLONE(profileInfo);
                        ProfilesData[defaultProfileId].sellingPrice = allItemsDocs[i].doc.batches[batch].sellingPrice * allItemsDocs[i].doc.info.conversionFactor;
                        unitInfo.pProfilesData = ProfilesData;
                        unitInfo.mrp = allItemsDocs[i].doc.batches[batch].mrp * allItemsDocs[i].doc.info.conversionFactor;
                        unitInfo.purchasePrice = allItemsDocs[i].doc.batches[batch].purchasePrice;
                        allItemsDocs[i].doc.batches[batch].unitsInfo[allItemsDocs[i].doc.info.purchaseUnitId] = CLONE(unitInfo);
                        /**
                         * line 2
                         */
                        //same as above
                        //discountId for sellingunit and undefined for purchase unit
                        ProfilesData[defaultProfileId] = CLONE(profileInfo);
                        ProfilesData[defaultProfileId].sellingPrice = allItemsDocs[i].doc.batches[batch].sellingPrice;
                        unitInfo.pProfilesData = ProfilesData;
                        unitInfo.mrp = allItemsDocs[i].doc.batches[batch].mrp;
                        unitInfo.purchasePrice = allItemsDocs[i].doc.batches[batch].purchasePrice / allItemsDocs[i].doc.info.conversionFactor;
                        unitInfo.factor = 1;
                        allItemsDocs[i].doc.batches[batch].unitsInfo[allItemsDocs[i].doc.info.sellingUnitId] = CLONE(unitInfo);
                        delete allItemsDocs[i].doc.batches[batch].purchasePrice;
                        delete allItemsDocs[i].doc.batches[batch].sellingPrice;
                        delete allItemsDocs[i].doc.batches[batch].mrp;
                        //delete discountId
                    }
                }
                else {
                    let ProfilesData = {};
                    ProfilesData[defaultProfileId] = {
                        "sellingPrice": allItemsDocs[i].doc.info.sellingPrice,
                        "discountId": allItemsDocs[i].doc.info.discountId
                    };
                    allItemsDocs[i].doc.info.unitsInfo = {};
                    allItemsDocs[i].doc.info.unitsInfo[allItemsDocs[i].doc.info.purchaseUnitId] = {
                        "refUnitId": allItemsDocs[i].doc.info.sellingUnitId,
                        "factor": allItemsDocs[i].doc.info.conversionFactor,
                        "pProfilesData": ProfilesData,
                        "purchasePrice": allItemsDocs[i].doc.info.purchasePrice,
                        "mrp": allItemsDocs[i].doc.info.mrp
                    };
                    for (var batch in allItemsDocs[i].doc.batches) {
                        let pProfilesData = {};
                        pProfilesData[defaultProfileId] = {
                            "sellingPrice": allItemsDocs[i].doc.batches[batch].sellingPrice,
                            "discountId": allItemsDocs[i].doc.batches[batch].discountId
                        };
                        allItemsDocs[i].doc.batches[batch].unitsInfo = {};
                        allItemsDocs[i].doc.batches[batch].unitsInfo[allItemsDocs[i].doc.info.purchaseUnitId] = {
                            "refUnitId": allItemsDocs[i].doc.info.sellingUnitId,
                            "factor": allItemsDocs[i].doc.info.conversionFactor,
                            "pProfilesData": pProfilesData,
                            "purchasePrice": allItemsDocs[i].doc.batches[batch].purchasePrice,
                            "mrp": allItemsDocs[i].doc.batches[batch].mrp
                        };
                        delete allItemsDocs[i].doc.batches[batch].purchasePrice;
                        delete allItemsDocs[i].doc.batches[batch].sellingPrice;
                        delete allItemsDocs[i].doc.batches[batch].mrp;
                        //discountId
                    }
                }
                allItemsDocs[i].doc.info.baseUnitId = allItemsDocs[i].doc.info.sellingUnitId;
                allItemsDocs[i].doc.info.defaultPurchaseUnitId = allItemsDocs[i].doc.info.purchaseUnitId;
                allItemsDocs[i].doc.info.defaultSellingUnitId = allItemsDocs[i].doc.info.sellingUnitId;
                allItemsDocs[i].doc.info.bAutoComputePurchasePrice = false;
                allItemsDocs[i].doc.info.bAutoComputeMRP = false;
                allItemsDocs[i].doc.info.bAutoComputeSellingPrice = false;
                allItemsDocs[i].doc.info.multipleUnits = false;
                allItemsDocs[i].doc.info.bPProfiles = false;
                delete allItemsDocs[i].doc.info.sellingPrice;
                delete allItemsDocs[i].doc.info.purchasePrice;
                delete allItemsDocs[i].doc.info.mrp;
                delete allItemsDocs[i].doc.info.sellingUnitId;
                delete allItemsDocs[i].doc.info.purchaseUnitId;
                delete allItemsDocs[i].doc.info.conversionFactor;
                delete allItemsDocs[i].doc.info.category;
                delete allItemsDocs[i].doc.info.discount;
                delete allItemsDocs[i].doc.info.cost_price;
                delete allItemsDocs[i].doc.info.unit_price;
                delete allItemsDocs[i].doc.info.item_image;
                delete allItemsDocs[i].doc.info.is_deleted;
                delete allItemsDocs[i].doc.info.allow_alt_description;
                delete allItemsDocs[i].doc.info.hasMeasurementUnit;
                docsToPush.push(allItemsDocs[i].doc);
            }
            //Purchase Docs 
            let allPurchaseDocs = yield couchDBUtils.getAllDocsByType('receiving', maindb);
            for (var j = 0; j < allPurchaseDocs.length; j++) {
                if (allPurchaseDocs[j].doc.receiving_items) {
                    for (var k = 0; k < allPurchaseDocs[j].doc.receiving_items.length; k++) {
                        let recItem = yield couchDBUtils.getDoc('item_' + allPurchaseDocs[j].doc.receiving_items[k].item_id, maindb, "Failed to fetch the item_" + allPurchaseDocs[j].doc.receiving_items[k].item_id, true);
                        if (!allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('unit') || allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('baseUnitId')) {
                            continue;
                        }
                        if (recItem === "Failed to fetch the item_" + allPurchaseDocs[j].doc.receiving_items[k].item_id) {
                            var unitId = getUnitIdByName(allPurchaseDocs[j].doc.receiving_items[k].unit, couchDBUtils, maindb);
                            recItem = {
                                info: {
                                    purchaseUnitId: unitId,
                                    sellingUnitId: unitId,
                                    conversionFactor: 1
                                }
                            };
                            allPurchaseDocs[j].doc.receiving_items[k].conversionFactor = 1;
                        }
                        allPurchaseDocs[j].doc.receiving_items[k].unitId = recItem.info.purchaseUnitId;
                        allPurchaseDocs[j].doc.receiving_items[k].baseUnitId = recItem.info.sellingUnitId;
                        allPurchaseDocs[j].doc.receiving_items[k].unitsInfo = {};
                        if (allPurchaseDocs[j].doc.receiving_items[k].purchaseUnitId !== recItem.info.sellingUnitId) {
                            var pProfile = {};
                            pProfile[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: allPurchaseDocs[j].doc.receiving_items[k].sellingPrice * allPurchaseDocs[j].doc.receiving_items[k].conversionFactor
                            };
                            allPurchaseDocs[j].doc.receiving_items[k].unitsInfo[recItem.info.purchaseUnitId] = {
                                factor: allPurchaseDocs[j].doc.receiving_items[k].conversionFactor,
                                refUnitId: recItem.info.sellingUnitId,
                                mrp: allPurchaseDocs[j].doc.receiving_items[k].mrp * allPurchaseDocs[j].doc.receiving_items[k].conversionFactor,
                                purchasePrice: allPurchaseDocs[j].doc.receiving_items[k].purchasePrice,
                                pProfilesData: pProfile
                            };
                            //selling Unit
                            var pProfile1 = {};
                            pProfile1[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: allPurchaseDocs[j].doc.receiving_items[k].sellingPrice
                            };
                            allPurchaseDocs[j].doc.receiving_items[k].unitsInfo[recItem.info.sellingUnitId] = {
                                factor: 1,
                                refUnitId: recItem.info.sellingUnitId,
                                mrp: allPurchaseDocs[j].doc.receiving_items[k].mrp,
                                purchasePrice: allPurchaseDocs[j].doc.receiving_items[k].purchasePrice / allPurchaseDocs[j].doc.receiving_items[k].conversionFactor,
                                pProfilesData: pProfile1
                            };
                        }
                        else {
                            var pProfile1 = {};
                            pProfile1[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: allPurchaseDocs[j].doc.receiving_items[k].sellingPrice
                            };
                            allPurchaseDocs[j].doc.receiving_items[k].unitsInfo[recItem.info.purchaseUnitId] = {
                                factor: allPurchaseDocs[j].doc.receiving_items[k].conversionFactor,
                                refUnitId: recItem.info.sellingUnitId,
                                mrp: allPurchaseDocs[j].doc.receiving_items[k].mrp,
                                purchasePrice: allPurchaseDocs[j].doc.receiving_items[k].purchasePrice,
                                pProfilesData: pProfile1
                            };
                        }
                        delete allPurchaseDocs[j].doc.receiving_items[k].unit;
                    }
                }
                // console.log(allPurchaseDocs[j].doc);
                docsToPush.push(allPurchaseDocs[j].doc);
            }
            // receivingReturn
            let allPurchaseReturnDocs = yield couchDBUtils.getAllDocsByType('receivingReturn', maindb);
            for (var j = 0; j < allPurchaseReturnDocs.length; j++) {
                if (allPurchaseReturnDocs[j].doc.items) {
                    for (var k = 0; k < allPurchaseReturnDocs[j].doc.items.length; k++) {
                        let recItem = yield couchDBUtils.getDoc('item_' + allPurchaseReturnDocs[j].doc.items[k].item_id, maindb, "Failed to fetch the item_" + allPurchaseReturnDocs[j].doc.items[k].item_id, true);
                        if (!allPurchaseReturnDocs[j].doc.items[k].hasOwnProperty('unit') || allPurchaseReturnDocs[j].doc.items[k].hasOwnProperty('baseUnitId')) {
                            continue;
                        }
                        if (recItem === "Failed to fetch the item_" + allPurchaseReturnDocs[j].doc.items[k].item_id) {
                            var unitId = getUnitIdByName(allPurchaseReturnDocs[j].doc.items[k].unit, couchDBUtils, maindb);
                            recItem = {
                                info: {
                                    purchaseUnitId: unitId,
                                    sellingUnitId: unitId,
                                    conversionFactor: 1
                                }
                            };
                            allPurchaseReturnDocs[j].doc.items[k].conversionFactor = 1;
                        }
                        console.log(recItem);
                        allPurchaseReturnDocs[j].doc.items[k].unitId = recItem.info.purchaseUnitId;
                        allPurchaseReturnDocs[j].doc.items[k].baseUnitId = recItem.info.sellingUnitId;
                        allPurchaseReturnDocs[j].doc.items[k].unitsInfo = {};
                        var stockKeys = Object.keys(recItem.batches);
                        var stockKey = stockKeys[0];
                        if (stockKeys.indexOf(allPurchaseReturnDocs[j].doc.items[k].stockKey) !== -1) {
                            stockKey = allPurchaseReturnDocs[j].doc.items[k].stockKey;
                        }
                        let sellingPrice = recItem.batches[stockKey].sellingPrice;
                        if (allPurchaseReturnDocs[j].doc.items[k].purchaseUnitId !== recItem.info.sellingUnitId) {
                            var pProfile = {};
                            pProfile[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: sellingPrice * allPurchaseReturnDocs[j].doc.items[k].conversionFactor
                            };
                            allPurchaseReturnDocs[j].doc.items[k].unitsInfo[recItem.info.purchaseUnitId] = {
                                factor: allPurchaseReturnDocs[j].doc.items[k].conversionFactor,
                                refUnitId: recItem.info.sellingUnitId,
                                mrp: allPurchaseReturnDocs[j].doc.items[k].mrp * allPurchaseReturnDocs[j].doc.items[k].conversionFactor,
                                purchasePrice: allPurchaseReturnDocs[j].doc.items[k].purchasePrice,
                                pProfilesData: pProfile
                            };
                            //selling Unit
                            var pProfile1 = {};
                            pProfile1[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: sellingPrice
                            };
                            allPurchaseReturnDocs[j].doc.items[k].unitsInfo[recItem.info.sellingUnitId] = {
                                factor: 1,
                                refUnitId: recItem.info.sellingUnitId,
                                mrp: allPurchaseReturnDocs[j].doc.items[k].mrp,
                                purchasePrice: allPurchaseReturnDocs[j].doc.items[k].purchasePrice / allPurchaseReturnDocs[j].doc.items[k].conversionFactor,
                                pProfilesData: pProfile1
                            };
                        }
                        else {
                            var pProfile1 = {};
                            pProfile1[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: sellingPrice
                            };
                            allPurchaseReturnDocs[j].doc.items[k].unitsInfo[recItem.info.purchaseUnitId] = {
                                factor: allPurchaseReturnDocs[j].doc.items[k].conversionFactor,
                                refUnitId: recItem.info.sellingUnitId,
                                mrp: allPurchaseReturnDocs[j].doc.items[k].mrp,
                                purchasePrice: allPurchaseReturnDocs[j].doc.items[k].purchasePrice,
                                pProfilesData: pProfile1
                            };
                        }
                        delete allPurchaseReturnDocs[j].doc.items[k].unit;
                    }
                }
                // console.log(allPurchaseReturnDocs[j].doc);
                docsToPush.push(allPurchaseReturnDocs[j].doc);
            }
            /**sales Multiple units */
            let allSalesDocs = yield couchDBUtils.getAllDocsByType('sale', maindb);
            for (var j = 0; j < allSalesDocs.length; j++) {
                allSalesDocs[j].doc.sales_info.pProfileId = defaultProfileId;
                if (allSalesDocs[j].doc.sale_items) {
                    for (var k = 0; k < allSalesDocs[j].doc.sale_items.length; k++) {
                        let saleItem = yield couchDBUtils.getDoc('item_' + allSalesDocs[j].doc.sale_items[k].item_id, maindb, "Failed to fetch the item_" + allSalesDocs[j].doc.sale_items[k].item_id, true);
                        if (!allSalesDocs[j].doc.sale_items[k].hasOwnProperty('unit') || allSalesDocs[j].doc.sale_items[k].hasOwnProperty('baseUnitId')) {
                            continue;
                        }
                        if (saleItem === "Failed to fetch the item_" + allSalesDocs[j].doc.sale_items[k].item_id) {
                            var unitId = getUnitIdByName(allSalesDocs[j].doc.sale_items[k].unit, couchDBUtils, maindb);
                            saleItem = {
                                info: {
                                    purchaseUnitId: unitId,
                                    sellingUnitId: unitId,
                                    conversionFactor: 1
                                }
                            };
                            allSalesDocs[j].doc.sale_items[k].conversionFactor = 1;
                        }
                        allSalesDocs[j].doc.sale_items[k].unitId = saleItem.info.sellingUnitId;
                        allSalesDocs[j].doc.sale_items[k].baseUnitId = saleItem.info.sellingUnitId;
                        allSalesDocs[j].doc.sale_items[k].unitsInfo = {};
                        if (saleItem.info.sellingUnitId !== saleItem.info.purchaseUnitId) {
                            var pProfile = {};
                            pProfile[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: allSalesDocs[j].doc.sale_items[k].sellingPrice * saleItem.info.conversionFactor
                            };
                            allSalesDocs[j].doc.sale_items[k].unitsInfo[saleItem.info.purchaseUnitId] = {
                                factor: saleItem.info.conversionFactor,
                                refUnitId: saleItem.info.sellingUnitId,
                                mrp: allSalesDocs[j].doc.sale_items[k].mrp * saleItem.info.conversionFactor,
                                purchasePrice: allSalesDocs[j].doc.sale_items[k].purchasePrice,
                                pProfilesData: pProfile
                            };
                            //selling Unit
                            var pProfile1 = {};
                            pProfile1[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: allSalesDocs[j].doc.sale_items[k].sellingPrice
                            };
                            allSalesDocs[j].doc.sale_items[k].unitsInfo[saleItem.info.sellingUnitId] = {
                                factor: 1,
                                refUnitId: saleItem.info.sellingUnitId,
                                mrp: allSalesDocs[j].doc.sale_items[k].mrp,
                                purchasePrice: allSalesDocs[j].doc.sale_items[k].purchasePrice / saleItem.info.conversionFactor,
                                pProfilesData: pProfile1
                            };
                        }
                        else {
                            var pProfile1 = {};
                            pProfile1[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: allSalesDocs[j].doc.sale_items[k].sellingPrice
                            };
                            allSalesDocs[j].doc.sale_items[k].unitsInfo[saleItem.info.purchaseUnitId] = {
                                factor: saleItem.info.conversionFactor,
                                refUnitId: saleItem.info.sellingUnitId,
                                mrp: allSalesDocs[j].doc.sale_items[k].mrp,
                                purchasePrice: allSalesDocs[j].doc.sale_items[k].purchasePrice,
                                pProfilesData: pProfile1
                            };
                        }
                        delete allSalesDocs[j].doc.sale_items[k].unit;
                    }
                }
                docsToPush.push(allSalesDocs[j].doc);
            }
            yield couchDBUtils.bulkInsert(maindb, docsToPush);
            //sales return 
            let allSaleRetunDocs = yield couchDBUtils.getAllDocsByType('saleReturn', maindb);
            for (var j = 0; j < allSaleRetunDocs.length; j++) {
                allSaleRetunDocs[j].doc.info.pProfileId = defaultProfileId;
                if (allSaleRetunDocs[j].doc.items) {
                    for (var k = 0; k < allSaleRetunDocs[j].doc.items.length; k++) {
                        let saleItem = yield couchDBUtils.getDoc('item_' + allSaleRetunDocs[j].doc.items[k].item_id, maindb, "Failed to fetch the item_" + allSaleRetunDocs[j].doc.items[k].item_id, true);
                        if (!allSaleRetunDocs[j].doc.items[k].hasOwnProperty('unit') || allSaleRetunDocs[j].doc.items[k].hasOwnProperty('baseUnitId')) {
                            continue;
                        }
                        if (saleItem === "Failed to fetch the item_" + allSaleRetunDocs[j].doc.items[k].item_id) {
                            var unitId = getUnitIdByName(allSaleRetunDocs[j].doc.items[k].unit, couchDBUtils, maindb);
                            saleItem = {
                                info: {
                                    purchaseUnitId: unitId,
                                    sellingUnitId: unitId,
                                    conversionFactor: 1
                                }
                            };
                            allSaleRetunDocs[j].doc.items[k].conversionFactor = 1;
                        }
                        allSaleRetunDocs[j].doc.items[k].unitId = saleItem.info.sellingUnitId;
                        allSaleRetunDocs[j].doc.items[k].baseUnitId = saleItem.info.sellingUnitId;
                        allSaleRetunDocs[j].doc.items[k].unitsInfo = {};
                        if (saleItem.info.sellingUnitId !== saleItem.info.purchaseUnitId) {
                            var pProfile = {};
                            pProfile[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: allSaleRetunDocs[j].doc.items[k].sellingPrice * saleItem.info.conversionFactor
                            };
                            allSaleRetunDocs[j].doc.items[k].unitsInfo[saleItem.info.purchaseUnitId] = {
                                factor: saleItem.info.conversionFactor,
                                refUnitId: saleItem.info.sellingUnitId,
                                mrp: allSaleRetunDocs[j].doc.items[k].mrp * saleItem.info.conversionFactor,
                                purchasePrice: allSaleRetunDocs[j].doc.items[k].purchasePrice,
                                pProfilesData: pProfile
                            };
                            //selling Unit
                            var pProfile1 = {};
                            pProfile1[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: allSaleRetunDocs[j].doc.items[k].sellingPrice
                            };
                            allSaleRetunDocs[j].doc.items[k].unitsInfo[saleItem.info.sellingUnitId] = {
                                factor: 1,
                                refUnitId: saleItem.info.sellingUnitId,
                                mrp: allSaleRetunDocs[j].doc.items[k].mrp,
                                purchasePrice: allSaleRetunDocs[j].doc.items[k].purchasePrice / saleItem.info.conversionFactor,
                                pProfilesData: pProfile1
                            };
                        }
                        else {
                            var pProfile1 = {};
                            pProfile1[defaultProfileId] = {
                                discountId: "",
                                sellingPrice: allSaleRetunDocs[j].doc.items[k].sellingPrice
                            };
                            allSaleRetunDocs[j].doc.items[k].unitsInfo[saleItem.info.purchaseUnitId] = {
                                factor: saleItem.info.conversionFactor,
                                refUnitId: saleItem.info.sellingUnitId,
                                mrp: allSaleRetunDocs[j].doc.items[k].mrp,
                                purchasePrice: allSaleRetunDocs[j].doc.items[k].purchasePrice,
                                pProfilesData: pProfile1
                            };
                        }
                        delete allSaleRetunDocs[j].doc.items[k].unit;
                    }
                }
                docsToPush.push(allSaleRetunDocs[j].doc);
            }
            yield couchDBUtils.bulkInsert(maindb, docsToPush);
            let applicationSettings = yield couchDBUtils.getDoc('profitGuruApplicationSettings_', coredb);
            applicationSettings.salesConfig.pProfileId = defaultProfileId;
            applicationSettings.salesConfig.pProfileSettings = {
                "defaultProfile": defaultProfileId
            };
            yield couchDBUtils.update(applicationSettings, coredb, 3);
        }
        catch (err) {
            logger.error(err);
            throw migrationName + ' up migration failed';
        }
    });
};
exports.down = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        try {
            /**
             * create default profile
             */
            let defaultProfileId = yield createOrGetDefaultPriceProfile(couchDBUtils, maindb);
            function processBatch(itemBatch, DSU, DPU) {
                itemBatch.discountId = itemBatch.unitsInfo[DSU].pProfilesData[defaultProfileId].discountId;
                itemBatch.mrp = itemBatch.unitsInfo[DSU].mrp;
                itemBatch.sellingPrice = itemBatch.unitsInfo[DSU].pProfilesData[defaultProfileId].sellingPrice;
                itemBatch.purchasePrice = itemBatch.unitsInfo[DPU].purchasePrice;
                delete itemBatch.unitsInfo;
            }
            let allItemsDocs = yield couchDBUtils.getAllDocsByType('item', maindb);
            /**
             *
             */
            let docsToPush = [];
            for (var i = 0; i < allItemsDocs.length; i++) {
                for (var batch in allItemsDocs[i].doc.batches) {
                    processBatch(allItemsDocs[i].doc.batches[batch], allItemsDocs[i].doc.info.defaultSellingUnitId, allItemsDocs[i].doc.info.defaultPurchaseUnitId);
                }
                allItemsDocs[i].doc.info.sellingPrice = allItemsDocs[i].doc.info.unitsInfo[allItemsDocs[i].doc.info.defaultSellingUnitId].pProfilesData[defaultProfileId].sellingPrice;
                allItemsDocs[i].doc.info.purchasePrice = allItemsDocs[i].doc.info.unitsInfo[allItemsDocs[i].doc.info.defaultPurchaseUnitId].purchasePrice;
                allItemsDocs[i].doc.info.mrp = allItemsDocs[i].doc.info.unitsInfo[allItemsDocs[i].doc.info.defaultSellingUnitId].mrp;
                allItemsDocs[i].doc.info.sellingUnitId = allItemsDocs[i].doc.info.defaultSellingUnitId;
                allItemsDocs[i].doc.info.purchaseUnitId = allItemsDocs[i].doc.info.defaultPurchaseUnitId;
                allItemsDocs[i].doc.info.conversionFactor = allItemsDocs[i].doc.info.unitsInfo[allItemsDocs[i].doc.info.defaultPurchaseUnitId].factor;
                delete allItemsDocs[i].doc.info.baseUnitId;
                delete allItemsDocs[i].doc.info.defaultPurchaseUnitId;
                delete allItemsDocs[i].doc.info.defaultSellingUnitId;
                delete allItemsDocs[i].doc.info.bAutoComputePurchasePrice;
                delete allItemsDocs[i].doc.info.bAutoComputeMRP;
                delete allItemsDocs[i].doc.info.bAutoComputeSellingPrice;
                delete allItemsDocs[i].doc.info.unitsInfo;
                delete allItemsDocs[i].doc.info.multipleUnits;
                delete allItemsDocs[i].doc.info.bPProfiles;
                docsToPush.push(allItemsDocs[i].doc);
            }
            /**Purchase Multiple Units */
            let allPurchaseDocs = yield couchDBUtils.getAllDocsByType('receiving', maindb);
            for (var j = 0; j < allPurchaseDocs.length; j++) {
                for (var k = 0; k < allPurchaseDocs[j].doc.receiving_items.length; k++) {
                    if (allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('unitId')) {
                        delete allPurchaseDocs[j].doc.receiving_items[k].unitId;
                    }
                    if (allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('baseUnitId')) {
                        delete allPurchaseDocs[j].doc.receiving_items[k].baseUnitId;
                    }
                    if (allPurchaseDocs[j].doc.receiving_items[k].hasOwnProperty('unitsInfo')) {
                        delete allPurchaseDocs[j].doc.receiving_items[k].unitsInfo;
                    }
                }
                docsToPush.push(allPurchaseDocs[j].doc);
            }
            /**Sales Multiple Units */
            let allSalesDocs = yield couchDBUtils.getAllDocsByType('sale', maindb);
            for (var j = 0; j < allSalesDocs.length; j++) {
                if (allSalesDocs[j].doc.sales_info.hasOwnProperty('pProfileId')) {
                    console.log('Hello');
                    delete allSalesDocs[j].doc.sales_info.pProfileId;
                }
                for (var k = 0; k < allSalesDocs[j].doc.sale_items.length; k++) {
                    if (allSalesDocs[j].doc.sale_items[k].hasOwnProperty('unitId')) {
                        delete allSalesDocs[j].doc.sale_items[k].unitId;
                    }
                    if (allSalesDocs[j].doc.sale_items[k].hasOwnProperty('baseUnitId')) {
                        delete allSalesDocs[j].doc.sale_items[k].baseUnitId;
                    }
                    if (allSalesDocs[j].doc.sale_items[k].hasOwnProperty('unitsInfo')) {
                        delete allSalesDocs[j].doc.sale_items[k].unitsInfo;
                    }
                }
                docsToPush.push(allSalesDocs[j].doc);
            }
            yield couchDBUtils.bulkInsert(maindb, docsToPush);
        }
        catch (err) {
            logger.error(err);
            throw migrationName + ' down migration failed';
        }
    });
};
function createOrGetDefaultPriceProfile(couchDBUtils, dbInstance) {
    return __awaiter(this, void 0, void 0, function* () {
        var defaultProfileId = -1;
        let resp = yield couchDBUtils.getAllDocsByType(P_PROFILE_PREFIX, dbInstance);
        for (var idx in resp) {
            if ((resp[idx].doc.name).toLowerCase() === 'default profile') {
                defaultProfileId = resp[idx].doc.id;
            }
        }
        if (defaultProfileId === -1) {
            const timeStamp = moment().valueOf();
            let createResp = yield couchDBUtils.create({
                _id: P_PROFILE_PREFIX + '_' + timeStamp,
                name: 'Default Profile',
                description: 'default profile',
                id: timeStamp
            }, dbInstance, 1, 'Internal Server Error Try Again');
            defaultProfileId = parseInt(createResp[0].id.substr(createResp[0].id.indexOf('_') + 1, createResp[0].id.length)); //createResp.id;
        }
        return defaultProfileId;
    });
}
;
function getUnitIdByName(name, couchDBUtils, dbInstance) {
    return __awaiter(this, void 0, void 0, function* () {
        var unitId = -1;
        let resp = yield couchDBUtils.getAllDocsByType('unit', dbInstance);
        for (var unitIdx in resp) {
            if ((resp[unitIdx].doc.name).toLowerCase() === name.toLowerCase()) {
                unitId = resp[unitIdx].doc.id;
            }
        }
        return unitId;
    });
}
//# sourceMappingURL=201803130000000-mulptipleUnits.js.map