/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const crypto = require("crypto");
let logger;
const alg = 'aes192';
let serverId = '';
exports.up = (params) => __awaiter(this, void 0, void 0, function* () {
    logger = params.logger;
    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let dbInstance = nanoClients.licencedb;
    try {
        let serverLicenceDoc = yield dbInstance.get('profitGuruServerLicence_');
        serverId = serverLicenceDoc[0].clientId;
        let resp;
        try {
            resp = yield dbInstance.get('smsOffer');
        }
        catch (e) {
            logger.error("Cannot fetch the smsOffer Doc");
            return;
        }
        let smsDoc = resp[0];
        if (smsDoc.version && smsDoc.version === '2.0') {
            return;
        }
        smsDoc.encrypt = decrypt(smsDoc.encrypt);
        smsDoc.encrypt = encrypt(smsDoc.encrypt);
        smsDoc.version = "2.0";
        yield dbInstance.insert(smsDoc);
    }
    catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }
});
exports.down = (params) => __awaiter(this, void 0, void 0, function* () {
});
function decrypt(data) {
    let decipher = crypto.createDecipher(alg, 'password');
    let decrypted = decipher.update(data, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return JSON.parse(decrypted);
}
function encrypt(data) {
    let enSMSInfo = JSON.stringify(data);
    let cipher = crypto.createCipher(alg, serverId);
    let encrypted = cipher.update(enSMSInfo, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}
exports.encrypt = encrypt;
//# sourceMappingURL=201901100000000-smsEnCrypt_v2.js.map