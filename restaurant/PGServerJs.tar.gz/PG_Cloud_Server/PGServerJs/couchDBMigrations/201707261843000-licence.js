/**
 */

'use strict';
const path = require('path');
const migrationName = path.basename(__filename, '.js');

const crypto = require('crypto');
const algorithm = 'aes-256-ctr';

function clone(obj) {
    if (null == obj || "object" != typeof obj) {
        return obj
    };

    var copy = obj.constructor();
    for (var attr in obj) {
        if (obj.hasOwnProperty(attr)) {
            copy[attr] = obj[attr];
        }
    }

    return copy;
}

function encrypt(licenceJson, password) {
    let licenceString = JSON.stringify(licenceJson);
    let cipher = crypto.createCipher(algorithm, password);
    let crypted = cipher.update(licenceString, 'utf8', 'hex');
    crypted += cipher.final('hex');
    return crypted;
}

function decrypt(encLicence, password) {
    let decipher = crypto.createDecipher(algorithm, password);
    let decLicence = decipher.update(encLicence, 'hex', 'utf8');
    decLicence += decipher.final('utf8');

    decLicence = JSON.parse(decLicence);
    return decLicence;
}

module.exports = {
    up: async function(params) {

        //Query all documents
        //if desktop
        //Decrypt, change clientid, encrypt and write document

        let logger = params.logger;

        try {
            let nanoClients = params.nanoClients;
            let nanoLicenceDB = nanoClients.licencedb;
            const appRootPath = params.migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            const macUtils = require(appRootPath + 'common/macUtils');
            const moment = require('moment');
            let macAddress = macUtils.getMacAddress();
            macAddress = macAddress.replace(/:/gi, '-');
            let macAddressArray = macUtils.getMacAddressArray();

            let queryResp = await nanoLicenceDB.fetch({}, {
                startkey: 'l',
                endkey: 'm'
            });

            let allDocs = queryResp[0].rows;
            let docs2Add = [];
            let docs2Delete = [];
            for (let i = 0; i < allDocs.length; i++) {
                let doc = allDocs[i].doc;
                if (doc.clientType !== 'DeskTopApp') {
                    logger.info('clientType<' + doc.clientType + '> is not DesktopApp');
                    continue;
                }

                let newDoc = clone(doc);
                newDoc.createTimeStamp = moment().format('x');
                delete newDoc._rev;

                let idPrefix;
                let encLicKey;
                let passwordKey;
                if (doc._id.indexOf('licenceapply_') === 0) {
                    idPrefix = 'licenceapply_';
                    encLicKey = 'enDeviceInfo';
                    passwordKey = 'candClientId';

                } else if (doc._id.indexOf('licence_') === 0) {
                    idPrefix = 'licence_';
                    encLicKey = 'enlicence';
                    passwordKey = 'clientId'
                } else {
                    logger.error(doc._id + ' Not expected to come here');
                    continue;
                }
                newDoc._id = idPrefix + macAddress;
                newDoc[passwordKey] = macAddress;

                //Decrypt
                let decLicence = decrypt(doc[encLicKey], doc[passwordKey]);
                decLicence.clientId = macAddress;
                decLicence.serialNumber = macAddress;
                decLicence.macs = macAddressArray;

                //Encrypt
                let encLicence = encrypt(decLicence, newDoc[passwordKey]);
                newDoc[encLicKey] = encLicence;
                //Deleting the old doc                
                doc._deleted = true;
                docs2Delete.push(doc);
                docs2Add.push(newDoc);
            }

            if (docs2Delete.length) {
                await couchDBUtils.bulkInsert(nanoLicenceDB, docs2Delete);
                await couchDBUtils.bulkInsert(nanoLicenceDB, docs2Add);
                logger.info('licence docs updated');
            }

        } catch (error) {
            logger.error(error);
            logger.error('Updating Licence Documents Failed');
            throw migrationName + " failed";
        }
    },
    down: async function(params) {
        let logger = params.logger;
        try {
            let nanoClients = params.nanoClients;
            let nanoLicenceDB = nanoClients.licencedb;

        } catch (error) {
            logger.error(error);
            let errMsg = migrationName + " failed";
            logger.error(errMsg);
            throw errMsg;
        }
    }
};