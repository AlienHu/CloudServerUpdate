/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

let itemIdConvFactorMap = {};

async function batchProcess(batchSize, docType, processFun, params) {
    let skip = 0;
    let itemDocsObj = {};
    while (true) {
        params.logger.info('Current Count <' + skip + ' >');
        let allDocs = await params.couchDBUtils.getAllDocsByType(docType, params.dbInstance, {
            limit: batchSize,
            skip: skip
        });
        skip += allDocs.length;

        await processFun(allDocs, params);

        if (allDocs.length !== batchSize) {
            params.logger.info('Total Process Count<' + skip + '>');
            break;
        }
    }
}

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const configState = require(appRootPath + 'common/configState');
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;

        let mainDBInstance = params.nanoClients.maindb;
        try {
            await batchProcess(10, 'receiving', processReceivings, {
                dbInstance: mainDBInstance,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            await batchProcess(10, 'receivingReturn', processReceivings, {
                dbInstance: mainDBInstance,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
        } catch (error) {
            logger.error(error);
            throw migrationName + 'up migration failed';
        }

        async function processReceivings(allReceivingDocs, params) {
            let itemDocsObj = params.itemDocsObj;

            let docs2Update = [];
            for (let i = 0; i < allReceivingDocs.length; i++) {
                let items = allReceivingDocs[i].doc.receiving_items;
                if (!items) {
                    items = allReceivingDocs[i].doc.items;
                }

                if (!items) {
                    continue;
                }

                let bDocChanged = false;
                for (let j = 0; j < items.length; j++) {
                    let item_id = items[j].item_id.toString();
                    if (!itemIdConvFactorMap[item_id]) {
                        let itemDoc = await couchDBUtils.getDoc('item_' + item_id, mainDBInstance);
                        itemIdConvFactorMap[item_id] = itemDoc.info.conversionFactor;
                    }
                    let conversionFactor = itemIdConvFactorMap[item_id];
                    if (items[j].conversionFactor === undefined) {
                        bDocChanged = true;
                        items[j].quantity_purchased = items[j].quantity_purchased / conversionFactor;
                        items[j].conversionFactor = conversionFactor;
                    }
                }

                docs2Update.push(allReceivingDocs[i].doc);
            }

            if (docs2Update.length) {
                await couchDBUtils.bulkInsert(mainDBInstance, docs2Update);
            }
        }

    },

    down: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const configState = require(appRootPath + 'common/configState');
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;

        let mainDBInstance = params.nanoClients.maindb;
        try {
            await batchProcess(10, 'receiving', processReceivings, {
                dbInstance: mainDBInstance,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            await batchProcess(10, 'receivingReturn', processReceivings, {
                dbInstance: mainDBInstance,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
        } catch (error) {
            logger.error(error);
            throw migrationName + 'up migration failed';
        }

        async function processReceivings(allReceivingDocs, params) {
            let itemDocsObj = params.itemDocsObj;

            let docs2Update = [];
            for (let i = 0; i < allReceivingDocs.length; i++) {

                let items = allReceivingDocs[i].doc.receiving_items;
                if (!items) {
                    items = allReceivingDocs[i].doc.items;
                }

                if (!items) {
                    continue;
                }

                let bDocChanged = false;
                for (let j = 0; j < items.length; j++) {
                    let conversionFactor = items[j].conversionFactor;
                    if (conversionFactor !== undefined) {
                        bDocChanged = true;
                        items[j].quantity_purchased = items[j].quantity_purchased * conversionFactor;
                        delete items[j].conversionFactor;
                    }
                }

                if (bDocChanged) {
                    docs2Update.push(allReceivingDocs[i].doc);
                }
            }

            if (docs2Update.length) {
                await couchDBUtils.bulkInsert(mainDBInstance, docs2Update);
            }
        }
    }
};