"use strict";
//This is mostly used for sales. When purchase comes rename the file or make the functions common
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTaxesByPercentageDetailed = function (itemArr, taxDetailedItrObj, taxNamesItrObj, hsnTaxesItrObj) {
    for (let i = 0; i < itemArr.length; i++) {
        exports.getDetailedTaxByPerc(itemArr[i], taxDetailedItrObj, taxNamesItrObj, hsnTaxesItrObj);
    }
};
/**
 * Didn't review this function
 * @param item
 * @param taxDetailedItrObj
 * @param taxNamesItrObj
 * @param hsnTaxesItrObj
 */
//Not using type for item because taxItrObj1 will be error
// export let getDetailedTaxByPerc = function (item: ReceiptSaleItem, taxDetailedItrObj: TaxDetailedItrObj, taxNamesItrObj: TaxNamesItrObj, hsnTaxesItrObj: HsnTaxesItrObj) {
exports.getDetailedTaxByPerc = function (item, taxDetailedItrObj, taxNamesItrObj, hsnTaxesItrObj) {
    let taxes = item.itemTaxList;
    let hasHSN = (item.hsn) ? true : false;
    item.totalAfterDisAndCharges = item.totalAfterDisAndCharges ? item.totalAfterDisAndCharges : (item.totalNoTaxWithDiscount ? item.totalNoTaxWithDiscount : item.subTotal); //report enhancement changes
    if (hasHSN && !hsnTaxesItrObj[item.hsn])
        hsnTaxesItrObj[item.hsn] = {};
    for (let j = 0; j < taxes.length; j++) {
        let percent = (taxes[j].percent) ? taxes[j].percent.toString() : "0";
        let name = taxes[j].name;
        let amtTemp = item.totalAfterDisAndCharges * percent * 0.01; //taxes[j].Amt !== undefined ? taxes[j].Amt : item.taxes[taxes[j].name]; //using item.taxes[taxes[j].name] for report enhancement changes
        if (hasHSN) {
            if (hsnTaxesItrObj[item.hsn][name] && hsnTaxesItrObj[item.hsn][name][percent]) {
                hsnTaxesItrObj[item.hsn][name][percent] += amtTemp;
                if (name != "SGST") {
                    hsnTaxesItrObj[item.hsn].taxable += item.totalAfterDisAndCharges;
                }
            }
            else {
                if (!hsnTaxesItrObj[item.hsn][name])
                    hsnTaxesItrObj[item.hsn][name] = {};
                hsnTaxesItrObj[item.hsn][name][percent] = amtTemp;
                hsnTaxesItrObj[item.hsn].taxable = item.totalAfterDisAndCharges;
            }
        }
        if ((name == 'CGST') || (name == 'SGST')) {
            percent = parseFloat(percent) * 2;
        }
        if (taxDetailedItrObj[percent] && taxDetailedItrObj[percent][name] || (taxDetailedItrObj[percent] && taxDetailedItrObj[percent][name] === 0)) {
            taxDetailedItrObj[percent][name] = taxDetailedItrObj[percent][name] + amtTemp;
            // sgst is hardcoded to avoid adding two times in case of cgst and sgst
            if (name != "SGST")
                taxDetailedItrObj[percent].taxable = taxDetailedItrObj[percent].taxable + item.totalAfterDisAndCharges;
        }
        else {
            if (!taxNamesItrObj[name])
                taxNamesItrObj[name] = true;
            if (!taxDetailedItrObj[percent]) {
                taxDetailedItrObj[percent] = {};
                taxDetailedItrObj[percent].taxable = item.totalAfterDisAndCharges;
            }
            taxDetailedItrObj[percent][name] = amtTemp;
        }
    }
};
//# sourceMappingURL=taxDetailsCommon.js.map