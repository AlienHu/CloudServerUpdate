/**
 */

'use strict';

let fs = require('fs');
let path = require('path');

module.exports = {
    up: async function(params) {
            let logger = params.logger;
            let migrationsBasePath = params.migrationsBasePath;

            const appRootPath = migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
            let migrationName = path.basename(__filename, '.js');
            params.migrationName = migrationName;
            let nanoClients = params.nanoClients;
            let maindb = nanoClients.maindb;

            try {
                const commonLib = require('../controllers/libraries/commonLib');
                const utils = require('../controllers/common/Utils');
                var computeUtils = require('../controllers/common/computeUtils');
                const CLONE = utils.clone;

                // it will add all taxes and create total variable
                async function getTaxTotal(items) {

                    for (let i = 0; i < items.length; i++) {
                        if (items[i].taxes.Total !== undefined) {
                            continue;
                        }
                        let total = 0;
                        items[i].taxes.Total = 0;
                        for (let w in items[i].taxes) {
                            total += items[i].taxes[w];
                        }
                        items[i].taxes.Total = total;
                    }
                }

                async function computeItemTotal(items, globalDiscount) {
                    for (var i = 0; i < items.length; i++) {
                        var item = CLONE(items[i]);
                        item.totalTaxPercent = 0;

                        for (var j = 0; j < item.itemTaxList.length; j++) {
                            var tax = item.itemTaxList[j];
                            // totalTaxPercent += tax.percent;
                            item.totalTaxPercent += tax.percent;
                        }

                        item.purchasePrice = commonLib.getPPFromUInfo(item.unitsInfo, item.unitId);
                        var price = computeUtils.getPriceTaxEx(item.purchasePrice, item.bPPTaxInclusive, item.totalTaxPercent);
                        item.purchasePriceExTax = price;
                        item.quantity = item.quantity ? item.quantity : item.quantity_purchased;
                        item.total = price * item.quantity;
                        delete item.quantity_purchased;

                        item.totalNoTaxNoDiscount = item.purchasePriceExTax * item.quantity;
                        item.discount = item.discount ? item.discount : 0;
                        item.totalNoTaxWithDiscount = item.totalNoTaxNoDiscount * (1 - item.discount * 0.01);

                        item.totalWithTax = item.total;
                        item.total = item.totalNoTaxWithDiscount * (1 + item.totalTaxPercent * 0.01);

                        if (globalDiscount && globalDiscount.hasOwnProperty('method')) {
                            if (globalDiscount.method == 'onTaxable') {
                                item.totalNoTaxWithDiscount = item.totalNoTaxNoDiscount * (1 - (globalDiscount.percent + item.discount) * 0.01);
                                item.total = item.totalNoTaxWithDiscount * (1 + item.totalTaxPercent * 0.01);
                            } else if (globalDiscount.method == 'onTotal') {
                                item.total = item.total * (1 - (globalDiscount.percent) * 0.01);
                                item.totalNoTaxWithDiscount = item.total / ((1 + item.totalTaxPercent * 0.01));
                                item.totalNoTaxNoDiscount = item.totalNoTaxWithDiscount / (1 - ((globalDiscount.percent + item.discount) * 0.01));
                                // item.total = item.totalNoTaxWithDiscount * (1 + item.totalTaxPercent * 0.01);
                            }
                        }
                        items[i].total = item.total;
                    }
                }

                /**sales Multiple units */
                let paramObject = {
                    include_docs: true // waste
                }

                //purchase return 
                // let allPurchaseRetunDocs = await couchDBUtils.getAllDocIdsByType('receivingReturn', maindb, paramObject);
                await batchProcess(1000, 'receivingReturn', processPuchaseReturnDocs, {
                    dbInstance: maindb,
                    couchDBUtils: couchDBUtils,
                    logger: logger
                });
                async function processPuchaseReturnDocs(allPurchaseRetunDocs) {
                    let docsToPush = [];
                    for (let k = 0; k < allPurchaseRetunDocs.length; k++) {
                        if (typeof allPurchaseRetunDocs[k].doc.info !== 'string' && allPurchaseRetunDocs[k].doc.info.type === 3) {
                            continue;
                        }
                        console.log(allPurchaseRetunDocs[k].id);
                        allPurchaseRetunDocs[k].doc = commonLib.transformSaleDoc(allPurchaseRetunDocs[k].doc, 'purchaseReturn');

                        await getTaxTotal(allPurchaseRetunDocs[k].doc.items);
                        console.log("tax total Done")
                        let globalDiscount = allPurchaseRetunDocs[k].doc.info.discount;
                        await computeItemTotal(allPurchaseRetunDocs[k].doc.items, globalDiscount);
                        // console.log("total Done")
                        allPurchaseRetunDocs[k].doc = await commonLib.encodeTransDoc(allPurchaseRetunDocs[k].doc, 'purchaseReturn');
                        docsToPush.push(allPurchaseRetunDocs[k].doc);
                    }
                    await couchDBUtils.bulkInsert(maindb, docsToPush);
                    console.log('purchase return tax total issue done');
                }

            } catch (err) {
                logger.error(err);
                throw migrationName + ' up migration failed';
            }

        },

        down: async function(params) {
            let logger = params.logger;
            let migrationName = path.basename(__filename, '.js');
            params.migrationName = migrationName;
            let migrationsBasePath = params.migrationsBasePath;
            let nanoClients = params.nanoClients;
            let maindb = nanoClients.maindb;

            try {
                //as if now down migration is not required
                //todo write code if down is rquired

            } catch (err) {
                logger.error(err);
                throw migrationName + ' down migration failed';
            }
        }
};