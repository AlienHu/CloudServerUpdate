/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        const utils = require('../controllers/common/Utils');
        const CLONE = utils.clone;

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        let coredb = nanoClients.coredb;
        const configsController = require('../controllers/GlobalConfigurations');

        try {
            let unitDocs = await couchDBUtils.getAllDocsByType('unit', maindb);
            let defaultUnitId = 0;
            for (var i = 0; i < unitDocs.length; i++) {
                if (unitDocs[i].doc.name.toLowerCase() === 'nos' || unitDocs[i].doc.name.toLowerCase() === '') {
                    defaultUnitId = unitDocs[i].doc.id;
                }
            }
            if (!defaultUnitId) {
                defaultUnitId = unitDocs[0].doc.id;
            }
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coredb);

            applicationSettings.defaultUnitSettings = {
                "id": defaultUnitId
            };

            await couchDBUtils.update(applicationSettings, coredb, 3);

        } catch (err) {
            logger.error(err);
            throw migrationName + ' up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;

        try {
            /**
             * create default profile
             */
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coredb);
            if (applicationSettings.hasOwnProperty('defaultUnitSettings')) {
                delete applicationSettings.defaultUnitSettings;
            }
            await couchDBUtils.update(applicationSettings, coredb, 3);

        } catch (err) {
            logger.error(err);
            throw migrationName + ' down migration failed';
        }
    }
};