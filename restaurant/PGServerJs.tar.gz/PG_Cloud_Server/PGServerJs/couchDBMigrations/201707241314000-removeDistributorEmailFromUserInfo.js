/**
 */

'use strict';

var path = require('path');
let migrationName = path.basename(__filename, '.js');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoUsers = nanoClients._users;
        try {

            var viewParams = {};
            await couchDBUtils2.createCouchDbAndViews(nanoUsers, '_users');
            let allUsers = await couchDBUtils.getView('employees', 'all', viewParams, nanoUsers);
            let allUsersDoc = [];
            for (var i = 0; i < allUsers.length; i++) {
                if (allUsers[i].value.hasOwnProperty('isDistributor') || allUsers[i].value.hasOwnProperty('distributorEmail')) {
                    delete allUsers[i].value.isDistributor;
                    delete allUsers[i].value.distributorEmail;
                } else {
                    logger.error('this user doesn\'t has distributor details');
                }
                allUsersDoc.push(allUsers[i].value);

            }
            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;

        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            var viewParams = {};

            let allUsers = await couchDBUtils.getView('employees', 'all', viewParams, nanoUsers);
            let allUsersDoc = [];
            for (var i = 0; i < allUsers.length; i++) {
                if (allUsers[i].value.roles[1] === 'admin') {
                    allUsers[i].value.isDistributor = false;
                    allUsers[i].value.distributorEmail = '';
                    allUsersDoc.push(allUsers[i].value);
                }
            }

            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);
        } catch (error) {
            logger.error(error);
            logger.error('remove distributor details from users info  update failed');

            throw migrationName + ' down migration failed';
        }
    }
};