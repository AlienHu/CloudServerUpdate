/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const moment = require("moment");
exports.up = (params) => __awaiter(this, void 0, void 0, function* () {
    let logger = params.logger;
    let nanoClients = params.nanoClients;
    const mainDBInstance = nanoClients.maindb;
    let migrationName = path.basename(__filename, '.js');
    try {
        let allCmpDocsArr = yield getAllCmpDocs(mainDBInstance, logger);
        let newDocs = [];
        for (let i = 0; i < allCmpDocsArr.length; i++) {
            // @ts-ignore
            let cmp = allCmpDocsArr[i].doc;
            for (let j = 0; j < cmp.customers.length; j++) {
                // @ts-ignore
                if (cmp.customers[j].status) {
                    // @ts-ignore
                    cmp.customers[j].smsStatus = cmp.customers[j].status;
                    cmp.customers[j].cAppStatus = cmp.customers[j].smsStatus;
                    // @ts-ignore
                    delete cmp.customers[j].status;
                }
            }
            newDocs.push(cmp);
        }
        if (newDocs.length) {
            yield bulkDocs(newDocs, mainDBInstance, undefined, undefined, logger);
        }
    }
    catch (error) {
        logger.error(error);
        throw migrationName + ' up migration failed';
    }
});
exports.down = (params) => __awaiter(this, void 0, void 0, function* () {
    let logger = params.logger;
    let nanoClients = params.nanoClients;
    const mainDBInstance = nanoClients.maindb;
    let migrationName = path.basename(__filename, '.js');
    try {
        let allCmpDocs = yield getAllCmpDocs(mainDBInstance, logger);
        let newDocs = [];
        for (let i = 0; i < allCmpDocs.length; i++) {
            // @ts-ignore
            let cmp = allCmpDocs[i].doc;
            for (let j = 0; j < cmp.customers.length; j++) {
                // @ts-ignore
                if (cmp.customers[j].smsStatus) {
                    // @ts-ignore
                    cmp.customers[j].status = cmp.customers[j].smsStatus;
                    // @ts-ignore
                    delete cmp.customers[j].cAppStatus;
                }
            }
            newDocs.push(cmp);
        }
        if (newDocs.length) {
            yield bulkDocs(newDocs, mainDBInstance, undefined, undefined, logger);
        }
    }
    catch (error) {
        logger.error(error);
        throw migrationName + ' up migration failed';
    }
});
const getAllDocsByType = function (type, db, params, bOnlyDocs, logger) {
    return __awaiter(this, void 0, void 0, function* () {
        params = params || {};
        params.startkey = type + '_';
        params.endkey = type + '_z';
        params.include_docs = true;
        try {
            let [body, header] = yield db.fetch({}, params);
            if (!bOnlyDocs) {
                return body.rows;
            }
            else {
                //This is just wasting of 1 for loop for the inconvinience of having to write body.rows[i].doc everytime
                //Bad don't use it
                let resp = [];
                for (let i = 0; i < body.rows.length; i++) {
                    resp.push(body.rows[i].doc);
                }
                return resp;
            }
        }
        catch (err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        }
    });
};
const bulkDocs = function (docsArray, db, reTryCount, docType, logger) {
    return __awaiter(this, void 0, void 0, function* () {
        if (reTryCount === undefined) {
            reTryCount = 99;
        }
        if (reTryCount === 0) {
            throw 'Out of trials';
        }
        if (docType) {
            let ts = parseInt(moment().format("x"));
            docsArray.forEach(function (doc) {
                if (!doc._id) {
                    doc._id = docType + '_' + ts;
                    ts += 1;
                }
            });
        }
        try {
            let resp = yield db.bulk({
                docs: docsArray
            });
            let pendingDocs = [];
            for (let i = 0; i < resp.length; i++) {
                if (resp[i].error || resp[i].reason) {
                    if (resp[i].error === 'conflict' || resp[i].reason === 'Document update conflict.') {
                        throw resp[i]._id + ' Document update conflict.';
                    }
                    pendingDocs.push(docsArray[i]);
                }
            }
            if (pendingDocs.length) {
                return yield bulkDocs(pendingDocs, db, reTryCount - 1, undefined, logger);
            }
            return 0;
        }
        catch (error) {
            logger.error(error);
            logger.error('bulkInsert2 catch block. Not Expected to come here');
            throw 'Internal Error';
        }
    });
};
const getAllCmpDocs = (mainDBInstance, logger) => __awaiter(this, void 0, void 0, function* () {
    let allCmpDocsArr = [];
    let respRowArr = yield getAllDocsByType('cmp', mainDBInstance, undefined, false, logger);
    Array.prototype.push.apply(allCmpDocsArr, respRowArr);
    respRowArr = yield getAllDocsByType('wisher', mainDBInstance, undefined, false, logger);
    Array.prototype.push.apply(allCmpDocsArr, respRowArr);
    respRowArr = yield getAllDocsByType('scheduler', mainDBInstance, undefined, false, logger);
    Array.prototype.push.apply(allCmpDocsArr, respRowArr);
    return allCmpDocsArr;
});
let COMPLETED = 'completed';
//# sourceMappingURL=201810230000000-cmp.js.map