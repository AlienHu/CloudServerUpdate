/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
let stateList = [];
let stateShortcutsList = [];
exports.up = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindbInstance = nanoClients.maindb;
        let coredbInstance = nanoClients.coredb;
        try {
            let stateCodesDoc = (yield coredbInstance.get('stateCodes'))[0];
            loadStateCodes(stateCodesDoc);
            let allDocsRespRowArr = (yield maindbInstance.fetch({}, {
                include_docs: true,
                startkey: 'customer_',
                endkey: 'customer_x'
            }))[0];
            let docs2UpdateArr = [];
            for (let i = 0; i < allDocsRespRowArr.rows.length; i++) {
                let doc = allDocsRespRowArr.rows[i].doc;
                const gstin_number = doc.gstin_number;
                if (gstin_number) {
                    let stateCode = gstin_number.substr(0, 2);
                    stateCode = (parseInt(stateCode)).toString();
                    if (!stateCodesDoc[stateCode]) {
                        logger.error('stateCode<' + stateCode + '> Customer<' + doc._id + '>');
                        continue;
                    }
                    const state_name = stateCodesDoc[stateCode].state_name;
                    if (doc.state_name !== state_name) {
                        doc.state_name = state_name;
                        docs2UpdateArr.push(doc);
                    }
                }
                else if (doc.state_name) {
                    let stateName = capitalize(doc.state_name);
                    if (stateList.indexOf(stateName) > -1) {
                        doc.state_name = stateName;
                        docs2UpdateArr.push(doc);
                    }
                    else if (stateShortcutsList.indexOf(stateName.toUpperCase()) > -1) {
                        doc.state_name = stateList[stateList.indexOf(stateName)];
                        docs2UpdateArr.push(doc);
                    }
                }
            }
            if (docs2UpdateArr.length) {
                yield maindbInstance.bulk({
                    docs: docs2UpdateArr
                });
            }
        }
        catch (error) {
            logger.error(error);
            throw migrationName + 'up migration failed';
        }
    });
};
exports.down = function () {
    return __awaiter(this, void 0, void 0, function* () {
        //no action required
        return;
    });
};
function capitalize(str) {
    return str.replace(/\w\S*/g, function (txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    });
}
function loadStateCodes(stateCodesDoc) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            for (let key in stateCodesDoc) {
                if (['_id', '_rev', 'timeStamp'].indexOf(key) < 0) {
                    stateList.push(stateCodesDoc[key].state_name);
                    stateShortcutsList.push(stateCodesDoc[key].name);
                }
            }
        }
        catch (error) {
            console.log('tryin again');
            setTimeout(function () {
                loadStateCodes(stateCodesDoc);
            }, 1000);
        }
        ;
    });
}
;
//# sourceMappingURL=201810310000000-customerState.js.map