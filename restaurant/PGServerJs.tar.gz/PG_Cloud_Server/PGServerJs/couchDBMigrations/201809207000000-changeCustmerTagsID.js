/**
 */

'use strict';

var fs = require('fs');
var path = require('path');
const NEW_TAGS_ID = "customers_tags";
const OLD_TAGS_ID = "customer_tags";

module.exports = {
    up: async function(params) {
            let logger = params.logger;
            let migrationsBasePath = params.migrationsBasePath;

            const appRootPath = migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            const couchDBUtils2 = require('../couchDb/couchDBUtils2');
            const utils = require('../controllers/common/Utils');
            const CLONE = utils.clone;

            let migrationName = path.basename(__filename, '.js');
            params.migrationName = migrationName;
            let nanoClients = params.nanoClients;
            let maindb = nanoClients.maindb;
            try {
                let oldTags = await couchDBUtils.getDocEx(OLD_TAGS_ID, maindb);
                let newTags = {
                    _id: NEW_TAGS_ID,
                    tags: oldTags.tags
                }
                await couchDBUtils.create(newTags, maindb);
                await couchDBUtils.delete(oldTags, maindb);
            } catch (err) {
                if (err.reason === 'missing' || err.reason === 'deleted') {
                    logger.info("Missing the old doc, migration not needed.");
                    return;
                }
                logger.error(err);
                throw migrationName + ' up migration failed';
            }
        },

        down: async function(params) {
            let logger = params.logger;
            let migrationName = path.basename(__filename, '.js');
            params.migrationName = migrationName;
            let migrationsBasePath = params.migrationsBasePath;
            const appRootPath = migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            const couchDBUtils2 = require('../couchDb/couchDBUtils2');
            let nanoClients = params.nanoClients;
            let maindb = nanoClients.maindb;
            let nanoUsers = nanoClients._users;

            try {

                try {
                    let newTags = await couchDBUtils.getDocEx(NEW_TAGS_ID, maindb);
                    let oldTags = {
                        _id: OLD_TAGS_ID,
                        tags: newTags.tags
                    }
                    await couchDBUtils.create(oldTags, maindb);
                    await couchDBUtils.delete(newTags, maindb);
                } catch (e) {
                    if (e.reason === 'missing' || e.reason === 'deleted') {
                        logger.info("Missing the new doc, migration not needed.");
                        return;
                    }
                    throw e;
                }

            } catch (err) {
                logger.error(err);
                throw migrationName + ' down migration failed';
            }
        }
};