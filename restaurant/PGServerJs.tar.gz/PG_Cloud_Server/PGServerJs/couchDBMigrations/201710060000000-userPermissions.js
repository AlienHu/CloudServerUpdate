/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;
        try {

            var params = {};
            await couchDBUtils2.createCouchDbAndViews(nanoUsers, '_users');
            console.log('hello');
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);

            var allUsersDoc = [];
            for (var i = 0; i < allUsers.length; i++) {
                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                delete allUsers[i].value.roles[0].globalConfigs;

                delete allUsers[i].value.roles[0].orderCounter;
                delete allUsers[i].value.roles[0].paymentCounter;
                delete allUsers[i].value.roles[0].tableReservations;
                delete allUsers[i].value.roles[0].tallyIntegration;
                var json = {
                    desc: "Category, Taxes, Discounts, ...",
                    allowNone: false,
                    allowAll: false,
                    viewOnMenu: false,
                    add: {
                        apis: ["createCategory", "createTax", "createDiscount", "createUnit", "createCharge", "createSlab", "createProfile", "createBrand", "createVariant"],
                        allowed: false,
                        desc: "Allows to Create :: Category, Discounts, Taxes, Discounts, .."
                    },
                    view: {
                        apis: [],
                        allowed: false,
                        desc: "Allowes to View :: Category, Discounts, Taxes, Discounts, .."
                    },
                    delete: {
                        apis: ["deleteCategory", "deleteTax", "deleteDiscount", "deleteUnit", "deleteCharge", "deleteSlab", "deleteProfile", "deleteBrand", "deleteVariant"],
                        allowed: false,
                        desc: "Allowes to Delete :: Category, Discounts, Taxes, Discounts, .."
                    },
                    update: {
                        apis: ["updateCategory", "updateTax", "updateDiscount", "updateUnit", "updateCharge", "updateSlab", "updateProfile", "updateBrand", "updateVariant"],
                        allowed: false,
                        desc: "Allowes to Update :: Category, Discounts, Taxes, Discounts, .."
                    }
                };

                var seetingsJson = {
                    desc: "Allows to Change or View the Application Settings",
                    apis: ["ConfigSettings4customersLoyalityRestApi", "saveConfigRestAPI", "saveLocaleConfigRestAPI", "saveBarcodeRestApi", "saveLocationsRestAPI", "savePrinterSettingsRestApi", "BackupDBRestApi"],
                    installUpdate: {},
                    viewBackup: {},
                    takeBackup: {},
                    restoreBackup: {},
                    checkApplicationUpdates: {}
                };

                seetingsJson.view = allUsers[i].value.roles[0].applicationSettings.view;
                seetingsJson.update = allUsers[i].value.roles[0].applicationSettings.update;
                seetingsJson.viewOnMenu = allUsers[i].value.roles[0].applicationSettings.viewOnMenu;
                seetingsJson.allowNone = allUsers[i].value.roles[0].applicationSettings.allowNone;
                seetingsJson.allowAll = allUsers[i].value.roles[0].applicationSettings.allowAll;
                // seetingsJson.checkApplicationUpdates = allUsers[i].value.roles[0].profitGuruUpdate.view;

                if (allUsers[i].value.roles[0].profitGuruUpdate && allUsers[i].value.roles[0].profitGuruUpdate) {
                    seetingsJson.installUpdate = Object.assign({}, allUsers[i].value.roles[0].profitGuruUpdate.installUpdate);
                    seetingsJson.viewBackup = Object.assign({}, allUsers[i].value.roles[0].backUpAndRestore.view);
                    seetingsJson.takeBackup = Object.assign({}, allUsers[i].value.roles[0].backUpAndRestore.backup);
                    seetingsJson.restoreBackup = Object.assign({}, allUsers[i].value.roles[0].backUpAndRestore.restore);
                    seetingsJson.checkApplicationUpdates = Object.assign({}, allUsers[i].value.roles[0].profitGuruUpdate.view);
                    delete allUsers[i].value.roles[0].backUpAndRestore;
                    delete allUsers[i].value.roles[0].profitGuruUpdate;
                }
                // delete allUsers[i].value.roles[0].applicationSettings;
                // delete allUsers[i].value.roles[0].applicationSettings.Delete;
                allUsers[i].value.roles[0].applicationSettings = seetingsJson;
                if (allUsers[i].value.roles[1] === 'admin') {
                    json.allowAll = true;
                    json.viewOnMenu = true;
                    json.add.allowed = true;
                    json.view.allowed = true;
                    json.delete.allowed = true;
                    json.update.allowed = true;

                }
                allUsers[i].value.roles[0].purchases.apis = ["getReceivingsRestApi"];

                if (allUsers[i].value.APP_TYPE === 'retail') {
                    allUsers[i].value.roles[0].sales.apis = ["getSalesRestApi"];
                    if (allUsers[i].value.roles[0].sales.makeSale.apis.indexOf("printSaleRestApi") === -1) {
                        allUsers[i].value.roles[0].sales.makeSale.apis.push("printSaleRestApi");
                    }
                    if (allUsers[i].value.roles[0].sales.makeReturn.apis.indexOf("printSaleRestApi") === -1) {
                        allUsers[i].value.roles[0].sales.makeReturn.apis.push("printSaleRestApi");
                    }

                } else if (allUsers[i].value.APP_TYPE === 'restaurant') {
                    allUsers[i].value.roles[0].takeAway.apis = ["getSalesRestApi"];
                    //TODO: remove getSalesRestApi and get getReceivingsRestAPi from sub permissions
                    if (allUsers[i].value.roles[0].takeAway.makeSale.apis.indexOf("printSaleRestApi") === -1) {
                        allUsers[i].value.roles[0].takeAway.makeSale.apis.push("printSaleRestApi");
                    }
                    if (allUsers[i].value.roles[0].takeAway.makeReturn.apis && allUsers[i].value.roles[0].takeAway.makeSale.apis.indexOf("printSaleRestApi") === -1) {
                        allUsers[i].value.roles[0].takeAway.makeReturn.apis.push("printSaleRestApi");
                    } else {
                        allUsers[i].value.roles[0].takeAway.makeReturn.apis = ["getSalesRestApi", "additemRestApi", "removeitemRestApi", "add_paymentRestApi", "completeSaleRestApi", "getCartTaxes", "addCustomer2SaleRestApi", "receiptRestApi", "printReceiptApi", "setPrintAfterSaleRestApi", "setInvoiceNumberEnabledRestApi", "setInvoiceNumberRestApi", "invoiceRestApi", "DeleteItemFromCartRestApi", "getItemsRestApi", "cancel_saleRestApi", "changeModeRestApi", "makeCustomerCreditPayment", "printSaleRestApi"];
                    }
                }

                if (allUsers[i].value.APP_TYPE !== 'retail') {
                    delete allUsers[i].value.roles[0].sales;
                }

                if (allUsers[i].value.APP_TYPE !== 'restaurant') {
                    delete allUsers[i].value.roles[0].tables;
                    delete allUsers[i].value.roles[0].takeAway;
                }

                if (allUsers[i].value.APP_TYPE !== 'petrolbunk') {
                    delete allUsers[i].value.roles[0].petrolbunk;
                }

                if (allUsers[i].value.APP_TYPE !== 'lodging') {
                    delete allUsers[i].value.roles[0].hotel;
                }

                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                allUsersDoc.push(allUsers[i].value);
            }

            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);

            let allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', nanoCore);
            // allowedFeatures.itemManagement = {};
            let coreDocs = [];

            // allowedFeatures.itemManagement = allowedFeatures.globalConfigs;
            allowedFeatures.itemManagement = Object.assign({
                "enabled": true,
                "desc": ""
            }, allowedFeatures.globalConfigs);
            delete allowedFeatures.globalConfigs;

            coreDocs.push(allowedFeatures);

            await couchDBUtils.bulkInsert(nanoCore, coreDocs);

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            /**
             * ignoring revertion of profitGuruUpdate and backupandRestore entitlements from applicationsettings to outside as for now 
             * because of assumption that will not break old functionality 
             * also , in this migration we are not moving back tallyIntegration , counterorder and counter payment from inProgress to restaurant app specific json
             */
            var params = {};
            let allUsersDoc = [];
            console.log('hello');
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            for (var i = 0; i < allUsers.length; i++) {
                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                if (allUsers[i].value.roles[0].hasOwnProperty('itemManagement')) {
                    allUsers[i].value.roles[0].globalConfigs = {};
                    allUsers[i].value.roles[0].globalConfigs = Object.assign({}, allUsers[i].value.roles[0].itemManagement);
                    delete allUsers[i].value.roles[0].itemManagement;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('itemManagement property not found');
                }

                console.log(allUsers[i].value.APP_TYPE);
                delete allUsers[i].value.roles[0].purchases.apis;
                delete allUsers[i].value.roles[0].sales.apis;
                delete allUsers[i].value.roles[0].takeAway.apis;
                if (allUsers[i].value.APP_TYPE === 'retail' && allUsers[i].value.roles[0].sales) {
                    while (allUsers[i].value.roles[0].sales.makeSale.apis.indexOf("printSaleRestApi") !== -1) {
                        allUsers[i].value.roles[0].sales.makeSale.apis.splice(allUsers[i].value.roles[0].sales.makeSale.apis.indexOf("printSaleRestApi"), 1);
                    }
                    while (allUsers[i].value.roles[0].sales.makeReturn.apis.indexOf("printSaleRestApi") !== -1) {
                        allUsers[i].value.roles[0].sales.makeReturn.apis.splice(allUsers[i].value.roles[0].sales.makeReturn.apis.indexOf("printSaleRestApi"), 1);
                    }
                }
                if (allUsers[i].value.APP_TYPE === 'restaurant' && allUsers[i].value.roles[0].takeAway) {
                    while (allUsers[i].value.roles[0].takeAway.makeSale.apis.indexOf("printSaleRestApi") !== -1) {
                        allUsers[i].value.roles[0].takeAway.makeSale.apis.splice(allUsers[i].value.roles[0].takeAway.makeSale.apis.indexOf("printSaleRestApi"), 1);
                    }
                    if (allUsers[i].value.roles[0].takeAway.makeReturn.apis) {
                        while (allUsers[i].value.roles[0].takeAway.makeReturn.apis.indexOf("printSaleRestApi") !== -1) {
                            allUsers[i].value.roles[0].takeAway.makeReturn.apis.splice(allUsers[i].value.roles[0].takeAway.makeReturn.apis.indexOf("printSaleRestApi"), 1);
                        }
                    }
                }
                var salesJson = {
                    desc: "",
                    allowNone: false,
                    allowAll: false,
                    viewOnMenu: false,
                    sendEmail: {
                        apis: ["/common/sendEmailApi"],
                        common: true,
                        allowed: false,
                        desc: "Allows to Send the Email to the Customer"
                    },
                    makeSale: {
                        allowed: false,
                        desc: "Allows to Add Items to Cart,Accept Payments, Complete Sale and to Generate Print Receipt on printer if configured.",
                        apis: ["getSalesRestApi", "additemRestApi", "removeitemRestApi", "add_paymentRestApi", "completeSaleRestApi", "getCartTaxes", "addCustomer2SaleRestApi", "receiptRestApi", "printReceiptApi", "setPrintAfterSaleRestApi", "setInvoiceNumberEnabledRestApi", "setInvoiceNumberRestApi", "invoiceRestApi", "DeleteItemFromCartRestApi", "getItemsRestApi", "cancel_saleRestApi", "changeModeRestApi", "makeCustomerCreditPayment", "printSaleRestApi"]
                    },
                    makeReturn: {
                        allowed: false,
                        desc: "Allows Returning of Sold Items.",
                        apis: ["getSalesRestApi", "additemRestApi", "removeitemRestApi", "add_paymentRestApi", "completeSaleRestApi", "getCartTaxes", "addCustomer2SaleRestApi", "receiptRestApi", "printReceiptApi", "setPrintAfterSaleRestApi", "setInvoiceNumberEnabledRestApi", "setInvoiceNumberRestApi", "invoiceRestApi", "DeleteItemFromCartRestApi", "getItemsRestApi", "cancel_saleRestApi", "changeModeRestApi", "makeCustomerCreditPayment", "printSaleRestApi"]
                    },
                    editPrice: {
                        allowed: false,
                        desc: "Allows to Modify the Price While making the Sale.",
                        apis: ["editItemRestApi"]
                    },
                    editDiscount: {
                        allowed: false,
                        desc: "Allows to Modify Discount Percents%",
                        apis: ["editItemRestApi", "getItemDiscountRestApi"]
                    },
                    suspendSales: {
                        allowed: false,
                        desc: "Allows to View Suspened Sales of OtherUsers",
                        apis: ["allSuspendedSalesRestApi", "suspendSaleRestApi"]
                    },
                    unsuspendSales: {
                        allowed: false,
                        desc: "Allows to View Suspened Sales of OtherUsers",
                        apis: ["unsuspendSaleRestApi"]
                    },
                    viewOthersSuspendedSales: {
                        allowed: false,
                        desc: "Allows to View Suspened Sales of OtherUsers"
                    },
                    unsuspendOthersSales: {
                        allowed: false,
                        desc: "Allows to Unsuspend the Sales"
                    },
                    deleteOthersSuspendedSales: {
                        allowed: false,
                        desc: "Allows to Delete Suspened Sales of OtherUsers"
                    },
                    salesHistory: {
                        view: {
                            apis: ["handled@ClientSide", "manageRestApi"],
                            allowed: false,
                            desc: "Allows to View Sales History"
                        },
                        update: {
                            apis: ["update", "saveEditSalesRestApi"],
                            allowed: false,
                            desc: "Allows to Modify Sales History"
                        },
                        delete: {
                            apis: ["delete", "deleteSaleRestApi"],
                            allowed: false,
                            desc: "Allows to Delete Sales History"
                        }
                    }

                }

                if (allUsers[i].value.APP_TYPE !== 'retail') {

                    allUsers[i].value.roles[0].sales = salesJson;
                }
                var tableJson = {
                    desc: "",
                    allowNone: false,
                    allowAll: false,
                    viewOnMenu: false,
                    createTable: {
                        apis: ["createTableRestApi"],
                        allowed: false,
                        desc: "Allows to Create Table"
                    },
                    deleteTable: {
                        apis: ["deleteTableApiRestApi"],
                        allowed: false,
                        desc: "Allows to Delete Table"
                    },
                    editPrice: {
                        apis: ["editItemRestApi"],
                        allowed: false,
                        desc: "Allows to Edit price of the item"
                    },
                    editDiscount: {
                        apis: ["editItemRestApi"],
                        allowed: false,
                        desc: "Allows to Edit Discount of the Item"
                    },
                    takeOrder: {
                        apis: ["additemRestApi", "add_paymentRestApi", "completeSaleRestApi", "getCartTaxes", "addCustomer2SaleRestApi", "receiptRestApi", "printReceiptApi", "setPrintAfterSaleRestApi", "setInvoiceNumberEnabledRestApi", "setInvoiceNumberRestApi", "invoiceRestApi", "DeleteItemFromCartRestApi", "getItemsRestApi", "checkAlreadyReservedRestApi", "getReservationDetails"],
                        allowed: false,
                        desc: "Allows to Take Order For the Table"
                    },
                    cancelOreder: {
                        apis: ["cancel_saleRestApi"],
                        allowed: false,
                        desc: "Allows to Cancel the Order"
                    },
                    editKot: {
                        apis: ["editSaveKOTRestApi"],
                        allowed: false,
                        desc: "Allows to Edit KOT"
                    },
                    editDiscounts: {
                        apis: ["editItemRestApi"],
                        allowed: false,
                        desc: "Allows to Edit the Discount "
                    },
                    takePayment: {
                        apis: ["add_paymentRestApi"],
                        allowed: false,
                        desc: "Allows to Make Payment"
                    },
                    completeOrder: {
                        apis: ["completeTakeOrderRestApi"],
                        allowed: false,
                        desc: "Allows to Complete the Order"
                    },
                    billSplit: {
                        apis: ["splitBillRestApi"],
                        allowed: false,
                        desc: "Allows to Split the Order Bill"
                    }
                };
                if (allUsers[i].value.APP_TYPE !== 'restaurant') {
                    allUsers[i].value.roles[0].tables = tableJson;
                    allUsers[i].value.roles[0].takeAway = salesJson;
                }

                if (allUsers[i].value.APP_TYPE !== 'petrolbunk') {
                    allUsers[i].value.roles[0].petrolbunk = {
                        desc: "petrol bunk",
                        allowNone: false,
                        allowAll: false,
                        viewOnMenu: false,
                        sendSMS: {
                            apis: ["/common/sendSMS"],
                            common: true,
                            allowed: false,
                            desc: "Allows to send promo sms"
                        }
                    };
                }

                if (allUsers[i].value.APP_TYPE !== 'lodging') {
                    allUsers[i].value.roles[0].hotel = {
                        desc: "Allows to manage the rooms",
                        allowNone: false,
                        allowAll: false,
                        viewOnMenu: false,
                        createTarrif: {
                            apis: ["/hotel/createTarrif"],
                            allowed: false,
                            desc: "Allows to create new tarrifs"
                        }
                    };
                }

                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                allUsersDoc.push(allUsers[i].value);
            }

            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);
            let allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', nanoCore);
            let coreDocs = [];
            allowedFeatures.globalConfigs = Object.assign({}, allowedFeatures.itemManagement);
            delete allowedFeatures.itemManagement;

            coreDocs.push(allowedFeatures);

            await couchDBUtils.bulkInsert(nanoCore, coreDocs);

        } catch (error) {
            logger.error(error);
            logger.error(' down user permissions failed');
            throw error;
        }
    }
};