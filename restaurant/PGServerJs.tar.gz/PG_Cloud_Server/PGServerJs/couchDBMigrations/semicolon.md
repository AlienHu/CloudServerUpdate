1. have 1000 item docs in array 
2. get the item info of each item of each sale 
3. verify name , category values 
4. review the values of following variable and reform the string 
  ##sale item
     name,
     category,
     hsn,
     uniqueItemCode,
     batchId,
     skuName,
     unit,
     stock_name,
     serialnumber

  ##sale info
     invoicePrefix,
     wcInfo,
     customer,
     employee,
     comment,
     vehicle_phNo,
     vehicleNo,
     deliveryBoy,
     shippingDetails

5. if extra semicolon found remove it from  the original element docs as well

Questions : 
* name can also be number ; category name also can be number , so how can be sure about the item id ?
* 

##### Revised ######
## items
* get all the item docs 
* get all the categories
* check if item name has semicolon 
* check if category name has semicolon
* if yes get all the corresponding sale docs
* replace semicolon with ""



## customers/employees
* get all the customer docs 
* get all the employee docs
* check if customer name has semicolon 
* check if employee name has semicolon
* if yes get all the corresponding sale docs
* replace semicolon with ""


## customers/employees
* get all the invoice prefixes
* check if invoice prefixes has semicolon 
* if yes get all the corresponding sale docs
* replace semicolon with ""