/** */
'use strict';
var fs = require('fs');
var path = require('path');
module.exports = {
    up: async function(params) {

            let logger = params.logger;
            let migrationsBasePath = params.migrationsBasePath;

            const appRootPath = migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            const utils = require('../controllers/common/Utils');
            const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
            const CLONE = utils.clone;

            let migrationName = path.basename(__filename, '.js');
            params.migrationName = migrationName;
            let nanoClients = params.nanoClients;
            let maindb = nanoClients.maindb;
            try {
                const taxLib = require('../TSControllers/libraries/taxDetailsCommon');
                const commonLib = require('../controllers/libraries/commonLib');
                const getTaxesByPercentageDetailed = taxLib.getTaxesByPercentageDetailed;

                //compute purchase

                // let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', maindb);
                await batchProcess(1000, 'receiving', processPuchaseDocs, {
                    dbInstance: maindb,
                    couchDBUtils: couchDBUtils,
                    logger: logger
                });

                async function processPuchaseDocs(allPurchaseDocs) {
                    let docsToPush = [];
                    for (var j = 0; j < allPurchaseDocs.length; j++) {
                        if (typeof allPurchaseDocs[j].doc.receivings_info !== 'string' && allPurchaseDocs[j].doc.receivings_info.type === 3) {
                            continue;
                        }
                        allPurchaseDocs[j].doc = commonLib.transformSaleDoc(allPurchaseDocs[j].doc, 'purchase');
                        for (var q = 0; q < allPurchaseDocs[j].doc.receiving_items.length; q++) {
                            let itemCalculations = computePurItem(allPurchaseDocs[j].doc.receiving_items[q], allPurchaseDocs[j].doc.receivings_info.discount);
                            allPurchaseDocs[j].doc.receiving_items[q].totalNoTaxWithDiscount = itemCalculations.subTotal;
                        }
                        allPurchaseDocs[j].doc.receivings_info.taxDetailed = {};
                        allPurchaseDocs[j].doc.receivings_info.taxNames = {};
                        allPurchaseDocs[j].doc.receivings_info.hsnTaxes = {};
                        getTaxesByPercentageDetailed(allPurchaseDocs[j].doc.receiving_items, allPurchaseDocs[j].doc.receivings_info.taxDetailed, allPurchaseDocs[j].doc.receivings_info.taxNames, allPurchaseDocs[j].doc.receivings_info.hsnTaxes);

                        allPurchaseDocs[j].doc = await commonLib.encodeTransDoc(allPurchaseDocs[j].doc, 'purchase');
                        docsToPush.push(allPurchaseDocs[j].doc);
                    }
                    await couchDBUtils.bulkInsert(maindb, docsToPush);
                    console.log('recalculation tax purchase_v2 done');
                }

                //compute purchase Return

                // let allPurchaseRetunDocs = await couchDBUtils.getAllDocsByType('receivingReturn', maindb);
                await batchProcess(1000, 'receivingReturn', processPuchaseReturnDocs, {
                    dbInstance: maindb,
                    couchDBUtils: couchDBUtils,
                    logger: logger
                });
                async function processPuchaseReturnDocs(allPurchaseRetunDocs) {
                    let retdDocsToPush = [];
                    for (var j = 0; j < allPurchaseRetunDocs.length; j++) {
                        if (typeof allPurchaseRetunDocs[j].doc.info !== 'string' && allPurchaseRetunDocs[j].doc.info.type === 3) {
                            continue;
                        }
                        allPurchaseRetunDocs[j].doc = commonLib.transformSaleDoc(allPurchaseRetunDocs[j].doc, 'purchaseReturn');
                        for (var q = 0; q < allPurchaseRetunDocs[j].doc.items.length; q++) {
                            let itemCalculations = computePurItem(allPurchaseRetunDocs[j].doc.items[q], allPurchaseRetunDocs[j].doc.info.discount);
                            allPurchaseRetunDocs[j].doc.items[q].totalNoTaxWithDiscount = itemCalculations.subTotal;
                        }
                        allPurchaseRetunDocs[j].doc.info.taxDetailed = {};
                        allPurchaseRetunDocs[j].doc.info.taxNames = {};
                        allPurchaseRetunDocs[j].doc.info.hsnTaxes = {};
                        getTaxesByPercentageDetailed(allPurchaseRetunDocs[j].doc.items, allPurchaseRetunDocs[j].doc.info.taxDetailed, allPurchaseRetunDocs[j].doc.info.taxNames, allPurchaseRetunDocs[j].doc.info.hsnTaxes);

                        allPurchaseRetunDocs[j].doc = await commonLib.encodeTransDoc(allPurchaseRetunDocs[j].doc, 'purchaseReturn');
                        retdDocsToPush.push(allPurchaseRetunDocs[j].doc);
                    }
                    await couchDBUtils.bulkInsert(maindb, retdDocsToPush);
                    console.log('recalculation tax purchase_v2 done');
                }
            } catch (err) {
                console.log("migration failed" + err);
                logger.info("migration failed" + err);
            }

            function computePurItem(itemInfo, globalDiscountInfo, calculations) {
                globalDiscountInfo = globalDiscountInfo ? globalDiscountInfo : {};
                var info = {};
                info.quantity = parseFloat(itemInfo.quantity_purchased);
                info.itemId = itemInfo.item_id;

                info.purchasePrice = parseFloat(itemInfo.unitsInfo[itemInfo.unitId].purchasePrice);
                var itemTaxes = itemInfo.itemTaxList;
                if (!itemTaxes) {
                    itemTaxes = [];
                }

                var taxPercent = getTotalPercent(itemTaxes);
                var priceTaxEx = getPriceTaxEx(info.purchasePrice, itemInfo.bPPTaxInclusive, taxPercent);
                info.discount = itemInfo.discount ? itemInfo.discount : 0;
                itemInfo.discount_percent = info.discount;
                info.discountPercent = itemInfo.discount_percent ? parseFloat(itemInfo.discount_percent) : 0;
                // info.discountPercent += globalDiscountInfo && globalDiscountInfo.percent ? globalDiscountInfo.percent : 0;

                info.priceWithoutDiscount = multiply(info.quantity, priceTaxEx);
                info.discountAmt = computepxax0dot01(info.priceWithoutDiscount, info.discountPercent);
                info.subTotal = subtract(info.priceWithoutDiscount, info.discountAmt);
                info.subTotalWithoutGD = info.subTotal;
                info.taxes = computeTaxAmounts(itemTaxes, info.subTotal);
                itemInfo.taxes = info.taxes;
                info.tax = computepxax0dot01(taxPercent, info.subTotal);
                info.total = add(info.subTotal, info.tax);

                if (globalDiscountInfo) {
                    if (globalDiscountInfo.method == 'onTaxable') {
                        info.subTotal = info.priceWithoutDiscount * (1 - (globalDiscountInfo.percent + info.discountPercent) * 0.01);
                        info.taxes = computeTaxAmounts(itemTaxes, info.subTotal);

                        info.tax = computepxax0dot01(taxPercent, info.subTotal);
                        info.total = add(info.subTotal, info.tax);
                        // computeTaxAmountsByPercentFilter(info, itemTaxes, info.subTotal, calculations);
                    } else if (globalDiscountInfo.method == 'onTotal') {
                        info.total = info.total * (1 - (globalDiscountInfo.percent) * 0.01);
                        info.subTotal = info.total / ((1 + taxPercent * 0.01))
                        info.taxes = computeTaxAmounts(itemTaxes, info.subTotal);

                        info.tax = computepxax0dot01(taxPercent, info.subTotal);
                        // computeTaxAmountsByPercentFilter(info, itemTaxes, info.subTotal, calculations);
                    }
                }
                info.taxes.total = info.tax;
                itemInfo.subTotal = info.subTotal;
                itemInfo.quantity = info.quantity;
                itemInfo.total = info.total;
                info.totalTaxPercent = taxPercent;
                itemInfo.taxes = info.taxes;
                return info;
            };

            function getTotalPercent(taxArray, itemId) {
                try {
                    var totalTaxPercent = 0;
                    if (!taxArray)
                        return totalTaxPercent;
                    for (var j = 0; j < taxArray.length; j++) {
                        var itemTax = taxArray[j];
                        if (!itemTax.item_id || itemTax.item_id === itemId) {
                            totalTaxPercent += parseFloat(itemTax.percent);
                        }
                    }

                    return totalTaxPercent;
                } catch (ex) {
                    console.log("ex");
                    console.log(ex);
                    return totalTaxPercent;
                }
            };

            function getPriceTaxEx(price, bTaxInclusive, totalTaxPercent) {
                var priceExcludingTax = price;
                if (bTaxInclusive) {
                    priceExcludingTax = calculatePriceExcludingTax(price, totalTaxPercent);
                };

                return priceExcludingTax;
            };

            function calculatePriceExcludingTax(price, taxPercent) {
                var factor = 1 + (taxPercent * 0.01);
                var priceExTax = price / factor;

                return priceExTax;
            }

            function computepxax0dot01(p, a) {
                return (p * a * 0.01);
            };

            function add(a, b) {
                return (a + b);
            };

            function multiply(a, b) {
                return (a * b);
            }

            function subtract(a, b) {
                return (a - b);
            };

            function computeTaxAmounts(taxArray, totalWithoutCharges) {

                var taxAmounts = {
                    CGST: 0,
                    SGST: 0,
                    IGST: 0,
                    CESS: 0,
                    Total: 0
                };
                for (var j = 0; j < taxArray.length; j++) {
                    var itemTax = taxArray[j];
                    if (!itemTax.item_id || itemTax.item_id === itemId) {
                        taxAmounts[itemTax.name] = computepxax0dot01(itemTax.percent, totalWithoutCharges);
                    }
                    taxAmounts.Total += taxAmounts[itemTax.name];
                }
                return taxAmounts;

            }
        },
        down: async function() {

        }
};