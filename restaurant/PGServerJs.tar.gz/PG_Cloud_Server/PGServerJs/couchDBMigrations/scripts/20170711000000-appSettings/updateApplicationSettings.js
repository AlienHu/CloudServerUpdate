let updateApplicationSettings = function(params) {

    let logger = params.logger;
    let migrationsBasePath = params.migrationsBasePath;
    let migrationName = params.migrationName;

    const appRootPath = migrationsBasePath + '/../';
    const prepareDocWithAppSpecifics = require(appRootPath + 'couchDb/firstTimeCouchInitHandler').prepareDocWithAppSpecifics;
    const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
    const employeeProfiler = require(appRootPath + 'employees/employeeProfiles.js');
    const couchDBUtils2 = require('../../../couchDb/couchDBUtils2');

    let nanoClients = params.nanoClients;
    let nanoCore = nanoClients.coredb;

    let foo = {};

    foo.up = async function() {
        try {
            await couchDBUtils2.createCouchDbAndViews(nanoCore, 'coredb');
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            applicationSettings.backUpLocation.frequency = 7;
            await couchDBUtils.update(applicationSettings, nanoCore, 2);
        } catch (error) {
            logger.error(error);
            logger.error('application settings update failed');
            throw error;
        }
    };

    foo.down = async function() {
        try {
            await couchDBUtils2.createCouchDbAndViews(nanoCore, 'coredb');
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            if (applicationSettings.backUpLocation.hasOwnProperty('frequency')) {
                delete applicationSettings.backUpLocation.frequency;
            } else {
                logger.error('Not expected to come here');
                logger.error('frequency property not found');
            }

            await couchDBUtils.update(applicationSettings, nanoCore, 2);
        } catch (error) {
            logger.error(error);
            logger.error('application settings update failed');
            throw error;
        }
    };

    return foo;

};

module.exports = function(params) {
    return updateApplicationSettings(params);
};