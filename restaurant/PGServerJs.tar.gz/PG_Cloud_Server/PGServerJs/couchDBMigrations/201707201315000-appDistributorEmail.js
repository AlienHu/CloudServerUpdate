/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;

        try {
            let nanoClients = params.nanoClients;
            let nanoCore = nanoClients.coredb;
            const appRootPath = params.migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            applicationSettings.ownersInfo.isDistributor = false;
            applicationSettings.ownersInfo.distributorEmail = '';
            await couchDBUtils.update(applicationSettings, nanoCore, 2);
        } catch (error) {
            logger.error(error);
            logger.error('application settings update failed');
            throw error;
        }
    },

    down: async function(params) {
        let logger = params.logger;
        try {
            let nanoClients = params.nanoClients;
            let nanoCore = nanoClients.coredb;
            const appRootPath = params.migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            if (applicationSettings.ownersInfo.hasOwnProperty('distributorEmail') || applicationSettings.ownersInfo.hasOwnProperty('isDistributor')) {
                delete applicationSettings.ownersInfo.isDistributor;
                delete applicationSettings.ownersInfo.distributorEmail;
                await couchDBUtils.update(applicationSettings, nanoCore, 2);
            } else {
                logger.error('not expected to come here. invoiceTitle is missing');
            }

        } catch (error) {
            logger.error(error);
            logger.error('application settings update failed');
            throw error;
        }
    }
};