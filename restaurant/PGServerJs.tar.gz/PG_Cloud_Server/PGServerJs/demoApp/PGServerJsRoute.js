require('errors');
//Shuould not be included in production release
var bodyParser = require('body-parser');
var PGServerJsRoute = require('express').Router();
var shellJs = require('shelljs');
shellJs.config.silent = true;
var logger = require('../common/Logger');
var bonjourService = require('../common/bonjourServer.js');
PGServerJsRoute.use(bodyParser.urlencoded({
    extended: true
}));
PGServerJsRoute.use(bodyParser.json());

PGServerJsRoute.post('/restart', function(req, res) {
    try {
        var result = {
            done: false
        };

        bonjourService.getBonjourServiceInstance().stop(function() {
            var retsartCmd = __dirname + '/../startComboServers.js';
            var execResult = shellJs.exec(retsartCmd);

            if (execResult.code !== 0) {
                result.errorMsg = execResult.stdout;
            } else {
                result.done = true;
            }
            logger.info('Server Restarted');
            res.send(result);
            res.end();
        });

    } catch (exception) {
        logger.error(exception);
        res.send(new Error(exception));
        res.end();
    }
});

module.exports = PGServerJsRoute;