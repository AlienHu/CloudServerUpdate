require('errors');
//Shuould not be included in production release
var bodyParser = require('body-parser');
var timeMachineRoute = require('express').Router();
var logger = require('../common/Logger');
timeMachineRoute.use(bodyParser.urlencoded({
    extended: true
}));
timeMachineRoute.use(bodyParser.json());

// initialDataCreationParamas = {
//     clientType: timeMachineParams.clientType,
//     appType: timeMachineParams.appType,
//     customers: timeMachineParams.iCustomers,
//     suppliers: timeMachineParams.iSuppliers,
//     employees: timeMachineParams.iEmployees,
//     items: timeMachineParams.iItems,
//     debug: timeMachineParams.debug
// };

// diaylyDataCreationParamas = {
//     clientType: timeMachineParams.clientType,
//     appType: timeMachineParams.appType,
//     customers: timeMachineParams.customersAday,
//     suppliers: timeMachineParams.suppliersAday,
//     employees: timeMachineParams.employeesAday,
//     items: timeMachineParams.itemsAday,
//     debug: timeMachineParams.debug
// };
// dailyTxnCreationParams = {
//     clientType: timeMachineParams.clientType,
//     appType: timeMachineParams.appType,
//     sales: timeMachineParams.salesTxnADay,
//     receivings: timeMachineParams.receiveTxnADay,
//     salesDuration: timeMachineParams.salesDuration,
//     receiveDuration: timeMachineParams.receiveDuration,
//     debug: timeMachineParams.debug
// };

var profitGuruFaker = require('../test/common/profitGuruFaker.js');

var profitGuruTxnsMaker = require('../timeMachine/profitGuruTxnsMaker.js');
profitGuruTxnsMaker = new profitGuruTxnsMaker();

var profitGuruTimeMachine = require('../timeMachine/profitGuruTimeMachine.js');
var profitGuruDataCreator = require('../timeMachine/profitGuruDataCreator.js');
profitGuruDataCreator = new profitGuruDataCreator();

var authenticatedUserRequest;
var commonTestUtils = require('../test/common/commonUtils.js');

//  = {
//     clientType: timeMachineParams.clientType,
//     appType: timeMachineParams.appType,
//     customers: timeMachineParams.iCustomers,
//     suppliers: timeMachineParams.iSuppliers,
//     employees: timeMachineParams.iEmployees,
//     items: timeMachineParams.iItems,
//     debug: timeMachineParams.debug
// };

timeMachineRoute.post('/runDataCreator', function(req, res, next) {

    var dataCreationParamas = req.body;
    dataCreationParamas.clientType = 'DeskTopApp';
    dataCreationParamas.appType = process.APP_TYPE;
    var dcResult = {
        done: false
    };
    var isSetTimeMachine = false;
    var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();

    function dataCreateSuccsHandler() {
        dcResult.done = true;
        req.app.get('rootApp').removeListener('profitGuruDataCreatorDone', dataCreateSuccsHandler);
        logger.info('profitGuruDataCreatorDone');
        res.send(dcResult);
        res.end();
    };

    try {
        commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(req.app.get('rootApp'), newEmployee4CreateNLogin).then(function(result) {
            authenticatedUserRequest = result.authenticatedRequest;
            profitGuruDataCreator.start(dataCreationParamas, req.app.get('rootApp'), profitGuruFaker, authenticatedUserRequest, isSetTimeMachine);
            req.app.get('rootApp').on('profitGuruDataCreatorDone', dataCreateSuccsHandler);

        });
    } catch (exception) {
        logger.error(exception);
        res.send(new Error(exception));
        res.end();
    }

});

timeMachineRoute.post('/runTaxnsMaker', function(req, res) {

    var txnsMakerParamas = req.body;
    txnsMakerParamas.clientType = 'DeskTopApp';
    txnsMakerParamas.appType = process.APP_TYPE;
    var txResult = {
        done: false
    };
    var isSetTimeMachine = false;

    function runTaxnsMakerSuccsHandler() {
        txResult.done = true;
        req.app.get('rootApp').removeListener('profitGuruTxnsMakerDone', runTaxnsMakerSuccsHandler);
        res.send(txResult);
        res.end();
    }
    try {
        var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
        commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(req.app.get('rootApp'), newEmployee4CreateNLogin).then(function(result) {
            authenticatedUserRequest = result.authenticatedRequest;

            profitGuruTxnsMaker.start(txnsMakerParamas, req.app.get('rootApp'), profitGuruFaker, authenticatedUserRequest, isSetTimeMachine);
            req.app.get('rootApp').on('profitGuruTxnsMakerDone', runTaxnsMakerSuccsHandler);

        });
    } catch (exception) {
        logger.error(exception);
        res.send(new Error(exception));
        res.end();
    }

});

timeMachineRoute.post('/runTimeMachine', function(req, res) {

    var timeMachineParamas = req.body;
    timeMachineParamas.clientType = 'DeskTopApp';
    timeMachineParamas.appType = process.APP_TYPE;
    var timeMachineResult = {
        done: false
    };
    var isSetTimeMachine = true;

    function profitGuruTimeMachineDoneSuccsHandler() {
        timeMachineResult.done = true;
        req.app.get('rootApp').removeListener('profitGuruTimeMachineDone', profitGuruTimeMachineDoneSuccsHandler);
        res.send(timeMachineResult);
        res.end();
    }

    try {
        var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
        commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(req.app.get('rootApp'), newEmployee4CreateNLogin).then(function(result) {
            authenticatedUserRequest = result.authenticatedRequest;

            profitGuruTimeMachine.startTimeMachine(timeMachineParamas, req.app.get('rootApp'), authenticatedUserRequest, isSetTimeMachine);
            req.app.get('rootApp').on('profitGuruTimeMachineDone', profitGuruTimeMachineDoneSuccsHandler);
        });
    } catch (exception) {
        logger.error(exception);
        res.send(new Error(exception));
        res.end();
    }

});

module.exports = timeMachineRoute;