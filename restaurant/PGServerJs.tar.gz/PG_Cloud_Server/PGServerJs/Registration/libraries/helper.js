"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const library = require("./library");
const init_1 = require("../../init/init");
const logger = require("../../common/Logger");
const couchdb_1 = require("../../TSControllers/interfaces/couchdb");
//copyregidatob in poc folder
exports.getRegistrationIdAndSave = (oldRegDoc) => __awaiter(this, void 0, void 0, function* () {
    let registrationName = oldRegDoc.name;
    let bNewRegistration = false;
    let registrationDoc;
    try {
        registrationDoc = yield library.getRegistrationId(registrationName);
    }
    catch (error) {
        logger.error(error);
        logger.error('getRegistrationIdAndSave. Proceeding Further.');
        if (["UNKNOWN", "EADDRINUSE"].indexOf(error.code) !== -1) {
            logger.error(error);
            throw error.error;
        }
        else if (couchdb_1.COUCH_FAILED_NO_INTERNET_CODES.indexOf(error.code) !== -1) {
            //no internet
            if (!oldRegDoc._id) {
                throw 'Internet is must for setup. Try Again Later.';
            }
            else {
                registrationDoc = {
                    _id: oldRegDoc._id,
                    name: oldRegDoc.name,
                    ip: ''
                };
                yield init_1.init(registrationDoc._id);
            }
        }
        else {
            bNewRegistration = true;
            if (oldRegDoc._id) {
                logger.info('getRegistrationIdAndSave::Not expected to come here. But proceeding by doing some hack');
                logger.info('Registration Name<' + oldRegDoc.name + '> Registration Id<' + oldRegDoc._id + '> Some problem.');
                throw 'getRegistrationIdAndSave::Not expected to come here.';
                // registrationName = moment().format('x');
                // registrationInfoArr[1] = '';
            }
        }
    }
    if (bNewRegistration) {
        registrationDoc = yield library.register({
            name: registrationName,
            ip: ''
        }).catch((error) => {
            throw 'Registration Failed';
        });
    }
    return registrationDoc;
});
//# sourceMappingURL=helper.js.map