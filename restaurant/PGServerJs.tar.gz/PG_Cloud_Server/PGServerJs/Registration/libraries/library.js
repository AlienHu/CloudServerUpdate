"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const nanoBlue = require("nano-blue");
const couchdb_1 = require("../../TSControllers/interfaces/couchdb");
const cloudIp = '51.15.206.208'; //This is the cloud master copy
const ip = '51.15.206.208'; //This is for registration
// const cloudIp = '127.0.0.1'; //use this for quick testing .. may be for dev and prod use different
// const ip: string = '127.0.0.1';
const port = 5984;
const username = 'registrar';
const password = 'ganesh';
const serverUrl = formatServerUrl(ip, port, username, password);
const REGISTRATION_DB_NAME = 'ah_registration';
const DESIGN_DOC_NAME = 'unique';
const VIEW_NAME = 'username';
const UNKONWN_REG_NAME_ERROR = 'Unknown Name. Try Registration First';
//http://couchadmin:test@51.15.206.208:5984/ah_registration/_design/unique/_view/username
const serverInstance = nanoBlue(serverUrl);
const dbInstance = serverInstance.use(REGISTRATION_DB_NAME);
exports.getRegistrationId = function (name) {
    return __awaiter(this, void 0, void 0, function* () {
        let params = {
            key: name.toLowerCase(),
            include_docs: true
        };
        let queryResp = yield dbInstance.view(DESIGN_DOC_NAME, VIEW_NAME, params);
        if (!queryResp[0].rows.length) {
            throw {
                error: UNKONWN_REG_NAME_ERROR
            };
        }
        else if (queryResp[0].rows.length > 1) {
            //not expected to come here
            throw {
                error: 'Unknown Error. Contact AlienHu Admin.',
                code: "UNKNOWN" //This is used in other places. If you change it make sure you change it in other places also
            };
        }
        let response = queryResp[0].rows[0].doc;
        return response;
    });
};
//registrationInfo.ts -> RegistrationInfo
exports.register = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        //lock here
        let resp = yield exports.checkUniqueName(data.name);
        if (!resp.bUnique) {
            throw resp;
        }
        data._id = (parseInt(yield getUpdateSeq()) + 1000).toString();
        data.ip = cloudIp;
        try {
            yield dbInstance.insert(data);
            return data;
        }
        catch (error) {
            throw {
                error: 'Registration Failed. Try Again Later.'
            };
        }
    });
};
exports.checkUniqueName = function (name) {
    return __awaiter(this, void 0, void 0, function* () {
        let response = {
            bUnique: false
        };
        try {
            yield exports.getRegistrationId(name);
        }
        catch (error) {
            const err = error;
            if (couchdb_1.COUCH_FAILED_NO_INTERNET_CODES_EX.indexOf(err.code) !== -1) {
                //Not expected To come here.. 
            }
            else if (err.error === UNKONWN_REG_NAME_ERROR) {
                response.bUnique = true;
            }
        }
        return response;
    });
};
function getUpdateSeq() {
    return __awaiter(this, void 0, void 0, function* () {
        let resp = yield serverInstance.db.get(REGISTRATION_DB_NAME);
        resp[0].update_seq = resp[0].update_seq.toString();
        return resp[0].update_seq.split('-')[0];
    });
}
function formatServerUrl(_ip, _port, _username, _password) {
    return 'http://' + _username + ':' + _password + '@' + _ip + ':' + _port;
}
//# sourceMappingURL=library.js.map