"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const logger = require("../common/Logger");
const library = require("./libraries/library");
const init_1 = require("../init/init");
const couchdb_1 = require("../TSControllers/interfaces/couchdb");
//#mctodo .. these apis should be either in apigateway or alienhu node server
const getRegistrationId = function (registrationDoc) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const doc = yield library.getRegistrationId(registrationDoc.name);
            if (registrationDoc._id && registrationDoc._id !== doc._id) {
                logger.error('Registration ID Mismatch. Please Contact Support Team.<' + registrationDoc._id + '> <' + doc._id + '>');
                throw 'Registration ID Mismatch. Please Contact Support Team.';
            }
            logger.info('getRegistrationId::RegistrationId<' + doc._id + '>');
            yield init_1.init(doc._id);
            return doc;
        }
        catch (error) {
            throw error;
        }
    });
};
const register = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const doc = yield library.register(data);
            yield init_1.init(doc._id);
            return doc;
        }
        catch (error) {
            throw error;
        }
    });
};
exports.checkUniqueName = function (name) {
    return library.checkUniqueName(name);
};
exports.getRegistrationDoc = (registrationDoc) => __awaiter(this, void 0, void 0, function* () {
    const registrationName = registrationDoc.name;
    let bNewRegistration = false;
    try {
        registrationDoc = yield getRegistrationId(registrationDoc);
    }
    catch (error) {
        logger.error(error);
        logger.error('getRegistrationDoc. Proceeding Further.');
        if (["UNKNOWN", "EADDRINUSE"].indexOf(error.code) !== -1) {
            logger.error(error);
            throw error.error;
        }
        else if (couchdb_1.COUCH_FAILED_NO_INTERNET_CODES.indexOf(error.code) !== -1) {
            //no internet
            if (!registrationDoc._id) {
                throw 'Internet is must for setup. Try Again Later.';
            }
            else {
                yield init_1.init(registrationDoc._id);
            }
        }
        else {
            bNewRegistration = true;
            if (registrationDoc._id) {
                logger.info('Registration Name<' + registrationDoc.name + '> Registration Id<' + registrationDoc._id + '> Some problem.');
                throw 'getRegistrationDoc::Not expected to come here.';
            }
        }
    }
    if (bNewRegistration) {
        throw 'Contact Support Team For New Registration <' + registrationName + '>';
    }
    return registrationDoc;
});
//# sourceMappingURL=controller.js.map