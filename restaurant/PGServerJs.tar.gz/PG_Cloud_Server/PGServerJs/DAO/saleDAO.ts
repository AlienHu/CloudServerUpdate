import * as couchDBUtils from '../controllers/common/CouchDBUtils';
import { DBSale } from '../TSControllers/interfaces/dbSaleDoc';
import SaleDoc = DBSale.SaleDoc;
import { DocId } from '../TSControllers/interfaces/common';
const TYPE = 'sale';
const PREFIX = TYPE + '_';
import { transformSaleDoc, encodeTransDoc } from '../controllers/libraries/commonLib';

export const createOrUpdate = async (doc: SaleDoc, dbInstance: any, reTryCount: number, errMsg: string): Promise<string> => {
    await encodeTransDoc(doc, 'sale');
    return couchDBUtils.createOrUpdate(doc, dbInstance, reTryCount, errMsg);
};

export const getDoc = async (docId: DocId, dbInstance: any): Promise<SaleDoc> => {
    let doc = await couchDBUtils.getDocEx(PREFIX + docId, dbInstance);
    let saleDoc: SaleDoc = transformSaleDoc(doc, TYPE);
    return saleDoc;
};