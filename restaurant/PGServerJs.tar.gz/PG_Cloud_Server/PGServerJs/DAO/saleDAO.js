"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const couchDBUtils = require("../controllers/common/CouchDBUtils");
const TYPE = 'sale';
const PREFIX = TYPE + '_';
const commonLib_1 = require("../controllers/libraries/commonLib");
exports.createOrUpdate = (doc, dbInstance, reTryCount, errMsg) => __awaiter(this, void 0, void 0, function* () {
    yield commonLib_1.encodeTransDoc(doc, 'sale');
    return couchDBUtils.createOrUpdate(doc, dbInstance, reTryCount, errMsg);
});
exports.getDoc = (docId, dbInstance) => __awaiter(this, void 0, void 0, function* () {
    let doc = yield couchDBUtils.getDocEx(PREFIX + docId, dbInstance);
    let saleDoc = commonLib_1.transformSaleDoc(doc, TYPE);
    return saleDoc;
});
//# sourceMappingURL=saleDAO.js.map