console.log('Started:Pre Switch Over Hook');
//NOTE: CWD while running this hook is To Be Live Installer  and Not the CurrentLive
console.log('Started:Pre Switch Over Hook');