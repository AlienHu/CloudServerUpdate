'use strict';

/**
 * SAI
 * Reason for moving out of configProfitGuruNodeServer:
 * 1. Utils should not depend on anything. configProfitGuruNodeServer seemed requiring many things (I may be wrong)
 */

let configState = function() {
    const logger = require('./Logger');
    const jsonfile = require('jsonfile');
    const fs = require('fs');

    let appType = process.env.APP_TYPE;
    let environment = process.env.ENVIRONMENT;

    let allConfigJson;
    try {
        allConfigJson = jsonfile.readFileSync(__dirname + '/../config/config.json');
    } catch (error) {
        throw error;
    }

    allConfigJson[environment][appType].version = allConfigJson.version;
    let applicationSettings;
    let _self = this;
    this.getAppConfig = function() {

        let config = allConfigJson[environment][appType];
        fillCouchParams(config, allConfigJson);
        return config;
    };

    this.setAuth = (auth) => {
        let config = allConfigJson[environment][appType];
        config.localCouch.UserName = auth.username;
        config.localCouch.Password = auth.password;
    };

    function fillCouchParams(config, allConfigJson) {
        config.umzugStoragePath = allConfigJson[environment].umzugStoragePath;
        config.relativeCouchMigrationsPath = allConfigJson[environment].relativeCouchMigrationsPath;
        if (allConfigJson[environment][appType].umzugStoragePath) {
            config.umzugStoragePath = allConfigJson[environment][appType].umzugStoragePath;
        }
    }

    this.isValidAppName = function(appNameParam) {
        var result = appNameParam === appType;
        return result;
    };

    this.getPlatform = function() {
        return /^win/.test(process.platform) ? "windows" : "linux";
    };

    this.isWindowsPlatform = function() {
        return /^win/.test(process.platform);
    };

    this.getUmzugStoragePath = function(umzugDir, appName) {
        return umzugDir + '/' + appName + '-meta.json';
    };

    this.getReportsdir = () => {
        const platform = _self.getPlatform();
        let path = allConfigJson.reportsDownloadPath[platform];
        if (!_self.isWindowsPlatform()) {
            path = process.env['HOME'] + path;
        }

        return path;
    };

    this.getUmzugStorageFullPath = function() {
        const appName = process.env.APP_TYPE;
        const platform = _self.getPlatform();
        const config = _self.getAppConfig();
        const umzugStoragePath = config.umzugStoragePath[platform];

        const umzugJsonPath = _self.getUmzugStoragePath(umzugStoragePath, appName);

        return umzugJsonPath;
    };

    this.deleteFile = function(fileName, bFatal) {
        try {
            if (fs.existsSync(fileName)) {
                fs.unlinkSync(fileName);
            }
        } catch (error) {
            logger.error(error);
            if (bFatal) {
                throw error;
            }
        }
    };

    this.getApplicationSettings = function() {
        return applicationSettings;
    };

    this.getBackUpLocation = function() {
        let platform = _self.getPlatform();
        let backUpLocation = applicationSettings.backUpLocation[platform]
        // if ("windows" !== platform) {
        //     backUpLocation = process.env['HOME'] + backUpLocation;
        // }
        return backUpLocation;
    }

    this.setApplicationSettings = function(_applicationSettings) {
        applicationSettings = _applicationSettings;
    };

};

module.exports = new configState;