let macUtils = function () {
    let shelljs = require('shelljs');
    let _self = this;
    const logger = require('./Logger');
    const uuid = require('uuid');

    function isCharInExpectedRange(charCode) {
        //http://www.asciitable.com/
        if (charCode >= 48 && charCode <= 57) {
            //0-9
            return true;
        }
        if (charCode >= 65 && charCode <= 70) {
            //A-F
            return true;
        }

        return false;
    }

    this.isValidMacAddress = function (targetStr) {
        let bytesArray = targetStr.split('-');
        if (bytesArray.length === 1) {
            bytesArray = targetStr.split(':');
            if (bytesArray.length === 1) {
                return false;
            }
        }
        if (bytesArray.length !== 6 && bytesArray.length !== 8) {
            return false;
        }

        let bValid = true;
        for (let j = 0; j < bytesArray.length; j++) {
            let byteWord = bytesArray[j];

            if (!byteWord) {
                bValid = false;
                break;
            }
            if (byteWord.length !== 2) {
                bValid = false;
                break;
            }

            byteWord = byteWord.toUpperCase();
            if (!isCharInExpectedRange(byteWord.charCodeAt(0))) {
                bValid = false;
                break;
            }
            if (!isCharInExpectedRange(byteWord.charCodeAt(1))) {
                bValid = false;
                break;
            }
            //https://stackoverflow.com/questions/94037/convert-character-to-ascii-code-in-javascript
            //http://www.asciitable.com/
        }
        return bValid;
    }

    this.getMacAddressInfoArray = function () {

        if (process.platform === "win32") {

            let ipConfigOutput = shelljs.exec('ipconfig /all');
            let out = ipConfigOutput.stdout.trim().split('\r\n');
            let macAddresses = [];
            let lastAdapterName = 'unknown';
            for (let i = 0; i < out.length; i++) {

                if (-1 < out[i].indexOf('adapter')) {
                    let adapterHead = out[i];
                    adapterName = adapterHead.replace(/^\s+|\s+$/g, '');
                    adapterName = adapterName.substring(adapterName.indexOf(" "));
                    adapterName = adapterName.replace(/\s+/g, ' ').trim();
                    adapterName = adapterName.substring(0, adapterName.indexOf(":"));
                    logger.silly(adapterName + " \n");
                    lastAdapterName = adapterName;
                }

                let lineOut = out[i];
                if (!lineOut) {
                    continue;
                }

                let lineOutArr = lineOut.split(": ");
                if (lineOutArr.length !== 2) {
                    continue;
                }

                let targetStr = lineOutArr[1].trim();
                if (targetStr.indexOf('\n') >= 0 || targetStr.indexOf('\r') >= 0) {
                    throw 'Mac Address Parse Failed. Unexpected';
                }

                if (!targetStr) {
                    continue;
                }

                /**
                 * 6 bytes or 8 bytes
                 * 14-18-77-C8-87-84
                 * 00-00-00-00-00-00-00-E0
                 */
                let bValid = _self.isValidMacAddress(targetStr);

                if (!bValid) {
                    continue;
                }

                macAddresses.push({
                    name: lastAdapterName,
                    address: targetStr
                });
                lastAdapterName = 'unknown-' + i;
            }

            logger.silly("\n\n");
            logger.silly(macAddresses);
            logger.silly("\n\n");

            return macAddresses;
        } else if ((process.platform === 'linux') && process.arch.indexOf('arm') === -1) {
            let output = shelljs.exec("ifconfig | grep HW | awk '{print $1, $5}'");
            let macArray = [];
            var arr = output.split("\n");
            for (var i = 0; i < arr.length; i++) {
                if (arr[i] !== "") {
                    let info = arr[i].split(" ");
                    macArray.push({
                        name: info[0],
                        address: info[1]
                    });
                }
            }
            return macArray;
        } else if ((process.platform === 'darwin') && process.arch.indexOf('arm') === -1) {
            let output = shelljs.exec("ifconfig en1 | awk '/ether/{print $2}'");
            let macArray = [];
            var arr = output.split("\n");
            for (var i = 0; i < arr.length; i++) {
                if (arr[i] !== "") {
                    let info = arr[i].split(" ");
                    macArray.push({
                        name: "mac-123456",
                        address: "123456789"
                    });
                }
            }
            return macArray;
        } else if (process.platform === 'linux' && process.arch.indexOf('arm') !== -1) {
            let output = shelljs.exec("ifconfig | grep ether | awk '{print $2}'");
            let macArray = [];
            var arr = output.split("\n");
            for (var i = 0; i < arr.length; i++) {
                if (arr[i] !== "") {
                    let info = arr[i].split(" ");
                    macArray.push({
                        name: 'unknown' + i,
                        address: arr[i]
                    });
                }
            }
            return macArray;
        } else {
            throw 'Unsupported Platform Architecture';
        }
    };

    this.getMacAddressArray = function () {
        let macInfoArray = _self.getMacAddressInfoArray();
        let macArray = [];
        for (let i = 0; i < macInfoArray.length; i++) {
            macArray.push(macInfoArray[i].address);
        }
        return macArray;

    };

    this.getMacAddress = function (bThrow) {
        let macArray = _self.getMacAddressInfoArray();
        let macAddress = '00-00-00-00-00-00-' + uuid.v4();
        if (macArray.length) {
            macAddress = macArray[0].address;
        } else {
            let errMsg = 'MacAddress Not Found';
            logger.error(errMsg);
            if (bThrow) {
                throw errMsg;
            }
            logger.error('Using ' + macAddress);
        }

        return macAddress;
    };

};

module.exports = new macUtils();

// dummy commit