"use strict";
/*
** https://developers.google.com/drive/api/v3/quickstart/nodejs
*/
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
// import { commonErrorLogger } from "../TSControllers/tally/computations/common";
const fs = require('fs');
const google = require('googleapis').google;
let DRIVE_INSTANCE;
const authorize = (credentials, tokenPath) => {
    const credObj = credentials.installed;
    const oAuth2Client = new google.auth.OAuth2(credObj.client_id, credObj.client_secret, credObj.redirect_uris[0]);
    try {
        const token = JSON.parse(fs.readFileSync(tokenPath));
        oAuth2Client.setCredentials(token);
        const driveInstance = google.drive({
            version: 'v3',
            auth: oAuth2Client
        });
        return driveInstance;
    }
    catch (err) {
        throw err;
    }
};
const listFiles = (driveInstance, folderId) => {
    return new Promise(function (resolve, reject) {
        driveInstance.files.list({
            q: "'" + folderId + "' in parents and trashed=false",
            fields: 'files(id, name)'
        }, function (err, res) {
            if (err) {
                return reject(err);
            }
            const files = res.data.files;
            return resolve(files);
        });
    });
};
const getFileById = (driveInstance, fileId) => {
    return new Promise(function (resolve, reject) {
        driveInstance.files.get({
            fileId: fileId,
            fields: 'webContentLink' // add properties here to get
        }, function (err, res) {
            if (err) {
                return reject(err);
            }
            const file = res.data;
            return resolve(file);
        });
    });
};
const deleteFileById = (driveInstance, fileId) => {
    return new Promise(function (resolve, reject) {
        driveInstance.files.delete({
            fileId: fileId
        }, function (err, res) {
            if (err) {
                return reject(err);
            }
            const file = res.data;
            return resolve(file);
        });
    });
};
const createFolder = (driveInstance, folderName, parentId) => {
    var folderMetadata = {
        'name': folderName,
        'mimeType': 'application/vnd.google-apps.folder'
    };
    if (parentId) {
        folderMetadata.parents = [parentId];
    }
    return new Promise(function (resolve, reject) {
        driveInstance.files.create({
            resource: folderMetadata,
            fields: 'id'
        }, function (err, folder) {
            if (err) {
                return reject(err);
            }
            else {
                return resolve(folder.data.id);
            }
        });
    });
};
exports.createFile = (driveInstance, filePath, folderId, fileName) => {
    const fileMetadata = {
        'name': fileName,
        parents: [folderId]
    };
    const media = {
        // mimeType: 'image/jpeg',
        body: fs.createReadStream(filePath)
    };
    return new Promise(function (resolve, reject) {
        driveInstance.files.create({
            resource: fileMetadata,
            media: media,
            fields: 'id'
        }, function (err, file) {
            if (err) {
                return reject(err);
            }
            else {
                return resolve(file.data.id);
            }
        });
    });
};
const getSharingInfo = (driveInstance, fileId) => {
    return new Promise(function (resolve, reject) {
        driveInstance.permissions.list({
            fileId: fileId
        }, function (err, res) {
            if (err) {
                return reject(err);
            }
            else {
                return resolve(res.data);
            }
        });
    });
};
exports.shareFile = (driveInstance, fileId, type = 'reader', email = "") => {
    let body = {
        'value': 'default',
        'type': 'anyone',
        'role': "reader"
    };
    if (email) {
        body.type = 'user';
        body.emailAddress = email;
        body.role = type ? type : "reader";
    }
    return new Promise(function (resolve, reject) {
        driveInstance.permissions.create({
            fileId: fileId,
            resource: body
        }, function (err, res) {
            if (err) {
                return reject(err);
            }
            else {
                return resolve(fileId);
            }
        });
    });
};
const updateFileById = function (driveInstance, filePath, fileId) {
    const fileMetadata = {
        'name': filePath
    };
    const media = {
        // mimeType: 'image/jpeg',
        body: fs.createReadStream(filePath)
    };
    return new Promise(function (resolve, reject) {
        driveInstance.files.update({
            resource: fileMetadata,
            media: media,
            fields: 'id',
            fileId: fileId
        }, function (err, file) {
            if (err) {
                return reject(err);
            }
            else {
                return resolve(file.data.id);
            }
        });
    });
};
exports.initDriveInstance = (credentialPath, tokenPath, forceRefresh = false) => {
    if (DRIVE_INSTANCE && !forceRefresh) {
        return DRIVE_INSTANCE;
    }
    try {
        const credentialJSON = JSON.parse(fs.readFileSync(credentialPath));
        DRIVE_INSTANCE = authorize(credentialJSON, tokenPath);
        return DRIVE_INSTANCE;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
};
exports.getDriveInstance = () => {
    return DRIVE_INSTANCE;
};
exports.saveCompressedImage = (srcPath, dstPath, param) => __awaiter(this, void 0, void 0, function* () {
    // https://www.npmjs.com/package/jimp
    const Jimp = require('jimp');
    try {
        const fileObj = yield Jimp.read(srcPath);
        fileObj.resize(param.width, param.height).quality(param.quality ? param.quality : 100).writeAsync(dstPath);
    }
    catch (err) {
        throw err;
    }
});
exports.downloadFile = (driveInstance, fileId, downloadPath) => {
    let dest = fs.createWriteStream(downloadPath);
    return new Promise((resolve, reject) => {
        driveInstance.files.get({ fileId: fileId, alt: 'media' }, { responseType: 'stream' }, function (err, res) {
            if (err) {
                return reject(err);
            }
            res.data
                .on('end', () => {
                return resolve(dest.path);
            })
                .on('error', err => {
                console.log('Error', err);
                return reject(err);
            })
                .pipe(dest);
        });
    });
};
// const test1 = async () => {
//     const credentialPath = "C:/ProfitGuru/Resources/RETAIL/Info/credentials.json";
//     const tokenPath = "C:/ProfitGuru/Resources/RETAIL/Info/token.json";
//     let driveInstance;
//     try {
//         driveInstance = initDriveInstance(credentialPath, tokenPath)
//     }
//     catch (err) {
//         throw err;
//     }
//     try {
//         let resp = await getSharingInfo(driveInstance, "1EFAGb72Tz-UMBjP5RzTbL5JS52Kjn2hR");
//         // resp = await shareFile(driveInstance, "1EFAGb72Tz-UMBjP5RzTbL5JS52Kjn2hR", "writer", "mafeela.azeez@gmail.com");
//         console.log(resp);
//     }
//     catch (err) {
//         console.log(6);
//         throw err;
//     }
// }
// test1().then(function () {
// }).catch(function (err) {
//     console.error(err);
// })
//# sourceMappingURL=googleDrive.js.map