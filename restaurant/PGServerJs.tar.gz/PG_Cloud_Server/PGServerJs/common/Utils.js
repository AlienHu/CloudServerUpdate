const BitlyClient = require('bitly');
const bitly = BitlyClient('e8f1597dcc51dbbef65ba80e2d8c0598017502d9');
//e8f1597dcc51dbbef65ba80e2d8c0598017502d9 - sai@alienhu.com password alienhu
// 3e8ba3d9de77528280cc7621376979c37e0a765e

const logger = require('./Logger');
var Utils = function() {
    'use strict';

    let _self = this;

    function isObject(obj) {
        return obj === Object(obj);
    }

    this.compareKeys = function(refObj, insObj, excludeKeys, errorsArray) {
        if (!errorsArray) {
            errorsArray = [];
        }
        if (!excludeKeys) {
            excludeKeys = [];
        }

        for (var key in refObj) {
            if (excludeKeys.indexOf(key) !== -1) {
                continue;
            }

            if (!refObj.hasOwnProperty(key)) {
                continue;
            }

            if (!insObj.hasOwnProperty(key)) {
                let errMsg = key + " not found in insObj";
                errorsArray.push(errMsg);
                continue;
            }

            let ref = refObj[key];
            let ins = insObj[key];
            if (typeof(ref) !== typeof(ins)) {
                let errMsg = 'Type mismatch. key<' + key + '> ref<' + typeof(ref) + '> ins<' + typeof(ins) + '>';
                errorsArray.push(errMsg);
            }

            if (Array.isArray(ref)) {
                continue;
            } else if (isObject(ref)) {
                _self.compareKeys(ref, ins, excludeKeys, errorsArray);
            }
        }

        return errorsArray.length === 0;
    };

    this.syncKeys = function(refObj, insObj, excludeKeys, errorsArray) {
        if (!errorsArray) {
            errorsArray = [];
        }

        _self.findStructDiffAndCopy(refObj, insObj, excludeKeys, errorsArray);
        deleteKeys(refObj, insObj, excludeKeys, errorsArray);
        return errorsArray.length === 0;
    }

    function typeDiff(ref, ins, excludeKeys, errorsArray, bNocopy, tree, key) {
        if (typeof(ref) !== typeof(ins)) {
            let errMsg = 'Type mismatch. key<' + tree + '/' + key + '> ref<' + typeof(ref) + '> ins<' + typeof(ins) + '>';
            errorsArray.push(errMsg);
            if (!bNocopy) {
                ins = ref;
            }
            return false;
        }

        if (Array.isArray(ref)) {
            if (ref.length === 0) {
                //No ref structure available
                return true;
            }

            for (let i = 0; i < ins.length; i++) {
                return _self.findStructDiffAndCopy(ref[0], ins[i], excludeKeys, errorsArray, bNocopy, tree + '/' + key + '/' + i);
            }
        }

        return true;
    }

    function convertDynamicObjArrPropToArr(input) {
        for (let i = 0; i < input.length; i++) {
            input[i] = _self.convertDynamicObjectPropertiesToArray(input[i]);
        }

        return input;
    }

    //Like UnitsInfo
    this.convertDynamicObjectPropertiesToArray = function(input) {
        if (Array.isArray(input)) {
            input = convertDynamicObjArrPropToArr(input);
        } else if (!isObject(input)) {
            return input;
        }

        let keys = Object.keys(input);
        if (!isNaN(keys[0])) {
            //convert to array
            let temp = input;
            input = [];
            for (let i = 0; i < keys.length; i++) {
                input.push(temp[keys[i]]);
            }
            return convertDynamicObjArrPropToArr(input);
        }

        for (var key in input) {
            let value = input[key];
            if (isObject(value)) {
                input[key] = _self.convertDynamicObjectPropertiesToArray(input[key]);
            } else if (Array.isArray()) {
                input[key] = convertDynamicObjArrPropToArr(value);
            }
        }

        return input;
    };

    //This doesn't work for objects with dynamic keys
    //So input that we should convert to array before sending to this
    this.findStructDiffAndCopy = function(refObj, insObj, excludeKeys, errorsArray, bNocopy, tree) {
        if (bNocopy === undefined) {
            bNocopy = false;
        }

        if (!tree) {
            tree = '';
        }

        if (!errorsArray) {
            errorsArray = [];
        }
        if (!excludeKeys) {
            excludeKeys = [];
        }

        if (!isObject(refObj) || Array.isArray(refObj)) {
            return typeDiff(refObj, insObj, excludeKeys, errorsArray, bNocopy, tree, '');
        }

        for (var key in refObj) {
            if (excludeKeys.indexOf(key) !== -1) {
                continue;
            }

            if (!refObj.hasOwnProperty(key)) {
                continue;
            }

            if (!insObj.hasOwnProperty(key)) {

                let errMsg = tree + '/' + key + " not found in insObj";
                errorsArray.push(errMsg);
                if (!bNocopy) {
                    insObj[key] = refObj[key];
                }
                continue;

            }

            let ref = refObj[key];
            let ins = insObj[key];
            if (typeof(ref) !== typeof(ins)) {
                let errMsg = 'Type mismatch. key<' + tree + '/' + key + '> ref<' + typeof(ref) + '> ins<' + typeof(ins) + '>';
                errorsArray.push(errMsg);
                if (!bNocopy) {
                    insObj[key] = refObj[key];
                }
                continue;
            }

            if (Array.isArray(ref)) {
                if (ref.length === 0) {
                    //No ref structure available
                    continue;
                }

                for (let i = 0; i < ins.length; i++) {
                    _self.findStructDiffAndCopy(ref[0], ins[i], excludeKeys, errorsArray, bNocopy, tree + '/' + key + '/' + i);
                }
            } else if (isObject(ref)) {
                _self.findStructDiffAndCopy(ref, ins, excludeKeys, errorsArray, bNocopy, tree + '/' + key);
            }
        }

        return errorsArray.length === 0;
    };

    function deleteKeys(refObj, insObj, excludeKeys, errorsArray) {
        if (!errorsArray) {
            errorsArray = [];
        }
        if (!excludeKeys) {
            excludeKeys = [];
        }

        for (var key in insObj) {
            if (excludeKeys.indexOf(key) !== -1) {
                continue;
            }

            if (!insObj.hasOwnProperty(key)) {
                continue;
            }

            if (!refObj.hasOwnProperty(key)) {
                let errMsg = key + " not found in refObj";
                errorsArray.push(errMsg);
                delete insObj[key];
                continue;
            }

            let ref = refObj[key];
            let ins = insObj[key];
            if (typeof(ref) !== typeof(ins)) {
                let errMsg = 'Type mismatch. key<' + key + '> ref<' + typeof(ref) + '> ins<' + typeof(ins) + '>';
                errorsArray.push(errMsg);
                insObj[key] = refObj[key];
            }

            if (Array.isArray(ref)) {
                continue;
            } else if (isObject(ref)) {
                deleteKeys(ref, ins, excludeKeys, errorsArray);
            }
        }

        return errorsArray.length === 0;
    };

    this.pgTimeOut = function(time) {
        return new Promise(resolve => {
            setTimeout(function() {
                resolve(true);
            }, time)
        });
    };

    this.getShortUrl = function(url) {
        return bitly.shorten(url).then(function(shortUrl) {
            logger.info("short url : " + shortUrl.data.url);
            return shortUrl.data.url
        });
    };

    function isObject(obj) {
        return obj === Object(obj);
    }

    this.compareObject = function(refObj, insObj, tolerance, excludeFields, errorsArray, tree) {
        if (!tree) {
            tree = '';
        }

        if (!errorsArray) {
            errorsArray = [];
        }
        if (!excludeFields) {
            excludeFields = [];
        }
        if (!tolerance) {
            tolerance = 0;
        }

        for (var key in refObj) {
            if (excludeFields.indexOf(key) !== -1) {
                continue;
            }

            if (refObj.hasOwnProperty(key)) {
                if (insObj.hasOwnProperty(key)) {
                    let ref = refObj[key];
                    let ins = insObj[key];
                    if (typeof(ref) !== typeof(ins)) {
                        let errMsg = 'Type mismatch. tree<' + tree + '> key<' + key + '> ref<' + typeof(ref) + '> ins<' + typeof(ins) + '>';
                        errorsArray.push(errMsg);
                        //console.log(errMsg);
                    }

                    if (Array.isArray(ref)) {
                        !_self.compareArray(ref, ins, tolerance, excludeFields, errorsArray, tree + '/' + key)
                    } else if (isObject(ref)) {
                        _self.compareObject(ref, ins, tolerance, excludeFields, errorsArray, tree + '/' + key);
                    } else {
                        if (typeof(ref) === 'number') {
                            if (Math.abs(ref - ins) > tolerance) {
                                let errMsg = 'Values Mismatch. tree<' + tree + '> Key<' + key + '> ref<' + ref + ' ' + '> ins<' + ins + '>';
                                //console.log(errMsg);
                                errorsArray.push(errMsg);
                            }
                        } else if (ref !== ins) {
                            let errMsg = 'Values Mismatch. tree<' + tree + '> Key<' + key + '> ref<' + refObj[key] + ' ' + '> ins<' + insObj[key] + '>';
                            //console.log(errMsg);
                            errorsArray.push(errMsg);
                        }
                    }
                } else if (excludeFields.indexOf(key) === -1) {
                    let errMsg = 'tree<' + tree + '> ' + key + " not found in insObj";
                    //console.log(errMsg);
                    errorsArray.push(errMsg);
                }
            }
        }

        return errorsArray.length === 0;
    };

    this.compareArray = function(refArray, insArray, tolerance, excludeFields, errorsArray, tree) {
        if (!tolerance) {
            tolerance = 0;
        }
        if (!excludeFields) {
            excludeFields = [];
        }
        if (!errorsArray) {
            errorsArray = [];
        }

        if (!insArray) {
            let errMsg = 'tree<' + tree + '>. insArray is undefined';
            //console.log(errMsg);
            errorsArray.push(errMsg);
            return;
        }

        if (insArray.length != refArray.length) {
            let errMsg = 'tree<' + tree + '> array length did not match. ref<' + refArray.length + '>  ins<' + insArray.length + '>';
            //console.log(errMsg);
            errorsArray.push(errMsg);
            return;
        }

        for (var i = 0; i < refArray.length; i++) {
            let resp = _self.compareObject(refArray[i], insArray[i], tolerance, excludeFields, errorsArray, tree + '/' + i);
        }

        return errorsArray.length === 0;
    };

};
module.exports = new Utils();