var argv = require('yargs')
    .usage('Usage: $0 -e <envirnment> -app <AppName> -p <platform> ')
    .alias('e', 'env')
    .describe('e', 'environment(production/production)')
    .choices('e', ['production', 'production'])
    .alias('a', 'app')
    .describe('a', 'Apptype to run (all/retail/restaurant)')
    .default('a', 'all')
    .alias('u', 'selfUpdate')
    .describe('u', 'software update')
    .alias('m', 'myself')
    .describe('m', 'Source Name')
    .default('m', 'PGServerJs')
    .help('h')
    .alias('h', 'help')
    .demandOption(['a'])
    .argv;

var shelljs = require('shelljs');
shelljs.exec('ln -sf /usr/share/zoneinfo/Asia/Calcutta /etc/localtime');
var PM2 = './node_modules/pm2/bin/pm2';
var startPM2;

var log = console.log;
startPM2 = PM2 + ' start npm -- start';

var app = argv.app;

var appArray = ['retail', 'restaurant', 'lodging', 'petrolbunk', 'pharmacy', 'crm', 'connect'];
console.log("app type= " + app);
shelljs.exec(PM2 + ' delete all ');
shelljs.exec(PM2 + ' update');

if (!app) {
    console.log("please add app type --app")
    process.exit(1);
} else if (app !== "all") {
    runServer(app);
} else {
    for (var i = 0; i < appArray.length; i++) {
        runServer(appArray[i]);
    }
}

function runServer(app) {
    var serverCommand = '';
    switch (app) {
        case 'retail':
            serverCommand = 'IS_DEMO_APP=yes ENVIRONMENT=production APP_TYPE=retail PROFITGURU_SERVER_PORT=3000 COUCHDB_USERNAME=couchadmin COUCHDB_PASSWORD=test COUCH_PORT=5984 ' + startPM2 + ' --name pg_' + app;
            break;
        case 'restaurant':
            serverCommand = 'IS_DEMO_APP=yes  ENVIRONMENT=production APP_TYPE=restaurant PROFITGURU_SERVER_PORT=3001 COUCHDB_USERNAME=couchadmin COUCHDB_PASSWORD=test COUCH_PORT=5984 ' + startPM2 + ' --name pg_' + app;
            break;
        case 'lodging':
            serverCommand = 'IS_DEMO_APP=yes  ENVIRONMENT=production APP_TYPE=lodging PROFITGURU_SERVER_PORT=3002 COUCHDB_USERNAME=couchadmin COUCHDB_PASSWORD=test COUCH_PORT=5984 ' + startPM2 + ' --name pg_' + app;
            break;
        case 'petrolbunk':
            serverCommand = 'IS_DEMO_APP=yes  ENVIRONMENT=production APP_TYPE=petrolbunk PROFITGURU_SERVER_PORT=3003 COUCHDB_USERNAME=couchadmin COUCHDB_PASSWORD=test COUCH_PORT=5984 ' + startPM2 + ' --name pg_' + app;
            break;
        case 'pharmacy':
            serverCommand = 'IS_DEMO_APP=yes  ENVIRONMENT=production APP_TYPE=pharmacy PROFITGURU_SERVER_PORT=3004 COUCHDB_USERNAME=couchadmin COUCHDB_PASSWORD=test COUCH_PORT=5984 ' + startPM2 + ' --name pg_' + app;
            break;
        case 'crm':
            serverCommand = 'IS_DEMO_APP=yes  ENVIRONMENT=production APP_TYPE=crm PROFITGURU_SERVER_PORT=3006 COUCHDB_USERNAME=couchadmin COUCHDB_PASSWORD=test COUCH_PORT=5984 ' + startPM2 + ' --name pg_' + app;
            break;
        case 'connect':
            serverCommand = 'IS_DEMO_APP=yes  ENVIRONMENT=production APP_TYPE=connect PROFITGURU_SERVER_PORT=3007 COUCHDB_USERNAME=couchadmin COUCHDB_PASSWORD=test COUCH_PORT=5984 ' + startPM2 + ' --name pg_' + app;
            break;
    }
    if (shelljs.exec(serverCommand).code !== 0) {
        console.log('Error while starting ' + app);
        process.exit(1);
    }
    console.log(app + " Server Successfully started");
    return true;
}