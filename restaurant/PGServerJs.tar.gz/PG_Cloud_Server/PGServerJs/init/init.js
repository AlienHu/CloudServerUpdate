"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const logger = require("../common/Logger");
const dbConfig_1 = require("../TSControllers/interfaces/dbConfig");
const updateAuth_1 = require("../TSCouchDB/Utils/updateAuth");
const couchInit_1 = require("../TSCouchDB/couchInit");
const serverDataInit_1 = require("../TSCouchDB/serverDataInit");
const storeSelectDataInit_1 = require("../TSCouchDB/storeSelectDataInit");
const formatDocIds_1 = require("../TSControllers/utils/formatDocIds");
const dbInstanceHelper_1 = require("../TSCouchDB/Common/dbInstanceHelper");
const licenceCouchHandler_1 = require("../couchDb/licenceCouchHandler");
const init_1 = require("../TSCouchDB/CloudCouch/init");
const formatCouchDBUrlAndName_1 = require("../TSControllers/utils/formatCouchDBUrlAndName");
const itemSyncWorker_1 = require("../TSControllers/workers/itemSyncWorker");
const initStatusHack = require("../common/initStatusHack");
const stockItems_1 = require("../TSControllers/stockItems");
const validateInstaller_1 = require("../TSCouchDB/validateInstaller");
const utils = require("../common/Utils");
const migrationHandler_1 = require("../couchDb/migrationHandler");
const tsCouchDBUtils_1 = require("../TSCouchDB/Utils/tsCouchDBUtils");
const syncMainDBFromOtherStore_1 = require("../TSCouchDB/Common/syncMainDBFromOtherStore");
const couchdb_1 = require("../TSControllers/interfaces/couchdb");
const versionCheck_1 = require("../middleWares/versionCheck");
const listenToVersion_1 = require("../TSControllers/libraries/listenToVersion");
const configState_1 = require("../common/configState");
//#TITO dbreset bForce parameter in earlier code
exports.setSkipForUT = (bSkip) => {
    //Skipping if UT wants to disable temporarily
    bSkipForUT = bSkip;
};
exports.setSkipForProductionScript = (bSkip) => {
    //Skipping if UT wants to disable temporarily
    bSkipForPS = bSkip;
};
exports.init = function (strRegistrationId) {
    return __awaiter(this, void 0, void 0, function* () {
        const bInitStatus = initStatusHack.getOnRegistrationIdInitStatus(strRegistrationId);
        yield exports.prepareDBConfig();
        logger.info("initLocalDBOnRegistrationIdInit::start");
        //Delete all replication here
        const dbContext = formatDocIds_1.getDBContext(strRegistrationId);
        let bIsSameVersion;
        let bIsGEVersion;
        let bIsAdminPC;
        if (bInitStatus) {
            try {
                [bIsSameVersion, bIsGEVersion, bIsAdminPC] = yield validateInstaller_1.isSyncNeedToStart(dbContext);
                logger.info("isSyncNeedToStart:: " + bIsGEVersion);
            }
            catch (error) {
                logger.info('isSyncNeedToStart::May be some problem. Lets try again later');
            }
        }
        const bReplicationDBDeleted = yield couchInit_1.deleteReplicationDBIfVersionDoesntMatch(dbConfig_1.dbConfig, dbConfig_1.dbConfig.onRegistrationId[couchdb_1.REPLICATIOR_DB_PREFIX]);
        if (!bReplicationDBDeleted) {
            yield couchInit_1.deleteReplicationDocsByRegistrationIdOnCondition(strRegistrationId, dbConfig_1.dbConfig, bIsSameVersion, bIsGEVersion);
        }
        yield initLocalDBOnRegistrationIdInit(strRegistrationId);
        logger.info("initLocalDBOnRegistrationIdInit::end");
        logger.info("initCloudDBOnRegistrationId::start");
        // if bInitStatus ==false its new pc  throw if version missmatch    
        if (bInitStatus) {
            init_1.onRegistrationId(strRegistrationId).catch((error) => {
                logger.error(error);
                logger.error('initCloudDBOnRegistrationId:: (Not sure. May be.) Looks like not connected to internet.');
            });
        }
        else {
            yield init_1.onRegistrationId(strRegistrationId);
        }
        logger.info("initCloudDBOnRegistrationId::end");
        logger.info("checkReplicationUsers::start");
        yield checkReplicationUsers(strRegistrationId, bInitStatus);
        logger.info("checkReplicationUsers::end");
        if (bIsGEVersion === undefined) {
            //it failed when trying in the beginning so trying again
            //it may have failed because of no dbs or some missing docs
            [bIsSameVersion, bIsGEVersion, bIsAdminPC] = yield validateInstaller_1.isSyncNeedToStart(dbContext);
        }
        logger.info("isSyncNeedToStart:: " + bIsGEVersion);
        if (!bInitStatus && !bIsSameVersion) {
            throw "version missmatch of new install can't proceed further";
        }
        if (!bInitStatus) {
            try {
                yield init_1.replicateCommonDBsFromCloud(dbConfig_1.dbConfig, dbContext);
            }
            catch (error) {
                logger.error('first time replication of users and licencedb from cloud failed.');
                throw 'first time replication of users and licencedb from cloud failed.';
            }
        }
        // check to start replication ..
        if (bIsGEVersion) {
            yield init_1.onRegistrationIdSyncCloudDB(dbConfig_1.dbConfig, strRegistrationId);
            logger.info("onRegistrationIdSyncCloudDB::end");
            logger.info("initDataOnRegistrationId::start");
        }
        else {
            logger.info("onRegistrationIdSyncCloudDB::Paused  <> bSyncStart ::" + bIsGEVersion);
        }
        versionCheck_1.setIsSameVersion(dbContext, bIsSameVersion);
        listenToVersion_1.listenToVersionDoc(dbContext, [bIsSameVersion, bIsGEVersion, bIsAdminPC]);
        if (bIsAdminPC) {
            yield init_1.migrateCloudCommonDBs(dbContext);
        }
        yield initDataOnRegistrationId(strRegistrationId);
        logger.info("initDataOnRegistrationId::end");
        initStatusHack.updateOnRegistrationIdInitStatus(strRegistrationId);
    });
};
exports.onStoreSelectInit = function (doc, requestSession) {
    return __awaiter(this, void 0, void 0, function* () {
        //Check if the device has permission
        if (doc.allowedDeviceId && doc.allowedDeviceId.length) {
            let bDeviceIsAllowed = false;
            //Ask and set the deviceId to this store
            let macAddArry = validateInstaller_1.getMacAddressArray();
            bDeviceIsAllowed = utils.ifFirstArryContainAnyEleOfSecArry(doc.allowedDeviceId, macAddArry);
            if (!bDeviceIsAllowed) {
                logger.error("initLocalDBOnStoreSelect::start");
                logger.info("initLocalDBOnStoreSelect::start");
                throw "This device is not set for this store";
            }
        }
        //If store is free - claim it now - Obviously it has to be online for this and operate on the cloud db
        //The below is if locally the store has been inited
        const bInitStatus = doc.bInitDone;
        logger.info("initLocalDBOnStoreSelect::start");
        yield initLocalDBOnStoreSelect(doc, bInitStatus);
        logger.info("initLocalDBOnStoreSelect::end");
        let [bIsSameVersion, ,] = yield validateInstaller_1.isSyncNeedToStart(doc.dbContext);
        if (!bInitStatus && !bIsSameVersion) {
            throw "version missmatch of new install can't proceed further";
        }
        logger.info("initCloudDBOnStoreSelect::start");
        if (bInitStatus) {
            init_1.onStoreSelect(doc.dbContext).catch((error) => {
                logger.error(error);
                logger.error('initCloudDBOnStoreSelect:: May be because of internet.');
            });
        }
        else {
            yield init_1.onStoreSelect(doc.dbContext);
        }
        logger.info("initCloudDBOnStoreSelect::end");
        if (!bInitStatus) {
            logger.info('init sync from other store:: start');
            yield init_1.initStoreReplicateCloudDBOfOtherStore(dbConfig_1.dbConfig, doc);
            logger.info('init sync from other store:: end');
            logger.info('makeZeroStockForNewItem:: start');
            yield itemSyncWorker_1.makeZeroStockForNewItem(doc.dbContext);
            logger.info('makeZeroStockForNewItem:: end');
        }
        if (bIsSameVersion) {
            logger.info("onStoreSelectSyncCloudDB::start");
            yield init_1.onStoreSelectSyncCloudDB(dbConfig_1.dbConfig, doc.dbContext);
            logger.info("onStoreSelectSyncCloudDB::end");
        }
        else {
            //we are syncing master from licence db. So we should not sync
            logger.info("Replication is paused");
            logger.info("onStoreSelectSyncCloudDB:: bSyncStart= " + bIsSameVersion);
            logger.info("onStoreSelectReplicateCloudDBOfOtherStores::bSyncStart= " + bIsSameVersion);
        }
        logger.info("onStoreSelectInitData::start");
        //migration here
        yield migrationHandler_1.migrate('', dbConfig_1.dbConfig, doc.dbContext);
        versionCheck_1.setIsSameVersion(doc.dbContext, bIsSameVersion);
        //replicate here then go
        //replicating basic documents is enough .. items can go on later
        //after replicating basic documents replicate next documents.. and after that setup continous replication
        //Maintain states properly for the UI
        //#TITO if replication is not success..
        doc.applicationSettings = yield storeSelectDataInit_1.initData(dbConfig_1.dbConfig.onStoreSelect, dbConfig_1.dbConfig, doc.dbContext, doc.appType);
        //Here we are listening for StockItemsRequest
        stockItems_1.listenToStockItemRequest(formatCouchDBUrlAndName_1.getFullUrlForDocCRUD(dbConfig_1.dbConfig, doc.dbContext, dbConfig_1.dbConfig.onRegistrationId.licencedb), doc.dbContext);
        //setup continous replication
        //add replication settings in store
        // have 1  more separate document for store and similarly for company
        logger.info("onStoreSelectInitData::end");
        //add a flag saying init done if flag is not there
        yield serverDataInit_1.updateStoreInitStatus(doc, dbConfig_1.dbConfig.onRegistrationId, dbConfig_1.dbConfig);
        //Calling callTOcheckStoreBOnline to update the last seen of store
        if (!bSkipForUT) {
            // callTOcheckStoreBOnline(doc.dbContext);
        }
    });
};
exports.resetDataByRegistrationId = function (strRegistrationId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield exports.prepareDBConfig();
        //delete locally
        //delete on cloud
        yield couchInit_1.resetData(dbConfig_1.dbConfig, strRegistrationId);
        yield init_1.resetData(strRegistrationId);
        //get all dbs ending with strRegistrationId
        //delete users db and sessions db as well
        configState_1.getAllMetaJsonBySignatureAndDelete(formatDocIds_1.getSignature({ strRegistrationId: strRegistrationId, strStoreCompanyId: '' }));
    });
};
const checkReplicationUsers = (strRegistrationId, bInitStatus) => __awaiter(this, void 0, void 0, function* () {
    logger.info('checkReplicationUsers Started');
    const dbContext = formatDocIds_1.getDBContext(strRegistrationId);
    const docIdArr = yield couchInit_1.getReplicationUserDocIds(dbContext);
    yield serverDataInit_1.checkLocalReplicationUsers(docIdArr, dbConfig_1.dbConfig.onRegistrationId._users, dbConfig_1.dbConfig, dbContext);
    if (bInitStatus) {
        init_1.checkCloudReplicationUsers(docIdArr, dbContext).catch((error) => {
            logger.error(error);
            logger.error('checkCloudReplicationUsers:: (May be. Not sure.) Looks like not connected to internet');
        });
    }
    else {
        yield init_1.checkCloudReplicationUsers(docIdArr, dbContext);
    }
    logger.info('checkReplicationUsers completed');
});
exports.prepareDBConfig = function () {
    return __awaiter(this, void 0, void 0, function* () {
        if (dbConfig_1.dbConfig.username && dbConfig_1.dbConfig.password) {
            //already initialized
            return;
        }
        let auth = yield updateAuth_1.getAuth();
        dbConfig_1.dbConfig.username = auth.username;
        dbConfig_1.dbConfig.password = auth.password;
        process.env.bCouch2 = (yield tsCouchDBUtils_1.isCouch2(dbConfig_1.dbConfig)).toString();
    });
};
exports.syncMainDBFromOtherStore = function (doc) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!doc.initSyncStoreDocId) {
            return;
        }
        const srcStrStoreCompanyId = doc.initSyncStoreDocId.substr(doc.initSyncStoreDocId.indexOf('_') + 1);
        //init should already have completed
        yield exports.prepareDBConfig();
        const localMainDBInstance = dbInstanceHelper_1.getDBInstance(dbConfig_1.dbConfig.onStoreSelect[couchdb_1.MAIN_DB_PREFIX], dbConfig_1.dbConfig, doc.dbContext);
        yield syncMainDBFromOtherStore_1.syncMainDBFromOtherStoreHelper(doc, localMainDBInstance, init_1.getCloudMainDBInstance({
            strRegistrationId: doc.dbContext.strRegistrationId,
            strStoreCompanyId: srcStrStoreCompanyId
        }));
    });
};
function initLocalDBOnStoreSelect(doc, bInitStatus) {
    return __awaiter(this, void 0, void 0, function* () {
        yield couchInit_1.createDBOnItrObj(dbConfig_1.dbConfig.onStoreSelect, dbConfig_1.dbConfig, doc.dbContext);
        yield couchInit_1.createDBSecurityDocOnItrObj(dbConfig_1.dbConfig.onStoreSelect, dbConfig_1.dbConfig, doc.dbContext);
        yield couchInit_1.createDBViewsOnItrObj(dbConfig_1.dbConfig.onStoreSelect, dbConfig_1.dbConfig, doc.dbContext);
        yield checkReplicationUsers(doc.dbContext.strRegistrationId, bInitStatus); //#TITO Blocker check for only this store
    });
}
function initLocalDBOnRegistrationIdInit(strRegistrationId) {
    return __awaiter(this, void 0, void 0, function* () {
        let dbContext = formatDocIds_1.getDBContext(strRegistrationId);
        dbInstanceHelper_1.setDBConfig(dbConfig_1.dbConfig); //#TITO Blocker - multitenancy is broken because of hardcoding
        licenceCouchHandler_1.setDBContext(dbContext); //#TITO Blocker - multitenancy is broken because of hardcoding
        yield couchInit_1.createDBOnItrObj(dbConfig_1.dbConfig.onRegistrationId, dbConfig_1.dbConfig, dbContext);
        yield couchInit_1.createDBSecurityDocOnItrObj(dbConfig_1.dbConfig.onRegistrationId, dbConfig_1.dbConfig, dbContext);
        yield couchInit_1.createDBViewsOnItrObj(dbConfig_1.dbConfig.onRegistrationId, dbConfig_1.dbConfig, dbContext);
    });
}
function initDataOnRegistrationId(strRegistrationId) {
    return __awaiter(this, void 0, void 0, function* () {
        let dbContext = formatDocIds_1.getDBContext(strRegistrationId);
        yield serverDataInit_1.initData(dbConfig_1.dbConfig.onRegistrationId, dbConfig_1.dbConfig, dbContext);
    });
}
let bSkipForUT = false; //Skipping if UT wants to disable temporarily
let bSkipForPS = false;
//# sourceMappingURL=init.js.map