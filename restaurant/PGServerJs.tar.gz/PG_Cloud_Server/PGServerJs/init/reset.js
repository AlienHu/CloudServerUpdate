"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const init_1 = require("./init");
const library = require("../Registration/libraries/library");
const registrationHack = require("../common/registrationHack");
const initStatusHack = require("../common/initStatusHack");
const logger = require("../common/Logger");
function reset() {
    return __awaiter(this, void 0, void 0, function* () {
        const registrationName = registrationHack()[0];
        logger.info('get registrationId starting');
        const doc = yield library.getRegistrationId(registrationName);
        logger.info('get registrationId ending');
        logger.info('Reset Starting');
        yield init_1.resetDataByRegistrationId(doc._id);
        logger.info('Reset Completed');
        logger.info('File Reset Started. InitStatus File');
        initStatusHack.resetInitStatus(doc._id);
        logger.info('File Reset Started. InitStatus File Completed');
        delete doc._id;
        logger.info('File Reset Started. Registration Name Completed');
        registrationHack(doc);
        logger.info('File Reset Started. Registration Name Completed');
    });
}
// resetDataByRegistrationId('11').then(() => { logger.info('success'); process.exit(0); }).catch(error => { logger.info('failed'); process.exit(-1) });
reset().then(() => { logger.info('success'); process.exit(0); }).catch(error => { logger.info('failed'); process.exit(-1); });
//# sourceMappingURL=reset.js.map