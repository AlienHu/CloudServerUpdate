/**
 * This module should not be dependent on any other.
 * 
 */

let couchDbUtils2 = function() {

    let couchViewHelper = require('../couchDBViews/couchViewHelper');
    const logger = require('../common/Logger');
    const httpUtils = require('../common/httpUtils');
    let _self = this;
    const fs = require('fs');
    let bCouchSet = false;
    let bCouch2 = false;
    this.isCouch2 = async function() {
        if (bCouchSet)
            return bCouch2;

        try {
            let queryUrl = 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT + '/_membership';
            let resp = await httpUtils.httpGet(queryUrl);
            if (resp.response.statusCode === 200) {
                logger.info('Couch2.1<' + bCouch2 + '>');
                bCouch2 = true;
            }
        } catch (error) {

        }
        bCouchSet = true;
        return bCouch2;
    };

    //This function creates dbs also, not required. Make sure dbs are created before only    
    this.createCouchDbAndViews = async function(dbInstance, dbSuffix) {
        try {
            let viewFileName = __dirname + '/../couchDBViews/' + dbSuffix + 'Views';
            if (!fs.existsSync(viewFileName + '.js')) {
                logger.info('views doesnt exist');
                return;
            }
            let viewsJson = require(viewFileName);

            logger.info('collection ' + dbSuffix + ' Exists!, will verify and see any updates for views ', viewFileName);
            await couchViewHelper.createViews(dbInstance, viewsJson.designDocs, viewsJson.updatesDesignDocs, viewsJson.ddocs);
        } catch (error) {
            throw error;
        }
    };

    //deprecate profitGuruDBsApps
    //This will create couchdb also
    this.createAndKeepCouchDbClient = async function(completeDbInfo) {
        let dbUrl = completeDbInfo.dbUrl;
        let dbPrefix = completeDbInfo.DBPrefix;
        let nanoBlueClient = require('nano-blue')(dbUrl);
        let couchdbPGClients = {};

        let dbInstances = {};
        for (let i = 0; i < completeDbInfo.profitGuruDBsApps.length; i++) {
            let appName = completeDbInfo.profitGuruDBsApps[i];
            couchdbPGClients[appName] = {};
            for (let dbSuffix in completeDbInfo.DBs) {
                let dbName = _self.getDBName(dbPrefix, appName, dbSuffix, completeDbInfo.DBs[dbSuffix].appSpecific);
                if (!completeDbInfo.DBs[dbSuffix].appSpecific) {
                    if (!dbInstances[dbSuffix]) {
                        await _self.createDb(dbUrl, dbName);
                        dbInstances[dbSuffix] = nanoBlueClient.db.use(dbName);

                    }
                    couchdbPGClients[appName][dbSuffix] = dbInstances[dbSuffix];
                } else {
                    await _self.createDb(dbUrl, dbName);
                    couchdbPGClients[appName][dbSuffix] = nanoBlueClient.db.use(dbName);
                }
            };
        }

        return couchdbPGClients;
    };

    this.getDBName = function(dbPrefix, appName, dbSuffix, appSpecific) {
        let dbName = dbPrefix + '_';
        if (appSpecific) {
            dbName += appName + '_';
        }

        if (dbSuffix === '_users') {
            dbName = dbSuffix;
        } else {
            dbName += dbSuffix;
        }

        return dbName;
    };

    //This function is redundant. configProfitGuruNodeServer, couchDBMain also define the same function
    this.getCouchUrl = function(dbInfo) {
        return 'http://' + dbInfo.UserName + ':' + dbInfo.Password + '@' + dbInfo.Host + ':' + dbInfo.Port;
    };

    this.createDb = async function(dbUrl, dbName, bForce) {
        let nanoWithPromises = require('nano-blue')(dbUrl);

        try {
            if (bForce) {
                await _self.deleteDb(dbUrl, dbName);
            }
            await nanoWithPromises.db.get(dbName);
            logger.info(dbName + 'DB Exists ');
        } catch (reason) {
            logger.info('creating ' + dbName + ' DB');
            return await nanoWithPromises.db.create(dbName);
        }
    };

    this.deleteDb = async function(dbUrl, dbName) {
        let nanoWithPromises = require('nano-blue')(dbUrl);

        try {
            await nanoWithPromises.db.destroy(dbName);
            logger.info('Successfully droped couchdb:', dbName);
        } catch (err) {
            if (err.error === 'not_found') {
                let errMsg = 'deleteDb exception. ' + dbName + ' Missing';
                logger.error(errMsg);
            } else {
                logger.error(err);
            }
            return;
        }
    };

    this.deleteAllUsersByAppType = async function(dbUrl, dbName, appName) {
        let docs;
        let nanoWithPromises = require('nano-blue')(dbUrl).use(dbName);
        try {
            let params = {};
            params.startkey = 'org.';
            params.endkey = 'org.z';
            params.include_docs = true;

            let resp = await nanoWithPromises.fetch({}, params);
            docs = resp[0].rows;
        } catch (error) {
            //Database doesn't exist .. not expected to come here
            logger.error(error);
            throw error;
        }

        try {
            for (let i = 0; i < docs.length; i++) {
                let doc = docs[i].doc;
                if (doc.APP_TYPE === appName) {
                    await nanoWithPromises.destroy(doc._id, doc._rev);
                }
            }
        } catch (err) {
            throw err;
        }
    };

};

module.exports = new couchDbUtils2();