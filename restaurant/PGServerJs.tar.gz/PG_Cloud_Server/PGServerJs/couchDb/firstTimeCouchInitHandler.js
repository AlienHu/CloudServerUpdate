'use strict';

/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */

var appRoot = require('app-root-path');
//var profitGuruStatusEvents = require('../../common/profitGuruStatusEvents.js');
//var requestPromise = require('request-promise');
var q = require('q');

var jsonfile = require('jsonfile');

var glob = require('glob-promise');
var path = require('path');
var _self;
var couchLicenceDbClientsJson;
let nanoCore, nanoMain, nanoHSN, nanoUsers, nanoLicence;
var APP_TYPE = process.env.APP_TYPE;
var employeeProfiler = require('../employees/employeeProfiles.js');
const logger = require('../common/Logger');
const shelljs = require('shelljs');
const utils = require('../common/Utils');
const moment = require('moment');
const smsDAO = require('../sms/smsDAO');
var firtTimeInitCouchHandler = function() {
    _self = this;
    var profitGuruElementsJson;
    var appConfig;
    const couchDBUtils = require('../controllers/common/CouchDBUtils');

    function genAndInsertServerLicence() {
        return new Promise(function(resolve, reject) {
            var licenceHelper = require('../licencer/licenceHelper.js');
            licenceHelper.generateServerLicence().then(function(serverLicenceJson) {
                    serverLicenceJson._id = 'profitGuruServerLicence_';
                    return couchDBUtils.create(serverLicenceJson, couchLicenceDbClientsJson[APP_TYPE], 1);
                }).then(function(result) {
                    resolve(true);
                })
                .catch(function(err) {
                    console.log(err);
                    reject(err);
                });
        });
    }

    function loadServerLicence() {
        return new Promise(function(resolve, reject) {
            var licenceHelper = require('../licencer/licenceHelper.js');
            couchDBUtils.getDoc('profitGuruServerLicence_', couchLicenceDbClientsJson[APP_TYPE], 'missing').then(function(serverLicence) {
                licenceHelper.setServerLicence(serverLicence);
                resolve(serverLicence);
            }).catch(function() {
                genAndInsertServerLicence().then(function() {
                    return couchDBUtils.getDoc('profitGuruServerLicence_', couchLicenceDbClientsJson[APP_TYPE], 'missing').then(function(serverLicence) {
                        licenceHelper.setServerLicence(serverLicence);
                        resolve(serverLicence);
                    });
                }).catch(function(reason) {
                    logger.error(reason);
                });
            });

        });
    }
    async function insertOrIpdateAppVersion() {
        try {
            var packageJSON = require(appRoot + '/package.json');
            var sVersion = {
                "version": packageJSON.version
            }
            let serverVersionDoc = await couchDBUtils.getDoc('s_version_' + sVersion.version, couchLicenceDbClientsJson[APP_TYPE], 's_not_found');
            if (sVersion.version !== serverVersionDoc.version) {
                serverVersionDoc.version = sVersion.version;
                await couchDBUtils.createOrUpdate(serverVersionDoc, couchLicenceDbClientsJson[APP_TYPE]);
            }

        } catch (err) {
            if (err === 's_not_found') {
                sVersion._id = 's_version_' + sVersion.version;
                sVersion.timestamp = moment().format('x');
                await couchDBUtils.createOrUpdate(sVersion, couchLicenceDbClientsJson[APP_TYPE]);
            }
        }
    }
    this.doFirstTimeCouchDBInit = async function(couchDBMain) {
        couchLicenceDbClientsJson = couchDBMain.getProfitGuruCouchLicenceDbClientsJson();
        nanoCore = couchDBMain.getCoreDbCouchClient();
        nanoMain = couchDBMain.getMainDbCouchClient();
        nanoLicence = couchDBMain.getLicenceDBClient();
        nanoHSN = couchDBMain.getCouchClient('hsndb');
        nanoUsers = couchDBMain.getUsersDbCouchClient();

        try {
            var firstTimeSetUpPromises = [];
            _self.appConfig = couchDBMain.getApplicationConfig();

            firstTimeSetUpPromises.push(loadServerLicence());
            firstTimeSetUpPromises.push(insertOrIpdateAppVersion());
            firstTimeSetUpPromises.push(loadProfitGuruElements());
            firstTimeSetUpPromises.push(loadProfitGuruRestApis());
            firstTimeSetUpPromises.push(loadApplicationSettings(nanoCore));
            firstTimeSetUpPromises.push(loadProfitGuruJson('profitGuruUsersAllEntitlements_', 'profitGuruUsersAllEntitlements.json'));
            firstTimeSetUpPromises.push(loadProfitGuruJson('profitGuruAllowedFeatures_', 'profitGuruAllowedFeatures.json'));
            // firstTimeSetUpPromises.push(loadProfitGuruDocs('hsn', nanoHSN));
            firstTimeSetUpPromises.push(loadProfitGuruDocs('stateCodes', nanoCore));
            firstTimeSetUpPromises.push(loadProfitGuruDocs('uqc', nanoCore));

            const autoIncrementHelper = require('../controllers/common/autoIncrementHelper');
            firstTimeSetUpPromises.push(autoIncrementHelper.getAllAutoIncrementIds());
            firstTimeSetUpPromises.push(createDefaultLocation());
            firstTimeSetUpPromises.push(loadCrmTemplates());

            await Promise.all(firstTimeSetUpPromises);
            await createDefaultConfigurations();
            await createDefaultUsers();
            await createsmsOffer();

            const commonWorker = require('../controllers/workers/commonWorker');
            commonWorker.start(); //Just triggering, not waiting for it to start
            const scheduler = require('../controllers/libraries/scheduler');
            scheduler.startJob();

            let applicationSettingsCouchHandler = require('./applicationSettingsCouchHandler')(couchDBMain);
            let applicationSettings = await applicationSettingsCouchHandler.getApplicationSettings(APP_TYPE);
            let configState = require('../common/configState');
            configState.setApplicationSettings(applicationSettings);
            await setDefaultPriceProfile(applicationSettings, applicationSettingsCouchHandler);
            await setDefaultUnitsInfo(applicationSettings, applicationSettingsCouchHandler);
            //This line because setDefaultPriceProfile can change appsettings
            return configState.getApplicationSettings();

        } catch (err) {
            throw err;
        }

    };

    function prepareProfitGuruElementsJson() {
        return new Promise(function(resolve, reject) {
            if (!profitGuruElementsJson) {
                profitGuruElementsJson = {};

                glob(appRoot + '/config/profitguruCoreConfig/ProfitGuruElements/*')
                    .then(function(ElementsJsonFileList) {
                        ElementsJsonFileList.forEach(function(elementFileName) {
                            var elementJson = jsonfile.readFileSync(elementFileName);
                            var fileName = path.basename(elementFileName);
                            var elementName = fileName.replace('.json', '');
                            profitGuruElementsJson[elementName] = elementJson;

                            //If the element is Employee add the entitlement Doc to it
                            if (elementName === "EmployeeElements") {
                                var entitlementFilePath = appRoot + '/config/profitguruCoreConfig/profitGuruUsersAllEntitlements.json';
                                var employeeEntitlementStruct = _self.prepareDocWithAppSpecifics(entitlementFilePath);
                                delete employeeEntitlementStruct.inProgress;
                                profitGuruElementsJson[elementName].EmpStruct.roles.push(JSON.stringify(employeeEntitlementStruct));
                            } else if (elementName === "profitGuruProfiles") {
                                var profilesSchemaFilePath = appRoot + '/config/profitguruCoreConfig/ProfitGuruElements/profitGuruProfiles.json';
                                profitGuruElementsJson[elementName] = _self.prepareDocWithAppSpecifics(profilesSchemaFilePath);
                            }
                        });
                        resolve(profitGuruElementsJson);

                    }).catch(function(err) {
                        reject(err);
                    });
            } else {
                resolve(profitGuruElementsJson);
            }
        });
    }

    function isDiffExists4CoreDocInDbAndConfigFiles(configDocInCouch, profitGuruCoreConfigDoc) {
        function prefilter(path, key) {
            return (['_id', '_rev'].indexOf(key) >= 0);
        }

        if (!(configDocInCouch && profitGuruCoreConfigDoc)) {
            return true;
        } else {
            var docDiff = require('deep-diff');

            var coreDocDiff = docDiff(configDocInCouch, profitGuruCoreConfigDoc, prefilter);

            return coreDocDiff ? true : false;
        }
    }

    function insertOrUpdateCoreDoc(docName, document2Insert, revision4Update, dbInstance) {

        if (!dbInstance) {
            dbInstance = nanoCore;
        }

        document2Insert._id = docName;
        if (revision4Update) {
            document2Insert._rev = revision4Update;
        }
        return dbInstance.insert(document2Insert).then(function() {
            var status = revision4Update ? 'Updated ' : 'Inserted ';
            console.log('Succesfully ' + status + docName);
            return Promise.resolve(true);
        }).catch(function(reason) {
            console.log('Error whilde Inserting ' + docName);
            return Promise.reject(reason);
        });

    }

    function loadProfitGuruElements() {

        return new Promise(function(resolve, reject) {
            prepareProfitGuruElementsJson().then(function(profitGuruElementsJson) {
                nanoCore.get('profitGuruElements_').then(function(docInDB) {

                    if (isDiffExists4CoreDocInDbAndConfigFiles(profitGuruElementsJson, docInDB[0])) {
                        insertOrUpdateCoreDoc('profitGuruElements_', profitGuruElementsJson, docInDB[0]._rev).then(resolve);
                    } else {
                        resolve();
                    }
                }).catch(function() {
                    insertOrUpdateCoreDoc('profitGuruElements_', profitGuruElementsJson).then(resolve);
                });
            }).catch(console.log);
        });
    }

    function loadProfitGuruRestApis() {

        return new Promise(function(resolve, reject) {
            var profitGuruAllAppRestApiJson = {};
            profitGuruAllAppRestApiJson[APP_TYPE] = {};
            var profitGuruRestApiDoc = require(appRoot + '/config/profitguruCoreConfig/PGServerJsRestApis.json');

            for (var module in profitGuruRestApiDoc) {
                profitGuruAllAppRestApiJson[APP_TYPE][module] = {};

                for (var api in profitGuruRestApiDoc[module]) {
                    profitGuruAllAppRestApiJson[APP_TYPE][module][api] = profitGuruRestApiDoc[module][api];

                }
            }

            nanoCore.get('profitGuruRestApis_').then(function(docInDB) {

                if (isDiffExists4CoreDocInDbAndConfigFiles(profitGuruAllAppRestApiJson, docInDB[0])) {
                    insertOrUpdateCoreDoc('profitGuruRestApis_', profitGuruAllAppRestApiJson, docInDB[0]._rev).then(resolve);
                } else {
                    resolve();
                }
            }).catch(function() {
                insertOrUpdateCoreDoc('profitGuruRestApis_', profitGuruAllAppRestApiJson).then(resolve);
            });

        });

    }

    async function loadApplicationSettings(dbInstance) {
        let appSettingsDoc = require(appRoot + '/config/profitguruCoreConfig/profitGuruApplicationSettings.json');

        let bUpdate = false;
        let docInDB;
        try {
            docInDB = await couchDBUtils.getDoc('profitGuruApplicationSettings_', dbInstance);
            if (!utils.syncKeys(appSettingsDoc, docInDB, ['_id', '_rev', 'terminals'])) {
                bUpdate = true;
            }

            if (!docInDB.terminals) {
                //If terminal settings is not there.. adding it
                docInDB.terminals = {};
                bUpdate = true;
            }

            let terminalConfigs = appSettingsDoc.terminalConfigs;
            for (let key in docInDB.terminals) {
                for (let i = 0; i < terminalConfigs.length; i++) {
                    if (!docInDB.terminals[key][terminalConfigs[i]]) {
                        docInDB.terminals[key][terminalConfigs[i]] = {};
                    }
                    if (!utils.syncKeys(appSettingsDoc[terminalConfigs[i]], docInDB.terminals[key][terminalConfigs[i]], [])) {
                        bUpdate = true;
                    }
                }
                for (let prop in docInDB.terminals[key]) {
                    if (terminalConfigs.indexOf(prop) < 0) {
                        delete docInDB.terminals[key][prop];
                        bUpdate = true;
                    }
                }
            }
        } catch (error) {
            bUpdate = true;
            docInDB = appSettingsDoc;
        }

        if (!bUpdate) {
            return;
        }
        docInDB._id = 'profitGuruApplicationSettings_';

        try {
            await couchDBUtils.create(docInDB, dbInstance, 2, 'Application Settings Loading Failed');
        } catch (error) {
            throw error;
        }
    }

    async function loadCrmTemplates() {
        let docType = 'ct'
        let defaultCrmTemplates = require(appRoot + '/config/profitguruCoreConfig/crmTemplates.json');
        let allTemplates = await couchDBUtils.getAllDocsByType(docType, nanoMain);
        if (allTemplates.length) {
            return;
        }

        await couchDBUtils.bulkDocs(defaultCrmTemplates, nanoMain, 1, docType);
    }

    //this is used in migrations as well
    this.prepareDocWithAppSpecifics = function(fileName) {

        var configDoc = require(fileName);
        if (configDoc.appSpecific && configDoc.appSpecific[APP_TYPE]) {
            var appSepecificElements = configDoc.appSpecific[APP_TYPE];
            delete configDoc.appSpecific;

            for (var element in appSepecificElements) {
                configDoc[element] = appSepecificElements[element]
            }
        }

        return configDoc;
    }

    async function loadProfitGuruJson(docName, docFileName, dbInstance) {

        if (!dbInstance) {
            dbInstance = nanoCore;
        }

        let filePath = appRoot + '/config/profitguruCoreConfig/' + docFileName;
        let refDoc = _self.prepareDocWithAppSpecifics(filePath);

        try {
            let docInDB = await dbInstance.get(docName);

            if (isDiffExists4CoreDocInDbAndConfigFiles(refDoc, docInDB[0])) {
                await insertOrUpdateCoreDoc(docName, refDoc, docInDB[0]._rev);
            }
        } catch (error) {
            await insertOrUpdateCoreDoc(docName, refDoc);
        }
    }

    async function loadProfitGuruDocs(docFilePattern, dbInstance) {

        async function insertDoc(fileName, dbInstance, bForce) {
            try {
                let doc = require(fileName);
                if (!doc) {
                    throw "Doc format is not supported."
                }
                doc._id = docFilePattern;

                if (bForce) {
                    let resp = await couchDBUtils.delete({
                        _id: docFilePattern
                    }, dbInstance);
                    logger.info('deleted previous doc');
                }

                await couchDBUtils.create(doc, dbInstance);
            } catch (error) {
                logger.error(error);
                throw 'Updating ' + fileName + ' failed';
            }
        }

        function getTimeStamp(fileName) {
            let indexDash = fileName.lastIndexOf('_');
            let indexDot = fileName.lastIndexOf('.');
            let timeStamp = 0;
            if (indexDash && indexDot && indexDot > indexDash) {
                timeStamp = fileName.substr(indexDash + 1, indexDot - indexDash - 1);
                if (isNaN(timeStamp)) {
                    timeStamp = 0;
                } else {
                    timeStamp = parseInt(timeStamp);
                }
            }

            return timeStamp;
        }

        function getFileName(pattern) {
            let resp = shelljs.ls(appRoot + '/config/profitguruCoreConfig/' + pattern);
            let outArray = resp.stdout.split('\n');
            let length = outArray.length;
            if (length === 0) {
                let msg = pattern + ' File Not Found'
                logger.error(msg);
                throw msg;
            }

            return outArray[length - 2]; //returning latest file
        }

        let fileName;
        try {
            fileName = getFileName(docFilePattern + '_*');

            let doc = await couchDBUtils.getDoc(docFilePattern, dbInstance, 'propagate');
            let fileTimeStamp = getTimeStamp(fileName);
            if (!fileTimeStamp) {
                throw "Unexpected file format";
            }

            if (doc.timeStamp !== fileTimeStamp) {
                await insertDoc(fileName, dbInstance, true);
            }
        } catch (error) {
            if (error.error === "not_found") {
                await insertDoc(fileName, dbInstance, false);
            } else {
                logger.error(error);
                throw 'update docs failed';
            }
        }
    }

    async function createDefaultLocation() {
        let errMsg = 'Missing';
        try {
            await nanoMain.get('location_1');
        } catch (error) {
            return await nanoMain.insert({
                _id: 'location_1',
                location_name: 'India'
            });
        }
    }

    function createDefaultConfigurations() {
        var globalConfigCntrlr = require('../controllers/GlobalConfigurations');
        return globalConfigCntrlr.createDefaultConfigs();
    }
    async function setDefaultUnitsInfo(applicationSettings, applicationSettingsCouchHandler) {
        if (applicationSettings.defaultUnitSettings.id) {
            return;
        }

        let resp = await couchDBUtils.getAllDocsByType('unit', nanoMain);
        if (!resp.length) {
            throw 'default unit missing';
        }

        applicationSettings.defaultUnitSettings.id = resp[0].doc.id;
        //cheating with dummy app . because after firsttimecouchinit app.local.appsettings is set
        applicationSettingsCouchHandler.updateApplicationSettings({
            body: applicationSettings,
            app: {
                locals: {}
            },
        }, APP_TYPE);
    }
    async function setDefaultPriceProfile(applicationSettings, applicationSettingsCouchHandler) {
        if (applicationSettings.salesConfig.pProfileId) {
            return;
        }

        let resp = await couchDBUtils.getAllDocsByType('pProfile', nanoMain);
        if (!resp.length) {
            throw 'default profile missing';
        }

        applicationSettings.salesConfig.pProfileId = resp[0].doc.id;
        //cheating with dummy app . because after firsttimecouchinit app.local.appsettings is set
        applicationSettingsCouchHandler.updateApplicationSettings({
            body: applicationSettings,
            app: {
                locals: {}
            },
        }, APP_TYPE);
    }

    async function createUserWithAdminRole(user) {
        var filePath = '../config/profitguruCoreConfig/profitGuruUsersAllEntitlements.json';
        let entitlements = _self.prepareDocWithAppSpecifics(filePath);
        employeeProfiler.adminRolePermissions(entitlements);

        user._id = "org.couchdb.user:" + user.name;
        user.type = 'user';
        var rolesJSON = entitlements;
        user.roles.push(JSON.stringify(rolesJSON));
        user.roles.push('admin');

        try {
            let doc = await couchDBUtils.getDoc(user._id, nanoUsers, 'deleted/missing');
            if (doc.APP_TYPE === user.APP_TYPE) {
                return;
            } else {
                user.name = user.name + '_' + APP_TYPE;
                user.username = user.name;
                user._id = "org.couchdb.user:" + user.name;
            }

            doc = await couchDBUtils.getDoc(user._id, nanoUsers, 'deleted/missing');
            //admin user exists
            return;
        } catch (error) {
            logger.info('admin user doesnt exist so creating');
        }

        try {
            await couchDBUtils.create(user, nanoUsers, 1, 'propagate');
        } catch (error) {
            if (error.statusCode === 409) {
                logger.error(error.reason);
                logger.error(user.name + ' create error.  Not throwing error. Giving benefit of doubt, user already created for some other purpose');
            } else {
                throw error;
            }
        }
    }

    function createDefaultUsers() {

        var adminUser = {
            username: 'admin',
            name: 'admin',
            APP_TYPE: APP_TYPE,
            password: 'profitGuru',
            password_again: 'profitGuru',
            isDefaultAdmin: true,
            passwordHasToBeChanged: true,
            first_name: 'Welcome to',
            last_name: 'ProfitGuru',
            gender: '',
            email: APP_TYPE + '@xyz.com',
            phone_number: '',
            address_1: 'xxxxxxx-1',
            address_2: 'xx xx xx',
            city: 'Dandeli',
            state: 'Karnataka',
            zip: '581329',
            country: 'India',
            comments: '',
            profile: 'adminProfile',
            isDistributor: false,
            distributorEmail: '',
            roles: []
        };

        return createUserWithAdminRole(adminUser).then(function(resp) {
            logger.info('admin user created');
        }).catch(function(err) {
            throw new Error(err);
        });
    }

    async function createsmsOffer() {
        let bCreate = false;
        let count;
        try {
            //let resp = await couchDBUtils.getDoc('smsOffer', nanoLicence, 'propagate');
            let resp = await smsDAO.get();
        } catch (error) {
            count = 0;
            bCreate = true;
            if (error.reason === 'missing') {
                count = 10;
            }
        }
        let doc = {
            apiUrl: "http://2factor.in/API/V1/",
            apiKey: "bc76ef16-6338-11e7-94da-0200cd936042",
            transLinkAdd: "ADDON_SERVICES/SEND/TSMS",
            promoLinkAdd: "ADDON_SERVICES/SEND/PSMS",
            sender: "ALINHU",
            transQuotaList: [{
                timestamp: moment().format('x'),
                count: count
            }],
            promoQuotaList: [{
                timestamp: moment().format('x'),
                count: count
            }]
        };

        if (bCreate) {
            try {
                doc = await couchDBUtils.getDoc('smsInfo', nanoLicence, 'propagate'); //TODO : remve this after few releases from 28-march-18
            } catch (e) {

            }
            try {
                //await couchDBUtils.create(doc, nanoLicence);
                doc._id = 'smsOffer';
                await smsDAO.save(doc);
            } catch (error) {
                logger.error('smsOffer default failed');
            }
        }
    }

};

module.exports = new firtTimeInitCouchHandler();