const marketDBUtils = function() {
    let couchUtils;
    const logger = require('../common/Logger');
    'use strict';

    this.initilizeDb = async function(param) {
        let cloudCouchUrl = param.cloudCouchUrl;
        let dbName = param.dbName;
        let response = {
            msg: '',
            error: true
        }
        let bCreate = false;

        let couchServerInstance = require("nano-blue")(cloudCouchUrl);
        try {
            let exist = await couchServerInstance.db.get(dbName);
            logger.info(dbName + 'DB Exists ');
        } catch (ex) {
            logger.error("db does't exist " + dbName)
            bCreate = true;
        }

        try {
            if (bCreate)
                await couchServerInstance.db.create(dbName);
        } catch (ex) {
            logger.error("failed to create db " + dbName);
            throw "db failed";
        }
        await initFeedbackFilter(couchServerInstance, dbName);
        return true;
    }

    let initFeedbackFilter = async function(couchServerInstance, dbName, response) {
        // creating and updating filters and views [design docs]
        var designDoc = [{
            _id: 'all_market_data',
            version: 2,
            filters: {
                purchase_order: function(doc) {
                    var doctype, uidx;
                    if (doc._id && (uidx = doc._id.indexOf("_")) > 0) {
                        doctype = doc._id.substring(0, uidx);
                        if (doctype === "purchaseOrder") {
                            return true;
                        }
                    }
                    return false;
                }
            },
            views: {}
        }];

        //for loop
        let designDocArry = []
        for (let i = 0; i < designDoc.length; i++) {
            let doc = designDoc[i];
            for (prop in doc) {
                if (prop === '_id') {
                    doc._id = '_design/' + doc._id;
                }
                if (['filters', 'views'].indexOf(prop) > -1) {
                    for (foo in doc[prop]) {
                        doc[prop][foo] = doc[prop][foo].toString();
                    }
                }
            }
            designDocArry.push(designDoc[i]._id);
        }

        if (!couchUtils) {
            couchUtils = require("../controllers/common/CouchDBUtils");
        }

        let dbInstance = couchServerInstance.db.use(dbName);
        let queryResponse = await couchUtils.getAllDocs(designDocArry, dbInstance)
        let docToUpdate = []
        for (let i = 0; i < queryResponse.length; i++) {
            if (queryResponse[i].error) {
                //create
                docToUpdate.push(designDoc[i]);
            } else {
                if (queryResponse[i].doc.version != designDoc[i].version) {
                    //update
                    designDoc[i]._rev = queryResponse[i].doc._rev;
                    docToUpdate.push(designDoc[i]);
                }
            }

        }
        if (docToUpdate.length) {
            try {
                await couchUtils.bulkDocs(docToUpdate, dbInstance);
            } catch (ex) {
                logger.error("Failed in updating market filter/view");
                logger.error(ex);
                throw "view failed";
            }
        }
        return true;
        //create/update
    }
}

module.exports = new marketDBUtils();