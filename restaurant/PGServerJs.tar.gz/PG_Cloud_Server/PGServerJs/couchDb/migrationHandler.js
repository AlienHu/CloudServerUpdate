'use strict';

//This should be run from installer, updater and couchdbmain also
//This module should have no or very minimal dependency
//This and all the dependencies should be self sufficient

let foo = function() {

    const couchDBUtils2 = require('./couchDBUtils2');
    const backUpAndRestore = require('../controllers/backUpAndRestore');
    const logger = require('../common/Logger');
    const configState = require('../common/configState');
    let platform = configState.getPlatform();

    /**
     * 1. Check if migrations are pending
     * 2. Take backup
     * 3. syncdatabase
     * 4. In case it fails, restore the database
     * migrationName = 20170717000000-appsetInvoiceTitle.js
     * if migration name is empty it will call pending up functions
     */
    this.migrate = async function(migrationName) {
        let config;
        let backUpConfig;
        let backUpBaseLocationDir;

        try {
            config = await configState.getAppConfig();
            let dbUrl = couchDBUtils2.getCouchUrl(config.localCouch);
            config.localCouch.dbUrl = dbUrl;
            let couchdbPGClients = await couchDBUtils2.createAndKeepCouchDbClient(config.localCouch);

            let appName = process.env.APP_TYPE;
            let umzugStoragePath = config.umzugStoragePath[platform];
            backUpBaseLocationDir = umzugStoragePath + '/backUp/';
            if (!(/^win/.test(process.platform))) {
                backUpBaseLocationDir = process.env['HOME'] + backUpBaseLocationDir;
            }

            backUpConfig = {
                reason4Backup: 'migration',
                backUpBaseLocationDir: backUpBaseLocationDir,
                couchConnectUrl: dbUrl
            };

            let migrationsBasePath = __dirname + '/../couchDBMigrations';

            let params = {
                storage: 'json',
                storageOptions: {
                    path: await configState.getUmzugStorageFullPath()
                },
                migrations: {
                    params: [{
                        nanoClients: couchdbPGClients[appName],
                        logger: logger,
                        migrationsBasePath: migrationsBasePath
                    }],
                    path: migrationsBasePath,
                    pattern: /\.js$/
                }
            };

            if (!(/^win/.test(process.platform))) {
                params.storageOptions.path = process.env['HOME'] + params.storageOptions.path;
            }
            let umzugUtils = require('../common/umzugUtils')(params);
            if (!(await umzugUtils.isRunMigrations(migrationName))) {
                logger.info('Database already in sync');
                return;
            }

            if (await umzugUtils.isFreshPC(migrationName)) {
                logger.info('firsttimecouchinithandler will take care');
                await umzugUtils.writeDummyEntry();
                return;
            }

            await backUpAndRestore.takeBackUp(backUpConfig);
            logger.info('backup completed');

            await umzugUtils.syncDatabase(migrationName);
            logger.info('syncdatabase completed');
        } catch (error) {
            logger.error(error);

            if (backUpConfig) {
                let restoreBackUpConfig = {
                    reason4Backup: 'migration_failed',
                    backUpBaseLocationDir: backUpBaseLocationDir,
                    backUpLocation2Restore: backUpConfig.backUpLocation,
                    couchConnectUrl: couchDBUtils2.getCouchUrl(config.localCouch)
                };

                //error happend so restoring the database to previous state. MaxRetries = 3
                await backUpAndRestore.restoreFromBackUp(restoreBackUpConfig, 3);
            }

            throw error;
        }
    };

};

module.exports = new foo();