function convertUndefinedToEmptyStrings(paramObject, existingSetting) {
    var keys = Object.keys(paramObject);
    for (var i = 0; i < keys.length; i++) {
        var tempObject = paramObject[keys[i]];
        var tempExistObject = existingSetting[keys[i]];
        if (tempObject === Object(tempObject)) {
            convertUndefinedToEmptyStrings(tempObject, tempExistObject);
        } else if (paramObject[keys[i]] === undefined) {
            if (!isNaN(existingSetting[keys[i]])) {
                paramObject[keys[i]] = 0;
            } else if (Array.isArray(existingSetting[keys[i]])) paramObject[keys[i]] = [];
            else if (typeof(existingSetting[keys[i]]) === 'boolean') paramObject[keys[i]] = false;
            else if (typeof(existingSetting[keys[i]]) === 'string') paramObject[keys[i]] = "";
            else paramObject[keys[i]] = {};
        }
    }
    return paramObject;
}

var oldJ = {
    footNote: "foot text",
    showFoot: false,
    label: "dpk",
    innerJSON: {
        x: 0,
        y: 1,
        extra: {
            uu: "ddd"
        }
    }
}
var newJ = {
    footNote: undefined,
    showFoot: false,
    label: undefined,
    innerJSON: {
        x: 0,
        y: 1,
        extra: {
            uu: undefined
        }
    }
}
var res = convertUndefinedToEmptyStrings(newJ, oldJ);
console.log(JSON.stringify(res));