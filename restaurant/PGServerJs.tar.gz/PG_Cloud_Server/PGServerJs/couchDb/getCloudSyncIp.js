'use strict';

const cloudCouchParams = require('../config/config').production.retail.cloudCouch;

function getCloudCouchSyncDetails(serverSerilaNumber) {
    const WebRequest = require("../common/webRequest.js");

    return new Promise(function(resolve, reject) {

        const webRequest = new WebRequest(cloudCouchParams.host, {
                "Content-Type": "application/json",
                "x-api-key": cloudCouchParams.apiKey
            },
            cloudCouchParams.ssl);

        webRequest.get(cloudCouchParams.api.cloudSyncDetails + '?ServerId=' + serverSerilaNumber, function(err, data) {
            if (err) {
                reject(err);
                return;
            }

            if (data.statusCode < 200 || data.statusCode > 299) {
                reject({
                    error: "Request Failed",
                    trace: data
                });
                return;
            }

            try {
                const parsedData = JSON.parse(data.data.toString());
                resolve(parsedData);
                return;
            } catch (e) {
                reject({
                    error: "Failed to parse json",
                    trace: e
                });
            }
        });
    });
}

// getCloudCouchSyncDetails('00-01-6c-45-96-06').then(console.log);

const Utils = function() {
    this.getCloudCouchSyncDetails = getCloudCouchSyncDetails;
};

module.exports = new Utils();