 var urlParser = require('url');
 var path = require('path');

 var serverConfig = require(path.join(__dirname, '../../config', 'config.json'));
 //var defaultWhiteListApiList = ['/user/signin', '/user/signout', '/user/signup', '/core/profitGuruRestApis', '/core/profitGuruElements', '/licence/amiauthorized2connect'];
 var whiteListApis = [];

 serverConfig.defaultWhiteListApis.forEach(function(api, index) {
     whiteListApis.push(api.toLowerCase());
 });

 var whiteListModules = [];
 serverConfig.defaultWhiteListModules.forEach(function(api, index) {
     whiteListModules.push(api.toLowerCase());
 });

 function loginAuthorizer(whiteListApiList) {
     if (whiteListApiList) {
         whiteListApis.push(whiteListApiList);
     }

     return function loginAuthorizer(req, res, next) {
         var urlPath = urlParser.parse(req.url).pathname.toLowerCase();
         //to Remove / at the end of url, to get the match properly
         urlPath = urlPath.replace(/\/\s*$/, "");
         var moduleName = urlPath.split('/');
         moduleName = moduleName[1].toLowerCase();

         if (req.session.user !== undefined || whiteListApis.indexOf(urlPath) >= 0 || whiteListModules.indexOf(moduleName) >= 0) {
             return next();
         } else {
             res.send(new Error('Login Error: User Not logged in'));
             res.end();
         }
     };
 }

 module.exports = loginAuthorizer;