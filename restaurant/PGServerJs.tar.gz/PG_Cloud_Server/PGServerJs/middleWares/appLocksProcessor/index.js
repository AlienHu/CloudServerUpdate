var shelljs;
var apRoot;

function applicaltionLocksProcessor() {
    return function applicaltionLocksProcessor(req, res, next) {
        if (!shelljs) {
            apRoot = req.app.get('appRootPath');
            shelljs = require(apRoot + '/node_modules/shelljs');
            //Suppresses all command output if true, except for echo() calls. Default is false.
            shelljs.config.silent = true;
        }

        var locksList = shelljs.ls('-d', apRoot + '/locks/*.lock');
        if (locksList.length > 0) {
            locksList = locksList.sort().split('\n');
            var appLockReasons = '';
            locksList.forEach(function (lockName) {
                lockName = lockName.replace('.lock', ' ,');
                appLockReasons += lockName;
            });
            res.send(new Error('Apllication Locked: Because of ' + appLockReasons + ' are Being Held up'));
            res.end();
        } else {
            return next();
        }

    };
}

module.exports = applicaltionLocksProcessor;