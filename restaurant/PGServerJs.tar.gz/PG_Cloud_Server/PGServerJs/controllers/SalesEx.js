"use strict";
//Bulk get source and destination table doc
//Iterate the array and get source orderno index
//Update slice from source order array and add at destination table.order 
//order no = maxOrderno + 1
//maxOrderno++ (increment)
//Bulk Update source and destination table doc
//send if succes otherwise throw the error
//copy from stock entry api.
//time to fix compiling ts both for developers and build purpose
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const couchDBUtils = require("./common/CouchDBUtils");
const logger = require("../common/Logger");
const mainDBInstance = couchDBUtils.getMainCouchDB();
exports.changeTableOrder = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        let allDocs = yield couchDBUtils.getAllDocs([data.srcTable, data.dstTable], mainDBInstance);
        let srcTableData = allDocs[0].doc;
        let dstTableData = allDocs[1].doc;
        let maxOrderno = dstTableData.maxOrderNo + 1;
        let srcOrderDataIndex = getOrderData(srcTableData, data.srcOrderNo);
        let srcOrderData = srcTableData.orders[srcOrderDataIndex];
        srcOrderData.order_no = maxOrderno;
        if (!dstTableData.orders) {
            dstTableData.orders = [];
        }
        dstTableData.orders.push(srcOrderData);
        dstTableData.maxOrderNo = maxOrderno;
        srcTableData.orders.splice(srcOrderDataIndex, 1);
        let docsArray = [srcTableData, dstTableData];
        try {
            let resp = yield couchDBUtils.bulkDocs(docsArray, mainDBInstance, 3);
            return 'success';
        }
        catch (error) {
            logger.error(error);
            throw "Could not change table";
        }
    });
};
function getOrderData(srcTableData, srcOrderNo) {
    for (let i = 0; i < srcTableData.orders.length; i++) {
        if (srcTableData.orders[i].order_no === srcOrderNo) {
            return i;
        }
    }
}
;
//# sourceMappingURL=SalesEx.js.map