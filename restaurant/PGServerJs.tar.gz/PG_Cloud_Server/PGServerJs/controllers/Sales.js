/*jshint sub:true*/

const moment = require('moment');
const validator = require('validator');
const BPromise = require('bluebird');
const utils = require('./common/Utils');
const IS_UNDEFINED_OR_NULL = utils.isUndefinedOrNull2;
const ASSIGN_IFNOT_UNDEFINED = utils.assignifNotUndefined;
const CLONE = utils.clone;
const logger = require('../common/Logger');
const status = require('../common/StatusCode');
const responseUtil = require('../common/responseJson');
const alienSaleSchedular = require('../TSControllers/libraries/alienSale');
let appSettingsHandler = require('../couchDb/applicationSettingsCouchHandler')();
const sendSMS = require('../sms/sms');
const customerCntrller = require('./Elements');
let maxHDOrderNo = require('./common/autoIncrementHelper').getMaxHomeDeliveryId();
const salesExController = require('../TSControllers/SalesEx');
const autoIncrementHelper = require('./common/autoIncrementHelper');

let maxSOOrderNo = require('./common/autoIncrementHelper').getMaxSalesOrderId();
let maxSQOrderNo = require('./common/autoIncrementHelper').getMaxSalesQuotationId();

// foo.form_validation.set_rulesRestApi('price', 'lang:items_price', 'required|numeric');
//             foo.form_validation.set_rulesRestApi('quantity', 'lang:items_quantity', 'required|numeric');
//             foo.form_validation.set_rulesRestApi('discount', 'lang:items_discount', 'required|numeric');

function salesController(requestSession, applicationSettings) {

    var salesControllerLib = new require('./libraries/salesControllerLib')(requestSession, applicationSettings);
    const salesControllerLib2 = new require('./libraries/salesControllerLib2');
    var suspendSalesLib = require('./libraries/SuspendSalesLib');
    var creditPaymentsLib = require('./libraries/creditPaymentsLib');
    var couchDBUtils = require('./common/CouchDBUtils');
    const commonLib = require('./libraries/commonLib');
    const commonLibEx = require('../TSControllers/libraries/commonLibEx');
    const saleEx = require('../TSControllers/SalesEx');
    const getSaleOnCreditAmt = commonLibEx.getSaleOnCreditAmt;
    const getTaxesByPercentage = commonLibEx.getTaxesByPercentage;
    const taxLib = require('../TSControllers/libraries/taxDetailsCommon');
    const getTaxesByPercentageDetailed = taxLib.getTaxesByPercentageDetailed;
    const get_taxes = commonLibEx.get_taxes;
    var mainDBInstance = couchDBUtils.getMainCouchDB();

    var salesValidator = require('./validatiors/Sales');

    let foo = {};
    var _self = foo;

    foo.getSaleLib = function() {
        //In UT 
        return salesControllerLib;
    };

    /**
     *      addCustomer2SaleRestApi
     */
    foo.addCustomer2Sale = function(requestData) {
        var customer_id = requestData.customer_id;
        var response = {
            succs_customer_id: null
        };

        return salesControllerLib.set_customer(customer_id).then(async function(resp) {
            if (resp.status === status.SUCCESS) {
                response.succs_customer_id = customer_id;
                if (requestData.doc_id) {
                    let doc = await couchDBUtils.getDoc(requestData.doc_id, mainDBInstance);
                    doc.sales_info.customer_id = customer_id;
                    // change name as well
                    const customerDoc = await couchDBUtils.getDoc('customer_' + customer_id, mainDBInstance);
                    doc.sales_info.customer = customerDoc.first_name + " " + customerDoc.last_name;
                    delete doc.sales_info.wcInfo;
                    let updateResp = await couchDBUtils.update(doc, mainDBInstance, 3);
                    let data = await couchDBUtils.getDoc(requestData.doc_id, mainDBInstance);
                    let module = requestData.doc_id.substr(0, 2);
                    if (module === 'hd') {
                        salesControllerLib.setHDIdRev(data);
                    } else if (module === 'so') {
                        salesControllerLib.setSOIdRev(data);
                    } else if (module === 'sq') {
                        salesControllerLib.setSQIdRev(data);
                    }
                    salesControllerLib.setWCInfo();
                }
            }
            let cust_info = salesControllerLib.getCartCustomerDetails();
            if (cust_info && cust_info.state_name && applicationSettings.ownersInfo.state != cust_info.state_name) {
                await salesControllerLib.setLocalTax(false);
            } else {
                await salesControllerLib.setLocalTax(true);
            }
            return prepareAndDispatchResponse(response);
        }).catch(function(err) {
            logger.error(err);
            return response;
        });
    };

    foo.addEmployee2Sale = async function(requestData) {
        var employee = requestData.employee_id;
        if (!employee) {
            employee = requestSession.user.name;
        }
        var response = {
            succs_employee: null
        };
        try {
            var resp = await salesControllerLib.setCartEmployeeDetails(employee)
            if (resp.status === status.SUCCESS) {
                response.succs_employee = employee;
            }

            response = await prepareAndDispatchResponse(response);
            return response;
        } catch (err) {
            logger.error(err);
            throw err;
        };
    };

    foo.addPrescription2Sale = function(requestData) {
        var prescriptionDetails = requestData.prescriptionDetails;
        var response = {};
        if (salesControllerLib.set_prescriptionDetails(prescriptionDetails) === status.SUCCESS) {
            response.prescriptionDetails = prescriptionDetails;
            return prepareAndDispatchResponse(response);
        } else {
            logger.error('Failed to add prescription details');
            throw 'Failed to add prescription details';
        };
    }
    foo.addRoom2Sale = async function(data) {
        if (IS_UNDEFINED_OR_NULL(data.customer_id) || IS_UNDEFINED_OR_NULL(data.refBookingId)) {
            throw 'Customer Id and Booking Id is mandatory';
        }

        salesControllerLib.setRefBookingId(data.refBookingId);

        return foo.addCustomer2Sale(data);
    };

    foo.additemRestApi = async function(requestData, bRemoveItem) {
        let bThrowError = requestData.bThrowError;

        var reverseQuantitySign = 1;
        if (!utils.isUndefinedOrNull(bRemoveItem)) {
            reverseQuantitySign = -1;
        }

        var response = {};
        var uniqueDetails = requestData.uniqueDetails ? requestData.uniqueDetails : {};

        var quantity = 1 * reverseQuantitySign;
        if (requestData.quantity) {
            quantity *= requestData.quantity;
        }

        let requiredFields = ['stockKey', 'unitId', 'unitsInfo', 'discount', 'price', 'baseUnitId', 'discount', 'discountBy', 'description'];
        let requiredFields2 = ['item', 'itemTaxList', 'bSPTaxInclusive', 'slab'];
        let mappedFields = ['itemId', 'pItemTaxList', 'pBSPTaxInclusive', 'pSlab'];
        let params = {};
        params.quantity = quantity;
        for (let i = 0; i < requiredFields.length; i++) {
            params[requiredFields[i]] = requestData[requiredFields[i]];
        }
        for (let i = 0; i < requiredFields2.length; i++) {
            params[mappedFields[i]] = requestData[requiredFields2[i]];
        }
        if (uniqueDetails.serialnumber || uniqueDetails.imeiNumbers) {
            params.serialnumber = uniqueDetails.serialnumber;
            params.imeiNumbers = uniqueDetails.imeiNumbers;
            params.isNew = uniqueDetails.new;
        }

        try {
            let cartItem = await salesControllerLib.addItem2Cart(params);

            // if (cartItem.is_serialized || cartItem.imeiCount) {
            //     //have logic inside the lib iteself
            //     var params = {
            //         line: cartItem.line,
            //         description: cartItem.description,
            //         serialnumber: uniqueDetails.serialnumber,
            //         imeiNumbers: uniqueDetails.imeiNumbers,
            //         price: cartItem.price,
            //         quantity: cartItem.quantity,
            //         discount: cartItem.discount
            //     };

            //     await _self.editItemRestApi(params);
            // }

            let itemStockStatus = await salesControllerLib.out_of_stock(requestData.item, requestData.stockKey);
            response.warning = itemStockStatus;
            return prepareAndDispatchResponse(response);
        } catch (err) {
            logger.error('additemRestApi exception')
            logger.error(err);
            logger.error(requestData);
            response.warning = err;
            if (bThrowError) {
                throw err;
            }
            return prepareAndDispatchResponse(response);
        };

    };

    foo.updateUnit = async function(requestData) {
        await salesControllerLib.updateUnit(requestData);
        return prepareAndDispatchResponse();
    };

    foo.editItemRestApi = function(requestData) {

        var response = {};
        return Promise.resolve().then(function() {

            //foo.form_validation.set_rulesRestApi('price', 'lang:items_price', 'required|numeric');
            // foo.form_validation.set_rulesRestApi('quantity', 'lang:items_quantity', 'required|numeric');
            // foo.form_validation.set_rulesRestApi('discount', 'lang:items_discount', 'required|numeric');
            var errMsg = '';
            var bIsDataValid = salesValidator.editItem(requestData, errMsg);
            if (!bIsDataValid) {
                Promise.reject(errMsg);
            } else {
                var discountMethod = requestData.discountBy;
                var line = requestData.line;
                var description = requestData.description;
                var serialnumber = requestData.serialnumber;
                var imeiNumbers = requestData.imeiNumbers;
                var price = requestData.price;
                var quantity = requestData.quantity;
                var discount = requestData.discount;
                var itemLocation = requestData.item_location;
                var name = requestData.name;
                var dp = discount;

                salesControllerLib.edit_item(line, description, serialnumber, imeiNumbers, quantity, discount, discountMethod, price, name);
                return salesControllerLib.out_of_stock(salesControllerLib.get_item_id(line), salesControllerLib.getStockKey(line), itemLocation);
            }
        }).then(function(itemStockStatus) {
            response.warning = itemStockStatus;
            return prepareAndDispatchResponse(response);
        });
    };

    /**
     * {
     * bPercent: true
     * value: 5
     * }
     * For tests, discountMethod has to be old method i.e. onTaxable
     */
    foo.setGlobalDiscount = async function(requestData) {
        if (!requestData.discountMethod) {
            //This change was done for sale edit
            requestData.discountMethod = (applicationSettings.salesConfig.discountMethod) ? applicationSettings.salesConfig.discountMethod : 'onTaxable';
        }
        await salesControllerLib.setGlobalDiscount(requestData);
        return prepareAndDispatchResponse();
    };

    /**
     * saving global discount in table order docs.
     * Input : * {
        tableNo:tableDoc.table_no,
        order_no:tableDoc.orders[0].order_no,
        value: 10,
        bPercent:  false,
        discountMethod : 'onTotal'
       }
     * 
     */

    foo.saveGlobalDiscount = async (requestData) => {
        let response = {};
        try {
            if (!requestData.discountMethod) {
                requestData.discountMethod = (applicationSettings.salesConfig.discountMethod) ? applicationSettings.salesConfig.discountMethod : 'onTaxable';
            };

            const tableDoc = await couchDBUtils.getDoc('table_' + requestData.tableNo, mainDBInstance);
            const orderIndex = salesExController.getOrderData(tableDoc, requestData.order_no);
            tableDoc.orders[orderIndex].globalDiscountInfo = {
                value: requestData.value,
                bPercent: requestData.bPercent,
                discountMethod: requestData.discountMethod
            };

            const updateResp = await couchDBUtils.update(tableDoc, mainDBInstance, 3);
            response = prepareAndDispatchResponse()
        } catch (error) {
            logger.error(error);
            response.error = 'Saved Global Discount failed';
            throw response;
        }
        return response;
    };

    /**
     *      removeitemRestApi
     */
    foo.removeItem = function(requestData) {
        return _self.additemRestApi(requestData, 1);
    };

    /**
     * DeleteItemFromCartRestApi
     * Todo 
     *          requestData.item is actually line number. Please validate
     */
    foo.delteItemFromCart = function(requestData) {
        var response = {};
        response.status = salesControllerLib.deleteItemByLine(requestData.item);
        return prepareAndDispatchResponse(response);
    };

    async function prepareAndDispatchResponse(response) {

        response = response || {};
        await salesControllerLib.computeCart(1, 0);
        response.cart = CLONE(salesControllerLib.get_cart());
        response.totalNoSpotDiscount = salesControllerLib.get_total();
        response.discount = salesControllerLib.get_discount();
        if (requestSession.gDiscountValue) {
            await salesControllerLib.computeCart();
        }
        let total = salesControllerLib.get_total(response);
        if (requestSession.discountMethod === 'onTaxable') {
            response.discount = salesControllerLib.get_discount();
        } else {
            response.discount += response.totalNoSpotDiscount - total;
        }
        response.discount = +response.discount.toFixed(2);
        response.bLocalTax = requestSession.settings.sales.bLocalTax;
        var allCartTaxes = get_taxes(response.cart, undefined, requestSession);
        response.charges = salesControllerLib.getAllCharges(response.cart);
        var amountDue = salesControllerLib.get_amount_due();
        let totalBeforeDeliveryCharge = total;
        let deliveryCharge = salesControllerLib.getDeliveryCharge();
        response.deliveryCharge = deliveryCharge;

        deliveryCharge = deliveryCharge ? deliveryCharge : 0;
        // amountDue += deliveryCharge;
        //TODO
        // taxArray is moved to cart, each cart Itme would have its tax info
        //This cart taxt summary
        response.taxes = allCartTaxes;
        response.bReadyForCheckout = salesControllerLib.isCartReadyForCheckout();
        response.refBookingId = salesControllerLib.getRefBookingId();
        //TODO
        //var person_info = foo.Employee.get_logged_in_employee_info();                
        response.modes = {
            sale: 'Sale',
            return: 'Return'
        };
        response.mode = salesControllerLib.get_mode();
        response.profileId = salesControllerLib.getProfileId();
        response.globalDiscountInfo = await salesControllerLib.getGlobalDiscountInfo();
        response.globalDiscountInfo.discountMethod = applicationSettings.salesConfig.discountMethod;
        //TODO looks foo is not needed at client side
        //response.stock_locations = foo.Stock_location.get_allowed_locations('sales');
        response.stock_location = salesControllerLib.get_sale_location();
        response.subtotal = salesControllerLib.get_subtotal(true, true);
        response.tax_exclusive_subtotal = salesControllerLib.get_subtotal(true);
        response.noTaxNoDiscountNoCharges = salesControllerLib.get_subtotal(false);
        response.totalTax = salesControllerLib.getTaxAmt(allCartTaxes);

        //response.taxesArray = foo.getAllCartItemTaxes();
        //TODO looks like we dont need foo
        //response.taxesArray = salesControllerLib.allCartTaxes;

        let totalAfterDeliveryCharge = totalBeforeDeliveryCharge + deliveryCharge;
        response.discounted_subtotal = salesControllerLib.get_subtotal(true);
        response.total = totalAfterDeliveryCharge;
        response.payments = salesControllerLib.get_payments();
        response.saleOnCreditAmt = getSaleOnCreditAmt(response.payments);

        //TODO Need get the Employee Permissions
        //response.items_module_allowed = foo.Employee.has_grant('items', loggedInEmployeeId);

        response.items_module_allowed = [];

        response.comment = salesControllerLib.get_comment();
        response.email_receipt = salesControllerLib.get_email_receipt();
        response.payments_total = +salesControllerLib.get_payments_total().toFixed(2);
        response.amount_due = amountDue;
        response.amount_change = amountDue * -1;
        response.stock_location = salesControllerLib.get_sale_location();
        //TODO might have to create new table with payment options and its names

        // let bSalesOrder = salesControllerLib.getBSalesOrder();
        response.payment_options = {};
        for (let i = 0; i < applicationSettings.paymentTerms.value.length; i++) {
            response.payment_options[applicationSettings.paymentTerms.value[i]] = applicationSettings.paymentTerms.value[i];
        }

        // if (bSalesOrder) {
        //     let orderInfoDate = salesControllerLib.getSOOrderDate();
        //     response.nxtCDate = orderInfoDate.nxtCDate;
        //     response.dlvDate = orderInfoDate.dlvDate;
        //     response.orderCrDate = orderInfoDate.orderCrDate;
        //     response.shippingAddress = salesControllerLib.getShippingAddress();
        //     response.bSalesOrder = bSalesOrder;
        // } else {
        //     response.payment_options['Sale on credit'] = 'Sale on credit';
        // }

        response.payment_options['Sale on credit'] = 'Sale on credit'; //TODO

        //TODO invoice generation
        let bHomeDelivery = salesControllerLib.getOrderFromHD();
        response.amount_due = salesControllerLib.get_amount_due();
        var cust_info = salesControllerLib.getCartCustomerDetails();

        if (!utils.isUndefinedOrNull(cust_info) && cust_info.person_id !== null) {
            var custLastName = cust_info.last_name ? cust_info.last_name : '';
            var custCompanyName = cust_info.company_name ? cust_info.company_name : '';

            response.customer = custCompanyName + ' ' + cust_info.first_name + ' ' + custLastName;
            response.customer_email = cust_info.email;
            response.customer_id = cust_info.person_id;
            response.loyaltyeligible = cust_info.loyalty;
            response.phone_number = cust_info.phone_number;
            response.customer_isCreditAllowed = cust_info.allow_credit;
            response.customer_credit_limit = cust_info.credit_limit;
            response.customer_loyaltyPnts = cust_info.loyaltyPnts;
            response.customer_address = cust_info.address_1;
            response.pincode = cust_info.pin_code;
            response.customerGSTIN = cust_info.gstin_number;
            response.city = cust_info.city_name;
            response.cust_state_name = cust_info.state_name;
        }
        let actual_total = response.total;
        if (deliveryCharge) {
            actual_total -= deliveryCharge;
        }
        let earnOnCredit = saleEx.earnOnCredit();
        if (!earnOnCredit && response.saleOnCreditAmt) {
            logger.info("Loyalty not added for credit payment! :" + response.saleOnCreditAmt);
            actual_total -= response.saleOnCreditAmt;
        }
        prepareLoyalty(response, actual_total);
        response.wcInfo = salesControllerLib.getWCInfo();
        if (!response.customer && response.wcInfo) {
            response.customer = response.wcInfo.invoiceCustomerName;
            response.phone_number = response.wcInfo.invoiceCustomerNumber;
        }

        // response.wcInfo = salesControllerLib.getWCInfo();
        response.employee_id = requestSession.user.name;

        var emp_info = salesControllerLib.getCartEmployeeDetails();
        if (!utils.isUndefinedOrNull(emp_info)) {
            response.employee_id = emp_info.name;
        }
        // response.invoice_number = foo._substitute_invoice_number(cust_info);

        response.invoice_number_enabled = salesControllerLib.is_invoice_number_enabled();
        response.print_after_sale = salesControllerLib.is_print_after_sale();
        response.payments_cover_total = doesPaymentsCoverTotal(response.total);
        if (bHomeDelivery) {
            let deliveryBoy = salesControllerLib.getDeliveryBoy();
            response.deliveryBoy = deliveryBoy;
            response.bHomeDelivery = bHomeDelivery;
        };
        response.sale_id = salesControllerLib.getPrintBillInvoiceNo();

        let bSalesOrder = salesControllerLib.getBSalesOrder();
        let orderInfoDate;
        if (bSalesOrder) {
            orderInfoDate = salesControllerLib.getSOOrderDate();
            response.dlvDate = orderInfoDate.dlvDate;
            response.shippingAddress = salesControllerLib.getShippingAddress();
            response.bSalesOrder = bSalesOrder;
        };

        let bSalesQuotation = salesControllerLib.getSQorder();
        if (bSalesQuotation) {
            orderInfoDate = salesControllerLib.getSQDate();
            response.expDate = orderInfoDate.expDate;
            response.bSalesQuotation = bSalesQuotation;
        }

        if (orderInfoDate) {
            response.nxtCDate = orderInfoDate.nxtCDate;
            response.orderCrDate = orderInfoDate.orderCrDate;
        }

        if (bSalesOrder || bHomeDelivery) {
            response.credit_balance = cust_info.credit_balance >= 1 ? cust_info.credit_balance : 0;
        }

        getTotalMRPValue(response);
        if (!bHomeDelivery) { //temprorary solution ,For saving temp detail need to change many where. holding it for now
            salesControllerLib.getTempDetails(response);
        }
        return response;
    }

    function getTotalMRPValue(response) {
        var mrpTotal = 0;
        for (var k in response.cart) {
            mrpTotal += response.cart[k].mrp * response.cart[k].quantity;
        }

        response.mrpTotal = mrpTotal;
    }

    function prepareLoyalty(response, actual_total) {
        let redeemMoney = salesControllerLib.getRedeemMoney();
        let rmPnts = 0;
        if (redeemMoney) {
            actual_total -= redeemMoney;
            rmPnts = saleEx.convertAmtToPnts(redeemMoney);
        }
        response.loyaltyPnts = saleEx.getLoyaltyPnts(actual_total);
        if (response.customer_loyaltyPnts) {
            let oldCustomer = salesControllerLib.compareCustomer();
            let oldLoyaltyRedeemed = salesControllerLib.getLoyaltyRedeemed();
            if (oldCustomer && oldLoyaltyRedeemed) { //while editing the redeemed sale
                logger.info("*** Edit sale, Loyalty redeemed " + oldLoyaltyRedeemed);
                response.customer_loyaltyPnts += oldLoyaltyRedeemed;
            }
            let oldLoyaltyEarned = salesControllerLib.getLoyaltyEarned();
            if (oldCustomer && oldLoyaltyEarned) { // while editing the sale
                logger.info("*** Edit sale, Loyalty earned " + oldLoyaltyEarned);
                response.customer_loyaltyPnts -= oldLoyaltyEarned;
            }
            if (rmPnts) {
                response.customer_loyaltyPnts -= rmPnts;
            }
            response.redeemMoney = saleEx.getLoyaltyAmt(response.customer_loyaltyPnts); //This variable (RedeemMoney) is showed in loyalty payments ui 
        }
    }

    function doesPaymentsCoverTotal(salesTotal) {

        var total_payments = 0;
        for (var index in salesControllerLib.get_payments()) {
            var payment = salesControllerLib.get_payments()[index];
            total_payments += payment.payment_amount;
        }

        if (salesControllerLib.get_mode() == 'sale' && (salesTotal - total_payments) > 1.0E-6) {
            return false;
        }
        return true;
    }

    /**
     *      setPrintAfterSaleRestApi
     */
    foo.setPrintAfterSale = function(requestData) {
        salesControllerLib.set_print_after_sale(requestData.sales_print_after_sale);
        return Promise.resolve({
            status: 'success'
        });
    }

    foo.cancel_saleRestApi = function() {
        salesControllerLib.clear_all();
        return prepareAndDispatchResponse();
    };

    function getPaymentsTotal(payments) {
        var total = 0;
        for (var i = 0; i < payments.length; i++) {
            if (payments[i].dp) {
                continue;
            }
            total += payments[i].payment_amount;
        }
        return total;
    }

    foo.completeReturn = function(requestData) {
        if (!requestData.employee_id) {
            requestData.employee_id = requestSession.user.name;
        }
        let invoiceCheckpointObj = commonLib.getCurrentCheckpoint(applicationSettings);
        requestData.invoiceCheckpoint = invoiceCheckpointObj.value;
        requestData.sReturnPrefix = invoiceCheckpointObj.sReturnPrefix;
        requestData.taxDetailed = {};
        requestData.taxNames = {};
        requestData.hsnTaxes = {};
        getTaxesByPercentageDetailed(requestData.items, requestData.taxDetailed, requestData.taxNames, requestData.hsnTaxes);
        // for (var q = 0; q < requestData.payments.length; q++) {
        //     if (requestData.payments[q].payment_type === 'Cash') {
        //         requestData.payments[q].returnAmt = 0;
        //     }
        // }
        let paymentsTotal = commonLib.getPaymentsTotal(requestData.payments);
        let changeDue = paymentsTotal - requestData.total;
        addChangeDue(requestData, changeDue);
        return salesControllerLib2.commitSaleReturn(requestData);
    };

    foo.suspendReturn = function(requestData) {
        return commonLib.suspendReturn(requestData);
    };

    foo.allSuspendedReturns = function() {
        return commonLib.getAllSuspendedReturns();
    };

    foo.unsuspendReturn = function(requestData) {
        return commonLib.unsuspendReturn(requestData);
    };
    /**
     * Quick sale : add payments + complete sale
     */

    foo.add_paymentRestApi = async function(paymentData, bEdit) {
        try {
            var payment_type = paymentData.payment_type;
            var thePaymentAmount = paymentData.amount_tendered;
            var thePaymentRefNo = paymentData.ref_no;
            if (!thePaymentAmount && thePaymentAmount !== 0) {
                throw "Enter amount to pay";

            }
            if (!payment_type) {
                throw "Select payment type";
            }
            var response = {};
            if (payment_type === 'Redeem') {
                if (bEdit) {
                    salesControllerLib.setRedeemMoney(thePaymentAmount);
                    salesControllerLib.add_payment(payment_type, thePaymentAmount);
                } else {
                    salesControllerLib.redeemLoyalty(payment_type, thePaymentAmount);
                }
                return prepareAndDispatchResponse(response);
            }
            if (salesControllerLib.add_payment(payment_type, thePaymentAmount, thePaymentRefNo)) {
                return prepareAndDispatchResponse(response);
            }
        } catch (error) {
            throw {
                'message': error
            };
        }
    };
    /**
     * Quick Payment
     */
    foo.quickSale = async function(quickParams) {
        try {
            var quickSaleParams = {
                payment_type: quickParams.payment_type,
                amount_tendered: quickParams.amount_tendered
            };
            let resp = await _self.add_paymentRestApi(quickSaleParams);
            var completeQuickParams = {
                comment: '',
                table_no: quickParams.table_no,
                order_no: quickParams.order_no,
                print_after_sale: quickParams.print_after_sale,
                timeStamp: quickParams.timeStamp
            };
            if (quickParams.bServerPush) {
                completeQuickParams.alienId = quickParams.alienId;
                completeQuickParams.bServerPush = quickParams.bServerPush;
            }
            if (quickParams.wcInfo) {
                completeQuickParams.wcInfo = quickParams.wcInfo;
            }
            if (quickParams.saleIdToEdit) {
                completeQuickParams.saleIdToEdit = quickParams.saleIdToEdit;
                completeQuickParams.invoiceCheckpoint = quickParams.invoiceCheckpoint;
                completeQuickParams.num = quickParams.num;
                completeQuickParams.prefix = quickParams.prefix;
            }
            if (quickParams.sq_id) {
                completeQuickParams.sq_id = quickParams.sq_id;
            }
            completeQuickParams.calledFromTakeaway = false;
            completeQuickParams.bSendSMS = quickParams.bSendSMS; // for always ask in enable sms
            completeQuickParams.purchaseOrderDoc = quickParams.purchaseOrderDoc;
            if (quickParams.bQuickOrder) {
                resp = await _self.completeTakeOrder(completeQuickParams);
            } else {
                completeQuickParams.calledFromTakeaway = true;
                resp = await _self.completeSaleRestApi(completeQuickParams);
            }
            return resp;

        } catch (e) {
            logger.error(e);
            return e;
        }

    }

    /**
     *      Todo: There is a problem with amount change and customer details
     */

    foo.completeSaleRestApi = async function(requestData) {
        if (requestData.print_after_sale != undefined) {
            salesControllerLib.set_print_after_sale(requestData.print_after_sale);
        }
        requestData = requestData ? requestData : {};
        if (!requestData.wcInfo) {
            requestData.wcInfo = salesControllerLib.getWCInfo();
        }
        let payments = salesControllerLib.get_payments();
        if (!payments.length) {
            salesControllerLib.set_payments([{
                payment_type: 'Cash',
                payment_amount: 0

            }]);
        }
        if (requestData.item_id) {
            //Petrol Bunk
            salesControllerLib.clear_all();
            requestData.item = requestData.item_id;
            await _self.additemRestApi(requestData);
            if (requestData.discounted_total) {
                await _self.add_paymentRestApi({
                    payment_type: 'Cash',
                    amount_tendered: requestData.discounted_total
                });
            }
        }

        var editSaleId = requestData.saleIdToEdit ? requestData.saleIdToEdit : null;
        let saleNum = requestData.num ? requestData.num : null;
        let invoiceCheckpointObj = commonLib.getCurrentCheckpoint(applicationSettings);
        let invoiceCheckpoint = requestData.invoiceCheckpoint ? requestData.invoiceCheckpoint : invoiceCheckpointObj.value;
        let invoicePrefix = requestData.prefix ? requestData.prefix : invoiceCheckpointObj.prefix;

        let comment = requestData ? requestData.comment : '';
        if (comment) {
            salesControllerLib.set_comment(comment);
        }
        let state_name = requestData ? requestData.state_name : '';
        var response = {};

        //Because we don't want to include global discount in cart
        await salesControllerLib.computeCart(1, 0);
        response.cart = CLONE(salesControllerLib.get_cart());
        response.discount = salesControllerLib.get_discount();
        response.totalNoSpotDiscount = salesControllerLib.get_total();
        if (requestSession.gDiscountValue) {
            await salesControllerLib.computeCart();
        }
        let onlyDiscount = salesControllerLib.get_discount();
        let total = salesControllerLib.get_total(response);

        let totalBeforeDeliveryCharge = total;
        let deliveryCharge = salesControllerLib.getDeliveryCharge();
        let bHomeDelivery = salesControllerLib.getOrderFromHD();
        let bSalesOrder = salesControllerLib.getBSalesOrder();
        let tableNo = salesControllerLib.getTableNo();

        deliveryCharge = deliveryCharge ? deliveryCharge : 0;
        let totalAfterDeliveryCharge = totalBeforeDeliveryCharge + deliveryCharge;
        total = totalAfterDeliveryCharge;
        response.deliveryCharge = +utils.roundOffNumber(deliveryCharge, applicationSettings);
        response.bHomeDelivery = bHomeDelivery;
        response.bSalesOrder = bSalesOrder;
        response.total = +utils.roundOffNumber(total, applicationSettings);

        if (requestSession.discountMethod === 'onTaxable') {
            response.discount = onlyDiscount;
        } else {
            response.discount += response.totalNoSpotDiscount - totalBeforeDeliveryCharge;
        }
        response.bLocalTax = requestSession.settings.sales.bLocalTax;
        var taxes = get_taxes(response.cart, true, requestSession);
        var taxesWithpercentages = getTaxesByPercentage(response.cart, requestSession);
        response.charges = salesControllerLib.getAllCharges(response.cart);
        var amount_due = salesControllerLib.get_amount_due();

        let timeStamp;
        let checkNo;
        let shippingAddress;

        if (requestData) {
            if (requestData.timeStamp) {
                var curTime = new Date();
                timeStamp = new Date(requestData.timeStamp);
                timeStamp.setSeconds(curTime.getSeconds());
                timeStamp = timeStamp.toISOString();
            }
            checkNo = requestData.chequeNo;
            if (requestData.shippingDetails || requestData.state_name) {
                state_name = requestData.state_name;
                shippingAddress = requestData.shippingDetails;
                response.shippingAddress = shippingAddress;
                response.state_name = state_name;
            }
        }
        response.taxesWithPercents = taxesWithpercentages;
        response.taxDetailed = {};
        response.taxNames = {};
        response.hsnTaxes = {};
        // get taxDetailed and taxNames
        getTaxesByPercentageDetailed(salesControllerLib.get_cart(), response.taxDetailed, response.taxNames, response.hsnTaxes);
        if (requestData.chequeNo) {
            response.cheQueNo = requestData.chequeNo;
        }
        if (requestData.vehicle_phNo) {
            response.vehicle_phNo = requestData.vehicle_phNo;
        }
        if (requestData.vehicleNo) {
            response.vehicleNo = requestData.vehicleNo;
        }
        response.taxes = taxes;
        response.totalTax = salesControllerLib.getTaxAmt(taxes);
        // if (response.totalTax) {
        response.taxes.Total = response.totalTax;
        // }
        response.total = +utils.roundOffNumber(total, applicationSettings);
        response.payments = salesControllerLib.get_payments();
        response.saleOnCreditAmt = getSaleOnCreditAmt(response.payments);

        response.amount_due = amount_due;

        response.totalQuantity = salesControllerLib.calculateQuantity(response.cart);
        response.subtotal = salesControllerLib.get_subtotal(true);

        response.discounted_subtotal = salesControllerLib.get_subtotal(true);

        response.totalWithoutTax = (onlyDiscount + response.discounted_subtotal);

        response.tax_exclusive_subtotal = salesControllerLib.get_subtotal(true);
        response.cost = salesControllerLib.get_cost(response.cart);
        response.profit = salesControllerLib.get_profit(response.subtotal, response.cost);
        response.quantity = salesControllerLib.get_quantity(response.cart);
        response.receipt_title = 'Sales Receipt';

        response.comments = salesControllerLib.get_comment();
        response.amount_change = amount_due * -1;
        response.employee = requestSession.user.first_name + ' ' + requestSession.user.last_name;
        let salesEmployeeName = requestSession.user.name;
        let salesEmployee = salesControllerLib.getCartEmployeeDetails();
        if (salesEmployee) {
            response.employee = salesEmployee.first_name + ' ' + salesEmployee.last_name;
            salesEmployeeName = salesEmployee.name;
        }
        response.company_info = {
            0: applicationSettings.ownersInfo.address,
            1: applicationSettings.ownersInfo.phone,
            2: applicationSettings.ownersInfo.account_number,
            3: applicationSettings.ownersInfo.company
        };
        response.company_address = applicationSettings.ownersInfo.address;
        response.company_phone = applicationSettings.ownersInfo.phone;
        response.company_account = applicationSettings.ownersInfo.account_number;
        response.company_name = applicationSettings.ownersInfo.company;
        response.globalDiscountInfo = await salesControllerLib.getGlobalDiscountInfo();

        var customerInfo = salesControllerLib.getCartCustomerDetails();
        if (customerInfo && customerInfo.alienId) { // if customer has alienId, set in requestData
            requestData.bServerPush = true;
            requestData.alienId = customerInfo.alienId;
        }
        if (customerInfo.person_id !== null) {
            if (customerInfo.company_name) {
                response.customer_compnay_name = customerInfo.company_name;
            }
            response.customer = customerInfo.first_name;
            if (customerInfo.last_name) {
                response.customer += ' ' + customerInfo.last_name;
            }

            if (!state_name) {
                state_name = customerInfo.state_name;
            }

            response.customer_id = customerInfo.person_id;

            response.customer_address = customerInfo.address_1;
            response.customer_location = customerInfo.zip + ' ' + customerInfo.city;
            response.account_number = customerInfo.account_number;
            response.customerGSTIN = customerInfo.gstin_number;
            response.phone_number = customerInfo.phone_number;
            response.customer_email = customerInfo.email;
            response.city = customerInfo.city_name;
            response.pincode = customerInfo.pin_code;
            response.customer_email = customerInfo.email;
            response.credit_balance = customerInfo.credit_balance >= 1 ? customerInfo.credit_balance : 0;
            response.CustomInput = customerInfo.CustomInput;
            if (editSaleId) {
                response.credit_balance = salesControllerLib.getCreditBalance();
            }

            response.customer_info = {
                0: response.customer,
                1: customerInfo.address_1,
                2: customerInfo.zip + ' ' + customerInfo.city,
                3: customerInfo.account_number,
                4: customerInfo.gstin_number,
                5: customerInfo.phone_number,
                6: customerInfo.customer_email

            };
        } else if (requestData.wcInfo) {
            let customerRequestData = {};
            let wcData = requestData.wcInfo;
            let name = requestData.wcInfo.name;
            let phone_number = requestData.wcInfo.phone_number;

            if (wcData.invoiceCustomerNumber) {
                name = wcData.invoiceCustomerName;
                phone_number = wcData.invoiceCustomerNumber;
                requestData.wcInfo.phone_number = phone_number;
            }

            response.customer = name;
            response.phone_number = phone_number;

            if (!phone_number && requestData.alienId) {
                phone_number = requestData.alienId;
                requestData.wcInfo.phone_number = phone_number;
            }
            if (phone_number) {
                if (!name) {
                    name = phone_number;
                }
                requestData.wcInfo.bWC = true;
                requestData.wcInfo.type = 'customer_';
                requestData.wcInfo.first_name = name;
                requestData.wcInfo.last_name = ' ';

                if (wcData.invoiceCustomerNumber) {
                    let keyArr = ['bWC', 'first_name', 'last_name', 'phone_number', 'type', 'address_1', 'city_name', 'pin_code'];
                    let keyComingObject = ['bWC', 'first_name', 'last_name', 'invoiceCustomerNumber', 'type', 'invoiceCustomerAddress', 'invoiceCustomerCity', 'invoiceCustomerPincode'];
                    for (var i = 0; i < keyArr.length; i++) {
                        customerRequestData[keyArr[i]] = requestData.wcInfo[keyComingObject[i]];
                    }
                } else {
                    customerRequestData = requestData.wcInfo;
                }
                customerRequestData.alienId = requestData.alienId ? requestData.alienId : '';
                if (customerRequestData.alienId) {
                    customerRequestData.nickName = name;
                }
                delete requestData.wcInfo.name; // to maintain consistency with ui form create customer
                try {
                    let resp = await customerCntrller.create(customerRequestData);
                    response.customer_id = resp.data.id;
                    response.customer = resp.data.name;
                    response.phone_number = resp.data.phone_number;
                    response.alienId = resp.data.alienId;
                    response.customer_info = {
                        0: response.customer,
                        1: customerInfo.phone_number
                    };
                    customerInfo.person_id = resp.data.id;
                } catch (err) {
                    logger.info('walkin customer create fail ' + requestData.wcInfo.first_name + ' ' + requestData.wcInfo.phone_number);
                }
            }

        } else {
            response.customer = '';
        }

        if ((requestData.purchaseOrderDoc && requestData.purchaseOrderDoc._id && (requestData.purchaseOrderDoc.customerId !== customerInfo.person_id))) {
            throw 'No Customer Selected for Purchase Order';
        }

        if (requestData.wcInfo) {
            if (requestData.wcInfo.invoiceCustomerName) {
                response.customer = requestData.wcInfo.invoiceCustomerName;
                response.phone_number = requestData.wcInfo.invoiceCustomerNumber;
            }
            response.customer_address = requestData.wcInfo.invoiceCustomerAddress;
            response.city = requestData.wcInfo.invoiceCustomerCity;
            response.pincode = requestData.wcInfo.invoiceCustomerPincode;
        };

        let completeDocData = await salesControllerLib.getHDIdRev();
        if (response.bHomeDelivery) {
            response.deliveryBoy = salesControllerLib.getDeliveryBoy();
            response.order_no = completeDocData._id;
        }

        if (response.bSalesOrder) {
            response.order_no = completeDocData._id;
        }

        response.orderStatus = completeDocData.orderStatus;
        getTotalMRPValue(response);

        response.globalDiscountInfo.discountMethod = applicationSettings.salesConfig.discountMethod;
        response.table_no = (requestData.table_no) ? requestData.table_no : tableNo;
        response.tableNo = response.table_no;
        //response.cart is not used below because it doesn't have globalDiscountPercent
        let params1 = {};
        params1.items = salesControllerLib.get_cart();
        params1.customer_id = customerInfo.person_id;
        params1.employee_id = requestSession.user.name;
        params1.salesEmployeeName = salesEmployeeName;
        params1.timeStamp = timeStamp;
        params1.checkNo = checkNo;
        params1.state_name = state_name;
        params1.roundOffMethod = applicationSettings.numberFormat.roundOffMethod;
        params1.wcInfo = requestData.wcInfo;
        params1.shippingAddress = shippingAddress;
        params1.editSaleId = requestData.saleIdToEdit;
        params1.invoiceCheckpoint = invoiceCheckpoint;
        params1.iPrefix = invoicePrefix;
        params1.saleNum = saleNum;
        params1.discount = response.discount;
        params1.t_no = response.t_no;
        let actual_total = response.total;
        if (deliveryCharge) {
            logger.info('*** completeSale : delivery charge doesnot get loyalty ' + deliveryCharge);
            actual_total -= deliveryCharge;
        }
        let earnOnCredit = saleEx.earnOnCredit();
        if (!earnOnCredit && response.saleOnCreditAmt) {
            actual_total -= response.saleOnCreditAmt;
        }
        calculateLoyalty(params1, actual_total);
        params1.order_no = response.id;
        params1.vehicle_phNo = response.vehicle_phNo;
        params1.vehicleNo = response.vehicleNo;
        params1.invoice_no = requestData.invoice_no;
        if (customerInfo && customerInfo.alienId) { // if customer has alienId, set in requestData
            requestData.bServerPush = applicationSettings.customerApp.bServerPush;
            requestData.alienId = customerInfo.alienId;
        }
        salesControllerLib.setAlienDoc(params1, requestData); // set if alienId available

        //preserving change due to avoid conflicts in payments total
        addChangeDue(response, response.amount_change);

        let requiredFields = ['payments', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'saleOnCreditAmt', 'globalDiscountInfo', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'order_no'];
        let requiredFields2 = ['comments', 'customerGSTIN', 'table_no'];
        let mappedFields = ['comment', 'GSTIN', 'tableNo'];
        for (let i = 0; i < requiredFields.length; i++) {
            params1[requiredFields[i]] = response[requiredFields[i]];
        }
        for (let i = 0; i < requiredFields2.length; i++) {
            params1[mappedFields[i]] = response[requiredFields2[i]];
        }

        if (requestData.calledFromTakeaway) {
            params1.calledFromTakeaway = requestData.calledFromTakeaway;
            params1.resetTime = applicationSettings.resetInfo.resetTime;
        }
        if (requestData.purchaseOrderDoc && requestData.purchaseOrderDoc.id) {
            params1.purchaseOrderDocId = requestData.purchaseOrderDoc.id;
        }
        let saleResponse = await salesControllerLib.commitSale(params1);
        let saleTemp = Object.assign(saleResponse, response);

        saleTemp.bSendSMS = requestData.bSendSMS;
        commonLibEx.sendSMSafterSale(applicationSettings, saleTemp).catch(function(e) {
            logger.info('Caught error from completeSaleRestApi', e);
        });

        response.sale_id = requestData.invoice_no ? requestData.prefix + requestData.invoice_no : invoicePrefix + (saleResponse.num ? saleResponse.num : saleResponse.sale_id);
        response.id = saleResponse.sale_id;
        response.t_no = saleResponse.t_no;
        delete response.taxes.Total;
        // response.transaction_time = saleResponse.timeStamp;
        response.transaction_time = moment(saleResponse.timeStamp).format(applicationSettings.dateTime.dateformat +
            ' ' + applicationSettings.dateTime.timeformat);

        response.transaction_date = moment(saleResponse.timeStamp).format(applicationSettings.dateTime.dateformat);

        //send SMS
        /* TODO
            1. add counter for SMS to track usage per client
            2. Mechanism to restrict setting change by end user
        */

        response.print_after_sale = salesControllerLib.is_print_after_sale();
        salesControllerLib.clear_all();

        if (requestData.purchaseOrderDoc && requestData.purchaseOrderDoc.id) {
            let statusToUpdate = 'READY TO PICK-UP';
            if (requestData.purchaseOrderDoc.value[7] == 'homeDelivery') {
                statusToUpdate = 'DISPATCHED'
            }
            alienSaleSchedular.setPurchaseOrderStatusAndReference(requestData.purchaseOrderDoc.id, statusToUpdate, saleResponse.sale_id, applicationSettings);
        }

        if (response.sale_id == 'POS -1') {
            response.error_message = 'Sales Transactions Failed';
            throw response;
        } else {
            response.discount = +response.discount.toFixed(2);
            response.total = total;

            if (!requestData.item_id && requestData.print_after_sale) {
                //Petrol Bunk
                response.print_after_sale = requestData.print_after_sale;
                if (requestSession.clientType === 'MobileApp' && !applicationSettings.cloudPrintOnMobile) {
                    if (applicationSettings.kotPrinter.printKOTByDefault && requestData.calledFromTakeaway) {
                        let kotOrderInfoJson4Couch = {
                            'order_no': -1,
                            'kotInfo': {}
                        };
                        kotOrderInfoJson4Couch.order_no = response.sale_id;
                        kotOrderInfoJson4Couch.user = response.employee;
                        kotOrderInfoJson4Couch.kotInfo.customer_id = response.customer_id;
                        kotOrderInfoJson4Couch.kotInfo.sale_id = response.sale_id;
                        kotOrderInfoJson4Couch.kotInfo.sale_time = response.transaction_time;
                        kotOrderInfoJson4Couch.kotInfo.kot_items = response.cart;
                        utils.sendSocketEvent('printKotReceipt', kotOrderInfoJson4Couch);
                    }
                    utils.sendSocketEvent('printSalesReceipt', response);
                }
            }
            if (tableNo) {
                await editOrderFromReports(tableNo, response);
            }
            alienSaleSchedular.syncSale(applicationSettings); // dont wait for this

            if (response.sale_id && requestData.sq_id) {
                let sqDoc = await couchDBUtils.getDoc(requestData.sq_id, mainDBInstance);
                sqDoc.orderStatus = 'C2Sales';
                resp = await couchDBUtils.createOrUpdate(sqDoc, mainDBInstance, 3, 'Save Quotation Failed');
                response.salesQuat_id = requestData.sq_id;
            }
            return response;
        }

    };

    function calculateLoyalty(params1, actual_total) {
        // Loyalty starts here by Linto
        let redeemMoney = salesControllerLib.getRedeemMoney();
        let rmPnts = 0;
        if (redeemMoney) {
            actual_total -= redeemMoney;
            rmPnts = saleEx.convertAmtToPnts(redeemMoney);
        }
        params1.loyaltyPnts = saleEx.getLoyaltyPnts(actual_total);
        params1.rmPnts = rmPnts; //to be saved in sales doc
        params1.loyaltyEarned = params1.loyaltyPnts; // to be saved in sales doc

        logger.info("*** completeSale : loyaltyPnts : " + params1.loyaltyPnts);
        logger.info("*** completeSale : redeemed pnts : " + rmPnts);
        let oldCustomer = salesControllerLib.compareCustomer();
        let oldLoyaltyRedeemed = salesControllerLib.getLoyaltyRedeemed();
        if (oldCustomer && oldLoyaltyRedeemed) {
            logger.info("*** completeSale : Edit sale old redeemed: " + oldLoyaltyRedeemed);
            rmPnts -= oldLoyaltyRedeemed;
        }
        let oldLoyaltyEarned = salesControllerLib.getLoyaltyEarned();
        if (oldCustomer && oldLoyaltyEarned) {
            params1.loyaltyPnts -= oldLoyaltyEarned;
            logger.info("*** completeSale : Edit sale old earned: " + oldLoyaltyEarned);
        }
        params1.loyaltyPnts -= rmPnts; // removing the loyalty from customer
        logger.info("*** completeSale : final loyalty : " + params1.loyaltyPnts);
    }

    function addChangeDue(response, amount_change) {
        bCashPaymentExists = false;
        cashPIndex = -1;
        for (var p = 0; p < response.payments.length; p++) {
            if (response.payments[p].payment_type === 'Cash') {
                bCashPaymentExists = true;
                cashPIndex = p;
            }
        }
        if (bCashPaymentExists) {
            response.payments[cashPIndex].returnAmt = amount_change;
        } else {
            if (response.payments.length > 1) {
                if (response.payments[0].payment_type !== 'Sale on credit') {
                    response.payments[0].returnAmt = amount_change;

                } else {
                    response.payments[1].returnAmt = amount_change;

                }
            } else if (response.payments.length === 1) {
                if (response.payments[0].payment_type !== 'Sale on credit') {
                    response.payments[0].returnAmt = amount_change;

                } else {
                    response.payments[0].payment_amount -= amount_change;
                    response.pending_amount -= amount_change;
                }
            }
        }
    }

    /**
      edit Kot from Reports
        */
    async function editOrderFromReports(tableNo, response) {
        try {
            var id = 't_table_' + tableNo + '_' + response.id;
            let checkoutOrder = await couchDBUtils.getDoc(id, mainDBInstance);
            let order = checkoutOrder.order;
            let sale_id = new Date(response.transaction_time).getTime();
            order.invoice_time = response.transaction_time;
            delete order.Kots;
            order.Kots = [{
                sale_time: response.transaction_time,
                sale_id: sale_id,
                customer_id: response.customer_id,
                KOT_bill: response.subtotal,
            }];
            order.Kots[0].kot_items = [];
            for (let i = 0; i < response.cart.length; i++) {
                let itemDescrib = {
                    item_id: response.cart[i].item_id,
                    item_total: response.cart[i].total,
                    item_unit_price: response.cart[i].sellingPriceExcludingTax,
                    name: response.cart[i].name,
                    quantity_purchased: response.cart[i].quantity
                }
                order.Kots[0].kot_items.push(itemDescrib);
            }
            await couchDBUtils.update(checkoutOrder, mainDBInstance);
        } catch (err) {
            logger.info('Edit KOT From Report Fail');
        }
    }

    /**
     * suspendSaleRestApi
     * Todo: 
     *      create lang files
     *      loggedInEmployeeId
     *      check front end and remove unused variables/calculations and comments
     *      prepareAndDispatchResponse is not required 
     * 
     */
    foo.suspendSale = function() {
        var employeeId = 1;
        var salesEmployee = salesControllerLib.getCartEmployeeDetails();
        let customerInfo = salesControllerLib.getCartCustomerDetails();
        var cart = salesControllerLib.get_cart();
        var comment = salesControllerLib.get_comment();
        var invoice_number = salesControllerLib.get_invoice_number();
        var payments = salesControllerLib.get_payments();
        if (salesEmployee) {
            var employee = salesEmployee.first_name + ' ' + salesEmployee.last_name;
        } else {
            var employee = requestSession.user.first_name + requestSession.user.last_name;
        }
        let invoiceCheckpointObj = commonLib.getCurrentCheckpoint(applicationSettings);
        return suspendSalesLib.saveSuspendSaleExt(cart, customerInfo.person_id, customerInfo.first_name + ' ' + customerInfo.last_name, employee, requestSession.user.name, comment, invoice_number, payments).then(function(resp) {
            var response = {};
            if (resp.sale_id == -1) {
                response.error_message = 'suspend sales failed';
            } else {
                response.sale_id = resp.sale_id;
                salesControllerLib.clear_all();
                response.success = 'sales_successfully_suspended_sale. ' + invoiceCheckpointObj.prefix + resp.sale_id.toString();
            }
            return prepareAndDispatchResponse(response);
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.unsuspendSale = function(requestData) {
        var saleId = requestData.suspended_sale_id;
        salesControllerLib.clear_all();
        return salesControllerLib.copy_entire_suspended_sale(saleId).then(function() {
            return suspendSalesLib.deleteExt(saleId);
        }).then(function(resp) {
            return prepareAndDispatchResponse();
        }).catch(function(err) {
            salesControllerLib.clear_all();
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.deleteSuspendedSale = async function(requestData) {
        var saleId = 'suspendedSale_' + requestData.suspended_sale_id;
        salesControllerLib.clear_all();
        let saleDoc = await couchDBUtils.getDoc(saleId, mainDBInstance, "could not fetch sale document");
        let resp = await couchDBUtils.delete(saleDoc, mainDBInstance, 3, "Failed to delete suspended sale");
        return resp;
    }

    /**
     *  allSuspendedSalesRestApi
     *      Todo: return structure changed
     */

    foo.allSuspendedSales = function() {
        return suspendSalesLib.getAll();
    };

    /**
     *    getSalesRestApi    
     *    see if the below call can be optimized, should it be called everytime
     *    calling updateSalesProfileSettings, to see if any changes to taxes have been made 
     */
    foo.getSales = async function() {
        await salesControllerLib.updateSalesProfileSettings();
        return prepareAndDispatchResponse();
    };

    foo.setLocalTax = async function(requestData) {
        await salesControllerLib.setLocalTax(requestData.bLocalTax);
        return prepareAndDispatchResponse();
    };

    /**
     *      delete_paymentRestApi
     */
    foo.deletePayment = function(requestData) {
        salesControllerLib.delete_payment(requestData.payment_id);
        return prepareAndDispatchResponse();
    };

    /**
     *      setInvoiceNumberEnabledRestApi
     */
    foo.setInvoiceNumberEnabled = function(requestData) {
        salesControllerLib.set_invoice_number_enabled(requestData.sales_invoice_number_enabled);
        return Promise.resolve({
            status: status.SUCCESS
        });
    };

    /**
     *      changeModeRestApi
     *      Todo: handle different sales locations
     */
    foo.changeMode = function(requestData) {
        salesControllerLib.set_mode(requestData.mode);
        return _self.cancel_saleRestApi();
    };

    /**
     *      saveTableOrderRestApi      
     *      Todo: if error, act on the error. Currently just sending error
     *      Todo: kot print     
     *      Todo: prepareAndDispatchResponse is not required
     *      Todo: if edit kot, delete suspendedsale item also
     */
    foo.saveTableOrder = function(requestData) {
        var response = {};
        response.status = status.ERR_UNDEFINED;

        var orderInfoJson4Couch = {};
        var kotOrderInfoJson4Couch = {
            'order_no': -1,
            'kotInfo': {}
        };

        var propsJson = {};

        var tableNo = requestData.table_no;
        var orderNo = requestData.order_no;
        var bNewOrder = requestData.isNewOrder;
        var employee = requestSession.user.first_name + requestSession.user.last_name;
        var salesEmployeeName = requestSession.user.name;
        var salesEmployee = salesControllerLib.getCartEmployeeDetails();
        if (salesEmployee) {
            employee = salesEmployee.first_name + ' ' + salesEmployee.last_name;
            salesEmployeeName = salesEmployee.name;
        }
        var deleteKotParams = {
            'order_no': orderNo,
            'kotInfo': {
                'saleId': requestData.sales_id4kot
            }
        };
        if (requestData.deleteKOT) {
            return couchDBUtils.deleteKot(tableNo, deleteKotParams, mainDBInstance).then(function(resp) {

                var params = {
                    table_no: tableNo,
                    order_no: orderNo
                }
                if (requestData.noOfKos === 1) {
                    return _self.cancelOrder(params).then(function(resp) {
                        return resp;
                    });
                } else {
                    return resp;
                }

            }).catch(function(error) {
                logger.error(error);
                return error;
            })
        }
        if (bNewOrder === true) {
            propsJson.maxOrderNo = _self.getMaxOrderNo({
                table_no: tableNo
            });
        }

        if (requestData.isItEditKot === true) {
            var oldSaleId = requestData.sales_id4kot;
            if (!utils.isUndefinedOrNull(oldSaleId)) {
                propsJson.deleteSuspendedItems = suspendSalesLib.deleteExt(oldSaleId);
                propsJson.deleteKotCouch = couchDBUtils.deleteKot(tableNo, deleteKotParams, mainDBInstance)
            } else {
                logger.error('editkot:: old sale id is null');
            }
        }

        return BPromise.props(propsJson).then(async function(respJson) {
            if (!utils.isUndefinedOrNull(respJson.maxOrderNo)) {
                orderNo = respJson.maxOrderNo.order_no;
            }
            if (utils.isUndefinedOrNull(orderNo)) {
                throw {
                    status: status.ERR_UNDEFINED,
                    status: 'order no is not defined'
                };
            }

            var employeeId = 1; //Todo: get proper employee id       
            var customerId = salesControllerLib.get_customer();
            var cart = salesControllerLib.get_cart();
            var comment = salesControllerLib.get_comment();
            var invoice_number = salesControllerLib.get_invoice_number();
            var payments = salesControllerLib.get_payments();

            var customerInfo = salesControllerLib.getCartCustomerDetails();
            var customer = "";
            if (customerInfo.person_id !== null) {
                customer = customerInfo.first_name + ' ' + customerInfo.last_name;
            } else if (requestData.wcInfo) {
                let name = requestData.wcInfo.name;
                let phone_number = requestData.wcInfo.phone_number;
                if (phone_number) {
                    if (!name) {
                        name = phone_number;
                    }
                    requestData.wcInfo.bWC = true;
                    requestData.wcInfo.type = 'customer_';
                    requestData.wcInfo.first_name = name;
                    requestData.wcInfo.last_name = ' ';
                    delete requestData.wcInfo.name; // to maintain consistency with ui form create customer
                    customer = requestData.wcInfo.first_name + ' ' + requestData.wcInfo.last_name;
                    try {
                        let resp = await customerCntrller.createCustomerIfNotExists(requestData.wcInfo);
                        customerId = resp;

                    } catch (err) {
                        logger.info('walkin customer create fail ' + requestData.wcInfo.first_name + ' ' + requestData.wcInfo.phone_number);
                    }
                }

            }
            kotOrderInfoJson4Couch.order_no = orderNo;

            //Todo: sale_time should be same for sql and couch
            var sale_time = requestData.kotSaleTime ? moment(requestData.kotSaleTime).format('YYYY-MM-DD HH:mm:ss') : moment().format('YYYY-MM-DD HH:mm:ss');
            var isKOT = true;
            kotOrderInfoJson4Couch.kotInfo = suspendSalesLib.getJson4Couch(sale_time, customerId, cart);

            return suspendSalesLib.saveSuspendSaleExt(cart, customerId, customer, employee, salesEmployeeName, comment, invoice_number, payments, requestData.kotSaleTime, isKOT);
        }).then(function(resp) {
            var saleId = resp.sale_id;
            if (saleId === -1) {
                return Promise.resolve(response);
            }

            response.status = status.SUCCESS;
            kotOrderInfoJson4Couch.kotInfo.sale_id = saleId;

            var propsJson2 = {};

            if (bNewOrder) {
                var guests = requestData.guests;
                var orderDesc = requestData.order_desc;
                var reservationId = requestData.reservation_id;
                orderInfoJson4Couch = {
                    'order_no': orderNo,
                    'guests': guests,
                    'order_desc': orderDesc,
                    'parent_order_no': -1,
                    'reservation_id': reservationId === undefined ? 0 : reservationId,
                    'Kots': []
                };
            }

            return BPromise.props(propsJson2);
        }).then(function() {
            //couchdb sync            
            if (bNewOrder) {
                return couchDBUtils.addOrder(tableNo, orderInfoJson4Couch, mainDBInstance).then(function(resp) {
                    return couchDBUtils.addKot(tableNo, kotOrderInfoJson4Couch, mainDBInstance);
                });
            } else {
                return couchDBUtils.addKot(tableNo, kotOrderInfoJson4Couch, mainDBInstance);
            }
        }).then(function() {
            if (response.status === status.SUCCESS) {
                kotOrderInfoJson4Couch.user = employee;
                kotOrderInfoJson4Couch.tableNo = tableNo;
                if (requestSession.clientType === 'MobileApp' && !applicationSettings.cloudPrintOnMobile) {
                    utils.sendSocketEvent('printKotReceipt', kotOrderInfoJson4Couch);
                }
                response.kotPrintInfo = kotOrderInfoJson4Couch;
                salesControllerLib.clear_all();
            }
            return prepareAndDispatchResponse(response);
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    /**
     * more fields have to be set and loaded here
     * like address, employee
     * @param {*} data 
     */
    foo.loadHDOrder = async function(params) {
        let response = {};
        salesControllerLib.clear_all();
        let data = await couchDBUtils.getDoc(params._id, mainDBInstance);
        try {
            for (let i = 0; i < data.sale_items.length; i++) {
                await salesControllerLib.addSuspendedItem2Cart(data.sale_items[i]);
            }

            if (data.sales_info.customer_id) {
                await salesControllerLib.set_customer(data.sales_info.customer_id);
                let cust_info = await couchDBUtils.getDoc('customer_' + data.sales_info.customer_id, mainDBInstance);
                if (cust_info && cust_info.state_name && applicationSettings.ownersInfo.state != cust_info.state_name) {
                    await salesControllerLib.setLocalTax(false);
                }
            }
            await salesControllerLib.setCartEmployeeDetails(data.sales_info.employee_id);

            if (data.sales_info.wcInfo) {
                await salesControllerLib.setWCInfo(data.sales_info.wcInfo);
            }

            if (data.sales_info.bHomeDelivery) {
                salesControllerLib.setOrderFromHD(data.sales_info.bHomeDelivery);
                salesControllerLib.setDeliveryCharge(data.sales_info.deliveryCharge);
                salesControllerLib.setDeliveryBoy(data.deliveryBoy);
            }

            if (data.sales_info.globalDiscountInfo) {
                data.sales_info.globalDiscountInfo.value = data.sales_info.globalDiscountInfo.percent;
                data.sales_info.globalDiscountInfo.bPercent = true;
                await _self.setGlobalDiscount(data.sales_info.globalDiscountInfo);
            }
            let temParamFields = ['wcInfo', 'sale_time'];
            var tempParams = {};
            for (var i = 0; i < temParamFields.length; i++) {
                tempParams[temParamFields[i]] = data.sales_info[temParamFields[i]];
            }
            salesControllerLib.setTempDetails(tempParams);
            salesControllerLib.setHDIdRev(data);

        } catch (error) {
            salesControllerLib.clear_all();
            response.warning = 'Failed to load order';
        } finally {
            return prepareAndDispatchResponse(response);
        }
    };

    foo.quickHDOrder = async function(doc) {
        await _self.loadHDOrder(doc);
        await _self.add_paymentRestApi(doc.payments[0]);
        return _self.completeHDOrder({});
    };

    foo.completeHDOrder = async function(param) {
        let saleData = await _self.saveHDOrder(undefined, true);
        try {
            let response = await _self.completeSaleRestApi(param);
            return response;
        } catch (err) {
            salesControllerLib.clear_all();
            throw "Failed to complete order";
        }
    };

    foo.saveHDOrder = async function(doc, bCompleted) {
        let response;
        if (!doc || !doc._id) {
            //Complete HD Order
            //Save Order
            let wcInfo = doc ? doc.wcInfo : undefined;
            let prevDoc = salesControllerLib.getHDIdRev();

            let deliveryCharge = 0
            let bHomeDelivery;
            if (doc) {
                deliveryCharge = doc.deliveryCharge;
                bHomeDelivery = doc.bHomeDelivery;
                salesControllerLib.setDeliveryCharge(deliveryCharge);
                salesControllerLib.setOrderFromHD(bHomeDelivery);
            }

            let bNewOrder = false;
            let _id = prevDoc._id;
            if (!_id) {
                _id = 'hd_' + (++maxHDOrderNo);
                bNewOrder = true;
            }

            let customerId = salesControllerLib.get_customer();
            let cart = salesControllerLib.get_cart();
            let comment = salesControllerLib.get_comment();
            let employee = salesControllerLib.getCartEmployeeDetails();

            let customerInfo = salesControllerLib.getCartCustomerDetails();
            let customer = customerInfo.person_id ? customerInfo.first_name + ' ' + customerInfo.last_name : "";

            //Todo: sale_time should be same for sql and couch
            let timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
            if (wcInfo) {
                salesControllerLib.setWCInfo(wcInfo);
            };

            response = await prepareAndDispatchResponse();

            doc = {
                _id: _id,
                sales_info: {
                    globalDiscountInfo: response.globalDiscountInfo,
                    sale_time: timestamp,
                    customer_id: customerId,
                    customer: customer,
                    employee_id: employee.name, //ohdtodo
                    employee: employee.name,
                    comment: comment,
                    total: response.total,
                    sale_id: undefined,
                    wcInfo: wcInfo,
                    deliveryCharge: deliveryCharge,
                    bHomeDelivery: bHomeDelivery
                },
                sale_items: suspendSalesLib.getCartItems(cart),
                payments: []
            }

            if (bNewOrder) { // new order
                doc.id = maxHDOrderNo;
                doc.timestamp = moment().format('x');
                doc.orderStatus = 'Order Received';
            } else {
                doc._rev = prevDoc._rev;
                doc.id = prevDoc.id;
                doc.timestamp = prevDoc.timestamp;
                doc.orderStatus = prevDoc.orderStatus;
            }
        } else {
            //Update Status
            response = await prepareAndDispatchResponse();
        }

        if (bCompleted) {
            doc.orderStatus = 'completed';
        }

        await couchDBUtils.createOrUpdate(doc, mainDBInstance, 3, 'Save Order Failed');
        var respForSMS = CLONE(response);
        respForSMS._id = 'hd_' + doc.id;
        respForSMS.orderStatus = doc.orderStatus;
        if (doc.sales_info.wcInfo && doc.sales_info.wcInfo.invoiceCustomerNumber)
            respForSMS.phone_number = doc.sales_info.wcInfo.invoiceCustomerNumber;
        commonLibEx.sendSMSafterSale(applicationSettings, respForSMS).catch(function(e) {
            logger.info('Caught error from saveHDOrder', e);
        });
        if (!bCompleted) {
            salesControllerLib.clear_all();
        }

        if (!response._id) {
            response._id = respForSMS._id
        }
        return response;
    };

    foo.printHDOrder = async function(data) {
        let resp = CLONE(await _self.loadHDOrder(data));
        resp.totalQuantity = salesControllerLib.calculateQuantity(resp.cart);
        salesControllerLib.clear_all();
        resp.taxDetailed = {};
        resp.taxNames = {};
        resp.hsnTaxes = {};
        getTaxesByPercentageDetailed(resp.cart, resp.taxDetailed, resp.taxNames, resp.hsnTaxes);
        var taxesWithpercentage = getTaxesByPercentage(resp.cart);
        resp.taxesWithPercents = taxesWithpercentage;
        return resp;
    };

    foo.loadSOOrder = async function(params) {
        let response = {};
        salesControllerLib.clear_all();

        let data = await couchDBUtils.getDoc(params._id, mainDBInstance);
        try {
            for (let i = 0; i < data.sale_items.length; i++) {
                await salesControllerLib.addSuspendedItem2Cart(data.sale_items[i]);
            }

            if (data.sales_info.customer_id) {
                await salesControllerLib.set_customer(data.sales_info.customer_id);
                let cust_info = await couchDBUtils.getDoc('customer_' + data.sales_info.customer_id, mainDBInstance);
                if (cust_info && cust_info.state_name && applicationSettings.ownersInfo.state != cust_info.state_name) {
                    await salesControllerLib.setLocalTax(false);
                }
            }
            await salesControllerLib.setCartEmployeeDetails(data.sales_info.employee_id);

            if (data.sales_info.wcInfo) {
                await salesControllerLib.setWCInfo(data.sales_info.wcInfo);
            }

            if (data.sales_info.paymentArr) {
                await commonLib.addPaymentsForEdit(data.sales_info.paymentArr, _self.add_paymentRestApi, true);
                // await salesControllerLib.set_payments(data.sales_info.paymentArr);// to fix the redeem bug in loyalty
            }
            if (data.sales_info.bSalesOrder) {
                salesControllerLib.setBSalesOrder(data.sales_info.bSalesOrder);
                let soOrderDate = {
                    nxtCDate: data.sales_info.nxtCDate,
                    dlvDate: data.sales_info.dlvDate
                }
                salesControllerLib.setSOOrderDate(soOrderDate);
                salesControllerLib.setSOIdRev(data);
                salesControllerLib.setSQorder();
            };

            if (data.sales_info.bSalesQuotation) {
                salesControllerLib.setSQorder(data.sales_info.bSalesQuotation);
                let SQDate = {
                    expDate: data.sales_info.expDate,
                    nxtCDate: data.sales_info.nxtCDate
                }
                salesControllerLib.setSQDate(SQDate);
                salesControllerLib.setSQIdRev(data);
                salesControllerLib.setBSalesOrder();
            };

            salesControllerLib.setShippingAddress(data.sales_info.sipAddrs);

            if (data.sales_info.globalDiscountInfo) {
                data.sales_info.globalDiscountInfo.value = data.sales_info.globalDiscountInfo.percent;
                data.sales_info.globalDiscountInfo.bPercent = true;
                await _self.setGlobalDiscount(data.sales_info.globalDiscountInfo);
            }
            let temParamFields = ['wcInfo', 'sale_time'];
            var tempParams = {};
            for (var i = 0; i < temParamFields.length; i++) {
                tempParams[temParamFields[i]] = data.sales_info[temParamFields[i]];
            }
            salesControllerLib.setTempDetails(tempParams);

        } catch (error) {
            salesControllerLib.clear_all();
            response.warning = 'Failed to load order';
        } finally {
            return prepareAndDispatchResponse(response);
        }
    };

    //save Sales order 
    //Taking all important session data, creating one object and saving in DB
    foo.saveSOOrder = async function(doc, bCompleted) {
        let response;
        if (!doc || !doc._id) {
            let sqData = doc;
            let wcInfo = doc ? doc.wcInfo : undefined;
            let prevDoc = salesControllerLib.getSOIdRev();
            let shippingAddress;
            let soOrderDate = {};
            let orderCrDate;
            // let ordCrDate;
            let bSalesOrder = true;;
            if (doc) {
                shippingAddress = doc.shippingDetails;
                soOrderDate = doc.soOrderDate;
                orderCrDate = doc.orderCrDate;
                soOrderDate.orderCrDate = doc.orderCrDate;
                salesControllerLib.setBSalesOrder(bSalesOrder);
                salesControllerLib.setSOOrderDate(soOrderDate);
                salesControllerLib.setShippingAddress(shippingAddress);
            }

            let bNewOrder = false;
            let _id = prevDoc._id;
            if (!_id) {
                _id = 'so_' + (++maxSOOrderNo);
                bNewOrder = true;
            }

            let customerId = salesControllerLib.get_customer();
            // if (!customerId) {

            // }

            if (wcInfo) {
                salesControllerLib.setWCInfo(wcInfo);
            };

            let cart = salesControllerLib.get_cart();
            let comment = salesControllerLib.get_comment();
            let employee = salesControllerLib.getCartEmployeeDetails();
            let paymentArr = salesControllerLib.get_payments();
            let customerInfo = salesControllerLib.getCartCustomerDetails();
            let customer = customerInfo.person_id ? customerInfo.first_name + ' ' + customerInfo.last_name : "";
            if (!customer && wcInfo) {
                customer = wcInfo.invoiceCustomerName;
            };
            salesControllerLib.set_print_after_sale(true);

            //Todo: sale_time should be same for sql and couch
            let timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
            response = await prepareAndDispatchResponse();
            response.customer_compnay_name = customerInfo.company_name;
            response.totalQuantity = salesControllerLib.calculateQuantity(cart);
            let salesEmployee = salesControllerLib.getCartEmployeeDetails();
            if (salesEmployee) {
                response.employee = salesEmployee.first_name + ' ' + salesEmployee.last_name;
                salesEmployeeName = salesEmployee.name;
            }

            doc = {
                _id: _id,
                sales_info: {
                    globalDiscountInfo: response.globalDiscountInfo,
                    sale_time: timestamp,
                    customer_id: customerId,
                    customer: customer,
                    employee_id: employee.name, //ohdtodo
                    employee: employee.name,
                    comment: comment,
                    total: response.total,
                    sale_id: undefined,
                    paymentArr: paymentArr,
                    shippingAddress: shippingAddress,
                    nxtCDate: soOrderDate.nxtCDate,
                    dlvDate: soOrderDate.dlvDate,
                    last_modified: timestamp,
                    wcInfo: wcInfo,
                    ordCrDate: orderCrDate,
                    bSalesOrder: bSalesOrder
                },
                sale_items: suspendSalesLib.getCartItems(cart),
                payments: []
            }

            if (sqData && sqData.orderStatus === 'C2SO') {
                doc.salesQuat_id = sqData._id;
            }

            if (bNewOrder) { // new order
                doc.id = maxSOOrderNo;
                doc.timestamp = moment().format('x');
                doc.orderStatus = 'Order Received';
            } else {
                doc._rev = prevDoc._rev;
                doc.id = prevDoc.id;
                doc.timestamp = prevDoc.timestamp;
                doc.orderStatus = prevDoc.orderStatus;
            }
        } else {
            //Update Status
            response = await prepareAndDispatchResponse();
        }

        if (bCompleted) {
            doc.orderStatus = 'completed';
        }

        await couchDBUtils.createOrUpdate(doc, mainDBInstance, 3, 'Save Order Failed');
        var respForSMS = CLONE(response);
        respForSMS._id = 'so_' + doc.id;
        respForSMS.orderStatus = doc.orderStatus;
        if (!bCompleted) {
            salesControllerLib.clear_all();
        }
        if (doc.sales_info.wcInfo && doc.sales_info.wcInfo.invoiceCustomerNumber)
            // respForSMS.phone_number = doc.sales_info.wcInfo.invoiceCustomerNumber;
            // commonLibEx.sendSMSafterSale(applicationSettings, respForSMS);
            if (!bCompleted) {
                salesControllerLib.clear_all();
            }

        if (!response._id) {
            response._id = respForSMS._id
        }
        response.taxDetailed = {};
        response.taxNames = {};
        response.hsnTaxes = {};
        getTaxesByPercentageDetailed(response.cart, response.taxDetailed, response.taxNames, response.hsnTaxes);
        var taxesWithpercentage = getTaxesByPercentage(response.cart);
        response.taxesWithPercents = taxesWithpercentage;
        return response;
    };

    foo.printSOOrder = async function(data) {
        try {
            let resp = CLONE(await _self.loadSOOrder(data));
            resp.totalQuantity = salesControllerLib.calculateQuantity(resp.cart);
            salesControllerLib.clear_all();
            let salesEmployee = salesControllerLib.getCartEmployeeDetails();
            if (salesEmployee) {
                resp.employee = salesEmployee.first_name + ' ' + salesEmployee.last_name;
            }
            let customerInfo = await couchDBUtils.getDoc('customer_' + resp.customer_id, mainDBInstance);
            if (customerInfo) {
                resp.customer_compnay_name = customerInfo.company_name;
            }
            resp.taxDetailed = {};
            resp.taxNames = {};
            resp.hsnTaxes = {};
            getTaxesByPercentageDetailed(resp.cart, resp.taxDetailed, resp.taxNames, resp.hsnTaxes);
            var taxesWithpercentage = getTaxesByPercentage(resp.cart);
            resp.taxesWithPercents = taxesWithpercentage;
            let cust_info = await couchDBUtils.getDoc('customer_' + resp.customer_id, mainDBInstance);
            if (cust_info && cust_info.state_name && applicationSettings.ownersInfo.state != cust_info.state_name) {
                await salesControllerLib.setLocalTax(false);
                resp.bLocalTax = false;
            }
            return resp;
        } catch (e) {
            console.log(e);
        }
    };

    const convertSQ2SO = async (doc) => {
        let resp;
        try {
            await _self.loadSOOrder(doc);

            const datex = {
                dlvDate: doc.sales_info.nxtCDate,
                nxtCDate: doc.sales_info.nxtCDate
            }
            let salesData = {
                soOrderDate: datex,
            };
            salesData.orderCrDate = new Date().getTime();
            salesData.wcInfo = doc.sales_info.wcInfo;
            await _self.saveSOOrder(salesData);
            resp = await couchDBUtils.createOrUpdate(doc, mainDBInstance, 3, 'Save Quotation Failed');
            return resp.msg = 'Convert to Sales Order Successfully';
        } catch (e) {
            logger.error(e);
        }
    }

    //save Sales Quotation 
    //Taking all important session data, creating one object and saving in DB
    foo.saveSaleQuotation = async function(doc, bCompleted) {
        let response;

        if (doc.orderStatus === 'C2SO') {
            response = await convertSQ2SO(doc);
            return response;
        };

        if (!doc || !doc._id) {
            let wcInfo = doc ? doc.wcInfo : undefined;
            let prevDoc = salesControllerLib.getSQIdRev();
            let quotCrDate;
            let soOrderDate = {};
            let orderCrDate;
            let bSalesQuotation = true;;
            if (doc) {
                soOrderDate = doc.soOrderDate;
                soOrderDate.orderCrDate = doc.orderCrDate;
                orderCrDate = doc.orderCrDate;
                salesControllerLib.setSQDate(soOrderDate)
                salesControllerLib.setSQorder(bSalesQuotation);
            }

            let bNewQuotation = false;
            let _id = prevDoc._id;
            if (!_id) {
                _id = 'sq_' + (++maxSQOrderNo);
                bNewQuotation = true;
            }

            let customerId = salesControllerLib.get_customer();
            // if (!customerId) {

            // }

            if (wcInfo) {
                salesControllerLib.setWCInfo(wcInfo);
            };

            let cart = salesControllerLib.get_cart();
            let comment = salesControllerLib.get_comment();
            let employee = salesControllerLib.getCartEmployeeDetails();
            let paymentArr = salesControllerLib.get_payments();
            let customerInfo = salesControllerLib.getCartCustomerDetails();
            let customer = customerInfo.person_id ? customerInfo.first_name + ' ' + customerInfo.last_name : "";
            let phone_number = customerInfo.phone_number;
            if (!customer && wcInfo) {
                customer = wcInfo.invoiceCustomerName;
                phone_number = wcInfo.invoiceCustomerNumber;
            };
            salesControllerLib.set_print_after_sale(true);

            //Todo: sale_time should be same for sql and couch
            let timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
            response = await prepareAndDispatchResponse();
            response.customer_compnay_name = customerInfo.company_name;
            response.totalQuantity = salesControllerLib.calculateQuantity(cart);
            let salesEmployee = salesControllerLib.getCartEmployeeDetails();
            if (salesEmployee) {
                response.employee = salesEmployee.first_name + ' ' + salesEmployee.last_name;
                salesEmployeeName = salesEmployee.name;
            }
            doc = {
                _id: _id,
                sales_info: {
                    globalDiscountInfo: response.globalDiscountInfo,
                    sale_time: timestamp,
                    customer_id: customerId,
                    customer: customer,
                    phone_number: phone_number,
                    employee_id: employee.name, //ohdtodo
                    employee: employee.name,
                    comment: comment,
                    total: response.total,
                    sale_id: undefined,
                    nxtCDate: soOrderDate.nxtCDate,
                    last_modified: timestamp,
                    wcInfo: wcInfo,
                    orderCrDate: orderCrDate,
                    expDate: soOrderDate.expDate,
                    bSalesQuotation: bSalesQuotation
                },
                sale_items: suspendSalesLib.getCartItems(cart),
                payments: []
            }

            if (bNewQuotation) { // new order
                doc.id = maxSQOrderNo;
                doc.timestamp = moment().format('x');
                doc.orderStatus = 'Quotation Received';
            } else {
                doc._rev = prevDoc._rev;
                doc.id = prevDoc.id;
                doc.timestamp = prevDoc.timestamp;
                doc.orderStatus = prevDoc.orderStatus;
            }
        } else {
            //Update Status
            response = await prepareAndDispatchResponse();
        }

        if (bCompleted) {
            doc.orderStatus = 'conv2SO';
        }

        await couchDBUtils.createOrUpdate(doc, mainDBInstance, 3, 'Save Quotation Failed');
        var respForSMS = CLONE(response);
        respForSMS._id = 'sq_' + doc.id;
        respForSMS.orderStatus = doc.orderStatus;
        if (!bCompleted) {
            salesControllerLib.clear_all();
        }
        if (doc.sales_info.wcInfo && doc.sales_info.wcInfo.invoiceCustomerNumber)
            // respForSMS.phone_number = doc.sales_info.wcInfo.invoiceCustomerNumber;
            // commonLibEx.sendSMSafterSale(applicationSettings, respForSMS);
            if (!bCompleted) {
                salesControllerLib.clear_all();
            }

        if (!response._id) {
            response._id = respForSMS._id
        }
        response.taxDetailed = {};
        response.taxNames = {};
        response.hsnTaxes = {};
        getTaxesByPercentageDetailed(response.cart, response.taxDetailed, response.taxNames, response.hsnTaxes);
        var taxesWithpercentage = getTaxesByPercentage(response.cart);
        response.taxesWithPercents = taxesWithpercentage;
        return response;
    };

    foo.quickSOOrder = async function(doc) {
        await _self.loadSOOrder(doc);
        if (doc.payments.length) {
            await _self.add_paymentRestApi(doc.payments[doc.payments.length - 1]);
        }
        return _self.completeSOOrder({});
    };

    foo.completeSOOrder = async function(param) {
        let saleData = await _self.saveSOOrder(undefined, true);
        try {
            let response = await _self.completeSaleRestApi(param);
            return response;
        } catch (err) {
            salesControllerLib.clear_all();
            throw "Failed to complete order";
        }
    };

    async function deleteOrder(tableNo, orderNo) {
        try {
            let resp = await getAllSales(tableNo, orderNo);
            var promisesArray = [];
            console.log(resp[0]);

            resp.forEach((item) => {
                promisesArray.push(suspendSalesLib.deleteExt(item));
            })

            var params = {
                'order_no': orderNo
            };
            promisesArray.push(couchDBUtils.deleteOrder(tableNo, params, mainDBInstance));
            return Promise.all(promisesArray);
        } catch (err) {
            logger.error(err);
            return Promise.reject(err);

        }
    }

    async function updatePrintOrders(tableNo, orderNo) {
        try {
            let tableDoc = await couchDBUtils.getDoc('table_' + tableNo, mainDBInstance);
            if (tableDoc.printedOrders) {
                let printedOrders = tableDoc.printedOrders;
                let orderIndex = printedOrders.indexOf(orderNo)
                if (orderIndex > -1) {
                    printedOrders.splice(orderIndex, 1)
                    await couchDBUtils.update(tableDoc, mainDBInstance);
                }
            }
        } catch (err) {
            logger.error(err);
        };

    }

    /**
     * deleteOrdersOfTableRestApi 
     * */
    foo.cancelOrder = async function(requestData) {
        var tableNo = requestData.table_no;
        var orderNo = requestData.order_no;
        try {
            await deleteOrder(tableNo, orderNo);
            await updatePrintOrders(tableNo, orderNo);

            return {
                status: status.SUCCESS
            };
        } catch (err) {
            logger.error(err);
            return err;
        }
    };

    /**
     *      getItemsForTableOrderRestApi
     */
    foo.getItemsForTableOrder = function(requestData) {
        var tableNo = requestData.table_no;
        var orderNo = requestData.order_no;
        var response = {};
        response.orderItems = {};
        response.status = status.ERR_UNDEFINED;

        return getAllSales(tableNo, orderNo).then(function(resp) {
            return suspendSalesLib.getItems(resp);
        }).then(function(resp) {
            response.status = status.SUCCESS;
            response.orderItems = resp;
            return response;
        }).catch(function(err) {
            logger.error(err);
            return response;
        });
    };

    /**
     *      addCustomer2OrdersRestApi
     *      deleteCustomer4OrderRestApi
     */

    foo.removeCustomer = async function() {
        try {
            let resp = await salesControllerLib.removeCustomer();
            return resp;
        } catch (error) {
            return error;
        }

    }
    foo.addCustomer2Order = function(requestData) {

        async function setCustomer4Order(data) {
            var tableNo = data.table_no;
            var orderNo = data.order_no;
            var response = {};
            response.status = status.ERR_UNDEFINED;
            try {
                let resp = await getAllSales(tableNo, orderNo);
                resp = await suspendSalesLib.setCustomer(resp, data.customer_id);

                response.status = status.SUCCESS;
                return response;
            } catch (err) {
                logger.error(err);
                return response;
            };
        }

        var response = {
            succs_customer_id: null
        };

        return setCustomer4Order(requestData).then(function(resp) {
            if (resp.status !== status.SUCCESS) {
                return response;
            }

            return _self.addCustomer2Sale(requestData);
        }).catch(function(err) {
            logger.error(err);
            return response;
        });
    };

    async function getAllSales(tableNo, orderNo) {
        try {
            let tableDoc = await couchDBUtils.getDoc('table_' + tableNo, mainDBInstance);
            let sales = [];
            for (let i = 0; i < tableDoc.orders.length; i++) {
                if (tableDoc.orders[i].order_no === orderNo) {
                    for (let j = 0; j < tableDoc.orders[i].Kots.length; j++) {
                        sales.push(tableDoc.orders[i].Kots[j].sale_id);
                    }
                    break;
                }
            }

            return sales;
        } catch (err) {
            logger.error(err);
            return [];
        }
    }

    /**
     *      loadAllOrderItemBeforeCheckOutRestApi
     */
    foo.loadAllOrdersToCart = async function(requestData) {
        salesControllerLib.clear_all();

        var tableNo = requestData.table_no;
        var orderNo = parseInt(requestData.order_no);

        try {
            let tableDoc = await couchDBUtils.getDoc('table_' + tableNo, mainDBInstance);
            let orderIndex = saleEx.getOrderData(tableDoc, orderNo);
            salesControllerLib.setPrintBillInvoiceNo(tableDoc.orders[orderIndex]);
            let resp = await getAllSales(tableNo, orderNo);
            resp = await salesControllerLib.addSuspendedSalesToCart(resp);
            let cust_info = salesControllerLib.getCartCustomerDetails();
            if (cust_info && cust_info.state_name && applicationSettings.ownersInfo.state != cust_info.state_name) {
                await salesControllerLib.setLocalTax(false);
            } else {
                await salesControllerLib.setLocalTax(true);
            }

            let globalDiscountInfo = tableDoc.orders[orderIndex].globalDiscountInfo;
            if (globalDiscountInfo) {
                await _self.setGlobalDiscount(globalDiscountInfo);
            }

            if (resp.status !== status.SUCCESS) {
                salesControllerLib.clear_all();
            }

            return prepareAndDispatchResponse();
        } catch (err) {
            logger.error(err);
            salesControllerLib.clear_all();
            return prepareAndDispatchResponse();

        }

    };

    const removeMergeTable = async (tableDoc, orderIndex) => {
        let tableArray = [];
        tableArray.push(tableDoc._id);
        if (tableDoc.mergeTables) {
            tableArray = tableArray.concat(tableDoc.mergeTables);
        } else if (tableDoc.orders[orderIndex].mergeTables) {
            tableArray = tableArray.concat(tableDoc.orders[orderIndex].mergeTables);
        }

        try {
            const allDocs = await couchDBUtils.getAllDocs(tableArray, mainDBInstance);
            if (allDocs[0].doc.mergeTables) {
                delete allDocs[0].doc.mergeTables;
            } else if (allDocs[0].doc.orders[orderIndex].mergeTables) {
                delete allDocs[0].doc.orders[orderIndex].mergeTables;
            }

            for (let i = 1; i < allDocs.length; i++) {
                delete allDocs[i].doc.mergeWith;
            }
            let tableDocs = [];
            for (let i = 0; i < allDocs.length; i++) {
                tableDocs.push(allDocs[i].doc);
            }
            await couchDBUtils.bulkDocs(tableDocs, mainDBInstance, 3);
        } catch (err) {
            logger.error(err);
            throw err;
        }
    }
    /**
     *      completeTakeOrderRestApi
     */
    foo.completeTakeOrder = async function(requestData) {
        var response = {};
        var tableNo = requestData.table_no;
        let tableDoc = await couchDBUtils.getDoc('table_' + tableNo, mainDBInstance);

        try {
            const orderIndex = saleEx.getOrderData(tableDoc, requestData.order_no);
            if (tableDoc.orders[orderIndex]) {
                if (tableDoc.orders[orderIndex].mergeTables || tableDoc.mergeTables) {
                    await removeMergeTable(tableDoc, orderIndex)
                }
            }

            let resp = await _self.completeSaleRestApi(requestData);
            var tableNo = requestData.table_no;
            response = resp;
            response.tableNo = tableNo;
            // updatePrintOrders(tableNo, requestData.order_no);
            var reservationId = requestData.reservation_id;
            if (!utils.isUndefinedOrNull(reservationId) && reservationId !== 0) {
                var query = {
                    where: {
                        reservation_id: reservationId
                    }
                };
                //NoSQLTodo: move this function to nosql
                // promisesArray.push(Models.profitGuru_table_reservation.destroy(query));

                var params = {
                    'reservation_id': reservationId
                };
                await couchDBUtils.deleteReservation(tableNo, params, mainDBInstance);
            }
            saveChekoutOrder(tableDoc, requestData, resp);

            await deleteOrder(tableNo, requestData.order_no);
            await updatePrintOrders(tableNo, requestData.order_no);
            return response;

        } catch (err) {
            logger.error(err);
            throw err;
        }
    };

    /**
     *      save checkout order before delete
     */

    async function saveChekoutOrder(tableDoc, requestData, resp) {
        try {
            let orderCheckOut = {};
            let orders = tableDoc.orders;
            for (let i = 0; i < orders.length; i++) {
                if (orders[i].order_no == requestData.order_no) {
                    id = resp.id;
                    orderCheckOut = orders[i];
                    break;
                }
            }
            orderCheckOut.invoice_id = resp.sale_id;
            orderCheckOut.invoice_time = resp.transaction_time;
            orderCheckOut.total = resp.total;
            let param = {
                _id: 't_' + tableDoc._id + '_' + id,
                table_no: tableDoc.table_no,
                order: orderCheckOut

            };
            await couchDBUtils.create(param, mainDBInstance);
        } catch (err) {
            logger.error(err);
            throw err;
        }
    }
    /**
     *  loadKotToCartRestApi
     */
    foo.loadKotToCart = function(requestData) {
        var saleId = requestData.sale_id;
        salesControllerLib.clear_all();
        return salesControllerLib.copy_entire_suspended_sale(saleId).then(function() {
            return prepareAndDispatchResponse();
        }).catch(function(err) {
            logger.error(err);
            salesControllerLib.clear_all();
            return prepareAndDispatchResponse();
        });
    };

    /**
     *      get_max_order_numberRestApi
     */
    foo.getMaxOrderNo = function(requestData) {

        return couchDBUtils.getDoc('table_' + requestData.table_no, mainDBInstance).then(function(tableData) {
            return {
                order_no: (tableData.maxOrderNo + 1)
            };
        }).catch(function(error) {
            let errMsg = 'Table Not Found';
            logger.error(errMsg);
            return Promise.reject(errMsg);
        });
    };

    /**
     *      getDateRangesRestApi
     */
    foo.getDateRanges = function() {
        var response = {
            date_range: []
        };

        var dateRange = utils.getDateRangesJson();
        for (key in dateRange) {
            response.date_range.push({
                date: key,
                label: dateRange[key]
            })
        }

        return Promise.resolve(response);
    };

    foo.loadSale = function(requestData) {
        var response = {
            data: {},
            msg: ''
        };

        if (validator.isNumeric(requestData.saleId + '') === false) {
            response.msg = 'saleId should be a number';
            return Promise.reject(response);
        }

        return salesControllerLib.loadSaleHelper(requestData).then(function(resp) {
            response.data = resp;
            //check error code

            return response;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.multipleReprint = async function(saleIds) {
        var salesInfoArray = [];
        var SaleData = {};
        if (saleIds) {
            for (var id in saleIds) {
                SaleData = {
                    saleId: saleIds[id]
                };
                var saleDta = await _self.rePrint(SaleData);
                salesInfoArray.push(saleDta);
            }
        }

        return await salesInfoArray;
    }

    foo.rePrint = function(requestData) {
        var response = {
            data: {},
            message: ''
        };

        // if (validator.isNumeric(requestData.saleId + '') === false) {
        //     response.message = 'saleId should be a number';
        //     return Promise.reject(response);
        // }

        return salesControllerLib.getJsonForPrint(requestData).then(function(resp) {
            response = resp;
            return response;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.makeCustomerCreditPayment = function(requestData) {
        requestData.employeeId = requestSession.user.name;
        return creditPaymentsLib.makeCustomerCreditPayment(requestData).then(function(response) {
            if (requestData.print_after_sale) {
                response.print_after_sale = requestData.print_after_sale;
                if (requestSession.clientType === 'MobileApp') {
                    utils.sendSocketEvent('printCreditReceipt', response);
                }
            }
            return response;
        }).catch(function(error) {
            logger.error(error);
            return Promise.reject(error);
        });
    };

    foo.resetSalesInfo = async function(type) {
        try {
            await commonLib.cleanTxnsByType(type);
            return;
        } catch (error) {
            console.log(error);
            logger.error(error);
            throw 'ResetSalesInfo Failed';
        }
    }

    foo.deleteSaleById = async function(docId) {
        let respArry = [];
        for (let i = 0; i < docId.length; i++) {
            respArry.push(await commonLib.reverseTransaction(docId[i], undefined, undefined, applicationSettings.bUpdateStockOnSalesDelete));
        }
        return respArry;
    }

    foo.rejectSale = function(params) {
        return commonLib.reverseTransaction(params.id, params.breject, params.reason, applicationSettings.bUpdateStockOnSalesDelete);
    }

    foo.getSalesDocById = function(saleId) {
        return commonLib.getTansDocument(saleId);
    }

    /**
     * Taxes
     * Inc/Ex Tax
     * If he deletes item .. exception will come
     */
    foo.copyThisSale = async function(saleDoc) {
        saleDoc = await commonLib.transformSaleDoc(saleDoc, 'sale');
        requestSession.user = {
            name: saleDoc.sales_info.employee_id
        };
        let resp = await _self.initEditSalesSession(undefined, saleDoc);
        let requestData = {
            state_name: saleDoc.sales_info.state_name,
            comment: saleDoc.sales_info.comment,
            timeStamp: saleDoc.sales_info.sale_time,
            chequeNo: saleDoc.sales_info.checkNo,
            shippingDetails: saleDoc.sales_info.shippingDetails,
            vehicle_phNo: saleDoc.sales_info.vehicle_phNo,
            vehicleNo: saleDoc.sales_info.vehicleNo,
            wcInfo: saleDoc.sales_info.wcInfo
        }

        let completeSaleResp = await _self.completeSaleRestApi(requestData);
        return completeSaleResp;
    }

    //very inefficient. Please do bulk operations. 
    //response is computed everytime
    foo.initEditSalesSession = async function(requestData, saleDoc) {
        try {
            saleDoc = saleDoc || await commonLib.getTansDocument(requestData.saleId);
            if (saleDoc.status.status) {
                throw {
                    'message': 'Not ready for Edit'
                };
            }

            if (applicationSettings.salesConfig.pProfileId !== saleDoc.sales_info.pProfileId) {
                applicationSettings.salesConfig.pProfileId = saleDoc.sales_info.pProfileId;
                await appSettingsHandler.updateApplicationSettings({
                    body: applicationSettings,
                    app: {
                        locals: {}
                    }
                }, process.env.APP_TYPE);

                salesControllerLib = new require('./libraries/salesControllerLib')(requestSession, applicationSettings);
            }

            await appSettingsHandler.updateApplicationSettings({
                body: applicationSettings,
                app: {
                    locals: {}
                }
            }, process.env.APP_TYPE);

            await _self.cancel_saleRestApi();
            let temParamFields = ['wcInfo', 'sale_time', 'shippingDetails', 'checkNo', 'comment', 'state_name', 'vehicle_phNo', 'vehicleNo'];
            var tempParams = {};
            for (var i = 0; i < temParamFields.length; i++) {
                tempParams[temParamFields[i]] = saleDoc.sales_info[temParamFields[i]];
            }
            salesControllerLib.setTempDetails(tempParams);
            if (saleDoc.sales_info.loyaltyEarned) {
                logger.info("setLoyaltyEarned " + saleDoc.sales_info.loyaltyEarned);
                salesControllerLib.setLoyaltyEarned(saleDoc.sales_info.loyaltyEarned);
            }
            if (saleDoc.sales_info.rmPnts) {
                logger.info("setLoyaltyRedeemed " + saleDoc.sales_info.rmPnts);
                salesControllerLib.setLoyaltyRedeemed(saleDoc.sales_info.rmPnts);
            }
            if (saleDoc.sales_info.customer_id) {
                logger.info("setCusB4Edit " + saleDoc.sales_info.customer_id);
                salesControllerLib.setCusB4Edit(saleDoc.sales_info.customer_id);
            }

            for (var i = 0; i < saleDoc.sale_items.length; i++) {
                let taxList = commonLib.convertToGSTTaxes(saleDoc.sale_items[i].itemTaxList);
                //ganesh
                var params = {
                    item: saleDoc.sale_items[i].item_id,
                    stockKey: saleDoc.sale_items[i].stockKey,
                    discount: saleDoc.sale_items[i].discount_percent,
                    discountBy: "percent",
                    price: saleDoc.sale_items[i].sellingPrice,
                    quantity: saleDoc.sale_items[i].quantity_purchased,
                    bSPTaxInclusive: saleDoc.sale_items[i].bSPTaxInclusive,
                    itemTaxList: taxList,
                    warranty: saleDoc.sale_items[i].warranty,
                    warrantyTerms: saleDoc.sale_items[i].warrantyTerms,
                    unitId: saleDoc.sale_items[i].unitId,
                    unitsInfo: saleDoc.sale_items[i].unitsInfo,
                    baseUnitId: saleDoc.sale_items[i].baseUnitId,
                    slab: saleDoc.sale_items[i].slab,
                    description: saleDoc.sale_items[i].description,
                }
                if (saleDoc.sale_items[i].serialnumber || saleDoc.sale_items[i].imeiNumbers.length) {
                    params.uniqueDetails = {};

                    if (saleDoc.sale_items[i].serialnumber) {
                        params.uniqueDetails.serialnumber = saleDoc.sale_items[i].serialnumber;
                    }
                    if (saleDoc.sale_items[i].imeiNumbers.length) {
                        params.uniqueDetails.imeiNumbers = saleDoc.sale_items[i].imeiNumbers;
                    }
                }

                params.bThrowError = true;
                await _self.additemRestApi(params);
            }

            if (saleDoc.sales_info.customer_id) {
                await _self.addCustomer2Sale({
                    'customer_id': saleDoc.sales_info.customer_id
                });
            }
            let customerInfo = salesControllerLib.getCartCustomerDetails();
            if (customerInfo && customerInfo.credit_balance > 0) { // test it for -ve credit balance
                let creditWithoutcurrCredit = customerInfo.credit_balance - commonLib.getCreditPayment(saleDoc.payments); //setting the crediot balance which is not the part og this particular sale
                salesControllerLib.setCreditBalance(creditWithoutcurrCredit);
            }
            if (saleDoc.sales_info.employee_id) {
                await _self.addEmployee2Sale({
                    'employee_id': saleDoc.sales_info.employee_id
                });
            }

            if (saleDoc.sales_info.bHomeDelivery) {
                salesControllerLib.setDeliveryCharge(saleDoc.sales_info.deliveryCharge);
            };

            if (saleDoc.sales_info.tableNo) {
                salesControllerLib.setTableNo(saleDoc.sales_info.tableNo);
            };

            let globalDiscountInfo = saleDoc.sales_info.globalDiscountInfo;
            if (globalDiscountInfo) {
                globalDiscountInfo.value = globalDiscountInfo.percent;
                globalDiscountInfo.bPercent = true;
                await _self.setGlobalDiscount(globalDiscountInfo);
            }

            let resp = await commonLib.addPaymentsForEdit(saleDoc.payments, _self.add_paymentRestApi, true);
            return resp;
        } catch (error) {
            await _self.cancel_saleRestApi();
            throw error;
        }

    }

    foo.getOrderBill = async (requestData) => {
        try {
            await savePrintOrder(requestData);
            let resp = await _self.loadAllOrdersToCart(requestData);
            salesControllerLib.clear_all();
            resp.taxDetailed = {};
            resp.taxNames = {};
            resp.hsnTaxes = {};
            getTaxesByPercentageDetailed(resp.cart, resp.taxDetailed, resp.taxNames, resp.hsnTaxes);
            var taxesWithpercentage = getTaxesByPercentage(resp.cart);
            resp.taxesWithPercents = taxesWithpercentage;
            resp.tableNo = requestData.table_no;
            resp.order_no = requestData.order_no;
            return resp;
        } catch (err) {
            logger.error(err);
            throw err;
        };
    };

    const savePrintOrder = async (requestData) => {
        try {
            const tableNo = requestData.table_no;
            const orderNo = parseInt(requestData.order_no);
            let isPrintBill = requestData.isOnlyPrintBill;
            const tableDoc = await couchDBUtils.getDoc('table_' + tableNo, mainDBInstance);
            let orderIndex = saleEx.getOrderData(tableDoc, orderNo);
            let printedOrders = tableDoc.printedOrders ? tableDoc.printedOrders : [];

            if (!isPrintBill) {
                return;
            }
            if (printedOrders) {
                if (printedOrders.indexOf(orderNo) !== -1) {
                    return;
                }
            }

            autoIncrementHelper.incrementSaleId();
            tableDoc.orders[orderIndex].invoice_no = autoIncrementHelper.getMaxSaleId();
            let invoiceCheckPoint = commonLib.getCurrentCheckpoint(applicationSettings);
            // let checkpoint = applicationSettings.invoiceCurrentCheckpoint;

            tableDoc.orders[orderIndex].prefix = invoiceCheckPoint.prefix;
            tableDoc.orders[orderIndex].invoiceCheckPoint = invoiceCheckPoint.value;

            printedOrders.push(orderNo);
            tableDoc.printedOrders = printedOrders;

            return couchDBUtils.update(tableDoc, mainDBInstance);
        } catch (err) {
            logger.error(err);
            throw err;
        };

    };

    return foo;
}

module.exports = function(requestSession, applicationSettings) {
    return salesController(requestSession, applicationSettings);
};