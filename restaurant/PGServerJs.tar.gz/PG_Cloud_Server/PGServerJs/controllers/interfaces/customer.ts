export interface Customer {
    _id: string;
    _rev?: string;
    first_name: string;
    last_name: string;
    gender: string;
    email: string;
    phone_number: string;
    address_1: string;
    account_number: number;
    company_name: string;
    credit_balance: number;
    credit_limit: number;
    pan_number: string;
    agency_name: string;
    aadhaar_number: number;
    city_name: string;
    state_name: string;
    pin_code: number;
    customer_since: string;
    occupation: string;
    birth_date: string;
    anniversary: string;
    bank_name: string;
    bank_branch: string;
    ifsc_code: string;
    micr_code: number;
    vat_number: number;
    gstin_number: string;
    tin_number: number;
    cst_number: number;
    allow_credit: string;
    payment_terms: string;
    by_months: number;
    type: string;
    total: number;
    person_id: number;
    deleted?: string;
}

const sampleCustomer: Customer = {
    "_id": "customer_1519888396382",
    "_rev": "1-48bbb9cc83cd48ceff544c463dfe2be4",
    "first_name": "linto",
    "last_name": "thomas",
    "gender": "0",
    "email": "email@gmail.com",
    "phone_number": "991658476068",
    "address_1": "address",
    "account_number": 65456454,
    "company_name": "compny",
    "credit_balance": 0,
    "credit_limit": 1000,
    "pan_number": "AAAAA1111A",
    "agency_name": "agency",
    "aadhaar_number": 7148635,
    "city_name": "city",
    "state_name": "state",
    "pin_code": 560581,
    "customer_since": "2018-02-28T18:30:00.000Z",
    "occupation": "occupa",
    "birth_date": "2017-08-08T18:30:00.000Z",
    "anniversary": "2018-02-07T18:30:00.000Z",
    "bank_name": "bank name",
    "bank_branch": "branch name",
    "ifsc_code": "546545",
    "micr_code": 6855464,
    "vat_number": 6545,
    "gstin_number": "29AAAAA1111A1ZA",
    "tin_number": 6846584,
    "cst_number": 6847867474,
    "allow_credit": "Allow",
    "payment_terms": "months",
    "by_months": 3,
    "type": "customer_",
    "total": 0,
    "person_id": 1519888396382
};

// skipping this "payment_terms": "Payment Terms", //weeks/months/days
const importCustomerMap = {
    "first_name": "First Name",
    "last_name": "Last Name",
    "gender": "Gender",
    "email": "Email Id",
    "phone_number": "Phone Number",
    "address_1": "Address",
    "account_number": "Account Number",
    "company_name": "Company Name",
    "credit_balance": "Credit Balance",
    "credit_limit": "Credit Limit",
    "pan_number": "PAN Number",
    "agency_name": "Agency Name",
    "aadhaar_number": "Aadhar Number",
    "city_name": "City",
    "state_name": "State",
    "pin_code": "PIN Code",
    "customer_since": "Customer Since",
    "occupation": "Occupation",
    "birth_date": "Birth Date",
    "anniversary": "Anniversary Date",
    "bank_name": "Bank Name",
    "bank_branch": "Branch Name",
    "ifsc_code": "IFSC Code",
    "micr_code": "MICR Code",
    "vat_number": "VAT Number",
    "gstin_number": "GSTIN Number",
    "tin_number": "TIN Number",
    "cst_number": "CST Number",
    "allow_credit": "Allow Credit",
    "by_months": "Months",
    "by_weeks": "Weeks",
    "by_days": "Days"
};