let utils = function() {

    this.batchProcess = async function(chunkSize, docType, processFun, params) {
        let offset = 0;
        while (true) {
            params.logger.info('Current Count <' + offset + ' >');
            let allDocs = await params.couchDBUtils.getAllDocsByType(docType, params.dbInstance, {
                limit: chunkSize,
                skip: offset
            });
            offset += allDocs.length;

            await processFun(allDocs, params);

            if (allDocs.length !== chunkSize) {
                params.logger.info('Total Process Count<' + offset + '>');
                break;
            }
        }
    }

};

module.exports = new utils();