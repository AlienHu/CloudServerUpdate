'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

// let itemsCtrl = function() {

const couchDbManager = require('../../../dbManagers/couchDbManager');
const couchDBUtils = require('../../common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const globalConfigController = require('../../GlobalConfigurations');
const roomCntrlr = require("../../../controllers/Rooms");
const logger = require("../../../common/Logger");
const varientCtrl = require("../../../controllers/Variants");
const Utils = require('../../../common/Utils');

let configObj = function() {

    this.createConfig = async function(key, itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr) {

        let foo = '';
        if (key === 'Category Name') {
            foo = 'createCategory';
        } else if (key === 'Discount %') {
            foo = 'createDiscount';
        } else if (key.indexOf("Purchase Taxes%") != -1) {
            purchaseTaxesHeaderNameArr.push(key);
            foo = 'createTax';
        } else if (key.indexOf("Sales Taxes%") != -1) {
            salesTaxesHeaderNameArr.push(key);
            foo = 'createTax';
        }

        //process is to get unique config names
        let count = {};
        for (let i = 0; i < itemsArray.length; i++) {

            let configName = itemsArray[i][key];

            if (!configName) {
                // To ignore empty category / subCategory
                continue;
            }
            console.log("configName:" + configName);
            count[configName] = 1;
        }

        //here creating config
        let namesArray = Object.keys(count);
        for (let i = 0; i < namesArray.length; i++) {

            let info;
            if (key === 'Category Name') {
                info = {
                    name: namesArray[i],
                    description: "Default Categories"
                };
            } else if (key === 'Discount %') {
                info = {
                    name: "discount",
                    discount: parseFloat(namesArray[i]),
                    description: "Default Discount",

                };
            } else if (key.indexOf("Purchase Taxes%") != -1 || key.indexOf("Sales Taxes%") != -1) {

                let spacePosition = key.indexOf(' ');
                let tempName = key.substr(0, spacePosition);
                info = {
                    name: tempName,
                    percent: parseFloat(namesArray[i]),
                    description: tempName + " Tax",

                };
            }
            try {
                await globalConfigController[foo](info);

            } catch (error) {
                console.log(namesArray[i] + ' already exist' + " error:");
            }
        }
    }

    this.createSupplier = async function() {

        let elementsCtrl = require("./../../../controllers/Elements");
        let supplier = {
            type: "supplier_",
            company_name: "Alienhu",
            first_name: "Mafeella",
            last_name: "A",
            email: "manjunathasundi39@gmail.com",
            gender: "0",
            phone_number: "9886988915"
        };
        elementsCtrl.create(supplier).then(function(response) {
            console.log("Supplier response:" + JSON.stringify(response));
        }).catch(function(err) {
            console.log("Supplier err:" + JSON.stringify(err));
        });

    }

    this.createSlab = async function() {

        let slabObj = {
            name: "Garments",
            taxName: "GST",
            rates: [{
                min: 10,
                max: 10000,
                percent: 10
            }]
        };

        try {
            await globalConfigController["createSlab"](slabObj);
            console.log("slab created successfully");
        } catch (error) {
            console.log("creating Slab error:" + error);
        }

        slabObj = {
            name: "Mobile",
            taxName: "GST",
            rates: [{
                min: 1000,
                max: 10000,
                percent: 10
            }]
        };

        try {
            await globalConfigController["createSlab"](slabObj);
            console.log("slab created successfully");
        } catch (error) {
            console.log("creating Slab error:" + error);
        }

    }
    this.createGeneralCategory = async function() {

        // if column doesn't exist, create General Category
        let info = {
            name: "General",
            description: "Default Categories"
        };

        try {

            await globalConfigController["createCategory"](info);
            console.log("try block of createGeneralCategory");
        } catch (error) {
            console.log("General" + ' already exist' + " error:");
        }

    }
    this.createVariants = async function(itemsArray) {

        let variantObjects = {};

        let index = 0;
        for (let i = 0; i < itemsArray.length; i += index) {
            let size = parseInt(itemsArray[i]["Initial Stock Size"]);
            index = size;
            if (itemsArray[i]["Attributes"] === '-' || itemsArray[i]["Attributes"] === ' ') {
                continue;
            }
            console.log("itemsArray[" + i + "]:" + itemsArray[i]["Attributes"]);
            let VariantsNamesArray = itemsArray[i]["Attributes"].split('/');

            for (let k = i; k < (i + size); k++) {
                let variantsValuesArray = itemsArray[k]["SKU Name"].split("/");
                //write condition that valuesarray length and namesarray length is same
                for (let j = 0; j < VariantsNamesArray.length; j++) {
                    let variantName = VariantsNamesArray[j];
                    if (!variantObjects[variantName]) {
                        variantObjects[variantName] = [];
                    }

                    let variantValue = variantsValuesArray[j];
                    if (variantObjects[variantName].indexOf(variantValue) === -1) {
                        variantObjects[variantName].push(variantValue);
                    }
                }
            }
        }

        //convert to required    
        for (let variantName in variantObjects) {
            let doc = {
                name: variantName,
                values: []
            };
            for (let i = 0; i < variantObjects[variantName].length; i++) {
                if (variantObjects[variantName][i] !== '-' && variantObjects[variantName][i] !== ' ') {
                    doc.values.push({
                        name: variantObjects[variantName][i]
                    });
                }
            }
            console.log("doc:" + JSON.stringify(doc));
            console.log("\n\n");
            await varientCtrl.create(doc)
                .then(function(response) {
                    console.log("response:" + JSON.stringify(response));
                }).catch(function(error) {
                    console.log("error:" + JSON.stringify(error));
                });

        }
    }

};

module.exports = new configObj();