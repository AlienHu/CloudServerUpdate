'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const couchDbManager = require('../../../dbManagers/couchDbManager');
const couchDBUtils = require('../../common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const globalConfigController = require('../../GlobalConfigurations');
const roomCntrlr = require("../../../controllers/Rooms");
const logger = require("../../../common/Logger");
const varientCtrl = require("../../../controllers/Variants");
const Utils = require('../../../common/Utils');
const configObj = require("./createConfig");

let idsObj = function() {

    this.getCategoriesObj = async function() {
        console.log("calling getCategoriesObj method");
        let categoryObj = {};
        let categoryArray = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
        //Initialize category array
        for (let i = 0; i < categoryArray.length; i++) {
            categoryObj[categoryArray[i].doc.name] = categoryArray[i].doc.id;
        }
        return categoryObj;
    }

    this.getSuppliersObj = async function() {
        console.log("calling getSuppliersObj method");
        let supplierArray = await couchDBUtils.getAllDocsByType('supplier', mainDBInstance);
        let supplierObj = {};

        //Initialize supplier array
        console.log("\nsupplierArray.length" + supplierArray.length)
        console.log("\nsupplierArray" + supplierArray);

        for (let i = 0; i < supplierArray.length; i++) {
            supplierObj[supplierArray[i].doc.first_name] = supplierArray[i].doc.person_id;
        }

        return supplierObj;
    }

    this.getSlabsObj = async function() {
        console.log("calling getSlabsObj method");
        let slabObj = {};
        let slabArray = await couchDBUtils.getAllDocsByType('slab', mainDBInstance);
        //Initialize slab array
        for (let i = 0; i < slabArray.length; i++) {
            slabObj[slabArray[i].doc.name] = slabArray[i].doc.id;
        }

        return slabObj;

    }

    this.getUnitsObj = async function() {

        console.log("calling getSlabsObj method");
        let unitArray = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);

        let unitObj = {};
        //Initialize unit array
        for (let i = 0; i < unitArray.length; i++) {
            unitObj[unitArray[i].doc.name] = unitArray[i].doc.id;
        }

        return unitObj;

    }

    this.getTaxIdsObj = async function() {

        console.log("calling getTaxIdsObj method");
        let taxObj = {};
        let taxArray = await couchDBUtils.getAllDocsByType('tax', mainDBInstance);
        //Initialize Tax array
        for (let i = 0; i < taxArray.length; i++) {
            let salesKey = taxArray[i].doc.name + ' Sales Taxes% ' + taxArray[i].doc.percent;
            let purchaseKey = taxArray[i].doc.name + ' Purchase Taxes% ' + taxArray[i].doc.percent;
            taxObj[salesKey] = taxArray[i].doc.id;
            taxObj[purchaseKey] = taxArray[i].doc.id;
        }
        return taxObj;
    }

    this.getVariantsObj = async function() {
        console.log("calling getVariantsObj method");
        let variantArray = await couchDBUtils.getAllDocsByType('variant', mainDBInstance);
        let variantObj = {};
        console.log(" variantArray.length:" + variantArray.length);
        //Initialize variant array
        for (let i = 0; i < variantArray.length; i++) {
            variantObj[variantArray[i].doc.name] = variantArray[i].doc.id;
            let valueKeys = Object.keys(variantArray[i].doc.values);
            let valueValues = Object.values(variantArray[i].doc.values);

            for (let j = 0; j < valueValues.length; j++) {
                console.log("\nvalueKeys[j]:" + valueKeys[j] + "  \nName[j]" + valueValues[j]["name"]);
                variantObj[variantArray[i].doc.name + " " + valueValues[j]["name"]] = valueKeys[j];
                console.log("\n");
            }
            console.log("variantObj[" + i + "]" + JSON.stringify(variantObj));
            console.log("\n");
        }

        return variantObj;
    }

    this.getPprofilesObj = async function() {
        let pprofileArray = await couchDBUtils.getAllDocsByType('pProfile', mainDBInstance);
        let pprofileObj = {};
        //Initialize profile array
        for (let i = 0; i < pprofileArray.length; i++) {
            pprofileObj[pprofileArray[i].doc.name] = pprofileArray[i].doc.id;
        }
        return pprofileObj;
    }

    this.getdiscountsObj = async function() {
        let discountArray = await couchDBUtils.getAllDocsByType('discount', mainDBInstance);
        let discountObj = {};
        //Initialize discount array
        for (let i = 0; i < discountArray.length; i++) {
            discountObj[discountArray[i].doc.discount] = discountArray[i].doc.id;
        }
        return discountObj;
    }

};

// let result = idsObj.getCategoriesObj();
module.exports = new idsObj();