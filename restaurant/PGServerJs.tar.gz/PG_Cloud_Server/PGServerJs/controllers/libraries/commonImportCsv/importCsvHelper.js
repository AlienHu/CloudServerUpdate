let importHelpCtrl = function() {

    this.checkBooleanType = function(data) {

        console.log("inside checkBooleanType method");
        if (data.toLowerCase() === "true" || data.toLowerCase() === "false" ||
            data.toLowerCase() === "no" || data.toLowerCase() === "yes") {
            return true;
        }
        return false;
    };

    this.checkNumberType = function(data) {

        data = parseInt(data);
        console.log("inside checkNumberType method");
        if (isNaN(data)) {
            return false;
        }
        return true;
    };

    this.checkBlankOrHypen = function(data) {

        console.log("checkBlankOrHypen");
        if (data === '-' || data.trim() === '' || data === ' ') {
            return true;
        }
        return false;
    }
    this.checkErrorType = function(data) {

        if (this.checkBlankOrHypen(data)) {
            return "is empty string or hypen";
        } else if (this.checkBooleanType(data)) {
            return "is type of boolean";
        }

    };

    this.priceCondition = function(item) {

        let pp = parseInt(item["Purchase Price"]);
        let sp = parseInt(item["Selling Price"]);
        let mrp = parseInt(item["MRP"]);
        if (pp > sp) {
            return false;
        } else if (mrp < sp) {
            return false;
        }
        return true;

    }

    this.inclusivePriceAndSlabCondition = function(item) {

        if (item["PP Tax Inclusive"].toLowerCase() == "yes" && item["SP Tax Inclusive"].toLowerCase() == "yes") {

            if (!this.checkBlankOrHypen(item["Slab"])) {
                return false;
            }
        }
        return true;
    }

    this.gstAndSlabCondition = function(item) {
        if (!this.checkBlankOrHypen(item["GST Purchase Taxes%"]) && !this.checkBlankOrHypen(item["GST Sales Taxes%"])) {

            if (!this.checkBlankOrHypen(item["Slab"])) {
                return false;
            }
        }
        return true;
    }

};

module.exports = new importHelpCtrl();