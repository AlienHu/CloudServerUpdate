let mobileStoreImport = function() {
    const refItem = require('./mobileStoreRefItem');
    const importHelperCtrl = require('./importCsvHelper');
    const Utils = require('../../../common/Utils');
    const logger = require("../../../common/Logger");

    let firstLevelFields = {
        "uniqueItemCode": "Item Code",
        "name": "Name",
        "item_number": "Barcode",
        "description": "Description",
        "bPPTaxInclusive": "PP Tax Inclusive",
        "bSPTaxInclusive": "SP Tax Inclusive",
        "reorderLevel": "Reorder Level",
        "reorderQuantity": "Reorder Quantity",
        "bOTG": "OTG",
        "hsn": "HSN"
    };

    function setDefaultFields(pgItem) {

        //receiving_quantity 
        pgItem.receiving_quantity = 0;

        //reorder_level 
        pgItem.reorder_level = 0;

        //expiry_date
        pgItem.expiry_date = "";

        // allow_alt_description
        pgItem.allow_alt_description = "0";

        //ItemType
        pgItem.ItemType = "";

        //purchasePrice 
        pgItem.purchasePrice = "";

        //sellingPrice
        pgItem.sellingPrice = "";

        //mrp
        pgItem.mrp = "",

            // isNewBatch 
            pgItem.isNewBatch = false;

        //hasMeasurementUnit 
        pgItem.hasMeasurementUnit = false;

        // density
        pgItem.density = 0;

        // pricingProfiles 
        pgItem.pricingProfiles = false;

        // multipleUnits
        pgItem.multipleUnits = false;

        // itemNprice 
        pgItem.itemNprice = 0;

        // purchaseUnitId 
        pgItem.purchaseUnitId = 0;

        // sellingUnitId 
        pgItem.sellingUnitId = 0;

        // isprepared 
        pgItem.isprepared = false;

        // issellable 
        pgItem.issellable = false;

        // isbought 
        pgItem.isbought = false;

        // is_deleted
        pgItem.is_deleted = "";

        // discount_expiry 
        pgItem.discount_expiry = null;

        // employeeId 
        pgItem.employeeId = "admin";
    }

    function formsUnitInfo(item, unitName, index, excelColumns, itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr,
        categoryObj, variantObj, taxObj, slabObj, supplierObj, unitObj, pprofileObj, discountObj) {
        let ptemp = {};

        //selling price
        if (excelColumns["Selling Price"] === 0) {
            ptemp["sellingPrice"] = 0;
        } else if (!(isNaN(parseInt(item["Selling Price"]))) && !(importHelperCtrl.checkBlankOrHypen(item["Selling Price"])) &&
            !(importHelperCtrl.checkBlankOrHypen(item["Selling Price"]))) {
            ptemp["sellingPrice"] = parseFloat(item["Selling Price"]);
            console.log("ptemp[sellingPrice]:" + ptemp["seelingPrice"]);
            console.log("\n")
        } else if (excelColumns["Selling Price"] === 1) {
            let error = importHelperCtrl.checkErrorType(item["Selling Price"]);

            if (!importHelperCtrl.checkNumberType(item["Selling Price"])) {
                error = "is not type of Number";
            }
            error = "at line:" + (index + 2) + " Selling Price " + error;
            csvDataErrorsArray.push(error);
        }

        // discount
        if (excelColumns["Discount %"] === 0) {
            ptemp["discountId"] = "";
        } else if (excelColumns["Discount %"] === 1 && !(isNaN(parseInt(item["Discount %"]))) && !(importHelperCtrl.checkBlankOrHypen(item["Discount %"])) &&
            !(importHelperCtrl.checkBlankOrHypen(item["Discount %"]))) {
            let discount = item["Discount %"];
            if (!isNaN(discount)) {
                ptemp["discountId"] = discountObj[discount];
            }
        } else if (excelColumns["Discount %"] === 1) {

            let error = importHelperCtrl.checkErrorType(item["Discount %"]);

            if (!importHelperCtrl.checkNumberType(item["Discount %"])) {
                error = "is not type of Number, please enter number only";
            }
            error = "at line:" + (index + 2) + " Discount % " + error;
            csvDataErrorsArray.push(error);
        }

        let pProfilesData = {};
        let profile1 = pprofileObj["profile 1"];
        pProfilesData[profile1] = ptemp;

        let unitInfo = {};
        let id = unitObj[unitName];

        let tempObj = {};
        tempObj["refUnitId"] = id;
        tempObj["factor"] = 1;

        //purchase price
        if (excelColumns["Purchase Price"] === 0) {
            tempObj["purchasePrice"] = 0;
        } else if (excelColumns["Purchase Price"] === 1 && !(isNaN(parseInt(item["Purchase Price"]))) && !(importHelperCtrl.checkBlankOrHypen(item["Purchase Price"])) &&
            !(importHelperCtrl.checkBlankOrHypen(item["Purchase Price"]))) {
            tempObj["purchasePrice"] = parseInt(item["Purchase Price"]);
        } else if (excelColumns["Purchase Price"] === 1) {
            let error = importHelperCtrl.checkErrorType(item["Purchase Price"]);

            if (!importHelperCtrl.checkNumberType(item["Purchase Price"])) {
                error = "is not type of Number";
            }
            error = "at line:" + (index + 2) + " Purchase Price " + error;
            csvDataErrorsArray.push(error);
        }

        if (excelColumns["MRP"] === 0) {
            tempObj["mrp"] = 0;
        } else if (excelColumns["MRP"] === 1 && !(isNaN(parseInt(item["MRP"]))) && !(importHelperCtrl.checkBlankOrHypen(item["MRP"])) &&
            !(importHelperCtrl.checkBlankOrHypen(item["MRP"]))) {
            tempObj["mrp"] = parseInt(item["MRP"]);
        } else if (excelColumns["MRP"] === 1) {
            let error = importHelperCtrl.checkErrorType(item["MRP"]);

            if (!importHelperCtrl.checkNumberType(item["MRP"])) {
                error = "is not type of Number";
            }
            error = "at line:" + (index + 2) + " MRP " + error;
            csvDataErrorsArray.push(error);
        }

        tempObj["pProfilesData"] = pProfilesData;
        unitInfo[id] = tempObj;

        return unitInfo;
    }

    function uniqueDetails(item) {
        let tempObj = {};
        let imeiNumbers = [];
        if (parseInt(item["IMEI Count"]) > 1) {
            let Numbers = item["IMEI Number"].split("-");
            for (let p = 0; p < Numbers.length; p++) {
                imeiNumbers.push(parseInt(Numbers[p]));
            }

        } else if (parseInt(item["IMEI Count"]) === 1) {
            imeiNumbers.push(parseInt(item["IMEI Number"]));
        }
        tempObj["serialnumber"] = item["Serial Number"];
        tempObj["imeiNumbers"] = imeiNumbers;

        return tempObj;
    }

    function formsInitialStock(item, index, excelColumns, itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr,
        categoryObj, variantObj, taxObj, slabObj, supplierObj, unitObj, pprofileObj, discountObj) {

        console.log("calling formsInitialStock" + JSON.stringify(formsInitialStock));
        console.log("\n\n");
        // [{"batchId": "batch103",
        // "quantity": 3,
        // "expiry": "2018-02-27T18:30:00.000Z",
        // "uniqueDetails": [{
        //         "imeiNumbers": [
        //             785785767655774,
        //             576596986986698
        //         ],
        //         "serialnumber": "7678"
        //     },
        //     {
        //         "imeiNumbers": [
        //             97907423740079,
        //             678320039999999
        //         ],
        //         "serialnumber": "784230009890"
        //     },
        //     {
        //         "imeiNumbers": [
        //             765765765764442,
        //             422229099877997
        //         ],
        //         "serialnumber": "762889999ybhujj"
        //     }
        // ]
        let initStock = {};

        //quantity, set default values and check values
        if (excelColumns["Quantity"] === 0) {
            initStock["quantity"] = 0;
        } else if (excelColumns["Quantity"] === 1 && !isNaN(parseInt(item["Quantity"])) && !(importHelperCtrl.checkBooleanType(item["Quantity"])) &&
            !(importHelperCtrl.checkBlankOrHypen(item["Quantity"]))) {
            initStock["quantity"] = parseInt(item["Quantity"]);
        } else if (excelColumns["Quantity"] === 1) {
            let error = importHelperCtrl.checkErrorType(item["Quantity"]);

            if (!importHelperCtrl.checkNumberType(item["Quantity"])) {
                error = "is not type of Number";
            }
            error = "at line:" + (index + 2) + " Quantity " + error;
            csvDataErrorsArray.push(error);
        }

        // batch ID
        if (excelColumns["Batch Id"] === 1 && !(importHelperCtrl.checkBooleanType(item["Batch Id"]))) {
            if (!(importHelperCtrl.checkBlankOrHypen(item["Batch Id"]))) {
                initStock["batchId"] = item["Batch Id"];
            }
        } else if (excelColumns["Batch Id"] === 1) {
            let error = importHelperCtrl.checkErrorType(item["Batch Id"]);
            error = "at line:" + (index + 2) + "Batch Id " + error;
            csvDataErrorsArray.push(error);
        }

        //expiry Date, check column, and type validation
        if (excelColumns["Expiry Date"] === 0) {
            initStock["expiry"] = null;
        } else {

            if (!(importHelperCtrl.checkBlankOrHypen(item["Expiry Date"])) &&
                !(importHelperCtrl.checkBooleanType(item["Expiry Date"]))) {
                initStock["expiry"] = item["Expiry Date"];
            }
        }

        let quantitySize = parseInt(item["Quantity"]);

        let uniqueDetailsArray = [];

        //uniqueDetails
        for (let k = index; k < (index + quantitySize); k++) {
            uniqueDetailsArray.push(uniqueDetails(itemsArray[k]));
            console.log("uniqueDetails(itemsArray[k]))" + JSON.stringify(uniqueDetails(itemsArray[k])));
            console.log("\n\n");
        }

        initStock["uniqueDetails"] = uniqueDetailsArray;
        // initiliazing the unitInfo
        initStock["unitsInfo"] = formsUnitInfo(item, "Pkt", index, excelColumns, itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr,
            categoryObj, variantObj, taxObj, slabObj, supplierObj, unitObj, pprofileObj, discountObj);

        console.log("initStock:" + initStock);
        return initStock;

    }

    let csvDataErrorsArray = [];

    this.createItemArray = async function(excelColumns, itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr,
        categoryObj, variantObj, taxObj, slabObj, supplierObj, unitObj, pprofileObj, discountObj) {
        let itemController = require('../../Items');

        let index = 0;

        for (let i = 0; i < itemsArray.length; i += index) {
            let pgItem = {
                initialStock: []
            };
            let purchaseTax = [];
            let salesTax = [];

            let size = parseInt(itemsArray[i]["Quantity"]);
            index = size;

            // keys
            let firstLevelKeys = Object.keys(firstLevelFields);

            //values
            let firstLevelValues = Object.values(firstLevelFields);

            //first level fields of csv file
            for (let k = 0; k < firstLevelKeys.length; k++) {

                //checking column exist or not and if not assign default value
                if (excelColumns[firstLevelValues[k]] === 0) {
                    if (firstLevelValues[k] === "Item Code" || firstLevelValues[k] === "Barcode" ||
                        firstLevelValues[k] === "Description" || firstLevelValues[k] === "Reorder Level" ||
                        firstLevelValues[k] === "Reorder Quantity" || firstLevelValues[k] === "HSN") {
                        pgItem[firstLevelKeys[k]] = "";
                    } else if (firstLevelValues[k] === "PP Tax Inclusive" || firstLevelValues[k] === "SP Tax Inclusive" ||
                        firstLevelValues[k] === "OTG") {
                        pgItem[firstLevelKeys[k]] = false;
                    }
                    continue;
                }

                if (itemsArray[i][firstLevelValues[k]].toLowerCase() === 'no') {
                    //bPP taxInclusive,bSP taxInclusive,bOTG
                    pgItem[firstLevelKeys[k]] = false;
                    continue;
                } else if (itemsArray[i][firstLevelValues[k]].toLowerCase() === 'yes') {
                    //bPP taxInclusive,bSP taxInclusive,bOTG
                    pgItem[firstLevelKeys[k]] = true;
                    continue;
                } else if (!isNaN(parseInt(itemsArray[i][firstLevelValues[k]])) && firstLevelValues[k] !== "HSN" && firstLevelValues[k] !== "Item Code" && firstLevelValues[k] !== "Barcode") {
                    //selling price, purchase price, mrp
                    pgItem[firstLevelKeys[k]] = parseInt(itemsArray[i][firstLevelValues[k]]);
                    continue;
                }

                // if values are right, will assign to item; 
                pgItem[firstLevelKeys[k]] = itemsArray[i][firstLevelValues[k]];

            }

            //Supplier id, column check , type validation
            if (excelColumns["Supplier Name"] === 1 && isNaN(parseInt(itemsArray[i]["Supplier Name"])) && !(importHelperCtrl.checkBooleanType(itemsArray[i]["Supplier Name"])) &&
                !(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["Supplier Name"]))) {
                pgItem.supplier_id = supplierObj[itemsArray[i]["Supplier Name"]];
            } else if (excelColumns["Supplier Name"] === 1) {
                let error = importHelperCtrl.checkErrorType(itemsArray[i]["Supplier Name"]);
                if (importHelperCtrl.checkNumberType(itemsArray[i]["Supplier Name"])) {
                    error = "is type of Number";
                }
                error = "at line:" + (i + 2) + " Supplier Name " + error;
                csvDataErrorsArray.push(error);
            }

            //Category id,  column check , type validation
            if (excelColumns["Category Name"] === 1 && isNaN(parseInt(itemsArray[i]["Category Name"])) && !(importHelperCtrl.checkBooleanType(itemsArray[i]["Category Name"])) &&
                !(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["Category Name"]))) {
                pgItem.categoryId = categoryObj[itemsArray[i]["Category Name"]];
            } else if (excelColumns["Category Name"] === 0) {
                pgItem.categoryId = categoryObj["General"];
            } else if (excelColumns["Category Name"] === 1) {
                let error = importHelperCtrl.checkErrorType(itemsArray[i]["Category Name"]);
                if (importHelperCtrl.checkNumberType(itemsArray[i]["Category Name"])) {
                    error = "is type of Number";
                }

                error = "at line:" + (i + 2) + " Category Name " + error;
                csvDataErrorsArray.push(error);
            }

            //purchase Slab id,  column check , type validation
            if (excelColumns["Slab"] === 1 && isNaN(parseInt(itemsArray[i]["Slab"])) && !(importHelperCtrl.checkBooleanType(itemsArray[i]["Slab"])) &&
                !(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["Slab"]))) {
                pgItem.purchaseSlab = slabObj[itemsArray[i]["Slab"]];
            } else if (excelColumns["Slab"] === 1) {
                let error = importHelperCtrl.checkErrorType(itemsArray[i]["Slab"]);
                if (importHelperCtrl.checkNumberType(itemsArray[i]["Slab"])) {
                    error = "is type of Number";
                }
                error = "at line:" + (i + 2) + " Slab " + error;
                csvDataErrorsArray.push(error);
            }

            //sales Slab Id,  column check , type validation
            if (excelColumns["Slab"] === 1 && isNaN(parseInt(itemsArray[i]["Slab"])) && !(importHelperCtrl.checkBooleanType(itemsArray[i]["Slab"])) &&
                !(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["Slab"]))) {
                pgItem.salesSlab = slabObj[itemsArray[i]["Slab"]];
            } else if (excelColumns["Slab"] === 1) {
                let error = importHelperCtrl.checkErrorType(itemsArray[i]["Slab"]);
                if (importHelperCtrl.checkNumberType(itemsArray[i]["Slab"])) {
                    error = "is type of Number";
                }

                error = "at line:" + (i + 2) + " Slab " + error;
                csvDataErrorsArray.push(error);
            }

            //is_serialized
            if (excelColumns["Serial Number"] === 1 && !(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["Serial Number"]))) {
                pgItem.is_serialized = true;
            } else {
                pgItem.is_serialized = false;
            }

            //imeiCount 
            if (excelColumns["IMEI Count"] === 1 && !(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["IMEI Count"]))) {
                pgItem.imeiCount = parseInt(itemsArray[i]["IMEI Count"]);
            } else {
                pgItem.imeiCount = 0;
            }

            //imeNumbers 
            pgItem.imeNumbers = [];

            // some of the fields are necessary but don't use anywhere, so they have been filled in this function
            setDefaultFields(pgItem);

            // baseUnitId
            if (excelColumns["Unit Name"] === 1) {
                pgItem.baseUnitId = parseInt(unitObj["Pkt"]);
            }

            // defaultSellingUnitId 
            pgItem.defaultSellingUnitId = parseInt(unitObj["Pkt"]);

            // defaultPurchaseUnitId 
            pgItem.defaultPurchaseUnitId = parseInt(unitObj["Pkt"]);

            //sales Tax
            pgItem.salesTaxes = [];

            for (let j = 0; j < salesTaxesHeaderNameArr.length; j++) {
                let headerName = salesTaxesHeaderNameArr[j];
                let taxPercent = itemsArray[i][headerName];
                if (isNaN(taxPercent)) {
                    continue;
                }
                let taxId = taxObj[salesTaxesHeaderNameArr[j] + " " + taxPercent];
                pgItem.salesTaxes.push(taxId);
            }

            //purchase tax
            pgItem.purchaseTaxes = [];
            for (let j = 0; j < purchaseTaxesHeaderNameArr.length; j++) {
                let headerName = purchaseTaxesHeaderNameArr[j];
                let taxPercent = itemsArray[i][headerName];
                if (isNaN(taxPercent)) {
                    continue;
                }
                let taxId = taxObj[purchaseTaxesHeaderNameArr[j] + " " + taxPercent];
                pgItem.purchaseTaxes.push(taxId);
            }

            //has variants default value false 
            pgItem.hasVariants = false;

            // unit info
            if (itemsArray[i]["Unit Name"] == 'Packet') {
                pgItem.unitsInfo = unitObj["Pkt"];
            }

            //default Has batch Number false
            pgItem.hasBatchNumber = false;

            // default has expiry Date false
            pgItem.hasExpiryDate = false;

            //  initialStock

            let initObj = formsInitialStock(itemsArray[i], i, excelColumns, itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr,
                categoryObj, variantObj, taxObj, slabObj, supplierObj, unitObj, pprofileObj, discountObj);
            if (initObj.expiry) {
                // assign has expiry Date true
                pgItem.hasExpiryDate = true;

            }
            if (initObj.batchId) {
                // assign Has batch Number true
                pgItem.hasBatchNumber = true;

            }
            pgItem.initialStock.push(initObj);

            //check SP,MP,PP price condition 
            if (!importHelperCtrl.priceCondition(itemsArray[i])) {
                let error = " please check SP, PP and MRP values";
                error = "at line:" + (i + 1) + error;
                csvDataErrorsArray.push(error);
            }

            //gst And Slab Condition
            if (!importHelperCtrl.gstAndSlabCondition(itemsArray[i])) {
                let error = " GST or Slab anyone be there, but not both";
                error = "at line:" + (i + 1) + error;
                csvDataErrorsArray.push(error);
            }

            //inclusive Price And Slab Condition Condition
            if (!importHelperCtrl.inclusivePriceAndSlabCondition(itemsArray[i])) {
                let error = " Inclusive Price or Slab anyone be there, but not both";
                error = "at line:" + (i + 1) + error;
                csvDataErrorsArray.push(error);
            }

            //attributes
            pgItem.attributes = [];

            //convPurchasePrice
            pgItem.convPurchasePrice = "";

            //units info
            pgItem.unitsInfo = formsUnitInfo(itemsArray[i], "Pkt", i, excelColumns, itemsArray, salesTaxesHeaderNameArr, purchaseTaxesHeaderNameArr,
                categoryObj, variantObj, taxObj, slabObj, supplierObj, unitObj, pprofileObj, discountObj);

            // isWarranty, warranty, warranty terms 
            if (excelColumns["Warranty"] === 1 && excelColumns["Warranty Terms"] === 1) {
                pgItem.warranty = parseInt(itemsArray[i]["Warranty"]);
                if (itemsArray[i]["Warranty Terms"] === "Year") {
                    pgItem.warrantyTerms = "Y";
                }
                pgItem.isWarranty = true;
            } else {
                pgItem.isWarranty = false;
            }

            // imei
            if (excelColumns["IMEI Number"] === 1 && !(importHelperCtrl.checkBlankOrHypen(itemsArray[i]["IMEI Number"]))) {
                pgItem.imei = true;
            } else {
                pgItem.imei = false;
            }

            if (true) {
                let errorsArray = [];
                Utils.findStructDiffAndCopy(refItem, pgItem, [], errorsArray, true);
                logger.error(errorsArray);
                logger.error('Errors Array Length<' + errorsArray.length + '>');
            }

            console.log("\n\npgItem:" + JSON.stringify(pgItem));
            try {
                await itemController.createItem(pgItem);
            } catch (error) {
                console.log("\n\nItemCreate error" + error);
            }
        }
    }

};

module.exports = new mobileStoreImport();