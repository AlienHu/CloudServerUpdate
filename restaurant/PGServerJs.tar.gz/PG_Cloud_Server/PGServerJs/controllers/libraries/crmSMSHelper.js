"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const sendSMS = require("../../sms/sms");
const sendPromoEmail = require("../sendPromoEmail");
const couchDBUtils = require("../common/CouchDBUtils");
const promoKeywords = ['CUSTOMER', 'BIRTHDAY', 'ANNIVERSARY', 'URL'];
const mainDBInstance = couchDBUtils.getMainCouchDB();
const helper = require("../../licencer/licenceHelper");
const utils = require("../../common/Utils");
const alienCampainHelper = require('../../TSControllers/libraries/alienCampaign');
const crm_1 = require("../crm");
const logger = require("../../common/Logger");
let sendEmail = function (doc, customer, message) {
    return __awaiter(this, void 0, void 0, function* () {
        if (doc.sendEmail && customer.email) {
            console.log("*** sending email to " + customer.email);
            let requestData = {
                message: message,
                email: customer.email,
                subject: 'Greetings',
            };
            try {
                yield sendPromoEmail(requestData);
            }
            catch (e) {
                logger.error("warning from sendPromoEmail" + JSON.stringify(e));
            }
        }
    });
};
let notifyAlienUser = function (info, id, type) {
    let params = {
        subject: 'Exciting Offers',
        info: info,
        id: id,
        type: type,
        shopId: '',
        shopName: '',
        shopInfo: {}
    };
    try {
        return alienCampainHelper.sendAlienNotification(params);
    }
    catch (err) {
        logger.error("Alien user notification failed with error " + JSON.stringify(err));
        throw 'notifyAlienUser::Not expected to come here.';
    }
};
/**
 *
 * @param doc campaign.
 * send promos to the customers and returns count of success;
 *
 * send Single/Multiple sms based on the message uses keywords
 */
exports.sendPromos = function (doc) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!doc.customers.length) {
            return;
        }
        //only alienid with no phone number
        let count = 0;
        let params = {
            Type: "PROMO",
            type: 'promo',
            Multiple: false,
            Msg: doc.message,
            To: ''
        };
        let hasKeyword = promoKeywords.some(k => doc.message.includes(k));
        let custKeys = [];
        for (let i = 0; i < doc.customers.length; i++) {
            custKeys.push(doc.customers[i]._id);
        }
        let allCustomers = yield couchDBUtils.getAllDocs(custKeys, mainDBInstance);
        let info = {};
        let alienCustomer = {};
        let type = "Promotionals";
        for (let i = 0; i < allCustomers.length; i++) {
            if (!allCustomers[i].doc || allCustomers[i].error) {
                logger.error("There is a error from customer doc for send SMS : " + doc.customers[i]._id);
                doc.customers[i].smsStatus = crm_1.COMPLETED;
                doc.customers[i].cAppStatus = crm_1.COMPLETED;
                count++;
                continue;
            }
            if (doc.customers[i].smsStatus === crm_1.COMPLETED && doc.customers[i].cAppStatus === crm_1.COMPLETED) {
                count++;
                continue;
            }
            let customer = allCustomers[i].doc;
            params.Msg = doc.message;
            let bBitlyError = false;
            let url;
            if (doc.feedbackFormId && params.Msg.indexOf('URL') > -1) {
                logger.info("*** feedback form found");
                var generate_short_url_payload = {
                    feed_id: doc.feedbackFormId,
                    custumer_id: customer._id.split('_')[1],
                    mac: helper.getServerSerialNum(),
                    app_type: process.env.APP_TYPE,
                    cmp_id: doc._id
                };
                url = `https://profitgurupos.com/user_feedback_view.html?f=${generate_short_url_payload.feed_id}&c=${generate_short_url_payload.custumer_id}&m=${generate_short_url_payload.mac}&a=${generate_short_url_payload.app_type}&s=${generate_short_url_payload.cmp_id}`;
            }
            if (hasKeyword) {
                params.Msg = params.Msg.replace(/CUSTOMER/g, customer.first_name);
                params.Msg = params.Msg.replace(/BIRTHDAY/g, customer.birth_date);
                params.Msg = params.Msg.replace(/ANNIVERSARY/g, customer.anniversary);
                params.To = customer.phone_number;
                if ((!customer.phone_number) || (customer.alienId && customer.phone_number === customer.alienId)) {
                    doc.customers[i].smsStatus = crm_1.COMPLETED;
                }
                if (url) {
                    try {
                        logger.info('full URL ' + url);
                        let shortURL = yield utils.getShortUrl(url);
                        params.Msg = params.Msg.replace(/URL/g, shortURL);
                    }
                    catch (err) {
                        bBitlyError = true;
                        logger.error(err);
                    }
                }
                if (!bBitlyError) {
                    if (customer.alienId && doc.customers[i].cAppStatus !== crm_1.COMPLETED) {
                        info[customer.alienId] = params.Msg;
                        alienCustomer[customer._id] = customer.alienId;
                    }
                    else {
                        doc.customers[i].cAppStatus = crm_1.COMPLETED;
                    }
                    logger.info("*** sending sms" + JSON.stringify(params));
                    if (doc.customers[i].smsStatus !== crm_1.COMPLETED) {
                        try {
                            yield sendSMS(params);
                            doc.customers[i].smsStatus = crm_1.COMPLETED;
                        }
                        catch (error) {
                            logger.error(error);
                            logger.error('sending sms failed. ' + +JSON.stringify(params));
                        }
                        try {
                            //email is optional
                            yield sendEmail(doc, customer, params.Msg);
                        }
                        catch (error) {
                            logger.error("sending mail error from crmSMSHelper" + JSON.stringify(error));
                        }
                    }
                }
                else {
                    logger.error("promos are not sending bcoz bitly failed");
                }
            }
            else {
                if (customer.alienId && doc.customers[i].cAppStatus !== crm_1.COMPLETED) {
                    info[customer.alienId] = doc.message;
                    alienCustomer[customer._id] = customer.alienId;
                }
                else {
                    doc.customers[i].cAppStatus = crm_1.COMPLETED;
                }
                if (!customer.phone_number || (customer.alienId && customer.phone_number === customer.alienId)) {
                    doc.customers[i].smsStatus = crm_1.COMPLETED;
                }
                if (doc.customers[i].smsStatus !== crm_1.COMPLETED) {
                    params.To = params.To ? params.To + ',' + customer.phone_number : customer.phone_number;
                }
            }
        }
        if (!hasKeyword && params.To) {
            params.Msg = doc.message;
            params.Multiple = true;
            let i, j, phoneNos, chunk = 100, length = 0;
            let allPhoneNos = params.To.split(',');
            for (i = 0, j = allPhoneNos.length; i < j; i += chunk) {
                phoneNos = allPhoneNos.slice(i, i + chunk);
                params.To = phoneNos.toString();
                logger.info("*** sending sms chunk " + JSON.stringify(params));
                try {
                    length += phoneNos.length;
                    yield sendSMS(params);
                    for (let k = i; k < length; k++) {
                        doc.customers[k].smsStatus = crm_1.COMPLETED;
                        try {
                            yield sendEmail(doc, allCustomers[k].doc, params.Msg);
                        }
                        catch (error) {
                            logger.error('sending emailfailed. ' + params.Msg);
                        }
                    }
                }
                catch (error) {
                    logger.error(error);
                }
            }
        }
        let campaignResp = [];
        if (Object.keys(info).length) {
            campaignResp = yield notifyAlienUser(info, doc._id, type);
        }
        for (let j = 0; j < doc.customers.length; j++) {
            if (campaignResp.indexOf(alienCustomer[doc.customers[j]._id]) > -1) {
                doc.customers[j].cAppStatus = crm_1.COMPLETED;
            }
            if (doc.customers[j].smsStatus === crm_1.COMPLETED && doc.customers[j].cAppStatus === crm_1.COMPLETED) {
                count++;
            }
        }
        return count;
    });
};
//pending cases
//1. sendsms bulk .. if out of 100, 5 fails, what is the response?
//2. sendsms single.. when will it throw?
//# sourceMappingURL=crmSMSHelper.js.map