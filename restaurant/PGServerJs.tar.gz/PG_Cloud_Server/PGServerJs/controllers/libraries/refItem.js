// let jsonObj = {
//     "uniqueItemCode": "566889877",
//     "name": "Levis 444",
//     "item_number": "893777",
//     "receiving_quantity": 0,
//     "reorder_level": 0,
//     "description": "Clothes",
//     "supplier_id": 1517463738354,
//     "expiry_date": "",
//     "allow_alt_description": "0",
//     "ItemType": "",
//     "categoryId": 1517463536794,
//     "purchasePrice": "",
//     "sellingPrice": "",
//     "mrp": "",
//     "hasMeasurementUnit": false,
//     "is_serialized": false,
//     "hasExpiryDate": true,
//     "purchaseTaxes": [
//         1517463768322
//     ],
//     "salesTaxes": [
//         1517463768322
//     ],
//     "reorderLevel": 10,
//     "reorderQuantity": 90,
//     "isNewBatch": false,
//     "hasBatchNumber": true,
//     "bOTG": true,
//     "bPPTaxInclusive": false,
//     "bSPTaxInclusive": false,
//     "imeiCount": 0,
//     "imeNumbers": [],
//     "initialStock": [{
//             "quantity": 10,
//             "batchId": "batch101",
//             "expiry": "2018-02-27T18:30:00.000Z",
//             "unitsInfo": {
//                 "1517461610631": {
//                     "refUnitId": 1517461610631,
//                     "factor": 1,
//                     "purchasePrice": 1000,
//                     "mrp": 1200,
//                     "pProfilesData": {
//                         "1517461608107": {
//                             "sellingPrice": 1200,
//                             "discountId": 1517462412064
//                         }
//                     }
//                 }
//             },
//             "attributeInfo": {
//                 "1": "1",
//                 "2": "1"
//             },
//             "skuName": "blue/36"
//         },
//         {
//             "quantity": 4,
//             "batchId": "batch102",
//             "expiry": "2018-02-27T18:30:00.000Z",
//             "unitsInfo": {
//                 "1517461607081": {
//                     "refUnitId": 1517461607081,
//                     "factor": 1,
//                     "purchasePrice": 200,
//                     "mrp": 400,
//                     "pProfilesData": {
//                         "1517461608107": {
//                             "sellingPrice": 400,
//                             "discountId": 1517462420926
//                         }
//                     }
//                 }
//             },
//             "attributeInfo": {
//                 "1": "2",
//                 "2": "2"
//             },
//             "skuName": "brown/30"
//         },
//         {
//             "quantity": 6,
//             "batchId": "batch103",
//             "expiry": "2018-02-27T18:30:00.000Z",
//             "unitsInfo": {
//                 "1517461607081": {
//                     "refUnitId": 1517461607081,
//                     "factor": 1,
//                     "purchasePrice": 800,
//                     "mrp": 900,
//                     "pProfilesData": {
//                         "1517461608107": {
//                             "sellingPrice": 900,
//                             "discountId": 1517462427863
//                         }
//                     }
//                 }
//             },
//             "attributeInfo": {
//                 "1": "3",
//                 "2": "3"
//             },
//             "skuName": "white/32"
//         }
//     ],
//     "unitsInfo": {
//         "1517461610631": {
//             "refUnitId": 1517461610631,
//             "factor": 1,
//             "purchasePrice": 1000,
//             "mrp": 1200,
//             "pProfilesData": {
//                 "1517461608107": {
//                     "sellingPrice": 1200,
//                     "discountId": 1517462412064
//                 }
//             }
//         },
//         "1517461607081": {
//             "refUnitId": 1517461607081,
//             "factor": 1,
//             "purchasePrice": 800,
//             "mrp": 900,
//             "pProfilesData": {
//                 "1517461608107": {
//                     "sellingPrice": 900,
//                     "discountId": 1517462427863
//                 }
//             }
//         }
//     },
//     "hasVariants": true,
//     "density": 0,
//     "pricingProfiles": false,
//     "multipleUnits": false,
//     "itemNprice": 0,
//     "baseUnitId": 1517461607081,
//     "attributes": [
//         1,
//         2
//     ],
//     "salesSlab": 1517462530856,
//     "hsn": "1000HSN",
//     "defaultSellingUnitId": 1517461607081,
//     "defaultPurchaseUnitId": 1517461607081,
//     "purchaseSlab": 1517462530856,
//     "purchaseUnitId": 0,
//     "sellingUnitId": 0,
//     "isprepared": false,
//     "issellable": false,
//     "isbought": false,
//     "is_deleted": "",
//     "discount_expiry": null,
//     "employeeId": "admin"
// }

let jsonObj = {
    "uniqueItemCode": "566889877",
    "name": "Levis",
    "item_number": "893777",
    "description": "",
    "supplier_id": 1517463738354,
    "ItemType": "Normal",
    "categoryId": 1517463536794,
    "is_serialized": false,
    "hasExpiryDate": true,
    "purchaseTaxes": [],
    "salesTaxes": [],
    "reorderLevel": 0,
    "reorderQuantity": 0,
    "hasBatchNumber": true,
    "bOTG": true,
    "bPPTaxInclusive": false,
    "bSPTaxInclusive": false,
    "imeiCount": 0,
    "imeNumbers": [],
    "initialStock": [{
            "quantity": 10,
            "batchId": "batch101",
            "expiry": "2018-02-27T18:30:00.000Z",
            "unitsInfo": {
                "1517461610631": {
                    "refUnitId": 1517461610631,
                    "factor": 1,
                    "purchasePrice": 1000,
                    "mrp": 1200,
                    "pProfilesData": {
                        "1517461608107": {
                            "sellingPrice": 1200,
                            "discountId": 1517462412064
                        }
                    }
                }
            },
            "attributeInfo": {
                "1": "1",
                "2": "1"
            },
            "skuName": "blue/36"
        },
        {
            "quantity": 4,
            "batchId": "batch102",
            "expiry": "2018-02-27T18:30:00.000Z",
            "unitsInfo": {
                "1517461607081": {
                    "refUnitId": 1517461607081,
                    "factor": 1,
                    "purchasePrice": 200,
                    "mrp": 400,
                    "pProfilesData": {
                        "1517461608107": {
                            "sellingPrice": 400,
                            "discountId": 1517462420926
                        }
                    }
                }
            },
            "attributeInfo": {
                "1": "2",
                "2": "2"
            },
            "skuName": "brown/30"
        },
        {
            "quantity": 6,
            "batchId": "batch103",
            "expiry": "2018-02-27T18:30:00.000Z",
            "unitsInfo": {
                "1517461607081": {
                    "refUnitId": 1517461607081,
                    "factor": 1,
                    "purchasePrice": 800,
                    "mrp": 900,
                    "pProfilesData": {
                        "1517461608107": {
                            "sellingPrice": 900,
                            "discountId": 1517462427863
                        }
                    }
                }
            },
            "attributeInfo": {
                "1": "3",
                "2": "3"
            },
            "skuName": "white/32"
        }
    ],
    "unitsInfo": {
        "1517461610631": {
            "refUnitId": 1517461610631,
            "factor": 1,
            "purchasePrice": 1000,
            "mrp": 1200,
            "pProfilesData": {
                "1517461608107": {
                    "sellingPrice": 1200,
                    "discountId": 1517462412064
                }
            }
        },
        "1517461607081": {
            "refUnitId": 1517461607081,
            "factor": 1,
            "purchasePrice": 800,
            "mrp": 900,
            "pProfilesData": {
                "1517461608107": {
                    "sellingPrice": 900,
                    "discountId": 1517462427863
                }
            }
        }
    },
    "hasVariants": true,
    "density": 0,
    "pricingProfiles": false,
    "multipleUnits": false,
    "baseUnitId": 1517461607081,
    "attributes": [
        1,
        2
    ],
    "salesSlab": 1517462530856,
    "hsn": "1000HSN",
    "defaultSellingUnitId": 1517461607081,
    "defaultPurchaseUnitId": 1517461607081,
    "purchaseSlab": 1517462530856,
    "isprepared": false,
    "issellable": false,
    "isbought": false
}

module.exports = jsonObj;