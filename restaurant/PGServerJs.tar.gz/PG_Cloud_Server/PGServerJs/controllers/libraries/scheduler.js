"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const cron = require("cron");
const moment = require("moment");
const logger = require("../../common/Logger");
const couchDBUtils = require("../common/CouchDBUtils");
const crmSMSHelper = require("./crmSMSHelper");
const sendReport_1 = require("./sendReport");
const crm_1 = require("../crm");
const scheduleCampaignHelper = require("./scheduleCampaignHelper");
const mainDBInstance = couchDBUtils.getMainCouchDB();
const coreDBInstance = couchDBUtils.getCoreCouchDB();
const RETRY_TIME_INTR_IN_MIN = 2;
let JOB_FREQUENCY = 60; //in seconds
const MAX_RETRY_COUNT = 3;
let MAX_RETRY_COUNT_STR = MAX_RETRY_COUNT.toString();
if (MAX_RETRY_COUNT < 10) {
    MAX_RETRY_COUNT_STR = '0' + MAX_RETRY_COUNT_STR;
}
exports.setJobFrequency = function (f) {
    if (f === JOB_FREQUENCY) {
        return;
    }
    JOB_FREQUENCY = f;
    job.stop();
    job = new cron.CronJob({
        cronTime: '*/' + JOB_FREQUENCY + ' * * * * *',
        // cronTime: '* * * * * *',
        onTick: onTick,
        start: false,
        timeZone: 'Asia/Colombo'
    });
    job.start();
};
function getAllPendingCampaigns(viewName) {
    return __awaiter(this, void 0, void 0, function* () {
        // http://localhost:5984/pg_collection_retail_maindb/_design/crm/_view/pending_cmp?endkey="11-2518766603776"
        let params = {
            endkey: MAX_RETRY_COUNT_STR,
            include_docs: true
        };
        let results = yield couchDBUtils.getView('crm', viewName, params, mainDBInstance);
        return results;
    });
}
let bPause = false;
exports.pause = function pause() {
    bPause = true;
};
exports.play = function play() {
    bPause = false;
};
let job = new cron.CronJob({
    cronTime: '*/' + JOB_FREQUENCY + ' * * * * *',
    // cronTime: '* * * * * *',
    onTick: onTick,
    start: false,
    timeZone: 'Asia/Colombo'
});
exports.isRunning = function () {
    return job.running;
};
exports.startJob = function () {
    if (!job.running) {
        logger.info("Scheduler started");
        job.start();
    }
    else {
        logger.info("Scheduler is running");
    }
};
let bInTick = false;
function onTick() {
    return __awaiter(this, void 0, void 0, function* () {
        if (bInTick) {
            logger.info('Processing.. come later');
            return;
        }
        bInTick = true;
        try {
            logger.info('*** job onTick');
            if (bPause) {
                return true;
            }
            yield processAutoReporter();
            let isEnableSMS = yield getEnableSMS();
            if (isEnableSMS) {
                yield processCampaigns();
                yield processScheduledCampaigns();
                yield processWisher();
            }
            else {
                logger.info("sms enable is " + isEnableSMS);
            }
            yield killSelf();
        }
        catch (error) {
            logger.error(error);
            logger.error('onTick catch block');
        }
        finally {
            bInTick = false;
        }
    });
}
function killSelf() {
    return __awaiter(this, void 0, void 0, function* () {
        let allFuturePendingCapaigns = yield getAllPendingCampaigns('pending_cmp');
        let allpendingSchedules = yield getAllPendingCampaigns('pending_schedules');
        let allPendingWishers = yield getAllPendingCampaigns('pending_wishers');
        let allAutoReporter = yield getAllPendingCampaigns('pending_auto_reporter');
        if (allFuturePendingCapaigns.length === 0 && allpendingSchedules.length === 0 && allPendingWishers.length === 0 && allAutoReporter.length === 0) {
            logger.info('*** job stopping');
            job.stop();
        }
    });
}
function getBdayCustomers(type, startDate, endDate) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let customerDocArr = yield couchDBUtils.getAllDocsByType('customer', mainDBInstance);
            let start = moment(startDate);
            let end = moment(endDate);
            let bcArr = [];
            customerDocArr.forEach(item => {
                let cus = item.doc;
                if (!cus[type] || cus.deleted) {
                    return;
                }
                let eDate = moment(cus[type]);
                if (eDate >= start && eDate <= end) {
                    bcArr.push({
                        _id: cus._id,
                        smsStatus: 'pending',
                        email: cus.email,
                        cAppStatus: 'pending'
                    });
                }
            });
            return bcArr;
        }
        catch (e) {
            throw e;
        }
    });
}
/**
 * step2: update doc with acampaign for today .. step1: check the doc if it has acampaign for today
 * schCmp._id = 'aschedule_' + doc._id + '_' + ts_date; this will autofail in step 3
 * add schedule in wish doc only and make the prev schedule empty
*/
function processWisher() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let ts = moment().startOf('day').toISOString();
            let day = parseInt(moment().format('e'));
            let allPendingWishers = yield getAllPendingCampaigns('pending_wishers');
            allPendingWishers.forEach((element) => __awaiter(this, void 0, void 0, function* () {
                let doc = element.doc;
                if (doc.dayOfWeekArr.indexOf(day) === -1) {
                    return;
                }
                if (doc.startDate && doc.startDate === ts) {
                    return;
                }
                let daysBefore = doc.daysBefore;
                if (doc.onType === "true") {
                    daysBefore = 0; // send sms only on birthdays
                }
                let start = ts;
                let end = moment().add(daysBefore, 'days').endOf('day').toISOString();
                doc.startDate = start;
                doc.endDate = moment().endOf('day').toISOString(); // schedule only per day; comment this to test
                //doc.endDate = moment().add(daysBefore, 'days').endOf('day').toISOString(); // uncomment this to test
                if (doc.onType === "false") {
                    if (doc.repeat === "false") {
                        logger.info("*** send sms only once");
                        start = moment().add(daysBefore, 'days').startOf('day').toISOString();
                    }
                    else {
                        if (doc.period === 'week') {
                            start = moment().add(1, 'weeks').startOf('week').toISOString();
                            end = moment().add(1, 'weeks').endOf('week').toISOString();
                        }
                        if (doc.period === 'month') {
                            start = moment().add(1, 'months').startOf('month').toISOString();
                            end = moment().add(1, 'months').endOf('month').toISOString();
                        }
                    }
                }
                doc.customers = yield getBdayCustomers(doc.type, start, end);
                if (!doc.customers.length) {
                    logger.info("*** No customers found for wisher");
                }
                scheduleCampaignHelper.generateSchedules(doc);
                console.log("Updated wisher" + JSON.stringify(doc, null, 2));
                doc.scheduleStatusArr.forEach(function (item) {
                    let d = new Date(parseInt(item.timestamp));
                    console.log(d);
                });
                yield couchDBUtils.update(doc, mainDBInstance);
            }));
        }
        catch (e) {
            throw e;
        }
    });
}
/**
 * Reports can send @4 am or when he start the application
 * for weeklky get the reports of the days he selected the days starts 0-6
 * for monthly and daily has to send properly
 * if reporter has all the 3 selected then he must get all
 *
 * monthly shoud get once in a month
 * weekly only one in the week
 */
function processAutoReporter() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let now = moment();
            let currentMonth = now.month();
            let currentWeek = now.week();
            let currentDay = now.date();
            let endOfMonth = now.endOf("month").date();
            let reportTime = moment('04:00 am', "HH:mm a");
            if (now.diff(reportTime) < 0) {
                return;
            }
            let allPendingReporter = yield getAllPendingCampaigns('pending_auto_reporter');
            let docArray = [];
            for (let i = 0; i < allPendingReporter.length; i++) {
                let doc = allPendingReporter[i].doc;
                let bUpdate = false;
                if (doc.monthly && doc.currentMonth !== currentMonth) {
                    // send monthly report
                    if (doc.dayOfMonth < endOfMonth && doc.dayOfMonth === currentDay) {
                        // the date is available in this month
                        logger.info("sending monthly report");
                        yield sendReport_1.sendReport('monthly', doc.emailArr, {}, undefined);
                        doc.currentMonth = currentMonth;
                        bUpdate = true;
                    }
                    else if (endOfMonth === currentDay) {
                        logger.info("selected day is not available in this month sending end of month");
                        logger.info("sending monthly report");
                        yield sendReport_1.sendReport('monthly', doc.emailArr, {}, undefined);
                        doc.currentMonth = currentMonth;
                        bUpdate = true;
                    }
                }
                if (doc.weekly && doc.currentWeek !== currentWeek) {
                    // send weekly report
                    logger.info("sending weekly report");
                    yield sendReport_1.sendReport('weekly', doc.emailArr, {}, doc.dayOfWeekArr);
                    doc.currentWeek = currentWeek;
                    bUpdate = true;
                }
                if (doc.daily && doc.currentDay !== currentDay) {
                    // send daily report
                    logger.info("sending daily report");
                    yield sendReport_1.sendReport('daily', doc.emailArr, {}, undefined);
                    doc.currentDay = currentDay;
                    bUpdate = true;
                }
                if (bUpdate) {
                    docArray.push(doc);
                }
            }
            yield couchDBUtils.bulkDocs(docArray, mainDBInstance);
        }
        catch (e) {
            logger.error('OnTick processAutoReporter Error');
            logger.error(e);
            // throw e; // not throwing error, it may block the other schedulers stop working
        }
    });
}
function processCampaigns() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let ts = moment().format('x');
            let allpendingCampaigns = yield getAllPendingCampaigns('pending_cmp');
            if (!allpendingCampaigns.length) {
                return; // kill the scheduler???
            }
            let docArray = [];
            for (let i = 0; i < allpendingCampaigns.length; i++) {
                let cmp = allpendingCampaigns[i];
                if (cmp.value > ts) {
                    //future campaign so skipping
                    continue;
                }
                let doc = cmp.doc;
                let totalC = doc.customers ? doc.customers.length : 0;
                let count = yield crmSMSHelper.sendPromos(doc);
                if (totalC === count) {
                    doc.status = crm_1.COMPLETED;
                }
                else {
                    doc.nextTime = moment().add(RETRY_TIME_INTR_IN_MIN, 'minutes').format('x');
                    doc.retryCount = doc.retryCount ? doc.retryCount + 1 : 1;
                    if (doc.retryCount >= MAX_RETRY_COUNT) {
                        doc.status = 'failed';
                    }
                }
                docArray.push(doc);
            }
            //bulk update
            yield couchDBUtils.bulkDocs(docArray, mainDBInstance);
        }
        catch (error) {
            logger.error(error);
            logger.error('OnTick Campaigns Error');
            throw error;
        }
    });
}
function processScheduledCampaigns() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let ts = moment().format('x');
            let allpendingSchedules = yield getAllPendingCampaigns('pending_schedules');
            if (!allpendingSchedules.length) {
                return; // kill the scheduler???
            }
            let docArray = [];
            // run for all pending schedules
            for (let i = 0; i < allpendingSchedules.length; i++) {
                let schedule = allpendingSchedules[i];
                if (schedule.value > ts) {
                    //future campaign so skipping
                    continue;
                }
                let doc = schedule.doc;
                let totalC = doc.customers ? doc.customers.length : 0;
                let count = yield crmSMSHelper.sendPromos(doc);
                doc.nextTime = getNextScheduledTime(doc, totalC === count);
                docArray.push(doc);
            }
            //bulk update
            yield couchDBUtils.bulkDocs(docArray, mainDBInstance);
        }
        catch (error) {
            logger.error(error);
            logger.error('OnTick Scheduled Campaigns Error');
            throw error;
        }
    });
}
function getEnableSMS() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let settings = yield couchDBUtils.getDocEx('profitGuruApplicationSettings_', coreDBInstance);
            return settings.enableSMS.value;
        }
        catch (e) {
            logger.error("error from getEnableSMS");
            logger.error(e);
        }
    });
}
function resetCusStatus(cmpCusArr) {
    cmpCusArr.forEach(cus => {
        cus.smsStatus = 'pending';
        cus.cAppStatus = 'pending';
    });
}
function getNextScheduledTime(doc, bCompleted) {
    let nextTime;
    for (let i = 0; i < doc.scheduleStatusArr.length; i++) {
        if (doc.scheduleStatusArr[i].status === crm_1.PENDING) {
            doc.retryCount = doc.retryCount ? doc.retryCount + 1 : 1;
            if (bCompleted) {
                doc.scheduleStatusArr[i].status = crm_1.COMPLETED;
            }
            else if (doc.retryCount >= MAX_RETRY_COUNT) {
                doc.scheduleStatusArr[i].status = crm_1.FAILED;
            }
            nextTime = moment().add(RETRY_TIME_INTR_IN_MIN, 'minutes').format('x');
            if (bCompleted || doc.retryCount >= MAX_RETRY_COUNT) {
                if ((i + 1) === doc.scheduleStatusArr.length) {
                    //finished all schedules so break and mark it as completed
                    nextTime = undefined;
                    break;
                }
                doc.retryCount = 0;
                nextTime = doc.scheduleStatusArr[i + 1].timestamp;
                resetCusStatus(doc.customers);
            }
            break;
        }
    }
    if (nextTime === undefined && doc._id.indexOf(crm_1.WISHER) === -1) {
        doc.status = crm_1.COMPLETED;
    }
    return nextTime;
}
exports.processWisher4UT = processWisher;
exports.getBdayCustomers4UT = getBdayCustomers;
//# sourceMappingURL=scheduler.js.map