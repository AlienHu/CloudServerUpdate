/*jshint sub:true*/
const itemsController = require('../Items.js');
const logger = require('../../common/Logger');
const utils = require('../common/Utils');
const CLONE = require('../common/Utils').clone;
const IS_UNDEFINED_OR_NULL = utils.isUndefinedOrNull2;
const ARRAY_LENGTH = utils.getArrayLength;
const ASSIGN_IF_TRUE = utils.assignIfTrue;
const couchDBUtils = require('../common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const autoIncrementHelper = require('../common/autoIncrementHelper');
let maxReturnId = autoIncrementHelper.getMaxReceivingReturnId();
const itemsLib = require('./itemsControllerLib');
const workerProcess = require('../workers/commonWorker');
const itemsValidator = require('../validatiors/Items');
const commonLib = require('./commonLib');
const moment = require('moment');

const lockUtils = require('../../common/lockUtils');
lockUtils.createLockDir('locks/purchase');
const lockPath = 'locks/purchase/purchase.lock';
const lockOptions = lockUtils.lockOptions();

let receivingsLib2 = function() {

    let applicationSettings;
    this.setAppSettings = function(appSettings) {
        applicationSettings = appSettings;
    };

    //Assign timestamps to batches Save and say success
    //1. info    
    //3. itmes
    //4. taxes
    //5. inventory document
    //6. item document
    //7. lock for maxReceivingId

    function getPrice(price, taxPercent, bIncTax) {
        if (bIncTax) {
            return price * (1 + taxPercent * 0.01);
        } else {
            return price / (1 + taxPercent * 0.01);
        }
    }

    function getItemJson(cartItem, roundOffMethod, bPurchase) {
        let jsonData = {
            name: cartItem.name,
            hsn: cartItem.hsn,
            item_id: cartItem.item_id,
            batchId: cartItem.batchId,
            stockKey: cartItem.stockKey,
            skuName: cartItem.skuName,
            line: cartItem.line,
            description: cartItem.description,
            quantity_purchased: cartItem.quantity,
            expiry: cartItem.expiry,
            unitId: cartItem.unitId,
            baseUnitId: cartItem.baseUnitId,
            unitsInfo: cartItem.unitsInfo,
            bPPTaxInclusive: cartItem.bPPTaxInclusive,
            item_location: cartItem.item_location,
            itemTaxList: [],
            slab: cartItem.slab,
            unit: cartItem.unit,
            hasExpiryDate: cartItem.hasExpiryDate,
            is_serialized: cartItem.is_serialized,
            hasBatchNumber: cartItem.hasBatchNumber,
            imeiCount: cartItem.imeiCount,
            hasVariants: cartItem.hasVariants,
            discount: cartItem.discount,
            subTotal: cartItem.subTotal ? cartItem.subTotal : cartItem.totalNoTaxWithDiscount,
            total: cartItem.total
        };

        if (bPurchase) {
            //This is for ex inc option in purchase screen
            if (cartItem.bPPTempTaxInclusive === cartItem.bPPTaxInclusive) {
                bPurchase = false;
            }
        }
        let totalTax = 0;
        let totalTaxPercent = 0;
        if (cartItem.taxes) {
            jsonData.taxes = cartItem.taxes;
            jsonData.itemTaxList = cartItem.itemTaxList;
        } else {
            jsonData.taxes = {};
            for (let i = 0; i < ARRAY_LENGTH(cartItem.itemTaxList); i++) {
                totalTax += cartItem.itemTaxList[i].Amt;
                jsonData.itemTaxList.push({
                    name: cartItem.itemTaxList[i].name,
                    percent: cartItem.itemTaxList[i].percent
                });
                if (bPurchase) {
                    totalTaxPercent += cartItem.itemTaxList[i].percent;
                }
                jsonData.taxes[cartItem.itemTaxList[i].name] = cartItem.itemTaxList[i].Amt;
            }

            jsonData.taxes.Total = totalTax;
        }

        if (cartItem.uniqueDetails) {
            jsonData.uniqueDetails = cartItem.uniqueDetails;
        }

        if (bPurchase) {
            for (let unitId in cartItem.unitsInfo) {
                cartItem.unitsInfo[unitId].purchasePrice = utils.roundOffNumber(getPrice(cartItem.unitsInfo[unitId].purchasePrice, totalTaxPercent, cartItem.bPPTaxInclusive), applicationSettings, roundOffMethod);
            }
            cartItem.bPPTempTaxInclusive = cartItem.bPPTaxInclusive;
        }

        return jsonData;
    }

    this.save = async function(cart, editPurchaseId, supplierId, employeeId, comment, invoiceNumber, payments, paymentType, total, purchaseOnCreditAmt, StockLocation, timeStamp, checkNo, roundOffMethod, amount_tendered, GSTIN, state_name, discount, interState, subtotal, taxes, quantity, taxDetailed) {
        try {
            await lockUtils.lockAsync(lockPath, CLONE(lockOptions));
            let receivingId = editPurchaseId ? parseInt(editPurchaseId.substring(10, editPurchaseId.length)) : autoIncrementHelper.getMaxReceivingId() + 1;

            if (!timeStamp) {
                timeStamp = parseInt(moment().format('x'));
            } else {
                timeStamp = parseInt(moment(timeStamp).format('x'));
            }

            function getInfo() {
                return {
                    receiving_time: timeStamp,
                    checkNo: checkNo,
                    supplier_id: supplierId,
                    employee_id: employeeId,
                    comment: comment,
                    invoice_number: invoiceNumber,
                    payment_type: paymentType,
                    pending_amount: purchaseOnCreditAmt,
                    total: total,
                    subtotal: subtotal,
                    taxes: taxes,
                    taxDetailed: taxDetailed,
                    quantity: quantity,
                    receiving_id: receivingId,
                    type: 1, //1 for Purchase 2 for Purchase Return,
                    round_off_method: roundOffMethod,
                    amount_tendered: amount_tendered,
                    GSTIN: GSTIN,
                    state_name: state_name,
                    discount: discount,
                    interState: interState
                };
            }

            function getItemsInfoJsonForStatus(cartItem, itemInfo) {
                if (!itemInfo._id) {
                    itemInfo._id = itemsLib.formatItemDocId(cartItem.item_id);
                    itemInfo.batches = {};
                }

                let batchInfo = itemsLib.getStockJsonFromItemData(cartItem);
                let errMsg = 'Item<' + cartItem.name + '> failed validation';
                let tempResp = itemsValidator.validateBatchInfo(batchInfo, true, cartItem.hasExpiryDate);
                if (!tempResp.bValid) {
                    logger.error(tempResp.errMsg);
                    logger.error(errMsg);
                    throw errMsg;
                }

                itemInfo.batches[cartItem.stockKey] = batchInfo;
            }

            function getItemsAndTaxesAndStatus() {
                let receiving_items = [];
                let inventoryTransStatus = {};
                let itemsInfoStatus = {};

                for (let i = 0; i < cart.length; i++) {
                    let item = cart[i];

                    let itemClone = CLONE(item);
                    let uniqueDetails = itemClone.uniqueDetails;
                    delete itemClone.uniqueDetails;
                    itemClone.uniqueDetails = utils.convertObjectToArray(uniqueDetails);

                    receiving_items.push(getItemJson(itemClone, roundOffMethod, true));

                    let docId = itemsLib.formatInvDocId(itemClone.item_id);
                    let invTrans = {};
                    if (inventoryTransStatus[docId] && inventoryTransStatus[docId].doc) {
                        invTrans = inventoryTransStatus[docId].doc;
                    }
                    itemsLib.updateStockHelper(commonLib.getParamsForGettingInvTrans(itemClone, timeStamp, employeeId, 'PUR ' + receivingId, false), invTrans, true, undefined, 'purchase');
                    inventoryTransStatus[invTrans._id] = {
                        status: 4,
                        doc: invTrans
                    };

                    docId = itemsLib.formatItemDocId(itemClone.item_id);
                    let itemsInfo = {};
                    if (itemsInfoStatus[docId] && itemsInfoStatus[docId].doc) {
                        itemsInfo = itemsInfoStatus[docId].doc;
                    }
                    getItemsInfoJsonForStatus(itemClone, itemsInfo);
                    itemsInfoStatus[itemsInfo._id] = {
                        status: 4,
                        doc: itemsInfo
                    };

                }

                return {
                    receiving_items: receiving_items,
                    inventoryTransStatus: inventoryTransStatus,
                    itemsInfoStatus: itemsInfoStatus
                };

            }

            let itemsAndTaxesAndStatus = getItemsAndTaxesAndStatus();

            let recvDoc = {
                _id: commonLib.formatReceivingId(receivingId),
                receiving_id: receivingId,
                receivings_info: getInfo(),
                payments: payments,
                receiving_items: itemsAndTaxesAndStatus.receiving_items,
                status: {
                    status: 4,
                    inventoryTrans: itemsAndTaxesAndStatus.inventoryTransStatus,
                    items: itemsAndTaxesAndStatus.itemsInfoStatus,
                    suppliers: {}
                }
            };

            if (supplierId) {
                let supplierDocId = 'supplier_' + supplierId;
                recvDoc.status.suppliers[supplierDocId] = {
                    status: 4,
                    doc: {
                        _id: supplierDocId,
                        total: total,
                        balance: purchaseOnCreditAmt
                    }
                };
            }
            let infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
            let itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount'];

            workerProcess.setFreeze(true);
            if (editPurchaseId) {
                var doc = await couchDBUtils.getTransDoc(editPurchaseId, mainDBInstance, 'Failed to get  sales Doc. Try Again');
                commonLib.mergeStatus(recvDoc.status, doc, timeStamp);
                recvDoc._id = doc._id;
                recvDoc._rev = doc._rev;
                recvDoc = await commonLib.encodeTransDoc(recvDoc, 'purchase', infoFields, itemFields)
                recvCreateResp = await couchDBUtils.update(recvDoc, mainDBInstance, 3, 'Edit Sales Transaction Failed. Try Again');
            } else {
                recvDoc = await commonLib.encodeTransDoc(recvDoc, 'purchase', infoFields, itemFields)
                let recvCreateResp = await couchDBUtils.create(recvDoc, mainDBInstance, 3, 'Purchase Transaction Failed. Try Again');
                autoIncrementHelper.incrementReceivingId();
            }
            await lockUtils.unlockAsync(lockPath);
            workerProcess.insertTrans({
                parentDocId: recvDoc._id,
                transactions: recvDoc.status.inventoryTrans,
                itemUpdates: recvDoc.status.items,
                elementUpdates: recvDoc.status.suppliers
            });
            workerProcess.setFreeze(false);

            let receivingsResp = {
                receivingId: receivingId,
                timeStamp: timeStamp
            }
            return receivingsResp;
        } catch (error) {
            await lockUtils.unlockAsync(lockPath);
            workerProcess.setFreeze(false);
            logger.error(error);
            throw error;
        }

    };

    /**
     * rTodo write api validation to check proper data is passed
     * {
     *      items: [], //refer getItemJson for structure
     *      timeStamp: 14511413321,
     *      checkNo: 132321,
     *      supplier_id: 1343242,
     *      employee_id: 'admin',
     *      comment: 'hello worl d',
     *      parentId: 23,
     *      payments: [],
     *      total: 100,
     *      creditAmt: 10
     * }
     */
    this.commitReturn = async function(data) {
        try {

            await lockUtils.lockAsync(lockPath, CLONE(lockOptions));
            let returnId = maxReturnId + 1;

            if (!data.timeStamp) {
                data.timeStamp = parseInt(moment().format('x'));
            } else {
                let timeStamp = parseInt(data.timeStamp);
                if (timeStamp === NaN) {
                    timeStamp = data.timeStamp;
                }
                data.timeStamp = parseInt(moment(timeStamp).format('x'));
            }

            function getInfo() {
                var amount_tendered = 0;
                for (var payment in data.payments) {
                    amount_tendered += data.payments[payment].payment_amount;
                }
                return {
                    id: returnId,
                    time: data.timeStamp,
                    checkNo: data.checkNo,
                    supplier_id: data.supplier_id,
                    employee_id: data.employee_id,
                    comment: data.comment,
                    parentId: data.parentId,
                    total: parseFloat(data.total),
                    subtotal: parseFloat(data.subtotal),
                    quantity: parseFloat(data.quantity),
                    taxes: data.taxes,
                    taxDetailed: data.taxDetailed,
                    round_off_method: data.round_off_method,
                    amount_tendered: amount_tendered,
                    GSTIN: data.GSTIN,
                    state_name: data.state_name,
                    discount: data.discount ? data.discount : {},
                    interState: data.interState ? data.interState : false
                };

            }

            function getItemsAndStatus() {

                let items = [];
                let inventoryTrans = {};
                for (let key in data.items) {
                    let cartItem = data.items[key];
                    let itemClone = CLONE(cartItem);
                    cartItem.subTotal = cartItem.computations ? cartItem.computations.subTotal : cartItem.subTotal;
                    cartItem.total = cartItem.computations ? cartItem.computations.total : cartItem.total;
                    items.push(getItemJson(cartItem, data.round_off_method));

                    let itemAvailable; //undefined so that we don't modify this variable in stock                    
                    let docId = itemsLib.formatInvDocId(cartItem.item_id);
                    let invTrans = {};
                    if (inventoryTrans[docId] && inventoryTrans[docId].doc) {
                        invTrans = inventoryTrans[docId].doc;
                    }

                    itemsLib.updateStockHelper(commonLib.getParamsForGettingInvTrans(itemClone, data.timeStamp, data.employee_id, 'PUR Return ' + returnId, false, true), invTrans, false, undefined, 'purchaseReturn');
                    inventoryTrans[invTrans._id] = {
                        status: 4,
                        doc: invTrans
                    };
                }

                return {
                    items: items,
                    inventoryTrans: inventoryTrans
                };

            }

            let itemsAndStatus = getItemsAndStatus();

            let doc = {
                _id: commonLib.formatReceivingReturnId(returnId),
                id: returnId
            };
            doc.info = getInfo();
            doc.payments = data.payments;
            doc.items = itemsAndStatus.items;

            doc.status = {
                status: 4,
                inventoryTrans: itemsAndStatus.inventoryTrans,
                suppliers: {},
                parentDoc: {}
            };

            if (data.supplier_id) {
                let supplierDocId = 'supplier_' + data.supplier_id;
                doc.status.suppliers[supplierDocId] = {
                    status: 4,
                    doc: {
                        _id: supplierDocId,
                        total: -parseFloat(data.total), //RelaxDanger This is rounded off total. get total without manipulation
                        balance: -data.creditAmt
                    }
                }
            };

            let parentDocId = commonLib.formatReceivingId(data.parentId);
            doc.status.parentDoc[parentDocId] = {
                status: 4,
                doc: {
                    _id: parentDocId,
                    returnDocId: returnId
                }
            };

            workerProcess.setFreeze(true);
            let infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
            let itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount'];
            doc = await commonLib.encodeTransDoc(doc, 'purchaseReturn', infoFields, itemFields)
            await couchDBUtils.create(doc, mainDBInstance, 3, 'Purchase Return Transaction Failed. Try Again');
            maxReturnId++;
            await lockUtils.unlockAsync(lockPath);
            workerProcess.insertTrans({
                parentDocId: doc._id,
                transactions: doc.status.inventoryTrans,
                itemUpdates: {},
                elementUpdates: doc.status.suppliers,
                returnUpdates: doc.status.parentDoc
            });
            workerProcess.setFreeze(false);

            return {
                message: 'Return Successful',
                data: {
                    id: returnId
                }
            };
        } catch (error) {
            await lockUtils.unlockAsync(lockPath);
            workerProcess.setFreeze(false);
            logger.error(error);
            throw {
                error: error
            };
        }
    };

};

module.exports = new receivingsLib2();