'use strict';

const moment = require('moment');
const logger = require('../../common/Logger');
const utils = require('../common/Utils');
const couchDBUtils = require('../common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const IS_EMPTY_OBJECT = utils.isEmptyObject;
const IS_UNDEFINED_OR_NULL = utils.isUndefinedOrNull2;
const ASSIGN_IF_TRUE = utils.assignIfTrue;
const CLONE = utils.clone;

const lockUtils = require('../../common/lockUtils');
const lockOptions = lockUtils.lockOptions();

const crudType = {
    CREATE: 0,
    UPDATE: 1,
    DELETE: 2
};

function getLockPath(type) {
    return 'locks/' + type + '/' + type + '.lock';
}

let foo = function() {

    this.crudType = crudType;

    function initialize(params) {
        if (!params.docPrefix) {
            throw 'Doc Prefix Cannot be Null';
        }

        if (params.crudType < 0 || params.crudType > 2) {
            throw 'Invalide CRUD Type';
        }

        params.formatDocIdFun = ASSIGN_IF_TRUE(params.formatDocIdFun, formatDocId);
        params.getUniqueHashFun = ASSIGN_IF_TRUE(params.getUniqueHashFun, getUniqueHash);
        params.uniqueConstraintFun = ASSIGN_IF_TRUE(params.uniqueConstraintFun, uniqueConstraint);
        params.canDeleteFun = ASSIGN_IF_TRUE(params.canDeleteFun, canDelete);
    }

    this.updateSettings = async function(params) {
        if (params.rev) params._rev = params.rev;
        if (!params._rev) {
            try {
                let resp = await couchDBUtils.create(params, mainDBInstance, 1, 'propagate');
                return resp[0];
            } catch (err) {
                // err.msg = 'Hotel settings update failed';
                throw err;
            }
        } else {
            try {
                let resp = await couchDBUtils.update(params, mainDBInstance, 2, 'propagate');
                return resp[0];
            } catch (err) {
                // err.msg = 'Hotel settings update failed';
                throw err;
            }
        }

    }

    this.crud = async function(params) {
        let response = {};
        try {
            initialize(params);
        } catch (error) {
            response.error = error;
            throw response;
        }

        let errMsg;
        if (params.validateDataFun) {
            errMsg = params.validateDataFun(params.data, params.crudType);
            if (errMsg !== true) {
                response.error = errMsg;
                throw response;
            }
        }
        errMsg = validateData(params.data, params.crudType);
        if (errMsg !== true) {
            response.error = errMsg;
            throw response;
        }

        let lockPath;
        try {
            if (params.crudType === crudType.DELETE && !IS_EMPTY_OBJECT(params.canDeleteFunParams)) {
                await params.canDeleteFun(params);
            }

            if (params.crudType !== crudType.DELETE && !IS_EMPTY_OBJECT(params.uniqueConstraintFunParams)) {
                lockPath = getLockPath(params.docPrefix);
                await lockUtils.lockAsync(lockPath, utils.clone(lockOptions));
                await params.uniqueConstraintFun(params);
            }

            if (params.crudType === crudType.CREATE) {
                params.data.id = moment().format('x');
            }
            params.data._id = params.formatDocIdFun(params.docPrefix, params.data.id);

            response.message = params.docPrefix;
            switch (params.crudType) {
                case crudType.CREATE:
                    response.message += ' Created '
                    await couchDBUtils.create(params.data, mainDBInstance, 1, 'Internal Server Error Try Again');
                    break;
                case crudType.UPDATE:
                    response.message += ' Updated '
                    await couchDBUtils.update(params.data, mainDBInstance, 2, 'Internal Server Error Try Again');
                    break;
                case crudType.DELETE:
                    response.message += ' Deleted '
                    await couchDBUtils.updateHandler(params.data._id, params.data, mainDBInstance, 'add_delete_flag', 'Internal Server Error Try Again');
                    break;
            }

            response.message += 'Successfully';
            response.data = {
                id: params.data.id
            };

            if (lockPath) {
                await lockUtils.unlockAsync(lockPath); //we don't need to wait for completing this? What about import case?
            }

            return response;
        } catch (error) {
            if (lockPath) {
                await lockUtils.unlockAsync(lockPath); //we don't need to wait for completing this? What about import case?
            }

            if (response.message) {
                delete response.message;
            }

            response.error = error;
            throw response;
        }
    };

    function formatDocId(docPrefix, id) {
        return docPrefix + '_' + id;
    }

    function validateData(data, _crudType) {
        if (IS_EMPTY_OBJECT(data)) {
            throw 'Invalid Data';
        }

        let errMsg = '';
        if (_crudType !== crudType.CREATE) {
            if (!data.id) {
                errMsg += 'ID is mandatory';
            }
        } else {
            if (data._id || data._rev || data.id) {
                errMsg += '_id and _rev are not expected';
            }
        }

        if (errMsg) {
            return errMsg;
        }

        return true;
    }

    async function canDelete(params) {

        let queryParams = {
            keys: [params.formatDocIdFun(params.docPrefix, params.data.id)]
        };

        let queryResponse = await couchDBUtils.getView(params.canDeleteFunParams.designDocName, params.canDeleteFunParams.viewName, queryParams, mainDBInstance);
        if (queryResponse.length) {
            let errMsg = params.docPrefix + ' cannot be deleted. It is being used.';
            throw errMsg;
        }
    }

    async function uniqueConstraint(params) {
        let uniqueHash = params.getUniqueHashFun(params);

        let queryParams = {
            keys: [uniqueHash],
            include_docs: false
        };

        let resp = await couchDBUtils.getView(params.uniqueConstraintFunParams.designDocName, params.uniqueConstraintFunParams.viewName, queryParams, mainDBInstance);
        let msg = uniqueHash + ' Already Exists. Enter Unique Values';

        let bUnique = true;
        for (let i = 0; i < resp.length; i++) {
            if (params.crudType === crudType.UPDATE && resp[i].id.indexOf(params.data.id) > 0) {
                continue;
            }

            let key = resp[i].key;
            if (uniqueHash === key) {
                bUnique = false;
            }
        }

        if (!bUnique) {
            throw msg;
        }
    }

    function getUniqueHash(params) {
        if (typeof(params.data.name) === "string") {
            return params.docPrefix + '_' + params.data.name.toLowerCase();
        } else {
            return params.docPrefix + '_' + params.data.name;
        }
    }

    return this;
};

module.exports = new foo();