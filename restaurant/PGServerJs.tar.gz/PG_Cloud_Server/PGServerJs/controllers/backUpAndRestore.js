var logger = require('../common/Logger');
var shelljs = require('shelljs');
var path = require('path');
var _self;
var couchdbBackupRestore = require('../couchdb-backup-restore');
const configState = require('../common/configState');
var fs = require('fs');
var moment = require('moment');

let MIGRATION_BACKUP_FOLDER = 'migration/'

var BackUpController = function() {
    _self = this;

    function getBackUpLocationDir(reason) {
        var now = moment().format('YYYY-MM-DD-HH-mm-ss-SSS');
        var currentBackUpLocation = now;
        if (!reason || reason === '') {
            reason = 'casual';
        }
        reason = reason.toLowerCase();

        switch (reason) {
            case 'b4_update':
                currentBackUpLocation = 'b4_update/' + now;
                break;
            case 'b4_restore':
                currentBackUpLocation = 'b4_restore/' + now;
                break;
            case 'autobackup':
                currentBackUpLocation = 'autoBackup/' + now;
                break;
            case 'migration':
                currentBackUpLocation = MIGRATION_BACKUP_FOLDER + now;
                break;
            case 'migration_failed':
                currentBackUpLocation = MIGRATION_BACKUP_FOLDER + now;
                break;
            default:
                logger.info('Reason for BackUp Unknown');
        }
        return currentBackUpLocation;
    }

    this.takeBackUp = async function(backUpConfig) {
        backUpConfig.backUpLocation = path.resolve(backUpConfig.backUpBaseLocationDir + '/' + getBackUpLocationDir(backUpConfig.reason4Backup));
        if (backUpConfig.reason4Backup === 'migration' || backUpConfig.reason4Backup === 'migration_failed') {
            let fileArray = shelljs.ls(backUpConfig.backUpBaseLocationDir + MIGRATION_BACKUP_FOLDER);
            if (fileArray.length) {
                let lastBackUp = fileArray[fileArray.length - 1];
                if (moment().diff(moment(lastBackUp, 'YYYY-MM-DD-hh-mm-ss-SSS'), 'hours') <= 48) return;
            }
            clearAutoBackup(backUpConfig.backUpBaseLocationDir + MIGRATION_BACKUP_FOLDER);
        }
        try {
            if (shelljs.mkdir('-p', backUpConfig.backUpLocation).code === 0) {
                //Lets start the Back up
                logger.info('Back Up Started');
                await couchdbBackupRestore.backup(backUpConfig);
                logger.info('BackUp Done!!');
                await backupMetaJson(backUpConfig.backUpLocation);
                return true;
            } else {
                throw 'Could Not Create backUp Location Folder';
            }
        } catch (error) {
            throw error;
        }
    };

    async function backupMetaJson(backupPath) {
        const umzugJsonPath = await configState.getUmzugStorageFullPath();
        shelljs.cp(umzugJsonPath, backupPath);
    }

    async function restoreMetaJson(backupPath) {
        //get umzug json path
        const umzugJsonPath = await configState.getUmzugStorageFullPath();
        const fileName = path.basename(umzugJsonPath);
        shelljs.cp(path.resolve(backupPath, fileName), umzugJsonPath);
    }

    //Returns all the backups -> ordered by descending timeStamp
    this.getBackUpsList = async function(backUpBaseLocationDir) {

        try {
            var backupList = shelljs.ls('-d', backUpBaseLocationDir + '/**/*/');
            if (backupList.length > 0) {
                backupList = backupList.sort('-r').split('\n');
                backupList.splice(backupList.length - 1, 1);
            }

            return backupList;
        } catch (error) {
            throw error;
        }
    };

    this.restoreFromBackUp = async function(restoreConfig, maxRetries) {
        try {
            //take backup first
            await _self.takeBackUp(restoreConfig);
        } catch (error) {
            logger.error(error);
            logger.error('taking backup failed');
            throw 'taking backup failed';
        }

        try {
            await couchdbBackupRestore.restore(restoreConfig);
            await restoreMetaJson(restoreConfig.backUpLocation2Restore);
            logger.info('Restore Done!!');
            return true;
        } catch (error) {

            logger.error(error);
            let errMsg = 'Restore Failed';
            logger.error(errMsg);
            throw errMsg;
        }

    };

    this.changeDatabaseDir = function(params) {
        return couchdbBackupRestore.changeDatabaseDir(params);
    };

    function checkNeedToTakeBackup() {
        /**
         * checkTime
         * checksale
         * 
         */

    }

    var clearAutoBackup = function(autoBackupPath) {
        let fileArray = shelljs.ls(autoBackupPath);
        for (let i = 0; fileArray.length > 5; i++) {
            console.log("removed" + fileArray[i]);
            logger.info("removed" + fileArray[i]);
            shelljs.rm("-rf", autoBackupPath + "/" + fileArray[i]);
            fileArray.splice(0, 1);

        }
    }

    this.autoBackup = async function() {
        console.log("autoBackup Backup");
        logger.info("autoBackup Backup");
        let backUpLocation = configState.getBackUpLocation();
        let param = {
            backUpBaseLocationDir: backUpLocation,
            reason4Backup: "autobackup"
        }
        clearAutoBackup(param.backUpBaseLocationDir + "/autoBackup");
        await _self.takeBackUp(param);
    }

    this.initAutoBackup = async function() {
        logger.info("init Backup");
        console.log("init Backup");

        const immediateObj = setImmediate(async () => {
            await _self.autoBackup();
        });
        const intervalObj = setInterval(async () => {
            await _self.autoBackup();
        }, 1000 * 5 * 60 * 60);

    }
};

module.exports = new BackUpController();