var promiseHelper = function() {

    var BPromise = require('bluebird');

    /**
     * Requirements
     * 1. execute array sequentially
     * 2. execute uniform object sequentially     
     */

};
module.exports = new promiseHelper();