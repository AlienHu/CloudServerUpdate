/*
 *		Todo: Add bulk_insert, bulk_update and delete functionality
 *		Todo: Use couchdb return status codes http://docs.couchdb.org/en/2.0.0/api/basics.html#http-status-codes
 * 		Todo: status code is in header.status_code
 *      http://docs.couchdb.org/en/2.0.0/api/document/common.html
 *      http://docs.couchdb.org/en/2.0.0/couchapp/views/joins.html
 *      https://github.com/dscape/nano
 */
const isWin = /^win/.test(process.platform);
let instPathPrefix = '';

var CouchDBUtils = function() {
    'use strict';

    require('errors');

    var _self = this;
    var utils = require('./Utils');
    var logger = require('../../common/Logger');
    var respJsonUtil = require('../../common/responseJson');
    var couchDB;
    var couchDbMain = require('../../couchDb/couchDBMain');
    let couchDBUtils2 = require('../../couchDb/couchDBUtils2');
    const httpUtils = require('../../common/httpUtils');
    const path = require('path');
    const moment = require('moment');

    const UNDEFINED_OR_NULL = utils.isUndefinedOrNull2;

    //In case couchDbMain is not done , i.e. when couchDbUtils used before launching the PGServerJs 
    //Ex: in controller unit tests
    if (couchDbMain.isInitDone()) {
        couchDB = couchDbMain;
    } else {
        initCouchDbMyself();
    }

    function initCouchDbMyself() {
        var createSingleton = require('create-singleton');

        var initCouchDB = function() {
            var couchUsersDbUrl = 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT;
            var nano = require('nano-blue')(couchUsersDbUrl);
            var dbName = 'pg_collection_' + process.env.APP_TYPE + '_maindb';
            var salesDBName = 'pg_collection_' + process.env.APP_TYPE + '_salesdb';
            var userDBName = '_users';
            var coreDBName = 'pg_collection_' + process.env.APP_TYPE + '_coredb';
            var licenceDBName = 'pg_collection_' + process.env.APP_TYPE + '_licencedb';
            const configDBName = '_config';

            this.getMainDbCouchClient = function() {
                return nano.use(dbName);
            };

            this.getUserDBClient = function() {
                return nano.use(userDBName);
            };

            this.getConfigDBClient = () => {
                return nano.use(configDBName)
            }

            this.getCoreDBClient = function() {
                return nano.use(coreDBName);
            };

            this.getLicenceDBClient = function() {
                return nano.use(licenceDBName);
            };

        };

        // Todo: is there use
        // for this singleton ?
        var initCouchDBSingleton = createSingleton(initCouchDB);
        couchDB = new initCouchDBSingleton();
    }

    this.getMainCouchDB = function() {

        return couchDB.getMainDbCouchClient();
    };

    this.getUserCouchDB = function() {
        return couchDB.getUserDBClient();
    };

    this.getCoreCouchDB = function() {
        return couchDB.getCoreDBClient();
    };

    this.getConfigCouchDB = function() {
        return couchDB.getConfigDBClient();
    };

    this.getLicenceDB = function() {
        return couchDB.getLicenceDBClient();
    };

    this.getDocEx = async function(id, db) {
        try {
            return await _self.getDoc(id, db, 'propagate');
        } catch (err) {
            throw err;
        }
    };

    this.getConfigDoc = async () => {
        const couchDocName = 'couchdb';
        const dbInstance = _self.getConfigCouchDB();
        try {
            const configDoc = await _self.getDoc(couchDocName, dbInstance, 'propogate');
            return configDoc;
        } catch (err) {
            throw err;
        }

    }

    this.getDoc = async function(id, db, errMsg, bDontThrow, param) {
        var response = respJsonUtil.get();
        param = param ? param : {};
        try {
            let queryResp = await db.get(id, param);
            return queryResp[0];
        } catch (err) {
            if (errMsg && errMsg.indexOf(err.reason) >= 0) {
                //Reason is expected so no problem
            } else if (['missing', 'deleted'].indexOf(err.reason) === -1) {
                logger.error(err); //404 Not Found is expected. Other errors are dangerous
            }
            if (errMsg === 'propagate') {
                throw err;
            }

            if (!errMsg) { //Maintaining the old response foramt
                errMsg = 'getDoc error ' + id;
                logger.error(errMsg);

                response.msg = errMsg;
                response.err.msg = errMsg;
                response.err.errObj = err;
                return response;
            } else {
                if (bDontThrow) {
                    return errMsg;
                } else {
                    throw errMsg;
                }
            }
        }
    };

    this.getTransDoc = async function(id, db, errMsg, bDontThrow) {
        const commonLib = require('../libraries/commonLib');
        var response = respJsonUtil.get();
        try {
            let queryResp = await db.get(id);

            let doc = commonLib.transformSaleDoc(queryResp[0], commonLib.getTransType(queryResp[0]._id));
            return doc;
        } catch (err) {
            if (errMsg && errMsg.indexOf(err.reason) >= 0) {
                //Reason is expected so no problem
            } else if (['missing', 'deleted'].indexOf(err.reason) === -1) {
                logger.error(err); //404 Not Found is expected. Other errors are dangerous
            }
            if (errMsg === 'propagate') {
                throw err;
            }

            if (!errMsg) { //Maintaining the old response foramt
                errMsg = 'getDoc error ' + id;
                logger.error(errMsg);

                response.msg = errMsg;
                response.err.msg = errMsg;
                response.err.errObj = err;
                return response;
            } else {
                if (bDontThrow) {
                    return errMsg;
                } else {
                    throw errMsg;
                }
            }
        }
    };

    this.getView = function(designDocName, viewName, params, db) {
        if (UNDEFINED_OR_NULL(params.reduce)) {
            params.reduce = false;
        }

        return db.view(designDocName, viewName, params).spread(function(body, header) {
            return body.rows;
        }).catch(function(err) {
            logger.error(err);
            logger.error('Query Error ' + designDocName + '/' + viewName);
            logger.error(params);
            return [];
        });
    };

    function transformSaleDoc(resp, type) {
        let infoKey = 'sales_info';
        let itemsKey = 'sale_items';
        let idKey = 'sale_id';

        if (resp.id.indexOf('receivingReturn') === 0 || resp.id.indexOf('saleReturn') === 0) {
            infoKey = 'info';
            itemsKey = 'items';
            idKey = 'id';

        } else if (resp.id.indexOf('receiving') === 0) {
            infoKey = 'receivings_info';
            itemsKey = 'receiving_items';
            idKey = 'receiving_id';

        }
        const commonLib = require('../libraries/commonLib');

        var doc;
        if (resp.doc) {
            doc = resp.doc;
        } else {
            resp = JSON.parse(resp.value);
            var id = JSON.parse(resp[0]);

            var jsonValue = {
                payments: resp[3]
            }
            jsonValue[idKey] = id[idKey];
            jsonValue[itemsKey] = JSON.parse(resp[2]);;
            jsonValue[infoKey] = resp[1];
            if (resp[4]) {
                jsonValue.bReturned = true;
            } else {
                jsonValue.bReturned = false;
            }
            if (resp[5]) {
                jsonValue.bRejected = true;
            } else {
                jsonValue.bRejected = false;
            }
            doc = jsonValue;
        }

        // var doc = resp.doc ? resp.doc : resp;
        if (type === 'sale' && doc.info) {
            type = 'saleReturn';
        } else if (type === 'purchase' && doc.info) {
            type = 'purchaseReturn';
        }

        doc = commonLib.transformSaleDoc(doc, type);
        return doc;
    }

    this.getTransView = function(designDocName, viewName, params, db, type) {
        if (UNDEFINED_OR_NULL(params.reduce)) {
            params.reduce = false;
        }

        return db.view(designDocName, viewName, params).spread(function(body, header) {
            let docs = body.rows
            for (let i = 0; i < docs.length; i++) {
                docs[i] = transformSaleDoc(docs[i], type);
            }
            return docs;
        }).catch(function(err) {
            logger.error(err);
            logger.error('Query Error ' + designDocName + '/' + viewName);
            logger.error(params);
            return [];
        });
    };

    /**
     * ['cust_id'] 
     * The API doesn't return any error. The result rows length is equal to input keys length
     * If some key is not found, that row structure is like this {"key":"item_3","error":"not_found"}
     */

    this.batchProcess = async function(dbUtilFunction, args, callBackFunc) {
        let offset = 0;
        let params = {};
        args.some(function(element) {
            if (typeof element == "object" && element.limit) {
                params = element;
                return true;
            }
        });
        while (true) {
            console.log('Current Count <' + offset + ' >');
            params.skip = offset;
            let allDocs = await dbUtilFunction(...args);
            offset += allDocs.length;
            await callBackFunc(allDocs);
            if (allDocs.length !== params.limit) {
                console.log('Total Process Count<' + offset + '>');
                break;
            }
        }
    }

    this.getAllDocs = function(keys, db, bOnlyDocs, params) {
        if (!params) {
            params = {}
        };
        params.include_docs = true; // keeping it as previous
        return db.fetch({
            "keys": keys
        }, params).spread(function(body, header) {
            if (!bOnlyDocs) {
                return body.rows;
            } else {
                //This is just wasting of 1 for loop for the inconvinience of having to write body.rows[i].doc everytime
                //Bad don't use it
                let resp = [];
                for (let i = 0; i < body.rows.length; i++) {
                    resp.push(body.rows[i].doc);
                }

                return resp;
            }
        }).catch(function(err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        });
    };

    this.getAllDocsInBulk = function(keys, db, type, bOnlyDocs) {
        return db.fetch({
            "keys": keys
        }, {
            include_docs: true
        }).spread(function(body, header) {
            if (!bOnlyDocs) {
                return body.rows;
            } else {
                //This is just wasting of 1 for loop for the inconvinience of having to write body.rows[i].doc everytime
                //Bad don't use it
                let resp = {};
                for (let i = 0; i < body.rows.length; i++) {
                    if (!body.rows[i].doc) {
                        continue;
                    }
                    // resp.push(body.rows[i].doc);
                    let key = "";
                    if (type === 'employee') {
                        key = body.rows[i].doc.name;
                    } else if (type === 'customer' || type === 'supplier') {
                        key = body.rows[i].doc.person_id;
                    } else if (type === 'item') {
                        key = body.rows[i].doc.item_id;
                    }
                    resp[key] = body.rows[i].doc
                }

                return resp;
            }
        }).catch(function(err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        });
    };

    /**
     * 
     * @param {*} type customer/supplier/sale 
     * @param {*} db dbInstance
     * @param {*} params http://docs.couchdb.org/en/2.1.1/api/ddoc/views.html#db-design-design-doc-view-view-name
     * @param {*} bOnlyDocs dont use .. use only for uts
     * This function will not throw exception
     * [
     *   {"id":"customer_1518010807646","key":"customer_1518010807646","value":{"rev":"15-bc597d68b3a511493eafdc3c840650d5"}, "doc":{"_id":"customer_1518010807646", "name": "sai"}},
     *   {"id":"customer_1518171919719","key":"customer_1518171919719","value":{"rev":"2-f237434ef62b5b4ff2666a8fa45f8001"}, "doc":{"_id":"customer_1518010807646", "name": "linto"}},
     * ]
     */
    this.getAllDocsByType = function(type, db, params, bOnlyDocs) {
        params = params || {};
        params.startkey = type + '_';
        params.endkey = type + '_z';
        params.include_docs = true;

        return db.fetch({}, params).spread(function(body, header) {
            if (!bOnlyDocs) {
                return body.rows;
            } else {
                //This is just wasting of 1 for loop for the inconvinience of having to write body.rows[i].doc everytime
                //Bad don't use it
                let resp = [];
                for (let i = 0; i < body.rows.length; i++) {
                    resp.push(body.rows[i].doc);
                }

                return resp;
            }
        }).catch(function(err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        });
    };
    this.getAllTransDocsByType = function(type, db, params, bOnlyDocs) {
        params = params || {};
        params.startkey = type + '_';
        params.endkey = type + '_z';
        params.include_docs = true;

        return db.fetch({}, params).spread(function(body, header) {
            if (!bOnlyDocs) {
                let rows = [];
                for (let i = 0; i < body.rows.length; i++) {
                    let row = body.rows[i];
                    row.doc = transformSaleDoc(row.doc, type);
                    rows.push(row);
                }
                return rows;
            } else {
                //This is just wasting of 1 for loop for the inconvinience of having to write body.rows[i].doc everytime
                //Bad don't use it
                let resp = [];
                for (let i = 0; i < body.rows.length; i++) {
                    let doc = body.rows[i].doc;
                    doc = transformSaleDoc(doc, type);
                    resp.push(doc);
                }

                return resp;
            }
        }).catch(function(err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        });
    };

    this.getTransDocByRev = async function(id, db, params, type) {
        try {
            let respDoc = await db.get(id, params);
            let totalRevs = respDoc[0][0].ok._revisions.ids.length;
            let resp;
            let bRevFound = false;
            for (let idx = 1; idx < totalRevs; idx++) {
                let rev = totalRevs - idx + '-' + respDoc[0][0].ok._revisions.ids[idx];
                resp = await db.get(id, {
                    rev: rev
                });
                let infoKey = 'sales_info';
                if (id.indexOf('saleReturn') === 0 || id.indexOf('receivingReturn') === 0) {
                    infoKey = 'info';
                } else if (id.indexOf('receiving') === 0) {
                    infoKey = 'receivings_info';
                }
                if (typeof resp[0][infoKey] === 'string') {
                    continue;
                } else {
                    bRevFound = true;
                    break;
                }

            }
            if (bRevFound) {
                return resp[0];
            } else {
                return;
            }
        } catch (error) {
            return;
        }

    }
    this.getAllDocIdsByType = function(type, db, params, bOnlyDocs) {
        params = params || {};
        params.startkey = type + '_';
        params.endkey = type + '_z';
        params.include_docs = false;

        return db.fetch({}, params).spread(function(body, header) {
            if (!bOnlyDocs) {
                return body.rows;
            } else {
                //This is just wasting of 1 for loop for the inconvinience of having to write body.rows[i].doc everytime
                //Bad don't use it
                let resp = [];
                for (let i = 0; i < body.rows.length; i++) {
                    resp.push(body.rows[i].doc);
                }

                return resp;
            }
        }).catch(function(err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        });
    };

    this.getUpdateSeq = async function(dbSuffix) {
        let couchUsersDbUrl = 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT;
        let nano = require('nano-blue')(couchUsersDbUrl);
        let dbName = 'pg_collection_' + process.env.APP_TYPE + '_' + dbSuffix;

        let queryResponse = await nano.db.get(dbName);
        let tempSequence = (queryResponse[0].update_seq + '').split("-");
        let refineSequence = parseInt(tempSequence[0]);
        return refineSequence;
    };

    this.getNoOfDocs = async function(dbSuffix) {
        let couchUsersDbUrl = 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT;
        let nano = require('nano-blue')(couchUsersDbUrl);
        let dbName = 'pg_collection_' + process.env.APP_TYPE + '_' + dbSuffix;

        let queryResponse = await nano.db.get(dbName);
        return queryResponse[0].doc_count;
    };

    // how to use descending https://github.com/pouchdb/pouchdb/issues/5126
    this.getLatestDocByKey = async function(type, limit, include_docs, db) {
        return db.fetch({}, {
            startkey: type + '_z',
            endkey: type + '_',
            descending: true,
            limit: limit,
            include_docs: include_docs ? include_docs : false
        }).spread(function(body, header) {
            return body.rows;
        }).catch(function(err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        });
    }

    /**
     * Same as create just for the sake of readability adding this function
     * if _rev is there.. it will create new doc
     * if rev is there it will update
     * @param {*} jsonDoc 
     * @param {*} db 
     * @param {*} reTryCount 
     * @param {*} errMsg 
     */
    this.createOrUpdate = function(jsonDoc, db, reTryCount, errMsg) {
        return _self.create(jsonDoc, db, reTryCount, errMsg);
    };

    /*		Todo: Have the retry count as a global configurable param*/
    //10 is a dangerous number, it may take too much time
    var MAX_COUCH_RETRY_COUNT = 10;
    /*
     *		id is expected to be filled and unique. No error handling for id	
     *      This function can be used for update document if _rev is filled
     *      This function is used for update in couple of places 
     */

    this.create = function(jsonDoc, db, reTryCount, errMsg) {
        if (!errMsg) {
            errMsg = 'Out of Trials';
        }

        if (utils.isUndefinedOrNull(reTryCount)) {
            reTryCount = MAX_COUCH_RETRY_COUNT;
        }

        return db.insert(jsonDoc).spread(function(body, header) {
            return [body, header];
        }).catch(function(err) {

            let bRetry = err.statusCode !== 400 && err.statusCode !== 401 && err.statusCode !== 404 && err.statusCode !== 409;
            if (!bRetry) {
                logger.error('create document <' + jsonDoc._id + '> error ' + err.statusCode + ' reason: <' + err.reason + '>');
            } else {
                logger.error(jsonDoc);
                logger.error(err);
            }

            if (!bRetry || reTryCount === 0) {
                if (errMsg === 'propagate') {
                    errMsg = err;
                }
                return Promise.reject(errMsg);
            }

            //if response is 409, 404, 401, 400 => It is waste of trying again
            return _self.create(jsonDoc, db, reTryCount - 1, errMsg);
        });
    };

    this.updateDeprecated = function(jsonDoc, db, reTryCount) {
        if (utils.isUndefinedOrNull(reTryCount)) {
            reTryCount = MAX_COUCH_RETRY_COUNT;
        }

        var response = respJsonUtil.get();

        if (reTryCount === 0) {
            logger.error('Out of trials');
            return Promise.reject('Out of trials');
        }

        return db.head(jsonDoc._id).spread(function(body, header) {
            jsonDoc._rev = JSON.parse(header.etag);
            return db.insert(jsonDoc).spread(function(body, header) {
                return [body, header];
            }).catch(function(err) {
                logger.error(err);
                delete jsonDoc._rev;
                return _self.update(jsonDoc, db, reTryCount - 1);
            });
        }).catch(function(err) {
            var errMsg = 'update document error';
            logger.error(errMsg);
            logger.error(jsonDoc);
            logger.error(err);

            response.msg = errMsg;
            response.err.msg = errMsg;
            response.err.errObj = err;
            return Promise.reject(response);
        });
    };

    this.update = async function(jsonDoc, db, reTryCount, errMsg) {
        if (!errMsg) {
            errMsg = 'Out of trials';
        }

        if (utils.isUndefinedOrNull(reTryCount)) {
            reTryCount = 2;
        }

        if (reTryCount === 0) {
            logger.error(errMsg);
            logger.error('update failed<' + jsonDoc._id + '>');
            throw errMsg;
        }

        try {
            return await _self.updateHandler(jsonDoc._id, jsonDoc, db, 'update')
        } catch (error) {
            logger.error(error);
            return _self.update(jsonDoc, db, reTryCount - 1, errMsg)
        }
    };

    //Todo: If by any chance, it comes here without document getting created, there will be exception. But to add a check if document exists everytime is an overhead
    this.addDeleteFlag = function(jsonDoc, db) {
        var response = respJsonUtil.get();

        return db.atomic('all_updates', 'add_delete_flag', jsonDoc._id, {}).spread(function(body, header) {
            return [body, header];
        }).catch(function(err) {
            var errMsg = 'add delete flag failed';
            logger.error(errMsg);
            logger.error(err);
            response.msg = errMsg;
            response.err.msg = errMsg;
            response.err.errObj = err;
            return Promise.reject(response);
        });
    };

    this.delete = async function(jsonDoc, db, reTryCount, errMsg) {
        if (!errMsg) {
            errMsg = 'Out of trials';
        }

        if (utils.isUndefinedOrNull(reTryCount)) {
            reTryCount = MAX_COUCH_RETRY_COUNT;
        }

        if (reTryCount === 0) {
            return Promise.reject(errMsg);
        }

        try {
            let rev = jsonDoc._rev;
            if (!rev) {
                let resp = await db.head(jsonDoc._id);
                rev = JSON.parse(resp[1].etag);
            }
            return await db.destroy(jsonDoc._id, rev);
        } catch (err) {
            logger.error(err);
            delete jsonDoc._rev;
            return _self.delete(jsonDoc, db, reTryCount - 1, errMsg);
        }
    };

    this.addOrder = function(id, orderInfo, db) {
        var response = respJsonUtil.get();
        return db.atomic("all_updates", "add_order", "table_" + id, orderInfo).spread(function(body, header) {
            return [body, header];
        }).catch(function(err) {
            var errMsg = 'add order failed';
            logger.error(err);
            response.msg = errMsg;
            response.err.msg = errMsg;
            response.err.errObj = err;
            return Promise.reject(response);
        });
    };

    this.deleteOrder = function(id, orderInfo, db) {
        var response = respJsonUtil.get();
        return db.atomic("all_updates", "delete_order", "table_" + id, orderInfo).spread(function(body, header) {
            return [body, header];
        }).catch(function(err) {
            var errMsg = 'delete order failed';
            logger.error(err);
            response.msg = errMsg;
            response.err.msg = errMsg;
            response.err.errObj = err;
            return Promise.reject(response);
        });
    };

    this.addKot = function(id, orderInfo, db) {
        var response = respJsonUtil.get();
        return db.atomic("all_updates", "add_kot", "table_" + id, orderInfo).spread(function(body, header) {
            return [body, header];
        }).catch(function(err) {
            var errMsg = 'add kot failed';
            logger.error(err);
            response.msg = errMsg;
            response.err.msg = errMsg;
            response.err.errObj = err;
            return Promise.reject(response);
        });
    };

    this.deleteKot = function(id, orderInfo, db) {
        var response = respJsonUtil.get();
        return db.atomic("all_updates", "delete_kot", "table_" + id, orderInfo).spread(function(body, header) {
            return [body, header];
        }).catch(function(err) {
            var errMsg = 'delete kot failed';
            logger.error(err);
            response.msg = errMsg;
            response.err.msg = errMsg;
            response.err.errObj = err;
            return Promise.reject(response);
        });
    };

    this.addReservation = function(id, reservationInfo, db) {
        var response = respJsonUtil.get();
        return db.atomic("all_updates", "add_reservation", "table_" + id, reservationInfo).spread(function(body, header) {
            return [body, header];
        }).catch(function(err) {
            var errMsg = 'add reservation failed';
            logger.error(err);
            response.msg = errMsg;
            response.err.msg = errMsg;
            response.err.errObj = err;
            return Promise.reject(response);
        });
    };

    this.deleteReservation = function(id, reservationInfo, db) {
        var response = respJsonUtil.get();
        return db.atomic("all_updates", "delete_reservation", "table_" + id, reservationInfo).spread(function(body, header) {
            return [body, header];
        }).catch(function(err) {
            var errMsg = 'delete reservation failed';
            logger.error(err);
            response.msg = errMsg;
            response.err.msg = errMsg;
            response.err.errObj = err;
            return Promise.reject(response);
        });
    };

    this.updateHandler = async function(docId, data, db, updateFuncName, errMsg) {
        try {
            return await db.atomic("all_updates", updateFuncName, docId, data);
        } catch (error) {
            if (error.code === 'ECONNRESET') {
                logger.error('The problem is that the view is not indexed when you add documents to it')
            } else if (error.statusCode === 409) {
                logger.error(error.reason);
            } else {
                logger.error(error);
            }

            throw errMsg;
        }
    };

    this.getReduceValue = async function(designDocName, viewName, dbInstance) {
        try {
            let queryResp = await _self.getView(designDocName, viewName, {
                reduce: true
            }, dbInstance);

            let maxId = 0;
            // build module api
            if (queryResp.length) {
                // maxId = queryResp[0].value;
                maxId = queryResp[0].value;
            }

            return maxId;
        } catch (error) {
            logger.error(error);
            throw 'Reduce Value Query Failed';
        }
    };

    this.bulkInsert = async function(db, docsArray) {
        try {
            let resp = await db.bulk({
                docs: docsArray
            });
            return resp;
        } catch (error) {
            logger.error(error);
            throw 'Bulk Update Failed';
        }
    };

    /**
     * _id is mandatory.. _id is the document name which should be unique.. suggested way is add doctype + ts
     * @param {*} docsArray [{_id: "customer_12345", name: "sai"}, {_id: "customer_56789", name: "linto"}]
     * @param {*} db 
     * @param {*} reTryCount 
     * @param {*} docType string eg: 'customer' add the time stamp with the document.
     * This function doesn't throw exception
     */
    this.bulkDocs = async function(docsArray, db, reTryCount, docType) {
        if (reTryCount === undefined) {
            reTryCount = 99;
        }

        if (reTryCount === 0) {
            throw 'Out of trials';
        }
        if (docType) {
            let ts = parseInt(moment().format("x"));
            docsArray.forEach(function(doc) {
                if (!doc._id) {

                    doc._id = docType + '_' + ts;
                    ts += 1;
                }
            });
        }

        try {
            let resp = await db.bulk({
                docs: docsArray
            });

            let pendingDocs = [];
            for (let i = 0; i < resp.length; i++) {
                if (resp[i].error || resp[i].reason) {
                    if (resp[i].error === 'conflict' || resp[i].reason === 'Document update conflict.') {
                        throw resp[i]._id + ' Document update conflict.';
                    }

                    pendingDocs.push(docsArray[i]);
                }
            }

            if (pendingDocs.length) {
                return await _self.bulkDocs(pendingDocs, db, reTryCount - 1);
            }

            return 0;
        } catch (error) {
            logger.error(error);
            logger.error('bulkInsert2 catch block. Not Expected to come here');
            throw 'Internal Error';
        }
    };

    this.updateDatabaseDir = async function(databasePath) {
        databasePath = JSON.stringify(path.normalize(databasePath));
        try {
            let url = 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT + '/_config/couchdb/database_dir';
            await httpUtils.httpPut(url, databasePath);
        } catch (error) {
            throw 'updateDatabaseDir failed';
        }
    }

    this.getDatabaseDir = async function() {
        try {
            let bCouch2 = await couchDBUtils2.isCouch2();
            let url = '';
            if (bCouch2) {
                url = 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT + '/_node/couchdb@localhost/_config/couchdb/database_dir';
            } else {
                url = 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT + '/_config/couchdb/database_dir';
            }
            let response = await httpUtils.httpGet(url);
            return response.body;
        } catch (error) {
            throw 'getDatabase failed';
        }
    }

    this.getDatabaseDirResolved = async () => {
        if (isWin && !instPathPrefix) {
            let utils = require('../../common/npmUtils');
            try {
                instPathPrefix = await utils.getWinCouchInstDir();
            } catch (error) {
                logger.info('Assuming new couchdb location');
                instPathPrefix = 'C:/ProfitGuru/CouchDB'
            }
            instPathPrefix = path.resolve(instPathPrefix, 'bin');
        }

        let response = await _self.getDatabaseDir();
        if (!path.isAbsolute(response) && instPathPrefix) {
            response = path.resolve(instPathPrefix, response);
        }
        return response;
    }

    this.getViewDirectoryRelative = async () => {
        const configDoc = await _self.getConfigDoc();
        return configDoc.view_index_dir; // relative path
    }

    this.getViewDirectory = async () => {
        const viewRelativePath = await _self.getViewDirectoryRelative();
        let dbPath = await _self.getDatabaseDirResolved();
        // adding dummy path to include CouchDb folder, it is excluded in path
        const viewFullPath = path.resolve(dbPath + "/../CouchDB/CouchDB/" + viewRelativePath);
        return viewFullPath;
    }

};

module.exports = new CouchDBUtils();