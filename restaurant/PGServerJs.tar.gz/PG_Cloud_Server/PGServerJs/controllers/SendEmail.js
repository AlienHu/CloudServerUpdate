//To Do: Add email-template and nodemailer in package.json

var EmailTemplate = require('email-templates').EmailTemplate;
var nodemailer = require('nodemailer');
var path = require('path');

var templateDir = path.resolve(__dirname, '../templates');
var template = new EmailTemplate(path.join(templateDir, 'e-mailTemplate'));

//function to send email to customer
var sendMailToCustomer = function(requestData, response) {
    return new Promise(function(resolve, reject) {
        //3. sender's credentials -- This should also come from app config file
        var credentials = {
            service: 'gmail',
            auth: {
                user: 'sumaltwork@gmail.com',
                pass: 'xxxxx'
            }
        };

        //define nodemailer transporter with the credentials
        var transporter = nodemailer.createTransport(credentials);

        //variable to store emailId
        var custEmailId = requestData.email;

        // ToDo:
        // This data will come in requestData argument. Need to read data and populate it template.
        // Template needs to be finalized.
        var locals = {
            item: {
                name: 'Apple',
                price: '120.0'
            },
            total: '120.0',
            date: '25/03/2017'
        };

        setTimeout(() => {
            console.log('1 seconds Timer expired!!!');
            resolve();
        }, 1000);
        template.render(locals, function(err, results) {
            if (err) {
                console.log(err);
                reject(err);
            }

            console.log(results.html.toString());
            console.log(results.text.toString());

            // ToDo : This mail options needs to be read from app config file
            var mailOptions = {
                from: '"Bill Amount" <sumaltwork@gmail.com>', // sender address
                to: custEmailId, // list of receivers
                subject: "Bill Itenary",
                html: results.html,
                text: results.text
            };

            transporter.sendMail(mailOptions, function(err, responseStatus) {
                if (err) {
                    console.error(err);
                    reject(err);
                };
                console.log(responseStatus);
                resolve(responseStatus);
            })

            console.log(err);
        });
    });
}

module.exports = function(requestData, resposne) {
    return sendMailToCustomer(requestData, resposne);
};