'use strict';

const moment = require('moment');

const couchDBUtils = require('./common/CouchDBUtils');
const responseUtil = require('../common/responseJson');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const logger = require('../common/Logger');
const controllerLib = require('./libraries/itemsControllerLib');
const importHelper = require('./libraries/itemsImportHelper');
const globalConfigController = require('./GlobalConfigurations');
const itemValidator = require('./validatiors/Items');
const utils = require('./common/Utils');

const ARRAY_LENGTH = utils.getArrayLength; //Example of a macro
const ASSIGN_IF_TRUE = utils.assignIfTrue;
const DELETE_KEY_IF_EXIST = utils.deleteKeyIfExist;
const CLONE = utils.clone;

let maxId = require('./common/autoIncrementHelper').getMaxItemId();

const lockUtils = require('../common/lockUtils');
lockUtils.createLockDir('locks/items');
const lockPath = 'locks/items/items.lock';
const lockOptions = lockUtils.lockOptions();

let Items = function() {
    let _self = this;

    //RelaxTodo Write Inheritance Example so that all the files get the default utils by default
    //RelaxTodo All the db values should have proper default values   

    /**          
     * RelaxTodo Don't change the response format
     * RelaxTodo Two documents are written. How do you take care of the inconsistency? 
     *  Change the item flow. First Create the Item. Then Add Initial Stock.
     *  couch create should take errorMessage and return that message
     */
    /**
     * Create Item
     * 1. Create Item Document
     * 2. Create Inventory Document
     */
    let defaultUnitId;
    this.createItemHelper = async function(data) {

        let response = {
            name: data.name
        };

        //RelaxTodoOldDebt Improve Validate data and see that no extra fields are dumped

        try {
            if (!defaultUnitId) {
                defaultUnitId = await globalConfigController.getDefaultUnitId();
            }
            // await lockUtils.lockAsync(lockPath, CLONE(lockOptions));

            let stock = controllerLib.getStock(data, (maxId + 1));
            let itemData = controllerLib.getInitialItemData((maxId + 1), data, stock);
            let invData = controllerLib.getInitialInventoryData((maxId + 1), data.employeeId, stock, itemData.info);

            await itemValidator.validateItemInfo(itemData, invData);
            let errMsg = 'Item Creation Failed. Try Again';
            // let createItemResp = await couchDBUtils.create(itemData, mainDBInstance, 3, errMsg);
            maxId = maxId + 1;
            return [itemData, invData];
        } catch (error) {
            // await lockUtils.unlockAsync(lockPath); //This function doesn't throw exception
            logger.error(error);
            response.error = error;
            throw error;
        }

    };

    this.createItem = async function(data) {
        let response = {
            name: data.name
        };
        try {
            await lockUtils.lockAsync(lockPath, CLONE(lockOptions));
            let [itemData, invData] = await _self.createItemHelper(data);
            // await itemValidator.validateItemInfo(itemData, invData);
            let errMsg = 'Item Creation Failed. Try Again';
            let createItemResp = await couchDBUtils.create(itemData, mainDBInstance, 3, errMsg);
            //RelaxUnhandledCase.  What if second document fails?          
            let createInvResp = await couchDBUtils.create(invData, mainDBInstance, 3, errMsg);
            await lockUtils.unlockAsync(lockPath);
            let item_id = maxId;
            //RelaxUnhandledCase.  What if second document fails?          
            // let createInvResp = await couchDBUtils.create(invData, mainDBInstance, 3, errMsg);
            // await lockUtils.unlockAsync(lockPath);
            response.success = 'Item Successfully Created';
            response.item_id = item_id;
            return response;
        } catch (error) {
            await lockUtils.unlockAsync(lockPath); //This function doesn't throw exception
            logger.error(error);
            response.error = error;
            throw error;
        }
    };

    this.updateItem = async function(data) {
        let response = {
            name: data.name
        };
        let itemData = controllerLib.getItemDataForUpdate(data);

        try {
            //Lock for unique name, category, barcode
            await lockUtils.lockAsync(lockPath, CLONE(lockOptions));
            await itemValidator.validateItemInfo(itemData, null, true);
            let errMsg = 'Item Update Failed. Try Again';
            await couchDBUtils.updateHandler(itemData._id, itemData, mainDBInstance, 'update_item_info', errMsg);
            await lockUtils.unlockAsync(lockPath);
            let invDocId = controllerLib.formatInvDocId(data.item_id);
            let invInfo = controllerLib.getInvDataInfoForUpdate(itemData.info);
            errMsg = 'Item Update Failed. Try Again';
            await couchDBUtils.updateHandler(invDocId, invInfo, mainDBInstance, 'invDocUpdateItemInfo', errMsg);
            response.success = 'Item Successfully Updated';
            response.item_id = itemData.item_id;
            return response;
        } catch (error) {
            await lockUtils.unlockAsync(lockPath); //This function doesn't throw exception
            logger.error(error);
            response.error = error;
            throw error;
        }
    };

    this.updateItemImages = async function(itemId, itemImagesArr) {
        let response = {
            name: itemId
        };
        if (!(itemId && itemImagesArr && itemImagesArr.length)) {
            response.error = "missing param"; // not needed 
            throw "missing param";
        }
        try {
            const itemDoc = await couchDBUtils.getDoc(itemId, mainDBInstance, 'propagate');
            itemDoc.info.images = itemImagesArr;
            await couchDBUtils.update(itemDoc, mainDBInstance);
            response.success = 'Item Image Updated';
            response.item_id = itemId;
            return response;
        } catch (error) {
            logger.error(error);
            response.error = error;
            throw error;
        }
    };

    this.updateBatch = async function(data) {
        let response = {
            msg: ''
        };

        if (!data.stockKey) {
            logger.error('Missing stockKey');
            throw 'Internal Error';
        }

        let itemData = controllerLib.getItemDataForBatchUpdate(data);
        let tempResp = itemValidator.validateBatchInfo(itemData.batches[data.stockKey], true);
        if (!tempResp.bValid) {
            throw tempResp.errMsg;
        }

        try {
            let errMsg = 'Batch Update Failed. Try Again';
            await couchDBUtils.updateHandler(itemData._id, itemData, mainDBInstance, 'update_item_info', errMsg);
            response.msg = 'Successfully updated Batch';
            return response;
        } catch (error) {
            logger.error(error);
            response.msg = error;
            throw response;
        }
    };

    //RelaxClientTodo Write a view to show only IMEI itemAvailable true and sold false
    //RelaxTodo add validation : if imei details, the uniqueDetails length should match
    //RelaxTodo IMEI unique constraint depending on itemAvailable
    //RelaxTodo IMEI validation if adding
    this.updateStock = async function(data) {
        let response = {
            msg: ''
        };

        let uniqueDetailsLength = ARRAY_LENGTH(data.uniqueDetails);
        let bNewStock = data.newQuantity > 0;
        try {
            //sold false or true we will not know. Is he removing because it is already sold or because of entry error (he is removing and he will add again)
            let invData = {};
            controllerLib.updateStockHelper(data, invData, bNewStock, undefined, 'updateStock');

            if (uniqueDetailsLength) {
                //We are locking here because, IMEI details may be manipulated some where else
                await lockUtils.lockAsync(lockPath, CLONE(lockOptions));
                if (bNewStock) {
                    await itemValidator.validateUniqueDetails(invData);
                } else {
                    //validate if details user wants to remove are present in db
                }
            }

            let errMsg = 'Stock Update Failed';
            await couchDBUtils.updateHandler(invData._id, invData, mainDBInstance, 'write_inv_trans', errMsg);
            uniqueDetailsLength ? await lockUtils.unlockAsync(lockPath) : false;
            response.msg = 'Stock Updated Successfully';
            return response;
        } catch (error) {
            uniqueDetailsLength ? await lockUtils.unlockAsync(lockPath) : false;
            response.message = error;
            throw response;
        }

    };

    async function canDeleteItem(requestId, type) {
        requestId = type + '_' + requestId;
        let params = {
            keys: [requestId]
        };
        let queryResponse = await couchDBUtils.getView('all_items_data', 'all_bom_itemid', params, mainDBInstance);
        return queryResponse;
    }

    this.deleteItem = async function(data) {
        let response = {};
        let item_id = data.item_id;
        try {
            let resp = await canDeleteItem(item_id, 'item');
            if (resp.length > 0) {
                throw 'This item is used in few prepared items. Delete Failed';
            }

            let promisesArray = [];
            let errMsg1 = 'Delete Item Failed';
            promisesArray.push(couchDBUtils.updateHandler('item_' + item_id, {}, mainDBInstance, 'add_delete_flag', errMsg1));
            let errMsg2 = 'Delete Inventory Failed';
            promisesArray.push(couchDBUtils.updateHandler(controllerLib.formatInvDocId(item_id), {}, mainDBInstance, 'add_delete_flag', errMsg2));

            await Promise.all(promisesArray);

            response.msg = 'Successfully deleted item';
            return response;
        } catch (error) {
            response.error = error ? error : 'Item Delete Failed';
            logger.error(error);
            throw response;
        }
    };

    this.importItems = function(data, user) {

        return importHelper.importItems(data, user, mainDBInstance, _self);
    }

};

module.exports = new Items();