"use strict";

//Todo: If couchdb sync fails. sequelize operations are rolled back. Is this the expected behaviour? 
//Todo: Bug: For import, if 1 couchdb insert fails, sequelize all the inserts are rolled back. But couchdb docs remain as is
//Todo: return error codes from couchdb sync
var phone = require('node-phonenumber');
var validator = require('validator');
var phoneUtil = phone.PhoneNumberUtil.getInstance();
var responseUtil = require('../common/responseJson');
var lockUtils = require('../common/lockUtils');
var updateTags = require('./ElementsEx').updateTags;
let elements = ['customer', 'supplier'];
var sendSMS = require('../sms/sms');
for (let i = 0; i < elements.length; i++) {
    lockUtils.createLockDir('locks/' + elements[i]);
}

var Elements = function() {
    var _self = this;
    var moment = require('moment');
    var BPromise = require('bluebird');

    require('errors');

    function getLockPath(type) {
        if (type === 'customer_') {
            type = 'customer';
        } else {
            type = 'supplier';
        }
        return 'locks/' + type + '/' + type + '.lock';
    }
    const lockOptions = lockUtils.lockOptions();

    var utils = require('./common/Utils');
    var couchDBUtils = require('./common/CouchDBUtils');
    var mainDBInstance = couchDBUtils.getMainCouchDB();
    var logger = require('../common/Logger');
    var respJsonUtil = require('../common/responseJson');

    function runElementValidations(requestData, isUpdate, bTallyData) {
        //CreditsTodo Make proper Validations
        //valid email, valid pin code, phone
        //unique email, unique phone        

        //Server side Validations, propogate them to clientside as well

        if (validator.isEmpty(String(requestData.phone_number))) {
            delete requestData.phone_number;
            return Promise.reject(' Phone Number Cannot be empty');
        } else {
            try {
                //will throw exception if its not valid phone number
                phoneUtil.parse(String(requestData.phone_number), 'IN');

            } catch (e) {
                return Promise.reject(' Invalid Phone/Mobile Number');
            }
        }

        if (validator.isEmpty(String(requestData.first_name))) {
            delete requestData.first_name;
            return Promise.reject(' First name Cannot be empty');
        }

        if (validator.isEmpty(String(requestData.last_name)) && !bTallyData) {
            delete requestData.first_name;
            return Promise.reject(' Last name Cannot be empty');
        }
        if (requestData.hasOwnProperty('email')) {
            //  if (validator.isEmpty(requestData.email) || ['', ""].indexOf(requestData.email) >= 0) {
            if (validator.isEmpty(requestData.email)) {
                delete requestData.email;
            } else {
                if (!validator.isEmail(requestData.email)) {
                    return Promise.reject(' Invalid EmailId');
                }
            }
        }
        if (requestData.hasOwnProperty('account_number')) {
            if (validator.isEmpty(requestData.account_number + '')) {
                delete requestData.account_number;
            } else {
                if (!validator.isNumeric(requestData.account_number + '')) {
                    return Promise.reject('Account number has to be Numeric');
                }
            }
        }

        if (!isUpdate) { //Create customer Validations

            if (requestData.hasOwnProperty('_rev')) {
                // console.log('Field requestData[\'person_id\']', 'should not Exist while creating New Item');
                delete requestData._rev;
            }

            if (requestData.hasOwnProperty('_id')) {
                // console.log('Field requestData[\'person_id\']', 'should not Exist while creating New Item');
                delete requestData._id;
            }

            if (requestData.hasOwnProperty('person_id')) {
                console.log('Field requestData[\'person_id\']', 'should not Exist while creating New Item');
                delete requestData.person_id;
            }

            if (!requestData.hasOwnProperty('total')) {
                //This is the total transaction amount by the customer/supplier
                requestData.total = 0;
            }
            if (!requestData.hasOwnProperty('credit_balance')) {
                requestData.credit_balance = 0;
            }

        } else {

            if (!requestData.hasOwnProperty('person_id')) {
                return Promise.reject(' Should pass person_id, while update');
            }
            if (!requestData._id) {
                requestData._id = requestData.type + requestData.person_id;
            }
        }

        var params = {
            keys: [requestData.email, requestData.phone_number, 'alien_' + requestData.alienId]
        };

        var docName;
        var viewName;
        if (requestData.type === "customer_") {
            docName = 'all_customers_data';
            viewName = 'all_customers_unique_data';

        } else if (requestData.type === "supplier_") {
            docName = 'all_suppliers_data';
            viewName = 'all_suppliers_unique_data';
        }
        return couchDBUtils.getView(docName, viewName, params, mainDBInstance).then(function(resp) {
            var msg = ' should be unique';

            var bUnique = true;
            for (var i = 0; i < resp.length; i++) {
                if (isUpdate && resp[i].id === requestData._id) {
                    continue;
                }

                var key = resp[i].key;

                if (requestData.email === key) {
                    msg = 'Email ' + requestData.email + msg;
                    bUnique = false;
                }
                if (requestData.phone_number === key) {
                    msg = 'Phone Number ' + requestData.phone_number + ' ' + msg;
                    bUnique = false;
                }
                if ('alien_' + requestData.alienId === key) {
                    msg = 'Alien Number ' + requestData.alienId + ' ' + msg;
                    bUnique = false;
                }
            }

            if (!bUnique) {
                return Promise.reject(msg);
            }
        });
    }
    this.updateTags = async function(tags) {
        try {
            await updateTags(tags);
        } catch (e) {
            logger.error("Tags not added", e);
        }
    }
    this.createCustomerIfNotExists = async function(reqData) {
        var params = {
            keys: [reqData.phone_number, 'alien_' + reqData.alienId]
        };

        let resp = await couchDBUtils.getView('all_customers_data', 'all_customers_unique_data', params, mainDBInstance);
        if (resp.length) {
            var cId = resp[0].id.substr(resp[0].id.indexOf('_') + 1, resp[0].id.length);
            return parseInt(cId);
        } else {
            resp = await _self.create(reqData);
            return resp.data.id;
        }

    }

    this.create = async function(requestData, bTallyData) {
        // console.log("*** Elements.create ", JSON.stringify(requestData, null, 2));
        var response = responseUtil.get2();
        var name = requestData.first_name + ' ' + requestData.last_name;
        var bCalledCreate = false;
        let lockPath = getLockPath(requestData.type);
        if (requestData.tags && requestData.tags.length) {
            this.updateTags(requestData.tags);
        }
        return lockUtils.lockAsync(lockPath, utils.clone(lockOptions)).then(function() {
            return runElementValidations(requestData, undefined, bTallyData);
        }).then(function() {
            var timeStamp = moment().valueOf();
            requestData.person_id = timeStamp;
            requestData._id = requestData.type + timeStamp;
            bCalledCreate = true;
            return couchDBUtils.create(requestData, mainDBInstance);
        }).then(function(couchResponse) {
            lockUtils.unlockAsync(lockPath); //we don't need to wait for completing this? What about import case?
            response.message = name + ' Created Successfully';
            response.data.id = requestData.person_id;
            response.data.name = requestData.first_name;
            response.data.phone_number = requestData.phone_number;

            return response;
        }).catch(function(error) {
            lockUtils.unlockAsync(lockPath);
            if (bCalledCreate) {
                response.error = name + ' Creation Failed';
            } else {
                response.error = error;
            }

            return Promise.reject(response);
        });
    };

    this.update = function(requestData) {
        var response = responseUtil.get2();
        var bCalledUpdate = false;
        var ElementType = requestData.type === "customer_" ? "Customer" : "Supplier";
        let lockPath = getLockPath(requestData.type);
        if (requestData.tags && requestData.tags.length) {
            this.updateTags(requestData.tags);
        }
        return lockUtils.lockAsync(lockPath, utils.clone(lockOptions)).then(function() {
            return runElementValidations(requestData, true);
        }).then(function() {
            bCalledUpdate = true;
            return couchDBUtils.update(requestData, mainDBInstance);
        }).then(function(couchResponse) {
            lockUtils.unlockAsync(lockPath);
            response.message = ElementType + ' update successfully';
            response.data.id = requestData.person_id;
            return response;
        }).catch(function(error) {
            lockUtils.unlockAsync(lockPath);
            if (bCalledUpdate) {

                response.error = 'Failed to update ' + ElementType;
            } else {
                response.error = error;
            }
            return Promise.reject(response);

        });
    };

    this.delete = function(requestData) {
        var response = responseUtil.get2();
        var ElementType = requestData.type === "customer_" ? "Customer" : "Supplier";
        if (!requestData.person_id) {
            response.error = 'Invalid id';
            return Promise.reject(response);
        }
        let lockPath = getLockPath(requestData.type);
        return lockUtils.lockAsync(lockPath, utils.clone(lockOptions)).then(function() {
            return couchDBUtils.addDeleteFlag({
                _id: requestData.type + requestData.person_id
            }, mainDBInstance);
        }).then(function(couchResponse) {
            lockUtils.unlockAsync(lockPath);

            response.message = ElementType + ' deleted successfully';
            response.data.id = requestData.person_id;
            return response;
        }).catch(function(error) {
            lockUtils.unlockAsync(lockPath);

            response.error = 'Failed to delete ' + ElementType;
            return Promise.reject(response);
        });
    }
    let importReqFields = {
        "first_name": "First Name",
        "last_name": "Last Name",
        "gender": "Gender",
        "phone_number": "Phone Number",
        "address_1": "Address 1",
        "address_2": "Address 2",
        "city_name": "City",
        "state_name": "State",
        "pin_code": "Zip",
        "country": "Country",
        "comments": "Comment",
        "company_name": "Company Name",
        "credit_balance": "Credit Balance",
        "credit_limit": "Credit Limit",
        "allow_credit": "Alow Credit",
        "payment_terms": 'Payment term',
        "occupation": 'Occupation',
        "birth_date": 'BirthDate',
        "anniversary": 'Anniversary',
        "customer_since": 'Customer Since',
        "customer_since": "Supplier Since",
        "gstin_number": 'GSTN No',
        "email": 'Email Id',
        "agency_name": 'Agency Name',
        "aadhaar_number": "Adhar Number",
        "account_number": "Account No",
        "bank_name": "Bank Name",
        "bank_branch": "Bank Branch",
        "ifsc_code": "IFSC",
        "micr_code": "MICR CODE",
        "pan_number": "PAN Number",
        "vat_number": "Vat Number",
        "tin_number": "TIN Number",
        "cst_number": "CST Number",
        "tags": "Tags",
        "alienId": "Alien ID",
        "nickName": "Customer Nick Name"
    }
    var numberFields = ['pin_code', 'aadhaar_number', 'account_number', 'micr_code', 'pan_number', 'vat_number', 'tin_number', 'cst_number'];
    var dateFields = ['birth_date', 'anniversary', 'customer_since'];

    function capitalize(str) {
        return str.replace(/\w\S*/g, function(txt) {
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
    }

    var stateList = [];
    var stateListObj = {};

    async function loadStateCodes(coreDBInstance) {
        try {
            let resp = await couchDBUtils.getDoc('stateCodes', coreDBInstance);
            for (var key in resp) {
                if (['_id', '_rev', 'timeStamp'].indexOf(key) < 0) {
                    stateList.push(resp[key].state_name);
                }
                stateListObj[key] = resp[key];
            }
        } catch (error) {
            console.log('tryin again');
            setTimeout(function() {
                loadStateCodes(coreDBInstance);
            }, 1000);
        };
    };

    function formatImportData(data) {
        for (var key in importReqFields) {
            let value = data[importReqFields[key]] ? data[importReqFields[key]] : "";
            if (key === 'state_name') {
                value = capitalize(value);
                if (value && stateList.indexOf(value) === -1) {
                    throw 'Invalid state name';
                }
            }
            data[key] = value;
            if (data.hasOwnProperty([importReqFields[key]])) {
                delete data[importReqFields[key]]
            };
            if (numberFields.indexOf(key) !== -1) {
                data[key] = isNaN(parseInt(data[key])) ? 0 : parseInt(data[key]);
            } else if (dateFields.indexOf(key) !== -1) {
                data[key] = new Date(data[key]);
            }
        }

        if (!data["phone_number"] && data["alienId"]) {
            data["phone_number"] = data["alienId"]
        }
        if (data["alienId"] && !data["nickName"] && data["first_name"]) {
            data["nickName"] = data["first_name"]
        }
        data.gender = data.gender === 'F' ? 1 : 0;
        data.allow_credit = data.allow_credit.toLowerCase() === 'yes' ? 'Allow' : '';
        data.credit_balance = parseFloat(data['credit_balance']) ? parseFloat(data['credit_balance']) : 0;
        data.credit_limit = parseFloat(data['credit_limit']) ? parseFloat(data['credit_limit']) : 0;
        if (data.hasOwnProperty('Customer Since')) {
            data["customer_since"] = new Date(data['Customer Since']);
            delete data['Customer Since'];
        }
        if (data["payment_terms"].toLowerCase() === 'days') {
            data.by_days = parseInt(data["Payment term values"]);
        } else if (data["payment_terms"].toLowerCase() === 'weeks') {
            data.by_weeks = parseInt(data["Payment term values"]);
        } else if (data["payment_terms"].toLowerCase() === 'months') {
            data.by_months = parseInt(data["Payment term values"]);
        }
        if (data.hasOwnProperty("Payment term values")) {
            delete data["Payment term values"];
        }
        if (data.tags) {
            data.tags = data.tags.split("|"); // tags are splited by |
        }
        //by_weeks

    }

    async function createFromArray(personsArray, errResponseArray, succResponseArray, type, bTallyData) {
        //CreditsTodo Not effective improve using bulk insert api.
        var coreDBInstance = couchDBUtils.getCoreCouchDB();
        var i = 0;
        var count = 0;
        let call = 0;
        await loadStateCodes(coreDBInstance);
        return BPromise.each(personsArray, function(personData) {
            i++;

            personData.type = type + '_';
            if (!bTallyData) {
                try {
                    formatImportData(personData);
                } catch (err) {
                    var failedObj = {
                        lineNo: i,
                        name: personData.first_name + ' ' + personData.last_name,
                        reason: err
                    }
                    errResponseArray.push(failedObj);
                    return;
                }
            }
            return _self.create(personData, bTallyData).then(async function(resp) {
                var passedObj = {
                    lineNo: i,
                    name: personData.first_name + ' ' + personData.last_name,
                    id: resp.data.id
                }
                if (personsArray[0].sendWelSMS && resp.data.phone_number) {
                    let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstance);
                    var params = {
                        To: resp.data.phone_number,
                        Msg: applicationSettings.enableSMS.smsMessageAfterAddingCustomer,
                        Type: "PROMO",
                        type: 'customers',
                        Multiple: false,
                        bWelcome: true
                    };
                    params.Msg = params.Msg.replace(/CUSTOMER/g, resp.data.name);
                    params.Msg = params.Msg.replace(/COMPANY/g, applicationSettings.ownersInfo.company);
                    logger.info("sending sms : " + JSON.stringify(params));
                    params.dontUpdate = true;
                    sendSMS(params).then(function(res) {
                        count++;
                    }).catch(function(error) { // not using await, I don' t want to wait! 
                        logger.info('Caught error from elements', error); //catch for UnhandledPromiseRejectionWarning
                    }).finally(function() {
                        call++;
                        console.log("variables", call, personsArray.length);
                        if (call === personsArray.length) {
                            //update the sms count
                            logger.info('finnaly in elements total SMS sent ' + count);
                            let msgCount = parseInt(parseInt(params.Msg.length / 160) + 1);
                            let totalSMSCount = parseInt(count * msgCount);
                            if (!applicationSettings.smsCounter.promoCounter) applicationSettings.smsCounter.promoCounter = 0;
                            applicationSettings.smsCounter.promoCounter += totalSMSCount;
                            couchDBUtils.update(applicationSettings, coreDBInstance).catch(function(e) {
                                logger.error('Caught error from elements', error);
                            })
                        }
                    });
                }
                succResponseArray.push(passedObj);
                return;
            }).catch(function(error) {
                var err = error;
                var errorMsg;
                if (err.msg) {
                    errorMsg = personData.first_name + ' ' + personData.last_name + ' ' + personData.phone_number + ' ' + err.msg;
                } else {
                    var message = '';
                    if (err.errors && err.errors.length !== 0) {
                        message = err.errors[0].message;
                    } else {
                        message = err;
                    }
                    personData.phone_number = personData.phone_number ? personData.phone_number : '';
                    errorMsg = message + '\n' + 'failed ' + type + ' is ' + personData.first_name + ' ' + personData.last_name + ' ' + personData.phone_number;
                }
                var failedObj = {
                    lineNo: i,
                    name: personData.first_name + ' ' + personData.last_name,
                    reason: error.error
                }
                errResponseArray.push(failedObj);
                return;
            });
        })
    }

    /**
     * 
     * @param {*} requestData : Array of json object
     * @param {*} type : 'Supplier' / 'Customer'
     * 
     */
    this.import = function(requestData, type, bTallyData) {
        var response = responseUtil.get2();
        var errResponseArray = [];
        var succResponseArray = [];
        return createFromArray(requestData, errResponseArray, succResponseArray, type, bTallyData).then(function() {
            response.message = succResponseArray.length + " Passed " + errResponseArray.length + " Failed";
            response.data = {
                passed: succResponseArray,
                failed: errResponseArray
            };
            return response;
        }).catch(function(err) {
            console.log(err);
            response.message = succResponseArray.length + " Passed " + errResponseArray.length + " Failed";
            response.data = {
                passed: succResponseArray,
                failed: errResponseArray
            };
            response.error = err;
            return response;
        });
    };

    this.getName = function(id, type) {
        //type sholud be 'customer_' for customer and 'supplier_' for supplier
        var name = '';
        if (!id) {
            return Promise.resolve(name);
        } else {
            return couchDBUtils.getDoc(type + id, mainDBInstance).then(function(resp) {
                if (resp) {
                    name = resp.first_name + ' ' + resp.last_name;
                }

                return Promise.resolve(name);
            }).catch(function(err) {
                return Promise.resolve(name);
            });
        }
    };

    /**
     * This is used in room booking
     */
    this.mergeCustomer = async function(data) {
        data.type = 'customer_';

        let promiseObj;
        if (!data.person_id) {
            promiseObj = _self.create(data);
        } else {
            promiseObj = _self.update(data);
        }

        return await promiseObj;
    };

    this.getNonDeleteCustomer = async function() {
        let liveCustomer = [];
        let customerData = await couchDBUtils.getAllDocsByType('customer', mainDBInstance);
        if (!customerData) {
            return "No Customer found";
        }
        for (var i = 0; i < customerData.length; i++) {
            let customerInfo = customerData[i];
            if (!customerInfo.doc.deleted) {
                liveCustomer.push(customerInfo.doc);
            }
        };
        return liveCustomer;
    }

};
module.exports = new Elements();