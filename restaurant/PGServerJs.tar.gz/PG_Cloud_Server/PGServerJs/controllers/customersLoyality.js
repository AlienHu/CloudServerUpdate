/*
 *      CRUD operation doesn't happen. Giftcard values is through sales only. 
 *      Todo: Because of the above, not syncing CRUD to couchdb also
 */

var customersLoyality = function() {

    var moment = require('moment');
    require('errors');

    // var customersLoyalityModel = require('../models').profitGuru_customersLoyality;

    /*
     *    Giftcards->getGiftCardsRestApi
     *    Pagination Implemenation is left out     
     */
    /*
    this.getAllGiftCards = function() {

        var response = {
            giftcards: []
        };

        return giftCardModel.getAll().then(function(res) {
            response.giftcards = res;
            return response;
        }).catch(function(err) {
            response.err = err;
            return Promise.reject(response);
        });
    };*/

    /*      
     *      Giftcards->createOrUpdateCustomersLoyality
     *      Todo:  
     *      Assuming loyalityValidity is in days 
     *      why two variables customersLoyality_id customersLoyality_number?     
     *      Suppose customer adds 2 giftcards (nov_1 1000, 45 days validity and dec_1 2000, 30 days validity) The current code will result in (dec_1 3000, 30 days validity) 
     *      Each gift card should have it's on validity
     *      record_time .. I would like to use updatedAt or someway to automatically set it whenever we do create/update
     *      skipping languages for return messages
     *      If person is deleted should we delete his customersLoyalitys also? how can it be automated
     */
    this.createOrUpdateCustomersLoyality = function(requestData) {

        var bIsNewCard = true;
        return customersLoyalityModel.findById(requestData.customersLoyality_id).then(function(resp) {
            if (resp) {
                bIsNewCard = false;
            }

            return appConfigModel.findById('loyalityValidity');
        }).then(function(resp) {
            var validity = 0;
            if (resp) {
                validity = parseInt(resp.value);
            }

            var bIsValid = validity === 0;
            if (!bIsNewCard && !bIsValid) {
                var recordTimeMoment = moment(requestData.record_time);
                var diff = moment().diff(recordTimeMoment, 'days');
                if (diff < validity) {
                    bIsValid = true;
                }
            }

            var value = requestData.customersLoyalityvalue;
            if (!bIsNewCard && bIsValid) {
                value += requestData.prevalue;
            }
            var customersLoyalityDataJson = {};
            customersLoyalityDataJson.record_time = moment().format('YYYY-MM-DD HH:mm:ss');
            customersLoyalityDataJson.value = value;
            customersLoyalityDataJson.customer_id = requestData.customer;

            if (bIsNewCard) {
                return customersLoyalityModel.create(customersLoyalityDataJson);
            } else {
                var params = {
                    where: {
                        customersLoyality_id: requestData.customersLoyality_id
                    }
                };
                return customersLoyalityModel.update(customersLoyalityDataJson, params);
            }
        }).then(function(resp) {
            var response = {};
            response.success = true;
            if (resp.dataValues) {
                response.message = 'SuccesFully Created customersLoyality';
                response.customersLoyality_id = resp.dataValues.customersLoyality_id;
            } else {

                response.message = 'SuccesFully Updated customersLoyality';
                response.customersLoyality_id = requestData.customersLoyality_id;
            }
            return response;

        }).catch(function(err) {
            var response = {};
            response.err = err;
            response.success = false;
            response.message = 'customersLoyality request failed';
            if (requestData.customersLoyality_id) {
                response.customersLoyality_id = requestData.customersLoyality_id;
            }

            return Promise.reject(response);
        });
    };

    /*
     *       Giftcards->delete 
     */
    this.delete = function(requestData) {
        var params = {};
        params.where = {};
        params.$or = [];
        for (var i = 0; i < requestData.ids.length; i++) {
            params.$or.push({
                customersLoyality_id: requestData.ids[i]
            });
        }

        return customersLoyalityModel.destroy(params).then(function(resp) {
            var response = {};
            response.success = true;
            response.message = 'customersLoyality successfully deleted';
            return response;
        }).catch(function(err) {
            var response = {};
            response.success = false;
            response.message = 'customersLoyality delete request failed';
            response.err = err;
            return Promise.reject(response);
        });
    };

    /**
     *      customersLoyalityValue
     */
    this.customersLoyalityValue = function(requestData) {
        var response = {
            customersLoyality: []
        };
        return customersLoyalityModel.findAll({
            where: {
                customer_id: requestData.customer_id
            }
        }).then(function(resp) {
            for (var i = 0; i < resp.length; i++) {
                response.customersLoyality.push(resp[i].get({
                    plain: true
                }));
            }

            return response;
        }).catch(function(err) {
            logger.error(err);
            return response;
        });
    };

};

module.exports = new customersLoyality();