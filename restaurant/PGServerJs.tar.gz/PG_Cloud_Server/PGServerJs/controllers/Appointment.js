"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
// const cauch_db_utils = require("../controllers/common/CouchDBUtils");
const cauch_db_utils = require("../controllers/common/CouchDBUtils");
const mainDBInstance = cauch_db_utils.getMainCouchDB();
let couchUsersDbUrl = `http:// ${process.env.COUCHDB_USERNAME}:${process.env.COUCHDB_PASSWORD}@127.0.0.1:${process.env.COUCH_PORT}`;
// var nano = require('nano-blue')(couchUsersDbUrl);
exports.postAppointment = function (payload) {
    return __awaiter(this, void 0, void 0, function* () {
        /* dump json into db */
        let response;
        try {
            // console.log('appointment', payload);
            let insertResult = yield cauch_db_utils.create(payload, mainDBInstance, 2, 'Coutch Db insert issue');
            // console.log("insert=======", insertResult);
            response = { code: "success", message: 'sucessfully added', data: insertResult };
            console.log('----------response---------', response);
            return response;
        }
        catch (e) {
            console.log('errr========', e);
            response = { code: "failed", message: 'failed to add', data: e };
            return response;
        }
    });
};
exports.putAppointment = function (payload) {
    return __awaiter(this, void 0, void 0, function* () {
        /* dump json into db */
        let response;
        try {
            console.log('appointment', payload);
            let updateResult = yield cauch_db_utils.update(payload, mainDBInstance, 2, 'Coutch Db update issue');
            console.log("updateResult=======", updateResult);
            response = { code: "success", message: 'sucessfully update', data: updateResult };
            return response;
        }
        catch (e) {
            console.log('errr========', e);
            response = { code: "failed", message: 'failed to update', data: e };
            return response;
        }
    });
};
