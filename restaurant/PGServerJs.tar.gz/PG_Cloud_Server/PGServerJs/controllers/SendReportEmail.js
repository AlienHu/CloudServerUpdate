//To Do: Add email-template and nodemailer in package.json

var EmailTemplate = require('email-templates').EmailTemplate;
var nodemailer = require('nodemailer');
var path = require('path');
var fs = require('fs');
var templateDir = path.resolve(__dirname, '../templates');
var template = new EmailTemplate(path.join(templateDir, 'e-mailTemplate'));
var templateReport = new EmailTemplate(path.join(templateDir, 'e-reportEmailTemplate'));
var templateCredit = new EmailTemplate(path.join(templateDir, 'e-mailCreditTemplate'));
//https://github.com/nodemailer/nodemailer/issues/176
//function to send email to customer
var sendReportEmail = function (requestData, response) {
    return new Promise(function (resolve, reject) {

        //define nodemailer transporter with the credentials
        var transporter = nodemailer.createTransport({
            host: "smtp.gmail.com",
            secureConnection: false,
            port: 587,
            requiresAuth: true,
            domains: ["gmail.com", "googlemail.com"],
            auth: {
                user: requestData.ownerInfo.email, //'profitguruhelpdesk@gmail.com',
                pass: requestData.ownerInfo.password //'wearethebest'
            }
        });

        //variable to store emailId
        var custEmailId = requestData.email;

        // ToDo:
        // This data will come in requestData argument. Need to read data and populate it template.
        // Template needs to be finalized.
        var locals = {

            userInfo: {
                name: requestData.ownerInfo.name,
                phone: requestData.ownerInfo.phone,
                address: requestData.ownerInfo.address,
                email: requestData.ownerInfo.email,
                website: requestData.ownerInfo.website,
                fax: requestData.ownerInfo.fax,
                location: requestData.ownerInfo.location,
                company: requestData.ownerInfo.company

            },
            reportParams: {
                start: requestData.reportParams.start,
                end: requestData.reportParams.end,
                title: requestData.title
            },
            data: {
                customer: requestData.data.customer,
                nearDueAmt: requestData.data.nearDueDateAmt,
                overDueAmt: requestData.data.overDueDateAmt,
                pendingAmt: requestData.data.pendingAmount,
                totalAmt: requestData.data.total
            }
        };

        if (requestData.data.isCredit) {

            templateCredit.render(locals, function (err, results) {
                if (err) {
                    console.log(err);
                    reject(err);
                }
                var mailOptions = {
                    from: requestData.ownerInfo.name + '" Report" <' + requestData.ownerInfo.email + '>', // sender address
                    to: custEmailId, // list of receivers
                    subject: requestData.subject,
                    html: results.html,
                    text: results.text,
                };

                transporter.sendMail(mailOptions, function (err, responseStatus) {
                    if (err) {
                        console.error(err);
                        reject(err);
                        response.send(new Error(err));
                        response.end();
                    };
                    console.log(responseStatus);
                    resolve(responseStatus);
                    response.send(responseStatus);
                    response.end();
                })

            });
            return;
        }

        setTimeout(() => {
            console.log('1 seconds Timer expired!!!');
            resolve();
        }, 10);
        templateReport.render(locals, function (err, results) {
            if (err) {
                console.log(err);
                reject(err);
            }

            // https://nodemailer.com/about/
            //https://nodemailer.com/message/attachments/

            //CommitTodo :: This was written for completesale. Either make the code common or write new function/file
            var json2csv = require('json2csv');
            var csv = requestData.data.length !== 0 ? json2csv({
                data: requestData.data
            }) : '';

            // ToDo : This mail options needs to be read from app config file
            //CommitTodo: From Body should be changed
            var mailOptions = {
                from: requestData.ownerInfo.name + '" Report" <' + requestData.ownerInfo.email + '>', // sender address
                to: custEmailId, // list of receivers
                subject: requestData.subject,
                html: results.html,
                text: results.text,
                attachments: [{ // utf-8 string as an attachment
                    filename: requestData.title,
                    content: csv
                }

                ]
            };
            if (requestData.emailType == 'Invoice') {
                mailOptions = {
                    from: requestData.ownerInfo.name + ' ' + requestData.emailType + '<' + requestData.ownerInfo.email + '>', // sender address
                    to: custEmailId, // list of receivers
                    subject: requestData.subject,
                    text: 'Thank you for shopping with us. Have a nice day ahead.',
                    attachments: [{
                        filename: requestData.title,
                        path: requestData.invoicePdf,
                        contentType: 'application/pdf'
                    }

                    ]
                }
                if (requestData.title1) {
                    mailOptions.attachments.push({
                        filename: requestData.title1,
                        path: requestData.packDetPdf,
                        contentType: 'application/pdf'
                    });
                }
            }

            transporter.sendMail(mailOptions, function (err, responseStatus) {
                if (err) {
                    console.error(err);
                    // reject(err);
                    var errResponse = {}
                    errResponse.error = {};
                    errResponse.error = err;
                    if (err.code === 'ECONNECTION') {
                        err.error = "Apply Licence Failed , Check your Internet Connection";
                        errResponse.error.message = "Apply Licence Failed , Check your Internet Connection";
                    }
                    errResponse = JSON.stringify(errResponse);
                    response.send(new Error(errResponse));
                    response.end();
                };
                console.log(responseStatus);
                resolve(responseStatus);
                response.send(responseStatus);
                response.end();
            })

        });
    });

}

module.exports = function (requestData, resposne) {
    return sendReportEmail(requestData, resposne);
};