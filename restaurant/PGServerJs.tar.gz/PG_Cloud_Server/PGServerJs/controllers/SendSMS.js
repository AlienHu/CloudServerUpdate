// This controller for send sms
// 1. This SMS send is using twilio. 
// npm install twilio

//To Do: Read the below three required credentials from config file

var credentials = {
    accountSid: 'AC4238f7cfa056fae95706a2f5f716a54e',
    authToken: '3e34c51ee189b61f815cad165db21362',
    sendingNumber: '+16789527080'
};

var sendSMSClient = require('twilio')(credentials.accountSid, credentials.authToken);

var sendSMSToCustomer = function(requestData, applicationSettings, totalAmount) {
    return new Promise(function(resolve, reject) {
        var custNumber;
        var messageBody = applicationSettings.ownersInfo.company + " Your total bill amount : Rs. " + totalAmount;
        //use validator and phoneUtil here to verify number here.
        if (requestData.phone_number == '') {
            reject("Error: Customer Phone number not found!!");
        } else
        if (requestData.phone_number.indexOf("+91") < 0) {
            custNumber = "+91" + requestData.phone_number;
        } else {
            custNumber = requestData.phone_number;
        }

        if (custNumber.length != 13) {
            reject("Error: Incorrect phone number!!");
        }

        sendSMSClient.messages.create({
            from: credentials.sendingNumber,
            to: custNumber,
            body: messageBody
        }, function(err, message) {
            if (err) {
                console.error(err.message);
                reject(err);
            } else {
                console.log(message);
                console.log('SMS sent successfully!!!');
            }
        });
    });
};

module.exports = function(requestData, applicationSettings, totalAmount) {
    return sendSMSToCustomer(requestData, applicationSettings, totalAmount);
};