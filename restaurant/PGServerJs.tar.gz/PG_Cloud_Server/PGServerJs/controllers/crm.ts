/**
 * import/export -> variable/function/interface/class
 *
 */

import * as couchDBUtils from './common/CouchDBUtils';
import * as schedular from './libraries/scheduler';
import * as couchMain from '../couchDb/couchDBMain.js';
import * as follow from 'follow';
import * as moment from 'moment';
import * as logger from '../common/Logger';
import { generateSchedules } from './libraries/scheduleCampaignHelper';
const mainDBInstance: any = couchDBUtils.getMainCouchDB();
const licenceDBInstance: any = couchDBUtils.getLicenceDB();
import * as salesEx from '../TSControllers/SalesEx';
import { compareObject } from '../common/Utils';
import { clone as CLONE } from '../controllers/common/Utils';

export let COMPLETED = 'completed';
export let PENDING = 'pending';
export let FAILED = 'failed';
export const WISHER = 'wisher';
export const AUTOREPORTER = 'autoreporter';
const VISIT_PREFIX = 'visit';
const CRM_TEMPLATE_PREFIX = 'ct';

export let createCampaign = function (data: Campaign): Promise<apiResponse> {
    let ts = moment().format('x');
    data._id = 'cmp_' + ts;
    if (!data.eventDateTime) {
        throw 'EventDateTime is Mandatory.';
    }
    data.eventDateTime = moment(data.eventDateTime).format('x');
    return create(data);
}

export let create = async function (data: BasicCampaign): Promise<apiResponse> {
    let response: apiResponse = {} as apiResponse;
    //console.log(JSON.stringify(data, null, 2));
    try {
        let dataArray = [];
        let { templateType, template, bUpdate }: PrepareTemplateOut = prepareTemplateDoc(data);
        //to create/update document
        if (bUpdate) {
            data.templateType = templateType;
            data.template = template;
            dataArray.push(data.templateType);
        }
        dataArray.push(data);
        await couchDBUtils.bulkDocs(dataArray, mainDBInstance);
        schedular.startJob();

    } catch (error) {
        logger.error(error);
        response.error = 'campaign create failed';
        throw response;
    }

    response.msg = 'campaign create success';
    return response;

}
export let updateCampaign = function (data: Campaign): Promise<apiResponse> {
    if (!data.eventDateTime) {
        throw 'EventDateTime is Mandatory.';
    }
    data.eventDateTime = moment(data.eventDateTime).format('x');
    return update(data);
}
//campaign update
//todo allow to create/update templates from update campaign also
export let update = async function (data: BasicCampaign): Promise<apiResponse> {
    let response: apiResponse = {} as apiResponse;

    try {
        let { templateType, template, bUpdate }: PrepareTemplateOut = prepareTemplateDoc(data);
        data.templateType = templateType;
        data.template = template;
        let dataArray = [];
        if (bUpdate) {
            //to create/update document
            dataArray.push(data.templateType);
        }
        dataArray.push(data);
        await couchDBUtils.bulkDocs(dataArray, mainDBInstance);
    } catch (error) {
        logger.error(error);
        response.error = 'campaign update failed';
        throw response;
    }
    return response;
}

export let deleteCampaign = async function (data: BasicCampaign): Promise<apiResponse> {
    let response: apiResponse = {} as apiResponse;
    try {
        await couchDBUtils.delete(data, mainDBInstance);
    } catch (error) {
        response.error = 'campaign delete failed';
        throw response;
    }
    return response;
}

function prepareTemplateDoc(data: BasicCampaign): PrepareTemplateOut {
    let ts = moment().format('x');
    let template: Template = {
        "message": data.message,
        "bApproved": false,
        "modifiedTs": moment().format('x')
    };
    let templateType: TemplateType;

    let bUpdate: boolean = false;
    if (data.templateTypeName && data.isTemplate) { // add the new template
        templateType = {
            "name": data.templateTypeName,
            "templates": [template],
            "_id": CRM_TEMPLATE_PREFIX + '_' + ts,
            "iPendingCount": 1
        }
        bUpdate = true;
    } else if (data.templateType && data.isTemplate) { // update the template
        templateType = data.templateType;
        templateType.templates.push(template);
        bUpdate = true;
    } else {
        //no create/update is required
    }

    if (bUpdate) {
        logger.error('call sai. update not expected.');
        throw 'call sai';
    }

    return { templateType: templateType, template: template, bUpdate: bUpdate };
}

//Transaction has to be implemented. two different writes are happening 
export let updateTemplateType = async function (inputTemplateType: TemplateType): Promise<apiResponse> {
    if (inputTemplateType._rev) {
        inputTemplateType.isUpdate = true;
    } else {
        let ts: string = moment().format('x');
        inputTemplateType._id = CRM_TEMPLATE_PREFIX + '_' + ts;
    }

    delete inputTemplateType.iPendingCount; //cheating variable use in UI to control edit of pending templates
    let clonedData: TemplateType = CLONE(inputTemplateType);
    getOnlyApprovedTemplates(clonedData);
    const iPendingCount: number = clonedData.iPendingCount;
    //The below is required. Because we are adding only approved templates in maindb
    let dataArr: TemplateType[] = [inputTemplateType, clonedData];

    let dbInstanceArr: any[] = [licenceDBInstance, mainDBInstance];
    let response: apiResponse = {} as apiResponse;

    for (let i: number = 0; i < dbInstanceArr.length; i++) {
        let data: TemplateType = dataArr[i];
        if (data._rev) {
            delete data._rev; //we will fetch it
        };

        let db = dbInstanceArr[i];
        let bDocExist: boolean = false;
        if (data.isUpdate) {
            try {
                let oldTemplate: TemplateType = await couchDBUtils.getDocEx(data._id, db);
                let errorsArr: string[] = [];
                const bEqual: boolean = compareObject(data, oldTemplate, 0, ['_rev'], errorsArr, '');
                if (bEqual) {
                    //already upto date
                    continue;
                }

                data._rev = oldTemplate._rev;
                bDocExist = true;
            } catch (e) {
                // Template doesn't exists in db 
            }
        }

        if (!bDocExist && data._deleted) {
            //doc doesnt exist so no need to delete
            continue;
        }

        if (i === 0 && !data._deleted && iPendingCount === 0) {
            //licencedb, no pending approvals. So better delete it from licencedb
            data._deleted = true;
        }

        try {
            await couchDBUtils.createOrUpdate(data, db);
            response.msg = 'Template Type Updated Successfully.';
        } catch (error) {
            logger.error(error);
            response.error = 'Template Type Update failed';
            throw response;
        }
    }

    return response;
}

function getOnlyApprovedTemplates(data: TemplateType): void {
    let templates: Template[] = [];
    data.iPendingCount = 0;
    for (let i: number = 0; i < data.templates.length; i++) {
        if (data.templates[i].bApproved) {
            templates.push(data.templates[i]);
        } else {
            data.iPendingCount++;
        }
    }

    data.templates = templates;
}

async function getUpdatedTransactions(data: Visit) {
    let custKeys: string[] = [];
    data.customers.forEach(c => {
        custKeys.push(c._id);
    });

    let allCustomers = await couchDBUtils.getAllDocs(custKeys, mainDBInstance);
    let customerDocs = [];
    let lytVisitPnts = salesEx.getVisitPnts();
    for (let i = 0; i < allCustomers.length; i++) {
        if (!allCustomers[i].doc || allCustomers[i].error) {
            throw allCustomers[i].error;
        }
        let ts: string = moment(data.date).format('x');
        let doc = allCustomers[i].doc;
        let date = new Date(parseInt(ts));
        let year = date.getFullYear();
        let month = date.getMonth();
        let key = year + '-' + month;

        if (!doc.stats) {
            doc.stats = {};
        }
        if (!doc.stats[key]) {
            doc.stats[key] = 0;
        }
        if (!doc.visitCount) {
            doc.visitCount = 0;
        }
        if (!doc.loyaltyPnts) {
            doc.loyaltyPnts = 0;
        }
        if (lytVisitPnts && !data._rev) {
            doc.loyaltyPnts += lytVisitPnts;
        }
        if (data.deleted === "1" && doc.loyaltyPnts > lytVisitPnts) {
            doc.loyaltyPnts -= lytVisitPnts;
        }
        if (data.redeem) { // Loyalty redeemed
            if (doc.loyaltyPnts >= data.redeem) {
                doc.loyaltyPnts -= data.redeem;
            } else {
                doc.loyaltyPnts = 0;
            }
        }
        doc.stats[key]++;
        doc.visitCount++;
        doc.lastTS = ts;
        doc.total += data.total;
        customerDocs.push(doc);
    }
    return customerDocs;

}

export let visit = async function (data: Visit): Promise<apiResponse> {

    // console.log("*** crm.visit" + JSON.stringify(data));
    let bUpdate: boolean = false;
    let response: apiResponse = {} as apiResponse;
    if (data._rev) {
        bUpdate = true;
    }
    let ts: string = moment().format('x');
    if (!bUpdate) {
        data._id = VISIT_PREFIX + '_' + ts;
    }
    let dataArray = [];
    dataArray.push(data);
    let customerDocs = [];
    customerDocs = await getUpdatedTransactions(data);
    if (!customerDocs.length) {
        console.log("*** No customers found");
        throw "No customers found";
    }

    dataArray = dataArray.concat(customerDocs);
    try {
        await couchDBUtils.bulkDocs(dataArray, mainDBInstance);
        response.msg = 'Visit added successfully';
    } catch (error) {
        logger.error(error);
        response.error = 'Visit update failed';
        throw response;
    }

    return response;
}

export let createSchedule = async function (data: ScheduledCampaign): Promise<apiResponse> {
    let ts = moment().format('x');
    data._id = 'schedule_' + ts;
    if (!data.timeOfDayArr.length) {
        throw 'Time is Mandatory.';
    }
    generateSchedules(data);
    return create(data);
}

export let updateSchedule = async function (data: ScheduledCampaign): Promise<apiResponse> {
    if (!data.timeOfDayArr) {
        throw 'Time is Mandatory.';
    }
    return update(data);
}

export let saveWisher = async function (data: Wisher): Promise<apiResponse> {
    let ts = moment().format('x');
    if (!data.timeOfDayArr.length) {
        throw 'Time is Mandatory.';
    }
    if (!data._rev) {
        data._id = WISHER + '_' + ts;
        return create(data);
    }
    return update(data);
}

// export let updateDNDArr = async function (data: DNDArr): Promise<apiResponse> {
//     let response: apiResponse = {} as apiResponse;
//     try {
//         let res = await couchDBUtils.createOrUpdate(data, mainDBInstance);
//         console.log(res);
//         response.msg = 'DND list updated successfully';
//         response.data = res;
//     } catch (e) {
//         logger.error(e);
//         response.error = 'DND list updated failed';
//         throw response;
//     }
//     return response;
// }

let checkTemplate = async function (template: TemplateType) {
    logger.silly("Got template for approve" + JSON.stringify(template));

    // create the same document in mainDb and delete the apply doc  

    let clonedData: TemplateType = CLONE(template);
    //because we are adding only approved templates in maindb
    getOnlyApprovedTemplates(clonedData);

    try {

        let oldTemplate: TemplateType = await couchDBUtils.getDoc(clonedData._id, mainDBInstance, 'propagate');//this doesn't throw error!
        let errorsArr: string[] = [];
        const bEqual: boolean = compareObject(clonedData, oldTemplate, 0, ['_rev'], errorsArr, '');
        if (bEqual) {
            //already upto date
            return;
        }
        clonedData._rev = oldTemplate._rev;
        //update in the existing template
    } catch (error) {

    }

    try {
        await couchDBUtils.createOrUpdate(clonedData, mainDBInstance);
    } catch (e) {
        logger.error(e);
        logger.error("Template update failed in maindb. ");
        return;
    }

    let bApproved: boolean = true;
    for (let i: number = 0; i < template.templates.length; i++) {
        if (!template.templates[i].bApproved) {
            bApproved = false;
        }
    }

    if (!bApproved) {
        //no need to delete yet because pending templates are still available
        return;
    }

    try {
        await couchDBUtils.delete(template, licenceDBInstance);
    } catch (error) {
        logger.error(error);
        logger.error('Template update in licencedb failed.');
    }

}

async function listenToChanges() {
    logger.info("listenToChanges.crm.ts");
    let count = 0;
    follow({
        db: couchMain.getLicencedbUrl(),
        include_docs: true,
        filter: function (doc, req) {
            var doctype, uidx;
            if (doc._id && (uidx = doc._id.indexOf('_')) > 0) {
                doctype = doc._id.substring(0, uidx);
                if (doctype === 'ct') {
                    return true;
                }
            }
            return false;
        },
        since: 'now'
    }, function (error, change) {
        if (!error) {
            count++;
            setTimeout(function () {
                count--;
                if (count === 0) {
                    //handle delete
                    if (change.deleted) {
                        //deleted do nothing
                    } else {
                        checkTemplate(change.doc);
                    }
                }
            }, 1000);

        }
    });
}
listenToChanges();
export interface DNDArr {
    _id: string;
    _rev: string;
    numberArr: number[]
}
export interface Wisher extends ScheduledCampaign {
    daysBefore: number;
    type: string;//birth_date,anniversary,
    onType: string,
    repeat: string,
    period: string
}

export interface ScheduledCampaign extends BasicCampaign {
    startDate: Timestamp; //Javascrpt Date Object
    endDate: Timestamp;
    dayOfWeekArr: number[]; //0 -6
    timeOfDayArr: string[]; //Javascript Date Object
    scheduleStatusArr: ScheduleStatus[]
}

export interface ScheduleStatus {
    timestamp: Timestamp;
    status: string;
}

export type Timestamp = string;

interface Visit {
    _id: string,
    _rev: string,
    total: number,
    comments: string,
    customers: CmpCustomers[],
    date: string,
    deleted?: string,
    redeem?: number;
}

export interface Campaign extends BasicCampaign {
    eventDateTime: string;
}

interface TemplateType {
    _id: string;
    _rev?: string;
    name: string; //Birthday, Christmas
    templates: Template[];
    iPendingCount: number; //This is a cheating variable. Update only for doc in maindb. For licencedb it is  0
    isUpdate?: boolean;
    deleted?: string;
    _deleted?: boolean;
}

interface Template {
    message: string;
    modifiedTs: Timestamp;
    bApproved: boolean;
}
export interface CmpCustomers {
    _id: string;
    smsStatus: string;
    email: string;
    cAppStatus: string;
}

export interface notifiAlienInfo {
    [alienId: string]: string
}
export interface notifyParams {
    subject: string;
    info: notifiAlienInfo;
    id: string;
    type: string;
    shopId: string,
    shopName: string,
    shopInfo: any;
}

export interface apiResponse {
    msg: string;
    data: any;
    error: string;
}

interface PrepareTemplateOut {
    templateType: TemplateType;
    template: Template;
    bUpdate: boolean;
}

export interface BasicCampaign {
    message: string;
    template: Template; //Selected Template from TemplateType
    templateType: TemplateType; //Birthday, Christmas full details
    _id: string;
    _rev?: string;
    templateTypeName?: string; //Birthday, Christmas
    isTemplate: boolean; //Save the template checkbox in UI
    sendEmail: boolean;
    sendSMS: boolean;
    customers: CmpCustomers[];
    status: string;
    nextTime: string;
    retryCount: number;
    feedbackFormId?: string;
}