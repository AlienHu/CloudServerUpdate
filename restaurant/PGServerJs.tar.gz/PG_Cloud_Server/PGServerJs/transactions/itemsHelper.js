"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Batches update
 * @param doc
 * @param params
 */
exports.updateStockInfo = function (doc, deltaDoc) {
    let stockInfoItrObj = deltaDoc.batches;
    if (!doc.info.hasBatchNumber && !doc.info.hasVariants) {
        //If item doesn't have batchNumber, update item details also
        let keys = Object.keys(stockInfoItrObj);
        if (keys.length === 1) {
            let batchInfo = stockInfoItrObj[keys[0]];
            //Update all the details to info
            for (let key in batchInfo) {
                doc.info[key] = batchInfo[key];
            }
        }
    }
    for (let stockKey in stockInfoItrObj) {
        doc.batches[stockKey] = stockInfoItrObj[stockKey];
    }
};
exports.writeInvTrans = function (doc, deltaDoc) {
    let stock = doc.stock;
    let transactions = doc.transactions;
    let newTransactions = deltaDoc.transactions;
    let transactions2Delete = deltaDoc.transactions2Delete;
    let deltaStock = deltaDoc.stock;
    if (transactions2Delete) {
        deleteTransactions(doc, stock, transactions, transactions2Delete, deltaStock);
    }
    for (let key in newTransactions) {
        if (!transactions.hasOwnProperty(key) || transactions[key].v !== newTransactions[key].v) {
            transactions[key] = newTransactions[key];
            let stockKey = transactions[key].trans_stockKey; //stockKey is compulsory       
            if (!stock[stockKey]) {
                //New Stock
                stock[stockKey] = {
                    quantity: 0,
                    uniqueDetails: {}
                };
            }
            updateQuantity(doc, stock, deltaStock, stockKey);
            //Check for uniqueDetails
            updateUniqueDetails(stock, deltaStock, stockKey);
        } //have a flag that it is edit and write it here
        // if returns are there don't edit
    }
};
function deleteTransactions(doc, stock, transactions, transactions2Delete, deltaStock) {
    for (let deleteKey in transactions2Delete) {
        if (transactions[deleteKey]) {
            let stockKey = transactions[deleteKey].trans_stockKey; //stockKey is compulsory       
            if (deltaStock[stockKey].bDeleted) {
                //only deleted which were left in the normal loop gets executed here
                updateQuantity(doc, stock, deltaStock, stockKey);
                //Check for uniqueDetails
                updateUniqueDetails(stock, deltaStock, stockKey);
            }
            delete transactions[deleteKey];
        }
    }
}
function updateUniqueDetails(stock, deltaStock, stockKey) {
    let deltaUniqueDetails = deltaStock[stockKey].uniqueDetails;
    let uniqueDetails = stock[stockKey].uniqueDetails;
    for (let detailKey in deltaUniqueDetails) {
        if (uniqueDetails.hasOwnProperty(detailKey)) {
            for (let infoKey in deltaUniqueDetails[detailKey]) {
                uniqueDetails[detailKey][infoKey] = deltaUniqueDetails[detailKey][infoKey]; //The assumption is all the serialnumber, imeidetails are present
            }
        }
        else {
            uniqueDetails[detailKey] = deltaUniqueDetails[detailKey]; //The assumption is all the serialnumber, imeidetails are present
        }
    }
}
function updateQuantity(doc, stock, deltaStock, stockKey) {
    stock[stockKey].quantity += deltaStock[stockKey].quantity;
    doc.quantity += deltaStock[stockKey].quantity;
}
//# sourceMappingURL=itemsHelper.js.map