/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */
var couchViewHelper = require('./couchViewHelper');
var createLicenceDBCouchViews = function() {

    this.ddocs = [{
            _id: '_design/all_provisnd_licences',
            version: 1,
            views: {
                all_provisnd_licences: {
                    map: function(doc) {
                        var doctype, uidx;
                        if (doc._id && (uidx = doc._id.indexOf('_')) > 0) {
                            doctype = doc._id.substring(0, uidx);
                            if (doctype === 'licence') {
                                emit(doc);
                            }
                        }
                    }.toString()
                }
            }
        },
        {
            _id: '_design/all_applied_licences',
            version: 1,
            views: {
                all_applied_licences: {
                    map: function(doc) {
                        var doctype, uidx;
                        if (doc._id && (uidx = doc._id.indexOf('_')) > 0) {
                            doctype = doc._id.substring(0, uidx);
                            if (doctype === 'licenceapply') {
                                emit(doc);
                            }
                        }
                    }.toString()
                }
            }
        },
        {
            _id: '_design/general',
            version: 5,
            filters: {
                localToCloud: function(doc, req) {
                    var doctype, uidx;
                    if (doc._id === 'smsOffer') {
                        return false;
                    }
                    return true;
                }.toString()
            }
        },
        {
            _id: '_design/all_applied_templates',
            version: 3,
            views: {
                all_applied_templates: {
                    map: function(doc) {
                        var doctype, uidx;
                        if (doc._id && (uidx = doc._id.indexOf('_')) > 0) {
                            doctype = doc._id.substring(0, uidx);
                            if (doctype === 'ct') {
                                var bApproved = true;
                                for (var i = 0; i < doc.templates.length; i++) {
                                    if (!doc.templates[i].bApproved) {
                                        bApproved = false;
                                        break;
                                    }
                                }
                                if (!bApproved) {
                                    emit();
                                }
                            }
                        }
                    }.toString()
                }
            }
        }
    ];

};

module.exports = new createLicenceDBCouchViews();