(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var coreDBInstance = couchDBUtils.getCoreCouchDB();
    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const migrationHandler = require('../../../couchDb/migrationHandler');

    describe('Elemets Controller UTs  ', function(done) {

        this.timeout(100000);
        before(function() {
            return couchDbManager.initCouchDb(true);
        });

        //Todo: Delete all Fs created. Get proper path of logDir
        after(function() {

        });

        beforeEach(function() {});

        it('up test', async function() {
            //query appsettingjson and make sure key is presnet

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstance);
            expect(applicationSettings.invoiceSettings.invoiceTitle).equal('INVOICE');

        });

        it('down test', async function() {

            await migrationHandler.migrate('20170711000000-appSettings.js');
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstance);
            expect(applicationSettings.invoiceSettings.hasOwnProperty('invoiceTitle')).equal(false);
            //query appsettingjson and make sure key is not presnet

        });

    });

})();