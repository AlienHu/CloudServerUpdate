   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   const coreDBInstancce = couchDBUtils.getCoreCouchDB();
   const maindb = couchDBUtils.getMainCouchDB();
   const couchDbManager = require('../../../dbManagers/couchDbManager');
   const migrationHandler = require('../../../couchDb/migrationHandler');

   describe('Migration Tests', function() {
       this.timeout(200000);

       before(async function() {
           let bResetDB = false;
           if (!bResetDB) {
               await couchDbManager.initCouchDb(false);
           } else {
               await couchDbManager.initCouchDb(true);
               let commonUtils2 = require('../../common/commonUtils2');

               await commonUtils2.createSomeData(true, true, 21, 21);
               let timeOut = require('../../common/commonUtils').pgTimeOut;
               await timeOut(2e0000);
               process.exit(0);
           }
       });

       it('down', async function() {

           await migrationHandler.migrate('201710160000000-itemManagement4InventoryManager.js');
           let allDocs = await couchDBUtils.getAllDocsByType('receiving', maindb);
           Array.prototype.push.apply(allDocs, await couchDBUtils.getAllDocsByType('receivingReturn', maindb));

           for (let i = 0; i < allDocs.length; i++) {
               let info = allDocs[i].doc.receivings_info;
               if (!info) {
                   info = allDocs[i].doc.info;
               }
               if (!info) {
                   info = allDocs[i].sales_info;
               }

               if (!info) {
                   continue;
               }

               expect(info.hasOwnProperty('GSTIN')).to.equal(false);
               expect(info.hasOwnProperty('state_name')).to.equal(false);
           }

       });

       it('up', async function() {
           await migrationHandler.migrate('201710180000000-gstinstatenames.js');

           let allElementDocs = {};
           let docs = await couchDBUtils.getAllDocsByType('customer', maindb);
           Array.prototype.push.apply(docs, await couchDBUtils.getAllDocsByType('supplier', maindb));
           for (let i = 0; i < docs.length; i++) {
               allElementDocs[docs[i].doc.person_id] = docs[i].doc;
           }

           let allDocs = await couchDBUtils.getAllDocsByType('receiving', maindb);
           Array.prototype.push.apply(allDocs, await couchDBUtils.getAllDocsByType('receivingReturn', maindb));
           Array.prototype.push.apply(allDocs, await couchDBUtils.getAllDocsByType('sale', maindb));
           Array.prototype.push.apply(allDocs, await couchDBUtils.getAllDocsByType('saleReturn', maindb));

           for (let i = 0; i < allDocs.length; i++) {
               let info = allDocs[i].doc.receivings_info;
               if (!info) {
                   info = allDocs[i].doc.info;
               }
               if (!info) {
                   info = allDocs[i].sales_info;
               }

               if (!info) {
                   continue;
               }

               let elementId = info.customer_id;
               if (!elementId) {
                   elementId = info.supplier_id;
               }

               if (!elementId) {
                   continue;
               }

               if (elementId && allElementDocs[elementId]) {
                   let GSTIN = allElementDocs[elementId].gstin_number;
                   let state_name = allElementDocs[elementId].state;
                   if (GSTIN) {
                       expect(info.GSTIN).to.equal(GSTIN);
                   }
                   if (state_name) {
                       expect(info.state_name).to.equal(state_name);
                   }
               }
           }
       });

   });