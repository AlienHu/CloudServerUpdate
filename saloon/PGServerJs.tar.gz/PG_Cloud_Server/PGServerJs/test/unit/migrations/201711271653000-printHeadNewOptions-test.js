'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const coreDBInstancce = couchDBUtils.getCoreCouchDB();
const usersDBInstance = couchDBUtils.getUserCouchDB();
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');

describe('Migration Tests', function() {
    this.timeout(200000);

    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    it('down', async function() {
        var bExpect = false;
        await migrationHandler.migrate('201711080000000-updatingDatabaseDir.js');
        let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('companyHeadWidth')).to.equal(bExpect);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('customerHeadWidth')).to.equal(bExpect);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('companyHeadTextAlign')).to.equal(bExpect);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('customerHeadTextAlign')).to.equal(bExpect);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('headTextAlign')).to.equal(!bExpect);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('headInfoWidth')).to.equal(!bExpect);
    });

    it('up', async function() {
        //userentitlements
        //users
        await migrationHandler.migrate('201711271653000-printHeadNewOptions.js');
        var bExpect = true;
        let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('companyHeadWidth')).to.equal(bExpect);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('customerHeadWidth')).to.equal(bExpect);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('companyHeadTextAlign')).to.equal(bExpect);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('customerHeadTextAlign')).to.equal(bExpect);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('headTextAlign')).to.equal(!bExpect);
        expect(applicationSettings.invoiceSettings.hasOwnProperty('headInfoWidth')).to.equal(!bExpect);
    });

});