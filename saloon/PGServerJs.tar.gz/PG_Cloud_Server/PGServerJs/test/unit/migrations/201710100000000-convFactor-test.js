(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const migrationHandler = require('../../../couchDb/migrationHandler');
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    const coreDBInstancce = couchDBUtils.getCoreCouchDB();
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const testUtils = require('../../common/Utils');

    /**
     * Note: In this test it is down-up
     * Creating data, going down, then going up
     * This way actual validations can happen
     */

    describe('Purchase Migration UTs  ', function(done) {

        this.timeout(100000);
        before(async function() {

            await couchDbManager.initCouchDb(true);
            let commonUtils2 = require('../../common/commonUtils2');

            await commonUtils2.createSomeData(true, true, 0, 21);
        });

        after(function() {

        });

        let quantityArr = [];

        it('down test', async function() {
            await migrationHandler.migrate('201710060000000-userPermissions.js');

            let allPurchaseDocs = await couchDBUtils.getView('all_receivings_info', 'all_time', {
                include_docs: true
            }, mainDBInstance);
            for (let i = 0; i < allPurchaseDocs.length; i++) {
                let doc = allPurchaseDocs[i].doc;
                let items = doc.receiving_items;
                if (!items) {
                    items = doc.items;
                } else {
                    continue;
                }
                for (let j = 0; j < items.length; j++) {
                    expect(items[j].conversionFactor).to.equal(undefined);
                    quantityArr.push(items[j].quantity_purchased);
                }
            }

        });

        it('up test', async function() {
            await migrationHandler.migrate('201710100000000-convFactor.js');

            let allPurchaseDocs = await couchDBUtils.getView('all_receivings_info', 'all_time', {
                include_docs: true
            }, mainDBInstance);
            for (let i = 0; i < allPurchaseDocs.length; i++) {
                let doc = allPurchaseDocs[i].doc;
                let items = doc.receiving_items;
                if (!items) {
                    items = doc.items;
                } else {
                    continue;
                }
                for (let j = 0; j < items.length; j++) {
                    expect(items[j].conversionFactor).to.not.equal(undefined);
                    let quantity_purchased = items[j].quantity_purchased;
                    expect(quantity_purchased * items[j].conversionFactor).to.equal(quantityArr.shift())
                }

            }

        });

    });

})();