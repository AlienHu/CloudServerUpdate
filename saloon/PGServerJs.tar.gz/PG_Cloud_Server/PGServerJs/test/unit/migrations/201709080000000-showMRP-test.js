(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var userDBInstance = couchDBUtils.getUserCouchDB();
    const coreDBInstancce = couchDBUtils.getCoreCouchDB();
    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const migrationHandler = require('../../../couchDb/migrationHandler');

    describe('Elemets Controller UTs  ', function(done) {
        let APP_TYPE = process.env.APP_TYPE;
        this.timeout(100000);
        before(function() {
            return couchDbManager.initCouchDb(false);
        });

        //Todo: Delete all Fs created. Get proper path of logDir 
        after(function() {

        });

        beforeEach(function() {});
        it('down test', async function() {
            await migrationHandler.migrate('201709060000000-invoiceFormatSelect.js');

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
            expect(applicationSettings.paperReceipt.hasOwnProperty('mrp_display')).to.equal(false);
            expect(applicationSettings.barcode.hasOwnProperty('a4')).to.equal(false);

        });

        it('up test', async function() {
            await migrationHandler.migrate('201709080000000-showMRP.js');

            let bUpdate = false;

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);

            expect(applicationSettings.paperReceipt.hasOwnProperty('mrp_display')).to.equal(true);
            expect(applicationSettings.barcode.hasOwnProperty('a4')).to.equal(true);

        });

    });

})();