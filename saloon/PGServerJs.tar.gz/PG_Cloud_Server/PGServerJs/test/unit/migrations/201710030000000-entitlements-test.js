   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   const coreDBInstancce = couchDBUtils.getCoreCouchDB();
   const usersDBInstance = couchDBUtils.getUserCouchDB();
   const couchDbManager = require('../../../dbManagers/couchDbManager');
   const migrationHandler = require('../../../couchDb/migrationHandler');

   describe('Migration Tests', function() {
       this.timeout(200000);
       before(async function() {
           await couchDbManager.initCouchDb(false);

       });

       it('down', async function() {
           await migrationHandler.migrate('201709251100000-invoiceNew.js');
           let allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', coreDBInstancce);
           expect(allowedFeatures.hasOwnProperty('itemManagement')).to.equal(false);
           expect(allowedFeatures.hasOwnProperty('globalConfigs')).to.equal(true);
           let params = {};
           let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
           for (var i = 0; i < allUsers.length; i++) {
               allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
               expect(allUsers[i].value.roles[0].hasOwnProperty('itemManagement')).to.equal(false);
               expect(allUsers[i].value.roles[0].hasOwnProperty('globalConfigs')).to.equal(true);
           }
       });

       it('up', async function() {
           await migrationHandler.migrate('201710030000000-entitlements.js');
           let params = {};
           let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);

           for (var i = 0; i < allUsers.length; i++) {
               allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
               console.log(allUsers[i].value.roles[0]);
               expect(allUsers[i].value.roles[0].hasOwnProperty('itemManagement')).to.equal(true);
               expect(allUsers[i].value.roles[0].hasOwnProperty('globalConfigs')).to.equal(false);
               expect(allUsers[i].value.roles[0].hasOwnProperty('orderCounter')).to.equal(false);
               expect(allUsers[i].value.roles[0].hasOwnProperty('paymentCounter')).to.equal(false);
               expect(allUsers[i].value.roles[0].hasOwnProperty('tableReservations')).to.equal(false);
               expect(allUsers[i].value.roles[0].hasOwnProperty('tallyIntegration')).to.equal(false);

               expect(allUsers[i].value.roles[0].applicationSettings.hasOwnProperty('installUpdate')).to.equal(true);
               expect(allUsers[i].value.roles[0].applicationSettings.hasOwnProperty('viewBackup')).to.equal(true);
               expect(allUsers[i].value.roles[0].applicationSettings.hasOwnProperty('takeBackup')).to.equal(true);
               expect(allUsers[i].value.roles[0].applicationSettings.hasOwnProperty('restoreBackup')).to.equal(true);
               expect(allUsers[i].value.roles[0].applicationSettings.hasOwnProperty('checkApplicationUpdates')).to.equal(true);

               //    expect(allUsers[i].value.roles[0].hasOwnProperty('backUpAndRestore')).to.equal(false);
               //    expect(allUsers[i].value.roles[0].hasOwnProperty('profitGuruUpdate')).to.equal(false);

           }

           let allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', coreDBInstancce);
           expect(allowedFeatures.hasOwnProperty('itemManagement')).to.equal(true);
           expect(allowedFeatures.hasOwnProperty('globalConfigs')).to.equal(false);

       });

   });