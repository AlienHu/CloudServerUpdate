(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const migrationHandler = require('../../../couchDb/migrationHandler');
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    const coreDBInstancce = couchDBUtils.getCoreCouchDB();
    const mainDBInstance = couchDBUtils.getMainCouchDB();

    /**
     * Note: In this test it is down-up
     * Creating data, going down, then going up
     * This way actual validations can happen
     */

    describe('Credit Fix Migration UTs  ', function(done) {

        this.timeout(100000);
        before(async function() {
            let bResetDB = true;
            await couchDbManager.initCouchDb(bResetDB);
            if (bResetDB) {
                let commonUtils2 = require('../../common/commonUtils2');
                //Creating some customers
                await commonUtils2.createSomeData(true, true, 23, 23);
            }
            const commonWorker = require('../../../controllers/workers/commonWorker');
            commonWorker.setFreeze(true);
        });

        after(function() {

        });

        async function validate(type) {

            let queryResp = await couchDBUtils.getAllDocsByType('supplier', mainDBInstance);
            for (let i = 0; i < queryResp.length; i++) {

                expect(queryResp[i].doc.total !== undefined).to.equal(true);
                expect(queryResp[i].doc.total !== NaN).to.equal(true);
                expect(queryResp[i].doc.total !== null).to.equal(true);
                expect(queryResp[i].doc.total >= 0).to.equal(true);
                expect(queryResp[i].doc.credit_balance !== undefined).to.equal(true);
                expect(queryResp[i].doc.credit_balance !== NaN).to.equal(true);
                expect(queryResp[i].doc.credit_balance !== null).to.equal(true);
                expect(queryResp[i].doc.credit_balance >= 0).to.equal(true);
            }
        }

        it('down test', async function() {
            await migrationHandler.migrate('201708220000000-noPopup.js');
            await validate('customer');
            await validate('supplier');

        });

        it('up test', async function() {
            await migrationHandler.migrate('201708230000000-credit.js');
            await validate('customer');
            await validate('supplier');
        });

    });

})();