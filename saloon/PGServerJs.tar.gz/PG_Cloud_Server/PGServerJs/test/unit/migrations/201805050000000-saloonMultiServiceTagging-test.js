(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var mainDBInstance = couchDBUtils.getMainCouchDB();
    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const migrationHandler = require('../../../couchDb/migrationHandler');

    describe('multiple service tagging: saloon', function(done) {

        this.timeout(100000);
        before(function() {
            return couchDbManager.initCouchDb(false);
        });

        it('up', async function() {
            await migrationHandler.migrate('201805050000000-saloonMultiServiceTagging.js');
            let savedAppointments = await couchDBUtils.getAllDocsByType('suspendedSale', mainDBInstance);
            for (let i = 0; i < savedAppointments.length; i++) {
                if (!savedAppointments[i].doc.sales_info.isAppointment) continue;
                for (let s = 0; s < savedAppointments[i].doc.sales_items.length; s++) {
                    if (savedAppointments[i].doc.sales_items[s].appointmentData) {
                        expect(savedAppointments[i].doc.sales_items[s].appointmentData.hasOwnProperty('employees')).equal(true);
                    } else {
                        continue;
                    }
                }
            }

            savedAppointments = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
            for (let i = 0; i < savedAppointments.length; i++) {
                if (!savedAppointments[i].doc.sales_info.isAppointment) continue;
                for (let s = 0; s < savedAppointments[i].doc.sale_items.length; s++) {
                    if (savedAppointments[i].doc.sale_items[s].appointmentData && savedAppointments[i].doc.sale_items[s].ItemType === 'Saloon') {
                        expect(savedAppointments[i].doc.sale_items[s].appointmentData.hasOwnProperty('employees')).equal(true);
                    } else {
                        continue;
                    }
                }
            }
        });

        it('down', async function() {
            await migrationHandler.migrate('201803310000000-barcodeProfilesToDesigns.js');
            let savedAppointments = await couchDBUtils.getAllDocsByType('suspendedSale', mainDBInstance);
            for (let i = 0; i < savedAppointments.length; i++) {
                if (!savedAppointments[i].doc.sales_infoisAppointment) continue;
                for (let s = 0; s < savedAppointments[i].doc.sales_items.length; s++) {
                    if (savedAppointments[i].doc.sales_items[s].appointmentData) {
                        expect(savedAppointments[i].doc.sales_items[s].appointmentData.hasOwnProperty('employees')).equal(false);
                        expect(savedAppointments[i].doc.sales_items[s].appointmentData.hasOwnProperty('employee')).equal(true);
                    } else {
                        continue;
                    }
                }
            }
            savedAppointments = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
            for (let i = 0; i < savedAppointments.length; i++) {
                if (!savedAppointments[i].doc.sales_info.isAppointment) continue;
                for (let s = 0; s < savedAppointments[i].doc.sale_items.length; s++) {
                    if (savedAppointments[i].doc.sale_items[s].ItemType === 'saloon' && savedAppointments[i].doc.sale_items[s].appointmentData) {
                        expect(savedAppointments[i].doc.sale_items[s].appointmentData.hasOwnProperty('employees')).equal(false);
                        expect(savedAppointments[i].doc.sale_items[s].appointmentData.hasOwnProperty('employee')).equal(true);
                    } else {
                        continue;
                    }
                }
            }
        });

    });

})();