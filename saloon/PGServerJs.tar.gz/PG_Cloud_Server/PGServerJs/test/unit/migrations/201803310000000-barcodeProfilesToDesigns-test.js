(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var coreDBInstance = couchDBUtils.getCoreCouchDB();
    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const migrationHandler = require('../../../couchDb/migrationHandler');

    describe('barcode profiles-designs test', function(done) {

        this.timeout(100000);
        before(function() {
            return couchDbManager.initCouchDb(false);
        });

        it('UP: barcode profileList to designs', async function() {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstance);
            expect(applicationSettings.barcode.hasOwnProperty('designs')).equal(true);
            expect(applicationSettings.barcode.hasOwnProperty('currentDesign')).equal(true);
            expect(applicationSettings.barcode.hasOwnProperty('profiles')).equal(true);
            expect(applicationSettings.barcode.hasOwnProperty('currentProfile')).equal(true);
            expect(applicationSettings.barcode.hasOwnProperty('profileList')).equal(false);
        });

        it('DOWN: barcode profileList from designs', async function() {
            await migrationHandler.migrate('201801180000000-gstinstatenames.js');
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstance);
            expect(applicationSettings.barcode.hasOwnProperty('designs')).equal(false);
            expect(applicationSettings.barcode.hasOwnProperty('currentDesign')).equal(false);
            expect(applicationSettings.barcode.hasOwnProperty('profiles')).equal(false);
            expect(applicationSettings.barcode.hasOwnProperty('profileList')).equal(true);
            expect(applicationSettings.barcode.hasOwnProperty('currentProfile')).equal(true);

        });

    });

})();