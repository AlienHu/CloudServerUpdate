(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var userDBInstance = couchDBUtils.getUserCouchDB();
    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const migrationHandler = require('../../../couchDb/migrationHandler');

    describe('Elemets Controller UTs  ', function(done) {
        let APP_TYPE = process.env.APP_TYPE;
        this.timeout(100000);
        before(function() {
            return couchDbManager.initCouchDb(false);
        });

        //Todo: Delete all Fs created. Get proper path of logDir 
        after(function() {

        });

        beforeEach(function() {});

        it('up test', async function() {

            let allUsers = await couchDBUtils.getView('employees', 'all', {}, userDBInstance);
            var allUsersDoc = [];
            let bUpdate = false;
            for (var i = 0; i < allUsers.length; i++) {
                if (allUsers[i].value._id === 'org.couchdb.user:admin' || allUsers[i].value._id === 'org.couchdb.user:admin_retail' || allUsers[i].value._id === 'org.couchdb.user:admin_restaurant') {
                    expect(allUsers[i].value.hasOwnProperty('isDefaultAdmin')).equal(true);
                }
                expect(allUsers[i].value.hasOwnProperty('APP_TYPE')).equal(true);
            }
        });

        it('down test', async function() {
            await migrationHandler.migrate('20170717112300-entitlements.js');
            let allUsers = await couchDBUtils.getView('employees', 'all', {}, userDBInstance);
            var allUsersDoc = [];
            for (var i = 0; i < allUsers.length; i++) {
                if (allUsers[i].value._id === 'org.couchdb.user:admin') {
                    expect(allUsers[i].value.hasOwnProperty('isDefaultAdmin')).equal(false);
                }
                expect(allUsers[i].value.hasOwnProperty('APP_TYPE')).equal(false);
                if (-1 < allUsers[i].value._id.indexOf('org.couchdb.user:admin') && allUsers[i].value._id !== 'org.couchdb.user:admin') {
                    expect(0).equal(1);
                }

            }
        });
    });

})();