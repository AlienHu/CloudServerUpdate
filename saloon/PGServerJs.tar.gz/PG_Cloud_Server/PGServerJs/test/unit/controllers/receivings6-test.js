'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const faker = require('faker');
const profitGuruFaker = require('../../common/profitGuruFaker.js');
const logger = require('../../../common/Logger');
const utils = require('../../common/Utils.js');
const commonUtils = require('../../common/commonUtils');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
let receivingsController;
let commonWorker;

describe('Purchase Controller 6 Purchase Edit UTS', function() {

    this.timeout(500000);
    this.slow(0);

    let allItems;
    let allVariants;
    let supplierArray;
    let prevResponse;
    let prevReceivingId;
    let prevInv = [];
    let prevItem = [];
    let prevSupplier = [];
    let prevTotal = 0;

    const curSession = profitGuruFaker.getFakerSession();
    let applicationSettings = profitGuruFaker.getApplicationSettings();

    before(async function() {
        let logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);

        let bResetDB = true;
        await couchDbManager.initCouchDb(bResetDB);
        commonWorker = require('../../../controllers/workers/commonWorker');
        // commonWorker.setFreeze(true);

        allItems = await commonUtils.createAllItemTypes();
        supplierArray = await commonUtils.getPeople(2, 'supplier');
        allVariants = await couchDBUtils.getAllDocsByType('variant', mainDBInstance, {}, true);
        receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);
    });

    after(function() {});

    async function addItem(itemIndex) {
        let params = {
            item: allItems[itemIndex].item_id
        };
        if (allItems[itemIndex].hasBatchNumber) {
            params.batchId = faker.random.alphaNumeric();
        }

        if (allItems[itemIndex].hasExpiryDate) {
            params.expiry = faker.date.future().toString();
        }
        params.uniqueDetails = [];

        if (allItems[itemIndex].imeiCount !== 0 || allItems[itemIndex].is_serialized) {
            params.quantity = 4;
            for (let i = 0; i < 4; i++) {
                let imeiNumbers = [];
                for (let j = 0; j < allItems[itemIndex].imeiCount; j++) {
                    imeiNumbers.push((faker.random.uuid()).toString());
                }

                params.uniqueDetails.push({
                    serialnumber: (faker.random.uuid()).toString(),
                    imeiNumbers: imeiNumbers
                });
            }
        }

        if (allItems[itemIndex].hasVariants) {
            params.skuName = '';
            params.attributeInfo = {};
            for (let i = 0; i < allItems[itemIndex].attributes.length; i++) {
                let attrId = allItems[itemIndex].attributes[i];
                let attributeValues = Object.keys(allVariants[attrId - 1].values);
                let randAttributeValue = faker.random.arrayElement(attributeValues)
                params.attributeInfo[attrId.toString()] = randAttributeValue;
                params.skuName += '/' + allVariants[attrId - 1].values[randAttributeValue].name;
            }
            params.purchasePrice = allItems[itemIndex].purchasePrice;
            params.sellingPrice = allItems[itemIndex].sellingPrice;
            params.mrp = allItems[itemIndex].mrp;

        }

        return await receivingsController.additem(params);
    }

    function compareDetails(cartIndex, curResponse, inv1, quantity, itemAvailable) {
        let stockKey = curResponse.cart[cartIndex].stockKey;
        expect(inv1.stock[stockKey].quantity).to.equal(quantity);
        let uniqueDetails = inv1.stock[stockKey].uniqueDetails;
        let uniqueDetailsKeys = Object.keys(uniqueDetails);
        expect(uniqueDetailsKeys.length).to.equal(4);
        for (let i = 0; i < quantity; i++) {
            expect(uniqueDetails[uniqueDetailsKeys[i]].itemAvailable).to.equal(itemAvailable);
        }
    }

    //inv transaction check missing
    it('make receiving', async function() {

        let curResponse = await addItem(0);
        curResponse = await addItem(0);
        curResponse = await addItem(1);
        curResponse = await addItem(1);
        curResponse = await addItem(0);

        let paymentParams = {
            payment_type: "Cash",
            amount_tendered: curResponse.amountDue / 2
        };

        curResponse = await receivingsController.add_paymentRestApi(paymentParams);
        paymentParams = {
            payment_type: "Debit Card",
            amount_tendered: curResponse.amountDue
        };

        let param = {
            supplier_id: supplierArray[0]
        };
        curResponse = await receivingsController.addSupplier(param);

        curResponse = await receivingsController.add_paymentRestApi(paymentParams);
        prevResponse = curResponse;
        prevInv.push(await couchDBUtils.getDoc('inventory_1', mainDBInstance));
        prevInv.push(await couchDBUtils.getDoc('inventory_2', mainDBInstance));
        prevItem.push(await couchDBUtils.getDoc('item_1', mainDBInstance));
        prevItem.push(await couchDBUtils.getDoc('item_2', mainDBInstance));
        prevSupplier.push(await couchDBUtils.getDoc('supplier_' + supplierArray[0], mainDBInstance));
        prevSupplier.push(await couchDBUtils.getDoc('supplier_' + supplierArray[1], mainDBInstance));

        let resp = await receivingsController.completeReceivings({
            comment: 'hello world'
        });
        prevReceivingId = resp.receiving_id.substr(5);

        await commonUtils.pgTimeOut(2000);

        let inv1 = await couchDBUtils.getDoc('inventory_1', mainDBInstance);
        expect(prevInv[0].quantity - inv1.quantity).to.equal(-12);
        let prevBatchesLength = allItems[0].batches.length;
        let stockKeys = Object.keys(inv1.stock);
        expect(stockKeys.length).to.equal(prevBatchesLength + 3);
        compareDetails(0, curResponse, inv1, 4, true);
        compareDetails(1, curResponse, inv1, 4, true);
        compareDetails(3, curResponse, inv1, 4, true);
        prevInv[0] = inv1;

        let item1 = await couchDBUtils.getDoc('item_1', mainDBInstance);
        expect(Object.keys(item1.batches).length).to.equal(prevBatchesLength + 3);
        prevItem[0] = item1;

        let inv2 = await couchDBUtils.getDoc('inventory_2', mainDBInstance);
        expect(prevInv[1].quantity - inv2.quantity).to.equal(-2);
        let stockKey = allItems[1].batches[0].stockKey;
        expect(prevInv[1].stock[stockKey].quantity - inv2.stock[stockKey].quantity).to.equal(-2);
        prevInv[1] = inv2;

        let supDoc = await couchDBUtils.getDoc('supplier_' + supplierArray[0], mainDBInstance);
        prevTotal = resp.total;
        expect(supDoc.total - prevSupplier[0].total - resp.total).within(-0.001, 0.001);
        prevSupplier[0] = supDoc;
    });

    it('initReceivingEdit', async function() {
        let curResponse = await receivingsController.initEditPurchaseSession({
            receivingId: 'receiving_' + prevReceivingId
        });

        expect(utils.compareObject(prevResponse, curResponse, 0, ['timeStamp', 'oldStock', 'slab', 'origTaxes'])).to.equal(true);
    });

    it('edit receiving', async function() {
        let curResponse = await receivingsController.delteItemFromCart({
            item: 2
        });
        curResponse = await receivingsController.removeItem({
            item: curResponse.cart[1].item_id,
            stockKey: curResponse.cart[1].batchId
        });
        curResponse.cart[2].sellingPrice = 99;
        curResponse = await receivingsController.editItem(curResponse.cart[2]);

        curResponse = await addItem(0);
        curResponse = await addItem(0);
        expect(curResponse.cart.length).to.equal(5);

        curResponse = await receivingsController.deletePayment({
            paymment_id: "Debit Card"
        });

        let paymentParams = {
            payment_type: "Purchase On Credit",
            amount_tendered: curResponse.amountDue
        };

        let param = {
            supplier_id: supplierArray[1]
        };
        curResponse = await receivingsController.addSupplier(param);

        curResponse = await receivingsController.add_paymentRestApi(paymentParams);

        // commonWorker.setFreeze(true);
        let resp = await receivingsController.completeReceivings({
            comment: 'hello world',
            purchaseIdToEdit: 'receiving_' + prevReceivingId
        });

        await commonUtils.pgTimeOut(4000);

        let inv1 = await couchDBUtils.getDoc('inventory_1', mainDBInstance);
        expect(prevInv[0].quantity - inv1.quantity).to.equal(-4);
        let prevBatchesLength = Object.keys(prevInv[0].stock).length;
        let stockKeys = Object.keys(inv1.stock);
        expect(stockKeys.length).to.equal(prevBatchesLength + 2);
        compareDetails(0, curResponse, inv1, 4, true);
        compareDetails(2, curResponse, inv1, 4, true);
        compareDetails(3, curResponse, inv1, 4, true);
        compareDetails(4, curResponse, inv1, 4, true);
        compareDetails(1, prevResponse, inv1, 0, false);

        prevInv[0] = inv1;

        let item1 = await couchDBUtils.getDoc('item_1', mainDBInstance);
        expect(Object.keys(item1.batches).length).to.equal(prevBatchesLength + 2);
        prevItem[0] = item1;

        let inv2 = await couchDBUtils.getDoc('inventory_2', mainDBInstance);
        expect(prevInv[1].quantity - inv2.quantity).to.equal(1);
        let stockKey = allItems[1].batches[0].stockKey;
        expect(prevInv[1].stock[stockKey].quantity - inv2.stock[stockKey].quantity).to.equal(1);
        prevInv[1] = inv2;

        let supDoc = await couchDBUtils.getDoc('supplier_' + supplierArray[0], mainDBInstance);
        expect(supDoc.total - prevSupplier[0].total + prevTotal).within(-0.001, 0.001);
        supDoc = await couchDBUtils.getDoc('supplier_' + supplierArray[1], mainDBInstance);
        expect(supDoc.total - prevSupplier[1].total - resp.total).within(-0.001, 0.001);
        expect(supDoc.credit_balance - prevSupplier[1].credit_balance - paymentParams.amount_tendered).within(-0.001, 0.001);
    });

});