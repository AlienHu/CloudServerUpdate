   'use strict';
   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;

   var profitGuruFaker = require('../../common/profitGuruFaker.js');
   var profitGuruFakerExt = require('../../common/profitGuruFakerExt.js');
   var commonTestUtils = require('../../common/commonUtils.js');
   var utils = require('../../common/Utils.js');
   var logger = require('../../../common/Logger');
   var faker = require('faker');
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   var couchDB = couchDBUtils.getMainCouchDB();
   let itemControllerLib;

   const couchDbManager = require('../../../dbManagers/couchDbManager');
   var BPromise = require('bluebird');
   var recivingsTestHelper;

   let itemDocs;
   let itemDocIds;
   let prevReceivingId;

   describe('Receivings Variants Controller UTS', function() {

       this.timeout(5000000);
       this.slow(0);

       var applicationSettings = {};
       var curSession = profitGuruFaker.getFakerSession();
       var receivingsController;
       var suppliersArray;
       var retResponse = {};
       var maxRecId = -1;
       var quantityArray = [];

       var batch1 = faker.random.alphaNumeric().toString();
       var batch2 = faker.random.alphaNumeric().toString();
       var batch3 = faker.random.alphaNumeric().toString();
       var batch4 = faker.random.alphaNumeric().toString();
       var batchArray = [batch1, batch2, batch4, batch2, batch3, batch3, batch4];
       var editBatchArray = [batch1, batch2, batch4, batch3];

       before(function() {
           return couchDbManager.initCouchDb(false).then(function(resp) {
               return BPromise.all([commonTestUtils.createGlobalConfigs(5), commonTestUtils.getPeople(5, 'supplier')]);
           }).then(function(resp) {
               let fakerParams = {
                   bFillAll: true,
                   bSerialized: false,
                   bIMEINumber: false,
                   bHasExpiryDate: false,
                   iAttributeCount: 3,
                   bTaxSlab: true
               };

               return BPromise.props({
                   itemDocs: commonTestUtils.getItemWithParams(fakerParams, 7),
                   allSuppliers: commonTestUtils.getPeople(4, 'supplier'),
               });
           }).then(function(promiseResults) {
               suppliersArray = promiseResults.allSuppliers;
               itemDocs = promiseResults.itemDocs;
               itemDocIds = Object.keys(itemDocs);

               expect(suppliersArray.length).to.be.at.least(4);
               expect(itemDocIds.length).to.be.at.least(7);
               applicationSettings = profitGuruFaker.getApplicationSettings();
               itemControllerLib = require('../../../controllers/libraries/itemsControllerLib');
               receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);
               recivingsTestHelper = require('./testHelpers/receivingsTestHelper.js')(curSession);
           });
       });

       after(function() {
           var logDir = '.';
           utils.deleteFilesOfType(logDir, ['log']);
       });

       async function addEditAdd(item_id, i) {
           let params = {
               item: item_id
           };
           params.attributeInfo = {};
           let attributes = itemDocs[item_id][itemControllerLib.formatItemDocId(item_id)].info.attributes;
           for (let j = 0; j < attributes.length; j++) {
               params.attributeInfo[attributes[j]] = 1;
           }

           retResponse = await receivingsController.additem(params);
           params.batchId = (faker.random.alphaNumeric()).toString();
           retResponse = await recivingsTestHelper.editItem(retResponse.cart[i], params.batchId);
           retResponse = await receivingsController.additem(params);
           checkTaxNames(true, retResponse);
           retResponse = await receivingsController.setLocalTax({
               bLocalTax: false
           });
           checkTaxNames(false, retResponse);
           retResponse = await receivingsController.setLocalTax({
               bLocalTax: true
           });
           checkTaxNames(true, retResponse);
       }

       function checkTaxNames(bLocal, response) {
           let notArray = ['GST', 'IGST'];
           if (!bLocal) {
               notArray = ['GST', 'CGST', 'SGST'];
           }

           for (let i = 0; i < response.cart.length; i++) {
               let cartItem = response.cart[i];
               for (let j = 0; j < cartItem.itemTaxList.length; j++) {
                   expect(notArray.indexOf(cartItem.itemTaxList[j].name.toUpperCase())).to.equal(-1);
               }
           }

           for (let key in response.taxes) {
               expect(notArray.indexOf(key.toUpperCase())).to.equal(-1);
           }
       }

       it('additem, edititem, addItemWithBatchParam x2 completesale', async function() {
           for (let i = 0; i < 2; i++) {
               await addEditAdd(itemDocIds[0], i);
           }
           expect(retResponse.cart.length).to.equal(2);
           for (let i = 0; i < retResponse.cart.length; i++) {
               expect(retResponse.cart[i].quantity).to.equal(3);
               expect(retResponse.cart[i].batchId).to.not.equal(undefined);
           }
           await recivingsTestHelper.completeReceivings({
               value: retResponse
           }).then(function(resp) {
               prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
               maxRecId = parseInt(resp.receiving_id.substring(4));
           });
       });

       xit('reset purchase data', async function() {
           var receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);
           let resp = await receivingsController.resetPurchaseInfo();
           let receivingsDoc = await couchDBUtils.getAllDocsByType('receiving', couchDB);
           let inventoryDocs = await couchDBUtils.getAllDocsByType('inventory', couchDB);
           let invUpdateDocs = [];
           for (let j = 0; j < inventoryDocs.length; j++) {
               for (let trans in inventoryDocs[j].doc.transactions) {
                   let type = inventoryDocs[j].doc.transactions[trans].trans_comment.substring(0, 3);
                   if (type === 'PUR') {
                       expect(0).to.equal(1);
                   }
               }
           }
           expect(receivingsDoc.length).to.equal(0);

       });

   });