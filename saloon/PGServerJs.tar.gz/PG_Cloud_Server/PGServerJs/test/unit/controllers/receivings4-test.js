'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const logger = require('../../../common/Logger');
const profitGuruFaker = require('../../common/profitGuruFaker.js');
const profitGuruFaker2 = require('../../common/profitGuruFaker2');
const faker = require('faker');
const moment = require('moment');

const cntrlrUtils = require('../../../controllers/common/Utils');
const ARRAY_LENGTH = cntrlrUtils.getArrayLength;
const CLONE = cntrlrUtils.clone;
const commonTestUtils = require('../../common/commonUtils.js');
const utils = require('../../common/Utils.js');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const computeUtils = require('../../../controllers/common/computeUtils');

const couchDbManager = require('../../../dbManagers/couchDbManager');
let BPromise = require('bluebird');

let allDocs;
const curSession = profitGuruFaker.getFakerSession();
let receivingController;
let itemLib;
let curResponse;

let calculations = {
    total: 0,
    totalNoDiscountNoChargesNoTax: 0,
    totalNoChargesNoTax: 0,
    totalNoTax: 0,
    totalDiscount: 0,
    totalCharges: 0,
    totalTax: 0,
    globalDiscount: 0,
    globalDiscountPercent: 0,
    cart: []
};

describe('Receiving Returns UTS', function() {

    this.timeout(500000);
    this.slow(0);

    before(async function() {
        let logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);

        await couchDbManager.initCouchDb(false);
        allDocs = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance, {}, true);
        expect(allDocs.length).greaterThan(0);
        let applicationSettings = profitGuruFaker.getApplicationSettings();
        receivingController = require('../../../controllers/Receivings')(curSession, applicationSettings);
        itemLib = require('../../../controllers/libraries/itemsControllerLib');
    });

    after(function() {});

    async function getDocs(doc) {
        let supplierDoc;
        if (doc.supplier_id) {
            supplierDoc = await couchDBUtils.getDoc('supplier_' + doc.supplier_id, mainDBInstance);
        }

        let invDocIds = [];
        for (let i = 0; i < doc.items.length; i++) {
            invDocIds.push(itemLib.formatInvDocId(doc.items[i].item_id));
        }
        let invDocs = await couchDBUtils.getAllDocs(invDocIds, mainDBInstance, true);

        return {
            invDocs: invDocs,
            supplierDoc: supplierDoc,
            doc: await couchDBUtils.getDoc('receiving_' + doc.parentId, mainDBInstance)
        };
    }

    function getJsonForReturnAPI(origDoc) {
        let doc = CLONE(origDoc);

        let receivingsInfo = doc.receivings_info;
        doc.parentId = doc.receiving_id;

        delete receivingsInfo.receiving_id;
        delete doc.receiving_id;
        delete doc._id
        delete doc.receivings_info;
        delete doc.status;
        if (doc.mods) {
            delete doc.mods;
        }

        doc.items = doc.receiving_items;
        delete doc.receiving_items;
        let items = doc.items;
        for (let i = 0; i < items.length; i++) {
            items[i].quantity = items[i].quantity_purchased;
        }

        for (let key in receivingsInfo) {
            doc[key] = receivingsInfo[key];
        }
        doc.creditAmt = doc.pending_amount;
        delete doc.pending_amount;
        delete doc.invoice_number;
        delete doc.receiving_time;
        doc.timeStamp = moment().format('x');

        return doc;
    }

    function getRefReceivingReturnDoc(origDoc, timeStamp, returnId) {
        let refReceivingReturnDoc = CLONE(origDoc);

        refReceivingReturnDoc.info = refReceivingReturnDoc.receivings_info;
        refReceivingReturnDoc.info.parentId = refReceivingReturnDoc.receiving_id;
        refReceivingReturnDoc.info.discount = origDoc.discount ? origDoc.discount : {};
        delete refReceivingReturnDoc.receivings_info;
        delete refReceivingReturnDoc.info.receiving_id;
        delete refReceivingReturnDoc.receiving_id;
        refReceivingReturnDoc.items = refReceivingReturnDoc.receiving_items;
        delete refReceivingReturnDoc.receiving_items;

        if (refReceivingReturnDoc.mods) {
            delete refReceivingReturnDoc.mods;
        }
        delete refReceivingReturnDoc.info.pending_amount;
        delete refReceivingReturnDoc.info.type;
        delete refReceivingReturnDoc.info.invoice_number;

        delete refReceivingReturnDoc.info.receiving_time;
        refReceivingReturnDoc.info.time = timeStamp;

        refReceivingReturnDoc._id = 'receivingReturn_' + returnId;
        refReceivingReturnDoc.id = returnId;
        refReceivingReturnDoc.info.id = returnId;

        return refReceivingReturnDoc;
    }

    it('return', async function() {
        let doc = getJsonForReturnAPI(allDocs[0]);

        let prevDocs = await getDocs(doc);

        let resp = await receivingController.completeReturn(doc);
        resp = resp.data.id;
        await commonTestUtils.pgTimeOut(2000);

        let refReceivingReturnDoc = getRefReceivingReturnDoc(allDocs[0], doc.timeStamp, resp);
        let curDocs = await getDocs(doc);

        if (doc.supplier_id) {
            expect(prevDocs.supplierDoc.total - curDocs.supplierDoc.total - doc.total).within(-0.001, 0.001);
        }
        expect(curDocs.doc.mods[curDocs.doc.mods.length - 1]).to.equal(resp);

        let curInvDocs = curDocs.invDocs;
        let prevInvDocs = prevDocs.invDocs;
        let items = doc.items;
        for (let i = 0; i < items.length; i++) {
            let stockKey = items[i].stockKey;
            expect(prevInvDocs[i].stock[stockKey].quantity - curInvDocs[i].stock[stockKey].quantity).to.equal(items[i].quantity * items[i].conversionFactor);
            for (let j = 0; j < items[i].uniqueDetails.length; j++) {
                let uniqueKey = '';
                if (items[i].uniqueDetails[j].serialnumber) {
                    uniqueKey = items[i].uniqueDetails[j].serialnumber;
                } else if (items[i].uniqueDetails[j].imeiNumbers && items[i].uniqueDetails[j].imeiNumbers.length) {
                    uniqueKey = items[i].uniqueDetails[j].imeiNumbers[0];
                }

                expect(curInvDocs[i].stock[stockKey].uniqueDetails[uniqueKey].itemAvailable).to.equal(false);

            }
        }

        let receivingReturnDoc = await couchDBUtils.getDoc('receivingReturn_' + resp, mainDBInstance);
        expect(utils.compareObject(refReceivingReturnDoc, receivingReturnDoc, 0.01, ['_rev', 'status', 'payment_type'])).to.equal(true);

    });

});