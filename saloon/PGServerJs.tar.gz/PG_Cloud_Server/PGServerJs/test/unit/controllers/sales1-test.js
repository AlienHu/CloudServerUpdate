   'use strict';
   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   /**
    *  Todo: Items and other required elements can be created once. No need to drop everytime. Consumes too much time.
    */

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   var profitGuruFaker = require('../../common/profitGuruFaker.js');
   var commonTestUtils = require('../../common/commonUtils.js');
   var faker = require('faker');

   let couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   let mainDBInstance = couchDBUtils.getMainCouchDB();

   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;
   const couchDbManager = require('../../../dbManagers/couchDbManager');
   var BPromise = require('bluebird');
   var itemList;
   var applicationSettings = {};
   var curSession = profitGuruFaker.getFakerSession();
   var customerArray;
   var prevSaleId = -1;
   var suspendedSaleId = -1;

   describe('Sales Controller UTS', function() {

       this.timeout(500000);

       before(function() {
           return couchDbManager.initCouchDb(true).then(function(resp) {
               //TODO BK depricate Models.profitGuru_app_config.initConfig()
               return Promise.all([commonTestUtils.createGlobalConfigs(5), commonTestUtils.getPeople(5, 'supplier')]);
           }).then(function(resp) {
               return BPromise.props({
                   allItems: commonTestUtils.getItems(7, false),
                   allCustomers: commonTestUtils.getPeople(5, 'customer')
               }).then(function(promiseResults) {
                   // console.log(promiseResults);
                   itemList = promiseResults.allItems;
                   customerArray = promiseResults.allCustomers;
                   applicationSettings = profitGuruFaker.getApplicationSettings();
                   expect(customerArray.length).to.be.at.least(5);
                   expect(itemList.length).to.be.at.least(7);
                   // appSettings: Models.profitGuru_app_config.findAll()
                   // promiseResults.appSettings.forEach(function(settingsElement) {
                   //     applicationSettings[settingsElement.key] = settingsElement.value;
                   // });
                   //console.log('Number of Items create=', allItem.length);
               });
           });

       });

       after(function() {});

       it('add Item to Cart', function() {
           curSession = profitGuruFaker.getFakerSession();
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           expect(itemList.length).greaterThan(4);

           var ids = [0, 2, 3, 0, 1, 4, 2, 2, 3];
           var itemIds = [];
           for (var i = 0; i < ids.length; i++) {
               itemIds.push(itemList[ids[i]].item_id);
           }
           var cartLength = [1, 2, 3, 3, 4, 5, 5, 5, 5];
           var quantity = [1, 1, 1, 2, 1, 1, 2, 3, 2];
           var index = 0;

           function testAddItem(id) {
               return salesController.additemRestApi({
                   item: itemIds[index],
                   stockKey: itemList[id].batches[0].stockKey
               }).then(function(resp) {
                   expect(resp.cart.length).to.equal(cartLength[index]);
                   for (var i = 0; i < resp.cart.length; i++) {
                       if (itemIds[index] === resp.cart[i].item_id) {
                           expect(resp.cart[i].quantity).to.equal(quantity[index]);
                       }
                   }
                   index = index + 1;
               });
           }

           return BPromise.each(ids, testAddItem);
       });

       it('delete item from cart (Linked with prev test)', function() {
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           var deleteItemIds = [itemList[0].item_id, itemList[3].item_id];
           return salesController.delteItemFromCart({
               item: 1 //line number
           }).then(function(resp) {
               expect(resp.cart.length).to.equal(4);
               return salesController.delteItemFromCart({
                   item: 3 //line number will not change
               });
           }).then(function(resp) {

               expect(resp.cart.length).to.equal(3);

               for (var i = 0; i < 3; i++) {
                   for (var j = 0; j < 2; j++) {
                       expect(resp.cart[i].item_id).to.not.equal(deleteItemIds[j]);
                   }
               }
           });
       });

       it('remove item from cart (Linked with prev test)', function() {
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           var ids = [2, 4, 2, 2];
           var cartLength = [3, 2, 2, 1];
           var quantity = [2, 0, 1, 0];
           var removeItemIds = [];
           for (var i = 0; i < ids.length; i++) {
               removeItemIds.push(itemList[ids[i]].item_id);
           }

           var index = 0;

           function testRemoveItem(id) {
               return salesController.removeItem({
                   item: removeItemIds[index],
                   stockKey: itemList[id].batches[0].stockKey
               }).then(function(resp) {
                   console.log(resp);
                   expect(resp.cart.length).to.equal(cartLength[index]);
                   for (var i = 0; i < resp.cart.length; i++) {
                       if (removeItemIds[index] === resp.cart[i].item_id) {
                           if (quantity[index] === 0) {
                               expect(1).to.equal(0); //Not expected to come here
                           }
                           expect(resp.cart[i].quantity).to.equal(quantity[index]);
                       }
                   }
                   index = index + 1;
               });
           }

           return BPromise.each(ids, testRemoveItem);
       });

       it('Edit Sale Item', function() {
           var fakerSession = profitGuruFaker.getFakerSession();
           var salesController = require('../../../controllers/Sales')(fakerSession, applicationSettings);
           expect(itemList.length).greaterThan(0);

           return salesController.additemRestApi({
               item: itemList[0].item_id,
               stockKey: itemList[0].batches[0].stockKey
           }).then(function(resp) {
               expect(resp.cart.length).to.equal(1);
               var editItemParams = {
                   line: resp.cart[0].line,
                   price: 100,
                   discount: 5,
                   quantity: 101
               };

               return salesController.editItemRestApi(editItemParams);
           }).then(function(resp) {
               console.log(resp);
               expect(resp.cart.length).to.equal(1);
               expect(resp.cart[0].price).to.equal(100);
               expect(resp.cart[0].quantity).to.equal(101);
           });
       });

       it('Cancel Sale', function() {
           var fakerSession = profitGuruFaker.getFakerSession();
           var salesController = require('../../../controllers/Sales')(fakerSession, applicationSettings);
           expect(itemList.length).greaterThan(0);

           return salesController.additemRestApi({
               item: itemList[0].item_id,
               stockKey: itemList[0].batches[0].stockKey
           }).then(function(resp) {

               expect(resp.cart.length).to.equal(1);
               return salesController.cancel_saleRestApi();
           }).then(function(resp) {
               console.log(resp);
               expect(resp.cart.length).to.equal(0);

           });
       });

       it('make Payments', function() {
           curSession = profitGuruFaker.getFakerSession();
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           expect(itemList.length).greaterThan(0);

           return salesController.additemRestApi({
               item: itemList[0].item_id,
               stockKey: itemList[0].batches[0].stockKey
           }).then(function(resp) {

               expect(resp.cart.length).to.equal(1);
               var paymentParams = {
                   payment_type: "Cash",
                   amount_tendered: resp.amount_due / 2
               };
               return salesController.add_paymentRestApi(paymentParams);
           }).then(function(resp) {
               console.log(resp);
               expect(resp.cart.length).to.equal(1);
               var paymentParams = {
                   payment_type: "Debit Card",
                   amount_tendered: resp.amount_due / 2
               };
               return salesController.add_paymentRestApi(paymentParams);
           }).then(function(resp) {
               console.log(resp);
               expect(resp.cart.length).to.equal(1);
               var paymentParams = {
                   payment_type: "Debit Card",
                   amount_tendered: resp.amount_due
               };
               return salesController.add_paymentRestApi(paymentParams);
           }).then(function(resp) {
               console.log(resp);
               expect(resp.amount_due).to.equal(0);
           });
       });

       it('delete payment cash', function() {
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           return salesController.deletePayment({
               payment_id: 'Cash'
           }).then(function(resp) {
               console.log(resp);
               for (var i = 0; i < resp.payments.length; i++) {
                   expect(resp.payments[i].payment_type).to.not.equal('Cash');
               }
           });
       });

       it('add customer to sale', function() {
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           var param = {
               customer_id: faker.random.arrayElement(customerArray)
           };

           return salesController.addCustomer2Sale(param).then(function(resp) {
               expect(resp.succs_customer_id).to.equal(param.customer_id);
           });
       });

       it('get sales', function() {
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           return salesController.getSales().then(function(resp) {
               console.log(resp);
           });
       });

       /**
        *  1. sales document inserted
        *        1. Check all items are present.
        *        2. Check all the status are 0
        *        3. payments
        *  2. Inventory Document updated?
        *        1. stock for stockKey got decremented properly
        *        2. overall quantity is correct?
        *  3. Don't let the worker process run
        *        Have a global variable called delay or accept/don't accept
        *  4. Check all the status are open in sales
        *        1. last modified time and waitTime
        *  5. Start the process and make sure the tansactions are success now (status closed)
        *  6. Make sales fail and check error messages
        *        Why can sales fail?
        */

       async function completeSale(cashPer, creditPer) {
           curSession = profitGuruFaker.getFakerSession();
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           expect(itemList.length).greaterThan(0);

           try {
               let resp = await salesController.additemRestApi({
                   item: itemList[0].item_id,
                   stockKey: itemList[0].batches[0].stockKey
               })

               expect(resp.cart.length).to.equal(1);
               var paymentParams = {
                   payment_type: "Cash",
                   amount_tendered: resp.total * cashPer
               };
               resp = await salesController.add_paymentRestApi(paymentParams);

               var paymentParams = {
                   payment_type: "Sale on credit",
                   amount_tendered: resp.total * creditPer
               };
               resp = await salesController.add_paymentRestApi(paymentParams);

               expect(resp.amount_due).to.lessThan(0.01);
               expect(resp.cart.length).to.equal(1);
               var param = {
                   customer_id: faker.random.arrayElement(customerArray)
               };
               resp = await salesController.addCustomer2Sale(param);

               resp = await salesController.completeSaleRestApi({
                   comment: 'hello world'
               });

               console.log(resp);
               var saleIdLength = resp.sale_id.length;
               prevSaleId = resp.sale_id.substring(4, saleIdLength);

           } catch (error) {
               console.log(error);
           }
       }
       it('complete sale with partial credit', async function() {
           var perArray = [];
           for (var i = 0; i < 5; i++) {
               var cashPer = faker.random.number({
                   min: 0,
                   max: 0.9
               });
               perArray.push({
                   cashPer: cashPer,
                   creditPer: 1 - cashPer
               });
           }

           for (var i = 0; i < 5; i++) {
               perArray.push({
                   cashPer: 1,
                   creditPer: 0
               });
           }

           for (var i = 0; i < 5; i++) {
               perArray.push({
                   cashPer: 0,
                   creditPer: 1
               });
           }

           for (let i = 0; i < perArray.length; i++) {
               let per = perArray[i];
               await completeSale(per.cashPer, per.creditPer);
           }
           await commonTestUtils.pgTimeOut(2000);
       });

       it('complete sale same item different batch', function() {
           curSession = profitGuruFaker.getFakerSession();
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           expect(itemList.length).greaterThan(0);

           var maxBatches = 0;
           var maxBatchesIdx = 0;
           for (var i = 0; i < itemList.length; i++) {
               var batchesCount = itemList[i].batches.length;
               if (maxBatches < batchesCount) {
                   maxBatches = batchesCount;
                   maxBatchesIdx = i;
               }
           }

           console.log('Batches = ' + maxBatches);
           if (maxBatches < 2) {
               return;
           }

           var batchIndexArray = [];
           for (var i = 0; i < maxBatches; i++) {
               batchIndexArray.push(i);
           }

           var addItemResp = {};
           return BPromise.each(batchIndexArray, function(batchIndex) {
               return salesController.additemRestApi({
                   item: itemList[maxBatchesIdx].item_id,
                   stockKey: itemList[maxBatchesIdx].batches[batchIndex].stockKey
               }).then(function(resp) {
                   addItemResp = resp;
               });
           }).then(function(resp) {
               expect(addItemResp.cart.length).to.equal(maxBatches);
               var paymentParams = {
                   payment_type: "Cash",
                   amount_tendered: addItemResp.total
               };
               return salesController.add_paymentRestApi(paymentParams);
           }).then(function(resp) {
               expect(resp.cart.length).to.equal(maxBatches);
               var param = {
                   customer_id: faker.random.arrayElement(customerArray)
               };
               return salesController.addCustomer2Sale(param);
           }).then(function(resp) {
               return salesController.completeSaleRestApi({});
           }).then(function(resp) {
               console.log(resp);
               var saleIdLength = resp.sale_id.length;
               prevSaleId = resp.sale_id.substring(4, saleIdLength);
           });
       });

       it('reprint sale', function() {
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           var params = {
               saleId: prevSaleId
           };

           return salesController.rePrint(params).then(function(resp) {
               console.log(resp);
           }).catch(function(err) {
               console.log(err);
           });
       });

       //Todo: Add test with payment and without payment
       it('suspend sale', function() {
           curSession = profitGuruFaker.getFakerSession();
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           expect(itemList.length).greaterThan(3);

           return BPromise.each([1, 2, 4], function(itemIndex) {
               return salesController.additemRestApi({
                   item: itemList[itemIndex].item_id,
                   stockKey: itemList[itemIndex].batches[0].stockKey
               });
           }).then(function(resp) {
               return salesController.suspendSale();
           }).then(function(resp) {
               console.log(resp);
           });
       });

       it('all suspended sales', function() {
           var salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
           return salesController.allSuspendedSales().then(function(resp) {
               console.log(resp);
               expect(resp.length).greaterThan(0);
               suspendedSaleId = resp[0].sale_id;
           });
       });

       it('unsuspend sale', function() {
           var salesController = require('../../../controllers/Sales')(profitGuruFaker.getFakerSession(), applicationSettings);
           return salesController.unsuspendSale({
               suspended_sale_id: suspendedSaleId
           }).then(function(resp) {
               console.log(resp);
           });
       });

       it('petrol bunk sale', function() {
           var salesController = require('../../../controllers/Sales')(profitGuruFaker.getFakerSession(), applicationSettings);
           return salesController.completeSaleRestApi({
               item_id: itemList[0].item_id,
               quantity: 5,
               stockKey: itemList[0].batches[0].stockKey,
               discounted_total: 1000
           }).then(function(resp) {
               console.log(resp);
           });
       });

   });