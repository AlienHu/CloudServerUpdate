   'use strict';
   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;

   var profitGuruFaker = require('../../common/profitGuruFaker.js');
   var profitGuruFakerExt = require('../../common/profitGuruFakerExt.js');
   var commonTestUtils = require('../../common/commonUtils.js');
   var utils = require('../../common/Utils.js');
   var logger = require('../../../common/Logger');
   var faker = require('faker');
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   var couchDB = couchDBUtils.getMainCouchDB();

   const couchDbManager = require('../../../dbManagers/couchDbManager');
   var BPromise = require('bluebird');
   var recivingsTestHelper;

   let itemDocs;
   let itemDocIdsWithBatch;
   let prevReceivingId;
   let retResponse = {};

   /** 
    *      What if items quantity is over? Add some items everytime
    */

   describe('Receivings Controller UTS', function() {

       this.timeout(5000000);
       this.slow(0);

       var applicationSettings = {};
       var curSession = profitGuruFaker.getFakerSession();
       var receivingsController;
       var itemsArray = [];
       var itemIdsArray = [];
       var suppliersArray;

       var maxRecId = -1;
       var quantityArray = [];
       let curResponse = {};

       var batch1 = faker.random.alphaNumeric().toString();
       var batch2 = faker.random.alphaNumeric().toString();
       var batch3 = faker.random.alphaNumeric().toString();
       var batch4 = faker.random.alphaNumeric().toString();
       var batchArray = [batch1, batch2, batch4, batch2, batch3, batch3, batch4];
       var editBatchArray = [batch1, batch2, batch4, batch3];

       function getQuantities() {
           return batchesModel.findAll({
               where: {
                   item_id: itemIdsArray
               }
           }).then(function(resp) {
               var retQuants = [];
               //    expect(resp.length).to.equal(itemsArray.length);
               resp.forEach(function(quantityData) {
                   retQuants.push(quantityData.get({
                       plain: true
                   }).quantity);
               });
               return retQuants;
           });
       }

       //RelaxTodo - recv test -> no batches purchase - item info should get update along with default stock
       //RelaxTodo -- complete comparisons uts

       before(function() {
           var logDir = '.';
           utils.deleteFilesOfType(logDir, ['log']);
           return couchDbManager.initCouchDb(true).then(function(resp) {
               return BPromise.all([commonTestUtils.createGlobalConfigs(5), commonTestUtils.getPeople(5, 'supplier')]);
           }).then(function(resp) {
               return BPromise.props({
                   allItems: commonTestUtils.getItems(7, true, 1, 0),
                   allSuppliers: commonTestUtils.getPeople(4, 'supplier'),
               });
           }).then(function(promiseResults) {
               suppliersArray = promiseResults.allSuppliers;
               itemsArray = promiseResults.allItems;

               expect(suppliersArray.length).to.be.at.least(4);
               expect(itemsArray.length).to.be.at.least(7);
               applicationSettings = profitGuruFaker.getApplicationSettings();
               receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);
               recivingsTestHelper = require('./testHelpers/receivingsTestHelper.js')(curSession);
               itemsArray.forEach(function(item) {
                   itemIdsArray.push(item.item_id);
               });

           });
       });

       after(function() {

       });

       it('add item to cart', function() {
           return recivingsTestHelper.addItems2Cart(undefined, undefined, batchArray, itemsArray, retResponse);
       });

       it('add supplier', function() {
           var params = {
               supplier_id: suppliersArray[1]
           };

           return receivingsController.addSupplier(params).then(function(resp) {
               expect(resp.succs_supplier_id).to.equal(params.supplier_id);
           });
       });

       //    it('add supplier with credit', function() {
       //        var params = {
       //            supplier_id: suppliersArray[3]
       //        };

       //        return recivingsTestHelper.addSupplier2Cart(params);
       //    });

       it('complete receivings', async function() {
           var paymentParams = {};
           var payment_types = [];
           payment_types[1] = 'Debit Cart';
           payment_types[0] = "Credit Card";
           paymentParams.amount_tendered = retResponse.value.total / 2;
           let paymentResp;
           for (var paymentType in payment_types) {
               paymentParams.payment_type = payment_types[paymentType];
               paymentResp = await recivingsTestHelper.addPayment(paymentParams);
           }

           expect(retResponse.value.cart.length).to.equal(paymentResp.cart.length);
           let resp = await recivingsTestHelper.completeReceivings(retResponse);
           curResponse = resp;

           prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
           maxRecId = parseInt(resp.receiving_id.substring(4));
           //    return recivingsTestHelper.completeReceivings(retResponse).then(function(resp) {
           //        prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
           //        maxRecId = parseInt(resp.receiving_id.substring(4));
           //    });
       });

       it('reprint test', async function() {

           let recId = curResponse.receiving_id;
           let receiving_id = parseInt(recId.substring(5, recId.length));

           let params = {
               purchaseId: 'receiving_' + receiving_id
           };

           let resp = await receivingsController.rePrint(params);
           let excludeFields = ['item_number', 'is_serialized', 'discountId', 'maxSubLine', 'bReadyForCheckout', 'hasBatchNumber', 'bOTG', 'hasExpiryDate', 'price', 'sellingPriceExcludingTax', 'reorder_level', 'imeiCount', 'origTaxes', 'slab', 'bReadyForCheckout', 'gDiscountValue', 'bGDiscountPercent', 'gDiscountPercent', 'gDiscountAmt', 'print_after_sale', 'globalDiscountInfo', 'profileId', 'bPPTempTaxInclusive', 'discount'];
           expect(utils.compareObject(curResponse, resp, 0.01, excludeFields)).to.equal(true);
       });

   });