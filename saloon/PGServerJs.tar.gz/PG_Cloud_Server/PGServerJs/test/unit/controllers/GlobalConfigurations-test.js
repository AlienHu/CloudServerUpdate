(function() {
    'use strict';

    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    var chai = require("chai");
    var chaiAsPromised = require("chai-as-promised");
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    var utils = require('../../common/Utils.js');
    var profitGuruFaker = require('../../common/profitGuruFaker.js');
    var profitGuruFakerExt = require('../../common/profitGuruFakerExt.js');
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var couchDB = couchDBUtils.getMainCouchDB();

    describe('Global Configurations Controller UTs  ', function() {
        this.timeout(50000);

        var globalConfigController = require('../../../controllers/GlobalConfigurations');
        const helper = require('./testHelpers/GlobalConfigurationsHelper');
        var itemController;
        var configData = {};
        var configId = -1;
        var defaultUnitId = -1;

        before(async function() {
            await couchDbManager.initCouchDb(true);
            itemController = require('../../../controllers/Items');
        });

        beforeEach(function() {});

        it('create category', function() {
            configData = profitGuruFaker.getFakerCategory();
            return globalConfigController.createCategory(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'category', 'name');
            }).then(function(resp) {
                configId = resp;
            });
        });

        it('create duplicate category', function() {
            configData.name = configData.name;
            var bException = false;
            return globalConfigController.createCategory(configData).then(function(resp) {
                //config creation should fail;
                bException = true;
                expect(0).to.equal(1);
            }).catch(function(err) {
                if (bException) {
                    expect(0).to.equal(1);
                }
                //It should come here
            });
        });

        it('update category', function() {
            configData.description = 'Changing Description';
            configData.id = configId;

            return globalConfigController.updateCategory(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'category', 'name');
            });
        });

        it('delete category by id', function() {
            var data = {
                id: configId
            };

            return globalConfigController.deleteCategory(data).then(function(resp) {
                return helper.validateConfigDelete(data.id, 'category');
            }).then(function(resp) {

            }).catch(function(err) {
                console.log(err);
                expect(1).to.equal(0);
            });
        });

        //BMTodo: Handle this very important
        // it('create category with same name after deleting', function() {
        //     return globalConfigController.createCategory(configData).then(function(resp) {
        //         return helper.validateConfigData(resp, configData, 'category', 'name');
        //     }).then(function(resp) {
        //         configId = resp;
        //     });
        // });

        it('create discount', function() {
            configData = profitGuruFaker.getFakerDiscount();
            return globalConfigController.createDiscount(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'discount', 'discount');
            }).then(function(resp) {
                configId = resp;
            });
        });

        it('create duplicate discount', function() {
            var bException = false;
            return globalConfigController.createDiscount(configData).then(function(resp) {
                //config creation should fail;
                bException = true;
                expect(0).to.equal(1);
            }).catch(function(err) {
                if (bException) {
                    expect(0).to.equal(1);
                }
                console.log(err);
            });
        });

        it('update discount', function() {
            configData.discount = configData.discount * 2;
            if (configData.discount > 100) {
                configData.discount = configData.discount / 5;
            }
            configData.id = configId;

            return globalConfigController.updateDiscount(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'discount', 'discount');
            });
        });

        it('delete discount by id', function() {
            var data = {
                id: configId
            };

            return globalConfigController.deleteDiscount(data).then(function(resp) {
                return helper.validateConfigDelete(data.id, 'discount');
            }).then(function(resp) {

            }).catch(function(err) {
                console.log(err);
                expect(1).to.equal(0);
            });
        });

        //BMTodo: Handle this very important
        // it('create discount with same name after deleting', function() {
        //     return globalConfigController.createDiscount(configData).then(function(resp) {
        //         return helper.validateConfigData(resp, configData, 'discount', 'discount');
        //     }).then(function(resp) {
        //         configId = resp;
        //     });
        // });

        it('create unit', function() {
            configData = profitGuruFaker.getFakerUnit();
            return globalConfigController.createUnit(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'unit', 'name');
            }).then(function(resp) {
                configId = resp;
            });
        });

        it('create duplicate unit', function() {
            var bException = false;
            return globalConfigController.createUnit(configData).then(function(resp) {
                //config creation should fail;
                bException = true;
                expect(0).to.equal(1);
            }).catch(function(err) {
                if (bException) {
                    expect(0).to.equal(1);
                }
                console.log(err);
            });
        });

        it('update unit', function() {
            configData.description = 'Changing Description';
            configData.id = configId;

            return globalConfigController.updateUnit(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'unit', 'name');
            });
        });

        it('delete unit by id', function() {
            var data = {
                id: configId
            };

            return globalConfigController.deleteUnit(data).then(function(resp) {
                return helper.validateConfigDelete(data.id, 'unit');
            }).then(function(resp) {

            }).catch(function(err) {
                console.log(err);
                expect(1).to.equal(0);
            });
        });

        it('delete default unit should fail', function() {

            return globalConfigController.getAllConfigDocsByType('unit').then(function(resp) {
                for (var unitIdx in resp) {
                    if (resp[unitIdx].doc.name === '') {
                        configData = resp[unitIdx].doc;
                        defaultUnitId = resp[unitIdx].doc.id;
                    }
                }
                var data = {
                    id: defaultUnitId
                };
                var bException;
                return globalConfigController.deleteUnit(data).then(function(resp) {
                    bException = true;
                    expect(0).to.equal(1);
                }).catch(function(err) {
                    console.log(err);
                    if (bException) {
                        expect(1).to.equal(0);
                    }
                });
            });
        });

        it('create deleted default unit', async function() {
            var bException = false;
            try {
                let resp = await globalConfigController.createDefaultConfigs();

                resp = await globalConfigController.getAllConfigDocsByType('unit');

                for (var unitIdx in resp) {
                    if (resp[unitIdx].doc.name === '' && (!doc.deleted || doc.deleted !== '1')) {
                        bException = true;
                        expect(0).to.equal(1);
                    }
                }

            } catch (error) {
                if (bException) {
                    expect(0).to.equal(1);
                }
            }
        });

        //BMTodo: Handle this very important
        // it('create unit with same name after deleting', function() {
        //     return globalConfigController.createUnit(configData).then(function(resp) {
        //         return helper.validateConfigData(resp, configData, 'unit', 'name');
        //     }).then(function(resp) {
        //         configId = resp;
        //     });
        // });

        it('create tax', function() {
            configData = profitGuruFaker.getFakerTax();
            return globalConfigController.createTax(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'tax', 'percent');
            }).then(function(resp) {
                configId = resp;
            });
        });

        it('create duplicate tax', function() {
            var bException = false;
            return globalConfigController.createTax(configData).then(function(resp) {
                //config creation should fail;
                bException = true;
                expect(0).to.equal(1);
            }).catch(function(err) {
                if (bException) {
                    expect(0).to.equal(1);
                }
                console.log(err);
            });
        });

        it('update tax', function() {
            configData.percent = configData.percent * 2;
            if (configData.percent > 100) {
                configData.percent = configData.percent / 5;
            }
            configData.id = configId;

            return globalConfigController.updateTax(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'tax', 'percent');
            });
        });

        it('delete tax by id', function() {
            var data = {
                id: configId
            };

            return globalConfigController.deleteTax(data).then(function(resp) {
                return helper.validateConfigDelete(data.id, 'tax');
            }).then(function(resp) {

            }).catch(function(err) {
                console.log(err);
                expect(1).to.equal(0);
            });
        });

        //BMTodo: Handle this very important
        // it('create tax with same name after deleting', function() {
        //     return globalConfigController.createTax(configData).then(function(resp) {
        //         return helper.validateConfigData(resp, configData, 'tax', 'percent');
        //     }).then(function(resp) {
        //         configId = resp;
        //     });
        // });

        it('create loyality', function() {
            configData = profitGuruFaker.getFakerLoyality();
            return globalConfigController.createLoyality(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'loyality', 'percent');
            }).then(function(resp) {
                configId = resp;
            });
        });

        it('create duplicate loyality', function() {
            var bException = false;
            return globalConfigController.createLoyality(configData).then(function(resp) {
                //config creation should fail;
                bException = true;
                expect(0).to.equal(1);
            }).catch(function(err) {
                if (bException) {
                    expect(0).to.equal(1);
                }
                console.log(err);
            });
        });

        it('update loyality', function() {
            configData.percent = configData.percent * 2;
            if (configData.percent > 100) {
                configData.percent = configData.percent / 5;
            }
            configData.id = configId;

            return globalConfigController.updateLoyality(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'loyality', 'percent');
            });
        });

        it('delete loyality by id', function() {
            var data = {
                id: configId
            };

            return globalConfigController.deleteLoyality(data).then(function(resp) {
                return helper.validateConfigDelete(data.id, 'loyality');
            }).then(function(resp) {

            }).catch(function(err) {
                console.log(err);
                expect(1).to.equal(0);
            });
        });

        //BMTodo: Handle this very important
        // it('create loyality with same name after deleting', function() {
        //     return globalConfigController.createLoyality(configData).then(function(resp) {
        //         return helper.validateConfigData(resp, configData, 'profitGuru_loyality', 'percent');
        //     }).then(function(resp) {
        //         configId = resp;
        //     });
        // });

        it('create brand', function() {
            configData = profitGuruFaker.getFakerBrand();
            return globalConfigController.createBrand(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'brand', 'name');
            }).then(function(resp) {
                configId = resp;
            });
        });

        it('create duplicate brand', function() {
            var bException = false;
            return globalConfigController.createBrand(configData).then(function(resp) {
                //config creation should fail;
                bException = true;
                expect(0).to.equal(1);
            }).catch(function(err) {
                if (bException) {
                    expect(0).to.equal(1);
                }
                console.log(err);
            });
        });

        it('update brand', function() {
            configData.description = 'Hello World';
            configData.id = configId;

            return globalConfigController.updateBrand(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'brand', 'name');
            });
        });

        it('delete brand by id', function() {
            var data = {
                id: configId
            };

            return globalConfigController.deleteBrand(data).then(function(resp) {
                return helper.validateConfigDelete(data.id, 'brand');
            }).then(function(resp) {

            }).catch(function(err) {
                console.log(err);
                expect(1).to.equal(0);
            });
        });

        it('query all including delted items', function() {
            delete configData.id;

            var type = ['category', 'discount', 'bramd', 'unit', 'tax'];
            return globalConfigController.getAllConfigDocsByType('category').then(function(resp) {

            });
        });

        //BMTodo: Handle this very important
        // it('create brand with same name after deleting', function() {
        //     return globalConfigController.createBrand(configData).then(function(resp) {
        //         return helper.validateConfigData(resp, configData, 'brand', 'name');
        //     }).then(function(resp) {
        //         configId = resp;
        //     });
        // });

        it('create unit to testdelete used one', function() {
            configData = profitGuruFaker.getFakerUnit();
            return globalConfigController.createUnit(configData).then(function(resp) {
                return helper.validateConfigData(resp, configData, 'unit', 'name');
            }).then(function(resp) {
                configId = resp;
            });
        });

        it('create item mandatory', async function() {

            var fakerParams = {
                bFillAll: true,
                bRandom: true,
                bHasBatchNumber: false
            };
            var curItemData = await profitGuruFakerExt.getFakerItem(fakerParams);

            return globalConfigController.getAllConfigDocsByType('unit').then(function(resp) {
                for (var unitIdx in resp) {
                    if (resp[unitIdx].doc.name === '') {
                        defaultUnitId = resp[unitIdx].doc.id;
                    }
                }

                curItemData.purchaseUnitId = defaultUnitId;

                curItemData.sellingUnitId = defaultUnitId;

                return itemController.createItem(curItemData).then(function(resp) {
                    curItemData.item_id = resp.item_id;
                }).catch(function(err) {
                    console.log(err);
                    console.log('error in item creation');
                    expect(1).to.equal(0);
                });
            });

        });

        it('delete unit default without name', function() {
            return globalConfigController.getAllConfigDocsByType('unit').then(function(resp) {
                for (var unitIdx in resp) {
                    if (resp[unitIdx].doc.name === '') {
                        configData = resp[unitIdx].doc;
                        defaultUnitId = resp[unitIdx].doc.id;
                    }
                }
                var data = {
                    id: defaultUnitId
                };
                var bException;

                return globalConfigController.deleteUnit(data).then(function(resp) {
                    return helper.validateConfigDelete(data.id, 'unit');
                }).then(function(resp) {
                    bException = true;
                    expect(0).to.equal(1);
                }).catch(function(err) {
                    console.log(err);
                    if (bException) {
                        expect(0).to.equal(1);
                    }
                    expect(err.msg).to.equal("This default unit cannot be deleted. Delete Failed.");
                });
            });
        });

    });
})();