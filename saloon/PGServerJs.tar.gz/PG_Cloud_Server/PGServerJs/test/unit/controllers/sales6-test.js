'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const logger = require('../../../common/Logger');
const profitGuruFaker = require('../../common/profitGuruFaker.js');
const profitGuruFaker2 = require('../../common/profitGuruFaker2');
const faker = require('faker');
const moment = require('moment');

const cntrlrUtils = require('../../../controllers/common/Utils');
const ARRAY_LENGTH = cntrlrUtils.getArrayLength;
const CLONE = cntrlrUtils.clone;
const commonTestUtils = require('../../common/commonUtils.js');
const utils = require('../../common/Utils.js');
const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const computeUtils = require('../../../controllers/common/computeUtils');
let saleCntrlrLib;

const couchDbManager = require('../../../dbManagers/couchDbManager');
let BPromise = require('bluebird');

let allSalesDocs;
const curSession = profitGuruFaker.getFakerSession();
let salesController;
let itemLib;
let curResponse;

let calculations = {
    total: 0,
    totalNoDiscountNoChargesNoTax: 0,
    totalNoChargesNoTax: 0,
    totalNoTax: 0,
    totalDiscount: 0,
    totalCharges: 0,
    totalTax: 0,
    globalDiscount: 0,
    globalDiscountPercent: 0,
    cart: []
};

describe('Sales Returns UTS', function() {

    this.timeout(500000);
    this.slow(0);

    before(async function() {
        let logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);

        await couchDbManager.initCouchDb(false);
        allSalesDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance, {}, true);
        expect(allSalesDocs.length).greaterThan(0);
        let applicationSettings = profitGuruFaker.getApplicationSettings();
        salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
        itemLib = require('../../../controllers/libraries/itemsControllerLib');
    });

    after(function() {});

    async function getDocs(saleDoc) {
        let customerDoc;
        if (saleDoc.customer_id) {
            customerDoc = await couchDBUtils.getDoc('customer_' + saleDoc.customer_id, mainDBInstance);
        }

        let invDocIds = [];
        for (let i = 0; i < saleDoc.items.length; i++) {
            invDocIds.push(itemLib.formatInvDocId(saleDoc.items[i].item_id));
        }
        let invDocs = await couchDBUtils.getAllDocs(invDocIds, mainDBInstance, true);

        return {
            invDocs: invDocs,
            customerDoc: customerDoc,
            saleDoc: await couchDBUtils.getDoc('sale_' + saleDoc.parentId, mainDBInstance)
        };
    }

    function getJsonForReturnAPI(origSaleDoc) {
        let saleDoc = CLONE(origSaleDoc);

        let salesInfo = saleDoc.sales_info;
        saleDoc.parentId = saleDoc.sale_id;
        delete saleDoc.mods;
        delete salesInfo.sale_id;
        delete saleDoc.sale_id;
        delete saleDoc._id
        delete saleDoc.sales_info;
        delete saleDoc.status;
        if (saleDoc.mods) {
            delete saleDoc.mods;
        }

        saleDoc.items = saleDoc.sale_items;
        delete saleDoc.sale_items;
        let items = saleDoc.items;
        for (let i = 0; i < items.length; i++) {
            items[i].quantity = items[i].quantity_purchased;
            items[i].discount = items[i].discount_percent;
            items[i].price = items[i].sellingPrice;
            delete items[i].quantity_purchased;
            delete items[i].discount_percent;
            delete items[i].sellingPrice;
        }

        for (let key in salesInfo) {
            saleDoc[key] = salesInfo[key];
        }
        saleDoc.creditAmt = saleDoc.pending_amount;
        delete saleDoc.pending_amount;
        delete saleDoc.invoice_number;
        delete saleDoc.sale_time;
        saleDoc.timeStamp = moment().format('x');

        return saleDoc;
    }

    function getRefSaleReturnDoc(origSaleDoc, timeStamp, returnId) {
        let refSaleReturnDoc = CLONE(origSaleDoc);

        refSaleReturnDoc.info = refSaleReturnDoc.sales_info;
        refSaleReturnDoc.info.parentId = refSaleReturnDoc.sale_id;
        delete refSaleReturnDoc.sales_info;
        delete refSaleReturnDoc.info.sale_id;
        delete refSaleReturnDoc.sale_id;
        refSaleReturnDoc.items = refSaleReturnDoc.sale_items;
        delete refSaleReturnDoc.sale_items;
        if (refSaleReturnDoc.mods) {
            delete refSaleReturnDoc.mods;
        }
        delete refSaleReturnDoc.info.pending_amount;
        delete refSaleReturnDoc.info.type;
        delete refSaleReturnDoc.info.invoice_number;

        delete refSaleReturnDoc.info.sale_time;
        refSaleReturnDoc.info.time = timeStamp;

        refSaleReturnDoc._id = 'saleReturn_' + returnId;
        refSaleReturnDoc.id = returnId;
        refSaleReturnDoc.info.id = returnId;

        return refSaleReturnDoc;
    }

    it('return', async function() {
        let saleDoc = getJsonForReturnAPI(allSalesDocs[0]);

        let prevDocs = await getDocs(saleDoc);

        let resp = await salesController.completeReturn(saleDoc);
        resp = resp.data.id;
        await commonTestUtils.pgTimeOut(2000);

        let refSaleReturnDoc = getRefSaleReturnDoc(allSalesDocs[0], saleDoc.timeStamp, resp);
        let curDocs = await getDocs(saleDoc);

        if (saleDoc.customer_id) {
            expect(prevDocs.customerDoc.total - curDocs.customerDoc.total - saleDoc.total).within(-0.001, 0.001);
        }
        expect(curDocs.saleDoc.mods[curDocs.saleDoc.mods.length - 1]).to.equal(resp);

        let curInvDocs = curDocs.invDocs;
        let prevInvDocs = prevDocs.invDocs;
        let items = saleDoc.items;
        for (let i = 0; i < items.length; i++) {
            //If more than 1 batch of same item is added to cart, the below condition is not valid
            //expect(curInvDocs[i].quantity - prevInvDocs[i].quantity).to.equal(items[i].quantity);
            let stockKey = items[i].stockKey;
            //unique details will be in different row in sale .. so it will fail
            //expect(curInvDocs[i].stock[stockKey].quantity - prevInvDocs[i].stock[stockKey].quantity).to.equal(items[i].quantity);
            let uniqueKey = '';
            if (items[i].serialnumber) {
                uniqueKey = items[i].serialnumber;
            } else if (items[i].imeiNumbers && items[i].imeiNumbers.length) {
                uniqueKey = items[i].imeiNumbers[0];
            }
            if (uniqueKey) {
                expect(curInvDocs[i].stock[stockKey].uniqueDetails[uniqueKey].sold).to.equal(false);
            }
        }

        let saleReturnDoc = await couchDBUtils.getDoc('saleReturn_' + resp, mainDBInstance);
        expect(utils.compareObject(refSaleReturnDoc, saleReturnDoc, 0.01, ['_rev'])).to.equal(true);

    });

    it('suspend, list, unsuspend sale return', async function() {
        let saleDoc1 = getJsonForReturnAPI(allSalesDocs[0]);
        saleDoc1.hi = 'hello1';
        let saleDoc2 = getJsonForReturnAPI(allSalesDocs[0]);
        saleDoc2.hi = 'hello2';
        let saleDoc3 = getJsonForReturnAPI(allSalesDocs[0]);
        saleDoc3.hi = 'hello3';

        let prevSuspendedList = await couchDBUtils.getAllDocsByType('suspendSaleReturn', mainDBInstance);
        let offset = prevSuspendedList.length;

        await salesController.suspendReturn(saleDoc1);
        let resp = await salesController.allSuspendedReturns();
        resp = resp.data;
        expect(resp.length).to.equal(offset + 1);
        await salesController.suspendReturn(saleDoc2);
        resp = await salesController.allSuspendedReturns();
        resp = resp.data;
        expect(resp.length).to.equal(offset + 2);
        resp = await salesController.unsuspendReturn({
            _id: resp[offset + 0]._id
        });
        resp = resp.data;
        expect(utils.compareObject(saleDoc1, resp, 0, ['_rev'])).to.equal(true);
        resp = await salesController.allSuspendedReturns();
        resp = resp.data;
        expect(resp.length).to.equal(offset + 1);
        await salesController.suspendReturn(saleDoc3);
        resp = await salesController.allSuspendedReturns();
        resp = resp.data;
        expect(resp.length).to.equal(offset + 2);
        let outDoc2 = await salesController.unsuspendReturn({
            _id: resp[offset + 0]._id
        });
        outDoc2 = outDoc2.data;
        expect(utils.compareObject(saleDoc2, outDoc2, 0, ['_rev'])).to.equal(true);
        let outDoc3 = await salesController.unsuspendReturn({
            _id: resp[offset + 1]._id
        });
        outDoc3 = outDoc3.data;
        expect(utils.compareObject(saleDoc3, outDoc3, 0, ['_rev'])).to.equal(true);
    });

});