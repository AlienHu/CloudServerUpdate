'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;

var profitGuruFaker = require('../../common/profitGuruFaker.js');
var profitGuruFakerExt = require('../../common/profitGuruFakerExt.js');
var commonTestUtils = require('../../common/commonUtils.js');
var utils = require('../../common/Utils.js');
var logger = require('../../../common/Logger');
var faker = require('faker');
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
var utils2 = require('../../../controllers/common/Utils');
var couchDB = couchDBUtils.getMainCouchDB();

const couchDbManager = require('../../../dbManagers/couchDbManager');
var BPromise = require('bluebird');
var recivingsTestHelper;

let itemDocs;
let itemDocIdsWithBatch;
let prevReceivingId;
let retResponse = {};

/** 
 *      What if items quantity is over? Add some items everytime
 */

describe('Receivings Controller UTS', function() {

    this.timeout(5000000);
    this.slow(0);

    var applicationSettings = {};
    var curSession = profitGuruFaker.getFakerSession();
    var receivingsController;
    var itemsArray = [];
    var itemIdsArray = [];
    var suppliersArray;

    var maxRecId = -1;
    var quantityArray = [];

    var batch1 = faker.random.alphaNumeric().toString();
    var batch2 = faker.random.alphaNumeric().toString();
    var batch3 = faker.random.alphaNumeric().toString();
    var batch4 = faker.random.alphaNumeric().toString();
    var batchArray = [batch1, batch2, batch4, batch2, batch3, batch3, batch4];
    var editBatchArray = [batch1, batch2, batch4, batch3];

    function getQuantities() {
        return batchesModel.findAll({
            where: {
                item_id: itemIdsArray
            }
        }).then(function(resp) {
            var retQuants = [];
            //    expect(resp.length).to.equal(itemsArray.length);
            resp.forEach(function(quantityData) {
                retQuants.push(quantityData.get({
                    plain: true
                }).quantity);
            });
            return retQuants;
        });
    }

    //RelaxTodo - recv test -> no batches purchase - item info should get update along with default stock
    //RelaxTodo -- complete comparisons uts

    before(function() {
        var logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);
        return couchDbManager.initCouchDb(true).then(function(resp) {
            return BPromise.all([commonTestUtils.createGlobalConfigs(5), commonTestUtils.getPeople(5, 'supplier')]);
        }).then(function(resp) {
            return BPromise.props({
                allItems: commonTestUtils.getItems(7, true, 1, 0),
                allSuppliers: commonTestUtils.getPeople(4, 'supplier'),
            });
        }).then(function(promiseResults) {
            suppliersArray = promiseResults.allSuppliers;
            itemsArray = promiseResults.allItems;

            expect(suppliersArray.length).to.be.at.least(4);
            expect(itemsArray.length).to.be.at.least(7);
            applicationSettings = profitGuruFaker.getApplicationSettings();
            receivingsController = require('../../../controllers/Receivings')(curSession, applicationSettings);
            recivingsTestHelper = require('./testHelpers/receivingsTestHelper.js')(curSession);
            itemsArray.forEach(function(item) {
                itemIdsArray.push(item.item_id);
            });

        });
    });

    after(function() {

    });

    it('add item to cart', function() {
        return recivingsTestHelper.addItems2Cart(undefined, undefined, batchArray, itemsArray, retResponse);
    });

    //    it('add unique details to cart', function() {
    //        return BPromise.each(retResponse.value.cart, function(cartItem) {
    //            var params = {
    //                line: cartItem.line,
    //                uniqueDetails: []
    //            };

    //            for (var i = 0; i < cartItem.quantity; i++) {
    //                if (cartItem.imeCount !== 0) {
    //                    var imeiNumbers = [];
    //                    for (var j = 0; j < cartItem.imeiCount; j++) {
    //                        imeiNumbers.push((faker.random.uuid()).toString());
    //                    }
    //                }
    //                params.uniqueDetails.push({
    //                    serialnumber: (faker.random.uuid()).toString(),
    //                    imeiNumbers: imeiNumbers
    //                })
    //            }

    //            return receivingsController.updateUniqueDetailsBulk(params).then(function(resp) {
    //                retResponse.value = resp;
    //            });
    //        });
    //    });

    it('add supplier', function() {
        var params = {
            supplier_id: suppliersArray[1]
        };

        return receivingsController.addSupplier(params).then(function(resp) {
            expect(resp.succs_supplier_id).to.equal(params.supplier_id);
        });
    });

    it('add supplier with credit', function() {
        var params = {
            supplier_id: suppliersArray[3]
        };

        return recivingsTestHelper.addSupplier2Cart(params);
        //    return receivingsController.addSupplier(params).then(function(resp) {
        //        expect(resp.succs_supplier_id).to.equal(params.supplier_id);
        //    });
    });

    //    it('edit item', function() {
    //        var index = faker.random.number({
    //            min: 0,
    //            max: retResponse.value.cart.length - 1
    //        });

    //        var cartLine = retResponse.value.cart[index];
    //        var params = {
    //            line: cartLine.line,
    //            description: cartLine.description,
    //            serialnumber: cartLine.serialnumber,
    //            price: cartLine.price,
    //            quantity: parseInt(cartLine.quantity) * 2,
    //            discount: cartLine.discount,
    //            item_location: cartLine.item_location
    //        };

    //        return receivingsController.editItem(params).then(function(resp) {
    //            retResponse.value = resp;
    //            expect(retResponse.value.cart.length).to.equal(4);
    //            var newCartLine = retResponse.value.cart[index];
    //            expect(newCartLine.quantity).to.equal(params.quantity);
    //            expect(newCartLine.total).to.equal(params.price * params.quantity);
    //        });

    //    });      

    it('delete item from cart', function() {

    });

    it('get receivings', function() {

    });

    it('cancel receivings', function() {

    });

    it('complete receivings', async function() {
        var paymentParams = {};
        var payment_types = [];
        payment_types[1] = 'Debit Cart';
        payment_types[0] = "Credit Card";
        paymentParams.amount_tendered = retResponse.value.total / 2;
        let paymentResp;
        for (var paymentType in payment_types) {
            paymentParams.payment_type = payment_types[paymentType];
            paymentResp = await recivingsTestHelper.addPayment(paymentParams);
        }

        expect(retResponse.value.cart.length).to.equal(paymentResp.cart.length);
        let resp = await recivingsTestHelper.completeReceivings(retResponse);

        prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
        maxRecId = parseInt(resp.receiving_id.substring(4));
        //    return recivingsTestHelper.completeReceivings(retResponse).then(function(resp) {
        //        prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
        //        maxRecId = parseInt(resp.receiving_id.substring(4));
        //    });
    });

    it('add item to cart 2', function() {
        return recivingsTestHelper.addItems2Cart(false, undefined, batchArray, itemsArray, retResponse);
    });

    //    it('add unique details to cart', function() {
    //        return BPromise.each(retResponse.value.cart, function(cartItem) {
    //            var params = {
    //                line: cartItem.line,
    //                uniqueDetails: []
    //            };

    //            for (var i = 0; i < cartItem.quantity; i++) {

    //                params.uniqueDetails.push(profitGuruFakerExt.getFakeUniqueDetails(cartItem.imeiCount, cartItem.is_serialized));
    //            }

    //            return receivingsController.updateUniqueDetailsBulk(params).then(function(resp) {
    //                retResponse.value = resp;
    //            });
    //        });
    //    });

    it('add batchId through edit', async function() {
        let newResp;
        for (let i = 0; i < retResponse.value.cart.length; i++) {
            newResp = await recivingsTestHelper.editItem(retResponse.value.cart[i], editBatchArray[i]);
            //Validations here
        }

        retResponse.value = newResp;
    });

    it('remove item', async function() {
        let index = 3;
        let params = {
            item: retResponse.value.cart[index].item_id,
            batchId: retResponse.value.cart[index].batchId,
            line: index + 1
        };
        params.uniqueDetails = [retResponse.value.cart[index].uniqueDetails['1']];
        // try {
        //     params.uniqueDetails = [retResponse.value.cart[index].uniqueDetails['1']];
        // } catch (err) {
        //     console.log(err);
        // }

        let remResp = await recivingsTestHelper.removeItemFromCart(params);

        expect(retResponse.value.cart.length).to.equal(remResp.cart.length);
        //    expect(retResponse.value.cart[index].quantity).to.equal(newResp.cart[index].quantity + 1);
        expect(Object.keys(remResp.cart[index].uniqueDetails).length).to.equal(1);
        retResponse.value = remResp;
    });

    it('complete receivings 2', async function() {
        var paymentParams = {};
        var payment_types = [];
        payment_types[1] = 'Credit Card';
        payment_types[0] = "Debit Card";
        paymentParams.amount_tendered = retResponse.value.total / 2;
        let paymentResp;
        for (var paymentType in payment_types) {
            paymentParams.payment_type = payment_types[paymentType];
            paymentResp = await recivingsTestHelper.addPayment(paymentParams);
        }

        expect(retResponse.value.cart.length).to.equal(paymentResp.cart.length);
        let resp = await recivingsTestHelper.completeReceivings(retResponse);

        prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
        maxRecId = parseInt(resp.receiving_id.substring(4));
        //    return recivingsTestHelper.completeReceivings(retResponse).then(function(resp) {
        //        prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
        //        maxRecId = parseInt(resp.receiving_id.substring(4));
        //    });
    });

    it('add same item with different batches', async function() {
        let fakerParams = {
            bFillAll: true,
            bSerialized: false,
            bIMEINumber: false,
            bHasExpiryDate: false,
            iAttributeCount: 0
        };

        let itemDocsWithBatch = await commonTestUtils.getItemWithParams(fakerParams, 2);
        itemDocIdsWithBatch = Object.keys(itemDocsWithBatch);
    });

    it('additem, edititem, addItemWithBatchParam x2 completesale', async function() {
        for (let i = 0; i < 2; i++) {
            retResponse = await recivingsTestHelper.addEditAdd(itemDocIdsWithBatch[0], i, retResponse);
        }
        expect(retResponse.value.cart.length).to.equal(2);
        for (let i = 0; i < retResponse.value.cart.length; i++) {
            expect(retResponse.value.cart[i].quantity).to.equal(3); // check if 2 or 3 or conditional
            expect(retResponse.value.cart[i].batchId).to.not.equal(undefined);
        }
        await recivingsTestHelper.completeReceivings(retResponse).then(function(resp) {
            prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
            maxRecId = parseInt(resp.receiving_id.substring(4));
        });
    });

    function add2Items2Cart(batch, indexes) {
        return recivingsTestHelper.addItems2Cart(batch, indexes, batchArray, itemsArray, retResponse);
    };
    it('add 2 items to cart', async function() {
        var indexes = [1, 2];
        let promiseLevel = 0;
        try {
            promiseLevel = 1;
            let retResponse = await add2Items2Cart(true, indexes).catch(function(err) {
                console.log(err);
            });

            promiseLevel = 2;
            let resp = await recivingsTestHelper.completeReceivings(retResponse).catch(function(err) {
                console.log(err);
            });

            prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
            maxRecId = parseInt(resp.receiving_id.substring(4));

        } catch (error) {
            console.log("erro at" + promiseLevel);
            console.log(error);
            expect(0).to.equal(1);
        }

    });

    it('compare items details', async function() {
        let promiseLevel = 0;
        try {
            promiseLevel = 1;
            let resp = await commonTestUtils.getPurchaseDetails(prevReceivingId);

            let receivingItems = resp.receiving_items;

            for (var i = 0; i < itemsArray.length; i++) {
                for (var j = 0; j < receivingItems.length; j++) {
                    if (itemsArray[i].item_id === receivingItems[j].item_id) {
                        for (var b = 0; b < itemsArray[i].batches; b++) {
                            if (itemsArray[i].batches[b].stockKey === receivingItems[j].stockKey) {
                                expect(itemsArray[i].batches[b].purchasePrice).to.equal(receivingItems[j].purchasePrice);
                                expect(itemsArray[i].batches[b].mrp).to.equal(receivingItems[j].mrp);
                                expect(itemsArray[i].batches[b].sellingPrice).to.equal(receivingItems[j].sellingPrice);
                                //    expect(itemsArray[i].batches[b].sellingPrice).to.equal(receivingItems[j].sellingPrice);
                            }
                        }

                        //    if (itemsArray[i].purchasePrice !== receivingItems[j].purchasePrice) {
                        //        console.log('item details doesn\'t matches');
                        //        return;
                        //    }
                        for (var k = 0; k < receivingItems[j].itemTaxList.length; k++) {
                            for (var l = 0; l < itemsArray[i].purchaseTaxes.length; l++) {
                                let taxId = "tax_" + itemsArray[i].purchaseTaxes[l];
                                promiseLevel = 2;
                                let purchaseTax = await couchDBUtils.getDoc(taxId, couchDB);
                                if (purchaseTax.name === receivingItems[j].itemTaxList[k].name)
                                    expect(purchaseTax.percent === receivingItems[j].itemTaxList[k].percent).to.equal(true);
                            }
                        }
                    }

                }

            }
        } catch (error) {
            console.log("error at" + promiseLevel);
            console.log(error);
            expect(0).to.equal(1);
        }
    });

    xit('cart item discount', async function() {
        // not required to run....already using edit ut to test this
        var discountOnTaxable = false;
        var oldCart = utils2.clone(retResponse.value.cart);
        var tempDisc = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90];
        // var tempDisc = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        var updatedResp = {};
        for (var item in retResponse.value.cart) {
            retResponse.value.cart[item].discount = tempDisc[item];
            updatedResp = await receivingsController.editItem(retResponse.value.cart[item]);
        }
        var tempTotalOftotalNoTaxWithDiscount = 0;
        var tempTotalOftotalNoTaxNoDiscount = 0;
        var tempOfTotal = 0;
        for (var item in updatedResp.cart) {
            let discountAmt = updatedResp.cart[item].purchasePrice * updatedResp.cart[item].discount * 0.01;
            expect(updatedResp.cart[item].discount).to.equal(tempDisc[item]);
            expect(updatedResp.cart[item].totalNoTaxWithDiscount - (updatedResp.cart[item].purchasePriceExTax - discountAmt) * updatedResp.cart[item].quantity).within(-0.001, 0.001);
            expect(updatedResp.cart[item].totalNoTaxNoDiscount).to.equal((updatedResp.cart[item].purchasePriceExTax) * updatedResp.cart[item].quantity);
            let itemTotal = updatedResp.cart[item].totalNoTaxWithDiscount * (1 + updatedResp.cart[item].totalTaxPercent * 0.01);
            expect(updatedResp.cart[item].total).to.equal(itemTotal);
            tempTotalOftotalNoTaxWithDiscount += updatedResp.cart[item].totalNoTaxWithDiscount;
            tempTotalOftotalNoTaxNoDiscount += updatedResp.cart[item].totalNoTaxNoDiscount;
            tempOfTotal += updatedResp.cart[item].total;
        }
        expect(tempTotalOftotalNoTaxWithDiscount).to.equal(updatedResp.totalNoTaxWithDiscount);
        expect(tempTotalOftotalNoTaxNoDiscount).to.equal(updatedResp.totalNoTaxNoDiscount);
        expect(tempOfTotal - updatedResp.total).within(-0.006, 0.006);
    });

    it('global discount', async function() {
        let ITERATIONS = 10;
        let discountParam = {
            method: 'onToTal',
            bPercent: true,
            value: 10, // set value
            percent: 10, // percent will be considered if refactoring done
            amount: 0
        }
        for (let d = 0; d < ITERATIONS; d++) {
            discountParam.value += 10;
            discountParam.method = (d % 2) ? discountParam.method == 'onTaxable' : 'onTotal';
            if (discountParam.value > 90) discountParam.value = 10;
            discountParam.percent = discountParam.value;
            var total = 0;
            var totalNoTaxWithDiscount = 0;
            let Odata = utils2.clone(retResponse.value);
            let resp = await receivingsController.setGlobalDiscount(discountParam);
            if (discountParam.method == 'onTotal') {
                for (let i = 0; i < resp.cart.length; i++) {
                    let thisItem = resp.cart[i];
                    let OldItem = Odata.cart[i];

                    let OtotalNoTaxWithDiscount = OldItem.totalNoTaxWithDiscount;
                    let Ototal = OldItem.total;

                    let discountAmount = (discountParam.bPercent) ? OldItem.total * discountParam.value * 0.01 : discountParam.value;

                    let Etotal = OldItem.total - discountAmount;
                    let EtotalNoTaxWithDiscount = Etotal / (1 + OldItem.totalTaxPercent * 0.01);

                    thisItem.total = OldItem.total - discountAmount;
                    thisItem.totalNoTaxWithDiscount = thisItem.total / (1 + thisItem.totalTaxPercent * 0.01);

                    expect(thisItem.totalNoTaxWithDiscount).to.equal(EtotalNoTaxWithDiscount);
                    expect(thisItem.total).to.equal(Etotal);

                    totalNoTaxWithDiscount += thisItem.totalNoTaxWithDiscount;
                    total += thisItem.total;
                }
                expect(resp.totalNoTaxWithDiscount - totalNoTaxWithDiscount).within(-0.005, 0.005);
                expect(resp.total - total).within(-0.005, 0.005);
            } else {
                for (let i = 0; i < resp.cart.length; i++) {
                    let thisItem = resp.cart[i];
                    let OldItem = Odata.cart[i];

                    let OtotalNoTaxWithDiscount = OldItem.totalNoTaxWithDiscount;
                    let Ototal = OldItem.total;
                    let EtotalNoTaxWithDiscount = (discountParam.bPercent) ? OtotalNoTaxWithDiscount * (1 - discountParam.value * 0.01) : OtotalNoTaxWithDiscount - discountParam.value;
                    let Etotal = EtotalNoTaxWithDiscount * (1 + OldItem.totalTaxPercent * 0.01);

                    expect(thisItem.totalNoTaxWithDiscount - EtotalNoTaxWithDiscount).within(-0.001, 0.001);
                    expect(thisItem.total).to.equal(Etotal);

                    totalNoTaxWithDiscount += thisItem.totalNoTaxWithDiscount;
                    total += thisItem.total;
                }
                expect(resp.totalNoTaxWithDiscount).to.equal(totalNoTaxWithDiscount);
                expect(resp.total - total).within(-0.003, 0.003);
            }
        }
    });

    it('add payments and complete receivings', async function() {
        let randIndexes = [];
        for (let i = 0; i < 16; i++) {
            var indexes = [1, 2];
            let promiseLevel = 0;
            try {
                promiseLevel = 1;
                let retResponse = await add2Items2Cart(true, indexes);

                if (randIndexes.length === 0) {
                    randIndexes = [0, 1, 2, 3, 4];
                }
                let suppIndex = randIndexes.shift();
                var params = {
                    supplier_id: suppliersArray[suppIndex]
                };

                await recivingsTestHelper.addSupplier2Cart(params);

                promiseLevel = 2;
                var paymentParams = {};
                var payment_types = [];
                payment_types[1] = profitGuruFakerExt.getPaymentType().payment_type;
                payment_types[0] = "Purchase On Credit";
                paymentParams.amount_tendered = retResponse.value.total / 2;
                let paymentResp;
                for (var paymentType in payment_types) {
                    paymentParams.payment_type = payment_types[paymentType];
                    paymentResp = await recivingsTestHelper.addPayment(paymentParams);
                }

                expect(retResponse.value.cart.length).to.equal(paymentResp.cart.length);
                let resp = await recivingsTestHelper.completeReceivings(retResponse);

                prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
                maxRecId = parseInt(resp.receiving_id.substring(4));

            } catch (error) {
                console.log("erro at" + promiseLevel);
                console.log(error);
                expect(0).to.equal(1);
            }
        }
    });

});