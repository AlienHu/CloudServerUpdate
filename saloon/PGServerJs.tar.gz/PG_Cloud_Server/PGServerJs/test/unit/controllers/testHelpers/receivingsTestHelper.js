'use strict';
var BPromise = require('bluebird');
var applicationSettings = {};
var profitGuruFaker = require('../../../common/profitGuruFaker.js');
var profitGuruFakerExt = require('../../../common/profitGuruFakerExt.js');
applicationSettings = profitGuruFaker.getApplicationSettings();
var faker = require('faker');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;

let recivingsTestHelper = function(curSession) {
    var receivingsController = require('../../../../controllers/Receivings')(curSession, applicationSettings);
    const itemsControllerLib = require('../../../../controllers/libraries/itemsControllerLib');
    const computeUtils = require('../../../../controllers/common/computeUtils');
    const utils = require('../../../../controllers/common/Utils');
    const IS_EMPTY_OBJECT = utils.isEmptyObject;

    var foo = {};
    var _self = foo;

    let calculations = {
        total: 0,
        totalNoTax: 0,
        totalTax: 0,
        totalNoTaxNoDiscount: 0,
        totalNoTaxWithDiscount: 0,
        totalNoGlobalDiscount: 0,
        discount: {
            method: "onTotal",
            bPercent: true,
            percent: true,
            amount: true,
            value: 0
        },
        cart: []
    };

    function compute() {
        calculations = {
            total: 0,
            totalNoTax: 0,
            totalTax: 0,
            totalNoTaxNoDiscount: 0,
            totalNoTaxWithDiscount: 0,
            totalNoGlobalDiscount: 0,
            discount: {
                method: "onTotal",
                bPercent: true,
                percent: true,
                amount: true,
                value: 0
            },
            cart: calculations.cart
        };

        for (let i = 0; i < calculations.cart.length; i++) {
            calculations.total += calculations.cart[i].total;
            calculations.totalNoTax += calculations.cart[i].totalNoTax;
            calculations.totalTax += calculations.cart[i].totalTax;
        }
    }

    function getTaxesForItem(taxes, slab, formattedTaxes, price, bPPTaxInclusive, isPurchseEdit, discount) {
        if (!IS_EMPTY_OBJECT(slab) && bPPTaxInclusive) {
            logger.error('tax slab and tax inclusive is not implemented');
            throw 'Internal Error';
        }

        let totalTaxPercent = 0;
        formattedTaxes.length = 0;
        let formattedTaxesCount = {};
        if (!IS_EMPTY_OBJECT(slab)) {
            let taxFromSlab = computeUtils.getTaxFromSlab(slab, price);

            if (taxFromSlab.percent !== 0) {
                formattedTaxes.push(taxFromSlab);
                formattedTaxesCount[taxFromSlab.name] = 1;
                totalTaxPercent += taxFromSlab.percent;
            }
        }
        let totalTaxWithoutSlab = 0
        for (let taxIdx in taxes) {
            let tax = taxes[taxIdx].taxInfo;
            if (!formattedTaxesCount[tax.name]) {
                let itemTaxInfo = {};
                itemTaxInfo.name = tax.name;
                itemTaxInfo.percent = tax.percent;
                totalTaxPercent += tax.percent;
                formattedTaxes.push(itemTaxInfo);
                formattedTaxesCount[tax.name] = 1;
                totalTaxWithoutSlab += tax.percent;
            }
        }

        computeUtils.formatGSTTaxes(formattedTaxes, curSession.settings.receivings.bLocalTax);
        // if (isPurchseEdit && discount != undefined) {
        //     totalTaxPercent -= getAppliedSlabTax(discount, price, slab, totalTaxWithoutSlab);
        // }

        return totalTaxPercent;
    }

    async function computeItem(item_id, quantity, discount, globalDiscountParam, purchasePrice) {
        let itemInfo = await itemsControllerLib.getThisItemInfo({
            item_id: item_id,
            taxType: itemsControllerLib.enPurchaseTax
        });
        let price = computeUtils.getPriceTaxEx(itemInfo.purchasePrice, itemInfo.bPPTaxInclusive);
        let purchasePriceExTax = price;
        let taxes = itemInfo.taxes;
        // if (itemInfo.slab && itemInfo.slab.taxName) {
        //     let tax = computeUtils.getTaxFromSlab(taxes, itemInfo.slab, undefined, purchasePriceExTax);
        //     let bMatchFound = false;
        //     for (let i = 0; i < taxes.length; i++) {
        //         if (taxes[i].taxInfo.name === tax.name) {
        //             taxes[i].taxInfo.percent = tax.percent;
        //             bMatchFound = true;
        //             break;
        //         }
        //     }

        //     if (!bMatchFound) {
        //         let newEntry = {};
        //         newEntry.taxInfo = tax;
        //         taxes.push(newEntry);
        //     }
        // }

        // let totalTaxPercent = computeUtils.getTotalTaxPercent(taxes) * 0.01;
        itemInfo.itemTaxList = [];

        discount = discount ? discount : 0;
        let discountAmt = discount * purchasePriceExTax * 0.01;

        let totalNoTaxNoDiscount = purchasePriceExTax * quantity;
        let totalNoTaxWithDiscount = (purchasePriceExTax - discountAmt) * quantity;
        let totalTaxPercent = getTaxesForItem(taxes, itemInfo.slab, itemInfo.itemTaxList, totalNoTaxWithDiscount / quantity) * 0.01;

        let total = totalNoTaxWithDiscount * (1 + totalTaxPercent);

        if (globalDiscountParam.method == 'onTaxable') {
            totalNoTaxWithDiscount = totalNoTaxWithDiscount * (1 - globalDiscountParam.percent * 0.01);
            totalTaxPercent = getTaxesForItem(taxes, itemInfo.slab, itemInfo.itemTaxList, totalNoTaxWithDiscount / quantity) * 0.01;
            total = totalNoTaxWithDiscount * (1 + totalTaxPercent);
        } else if (globalDiscountParam.method == 'onTotal') {
            total = total * (1 - globalDiscountParam.percent * 0.01);
            totalNoTaxWithDiscount = total / (1 + totalTaxPercent);
            totalTaxPercent = getTaxesForItem(taxes, itemInfo.slab, itemInfo.itemTaxList, totalNoTaxWithDiscount / quantity) * 0.01;
            totalNoTaxNoDiscount = totalNoTaxWithDiscount / (1 - (globalDiscountParam.percent + discount) * 0.01);
            // totalNoTaxNoDiscount = total / ((1 + totalTaxPercent));
            // totalNoTaxWithDiscount = totalNoTaxNoDiscount * (1 - globalDiscountParam.percent * 0.01) * quantity;
        }

        // return {
        //     total: price * quantity * (1 + totalTaxPercent),
        //     totalNoTax: price * quantity,
        //     totalTax: price * quantity * totalTaxPercent
        // };
        return {
            itemInfo: itemInfo,
            total: total,
            totalNoTax: totalNoTaxNoDiscount,
            totalTax: totalNoTaxWithDiscount * totalTaxPercent
        };
    }

    async function compareCartItemResponse(cartItem, globalDiscountParam) {
        // console.log('enter ' + calculations.cart.length);
        let computeResp = await computeItem(cartItem.item_id, cartItem.quantity, cartItem.discount, globalDiscountParam, cartItem.purchasePrice);
        calculations.cart.push(computeResp);
        // console.log('exit ' + +calculations.cart.length);
        expect(computeResp.totalNoTax - cartItem.totalNoTaxNoDiscount).within(-0.001, 0.001);
    }

    async function compareOverAllResponse(response) {
        calculations.cart = [];
        for (let i = 0; i < response.cart.length; i++) {
            await compareCartItemResponse(response.cart[i], response.discount).catch(function(err) {
                console.error(err);
            });
            // console.log(calculations.cart.length + '<>' + (i + 1));
        }
        compute();

        expect(calculations.total - response.total).within(-1, 1);
        expect(calculations.totalNoTax - response.totalNoTaxNoDiscount).within(-0.001, 0.001);
    }

    //can make foo function random
    foo.addItems2Cart = function(bBatch, indexesOf2, batchArray, itemsArray, retResponse) {

        if (bBatch === undefined) {
            bBatch = true;
        }

        var indexes = indexesOf2 ? indexesOf2 : [1, 2, 4, 2, 3, 3, 4];
        var tempBatchArr = batchArray.slice();

        return BPromise.each(indexes, function(itemIndex) {
            var params = {
                item: itemsArray[itemIndex].item_id
            };
            if (bBatch) {
                params.batchId = tempBatchArr.shift();
            }

            if (itemsArray[itemIndex].hasExpiryDate) {
                params.expiry = faker.date.future().toString();
            }
            params.uniqueDetails = [];

            // if () {
            //  for (var i = 0; i < cartItem.quantity; i++) {
            if (itemsArray[itemIndex].imeCount !== 0 || itemsArray[itemIndex].is_serialized) {
                var imeiNumbers = [];
                for (var j = 0; j < itemsArray[itemIndex].imeiCount; j++) {
                    imeiNumbers.push((faker.random.uuid()).toString());
                }
            }
            params.uniqueDetails.push({
                serialnumber: (faker.random.uuid()).toString(),
                imeiNumbers: imeiNumbers
            });
            //    }
            // }
            return receivingsController.additem(params).then(function(resp) {
                retResponse.value = resp;
                return retResponse;
            });
        }).then(function() {
            if (indexesOf2) {
                expect(retResponse.value.cart.length).to.equal(2);
            } else {
                expect(retResponse.value.cart.length).to.equal(4);
            }
            return compareOverAllResponse(retResponse.value);
        }).then(function() {
            return retResponse;
        });
    }

    foo.validateInventoryEntry = function(receivingId, cart) {
        return inventorysModel.findAll({
            where: {
                trans_comment: 'RECV ' + receivingId
            }
        }).then(function(resp) {
            expect(resp.length).to.equal(cart.length);
            for (var i = 0; i < resp.length; i++) {
                var invData = resp[i].get({
                    plain: true
                });
                var cartItemIndex = -1;
                for (var j = 0; j < cart.length; j++) {
                    if (cart[j].item_id === invData.trans_items) {
                        cartItemIndex = j;
                    }
                }
                expect(cartItemIndex).to.not.equal(-1);
                expect(invData.trans_inventory).to.equal(cart[cartItemIndex].quantity * cart[cartItemIndex].conversionFactor);
            }
        });
    }

    function pgTimeOut(time) {
        return new Promise(resolve => {
            setTimeout(function() {
                resolve();
            }, time)
        });
    }

    function getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min)) + min; //The maximum is exclusive and the minimum is inclusive
    }

    foo.editItem = async function(cartItem, batchId) {
        let discount = [10, 20, 30, 40, 50, 60, 70, 80, 90, 0];
        let params = {
            line: cartItem.line,
            description: cartItem.description,
            // purchasePrice: parseFloat(cartItem.purchasePrice * 1.5),
            purchasePrice: cartItem.purchasePrice,
            sellingPrice: parseFloat(cartItem.sellingPrice),
            mrp: parseFloat(cartItem.mrp),
            quantity: parseFloat(cartItem.quantity),
            expiry: cartItem.expiry,
            itemLocation: cartItem.item_location,
            batchId: batchId,
            // discount: discount[(cartItem.line % discount.length) - 1]
            discount: getRandomInt(10, 90)
        };
        if (!cartItem.is_serialized && !cartItem.imeiCount) { // not unique items
            params.quantity *= 2;
        }
        let response;
        return receivingsController.editItem(params).then(function(resp) {
            response = resp;
            for (let i = 0; i < response.cart.length; i++) {
                if (response.cart[i].line === params.line) {
                    expect(response.cart[i].purchasePrice).to.equal(params.purchasePrice);
                    expect(response.cart[i].quantity).to.equal(params.quantity);
                    expect(response.cart[i].discount).to.equal(params.discount);
                }
            }
            return compareOverAllResponse(response);
        }).then(function() {
            return response;
        }).catch(function(err) {
            console.log(err);
        });
    };

    foo.removeItemFromCart = async function(params) {
        let newResp = await receivingsController.removeItem(params);
        await compareOverAllResponse(newResp);
        return newResp;
    }

    foo.addEditAdd = async function(item_id, i, retResponse) {
        let params = {
            item: item_id
        };

        retResponse.value = await receivingsController.additem(params);
        await compareOverAllResponse(retResponse.value);
        params.batchId = (faker.random.alphaNumeric()).toString();
        retResponse.value = await _self.editItem(retResponse.value.cart[i], params.batchId);
        await compareOverAllResponse(retResponse.value);
        retResponse.value = await receivingsController.additem(params);
        await compareOverAllResponse(retResponse.value);
        return retResponse;
    }

    foo.addSupplier2Cart = async function(params) {
        let resp = await receivingsController.addSupplier(params);
        // .then(function(resp) {
        expect(resp.succs_supplier_id).to.equal(params.supplier_id);
        // });
    }

    foo.addPayment = async function(paymentParams) {

        let resp = await receivingsController.add_paymentRestApi(paymentParams);

        return resp;
    }
    foo.completeReceivings = async function(retResponse, bTimeout) {
        if (bTimeout === undefined) {
            bTimeout = 2000;
        }

        var params = {
            comment: 'hello world',
            amount_tendered: retResponse.value.total + 2,
            payment_type: 'Cash'
        };

        let resp = await receivingsController.completeReceivings(params).catch(function(err) {
            console.log(err);
        });
        //    resp.receiving_id.substring(5, resp.receiving_id.length);
        // prevReceivingId = resp.receiving_id.substring(5, resp.receiving_id.length);
        await pgTimeOut(bTimeout);
        expect(resp.amount_change).to.equal(2);
        expect(resp.amount_tendered).to.equal(params.amount_tendered);
        expect(resp.comment).to.equal(params.comment);
        expect(resp.payment_type).to.equal(params.payment_type);
        expect(resp.cart.length).to.equal(retResponse.value.cart.length);
        // maxRecId.value = parseInt(resp.receiving_id.substring(4));
        await compareOverAllResponse(resp).catch(function(err) {
            console.log(err);
        });

        return resp;
        /**
         * 1. New Stock Details should get updated
         *    a. If it is same batch, new details should get updated
         * 2. New Inventory entry should be there
         *    a. Stock Entry should be created or updated
         *    b. unique details should be updated  .. it should just change itemAvailable to true
         */
        //    var propsJson = {};
        //    propsJson.invResponse = validateInventoryEntry(maxRecId, resp.cart);
        //    propsJson.quantityResponse = getQuantities();
        //    return BPromise.props(propsJson);
        //Check receivings details
        //check receivings items            
        //check if item quantity has been updated
        //check all the above for couch docs as well

        //    }).then(function(resp) {
        //        console.log(resp);
        //        var newQuantityArray = resp.quantityResponse;
        //        var quantityDiffArray = [];
        //        itemIdsArray.forEach(function() {
        //            quantityDiffArray.push(0);
        //        });
        //        quantityDiffArray[1] = 1;
        //        quantityDiffArray[2] = 2;
        //        quantityDiffArray[3] = 2;
        //        quantityDiffArray[4] = 2;

        //    expect(newQuantityArray.length).to.equal(quantityArray.length);
        //    for (var i = 0; i < quantityArray.length; i++) {
        //        expect(newQuantityArray[i] - quantityArray[i]).to.equal(quantityDiffArray[i]);
        //    }

    }

    return foo;

};

module.exports = function(session) {
    return recivingsTestHelper(session);
};