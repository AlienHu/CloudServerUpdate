   'use strict';
   let chai = require('chai');
   let expect = chai.expect;

   describe('schema Test UT', function() {
       this.timeout(100000);
       let validator = require('../../../schema/validator.js');
       let api = require('../../../schema/apis/restaurant.js');

       after(function() {});

       it('validator test 1', async function() {
           console.log('validator test');
           let request = {
               id: 1,
               ItemType: 'normal',
               table_no: 5
           }
           try {
               let resp = await validator.validateApiRequest(request, api.checkAlreadyReservedRestApi);

               expect(resp.message).to.equal('');
               expect(resp.data.hasOwnProperty('id')).to.equal(false);
               expect(resp.data.hasOwnProperty('ItemType')).to.equal(false);
               expect(resp.data.table_no).to.equal(5);
           } catch (error) {
               console.log(error);
               expect(1).to.equal(0);
           }
       });

       it('validator test 2', async function() {
           console.log('validator test');
           let request = {
               id: 1,
               ItemType: 'normal'

           }
           try {
               let resp = await validator.validateApiRequest(request, api.checkAlreadyReservedRestApi);
               expect(resp.message).to.equal(' Missing Mandatory Field <table_no>');

           } catch (error) {
               console.log(error);
               expect(1).to.equal(0);
           }
       });

   });