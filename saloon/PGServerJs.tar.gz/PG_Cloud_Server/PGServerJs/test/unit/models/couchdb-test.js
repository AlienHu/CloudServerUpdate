'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

var chai = require('chai');
var expect = chai.expect;
var BPromise = require('bluebird');
const logger = require('../../../common/Logger');

describe('Couch DB Test UT', function() {
    this.timeout(1000000000);

    var utils = require('../../common/Utils.js');
    var cntrlrUtils = require('../../../controllers/common/Utils');
    var couchUtils = require('../../../controllers/common/CouchDBUtils');
    var mainDBInstance = couchUtils.getMainCouchDB();
    let userdbInstance = couchUtils.getUserCouchDB();

    const couchDbManager = require('../../../dbManagers/couchDbManager');

    var faker = require('faker');

    before(function() {
        return;
        return couchDbManager.initCouchDb(false);
    });

    after(function() {

    });

    it('serial number test', function() {
        var doc = {};
        doc._id = 'uniqueDoc';
        for (var i = 0; i < 2000000; i++) {
            var uid = (faker.random.uuid()).toString();
            doc[uid] = uid;
        }

        console.log('create');
        return couchUtils.create(doc, mainDBInstance).then(function(resp) {
            console.log('created');
        }).catch(function(error) {
            console.log(error);
        });
    });

    it('all_docs view test', async function() {

        try {
            let resp = await couchUtils.getView('employees', 'all', {}, userdbInstance);
            // let resp = await couchUtils.getAllDocsByType('org.user.couchdb', userdbInstance);
            console.log(resp);
        } catch (error) {
            console.log(error);
        }

    });

    function replicateDB(sourceCouchDdClient, sourceDBUrl, targetDBUrl) {
        return new Promise((resolve, reject) => {
            //couchdbClient.replicate('http://couchadmin:test@52.66.118.212:5984/profit_guru_licence', {
            let dbs = sourceCouchDdClient.db.list(function(dbs) {
                console.log(dbs);
            });

            sourceCouchDdClient.db.replicate(sourceDBUrl, targetDBUrl, {
                    create_target: true,
                    continuous: true
                },
                function(err, resp) {
                    if (!err) {
                        console.log('couchDb', resp);
                        resolve(resp);
                    } else {
                        console.log('Replcaition to cloud failed ', err);
                        reject(err);
                    }
                });
        });
    }

    xit('replication test', async function() {
        var syncCloudCouchUrl = 'http://couchadmin:test@192.168.1.9:5984/saitest1';
        var localCouchUrl = 'http://couchadmin:test@localhost:5984/sa2';
        var localLicenceNano = require('nano')('http://couchadmin:test@localhost:5984');
        await replicateDB(localLicenceNano, localCouchUrl, syncCloudCouchUrl);
        await replicateDB(localLicenceNano, syncCloudCouchUrl, localCouchUrl);
    });

    xit('replication test', async function() {
        var syncCloudCouchUrl = 'http://couchadmin:test@192.168.1.9:5984/saitest1';
        var localCouchUrl = 'http://couchadmin:test@localhost:5984/saitest2';
        //    var localLicenceNano = require('nano')(localCouchUrl);
        //    await replicateDB(localLicenceNano, syncCloudCouchUrl);
        var cloudLicenceNano = require('nano')(syncCloudCouchUrl);
        await replicateDB(cloudLicenceNano, localCouchUrl);
    });
    it('serial number test 2', function() {
        var docs = [];
        for (var i = 1; i < 2000000; i++) {
            var uid = (faker.random.uuid()).toString();
            docs.push({
                _id: 'unique_' + i,
                uid: uid,
                id: i
            });
        }

        console.log('hello');
        return BPromise.each(docs, create);

        function create(doc) {
            if (doc.id % 100 === 0) {
                console.log(doc.id);
            }

            return couchUtils.create(doc, mainDBInstance).then(function(resp) {}).catch(function(error) {
                console.log(error);
            });
        }
    });

    it('bulk create', function() {
        var docs = [];
        for (var i = 24000; i < 200000; i++) {
            var uid = (faker.random.uuid()).toString();
            docs.push({
                _id: 'unique_' + i,
                uid: uid,
                id: i
            });
        }

        return mainDBInstance.bulk({
            docs: docs
        }).then(function(resp) {

        }).catch(function(err) {
            console.log(err);
        });

    });

    it('bulk create', function() {
        var batches = [];
        var batchLength = 200000;
        batches.push([]);
        var curBatchId = 0;
        for (var i = 1; i < 2000000; i++) {
            var uid = (faker.random.uuid()).toString();
            batches[curBatchId].push({
                _id: 'unique_' + i,
                uid: uid,
                id: i
            });

            if (i % batchLength === 0) {
                batches.push([]);
                curBatchId++;
            }
        }

        console.log('hello');
        console.log(batches.length);
        return BPromise.each(batches, createBulk);

        function createBulk(docs) {
            return mainDBInstance.bulk({
                docs: docs
            }).then(function(resp) {
                console.log('done');
            }).catch(function(err) {
                console.log(err);
            });
        }
    });
    it('get db test', async function() {
        var nano = require('nano-blue')("http://couchadmin:test@127.0.0.1:5984");
        try {

            let nanoInstance = nano.use("pg_collection_cloud_retail_licencedb");
            let allLicenceDocs = await couchUtils.getAllDocsByType('licence', nanoInstance, undefined, true);

            //  let allLicenceDocs = await couchUtils.getAllDocsByType('licence', nano);
            for (let i = 0; i < allLicenceDocs.length; i++) {
                let doc = allLicenceDocs[i];
                console.log(doc);
            }
        } catch (ex) {
            console.log(ex);
        }

    });
    it('get all dbtest', async function() {
        var nano = require('nano-blue')("http://couchadmin:test@127.0.0.1:5984");
        try {
            let list = await nano.db.list();
            for (let i = 0; i < list[0].length; i++) {
                if (list[0][i].indexOf("pg_collection_cloud_crm_") === 0) {
                    console.log(list[0][i]);
                }
            }
        } catch (error) {
            console.log(error);
        }

    });
    xit('delete single dbtest', async function() {
        var nano = require('nano-blue')("http://couchadmin:test@51.15.213.105:5984");
        try {
            let bRtn = await nano.db.destroy("pg_collection_cloud_crm_licencedb");
            console.log("isDeleted:");
            console.log(bRtn[0]);

        } catch (error) {
            console.log(error);
        }

    });

    xit('delete dbtest', async function() {
        var nano = require('nano-blue')("http://couchadmin:test@51.15.213.105:5984");
        try {
            let list = await nano.db.list();
            //  console.log(list);
            //  console.log(JSON.stringify(list));
            for (let i = 0; i < list[0].length; i++) {
                if (list[0][i].indexOf("pg_collection_cloud_crm_") === 0) {
                    console.log(list[0][i]);
                    //    let bRtn = await nano.db.destroy(list[0][i]);
                    //    console.log("isDeleted:");
                    //    console.log(bRtn[0]);

                }
            }
        } catch (error) {
            console.log(error);
        }

    });

    it('count dbtest', async function() {
        var nano = require('nano-blue')("http://couchadmin:test@127.1.1.0:5984");
        let dbArray = {};
        try {
            let list = await nano.db.list();
            let totalCount = 0;
            //  console.log(list);
            //  console.log(JSON.stringify(list));
            for (let i = 0; i < list[0].length; i++) {
                if (list[0][i].indexOf("pg_collection_") === 0) {
                    var tArr = list[0][i].split('_');
                    if (tArr < 5) {
                        continue;
                    }
                    totalCount++;

                    let key = tArr[tArr.length - 1] + '-' + tArr[3];
                    if (!dbArray[key]) {
                        dbArray[key] = {};

                    }
                    let dbName = tArr[tArr.length - 2];
                    if (dbArray[key][dbName]) {
                        dbArray[key][dbName]++;
                        console.log('Not expected to come here <' + key + '> <' + dbName + '>');
                    } else {
                        dbArray[key][dbName] = 1
                    }

                }
            }
            let count = 0;
            let defectiveDBs = [];
            for (var i in dbArray) {
                var total = 0;
                for (var j in dbArray[i]) {

                    total += dbArray[i][j];
                }
                dbArray[i].total = total;
                if (total != 4) {
                    let data = {};
                    data[i] = total;
                    defectiveDBs.push(data);
                }
            }

            console.log(defectiveDBs);
            console.log(Object.keys(dbArray).length);
            console.log('Expected <' + (totalCount / 4) + '> Actual <' + Object.keys(dbArray).length + '>');
            console.log(defectiveDBs.length);
        } catch (error) {
            console.log(error);
        }

    });

    it('update function test', async function() {
        let doc = {
            _id: 'hello_1',
            'rg': 'sai'
        };
        let errMsg = 'failed';
        try {
            await couchUtils.updateHandler(doc._id, doc, mainDBInstance, 'update', errMsg);
        } catch (error) {
            throw errMsg;
        }
    });

    it('design doc query test', async function() {
        //This doesn't work
        console.log(await couchUtils.getAllDocsByType('_design', mainDBInstance));
    });

    it('couchdb sync test', async function() {
        const pouchDB = require('pouchdb');
        const moment = require('moment');
        const commonUtils = require('../../common/commonUtils');

        //Client Side Code
        let logDBName = 'pg_log_test_retail';
        let remoteLogDbName = 'pg_log_test_retail_mac';
        let logDb = new pouchDB(logDBName, {
            auto_compaction: true
        });
        let remoteLogDb = new pouchDB('http://couchadmin:test@localhost:5984/' + remoteLogDbName);

        if (0) {
            await logDb.destroy();
            await remoteLogDb.destroy();
            return;
        }

        commonUtils.pgTimeOut(20).then(function() {
            logDb.replicate.to(remoteLogDb);
            remoteLogDb.replicate.to(logDb);
        });

        for (let i = 0; i < 100; i++) {
            await commonUtils.pgTimeOut(20);
        }

        //nano
        let nano = require('nano')("http://couchadmin:test@127.0.0.1:5984");
        let db = nano.use(remoteLogDbName);
        await commonUtils.pgTimeOut(100);
        var feed = db.follow({

        });

        let allDocs = [];
        feed.on('change', function(change) {
            //    console.log("change: ", change);
            allDocs.push(change);
        });
        feed.follow();

        console.log((await logDb.allDocs()).rows.length);
        for (let i = 0; i < 10; i++) {
            await commonUtils.pgTimeOut(100);
            await logDb.put({
                _id: moment().format('x'),
                timeStamp: moment().format('x')
            });
        }

        console.log((await logDb.allDocs()).rows.length);
        let length = allDocs.length;
        for (let i = 0; i < length; i = i + 1) {
            let nano2 = require('nano-blue')("http://couchadmin:test@127.0.0.1:5984");
            let nanoInstance = nano2.use(remoteLogDbName);
            if (allDocs[i].deleted) {
                continue;
            }

            await couchUtils.delete({
                _id: allDocs[i].id
            }, nanoInstance, 1);

            await commonUtils.pgTimeOut(20);
        }

        for (let i = 0; i < 100; i++) {
            await commonUtils.pgTimeOut(20);
        }

        console.log((await logDb.allDocs()).rows.length);
        console.log((await remoteLogDb.allDocs()).rows.length);
    });

    it('licence dbtest', async function() {
        var nano = require('nano-blue')("http://couchadmin:test@127.0.0.1:5984");
        var licenceHelper = require('../../../licencer/licenceHelper');
        try {
            let list = await nano.db.list();
            //  console.log(list);
            //  console.log(JSON.stringify(list));
            let names = [];
            let licences = [];
            let count1 = 0;
            let count2 = 0;
            for (let i = 0; i < list[0].length; i++) {
                if (list[0][i].indexOf("pg_collection_cloud_retail_licencedb") === 0 || list[0][i].indexOf("pg_collection_cloud_restaurant_licencedb") === 0) {
                    let dbName = list[0][i];
                    let domain = dbName.split('_')[3];
                    names.push(dbName);
                    let nanoInstance = nano.use(dbName);
                    let docs = await couchUtils.getAllDocsByType('licence', nanoInstance, undefined, true);
                    Array.prototype.push.apply(licences, docs);
                    let bFound = false;
                    let validity = 0;
                    for (let j = 0; j < docs.length; j++) {
                        let decLicence = licenceHelper.decryptLicence(docs[j]);
                        if (!decLicence.isTrial && decLicence.validity > 301 && decLicence.validity <= 400) {
                            if (decLicence.validity > validity) {
                                validity = decLicence.validity;
                            }
                            count2++;
                            bFound = true;
                        }
                    }
                    if (bFound) {
                        let doc = await couchUtils.getDoc('profitGuruServerLicence_', nanoInstance);
                        console.log('<' + domain + '>:<' + doc.clientId + '>:<' + validity + '>');
                        logger.info('<' + doc.clientId + '>:<' + validity + '>');
                        count1++;
                    }

                    // if (count1 == 5) {
                    //     break;
                    // }
                }
            }
            console.log(names.length);
            console.log(licences.length);
            console.log(count2);
            console.log(count1);
        } catch (error) {
            console.log(error);
        }
    });

    it('getAllDoc', async function() {
        var nanoInstance = require('nano-blue')("http://couchadmin:test@127.0.0.1:5984").use('pg_collection_retail_maindb');
        let docs = await couchUtils.getAllDocsByType('item', nanoInstance, undefined, true);
        console.log(docs.length);
        var deletedItem = [];
        var count = 0;
        for (var i = 0; i < docs.length; i++) {
            var doc = docs[i];
            if (doc.deleted) {
                deletedItem[count] = doc;
                count++;
            }
        }
        console.log("deleted item: " + deletedItem.length);
        console.log("not deleted item: " + (parseInt(docs.length) - parseInt(deletedItem.length)));
    });
    xit('delete test', async function() {
        var nano = require('nano-blue')("http://couchadmin:test@192.168.1.100:5984").use('pg_collection_retail_licencedb');
        await couchUtils.delete({
            _id: 'licenceapply_54-53-ed-23-c4-ef'
        }, nano);
    });

    it('replicate 1 cloud to other cloud', async function() {
        let sourceDBUrl = 'http://couchadmin:test@localhost:5984/pg_collection_cloud_retail_licencedb_14-18-77-c8-87-84';
        let targetDBUrl = 'http://couchadmin:test@localhost:5984/pg_collection_cloud_retail_licencedb_14-18-77-c8-87-84';

        let sourceCouchClient = require('nano-blue')('http://couchadmin:test@localhost:5984');
        try {
            let resp = await sourceCouchClient.db.replicate(sourceDBUrl, targetDBUrl, {
                create_target: true
            });

            console.log(resp);
            console.log('success');
        } catch (err) {
            console.log(err);
            console.log('failed');
        }
    });

    it('changes feed test', async function(done) {
        let resp = await couchUtils.getUpdateSeq('licencedb');
        console.log(resp);

        var follow = require('follow');

        follow({
            db: "http://couchadmin:test@localhost:5984/pg_collection_retail_licencedb",
            include_docs: true
        }, function(error, change) {
            if (!error) {
                console.log("Change " + change.seq + " has " + Object.keys(change.doc).length + " fields");
            }
        })
    });

    it('decrypt', async function() {
        var moment = require('moment');
        let encLicence = {
            "_id": "licence_e8-4e-06-43-9d-03",
            "_rev": "2-de84802b2a705a3740aaf9ec8ac57286",
            "clientType": "DeskTopApp",
            "allowAccess": true,
            "isLocalHostClient": true,
            "validity": 15,
            "clientId": "e8-4e-06-43-9d-03",
            "enlicence": "600bc639d3d8cb7c0c3b0c99b7f1a2ea61c9278e677198d3aa5420d34f97268d33e1c4f4932686378a8efb4567c7d395910fc7409dee381a3609c6001967cc14c8288093b06c27c29196dfa34c95ad5aa691317c21f5319932984e5a61d7f34499d808c6b21b8fc060d44c9613b8d0e861187405df8ccc3989847fb097f3320f579c1e38b78af03a6ef7188c9476443e5ae0912e4b298eae53c781d85a367965e5e90901693174fe6f97b97f7a95e89d4020c2e9b5ec98c44dfa31ab74931a408f7e031377a4e22cefdd86a79975602293d30b6a316c991f9776f50b9b32ea91567a84439e55cdce61c514ec18d7fa65b945ffb810155ea494b5de72cd9361115b2fa3de19e7501ac356439213f6e67a8b6ffcb3dd1450e2360f470db28b5eba939b1c21f03fccddc01d383b9c4edec28a7b13dd6392e88fc84da59c774f79833df3e486aec358ef4dbe453f874fffc79dc823679b5a5d06bcb1bc07fdec594e7bd41ae81b959ff69e9c94aeb633ea173e73c37fa9f1d455656d9617d5716061572d9a64ab0bb18bb9bea3c7ed9209b3256fabff389bc7e07ebaf47bd8dfd4b724ba7243606044cfb79e69b51c88f160ac9566f19caa338340072e7e4fe924c92a2cb1ba65e639dcd187ebac3ed592957ee7acf895d5678ec94bc3f01cb3328c9f2c363705acc47a9f8596db00813e63c8be5e9f4e42f58ed7886dcd35cbd8e5e9029633511743b9a573f04e8a1c8c1aa87cbd9b5d8d1a8514dc5f4213bed86d4edf19f2a51eaf4948558a18063341d0e096a8b9a2415b2e431df0af953ca2943c3d2e938b1a53b16d13d8a9db2460bdfa401746d01cdd5953d8241d7836bf9ac502653ca4595cbc3ee8bf37e5c9d74da0b9793cb7583808a9705b66d1ca299129707e2b919aae99faac6762ac4e07d9ce546c40ad16d923bf989dc67eb4f226670191a9f1bbaf4228834ad8ad952b732a690be4654b5fff53f908850c8b834e2a5be80265b0d3fe441cb8e68a37055af9cc9663f0321ed8e84e8ff9335891927b31cf596fc951565cff9e599e712ccc569e06cbd6ee7928e7b9a6ff8614e366cceaf17ab52352ca2123f3260f4a587c5930ad1e9278e57a19c62a0e0a70263bfa2c8ffc9e18b28beb5b65161c535a5558d377869110e329bf23836938e1a214451a48a1bb1d7e854a8c1c165f267698311f52bd82f7536535f8313185c54ea018e41c1d09c23bc55854a1f1ee2b8b18b8e7a6fca9e2ff257555f83dd9873d2b580d48247a5880feaa86a1e7a902dc965b1acb7eb42cdffc51bbea936388e78582f4022222558e94c3c1bfeac7b026ecd5ce8e3458afa29621b783c1748c5430fe"
        }
        var licenceHelper = require('../../../licencer/licenceHelper');
        let output = licenceHelper.decryptLicence(encLicence);
        // console.log(encLicence.clientId + '<' + moment().diff(new Date(output.licStartDate), 'days') + '>');
        logger.error(encLicence.clientId + '<' + output.licStartDate + '::' + output.validity + '>');
        logger.error(output.macs);
    })

});