//https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/async_function

'use strict';

var chai = require('chai');
var expect = chai.expect;

describe('Couch DB Test UT', function() {
    this.timeout(100000);

    before(function() {

    });

    after(function() {

    });

    function resolveAfter2Seconds(x) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve(x);
            }, 2000);
        });
    }

    //This is parallel
    async function add11(x) {
        var a = resolveAfter2Seconds(20);
        var b = resolveAfter2Seconds(30);

        try {
            var val1 = await a;
        } catch (error) {
            throw error;
        }

        try {
            var val2 = await b;
        } catch (error) {
            throw error;
        }

        return x + val1 + val2;
    }

    async function add1(x) {
        var a = resolveAfter2Seconds(20);
        var b = resolveAfter2Seconds(30);

        try {
            var val = await Promise.all([a, b]);
            console.log(val);
        } catch (error) {
            console.log('throwing async error ' + error);
            throw error;
        }

        return x + val[0] + val[1];
    }

    async function firstLineThrow() {
        throw "First Line Throw";
    }

    async function firstLineReturn() {
        return "First Line Return";
    }

    async function forwardError() {
        let b = await firstLineThrow();
        return b;
    }

    //This is sequence
    async function add2(x) {
        try {
            var a = await resolveAfter2Seconds(20);
        } catch (error) {
            console.log(error);
        }
        try {
            var b = await resolveAfter2Seconds(30);
        } catch (error) {
            console.log(error);
        }

        return x + a + b;
    }

    xit('async await test', function() {
        return add1(10).then(v => {
            console.log(v); // prints 60 after 2 seconds.
        }).catch(function(err) {
            console.log(err);
        });
    });

    xit('async await test2', function() {
        return add2(10).then(v => {
            console.log(v); // prints 60 after 4 seconds.
        }).catch(function(err) {
            console.log(err);
        });
    });

    it('first line throw', function() {
        let bException = false;
        return firstLineThrow().then(resp => {
            console.log(resp);
            bException = true;
            expect(1).to.equal(0);
        }).catch(error => {
            if (bException) {
                expect(1).to.equal(0);
            }

            console.log(error);
        });
    });

    it('first line return', function() {
        return firstLineReturn().then(resp => {
            console.log(resp);
        }).catch(error => {
            expect(1).to.equal(0);
            console.log(error);
        });
    });

    it('async await mocha', async function() {
        let bException = true;
        try {
            await firstLineReturn();
            bException = false;
            await firstLineThrow();
        } catch (error) {
            if (bException) {
                expect(1).to.equal(0);
            }
        }
    });

    it('forward error', async function() {
        try {
            await forwardError();
        } catch (error) {
            console.log('hello');
            console.log(error);
        }
    });

    function foo1() {
        try {
            foo2();
        } catch (error) {
            console.log('foo1');
            console.log(error);
            console.log('foo1');
        }
    }

    function foo2() {
        foo3();
    }

    function foo3() {
        foo4();
    }

    function foo4() {
        throw 'hell';
    }

    it('catch test', function() {
        foo1();
    });

    it('test done', function(done) {
        console.log('hello');
        add2(2);
        add2(2).then(resp => {
            done();
        });
    });

    async function test1(a) {
        let resp = await resolveAfter2Seconds(a);
        return resp;
    }

    it('test async', async function() {
        console.log(test1(3));
        console.log(await test1(3));
    });

    it.only('exception test', function(done) {
        try {
            setTimeout(function() {
                throw 'I am exception';
            }, 1000);
            // throw 'hello exception'
        } catch (error) {
            console.log('i am in exception block')
            console.log(error);
        }

        setTimeout(function() {
            console.log('finished');
            done();
        }, 2000);
    });

});