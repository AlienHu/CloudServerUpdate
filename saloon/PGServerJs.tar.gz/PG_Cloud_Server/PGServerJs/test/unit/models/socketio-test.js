  // Setup basic express server
  let express = require('express');
  let app = express();
  let path = require('path');
  let server = require('http').createServer(app);
  let io = require('socket.io')(server);
  let port = process.env.PORT || 3000;

  server.listen(port, function() {
      console.log('Server listening at port %d', port);
  });

  // Routing
  app.use(express.static(path.join(__dirname)));

  io.sockets.on('connection', function(socket) {
      console.log(socket.id + ' connected');
      socket.on('disconnect', function() {
          console.log(socket.id + '<' + socket.user + '> disconnected');
      });
      socket.on('add user', function(id) {
          console.log('Old<' + socket.user + '> New<' + id + '>');
          socket.user = id;
      });
  });

  function setUserName(id) {
      console.log(id);
      let skt = require('socket.io-client')('http://localhost:3000')
      skt.on('connect', function() {
          skt.emit('add user', id);
      });
      skt.on('hello', function(msg) {
          console.log('<' + id + '> ' + msg);
      });

      return skt;
  }

  let socket1 = setUserName(1);
  let socket2 = setUserName(2);
  let socket3 = setUserName(3);

  pgTimeOut(1000).then(async function() {
      io.sockets.emit('hello', 'world');
      await pgTimeOut(1000);
      socket1.disconnect();
      await pgTimeOut(1000);
      socket3.disconnect();
      await pgTimeOut(1000);
      socket2.disconnect();
  })

  function pgTimeOut(time) {
      return new Promise(resolve => {
          setTimeout(function() {
              resolve(true);
          }, time)
      });
  }