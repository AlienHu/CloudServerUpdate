var Utils = function() {
    'use strict';

    var q = require('q');
    var fs = require('fs');
    require('errors');
    var _self = this;
    var shelljs = require('shelljs');

    function isObject(obj) {
        return obj === Object(obj);
    }

    this.compareObject = function(refObj, insObj, tolerance, excludeFields, errorsArray, tree) {
        if (!tree) {
            tree = '';
        }

        if (!errorsArray) {
            errorsArray = [];
        }
        if (!excludeFields) {
            excludeFields = [];
        }
        if (!tolerance) {
            tolerance = 0;
        }

        for (var key in refObj) {
            if (excludeFields.indexOf(key) !== -1) {
                continue;
            }

            if (refObj.hasOwnProperty(key)) {
                if (insObj.hasOwnProperty(key)) {
                    let ref = refObj[key];
                    let ins = insObj[key];
                    if (typeof(ref) !== typeof(ins)) {
                        let errMsg = 'Type mismatch. tree<' + tree + '> key<' + key + '> ref<' + typeof(ref) + '> ins<' + typeof(ins) + '>';
                        errorsArray.push(errMsg);
                        console.log(errMsg);
                    }

                    if (Array.isArray(ref)) {
                        !_self.compareArray(ref, ins, tolerance, excludeFields, errorsArray, tree + '/' + key)
                    } else if (isObject(ref)) {
                        _self.compareObject(ref, ins, tolerance, excludeFields, errorsArray, tree + '/' + key);
                    } else {
                        if (typeof(ref) === 'number') {
                            if (Math.abs(ref - ins) > tolerance) {
                                let errMsg = 'Values Mismatch. tree<' + tree + '> Key<' + key + '> ref<' + ref + ' ' + '> ins<' + ins + '>';
                                console.log(errMsg);
                                errorsArray.push(errMsg);
                            }
                        } else if (ref !== ins) {
                            let errMsg = 'Values Mismatch. tree<' + tree + '> Key<' + key + '> ref<' + refObj[key] + ' ' + '> ins<' + insObj[key] + '>';
                            console.log(errMsg);
                            errorsArray.push(errMsg);
                        }
                    }
                } else if (excludeFields.indexOf(key) === -1) {
                    let errMsg = 'tree<' + tree + '> ' + key + " not found in insObj";
                    console.log(errMsg);
                    errorsArray.push(errMsg);
                }
            }
        }

        return errorsArray.length === 0;
    };

    this.compareArray = function(refArray, insArray, tolerance, excludeFields, errorsArray, tree) {
        if (!tolerance) {
            tolerance = 0;
        }
        if (!excludeFields) {
            excludeFields = [];
        }
        if (!errorsArray) {
            errorsArray = [];
        }

        if (!insArray) {
            let errMsg = 'tree<' + tree + '>. insArray is undefined';
            console.log(errMsg);
            errorsArray.push(errMsg);
            return;
        }

        if (insArray.length != refArray.length) {
            let errMsg = 'tree<' + tree + '> array length did not match. ref<' + refArray.length + '>  ins<' + insArray.length + '>';
            console.log(errMsg);
            errorsArray.push(errMsg);
            return;
        }

        for (var i = 0; i < refArray.length; i++) {
            let resp = _self.compareObject(refArray[i], insArray[i], tolerance, excludeFields, errorsArray, tree + '/' + i);
        }

        return errorsArray.length === 0;
    };

    this.compareFields = function(refValue, insValue) {
        if (refValue !== insValue) {
            return false;

        }

        return true;
    };

    this.mergeObjects = function(objArray) {
        var mergedObj = {};
        for (var i = 0; i < objArray.length; i++) {
            var obj = objArray[i];
            for (var attrname in obj) {
                if (obj.hasOwnProperty(attrname))
                    mergedObj[attrname] = obj[attrname];
            }
        }

        return mergedObj;
    };

    this.deleteFilesOfType = function(dirPath, fileTypeArray) {
        fs
            .readdirSync(dirPath)
            .filter(function(file) {
                var bTypeMatches = false;
                for (var i = 0; i < fileTypeArray.length; i++) {
                    if (file.indexOf('.' + fileTypeArray[i]) > -1) {
                        bTypeMatches = true;
                        break;
                    }
                }
                return bTypeMatches;
            })
            .forEach(function(file) {
                console.log('deleting ' + file);
                fs.unlinkSync(file);
            });
    };

    this.deleteDir = function(dirPath) {
        shelljs.rm('-r', dirPath);
    };

};
module.exports = new Utils();