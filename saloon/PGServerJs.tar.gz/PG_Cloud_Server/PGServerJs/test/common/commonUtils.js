var profitGuruFaker = require('./profitGuruFaker.js');
var profitGuruFaker2 = require('./profitGuruFaker2.js');
var profitGuruFakerExt = require('./profitGuruFakerExt.js');

var couchDBUtils = require('../../controllers/common/CouchDBUtils');
const controllerUtils = require('../../controllers/common/Utils');
const IS_UNDEFINED_OR_NULL = controllerUtils.isUndefinedOrNull2;
const IS_EMPTY_OBJECT = controllerUtils.isEmptyObject;
var mainDBInstance = couchDBUtils.getMainCouchDB();
const commonLib = require('../../controllers/libraries/commonLib');

var request = require('supertest');
var linuxShell = require('shelljs');

var BPromise = require('bluebird');

var initPGServerEmployee = {
    name: 'admin'
};

var logger = require('../../common/Logger');

var commonTestUtils = function() {
    var _self = this;

    this.createExpressUserCouchNewUserAuthenticatedRequest = function(app, userForCommonAuthentication, dontApply4trialLicence) {
        var result = {};
        userForCommonAuthentication = userForCommonAuthentication || profitGuruFaker.getFakerExpressUserCouchEmployee();
        var authenticatedRequest = request.agent(app);
        return new Promise(function(resolve, reject) {
            authenticatedRequest
                .post('/employees/signin')
                .redirects(1)
                .send(userForCommonAuthentication)
                .expect(200)
                .then(function(resp) {
                    result.authenticatedRequest = authenticatedRequest;
                    result.loggedInUser = userForCommonAuthentication;
                    resolve(result);
                }).catch(function() {
                    return authenticatedRequest
                        .post('/employees/signUp')
                        .redirects(1)
                        .send(userForCommonAuthentication)
                        .expect(200)
                        .then(function(resp) {

                            authenticatedRequest
                                .post('/employees/signin')
                                .redirects(1)
                                .send(userForCommonAuthentication)
                                .expect(200)
                                .end(function(error) {
                                    if (error) {
                                        throw error;
                                    } else {
                                        result.authenticatedRequest = authenticatedRequest;
                                        result.loggedInUser = userForCommonAuthentication;
                                        if (!dontApply4trialLicence) {
                                            _self.applyTrialLicence(authenticatedRequest).then(function(hasApplied) {
                                                if (hasApplied) {
                                                    result.hasAppliedTrialLicence = true;
                                                    resolve(result);
                                                } else {
                                                    reject('could Not apply the Trial licence');
                                                }
                                            });
                                        } else {
                                            resolve(result);
                                        }

                                    }
                                });

                        });
                });
        });

    }
    this.applyTrialLicence = function(authenticatedRequest) {
        return new Promise(function(resolve, reject) {
            authenticatedRequest
                .get('/licence/amILicenced?clientType=DeskTopApp&appType=' + process.env.APP_TYPE)
                .expect(200).then(function(result) {
                    if (result.body.hasApplied) {
                        resolve(true);
                    } else {
                        authenticatedRequest
                            .post('/licence/requestTrialLicence')
                            .send({
                                clientType: 'DeskTopApp',
                                appType: process.env.APP_TYPE
                            }).expect(200).then(function(result) {
                                resolve(true);
                            });
                    }

                }).catch(function(reason) {
                    reject(reason);
                });
        });
    }
    this.createNewUserAuthenticatedRequest = function(app, userForCommonAuthentication) {
        return _self.createExpressUserCouchNewUserAuthenticatedRequest(app, userForCommonAuthentication);
    }

    this.signUp = function(server, requestData) {

        return server
            .post('/signup')
            .send(requestData);
    };

    this.login = function(server, requestData) {

        return server
            .post('/login')
            .send(requestData);
    };

    this.createSomeItems = async function(noItem2Create) {
        var ItemController = require('../../controllers/Items');
        var noOfItems2Create = noItem2Create || 2;
        var promiseList = [];

        var fakerParams = {
            bFillAll: true,
            bSerialized: false,
            bIMEINumber: false,
            iAttributeCount: 0
        };

        var anItem;
        for (var i = 0; i < noOfItems2Create; ++i) {
            anItem = await profitGuruFakerExt.getFakerItem(fakerParams);
            //anItem.supplier_id = null;
            anItem.employeeId = initPGServerEmployee.name;
            promiseList.push(ItemController.createItem(anItem));
        }

        return await Promise.all(promiseList);
    };

    /**
     *  This is a serial function. After creation, returns all items in db
     */
    this.createItems = async function(noItems, bSerialized, conversionFactor, iAttributeCount, bTaxSlab, bNoIngredients) {
        var ItemController = require('../../controllers/Items');
        var itemsArray = [];

        var fakerParams = {
            bFillAll: true,
            bSerialized: bSerialized,
            bIMEINumber: bSerialized,
            conversionFactor: conversionFactor,
            iAttributeCount: iAttributeCount,
            bTaxSlab: bTaxSlab,
            bNoIngredients: true
        };

        try {
            for (var i = 0; i < noItems; ++i) {
                let resp = await profitGuruFakerExt.getFakerItem(fakerParams);
                itemsArray.push(resp);
            }

            for (let i = 0; i < itemsArray.length; i++) {
                await ItemController.createItem(itemsArray[i]);

            }
            return await _self.getItems(noItems);
        } catch (error) {
            logger.error(error);
            return [];

        }
    };

    this.createAllItemTypes = async function() {
        // 1. batches, variants, unique details
        // 2. no batches, nothing

        let resp = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
        if (resp.length === 2) {
            return _self.getItems(2);
        }

        await _self.createGlobalConfigs(5);

        let ItemController = require('../../controllers/Items');
        let itemsArray = [];

        let fakerParams = {
            bFillAll: true,
            bHasBatchNumber: true,
            bSerialized: true,
            bIMEINumber: true,
            bHasInitialStock: true,
            iAttributeCount: 3,
            conversionFactor: 1
        }
        itemsArray.push(await profitGuruFakerExt.getFakerItem(fakerParams));

        fakerParams = {
            bFillAll: true,
            bHasBatchNumber: false,
            bSerialized: false,
            bIMEINumber: false,
            bHasInitialStock: true,
            iAttributeCount: 0,
            conversionFactor: 1
        };
        itemsArray.push(await profitGuruFakerExt.getFakerItem(fakerParams));

        try {
            for (let i = 0; i < itemsArray.length; i++) {
                await ItemController.createItem(itemsArray[i]);

            }
            return await _self.getItems(2);
        } catch (error) {
            logger.error(error);
            return [];

        }
    };

    /**
     *      returns all items in db
     */
    function formatItem(item, inventory) {
        let formattedItem = controllerUtils.clone(item.info);
        if (item.batches) {
            formattedItem.batches = Object.values(item.batches);
        }
        if (inventory) {
            formattedItem.inventory = inventory;
        }
        formattedItem.item_id = item.item_id;
        formattedItem._id = item._id;

        return formattedItem;
    }

    this.getItems = async function(noItems, bSerialized, conversionFactor, iAttributeCount, bTaxSlab, bNoIngredients) {
        try {
            //RelaxTodo .. This gives deleted docs also
            let resp = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
            let invResp = await couchDBUtils.getAllDocsByType('inventory', mainDBInstance);
            let allItems = [];
            for (let i = 0; i < resp.length; i++) {
                if (!resp[i].doc.deleted) {
                    allItems.push(resp[i].doc);
                }
            }
            if (allItems.length < noItems) {
                noItems = noItems - allItems.length;
                return await _self.createItems(noItems, bSerialized, conversionFactor, iAttributeCount, bTaxSlab, bNoIngredients);
            } else {
                let resp = [];
                for (let i = 0; i < allItems.length; i++) {
                    resp.push(formatItem(allItems[i], invResp[i].doc));
                }
                resp.sort(function(a, b) {
                    return parseInt(a.item_id) - parseInt(b.item_id);
                });
                return resp;
            }
        } catch (error) {
            logger.error(error);
            return [];
        }
    };

    this.getAllItemsInSqlDb = function() {
        return ItemModel.all();
    };

    /**
     *      returns only ids
     */
    this.createSomePeople = function(noPeople, type) {

        var elementController = require('../../controllers/Elements');
        var peopleArray = [];
        for (var i = 0; i < noPeople - 2; i++) {
            peopleArray.push(profitGuruFaker.getFakerCustomer());
        }

        for (var i = 0; i < 2; i++) {
            peopleArray.push(profitGuruFaker.getFakerPersonWithCredit());
        }

        var response = [];
        return BPromise.each(peopleArray, function(personInfo) {
            personInfo.type = type + '_';
            return elementController.create(personInfo).then(function(resp) {
                response.push(resp.data.id);
            });
        }).then(function(resp) {
            return response;
        }).catch(function(err) {
            logger.error(err);
            return [];
        });
    };

    /**
     *      returns only ids
     */

    this.getPeople = function(noPeople, type) {
        var type = type;
        var response = [];
        var bCreateNewPeople = false;
        return couchDBUtils.getAllDocsByType(type, mainDBInstance).then(function(resp) {
            for (var i = 0; i < resp.length; i++) {
                var data = resp[i].doc;
                if (!data.deleted) {
                    response.push(data.person_id);
                }
            }

            if (resp.length < noPeople) {
                bCreateNewPeople = true;
                noPeople = noPeople - resp.length;
                return _self.createSomePeople(noPeople, type);
            }

            return response;
        }).then(function(resp) {
            if (bCreateNewPeople) {
                for (var i = 0; i < resp.length; i++) {
                    response.push(resp[i]);
                }
            }

            return response;
        }).catch(function(err) {
            logger.error(err);
            return [];
        });
    };

    this.createVariants = async function(noOfVariants, maxRetryCount, currentCount) {
        let variantsController = require('../../controllers/Variants');

        if (IS_UNDEFINED_OR_NULL(currentCount)) {
            currentCount = 0;
        }

        if (IS_UNDEFINED_OR_NULL(maxRetryCount)) {
            maxRetryCount = 3;
        }

        try {
            while (currentCount < noOfVariants) {
                let variantData = profitGuruFakerExt.getFakerRandomAttribute();
                await variantsController.create(variantData);
            }

            return currentCount;
        } catch (error) {
            if (maxRetryCount) {
                return _self.createVariants(noOfVariants, maxRetryCount - 1, currentCount);
            }

            return currentCount;
        }
    };

    async function getVariantsCount() {
        let params = {
            reduce: true
        };

        let queryResponse = await couchDBUtils.getView('all_variants_data', 'all_variants_unique_data', params, mainDBInstance);
        return queryResponse;
    }

    //BMTodo Taxes fail randomly with unique constraint error
    this.createGlobalConfigs = async function(noOfConfigs, noOfCategories, retryCount) {
        try {
            if (retryCount === undefined) {
                retryCount = 0;
            }

            if (!noOfCategories) {
                noOfCategories = noOfConfigs;
            }

            var promisesArray0 = [];
            var globalConfigController = require('../../controllers/GlobalConfigurations');

            promisesArray0.push(globalConfigController.getConfigsCount('category'));
            promisesArray0.push(globalConfigController.getConfigsCount('discount'));
            promisesArray0.push(globalConfigController.getConfigsCount('unit'));
            promisesArray0.push(globalConfigController.getConfigsCount('tax'));
            promisesArray0.push(globalConfigController.getConfigsCount('slab'));
            promisesArray0.push(globalConfigController.getConfigsCount('charge'));
            promisesArray0.push(globalConfigController.getConfigsCount('loyality'));
            promisesArray0.push(globalConfigController.getConfigsCount('brand'));
            promisesArray0.push(globalConfigController.getConfigsCount('profile'));
            promisesArray0.push(getVariantsCount());

            let resp = await Promise.all(promisesArray0);

            if (resp[0].length === 0 || (resp[0][0].value < noOfConfigs)) {
                let count = noOfConfigs;
                if (resp[0][0]) {
                    count -= resp[0][0].value;
                }
                for (let i = 0; i < count; i++) {
                    let info = profitGuruFaker.getFakerCategory();
                    await globalConfigController.createCategory(info);
                }
            }

            if (resp[1].length === 0 || (resp[1][0].value < noOfConfigs)) {
                let count = noOfConfigs;
                if (resp[1][0]) {
                    count -= resp[1][0].value;
                }
                for (let i = 0; i < count; i++) {
                    let info = profitGuruFaker.getFakerDiscount();
                    await globalConfigController.createDiscount(info);
                }
            }

            if (resp[2].length === 0 || (resp[2][0].value < noOfConfigs)) {
                let count = noOfConfigs;
                if (resp[2][0]) {
                    count -= resp[2][0].value;
                }
                for (let i = 0; i < count; i++) {
                    let info = profitGuruFaker.getFakerUnit();
                    await globalConfigController.createUnit(info);
                }
            }

            if (resp[3].length === 0 || (resp[3][0].value < noOfConfigs)) {
                let count = noOfConfigs;
                if (resp[3][0]) {
                    count -= resp[3][0].value;
                }
                count = count < 4 ? 4 : count; //because we need different taxes
                for (let i = 0; i < count; i++) {
                    let info = profitGuruFaker.getFakerTax();
                    await globalConfigController.createTax(info);
                }
            }

            if (resp[4].length === 0 || (resp[4][0].value < noOfConfigs)) {
                let count = noOfConfigs;
                if (resp[4][0]) {
                    count -= resp[4][0].value;
                }
                for (let i = 0; i < count; i++) {
                    let info = profitGuruFaker2.getFakerTaxSlab();
                    await globalConfigController.createSlab(info);
                }
            }

            if (resp[5].length === 0 || (resp[5][0].value < noOfConfigs)) {
                let count = noOfConfigs;
                if (resp[5][0]) {
                    count -= resp[5][0].value;
                }
                for (let i = 0; i < count; i++) {
                    let info = profitGuruFaker2.getFakerCharge();
                    await globalConfigController.createCharge(info);
                }
            }

            if (resp[6].length === 0 || (resp[6][0].value < noOfConfigs)) {
                let count = noOfConfigs;
                if (resp[6][0]) {
                    count -= resp[6][0].value;
                }
                for (let i = 0; i < count; i++) {
                    let info = profitGuruFaker.getFakerLoyality();
                    await globalConfigController.createLoyality(info);
                }
            }

            if (resp[7].length === 0 || (resp[7][0].value < noOfConfigs)) {
                let count = noOfConfigs;
                if (resp[7][0]) {
                    count -= resp[7][0].value;
                }
                for (let i = 0; i < count; i++) {
                    let info = profitGuruFaker.getFakerBrand();
                    await globalConfigController.createBrand(info);
                }
            }

            if (resp[8].length === 0 || (resp[8][0].value < noOfConfigs)) {
                let count = noOfConfigs;
                if (resp[8][0]) {
                    count -= resp[8][0].value;
                }
                for (let i = 0; i < count; i++) {
                    let info = await profitGuruFaker2.getFakerProfile();
                    await globalConfigController.createProfile(info);
                }
            }

            if (resp[9].length === 0 || (resp[9][0].value < noOfConfigs)) {
                let curCount = 0;
                if (resp[9][0]) {
                    curCount = resp[9][0].value;
                }
                let count = noOfConfigs - curCount;
                await _self.createVariants(noOfConfigs, 2, curCount);
            }
        } catch (error) {
            logger.error(error);
            if (retryCount < 8) {
                logger.error('Trying Again ' + retryCount);
                return _self.createGlobalConfigs(noOfConfigs, noOfCategories, retryCount + 1);
            } else {
                throw error;
            }
        }
    };

    /**
     * type sale/receiving
     */
    this.getAllPendingTransactionsAndMaxCreditId = async function(type) {
        let allDocs = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
        var response = {};
        for (var i = 0; i < allDocs.length; i++) {
            var doc = allDocs[i].doc;
            let info = doc.sales_info;
            if (!info) {
                info = doc.receivings_info;
            }

            if (info.pending_amount > 0) {
                var personId = info.customer_id;
                if (!personId) {
                    personId = info.supplier_id;
                }
                if (!(personId in response)) {
                    response[personId] = {};
                    response[personId].pendingTransactions = [];
                    response[personId].pending_amount = 0;
                    response[personId].total = 0;
                }
                response[personId].pendingTransactions.push(doc);
                response[personId].pending_amount += info.pending_amount;
                response[personId].total += info.total;
            }
        }

        let allCreditDocs = await couchDBUtils.getAllDocsByType(type + 'Credit', mainDBInstance);

        return [response, allCreditDocs.length];
    };

    this.getSaleDetails = function(sale_id) {
        var id = commonLib.formatSaleId(sale_id);
        return couchDBUtils.getDoc(id, mainDBInstance, "").then(function(thisSaleDetails) {
            return thisSaleDetails;
        }).catch(function(error) {
            return Promise.reject(error);
        });
    };

    this.getPurchaseDetails = function(id) {
        var id = commonLib.formatReceivingId(id);
        return couchDBUtils.getDoc(id, mainDBInstance, "").then(function(thisPurchaseDetails) {
            return thisPurchaseDetails;
        }).catch(function(error) {
            return Promise.reject(error);
        });
    };

    this.pgTimeOut = function(time) {
        return new Promise(resolve => {
            setTimeout(function() {
                resolve(true);
            }, time)
        });
    };

    this.getItemWithParams = async function(fakerParams, noItems) {
        let ItemController = require('../../controllers/Items');
        let itemsControllerLib = require('../../controllers/libraries/itemsControllerLib');

        let docs = [];
        let response = {};
        try {
            for (var i = 0; i < noItems; ++i) {
                let item = await profitGuruFakerExt.getFakerItem(fakerParams);
                let resp = await ItemController.createItem(item);
                docs.push(itemsControllerLib.formatItemDocId(resp.item_id));
                docs.push(itemsControllerLib.formatInvDocId(resp.item_id));
                response[resp.item_id] = {};
            }

            let queryResponse = await couchDBUtils.getAllDocs(docs, mainDBInstance);
            for (let i = 0; i < queryResponse.length; i++) {
                let doc = queryResponse[i].doc;
                response[doc.item_id][doc._id] = doc;
            }

            return response;

        } catch (error) {
            logger.error(error);
        }

    };

    this.createRoomConfig = async function(retryCount) {
        if (retryCount === undefined) {
            retryCount = 10;
        }

        try {

            let profitGuruFaker3 = require('./profitGuruFaker3');
            let roomCntrlr = require('../../controllers/Rooms.js');

            let noTariffs = 5 - (await couchDBUtils.getAllDocsByType('tariff', mainDBInstance)).length;
            let noAddOnTariffs = 5 - (await couchDBUtils.getAllDocsByType('addOn', mainDBInstance)).length;
            let noRooms = 20 - (await couchDBUtils.getAllDocsByType('room', mainDBInstance)).length;

            let fakerData;
            for (let i = 0; i < noTariffs; i++) {
                fakerData = profitGuruFaker3.getFakerRoomTariff();
                await roomCntrlr.create(fakerData, 'tariff');
            }

            for (let i = 0; i < noAddOnTariffs; i++) {
                fakerData = profitGuruFaker3.getFakerRoomAddOnTariff();
                await roomCntrlr.create(fakerData, 'addOn');
            }

            for (let i = 0; i < noRooms; i++) {
                fakerData = await profitGuruFaker3.getFakerRoom();
                await roomCntrlr.create(fakerData, 'room');
            }

            return;
        } catch (error) {
            if (retryCount === 0) {
                throw error;
            } else {
                logger.error('Trying Again');
                return _self.createRoomConfig(retryCount - 1);
            }
        }
    };

};

module.exports = new commonTestUtils();