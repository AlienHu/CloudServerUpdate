'use strict';

var commonUtils = function () {

    const _self = this;

    const faker = require('faker');
    const moment = require('moment');

    const logger = require('../../common/Logger');

    const profitGuruFakerExt = require('./profitGuruFakerExt');
    const profitGuruFaker = require('./profitGuruFaker');
    const utils = require('../../controllers/common/Utils');
    const IS_UNDEFINED_OR_NULL = utils.isUndefinedOrNull2;
    const IS_EMPTY_OBJECT = utils.isEmptyObject;
    const ARRAY_LENGTH = utils.getArrayLength;

    const commonTestUtils = require('./commonUtils');
    const itemController = require('../../controllers/Items');
    const peopleController = require('../../controllers/Elements');

    const fakerSession1 = profitGuruFaker.getFakerSession();
    const applicationSettings1 = profitGuruFaker.getApplicationSettings();
    const fakerSession2 = profitGuruFaker.getFakerSession();
    const applicationSettings2 = profitGuruFaker.getApplicationSettings();

    const couchDBUtils = require('../../controllers/common/CouchDBUtils');
    const mainDBInstance = couchDBUtils.getMainCouchDB();

    const itemControllerLib = require('../../controllers/libraries/itemsControllerLib');
    let receivingsController;
    let salesController;

    const allElements = {
        docCount: 0,
        itemDocIds: [],
        customerDocIds: [],
        supplierDocIds: []
    };

    this.createElements = async function (type, fakerParams, noElements, maxRetryCount, currentCount) {

        if (IS_EMPTY_OBJECT(fakerParams)) {
            fakerParams = {
                bFillAll: true
            };
        }

        let create;
        let elementFaker;
        let elementType;
        switch (type) {
            case 'item':
                create = itemController.createItem;
                //hardcoded assumption
                let maxCategories = (noElements / 10) + 1;
                fakerParams.maxCategories = maxCategories;
                fakerParams.maxTaxes = 10;
                fakerParams.maxAttributes = 10;
                fakerParams.maxUnits = 10;
                fakerParams.conversionFactor = 1;
                fakerParams.bSerialized = false;
                fakerParams.bIMEINumber = false;
                fakerParams.bHasBatchNumber = false;
                fakerParams.bHasExpiryDate = false;
                fakerParams.bHasInitialStock = true;
                fakerParams.conversionFactor = 1;
                fakerParams.iAttributeCount = 0;

                elementFaker = profitGuruFakerExt.getFakerItem;
                break;
            case 'customer':
                create = peopleController.create;
                elementType = type;
                elementFaker = profitGuruFaker.getFakerCustomer;
                break;
            case 'supplier':
                create = peopleController.create;
                elementType = type;
                elementFaker = profitGuruFaker.getFakerSupplier;
                break;
            default:
                return 0;
        }

        if (IS_UNDEFINED_OR_NULL(currentCount)) {
            currentCount = 0;
        }

        if (IS_UNDEFINED_OR_NULL(maxRetryCount)) {
            maxRetryCount = 3;
        }

        try {
            while (currentCount < noElements) {
                let element = elementFaker(fakerParams);
                if (type === 'item') {
                    //fakerItem is promise based
                    element = await element;
                }

                let resp = await create(element, elementType);
                currentCount++;
            }

            return currentCount;
        } catch (error) {
            if (maxRetryCount) {
                return _self.createElements(fakerParams, noElements, maxRetryCount - 1, currentCount);
            }

            return currentCount;
        }

    };

    this.preProcessItems = async function (noOfItems, maxRetryCount) {
        if (IS_UNDEFINED_OR_NULL(maxRetryCount)) {
            maxRetryCount = 3;
        }

        try {
            let maxCategories = (noOfItems / 10) + 1;
            await commonTestUtils.createGlobalConfigs(10, maxCategories);
            await commonTestUtils.createVariants(10);
        } catch (error) {
            if (maxRetryCount) {
                return _self.preProcessItems(noOfItems, maxRetryCount - 1);
            }

            throw error;
        }
    };

    //items, customer_id, employee_id, comment, invoice_number, payments, total, saleOnCreditAmt, timeStamp, bCustomerTaxable
    //cart, supplierId, employeeId, comment, invoiceNumber, paymentType, StockLocation, timeStamp
    //Decide no of items to purchase -- (10, 50)
    //get all items
    //choose randomly item --> assumption it doesn't give repeated item
    //add all required fields like batchId, variant combination, imeiNumbers
    //timeStamp increase it linearly

    function getNoOfItemsForCart(maxItems) {
        return faker.random.number({
            min: maxItems / 20 + 1,
            max: maxItems / 10 + 1
        });
    }

    async function getElementDocIds(designDocName, viewName) {
        let docIds = [];
        let queryResponse = await couchDBUtils.getView(designDocName, viewName, {
            key: null
        }, mainDBInstance);

        for (let i = 0; i < queryResponse.length; i++) {
            docIds.push(queryResponse[i].id);
        }

        return docIds;
    }

    async function loadAllElementDocIds() {
        let latestDocCount = await couchDBUtils.getUpdateSeq('maindb');
        if (latestDocCount === allElements.docCount) {
            return;
        }

        allElements.itemDocIds = await getElementDocIds('all_items_data', 'all_items_data');
        allElements.customerDocIds = await getElementDocIds('all_customers_data', 'all_customers_data');
        allElements.supplierDocIds = await getElementDocIds('all_suppliers_data', 'all_suppliers_data');

        allElements.docCount = await couchDBUtils.getUpdateSeq('maindb');
    }

    //The below are for receivings
    this.makeTransactions = async function (type, noOfTransactions, startTime, endTime, maxRetryCount, currentCount) {
        let makeTransaction;
        if (type === 'sale') {
            salesController = require('../../controllers/Sales')(fakerSession2, applicationSettings2);

            makeTransaction = makeSaleTransaction;
        } else {
            receivingsController = require('../../controllers/Receivings')(fakerSession1, applicationSettings1);
            makeTransaction = makeReceivingTransaction;
        }

        if (IS_UNDEFINED_OR_NULL(currentCount)) {
            currentCount = 0;
        }

        if (IS_UNDEFINED_OR_NULL(maxRetryCount)) {
            maxRetryCount = 3;
        }

        startTime = parseInt(moment(startTime).format('x'));
        if (IS_UNDEFINED_OR_NULL(endTime)) {
            endTime = parseInt(moment().format('x'));
        }

        endTime = parseInt(moment(endTime).format('x'));
        let deltaTime = parseInt((endTime - startTime) / noOfTransactions);

        try {
            await loadAllElementDocIds();

            while (currentCount < noOfTransactions) {
                let timeStamp = startTime + currentCount * deltaTime;
                await makeTransaction(timeStamp);
                currentCount++;
                if (currentCount % 100 === 0) {
                    console.log(currentCount + ' ' + type + ' completed');
                }
            }

            return true;
        } catch (error) {
            if (maxRetryCount) {
                logger.error('Excetption. Trying Again');
                return _self.makeTransactions(type, noOfTransactions, startTime, endTime, maxRetryCount, currentCount);
            }

            return currentCount;
        }
    }

    async function makeReceivingTransaction(timeStamp) {

        //TMTodo skuname
        async function addItem2Cart(itemDocId) {
            let item = await couchDBUtils.getDoc(itemDocId, mainDBInstance);
            let params = {
                item: item.item_id,
                batchId: faker.random.word(),
                uniqueDetails: [],
                quantity: faker.random.number(1, 5),
                attributeInfo: {}
            };

            let itemInfo = item.info;

            if (itemInfo.hasExpiryDate) {
                params.expiry = moment().add(5, 'years').format('YYYY-MM-DD');
            }

            let attributes = itemInfo.attributes;
            if (ARRAY_LENGTH(attributes)) {
                for (let j = 0; j < attributes.length; j++) {
                    params.attributeInfo[attributes[j]] = 1;
                }
            }

            if (itemInfo.is_serialized || itemInfo.imeiCount) {
                for (let i = 0; i < params.quantity; i++) {
                    let detail = {
                        imeiNumbers: []
                    };

                    if (itemInfo.is_serialized) {
                        detail.serialnumber = (faker.random.uuid()).toString();
                    }

                    for (let j = 0; j < itemInfo.imeiCount; j++) {
                        detail.imeiNumbers.push((faker.random.uuid()).toString());
                    }

                    params.uniqueDetails.push(detail);
                }
            }

            await receivingsController.additem(params);
        }

        async function addSupplier(supplierDocId) {
            let supplier = await couchDBUtils.getDoc(supplierDocId, mainDBInstance);
            await receivingsController.addSupplier({
                supplier_id: supplier.person_id
            });
        }

        async function makePayment() {
            logger.silly('makePayment purchase start');

            let receivingsResponse = await receivingsController.getReceivings();
            let payment_options = receivingsResponse.payment_options;

            let pendingAmount = receivingsResponse.amountDue;
            while (pendingAmount > 0.01) {
                let payment_type = faker.random.arrayElement(Object.keys(payment_options));

                let params = {
                    amount_tendered: receivingsResponse.total / 2,
                    payment_type: payment_options[payment_type],
                };

                if (Math.abs(pendingAmount - params.amount_tendered) < 0.001) {
                    params.amount_tendered = pendingAmount;
                }

                receivingsResponse = await receivingsController.add_paymentRestApi(params);
                pendingAmount = receivingsResponse.amountDue;
            }

            logger.silly('makePayment purchase end');
        }

        async function completeReceiving(timeStamp) {
            await receivingsController.completeReceivings(timeStamp);
        }

        let itemDocIds = allElements.itemDocIds;
        let cartLength = getNoOfItemsForCart(itemDocIds.length);
        cartLength = 2;
        for (let i = 0; i < cartLength; i++) {
            let itemDocId = faker.random.arrayElement(itemDocIds);
            await addItem2Cart(itemDocId);
        }

        let supplierDocId = faker.random.arrayElement(allElements.supplierDocIds);
        await addSupplier(supplierDocId);
        await makePayment();
        await completeReceiving(timeStamp);
    }

    async function makeSaleTransaction(timeStamp) {
        logger.silly('makeSaleTransaction start');

        async function addItem2Cart(itemDocId) {
            logger.silly('addItem2Cart sale start');
            let quantity = faker.random.number(1, 5);
            let item = await couchDBUtils.getDoc(itemDocId, mainDBInstance);
            let inventory = await couchDBUtils.getDoc(itemControllerLib.formatInvDocId(item.item_id), mainDBInstance);
            let stockKeys = Object.keys(item.batches);

            for (let i = 0; i < quantity; i++) {
                let stockKey = faker.random.arrayElement(stockKeys);
                let params = {
                    item: item.item_id,
                    stockKey: stockKey,
                    uniqueDetails: {}
                };

                let itemInfo = item.info;
                if (itemInfo.is_serialized || itemInfo.imeiCount) {
                    let uniqueDetails = inventory.stock[stockKey].uniqueDetails;
                    //Take 1st non sold item
                    for (let uniqueKey in uniqueDetails) {
                        if (!uniqueDetails[uniqueKey].sold) {
                            params.uniqueDetails.serialnumber = uniqueDetails[uniqueKey].info.serialnumber;
                            params.uniqueDetails.imeiNumbers = uniqueDetails[uniqueKey].info.imeiNumbers;
                            uniqueDetails[uniqueKey].sold = true; //so that next time we don't pick this
                            break;
                        }
                    }
                }

                await salesController.additemRestApi(params);
            }

            logger.silly('addItem2Cart sale end');
        }

        async function addCustomer(customerDocId) {
            let customer = await couchDBUtils.getDoc(customerDocId, mainDBInstance);
            await salesController.addCustomer2Sale({
                customer_id: customer.person_id
            });
        }

        async function makePayment() {
            logger.silly('makePayment sale start');

            let response = await salesController.getSales();
            let payment_options = response.payment_options;
            if (!response.customer_isCreditAllowed) {
                delete payment_options['Sale on credit'];
            }

            let pendingAmount = response.amount_due;
            while (pendingAmount > 0.01) {
                let payment_type = faker.random.arrayElement(Object.keys(payment_options));

                let params = {
                    amount_tendered: response.total / 2,
                    payment_type: payment_options[payment_type],
                };

                if (Math.abs(pendingAmount - params.amount_tendered) < 0.001) {
                    params.amount_tendered = pendingAmount;
                }

                response = await salesController.add_paymentRestApi(params);
                pendingAmount = response.amount_due;
            }

            logger.silly('makePayment sale end');
        }

        async function completeSale(timeStamp) {
            await salesController.completeSaleRestApi({
                timeStamp: timeStamp
            });
        }

        let itemDocIds = allElements.itemDocIds;
        let cartLength = getNoOfItemsForCart(itemDocIds.length);
        cartLength = 5;
        for (let i = 0; i < cartLength; i++) {
            let itemDocId = faker.random.arrayElement(itemDocIds);
            await addItem2Cart(itemDocId);
        }

        let customerDocId = faker.random.arrayElement(allElements.customerDocIds);
        await addCustomer(customerDocId);
        await makePayment();
        await completeSale(timeStamp);

        logger.silly('makeSaleTransaction end');
    }

    this.createSomeData = async function (bCreateElements, bCreateItems, noSalesTrans, noPurTrans) {
        if (bCreateElements) {
            let typeArray = ['supplier', 'customer', 'item'];
            await _self.preProcessItems(20);
            for (let i = 0; i < typeArray.length; i++) {
                await _self.createElements(typeArray[i], {}, 20);
            }
        }

        let noOfItems = faker.random.number({
            min: 5,
            max: 20
        });
        if (bCreateItems) {
            await _self.createElements('item', {}, noOfItems);
        }

        if (!noSalesTrans) {
            noSalesTrans = faker.random.number({
                min: 2,
                max: 6
            });
        }
        if (!noPurTrans) {
            noPurTrans = faker.random.number({
                min: 2,
                max: 6
            });
        }

        let transactionArray = [{
            type: 'receiving',
            count: noPurTrans
        }, {
            type: 'sale',
            count: noSalesTrans
        }];
        for (let i = 0; i < transactionArray.length; i++) {
            await _self.makeTransactions(transactionArray[i].type, transactionArray[i].count, 1498144485000);
        }
    };

};

module.exports = new commonUtils();