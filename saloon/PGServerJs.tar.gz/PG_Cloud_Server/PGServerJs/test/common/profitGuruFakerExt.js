'use strict';
var faker = require('faker');
faker.locale = 'en_IND';
//faker::Config.locale = 'en-US';
var path = require('path');

var chance = require('chance')();
const moment = require('moment');
const globalConfigCntrlr = require('../../controllers/GlobalConfigurations');
const pharmaData = require('../data/pharma.json');
let iReadCount = 0;

var profitGuruFakerElementsData = function() {
    var _self = this;
    // let ConfigIds = [];

    function getRandomBoolean(bValue, bTrue) {

        var bRetValue = bValue;
        if (bTrue && bRetValue === undefined) {
            bRetValue = true;
        } else if (bRetValue === undefined) {
            bRetValue = faker.random.boolean();
        }

        return bRetValue;
    }

    function getRandomNumber(value, minValue, maxValue) {
        if (minValue == undefined) {
            minValue = 1;
        }
        if (maxValue === undefined) {
            maxValue = 1000;
        }

        var retValue = value;
        if (retValue === undefined) {
            retValue = faker.random.number({
                min: minValue,
                max: maxValue
            });
        }

        return retValue;
    }

    function getRandomArrayValue(value, array, defaultValue) {
        if (value !== undefined) {
            return value;
        }
        if (array != undefined && array.length) {
            return faker.random.arrayElement(array);
        }
        return defaultValue;
    }

    async function getSuppliersDB(type) {
        var couchDBUtils = require('../../controllers/common/CouchDBUtils');
        var mainDBInstance = couchDBUtils.getMainCouchDB();
        let resp = await couchDBUtils.getAllDocsByType('supplier', mainDBInstance);

        let suppliersResp = [];
        for (var i = 0; i < resp.length; i++) {
            suppliersResp.push(resp[i].doc.person_id);
        }
        return suppliersResp;
    }

    this.getConfigsFromDB = async function(type, bUniqueByName) {

        let resp = await globalConfigCntrlr.getAllConfigDocsByType(type);
        let configResponse = [];

        if (!bUniqueByName) {
            for (var i = 0; i < resp.length; i++) {
                configResponse.push(resp[i].doc.id);
            }
        } else {
            let taxes = {};
            for (let i = 0; i < resp.length; i++) {
                let name = resp[i].doc.name;
                if (!taxes.hasOwnProperty(name)) {
                    taxes[name] = [];
                };

                taxes[name].push(resp[i].doc.id);
            }

            for (let name in taxes) {
                configResponse.push(faker.random.arrayElement(taxes[name]));
            }
        }
        return configResponse;
    };

    async function getConfigs(type, item, bFillAll, bFill, params) {
        if (type === 'tax') {
            if (bFillAll) {
                item.purchaseTaxes = [];

                let configsArray = await _self.getConfigsFromDB(type, true);
                var bNumTaxes = faker.random.number({
                    min: 1,
                    max: configsArray.length
                });
                for (var i = 0; i < bNumTaxes; i++) {
                    item.purchaseTaxes.push(configsArray[i]);
                }
            }
            if (bFillAll) {
                let configsArray = await _self.getConfigsFromDB(type, true);
                var bNumTaxes = faker.random.number({
                    min: 1,
                    max: configsArray.length
                });
                for (var i = 0; i < bNumTaxes; i++) {
                    item.salesTaxes.push(configsArray[i]);
                }
            }

            return;
        }

        let configsArray = await _self.getConfigsFromDB(type);
        if (type === 'unit') {

            item.purchaseUnitId = faker.random.arrayElement(configsArray);
            item.sellingUnitId = faker.random.arrayElement(configsArray);
        }
        if (type === 'category') {

            item.categoryId = faker.random.arrayElement(configsArray);
        }

        if (type === 'slab') {
            let bSalesTaxSlab = getRandomBoolean(params.bTaxSlab, bFillAll);
            let bPurchaseTaxSlab = getRandomBoolean(params.bTaxSlab, bFillAll);

            if (bPurchaseTaxSlab) {
                item.bSPTaxInclusive = false;
                item.purchaseSlab = faker.random.arrayElement(configsArray);
            }
            if (bSalesTaxSlab) {
                item.bPPTaxInclusive = false;
                item.salesSlab = faker.random.arrayElement(configsArray);
            }
        }

        if (type === 'brand') {
            if (bFill || bFillAll) {
                item.brandId = faker.random.arrayElement(configsArray);
            }
        }

        configsArray = [];
    }

    /**
     *  bFillAll: All the values will be filled (true)
     */
    this.getFakerItem = async function(params) {
        var bFillAll = getRandomBoolean(params.bFillAll);
        var bHasBatchNumber = getRandomBoolean(params.bHasBatchNumber, bFillAll);
        var bHasExpiryDate = getRandomBoolean(params.bHasExpiryDate, bFillAll);
        var bSerialized = getRandomBoolean(params.bSerialized, bFillAll);
        var bIMEINumber = getRandomBoolean(params.bIMEINumber, bFillAll);
        var bSPTaxInclusive = getRandomBoolean(params.bSPTaxInclusive, bFillAll);
        var bPPTaxInclusive = getRandomBoolean(params.bPPTaxInclusive, bFillAll);
        var bHasInitialStock = getRandomBoolean(params.bHasInitialStock, bFillAll);
        var conversionFactor = getRandomNumber(params.conversionFactor);
        var iAttributeCount = getRandomNumber(params.iAttributeCount, 0, 5);
        let itemTypes = ['Prepared', 'Ingredient', 'Normal', 'Liquor'];
        if (params.bNoIngredient) {
            itemTypes = ['Prepared', 'Normal', 'Liquor'];
        }
        var itemType = getRandomArrayValue(params.itemType, itemTypes, 'Normal');
        let maxCategories = params.maxCategories ? params.maxCategories : 5;
        let maxUnits = params.maxUnits ? params.maxUnits : 5;
        let maxTaxes = params.maxTaxes ? params.maxTaxes : 5;
        let maxAttributes = params.maxAttributes ? params.maxAttributes : 5;

        var item = {
            name: faker.commerce.productName(),
            // name: pharmaData[iReadCount++].name,
            ItemType: itemType,
            hsn: faker.random.number(),
            categoryId: faker.random.number({
                min: 1,
                max: maxCategories
            }),
            purchasePrice: faker.random.number({
                min: 10,
                max: 1000
            }),
            sellingPrice: faker.random.number({
                min: 10,
                max: 1000
            }),
            mrp: faker.random.number({
                min: 10,
                max: 1000
            }),
            is_serialized: bSerialized,
            imeiCount: bIMEINumber ? faker.random.number({
                min: 1,
                max: 5
            }) : 0,
            hasExpiryDate: bHasExpiryDate,
            hasVariants: iAttributeCount !== 0,
            hasBatchNumber: bHasBatchNumber,
            bSPTaxInclusive: bSPTaxInclusive,
            bPPTaxInclusive: bPPTaxInclusive,
            bOTG: false,

            conversionFactor: conversionFactor,
            //During real item creation we would be taking this from session object created after login
            employeeId: 'admin',
            purchaseTaxes: [],
            salesTaxes: [],
            initialStock: {}
        };

        var bFill = faker.random.boolean();

        bFill = faker.random.boolean();
        if (bFill || bFillAll) {
            item.item_number = faker.random.number();
        }
        bFill = faker.random.boolean();
        if (bFill || bFillAll) {
            item.description = faker.random.word();
        }
        bFill = faker.random.boolean();
        if (bFill || bFillAll) {
            item.reorderLevel = faker.random.number({
                min: 10,
                max: 200
            });

            bFill = faker.random.boolean();
            if (bFill || bFillAll) {
                item.reorderQuantity = faker.random.number({
                    min: 0,
                    max: 500
                });
            }
        }

        item.attributes = [];
        for (var i = 0; i < iAttributeCount; i++) {
            item.attributes.push(i + 1);
        }

        if (bHasInitialStock) {
            item.initialStock = [];

            if (iAttributeCount === 0) {
                item.initialStock.push(await _self.getFakerBatch(bHasExpiryDate, bHasBatchNumber, bSerialized, item.imeiCount));
            } else {
                for (var i = 0; i < 3; i++) {
                    var attributeInfo = {};
                    for (var j = 0; j < item.attributes.length; j++) {
                        attributeInfo[item.attributes[j]] = i;
                    }

                    item.initialStock.push(await _self.getFakerBatch(bHasExpiryDate, bHasBatchNumber, bSerialized, item.imeiCount, attributeInfo));
                }
            }

        }

        var configs = ['unit', 'category', 'brand', 'tax', 'discount', 'slab'];
        for (var i = 0; i < configs.length; i++) {
            var type = configs[i];

            await getConfigs(type, item, bFillAll, bFill, params);

        }

        return item;
    };

    this.getFakerReadableItem = async function(params) {
        var bFillAll = getRandomBoolean(params.bFillAll);
        var bHasBatchNumber = getRandomBoolean(params.bHasBatchNumber, bFillAll);
        var bHasExpiryDate = getRandomBoolean(params.bHasExpiryDate, bFillAll);
        var bSerialized = getRandomBoolean(params.bSerialized, bFillAll);
        var bIMEINumber = getRandomBoolean(params.bIMEINumber, bFillAll);
        var bSPTaxInclusive = getRandomBoolean(params.bSPTaxInclusive, bFillAll);
        var bPPTaxInclusive = getRandomBoolean(params.bPPTaxInclusive, bFillAll);
        var bHasInitialStock = getRandomBoolean(params.bHasInitialStock, bFillAll);
        var conversionFactor = getRandomNumber(params.conversionFactor);
        var iAttributeCount = getRandomNumber(params.iAttributeCount, 0, 5);
        let maxCategories = params.maxCategories ? params.maxCategories : 5;
        let maxUnits = params.maxUnits ? params.maxUnits : 5;
        let maxTaxes = params.maxTaxes ? params.maxTaxes : 5;
        let maxAttributes = params.maxAttributes ? params.maxAttributes : 5;

        var item = {
            name: faker.commerce.productName(),
            category: faker.lorem.word(),
            purchasePrice: faker.random.number({
                min: 10,
                max: 1000
            }),
            sellingPrice: faker.random.number({
                min: 10,
                max: 1000
            }),
            mrp: faker.random.number({
                min: 10,
                max: 1000
            }),
            is_serialized: bSerialized,
            imeiCount: bIMEINumber ? faker.random.number({
                min: 1,
                max: 4
            }) : 0,
            hasExpiryDate: bHasExpiryDate,
            hasBatchNumber: bHasBatchNumber,
            bSPTaxInclusive: bSPTaxInclusive,
            bPPTaxInclusive: bPPTaxInclusive,
            bOTG: false,
            purchaseUnit: faker.random.word(),
            sellingUnit: faker.random.word(),
            conversionFactor: conversionFactor,
            //During real item creation we would be taking this from session object created after login
            employeeId: 'admin',
            supplier: faker.company.companyName(),
            purchaseTaxes: [],
            salesTaxes: [],
            initialStock: {}
        };

        var bFill = faker.random.boolean();
        bFill = faker.random.boolean();
        if (bFill || bFillAll) {
            item.item_number = faker.random.number();
        }
        bFill = faker.random.boolean();
        if (bFill || bFillAll) {
            item.description = faker.random.word();
        }
        bFill = faker.random.boolean();
        if (bFill || bFillAll) {
            item.reorderLevel = faker.random.number({
                min: 10,
                max: 200
            });

            bFill = faker.random.boolean();
            if (bFill || bFillAll) {
                item.reorderQuantity = faker.random.number({
                    min: 0,
                    max: 500
                });
            }
        }

        item.attributes = [];
        for (var i = 0; i < iAttributeCount; i++) {
            item.attributes.push(i + 1);
        }

        if (bHasInitialStock) {
            item.initialStock = [];

            if (iAttributeCount === 0) {
                item.initialStock.push(_self.getFakerRedableBatch(bHasExpiryDate, bHasBatchNumber, bSerialized, item.imeiCount));
            } else {
                for (var i = 0; i < 3; i++) {
                    var attributeInfo = {};
                    for (var j = 0; j < item.attributes.length; j++) {
                        attributeInfo[item.attributes[j]] = i;
                    }

                    item.initialStock.push(_self.getFakerRedableBatch(bHasExpiryDate, bHasBatchNumber, bSerialized, item.imeiCount, attributeInfo));
                }
            }
        }

        var configs = ['unit', 'category', 'brand', 'tax', 'discount'];
        for (var i = 0; i < configs.length; i++) {
            var type = configs[i];
            await getConfigs(type, item, bFillAll, bFill);
        }

        return item;
    };

    this.getFakerBatch = async function(bHasExpiryDate, bHasBatchNumber, bSerialized, imeiCount, attributeInfo) {

        var configsArray = await _self.getConfigsFromDB('discount');

        var batch = {
            purchasePrice: faker.random.number({
                min: 10,
                max: 1000
            }),
            sellingPrice: faker.random.number({
                min: 10,
                max: 1000
            }),
            mrp: faker.random.number({
                min: 10,
                max: 1000
            }),
            quantity: faker.random.number({
                min: 10,
                max: 1000
            }),
            //During real item creation we would be taking this from session object created after login
            employeeId: 'admin',
            discountId: faker.random.arrayElement(configsArray),
            location_id: 1
        };

        if (bHasExpiryDate) {
            batch.expiry = faker.date.future().toString();
        }

        if (bHasBatchNumber) {
            batch.batchId = (faker.random.alphaNumeric()).toString();
        }

        batch.uniqueDetails = [];
        if (bSerialized || imeiCount) {
            for (var i = 0; i < batch.quantity; i++) {
                var uniqueDetails = {};
                if (bSerialized) {
                    uniqueDetails.serialnumber = (faker.random.uuid()).toString();
                }

                uniqueDetails.imeiNumbers = [];
                for (var j = 0; j < imeiCount; j++) {
                    uniqueDetails.imeiNumbers.push(faker.random.number({
                        min: 100000000000000,
                        max: 999999999999999
                    }));
                }
                batch.uniqueDetails.push(uniqueDetails);
            }
        }

        if (attributeInfo) {
            batch.attributeInfo = attributeInfo;
        }

        return batch;
    };

    this.getFakerRedableBatch = function(bHasExpiryDate, bHasBatchNumber, bSerialized, imeiCount, attributeInfo) {
        var batch = {
            purchasePrice: faker.random.number({
                min: 10,
                max: 1000
            }),
            sellingPrice: faker.random.number({
                min: 10,
                max: 1000
            }),
            mrp: faker.random.number({
                min: 10,
                max: 1000
            }),
            quantity: faker.random.number({
                min: 10,
                max: 1000
            }),
            //During real item creation we would be taking this from session object created after login
            employeeId: 'admin',
            discount: faker.random.number({
                min: 0,
                max: 50
            }),
            location_id: 1
        };

        if (bHasExpiryDate) {
            batch.expiry = faker.date.future().toString();
        }

        if (bHasBatchNumber) {
            batch.batchId = (faker.random.alphaNumeric()).toString();
        }

        batch.uniqueDetails = [];
        if (bSerialized || imeiCount) {
            for (var i = 0; i < batch.quantity; i++) {
                var uniqueDetails = {};
                if (bSerialized) {
                    uniqueDetails.serialnumber = (faker.random.uuid()).toString();
                }

                uniqueDetails.imeiNumbers = [];
                for (var j = 0; j < imeiCount; j++) {
                    uniqueDetails.imeiNumbers.push(faker.random.number({
                        min: 100000000000000,
                        max: 999999999999999
                    }));
                }
                batch.uniqueDetails.push(uniqueDetails);
            }
        }

        if (attributeInfo) {
            batch.attributeInfo = attributeInfo;
        }

        return batch;
    };

    this.getFakeUniqueDetails = function(imeiCount, bSerialized) {
        var uniqueDetails = {
            imeiNumbers: []
        };

        if (bSerialized) {
            uniqueDetails.serialnumber = (faker.random.uuid()).toString();
        }

        for (var i = 0; i < imeiCount; i++) {
            uniqueDetails.imeiNumbers.push(faker.random.number({
                min: 100000000000000,
                max: 999999999999999
            }));
        }

        return uniqueDetails;
    };

    this.getFakerRandomAttribute = function() {
        var attributeData = {
            name: faker.commerce.productAdjective(),
            values: []
        }

        var iRandomAttributeValuesLength = faker.random.number({
            min: 7,
            max: 8
        });

        for (var i = 1; i < iRandomAttributeValuesLength + 1; i++) {
            var valueData = {};
            valueData = {
                name: faker.commerce.productMaterial() + "" + i, //faker gives random not necessarily unique. So introducing uniqueness by adding i
                code: faker.commerce.productMaterial()
            }
            attributeData.values.push(valueData);
        }

        return attributeData;
    }

    /**
     * values length is atleast 10
     */
    this.getFakerRandomAttributeUpdate = function(attributeData, bChangeAll) {
        attributeData.name = faker.commerce.productAdjective();

        var values = attributeData.values;
        var valueIds = Object.keys(values);
        //Remove some.. make sure no item is using it
        var bNumberToRemove = faker.random.number({
            min: 1,
            max: 5
        });

        for (var i = 0; i < bNumberToRemove; i++) {
            var randomIdToRemove = faker.random.arrayElement(valueIds);
            //delete values[randomIdToRemove];
            //var index = valueIds.indexOf(randomIdToRemove);
            // valueIds.splice(index, 0);
            attributeData.values[randomIdToRemove].deleted = 1
        }

        //Edit some
        var bNumberToEdit = faker.random.number({
            min: 5,
            max: 8
        });
        for (var i = 0; i < bNumberToEdit; i++) {
            var randomIdToEdit = faker.random.arrayElement(valueIds);
            values[randomIdToEdit].name += randomIdToEdit + "" + i;
        }

        //Add some
        var bNumberToAdd = faker.random.number({
            min: 9,
            max: 12
        });
        for (var i = 0; i < bNumberToAdd; i++) {
            values['new' + i] = {
                name: faker.commerce.productMaterial() + "" + i,
                code: faker.commerce.productMaterial()
            };
        }

        // var iRandomAttributeValuesLength = faker.random.number({
        //     min: 2,
        //     max: 5
        // });

        // for (var i = 1; i < iRandomAttributeValuesLength + 1; i++) {
        //     var valueData = {};
        //     valueData = {
        //         name: faker.commerce.productMaterial(),
        //         code: faker.commerce.productMaterial()
        //     }
        //     attributeData.values.push(valueData);
        // }

        return attributeData;
    }

    this.getPaymentType = function() {
        return {
            'payment_type': faker.random.arrayElement(["Cash", "Cheque", "Debit Card", "Credit Card"]),
        }
    }

};

module.exports = new profitGuruFakerElementsData();