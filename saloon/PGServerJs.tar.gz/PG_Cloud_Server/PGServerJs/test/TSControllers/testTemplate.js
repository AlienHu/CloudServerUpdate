"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const testUtils = require("../common/Utils");
var compareObject = testUtils.compareObject;
var compareArray = testUtils.compareArray;
describe('XXXX UT', function () {
    this.timeout(100000);
    before(function () {
    });
    it('xxxxxxxxxx', () => {
        let refObj = { a: 1, b: 2, c: 5 };
        let insObj = { a: 2, b: 1 };
        let errorsArray = [];
        let bSame = compareObject(refObj, insObj, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(false);
    });
    it('XXXXXX', function () {
        let refArr = [1, 2, 3];
        let insArr = [1, 2, 3];
        let errorsArray = [];
        let bSame = compareArray(refArr, insArr, 0, [], errorsArray);
        if (!bSame) {
            console.log(errorsArray);
        }
        expect(bSame).to.equal(true);
    });
});
//# sourceMappingURL=testTemplate.js.map