"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_safe_1 = require("dotenv-safe");
dotenv_safe_1.load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});
const chai = require("chai");
const expect = chai.expect;
const couchDbManager = require("../../dbManagers/couchDbManager");
const commonUtils = require("../common/commonUtils");
const genFakeData_1 = require("../TSCommon/genFakeData");
const stockTransfer_1 = require("../../TSControllers/interfaces/stockTransfer");
const moment = require("moment");
const serverDataInit_1 = require("../../TSCouchDB/serverDataInit");
const Utils_1 = require("../../common/Utils");
const couchDBApis_1 = require("../../TSCouchDB/Common/couchDBApis");
const formatDocIds_1 = require("../../TSControllers/utils/formatDocIds");
const dbInstanceHelper_1 = require("../../TSCouchDB/Common/dbInstanceHelper");
const stockTransfer_2 = require("../../TSControllers/stockTransfer");
const Utils_2 = require("../common/Utils");
const commonLibEx_1 = require("../../TSControllers/libraries/commonLibEx");
const autoIncrementHelper_1 = require("../../TSControllers/libraries/autoIncrementHelper");
const init_1 = require("../../TSCouchDB/CloudCouch/init");
const general_1 = require("../../TSControllers/utils/general");
describe('StockTransfer UT', function () {
    this.timeout(9999999);
    let prevItemByStoreDocId = {}; //we have to have items from all stores
    let prevInventoryByStoreDocId = {}; //we have to have items from all stores
    let dbContext;
    let dbContextByStoreDocId = {};
    let storeDocIdArr;
    let curMainDBSeqByStoreDocId = {};
    ;
    ;
    before(() => __awaiter(this, void 0, void 0, function* () {
        let bResetDB = false;
        let resp = yield couchDbManager.initCouchDb(bResetDB);
        dbContext = resp.dbContext;
        if (bResetDB) {
            //local to cloud for some junk reason is taking time
            yield Utils_1.pgTimeOut(10000);
        }
        //create 3 stores
        storeDocIdArr = yield genFakeData_1.createStores(3, dbContext);
        dbContextByStoreDocId[storeDocIdArr[0]] = dbContext;
        //initializing the stores
        resp = yield couchDbManager.initStore(storeDocIdArr[1], dbContext);
        dbContextByStoreDocId[storeDocIdArr[1]] = resp.dbContext;
        resp = yield couchDbManager.initStore(storeDocIdArr[2], dbContext);
        dbContextByStoreDocId[storeDocIdArr[2]] = resp.dbContext;
        commonUtils.setDBContext(dbContext);
        //create 3 items
        yield commonUtils.createAllItemTypes(false, false, false);
        if (bResetDB) {
            yield Utils_1.pgTimeOut(5000);
        }
        [prevItemByStoreDocId, prevInventoryByStoreDocId] = yield getLatestItemAndInvDocs();
        for (let i = 0; i < storeDocIdArr.length; i++) {
            const docId = storeDocIdArr[i];
            curMainDBSeqByStoreDocId[docId] = autoIncrementHelper_1.getNextSeq(dbContextByStoreDocId[docId]);
        }
    }));
    const getLatestItemAndInvDocs = () => __awaiter(this, void 0, void 0, function* () {
        let itemByStoreDocId = {};
        let inventoryByStoreDocId = {};
        for (let docId in dbContextByStoreDocId) {
            itemByStoreDocId[docId] = [];
            inventoryByStoreDocId[docId] = [];
            let respArr = yield couchDBApis_1.getAllDocsByType(dbContextByStoreDocId[docId], formatDocIds_1.ITEM_PREFIX, dbInstanceHelper_1.getMainDBInstance, undefined, false);
            for (let i = 0; i < respArr.length; i++) {
                itemByStoreDocId[docId].push(respArr[i].doc);
            }
            respArr = yield couchDBApis_1.getAllDocsByType(dbContextByStoreDocId[docId], formatDocIds_1.INVENTORY_PREFIX, dbInstanceHelper_1.getMainDBInstance, undefined, false);
            for (let i = 0; i < respArr.length; i++) {
                inventoryByStoreDocId[docId].push(respArr[i].doc);
            }
        }
        return [itemByStoreDocId, inventoryByStoreDocId];
    });
    /**
     * * create 3 stores
        * create 3 items
        * transferout 2 items
        * transferin 2 items
     */
    const addItem = (item, stockIndex, quantity) => {
        const stockInfo = Object.values(item.batches)[stockIndex];
        return {
            name: item.info.name,
            expiry: stockInfo.expiry,
            attributeInfo: stockInfo.attributeInfo,
            hasExpiryDate: item.info.hasExpiryDate,
            item_id: item.item_id,
            batchId: stockInfo.batchId,
            stockKey: stockInfo.stockKey,
            quantity: quantity,
            skuName: stockInfo.skuName,
            unitId: item.info.defaultSellingUnitId,
            baseUnitId: item.info.baseUnitId,
            unitsInfo: stockInfo.unitsInfo,
            uniqueDetails: []
        };
    };
    const addItems = (storeDocId) => {
        //if item has batches/variants .. add 2 times
        //Quantity 10
        //do the above for 2 items
        let transferItemArr = [];
        let quantity = 10;
        for (let i = 0; i < 2; i++) {
            const itemArr = prevItemByStoreDocId[storeDocId];
            let iStockLength = Object.keys(itemArr[i].batches).length;
            if (iStockLength > 1) {
                iStockLength = 2;
            }
            for (let j = 0; j < iStockLength; j++) {
                transferItemArr.push(addItem(itemArr[i], j, quantity));
            }
        }
        return transferItemArr;
    };
    const getStockTransferDoc_Request = (inStoreDocId, outStoreDocId) => {
        return {
            inStoreDocId: inStoreDocId,
            outStoreDocId: outStoreDocId,
            info: {
                description: 'From UT',
                expenseIdArr: [],
                status: stockTransfer_1.StockTransfer.REQUESTED
            },
            requested: {
                itemsArr: addItems(outStoreDocId),
                timestamp: moment().format('x'),
                employee: serverDataInit_1.ADMIN_USER,
                description: '',
                transStatus: undefined,
                bModifictaion: false
            },
            transferIn: undefined,
            transferOut: undefined,
            id: undefined,
            _id: undefined,
            _rev: undefined
        };
    };
    const getStockTransferDoc_TransferOut = (doc) => {
        doc.info.status = stockTransfer_1.StockTransfer.TRANSFER_OUT;
        doc.transferOut = general_1.CLONE(doc.requested);
        return doc;
    };
    const getStockTransferDoc_RejectTransferOut = (doc) => {
        doc.info.status = stockTransfer_1.StockTransfer.REJECTED_TRANSFER_OUT;
        return doc;
    };
    const getStockTransferDoc_Rejected = (doc) => {
        doc.info.status = stockTransfer_1.StockTransfer.REJECTED;
        return doc;
    };
    const getStockTransferDoc_TransferIn = (doc) => {
        doc.info.status = stockTransfer_1.StockTransfer.TRANSFER_IN;
        doc.transferIn = general_1.CLONE(doc.requested);
        return doc;
    };
    const getOtherStoreDocId = (docIdArr) => {
        let otherStoreDocIdArr = [];
        for (let i = 0; i < storeDocIdArr.length; i++) {
            if (docIdArr.indexOf(storeDocIdArr[i]) === -1) {
                otherStoreDocIdArr.push(storeDocIdArr[i]);
            }
        }
        return otherStoreDocIdArr;
    };
    //change the order and send for transferout and transferin
    const validateInventoryDocs = (transferItemArr, lessInventoryDocArr, moreInventoryDocArr) => {
        for (let j = 0; j < lessInventoryDocArr.length; j++) {
            let totalQuantity = 0;
            for (let i = 0; i < transferItemArr.length; i++) {
                if (transferItemArr[i].item_id !== lessInventoryDocArr[j].item_id) {
                    continue;
                }
                const stockKey = transferItemArr[i].stockKey;
                const stockQuantity = transferItemArr[i].quantity;
                totalQuantity += stockQuantity;
                let prevQuantity = 0;
                if (lessInventoryDocArr[j].stock[stockKey]) {
                    prevQuantity = lessInventoryDocArr[j].stock[stockKey].quantity;
                }
                //checking quantity for that particular stockKey
                expect(moreInventoryDocArr[j].stock[stockKey].quantity - prevQuantity).to.equal(stockQuantity);
            }
            //checking overall quantity for the item
            expect(moreInventoryDocArr[j].quantity - lessInventoryDocArr[j].quantity).to.equal(totalQuantity);
        }
    };
    const validateItemDocs = (transferItemArr, itemDocArr) => {
        for (let i = 0; i < itemDocArr.length; i++) {
            let unitsInfo;
            for (let j = 0; j < transferItemArr.length; j++) {
                if (transferItemArr[j].item_id !== itemDocArr[i].item_id) {
                    continue;
                }
                const stockInfo = commonLibEx_1.getStockJsonFromItemData(transferItemArr[j]);
                let errorsArray = [];
                expect(itemDocArr[i].batches[stockInfo.stockKey] !== undefined).to.equal(true);
                let bEqual = Utils_2.compareObject(stockInfo, itemDocArr[i].batches[stockInfo.stockKey], 0, ['timestamp'], errorsArray);
                expect(bEqual).to.equal(true);
                unitsInfo = stockInfo.unitsInfo;
            }
            if (unitsInfo && Object.keys(itemDocArr[i].batches).length === 1) {
                let errorsArray = [];
                let bEqual = Utils_2.compareObject(unitsInfo, itemDocArr[i].info.unitsInfo, 0, [], errorsArray);
                expect(bEqual).to.equal(true);
            }
        }
    };
    const testStockTransfer_Request = (inStoreDocId, outStoreDocId) => __awaiter(this, void 0, void 0, function* () {
        let doc = getStockTransferDoc_Request(inStoreDocId, outStoreDocId);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[inStoreDocId]);
        //doc should be created in instore        
        let inStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[inStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, inStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        //wait sometime 
        yield Utils_1.pgTimeOut(10000);
        //doc should be created in outstore
        let outStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[outStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        bEqual = Utils_2.compareObject(doc, outStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        //doc should not be created in the 3rd store
        let otherStoreDocIdArr = getOtherStoreDocId([inStoreDocId, outStoreDocId]);
        for (let i = 0; i < otherStoreDocIdArr.length; i++) {
            let bError = false;
            try {
                yield couchDBApis_1.getDoc(dbContextByStoreDocId[otherStoreDocIdArr[i]], doc._id, dbInstanceHelper_1.getMainDBInstance, 'propagate');
                bError = true;
                throw 'doc exist where it should not be. ' + otherStoreDocIdArr[i];
            }
            catch (error) {
                if (bError) {
                    expect(0).to.equal(1);
                }
            }
        }
        curMainDBSeqByStoreDocId[inStoreDocId]++;
        const syncDocId = formatDocIds_1.formatSyncTransactionDocId(curMainDBSeqByStoreDocId[inStoreDocId], dbContextByStoreDocId[inStoreDocId].strStoreCompanyId);
        const syncDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[inStoreDocId], syncDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(syncDoc._deleted).to.equal(true);
        expect(syncDoc._rev.indexOf("2-")).to.equal(0);
        expect(inStoreDoc._rev.indexOf("1-")).to.equal(0);
        const masterDocId = formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(syncDocId);
        const slaveDocId = formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDocId);
        const slaveDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[outStoreDocId], slaveDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(slaveDoc._deleted).to.equal(true);
        expect(slaveDoc._rev.indexOf("2-")).to.equal(0);
        const masterDoc = yield couchDBApis_1.getDeletedDoc(dbContext, masterDocId, 0, dbInstanceHelper_1.getLicenceDBInstance);
        expect(masterDoc._rev.indexOf("2-")).to.equal(0);
        const lockDocId = formatDocIds_1.formatLockDocIdFromDocId(inStoreDoc._id);
        const lockDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockDocId, 1, init_1.getCloudLicenceDBInstance);
        expect(lockDoc.txDocId).to.equal(slaveDoc._id);
        expect(lockDoc._rev.indexOf("1-")).to.equal(0);
        return [inStoreDoc, outStoreDoc];
    });
    const testStockTransfer_TransferOut = (doc) => __awaiter(this, void 0, void 0, function* () {
        doc = getStockTransferDoc_TransferOut(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.outStoreDocId]);
        //doc should be created in instore        
        let outStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.outStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, outStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        let [itemByStoreDocId, inventoryByStoreDocId] = yield getLatestItemAndInvDocs();
        validateInventoryDocs(doc.transferOut.itemsArr, inventoryByStoreDocId[doc.outStoreDocId], prevInventoryByStoreDocId[doc.outStoreDocId]);
        prevItemByStoreDocId = itemByStoreDocId;
        prevInventoryByStoreDocId = inventoryByStoreDocId;
        //wait sometime 
        yield Utils_1.pgTimeOut(10000);
        //doc should be created in outstore
        let inStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.inStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        bEqual = Utils_2.compareObject(doc, inStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        //doc should not be created in the 3rd store
        let otherStoreDocIdArr = getOtherStoreDocId([doc.inStoreDocId, doc.outStoreDocId]);
        for (let i = 0; i < otherStoreDocIdArr.length; i++) {
            let bError = false;
            try {
                yield couchDBApis_1.getDoc(dbContextByStoreDocId[otherStoreDocIdArr[i]], doc._id, dbInstanceHelper_1.getMainDBInstance, 'propagate');
                bError = true;
                throw 'doc exist where it should not be. ' + otherStoreDocIdArr[i];
            }
            catch (error) {
                if (bError) {
                    expect(0).to.equal(1);
                }
            }
        }
        curMainDBSeqByStoreDocId[doc.outStoreDocId]++;
        const syncDocId = formatDocIds_1.formatSyncTransactionDocId(curMainDBSeqByStoreDocId[doc.outStoreDocId], dbContextByStoreDocId[doc.outStoreDocId].strStoreCompanyId);
        const syncDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.outStoreDocId], syncDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(syncDoc._deleted).to.equal(true);
        expect(syncDoc._rev.indexOf("2-")).to.equal(0);
        expect(outStoreDoc._rev.indexOf("3-")).to.equal(0);
        expect(inStoreDoc._rev.indexOf("2-")).to.equal(0);
        const masterDocId = formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(syncDocId);
        const slaveDocId = formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDocId);
        const slaveDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.inStoreDocId], slaveDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(slaveDoc._deleted).to.equal(true);
        expect(slaveDoc._rev.indexOf("2-")).to.equal(0);
        const masterDoc = yield couchDBApis_1.getDeletedDoc(dbContext, masterDocId, 0, dbInstanceHelper_1.getLicenceDBInstance);
        expect(masterDoc._rev.indexOf("2-")).to.equal(0);
        const lockSyncDocId = formatDocIds_1.formatLockDocIdFromDocId(inStoreDoc._id);
        const lockSyncDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSyncDocId, 3, init_1.getCloudLicenceDBInstance);
        expect(lockSyncDoc.txDocId).to.equal(syncDoc._id);
        expect(lockSyncDoc._rev.indexOf("3-")).to.equal(0);
        const lockSlaveDocId = formatDocIds_1.formatLockDocIdFromDocId(inStoreDoc._id);
        const lockSlaveDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSlaveDocId, 1, init_1.getCloudLicenceDBInstance);
        expect(lockSlaveDoc.txDocId).to.equal(slaveDoc._id);
        expect(lockSlaveDoc._rev.indexOf("5-")).to.equal(0);
        return [inStoreDoc, outStoreDoc];
    });
    const testStockTransfer_RejectTransferOut = (doc) => __awaiter(this, void 0, void 0, function* () {
        doc = getStockTransferDoc_RejectTransferOut(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.outStoreDocId]);
        //doc should be created in outstore        
        let outStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.outStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, outStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        let [itemByStoreDocId, inventoryByStoreDocId] = yield getLatestItemAndInvDocs();
        validateInventoryDocs(doc.transferOut.itemsArr, prevInventoryByStoreDocId[doc.outStoreDocId], inventoryByStoreDocId[doc.outStoreDocId]);
        prevItemByStoreDocId = itemByStoreDocId;
        prevInventoryByStoreDocId = inventoryByStoreDocId;
        //wait sometime 
        yield Utils_1.pgTimeOut(10000);
        //doc should be created in outstore
        let inStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.inStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        bEqual = Utils_2.compareObject(doc, inStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        //doc should not be created in the 3rd store
        let otherStoreDocIdArr = getOtherStoreDocId([doc.inStoreDocId, doc.outStoreDocId]);
        for (let i = 0; i < otherStoreDocIdArr.length; i++) {
            let bError = false;
            try {
                yield couchDBApis_1.getDoc(dbContextByStoreDocId[otherStoreDocIdArr[i]], doc._id, dbInstanceHelper_1.getMainDBInstance, 'propagate');
                bError = true;
                throw 'doc exist where it should not be. ' + otherStoreDocIdArr[i];
            }
            catch (error) {
                if (bError) {
                    expect(0).to.equal(1);
                }
            }
        }
        curMainDBSeqByStoreDocId[doc.outStoreDocId]++;
        const syncDocId = formatDocIds_1.formatSyncTransactionDocId(curMainDBSeqByStoreDocId[doc.outStoreDocId], dbContextByStoreDocId[doc.outStoreDocId].strStoreCompanyId);
        const syncDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.outStoreDocId], syncDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(syncDoc._deleted).to.equal(true);
        expect(syncDoc._rev.indexOf("2-")).to.equal(0);
        expect(outStoreDoc._rev.indexOf("5-")).to.equal(0);
        expect(inStoreDoc._rev.indexOf("3-")).to.equal(0);
        const masterDocId = formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(syncDocId);
        const slaveDocId = formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDocId);
        const slaveDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.inStoreDocId], slaveDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(slaveDoc._deleted).to.equal(true);
        expect(slaveDoc._rev.indexOf("2-")).to.equal(0);
        const masterDoc = yield couchDBApis_1.getDeletedDoc(dbContext, masterDocId, 0, dbInstanceHelper_1.getLicenceDBInstance);
        expect(masterDoc._rev.indexOf("2-")).to.equal(0);
        const lockSyncDocId = formatDocIds_1.formatLockDocIdFromDocId(inStoreDoc._id);
        const lockSyncDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSyncDocId, 3, init_1.getCloudLicenceDBInstance);
        expect(lockSyncDoc.txDocId).to.equal(syncDoc._id);
        expect(lockSyncDoc._rev.indexOf("7-")).to.equal(0);
        const lockSlaveDocId = formatDocIds_1.formatLockDocIdFromDocId(inStoreDoc._id);
        const lockSlaveDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSlaveDocId, 1, init_1.getCloudLicenceDBInstance);
        expect(lockSlaveDoc.txDocId).to.equal(slaveDoc._id);
        expect(lockSlaveDoc._rev.indexOf("9-")).to.equal(0);
        return [inStoreDoc, outStoreDoc];
    });
    const testStockTransfer_RejectTransferOut_frominstore = (doc) => __awaiter(this, void 0, void 0, function* () {
        doc = getStockTransferDoc_RejectTransferOut(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.inStoreDocId]);
        //doc should be created in instore        
        let inStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.inStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, inStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        //wait sometime 
        yield Utils_1.pgTimeOut(10000);
        //doc should be created in outstore
        let outStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.outStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        bEqual = Utils_2.compareObject(doc, inStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        let [itemByStoreDocId, inventoryByStoreDocId] = yield getLatestItemAndInvDocs();
        validateInventoryDocs(doc.transferOut.itemsArr, prevInventoryByStoreDocId[doc.outStoreDocId], inventoryByStoreDocId[doc.outStoreDocId]);
        prevItemByStoreDocId = itemByStoreDocId;
        prevInventoryByStoreDocId = inventoryByStoreDocId;
        //doc should not be created in the 3rd store
        let otherStoreDocIdArr = getOtherStoreDocId([doc.inStoreDocId, doc.outStoreDocId]);
        for (let i = 0; i < otherStoreDocIdArr.length; i++) {
            let bError = false;
            try {
                yield couchDBApis_1.getDoc(dbContextByStoreDocId[otherStoreDocIdArr[i]], doc._id, dbInstanceHelper_1.getMainDBInstance, 'propagate');
                bError = true;
                throw 'doc exist where it should not be. ' + otherStoreDocIdArr[i];
            }
            catch (error) {
                if (bError) {
                    expect(0).to.equal(1);
                }
            }
        }
        curMainDBSeqByStoreDocId[doc.inStoreDocId]++;
        const syncDocId = formatDocIds_1.formatSyncTransactionDocId(curMainDBSeqByStoreDocId[doc.inStoreDocId], dbContextByStoreDocId[doc.inStoreDocId].strStoreCompanyId);
        const syncDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.inStoreDocId], syncDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(syncDoc._deleted).to.equal(true);
        expect(syncDoc._rev.indexOf("2-")).to.equal(0);
        expect(outStoreDoc._rev.indexOf("5-")).to.equal(0);
        expect(inStoreDoc._rev.indexOf("3-")).to.equal(0);
        const masterDocId = formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(syncDocId);
        const slaveDocId = formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDocId);
        const slaveDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.outStoreDocId], slaveDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(slaveDoc._deleted).to.equal(true);
        expect(slaveDoc._rev.indexOf("2-")).to.equal(0);
        const masterDoc = yield couchDBApis_1.getDeletedDoc(dbContext, masterDocId, 0, dbInstanceHelper_1.getLicenceDBInstance);
        expect(masterDoc._rev.indexOf("2-")).to.equal(0);
        const lockSyncDocId = formatDocIds_1.formatLockDocIdFromDocId(inStoreDoc._id);
        const lockSyncDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSyncDocId, 3, init_1.getCloudLicenceDBInstance);
        expect(lockSyncDoc.txDocId).to.equal(syncDoc._id);
        expect(lockSyncDoc._rev.indexOf("7-")).to.equal(0);
        const lockSlaveDocId = formatDocIds_1.formatLockDocIdFromDocId(outStoreDoc._id);
        const lockSlaveDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSlaveDocId, 1, init_1.getCloudLicenceDBInstance);
        expect(lockSlaveDoc.txDocId).to.equal(slaveDoc._id);
        expect(lockSlaveDoc._rev.indexOf("9-")).to.equal(0);
        return [inStoreDoc, outStoreDoc];
    });
    const testStockTransfer_Rejected = (doc) => __awaiter(this, void 0, void 0, function* () {
        doc = getStockTransferDoc_Rejected(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.outStoreDocId]);
        //doc should be created in instore        
        let outStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.outStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, outStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        //wait sometime 
        yield Utils_1.pgTimeOut(10000);
        //doc should be created in outstore
        let inStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.inStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        bEqual = Utils_2.compareObject(doc, inStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        //doc should not be created in the 3rd store
        let otherStoreDocIdArr = getOtherStoreDocId([doc.inStoreDocId, doc.outStoreDocId]);
        for (let i = 0; i < otherStoreDocIdArr.length; i++) {
            let bError = false;
            try {
                yield couchDBApis_1.getDoc(dbContextByStoreDocId[otherStoreDocIdArr[i]], doc._id, dbInstanceHelper_1.getMainDBInstance, 'propagate');
                bError = true;
                throw 'doc exist where it should not be. ' + otherStoreDocIdArr[i];
            }
            catch (error) {
                if (bError) {
                    expect(0).to.equal(1);
                }
            }
        }
        curMainDBSeqByStoreDocId[doc.outStoreDocId]++;
        const syncDocId = formatDocIds_1.formatSyncTransactionDocId(curMainDBSeqByStoreDocId[doc.outStoreDocId], dbContextByStoreDocId[doc.outStoreDocId].strStoreCompanyId);
        const syncDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.outStoreDocId], syncDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(syncDoc._deleted).to.equal(true);
        expect(syncDoc._rev.indexOf("2-")).to.equal(0);
        expect(outStoreDoc._rev.indexOf("6-")).to.equal(0);
        expect(inStoreDoc._rev.indexOf("4-")).to.equal(0);
        const masterDocId = formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(syncDocId);
        const slaveDocId = formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDocId);
        const slaveDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.inStoreDocId], slaveDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(slaveDoc._deleted).to.equal(true);
        expect(slaveDoc._rev.indexOf("2-")).to.equal(0);
        const masterDoc = yield couchDBApis_1.getDeletedDoc(dbContext, masterDocId, 0, dbInstanceHelper_1.getLicenceDBInstance);
        expect(masterDoc._rev.indexOf("2-")).to.equal(0);
        const lockSyncDocId = formatDocIds_1.formatLockDocIdFromDocId(inStoreDoc._id);
        const lockSyncDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSyncDocId, 3, init_1.getCloudLicenceDBInstance);
        expect(lockSyncDoc.txDocId).to.equal(syncDoc._id);
        expect(lockSyncDoc._rev.indexOf("11-")).to.equal(0);
        const lockSlaveDocId = formatDocIds_1.formatLockDocIdFromDocId(inStoreDoc._id);
        const lockSlaveDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSlaveDocId, 1, init_1.getCloudLicenceDBInstance);
        expect(lockSlaveDoc.txDocId).to.equal(slaveDoc._id);
        expect(lockSlaveDoc._rev.indexOf("13-")).to.equal(0);
        return [inStoreDoc, outStoreDoc];
    });
    const testStockTransfer_Rejected_frominstore = (doc) => __awaiter(this, void 0, void 0, function* () {
        doc = getStockTransferDoc_Rejected(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.inStoreDocId]);
        //doc should be created in instore        
        let inStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.inStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, inStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        //wait sometime 
        yield Utils_1.pgTimeOut(10000);
        //doc should be created in outstore
        let outStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.outStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        bEqual = Utils_2.compareObject(doc, outStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        //doc should not be created in the 3rd store
        let otherStoreDocIdArr = getOtherStoreDocId([doc.inStoreDocId, doc.outStoreDocId]);
        for (let i = 0; i < otherStoreDocIdArr.length; i++) {
            let bError = false;
            try {
                yield couchDBApis_1.getDoc(dbContextByStoreDocId[otherStoreDocIdArr[i]], doc._id, dbInstanceHelper_1.getMainDBInstance, 'propagate');
                bError = true;
                throw 'doc exist where it should not be. ' + otherStoreDocIdArr[i];
            }
            catch (error) {
                if (bError) {
                    expect(0).to.equal(1);
                }
            }
        }
        curMainDBSeqByStoreDocId[doc.inStoreDocId]++;
        const syncDocId = formatDocIds_1.formatSyncTransactionDocId(curMainDBSeqByStoreDocId[doc.inStoreDocId], dbContextByStoreDocId[doc.inStoreDocId].strStoreCompanyId);
        const syncDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.inStoreDocId], syncDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(syncDoc._deleted).to.equal(true);
        expect(syncDoc._rev.indexOf("2-")).to.equal(0);
        expect(outStoreDoc._rev.indexOf("6-")).to.equal(0);
        expect(inStoreDoc._rev.indexOf("4-")).to.equal(0);
        const masterDocId = formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(syncDocId);
        const slaveDocId = formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDocId);
        const slaveDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.outStoreDocId], slaveDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(slaveDoc._deleted).to.equal(true);
        expect(slaveDoc._rev.indexOf("2-")).to.equal(0);
        const masterDoc = yield couchDBApis_1.getDeletedDoc(dbContext, masterDocId, 0, dbInstanceHelper_1.getLicenceDBInstance);
        expect(masterDoc._rev.indexOf("2-")).to.equal(0);
        const lockSyncDocId = formatDocIds_1.formatLockDocIdFromDocId(inStoreDoc._id);
        const lockSyncDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSyncDocId, 3, init_1.getCloudLicenceDBInstance);
        expect(lockSyncDoc.txDocId).to.equal(syncDoc._id);
        expect(lockSyncDoc._rev.indexOf("11-")).to.equal(0);
        const lockSlaveDocId = formatDocIds_1.formatLockDocIdFromDocId(outStoreDoc._id);
        const lockSlaveDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSlaveDocId, 1, init_1.getCloudLicenceDBInstance);
        expect(lockSlaveDoc.txDocId).to.equal(slaveDoc._id);
        expect(lockSlaveDoc._rev.indexOf("13-")).to.equal(0);
        return [inStoreDoc, outStoreDoc];
    });
    const testStockTransfer_TransferIn = (doc) => __awaiter(this, void 0, void 0, function* () {
        doc = getStockTransferDoc_TransferIn(doc);
        yield stockTransfer_2.stockRequest(doc, dbContextByStoreDocId[doc.inStoreDocId]);
        //doc should be created in instore        
        let inStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.inStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        let errorsArray = [];
        let bEqual = Utils_2.compareObject(doc, inStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        let [itemByStoreDocId, inventoryByStoreDocId] = yield getLatestItemAndInvDocs();
        validateInventoryDocs(doc.transferIn.itemsArr, prevInventoryByStoreDocId[doc.inStoreDocId], inventoryByStoreDocId[doc.inStoreDocId]);
        validateItemDocs(doc.transferIn.itemsArr, itemByStoreDocId[doc.inStoreDocId]);
        prevItemByStoreDocId = itemByStoreDocId;
        prevInventoryByStoreDocId = inventoryByStoreDocId;
        //wait sometime 
        yield Utils_1.pgTimeOut(10000);
        //doc should be created in outstore
        let outStoreDoc = yield couchDBApis_1.getDoc(dbContextByStoreDocId[doc.outStoreDocId], doc._id, dbInstanceHelper_1.getMainDBInstance);
        bEqual = Utils_2.compareObject(doc, outStoreDoc, 0, ['_rev', 'txDocIdArr'], errorsArray);
        expect(bEqual).to.equal(true);
        //doc should not be created in the 3rd store
        let otherStoreDocIdArr = getOtherStoreDocId([doc.inStoreDocId, doc.outStoreDocId]);
        for (let i = 0; i < otherStoreDocIdArr.length; i++) {
            let bError = false;
            try {
                yield couchDBApis_1.getDoc(dbContextByStoreDocId[otherStoreDocIdArr[i]], doc._id, dbInstanceHelper_1.getMainDBInstance, 'propagate');
                bError = true;
                throw 'doc exist where it should not be. ' + otherStoreDocIdArr[i];
            }
            catch (error) {
                if (bError) {
                    expect(0).to.equal(1);
                }
            }
        }
        curMainDBSeqByStoreDocId[doc.inStoreDocId]++;
        const syncDocId = formatDocIds_1.formatSyncTransactionDocId(curMainDBSeqByStoreDocId[doc.inStoreDocId], dbContextByStoreDocId[doc.inStoreDocId].strStoreCompanyId);
        const syncDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.inStoreDocId], syncDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(syncDoc._deleted).to.equal(true);
        expect(syncDoc._rev.indexOf("2-")).to.equal(0);
        expect(outStoreDoc._rev.indexOf("4-")).to.equal(0);
        expect(inStoreDoc._rev.indexOf("4-")).to.equal(0);
        const masterDocId = formatDocIds_1.formatMasterDocIdFromSyncTransactionDocId(syncDocId);
        const slaveDocId = formatDocIds_1.formatSlaveDocIdFromMasterDocId(masterDocId);
        const slaveDoc = yield couchDBApis_1.getDeletedDoc(dbContextByStoreDocId[doc.outStoreDocId], slaveDocId, 0, dbInstanceHelper_1.getMainDBInstance);
        expect(slaveDoc._deleted).to.equal(true);
        expect(slaveDoc._rev.indexOf("2-")).to.equal(0);
        const masterDoc = yield couchDBApis_1.getDeletedDoc(dbContext, masterDocId, 0, dbInstanceHelper_1.getLicenceDBInstance);
        expect(masterDoc._rev.indexOf("2-")).to.equal(0);
        const lockSyncDocId = formatDocIds_1.formatLockDocIdFromDocId(inStoreDoc._id);
        const lockSyncDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSyncDocId, 3, init_1.getCloudLicenceDBInstance);
        expect(lockSyncDoc.txDocId).to.equal(syncDoc._id);
        expect(lockSyncDoc._rev.indexOf("7-")).to.equal(0);
        const lockSlaveDocId = formatDocIds_1.formatLockDocIdFromDocId(inStoreDoc._id);
        const lockSlaveDoc = yield couchDBApis_1.getDeletedDoc(dbContext, lockSlaveDocId, 1, init_1.getCloudLicenceDBInstance);
        expect(lockSlaveDoc.txDocId).to.equal(slaveDoc._id);
        expect(lockSlaveDoc._rev.indexOf("9-")).to.equal(0);
        return [inStoreDoc, outStoreDoc];
    });
    it('Execute Transfer Doc', () => __awaiter(this, void 0, void 0, function* () {
        //master doc should not create slave document in the 3rd store
    }));
    it('end to end test', () => __awaiter(this, void 0, void 0, function* () {
        //use changes
        //check lock and unlock
        //slave doc
        //master doc
        //sync transaction doc
    }));
    it('tests', () => __awaiter(this, void 0, void 0, function* () {
        // //request
        let [inStoreDoc, outStoreDoc] = yield testStockTransfer_Request(storeDocIdArr[1], storeDocIdArr[0]);
        // //transferout
        [inStoreDoc, outStoreDoc] = yield testStockTransfer_TransferOut(outStoreDoc);
        // //transfer in
        [inStoreDoc, outStoreDoc] = yield testStockTransfer_TransferIn(inStoreDoc);
        // //request 
        [inStoreDoc, outStoreDoc] = yield testStockTransfer_Request(storeDocIdArr[1], storeDocIdArr[0]);
        // //transferout
        [inStoreDoc, outStoreDoc] = yield testStockTransfer_TransferOut(outStoreDoc);
        //reject transfer out
        [inStoreDoc, outStoreDoc] = yield testStockTransfer_RejectTransferOut(outStoreDoc);
        //rejected
        [inStoreDoc, outStoreDoc] = yield testStockTransfer_Rejected(outStoreDoc);
        //transferout delete
        //request 
        [inStoreDoc, outStoreDoc] = yield testStockTransfer_Request(storeDocIdArr[1], storeDocIdArr[0]);
        //transferout
        [inStoreDoc, outStoreDoc] = yield testStockTransfer_TransferOut(outStoreDoc);
        //reject transfer out
        [inStoreDoc, outStoreDoc] = yield testStockTransfer_RejectTransferOut_frominstore(inStoreDoc);
        //rejected
        [inStoreDoc, outStoreDoc] = yield testStockTransfer_Rejected_frominstore(inStoreDoc);
        //transferout delete
    }));
});
//# sourceMappingURL=stockTransfer-test.js.map