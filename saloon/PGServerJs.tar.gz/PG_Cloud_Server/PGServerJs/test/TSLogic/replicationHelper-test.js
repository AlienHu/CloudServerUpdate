"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const chai = require("chai");
const expect = chai.expect;
const dbInstanceHelper_1 = require("../../TSCouchDB/Common/dbInstanceHelper");
const dbConfig_1 = require("../../TSControllers/interfaces/dbConfig");
const couchDBUtils = require("../../controllers/common/CouchDBUtils");
const couchInit_1 = require("../../TSCouchDB/couchInit");
const replicationHelper_1 = require("../../TSCouchDB/Replication/replicationHelper");
const formatCouchDBUrlAndName_1 = require("../../TSControllers/utils/formatCouchDBUrlAndName");
const commonUtils_1 = require("../common/commonUtils");
const couchDBApisG_1 = require("../../TSCouchDB/Common/couchDBApisG");
describe('Replication UT', function () {
    this.timeout(100000);
    let iMaxItemId = 0;
    let iMaxCatId = 0;
    let port = dbConfig_1.dbConfig.port;
    const _replicatorConfig = {
        host: '127.0.0.1',
        port: port,
        username: 'couchadmin',
        password: 'test',
        dbPrefix: '',
        name: '_replicator',
        bAddPrefix: false,
        bAddCompanyStoreIDSufix: false,
        bAddRegistrationIDSufix: false,
        strStoreCompanyId: '',
        strRegistrationId: ''
    };
    const rt1Config = {
        host: '127.0.0.1',
        port: port,
        username: 'couchadmin',
        password: 'test',
        dbPrefix: '',
        name: 'rt1',
        bAddPrefix: false,
        bAddCompanyStoreIDSufix: false,
        bAddRegistrationIDSufix: false,
        strStoreCompanyId: '',
        strRegistrationId: ''
    };
    const rt2Config = {
        host: '127.0.0.1',
        port: port,
        username: 'couchadmin',
        password: 'test',
        dbPrefix: '',
        name: 'rt2',
        bAddPrefix: false,
        bAddCompanyStoreIDSufix: false,
        bAddRegistrationIDSufix: false,
        strStoreCompanyId: '',
        strRegistrationId: ''
    };
    before(() => __awaiter(this, void 0, void 0, function* () {
        yield couchInit_1.deleteDB(_replicatorConfig, _replicatorConfig, _replicatorConfig);
        yield couchInit_1.createDatabase(_replicatorConfig, _replicatorConfig, _replicatorConfig);
        yield couchInit_1.deleteDB(rt1Config, rt1Config, rt1Config);
        yield couchInit_1.createDatabase(rt1Config, rt1Config, rt1Config);
        yield couchInit_1.deleteDB(rt2Config, rt2Config, rt2Config);
        yield couchInit_1.createDatabase(rt2Config, rt2Config, rt2Config);
    }));
    function createDocs(config, bAddDDoc, iNumDocs) {
        return __awaiter(this, void 0, void 0, function* () {
            let dbInstance = dbInstanceHelper_1.getDBInstance(config, config, config);
            let docArr = [];
            for (let i = 0; i < iNumDocs; i++) {
                docArr.push({
                    _id: 'item_' + (++iMaxItemId)
                });
            }
            for (let i = 0; i < iNumDocs; i++) {
                docArr.push({
                    _id: 'cat_' + (++iMaxCatId)
                });
            }
            if (bAddDDoc) {
                docArr.push({
                    _id: "_design/replication",
                    version: 1,
                    filters: {
                        byTypeArr: function (doc, req) {
                            function getDocTypeFromDocId(docId) {
                                var strSplitArr = docId.split('_');
                                if (strSplitArr.length >= 1) {
                                    return strSplitArr[0];
                                }
                                else {
                                    return "";
                                }
                            }
                            if (!req.query.includeDocTypeSerializedStr && !req.query.excludeDocTypeSerializedStr) {
                                return true;
                            }
                            if (doc._id.indexOf('_design') === 0) {
                                return false; //because we may have per store conditions
                            }
                            var docType = getDocTypeFromDocId(doc._id); //#TITO Design Documents? What to do?
                            docType = '_' + docType + '_';
                            //#TITO when migration.. few or many of the documents would have been migrated
                            //#TITO so migrate on cloud or turn off replication or have some hybrid approach
                            if (req.query.includeDocTypeSerializedStr && req.query.includeDocTypeSerializedStr.indexOf(docType) > -1) {
                                return true;
                            }
                            if (req.query.excludeDocTypeSerializedStr && req.query.excludeDocTypeSerializedStr.indexOf(docType) > -1) {
                                return false;
                            }
                            if (req.query.includeDocTypeSerializedStr) {
                                return false;
                            }
                            else if (req.query.excludeDocTypeSerializedStr) {
                                return true;
                            }
                            return false;
                        }.toString()
                    }
                });
            }
            yield couchDBUtils.bulkDocs(docArr, dbInstance);
            let allDocs = yield couchDBUtils.getAllDocsByType('item', dbInstance);
            expect(allDocs.length).to.equal(iMaxItemId);
            allDocs = yield couchDBUtils.getAllDocsByType('cat', dbInstance);
            expect(allDocs.length).to.eq(iMaxCatId);
        });
    }
    it('create sample data', () => __awaiter(this, void 0, void 0, function* () {
        yield createDocs(rt1Config, true, 3);
    }));
    it('Adding Replication', () => __awaiter(this, void 0, void 0, function* () {
        yield replicationHelper_1.replicateByTypeArr({
            excludeDocTypeArr: [],
            includeDocTypeArr: ['item'],
            bContinuous: true,
            bNoReplication: false,
            username: 'couchadmin',
            password: 'test',
            srcDBName: formatCouchDBUrlAndName_1.getFullDBName(rt1Config, rt1Config, rt1Config.dbPrefix),
            srcDBUrl: formatCouchDBUrlAndName_1.getFullCouchDBDbUrl(rt1Config),
            targetDBName: formatCouchDBUrlAndName_1.getFullDBName(rt2Config, rt2Config, rt2Config.dbPrefix),
            targetDBUrl: formatCouchDBUrlAndName_1.getFullCouchDBDbUrl(rt2Config)
        });
        yield commonUtils_1.pgTimeOut(1000);
        let dbInstance = dbInstanceHelper_1.getDBInstance(rt2Config, rt2Config, rt2Config);
        let allDocs = yield couchDBUtils.getAllDocsByType('item', dbInstance);
        expect(allDocs.length).to.equal(3);
        allDocs = yield couchDBUtils.getAllDocsByType('cat', dbInstance);
        expect(allDocs.length).to.eq(0);
    }));
    it('Create More Docs And Check Replication', () => __awaiter(this, void 0, void 0, function* () {
        yield createDocs(rt1Config, false, 3);
        yield commonUtils_1.pgTimeOut(2000);
        let dbInstance = dbInstanceHelper_1.getDBInstance(rt2Config, rt2Config, rt2Config);
        let allDocs = yield couchDBUtils.getAllDocsByType('item', dbInstance);
        expect(allDocs.length).to.equal(6);
        allDocs = yield couchDBUtils.getAllDocsByType('cat', dbInstance);
        expect(allDocs.length).to.eq(0);
    }));
    it('Replicating Cat but not item now', () => __awaiter(this, void 0, void 0, function* () {
        yield replicationHelper_1.replicateByTypeArr({
            excludeDocTypeArr: [],
            includeDocTypeArr: ['cat'],
            bContinuous: true,
            bNoReplication: false,
            username: 'couchadmin',
            password: 'test',
            srcDBName: formatCouchDBUrlAndName_1.getFullDBName(rt1Config, rt1Config, rt1Config.dbPrefix),
            srcDBUrl: formatCouchDBUrlAndName_1.getFullCouchDBDbUrl(rt1Config),
            targetDBName: formatCouchDBUrlAndName_1.getFullDBName(rt2Config, rt2Config, rt2Config.dbPrefix),
            targetDBUrl: formatCouchDBUrlAndName_1.getFullCouchDBDbUrl(rt2Config)
        });
        yield commonUtils_1.pgTimeOut(2000);
        let dbInstance = dbInstanceHelper_1.getDBInstance(rt2Config, rt2Config, rt2Config);
        let allDocs = yield couchDBUtils.getAllDocsByType('item', dbInstance);
        expect(allDocs.length).to.equal(6);
        allDocs = yield couchDBUtils.getAllDocsByType('cat', dbInstance);
        expect(allDocs.length).to.eq(6);
    }));
    it('Create More Docs And Check Replication', () => __awaiter(this, void 0, void 0, function* () {
        yield createDocs(rt1Config, false, 3);
        yield commonUtils_1.pgTimeOut(2000);
        let dbInstance = dbInstanceHelper_1.getDBInstance(rt2Config, rt2Config, rt2Config);
        let allDocs = yield couchDBUtils.getAllDocsByType('item', dbInstance);
        expect(allDocs.length).to.equal(6);
        allDocs = yield couchDBUtils.getAllDocsByType('cat', dbInstance);
        expect(allDocs.length).to.eq(9);
    }));
    it('Stop Replicating', () => __awaiter(this, void 0, void 0, function* () {
        yield replicationHelper_1.replicateByTypeArr({
            excludeDocTypeArr: [],
            includeDocTypeArr: [],
            bContinuous: true,
            bNoReplication: true,
            username: 'couchadmin',
            password: 'test',
            srcDBName: formatCouchDBUrlAndName_1.getFullDBName(rt1Config, rt1Config, rt1Config.dbPrefix),
            srcDBUrl: formatCouchDBUrlAndName_1.getFullCouchDBDbUrl(rt1Config),
            targetDBName: formatCouchDBUrlAndName_1.getFullDBName(rt2Config, rt2Config, rt2Config.dbPrefix),
            targetDBUrl: formatCouchDBUrlAndName_1.getFullCouchDBDbUrl(rt2Config)
        });
        yield createDocs(rt1Config, false, 3);
        yield commonUtils_1.pgTimeOut(2000);
        let dbInstance = dbInstanceHelper_1.getDBInstance(rt2Config, rt2Config, rt2Config);
        let allDocs = yield couchDBUtils.getAllDocsByType('item', dbInstance);
        expect(allDocs.length).to.equal(6);
        allDocs = yield couchDBUtils.getAllDocsByType('cat', dbInstance);
        expect(allDocs.length).to.eq(9);
    }));
    it('rep test', () => __awaiter(this, void 0, void 0, function* () {
        yield couchInit_1.deleteDB(_replicatorConfig, _replicatorConfig, _replicatorConfig);
        yield couchInit_1.createDatabase(_replicatorConfig, _replicatorConfig, _replicatorConfig);
        yield couchInit_1.deleteDB(rt2Config, rt2Config, rt2Config);
        yield couchInit_1.createDatabase(rt2Config, rt2Config, rt2Config);
        let dbInstance = dbInstanceHelper_1.getDBInstance(rt2Config, rt2Config, rt2Config);
        let allDocs = yield couchDBUtils.getAllDocsByType('item', dbInstance);
        expect(allDocs.length).to.equal(0);
        yield createDocs(rt1Config, false, 50);
        dbInstance = dbInstanceHelper_1.getDBInstance(rt1Config, rt1Config, rt1Config);
        allDocs = yield couchDBUtils.getAllDocsByType('item', dbInstance);
        expect(allDocs.length).to.equal(62);
        yield commonUtils_1.pgTimeOut(5000);
        let repDoc = {
            "_id": "rt1_rt2",
            "source": "http://couchadmin:test@127.0.0.1:5894/rt1",
            "target": "http://couchadmin:test@127.0.0.1:5894/rt2",
            "continuous": false,
            "create_target": false,
            "filter": "replication/byTypeArr",
            "query_params": {
                "includeDocTypeSerializedStr": "_cat_item_",
                "excludeDocTypeSerializedStr": "",
                "storeDocIdSerializedStr": ""
            }
        };
        dbInstance = dbInstanceHelper_1.getDBInstance(_replicatorConfig, _replicatorConfig, _replicatorConfig);
        yield couchDBApisG_1.createOrUpdate(repDoc, dbInstance);
        yield replicationHelper_1.isReplicationCompleted(repDoc._id, _replicatorConfig);
        dbInstance = dbInstanceHelper_1.getDBInstance(rt2Config, rt2Config, rt2Config);
        allDocs = yield couchDBUtils.getAllDocsByType('item', dbInstance);
        expect(allDocs.length).to.equal(62);
        allDocs = yield couchDBUtils.getAllDocsByType('cat', dbInstance);
        expect(allDocs.length).to.eq(62);
    }));
});
//# sourceMappingURL=replicationHelper-test.js.map