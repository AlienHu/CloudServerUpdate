require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
var profitGuruFaker = require('../common/profitGuruFaker.js');
var commonTestUtils = require('../common/commonUtils.js');
const couchDbManager = require('../../dbManagers/couchDbManager');
//var app = require('../../app');
var app;
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;

var ItemModel = Models.profitGuru_items;
var itemList;

var newEmployee4ThisTest = profitGuruFaker.getFakerExpressUserCouchEmployee();

describe('All Sales Rest Apis:', function() {
    this.timeout(500000);

    before(function(done) {
        couchDbManager.initCouchDb(true).then(function(resp) {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                //TODO BK have to look why makePayment UT is fiailing when I use same authenticated request
                //across all the UTs here
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4ThisTest).then(function(result) {
                    // authenticatedUserRequest = result.authenticatedRequest;
                    return commonTestUtils.createSomeItems(5);
                }).then(function(resp) {
                    return ItemModel.all().then(function(allItem) {
                        itemList = allItem;
                    });
                }).then(function() {
                    done();
                });
            });
        });
    });

    it('Add Item to Cart', function() {
        expect(itemList.length).greaterThan(0);
        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4ThisTest).then(function(result) {
            var authenticatedRequest = result.authenticatedRequest;
            return authenticatedRequest
                .post('/sales/additemRestApi')
                .send({
                    item: itemList[0].dataValues.item_id
                })
                .expect(200).then(function(resp) {
                    //console.log(resp);
                    expect(resp.body.cart.length).to.equal(1);
                });
        });
    });

    it('Edit Sale Item', function() {

        expect(itemList.length).greaterThan(0);
        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4ThisTest).then(function(result) {
            var authenticatedRequest = result.authenticatedRequest;

            return authenticatedRequest
                .post('/sales/additemRestApi')
                .send({
                    item: itemList[0].dataValues.item_id
                })
                .expect(200).then(function(resp) {

                    expect(resp.body.cart.length).to.equal(1);

                    var editItemParams = {
                        line: resp.body.cart[0].line,
                        price: 100,
                        discount: 5,
                        quantity: 101
                    };

                    return authenticatedRequest
                        .post('/sales/editItemRestApi')
                        .send(editItemParams)
                        .expect(200);
                }).then(function(resp) {

                    expect(resp.body.cart.length).to.equal(1);
                    expect(resp.body.cart[0].price).to.equal(100);
                    expect(resp.body.cart[0].quantity).to.equal(101);

                });
        });

    });

    it('Edit Sale and Add Item to Sale', function() {

        expect(itemList.length).greaterThan(0);
        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4ThisTest).then(function(result) {
            var authenticatedRequest = result.authenticatedRequest;

            return authenticatedRequest
                .post('/sales/additemRestApi')
                .send({
                    item: itemList[0].dataValues.item_id
                })
                .expect(200).then(function(resp) {

                    expect(resp.body.cart.length).to.equal(1);

                    var editItemParams = {
                        line: resp.body.cart[0].line,
                        price: 100,
                        discount: 5,
                        quantity: 101
                    };

                    return authenticatedRequest
                        .post('/sales/editItemRestApi')
                        .send(editItemParams)
                        .expect(200).then(function(resp) {
                            return authenticatedRequest
                                .post('/sales/additemRestApi')
                                .send({
                                    item: itemList[0].dataValues.item_id
                                }).then(function(resp) {

                                    expect(resp.body.cart.length).to.equal(1);
                                    expect(resp.body.cart[0].price).to.equal(100);
                                    expect(resp.body.cart[0].quantity).to.equal(102);

                                })

                        });
                });
            // .then(function(resp) {

            //     expect(resp.body.cart.length).to.equal(1);
            //     expect(resp.body.cart[0].price).to.equal(100);
            //     expect(resp.body.cart[0].quantity).to.equal(103);

            // });
        });

    });

    it('Cancel Sale', function() {

        expect(itemList.length).greaterThan(0);
        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4ThisTest).then(function(result) {
            var authenticatedRequest = result.authenticatedRequest;
            return authenticatedRequest
                .post('/sales/additemRestApi')
                .send({
                    item: itemList[0].dataValues.item_id
                })
                .expect(200).then(function(resp) {

                    expect(resp.body.cart.length).to.equal(1);
                    return authenticatedRequest
                        .post('/sales/cancel_saleRestApi')
                        .expect(200)
                }).then(function(resp) {
                    expect(resp.body.cart.length).to.equal(0);
                });
        });

    });

    it('Make Payment', function() {
        var paymentParams;
        expect(itemList.length).greaterThan(0);
        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4ThisTest).then(function(result) {
            var authenticatedRequest = result.authenticatedRequest;
            return authenticatedRequest
                .post('/sales/additemRestApi')
                .send({
                    item: itemList[0].dataValues.item_id
                })
                .expect(200)
                .then(function(resp) {

                    expect(resp.body.cart.length).to.equal(1);
                    paymentParams = {
                        payment_type: "Cash",
                        amount_tendered: 10000
                    };
                    return authenticatedRequest
                        .post('/sales/add_paymentRestApi')
                        .send(paymentParams)
                        .expect(200);
                }).then(function(resp) {
                    expect(resp.body.payments_total).to.equal(paymentParams.amount_tendered);

                });
        });

    });

    it('complete sale', function() {
        var paymentParams;
        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4ThisTest).then(function(result) {
            var authenticatedRequest = result.authenticatedRequest;
            return authenticatedRequest
                .post('/sales/additemRestApi')
                .send({
                    item: itemList[0].dataValues.item_id
                })
                .expect(200)
                .then(function(resp) {

                    expect(resp.body.cart.length).to.equal(1);
                    paymentParams = {
                        payment_type: "Cash",
                        amount_tendered: resp.body.total
                    };
                    return authenticatedRequest
                        .post('/sales/add_paymentRestApi')
                        .send(paymentParams)
                        .expect(200);
                }).then(function(resp) {

                    expect(resp.body.payments_total).to.equal(paymentParams.amount_tendered);
                    return authenticatedRequest
                        .post('/sales/completeSaleRestApi')
                        .send(paymentParams)
                        .expect(200);
                }).then(function(resp) {
                    console.log(resp.body);
                });
        });
    });

    it('suspend sale', function() {
        var paymentParams;
        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4ThisTest).then(function(result) {
            var authenticatedRequest = result.authenticatedRequest;
            return authenticatedRequest
                .post('/sales/additemRestApi')
                .send({
                    item: itemList[0].dataValues.item_id
                })
                .expect(200)
                .then(function(resp) {

                    expect(resp.body.cart.length).to.equal(1);
                    paymentParams = {
                        payment_type: "Cash",
                        amount_tendered: resp.body.total
                    };
                    return authenticatedRequest
                        .post('/sales/add_paymentRestApi')
                        .send(paymentParams)
                        .expect(200);
                }).then(function(resp) {

                    expect(resp.body.payments_total).to.equal(paymentParams.amount_tendered);
                    return authenticatedRequest
                        .put('/sales/suspendSaleRestApi')
                        .send(paymentParams)
                        .expect(200);
                }).then(function(resp) {
                    console.log(resp.body);
                });
        });
    });

    //TODO Ganesh: Write UT's for SaveKOT and edit KOT that uses saveTableOrde api

});