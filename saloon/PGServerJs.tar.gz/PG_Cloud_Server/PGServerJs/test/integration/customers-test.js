require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;

var profitGuruFaker = require('../common/profitGuruFaker.js');
var request = require('supertest');
var chai = require("chai");
var expect = chai.expect;

var app;
var q = require('q');
const couchDbManager = require('../../dbManagers/couchDbManager');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');
describe('All Customer functionalities:', function() {

    this.timeout(100000);
    before(function(done) {
        couchDbManager.initCouchDb(false).then(function(resp) {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                //  commonTestUtils.initPGServer(newEmployee4CreateNLogin).then(function() {
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });

                // });
            });
        });

    });

    it.only('create Customer', function() {
        var aCustomer = {
            customer: profitGuruFaker.getFakerCustomer()
        };
        console.log('Phone-number:', aCustomer.customer.phone_number);
        return authenticatedUserRequest
            .post('/customers/create')
            .send(aCustomer)
            .expect(200).then(function(resp) {
                expect(resp.body.customer_id).to.be.a('number')

            });
    });

    //Todo: this will not work without id as parameter
    it('update Customer', function() {
        var aCustomer = {
            customer: profitGuruFaker.getFakerCustomer()
        };
        return authenticatedUserRequest
            .post('/customers/create')
            .send(aCustomer)
            .expect(200).then(function(resp) {
                expect(resp.body.customer_id).to.be.a('number');
                aCustomer.customer.person_id = resp.body.customer_id;
                return authenticatedUserRequest
                    .put('/customers/update')
                    .send(aCustomer)
                    .expect(200).then(function(resp) {
                        //Todo: add validation here
                    });
            });

    });

    //Todo: this will not work without id as parameter
    it('import Customer', function() {
        var reqData = {};
        reqData.customer = {};
        reqData.customer.file = 'xyz.csv';
        return authenticatedUserRequest
            .post('/customers/import')
            .send(reqData)
            .expect(500).then(function(resp) {
                //Todo: add validation here
            });
    });

    //Todo: this will not work without id as parameter
    it('export Customer', function() {
        var reqData = {};
        reqData.customer = {};
        reqData.customer.file = 'xyzw.csv';
        return authenticatedUserRequest
            .post('/customers/export')
            .send(reqData)
            .expect(200).then(function(resp) {
                //Todo: add validation here
            });
    });

    it('delete Customer', function() {

        var aCustomer = {
            customer: profitGuruFaker.getFakerCustomer()
        };
        return authenticatedUserRequest
            .post('/customers/create')
            .send(aCustomer)
            .expect(200).then(function(resp) {
                expect(resp.body.customer_id).to.be.a('number');
                aCustomer.customer.person_id = resp.body.customer_id;
                return authenticatedUserRequest
                    .delete('/customers/delete')
                    .send(aCustomer)
                    .expect(200).then(function(resp) {
                        //Todo: add validation here
                    });
            });

    });

});