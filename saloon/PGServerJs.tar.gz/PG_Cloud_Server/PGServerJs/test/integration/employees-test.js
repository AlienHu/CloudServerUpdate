require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;
var profitGuruFaker = require('../common/profitGuruFaker.js');
var commonTestUtils = require('../common/commonUtils.js');
var chai = require("chai");
var expect = chai.expect;
var app;
const couchDbManager = require('../../dbManagers/couchDbManager');
var newNodeUserOrEmployee;

var request = require('supertest');
var testConfig = require("../testConfig.json");
/*
#################### IMPORTANT #########
Following are the basic UTs for integration tests
for detailed UTs look under PGServerJs/test/unit/express-user-couch-test
*/

describe('profitguru APP Users/Employees', function() {
    this.timeout(500000);

    before(function(done) {
        Models.dropAllDbs({
            dropSqlDbs: false,
            dropCouchDbs: true
        }).then(function(resp) {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                done();
            });
        });

    });

    it('Create First User/Employee', function() {

        newNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();
        console.log('Adding User/Employee:', newNodeUserOrEmployee);

        return request(app)
            .post('/employees/signup')

            .send(newNodeUserOrEmployee)
            .expect(200);
    });

    it('signin/login', function() {

        var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();

        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, tmpnewNodeUserOrEmployee).then(function(response) {

            return request('http://localhost:3000')
                .post('/employees/signin')

                .send(tmpnewNodeUserOrEmployee)
                .expect(200)
                .then(function(resp) {

                    console.log(resp.body);

                });
        })
    });

    it('get logged in profile', function() {
        var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();
        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, tmpnewNodeUserOrEmployee).then(function(response) {
            return response.authenticatedRequest
                .get('/employees/current')

                .expect(200)
                .then(function(res) {
                    console.log(res.text);

                });
        });
    });

    it('should not login', function() {
        //changing the password
        var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();;

        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, tmpnewNodeUserOrEmployee).then(function(response) {

            tmpnewNodeUserOrEmployee.password = 'casjchsa';
            return response.authenticatedRequest
                .post('/employees/signin')

                .send(tmpnewNodeUserOrEmployee)
                .expect(200)
                .then(function(resp) {
                    //Error
                    expect(1).to.equal(0);
                }).catch(function(reason) {
                    //Expected
                    expect(1).to.equal(1);
                });

        });

    });

    it('Create User/Employee after logging in', function() {

        var adminUser = profitGuruFaker.getFakerExpressUserCouchEmployee();
        var secondUser = profitGuruFaker.getFakerExpressUserCouchEmployee();
        secondUser.name = 'alienHu';

        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, adminUser).then(function(response) {

            return response.authenticatedRequest
                .post('/employees')

                .send(secondUser)
                .expect(200)
                .then(function() {

                    return response.authenticatedRequest
                        .post('/employees/signin')

                        .send(secondUser)
                        .expect(200);

                }).then(function() {
                    return response.authenticatedRequest
                        .get('/employees/current')

                        .expect(200);
                }).then(function(resp) {
                    var currentEmployee = JSON.parse(resp.text).user;
                    expect(currentEmployee.name).to.equal(secondUser.name);
                });
        });
    });

    it('Delete User/Employee', function() {

        var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();

        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, tmpnewNodeUserOrEmployee).then(function(response) {

            var user4Delete = {
                user: {
                    username: tmpnewNodeUserOrEmployee.username
                }
            };
            return response.authenticatedRequest
                .delete('/employees/' + tmpnewNodeUserOrEmployee.name)
                .expect(200)
                .then(function(resp) {
                    expect(1).to.equal(1);
                }).catch(function(reason) {
                    expect(1).to.equal(0);
                });

        });

    });

});