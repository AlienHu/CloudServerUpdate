require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;
var assert = require('assert');
var app;
var profitGuruFaker = require('../common/profitGuruFaker.js');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');
const couchDbManager = require('../../dbManagers/couchDbManager');
var dbManagers = require('../../dbManagers');

var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;

describe('Application Features ', function() {
    this.timeout(100000);

    before(function(done) {
        Models.dropAllDbs({
            dropSqlDbs: false,
            dropCouchDbs: true
        }).then(function() {
            dbManagers.couchDbManager.grantFeaturesModuleUpdatePermission().then(function() {
                app = require('../../bin/PGServerJs.js');
                app.on("PGuruNodeServerStarted", function() {
                    var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                    //Adding the features modules entitlment for this Employee
                    var entitlements = JSON.parse(newEmployee4CreateNLogin.roles[0]);
                    //Enabling features Module
                    entitlements.features = {
                        allowAll: true,
                        allowNone: false,
                        featuresGetAndUpdate: {
                            apis: ['getAllowedFeatures', 'updateAllowedFeatures']
                        }
                    };
                    newEmployee4CreateNLogin.roles[0] = JSON.stringify(entitlements);
                    commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                        authenticatedUserRequest = result.authenticatedRequest;
                        done();
                    });
                });
            });

        });
    });

    it('get allowed features', function() {
        return authenticatedUserRequest
            .get('/features/getAllowedFeatures')
            .expect(200).then(function(result) {
                console.log(result.body);
                expect(result.body).to.not.equal(null);
                expect(result.body.hasOwnProperty('items')).to.equal(true);
            });
    });

    it('should create Item with default enabled items feature', function() {

        var anItem = {
            item: profitGuruFaker.getFakerItem()
        };

        return authenticatedUserRequest
            .post('/items/create')
            .send(anItem)
            .expect(200);
    });

    it('should not create  with  disabled items feature', function() {
        var existingFeatures;
        return authenticatedUserRequest
            .get('/features/getAllowedFeatures')
            .expect(200).then(function(result) {
                existingFeatures = result.body;
                existingFeatures.items.enabled = false;
                return authenticatedUserRequest
                    .put('/features/updateAllowedFeatures')
                    .send(existingFeatures)
                    .expect(200);
            }).then(function(result) {
                var anItem = {
                    item: profitGuruFaker.getFakerItem()
                };

                return authenticatedUserRequest
                    .post('/items/create')
                    .send(anItem)
                    .expect(500);
            }).then(function(result) {
                console.log(result.body);
            });
    });

});