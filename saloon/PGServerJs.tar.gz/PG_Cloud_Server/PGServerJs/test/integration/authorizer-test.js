require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;

var requestAsPromised = require("supertest-as-promised");
var fs = require('fs');
var assert = require('assert');
var jsonfile = require('jsonfile');
var q = require('q');
var profitGuruFaker = require('../common/profitGuruFaker.js');
var commonTestUtils = require('../common/commonUtils.js');
var chai = require("chai");
var expect = chai.expect;
var app;
const couchDbManager = require('../../dbManagers/couchDbManager');
var newNodeUserOrEmployee;

var request = require('supertest');

describe('Authorization MiddleWare Tests', function() {
    this.timeout(500000);

    before(function(done) {
        Models.dropAllDbs({
            dropSqlDbs: false,
            dropCouchDbs: true
        }).then(function(resp) {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                done();
            });
        });

    });
    describe('Login Authorizer', function() {
        it('Access server for allSuspendedSalesRestApi Before logging in', function() {

            return request('http://localhost:3000')
                .get('/sales/allSuspendedSalesRestApi')
                .expect(500);

        });

        it('Access server for allSuspendedSalesRestApi After logging in', function() {

            var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();

            return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, tmpnewNodeUserOrEmployee).then(function(response) {
                console.log(tmpnewNodeUserOrEmployee);
                return request('http://localhost:3000')
                    .post('/employees/signin')
                    .redirects(1)
                    .send(tmpnewNodeUserOrEmployee)
                    .expect(200)
                    .then(function(resp) {
                        //Should fail because we are't using authenticated request object
                        return request('http://localhost:3000')
                            .get('/sales/allSuspendedSalesRestApi')
                            .expect(500)
                            .then(function() {
                                return response.authenticatedRequest
                                    .get('/sales/allSuspendedSalesRestApi')
                                    .expect(200);
                            });

                    });
            });
        });
    });

    describe('Entilttlements Authorizer', function() {

        it('Access server for allSuspendedSalesRestApi Before logging in', function() {

            return request('http://localhost:3000')
                .get('/sales/allSuspendedSalesRestApi')
                .expect(500);

        });

        it('Access server for allSuspendedSalesRestApi After logging in', function() {

            var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();

            return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, tmpnewNodeUserOrEmployee).then(function(response) {
                console.log(tmpnewNodeUserOrEmployee);
                return request('http://localhost:3000')
                    .post('/employees/signin')
                    .redirects(1)
                    .send(tmpnewNodeUserOrEmployee)
                    .expect(200)
                    .then(function(resp) {
                        return response.authenticatedRequest
                            .get('/sales/allSuspendedSalesRestApi')
                            .expect(200);

                    });

            });
        });

        it('Disable Sales Entitlements and try allSuspendedSalesRestApi After logging in', function() {

            var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();
            var entitlements = JSON.parse(tmpnewNodeUserOrEmployee.roles[0]);
            //Disabling Sales Module
            entitlements.sales.allowNone = true;
            tmpnewNodeUserOrEmployee.roles[0] = JSON.stringify(entitlements);

            return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, tmpnewNodeUserOrEmployee).then(function(response) {
                console.log(tmpnewNodeUserOrEmployee);
                return request('http://localhost:3000')
                    .post('/employees/signin')
                    .redirects(1)
                    .send(tmpnewNodeUserOrEmployee)
                    .expect(200)
                    .then(function(resp) {
                        return response.authenticatedRequest
                            .get('/sales/allSuspendedSalesRestApi')
                            .expect(500);

                    });

            });
        });
    });

    describe('licence Authorizer', function() {

        it('should not allow allSuspendedSalesRestApi After logging in without applying licence', function() {

            var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();

            return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, tmpnewNodeUserOrEmployee, true).then(function(response) {
                console.log(tmpnewNodeUserOrEmployee);
                return request('http://localhost:3000')
                    .post('/employees/signin')
                    .redirects(1)
                    .send(tmpnewNodeUserOrEmployee)
                    .expect(200)
                    .then(function(resp) {
                        return response.authenticatedRequest
                            .get('/sales/allSuspendedSalesRestApi')
                            .expect(500);

                    });

            });
        });

        it('should  allow allSuspendedSalesRestApi After logging in with applying licence', function() {

            var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();

            //createExpressUserCouchNewUserAuthenticatedRequest applies licence also
            return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, tmpnewNodeUserOrEmployee, false).then(function(response) {
                console.log(tmpnewNodeUserOrEmployee);
                return request('http://localhost:3000')
                    .post('/employees/signin')
                    .redirects(1)
                    .send(tmpnewNodeUserOrEmployee)
                    .expect(200)
                    .then(function(resp) {
                        return response.authenticatedRequest
                            .get('/sales/allSuspendedSalesRestApi')
                            .expect(200);

                    });

            });
        });

    });
    /*
    //TODO 
    1) following UT should try to access a feature which is not Allowed.
    2) a) grant the permission to use the above feature and try to acces that feature now it should allow.
    3) revoke the above feature now it should not work
        describe.only('Allowed Features Authorizer', function() {
            // before(function(done) {
            //     app.httpServer.close();
            //     done();
            // });
            var featureApp;
            beforeEach(function(done) {
                Models.dropAllDbs({
                    dropSqlDbs: false,
                    dropCouchDbs: true
                }).then(function(resp) {
                    featureApp = require('../../bin/PGServerJs.js', {
                        bustCache: true
                    });
                    featureApp.on("PGuruNodeServerStarted", function() {
                        done();
                    });
                });

            });

            afterEach(function(done) {
                featureApp.httpServer.close(done);
            }); //Kill the server here

            it('should not allow allSuspendedSalesRestApi After logging in without applying licence', function() {

                var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();

                return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(featureApp, tmpnewNodeUserOrEmployee, true).then(function(response) {
                    console.log(tmpnewNodeUserOrEmployee);
                    return request('http://localhost:3000')
                        .post('/employees/signin')
                        .redirects(1)
                        .send(tmpnewNodeUserOrEmployee)
                        .expect(200)
                        .then(function(resp) {
                            return response.authenticatedRequest
                                .get('/sales/allSuspendedSalesRestApi')
                                .expect(500);

                        });

                });
            });

            it('should  allow allSuspendedSalesRestApi After logging in with applying licence', function() {

                var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();

                //createExpressUserCouchNewUserAuthenticatedRequest applies licence also
                return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(featureApp, tmpnewNodeUserOrEmployee, false).then(function(response) {
                    console.log(tmpnewNodeUserOrEmployee);
                    return request('http://localhost:3000')
                        .post('/employees/signin')
                        .redirects(1)
                        .send(tmpnewNodeUserOrEmployee)
                        .expect(200)
                        .then(function(resp) {
                            return response.authenticatedRequest
                                .get('/sales/allSuspendedSalesRestApi')
                                .expect(200);

                        });

                });
            });
            // it('Disable Sales Feature and try allSuspendedSalesRestApi After logging in', function() {

            //     var tmpnewNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();

            //     return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, tmpnewNodeUserOrEmployee).then(function(response) {
            //         console.log(tmpnewNodeUserOrEmployee);
            //         return request('http://localhost:3000')
            //             .post('/employees/signin')
            //             .redirects(1)
            //             .send(tmpnewNodeUserOrEmployee)
            //             .expect(200)
            //             .then(function(resp) {
            //                 return response.authenticatedRequest
            //                     .get('/sales/allSuspendedSalesRestApi')
            //                     .expect(500);

            //             });

            //     });
            // });
        });*/

});