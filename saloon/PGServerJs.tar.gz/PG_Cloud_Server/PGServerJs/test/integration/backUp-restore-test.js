require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;
var profitGuruFaker = require('../common/profitGuruFaker.js');
var commonTestUtils = require('../common/commonUtils.js');
var request = require('supertest');
var requestAsPromised = require("supertest-as-promised");
const couchDbManager = require('../../dbManagers/couchDbManager');
var shelljs = require('shelljs');
var app;
var path = require('path');
var backUpBaseLocationDir = __dirname + '/../testData';
var authenticatedUserRequest;
var chai = require('chai');
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
var chaiFiles = require('chai-files');
chai.use(chaiFiles);
var file = chaiFiles.file;
chai.should();
var expect = chai.expect;

describe('All Items functionalities:', function() {
    this.timeout(500000);
    before(function(done) {
        shelljs.rm('-rf', backUpBaseLocationDir + '/*');
        couchDbManager.initCouchDb(true).then(function(resp) {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });
            });
        });
    });

    beforeEach(function() {

    });
    it('Take BackUp', function() {

        return authenticatedUserRequest
            .post('/backUpAndRestore/takeBackUp')
            .send({
                reason: 'casual',
                backUpLocation: backUpBaseLocationDir
            })
            .expect(200);
    });

    it('get BackUpList ', function() {

        return authenticatedUserRequest
            .post('/backUpAndRestore/takeBackUp')
            .send({
                reason: 'casual',
                backUpLocation: backUpBaseLocationDir
            })
            .expect(200).then(function() {
                return authenticatedUserRequest
                    .get('/backUpAndRestore/listBackUps?backUpLocation=+' + backUpBaseLocationDir)
                    .expect(200);

            }).then(function(backUpList) {
                expect(backUpList.body.length).to.be.at.least(1);
            });
    });

    it('Restore BackUp ', function() {

        return authenticatedUserRequest
            .post('/backUpAndRestore/takeBackUp')
            .send({
                reason: 'casual',
                backUpLocation: backUpBaseLocationDir
            })
            .expect(200).then(function() {
                return authenticatedUserRequest
                    .get('/backUpAndRestore/listBackUps?backUpLocation=+' + backUpBaseLocationDir)
                    .expect(200);

            }).then(function(backUpList) {
                expect(backUpList.body.length).to.be.at.least(1);
                return authenticatedUserRequest
                    .post('/backUpAndRestore/restoreBackUp')
                    .send({
                        restoreLocation: backUpList.body[0],
                        backUpLocation: backUpBaseLocationDir
                    })
                    .expect(200);
            }).then(function(resp) {

            });
    });

});