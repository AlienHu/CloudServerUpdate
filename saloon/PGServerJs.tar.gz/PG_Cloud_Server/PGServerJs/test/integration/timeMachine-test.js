require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;

var profitGuruFaker = require('../common/profitGuruFaker.js');
var request = require('supertest');
var chai = require("chai");
var expect = chai.expect;

var app;
var q = require('q');
const couchDbManager = require('../../dbManagers/couchDbManager');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');
describe('All Time Machine functionalities:', function() {

    this.timeout(20000000);
    before(function(done) {
        couchDbManager.initCouchDb(true).then(function(resp) {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                //  commonTestUtils.initPGServer(newEmployee4CreateNLogin).then(function() {
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });

                // });
            });
        });

    });

    it('Data Creator', function() {
        var dataCreationParama = {
            // clientType: 'DeskTopApp',
            //appType: 'retail',
            customers: 10,
            suppliers: 10,
            employees: 10,
            items: 10,
            debug: false
        };
        return authenticatedUserRequest
            .post('/demoApp/timeMachine/runDataCreator')
            .send(dataCreationParama)
            .expect(200).then(function(resp) {
                expect(resp.body.done).to.equal(true);

            });
    });

    it('Txns Maker', function() {
        var txnsMakerParama = {
            sales: 10,
            receivings: 10,
            debug: false,
            salesDuration: 10,
            receiveDuration: 10
        };

        var dataCreationParama = {
            customers: 10,
            suppliers: 10,
            employees: 10,
            items: 10,
            debug: false
        };

        return authenticatedUserRequest
            .post('/demoApp/timeMachine/runDataCreator')
            .send(dataCreationParama)
            .expect(200).then(function(resp) {
                expect(resp.body.done).to.equal(true);
                return authenticatedUserRequest
                    .post('/demoApp/timeMachine/runTaxnsMaker')
                    .send(txnsMakerParama)
                    .expect(200);
            }).then(function(resp) {
                expect(resp.body.done).to.equal(true);

            });
    });

    it.only('The Time Machine', function() {
        var timeMachineParamas = {
            clientType: 'DeskTopApp',
            appType: 'retail',
            // customers: 5,
            // suppliers: 5,
            // employees: 1,
            // items: 10,
            debug: false,
            iCustomers: 10, //initial customers
            iSuppliers: 10,
            iEmployees: 2,
            iItems: 15,
            years: 0,
            months: 0,
            weeks: 0,
            days: 5,
            customersAday: 1,
            suppliersAday: 1,
            employeesAday: 0,
            itemsAday: 3,
            salesTxnADay: 10,
            receiveTxnADay: 2,
            salesDuration: 15,
            receiveDuration: 100,
            isApplyRandomness: false
        };
        return authenticatedUserRequest
            .post('/demoApp/timeMachine/runTimeMachine')
            .send(timeMachineParamas)
            .expect(200).then(function(resp) {
                expect(resp.body.done).to.equal(true);

            });
    });

});