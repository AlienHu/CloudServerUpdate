require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;

var app;
var profitGuruFaker = require('../common/profitGuruFaker.js');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');
var profitGuruFaker = require('../common/profitGuruFaker.js');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');
var request = require('supertest');

describe('All Core functionalities:', function() {
    this.timeout(100000);
    var faker = require('faker');
    var randomNote = faker.lorem.word() + ' ' + faker.lorem.word() + ' ' + faker.lorem.word();

    var aNote = {
        data: {
            notes: randomNote
        }
    };

    before(function(done) {
        require('../../dbManagers/couchDbManager').initCouchDb(true).then(function() {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                //commonTestUtils.initPGServer(newEmployee4CreateNLogin).then(function() {
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });

                //});
            });
        });
    });

    it('Get ProfitGuru Rest Apis', function() {
        //return authenticatedUserRequest
        request('http://localhost:3000')
            .get('/core/profitGuruRestApis')
            .expect(200).then(function(resp) {
                console.log(resp);
            });
    });

    it('Get ProfitGuru Elements', function() {
        // return authenticatedUserRequest
        request('http://localhost:3000')
            .get('/core/profitGuruElements')
            .expect(200).then(function(resp) {
                console.log(resp);
            });
    });

});