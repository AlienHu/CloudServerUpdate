require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;

var profitGuruFaker = require('../common/profitGuruFaker.js');
var chai = require("chai");
var expect = chai.expect;
var app;

const couchDbManager = require('../../dbManagers/couchDbManager');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');
describe('All ProfitGuru Db Reset functionalities:', function() {

    this.timeout(100000);
    before(function(done) {
        couchDbManager.initCouchDb(true).then(function(resp) {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                //  commonTestUtils.initPGServer(newEmployee4CreateNLogin).then(function() {
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });

                // });
            });
        });

    });

    it('reset ProfitGuru Dbs', function() {

        return authenticatedUserRequest
            .post('/demoApp/resetProfitGuruDbs')
            .expect(200).then(function(resp) {
                expect(resp.body.done).to.equal(true);

            });
    });

    it('reset ProfitGuru Dbs with Re-start', function() {
        var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
            authenticatedUserRequest = result.authenticatedRequest;
            return authenticatedUserRequest
                .post('/demoApp/resetProfitGuruDbs')
                .send({
                    restart: true
                })
                .expect(200).then(function(resp) {
                    expect(resp.body.done).to.equal(true);
                    expect(resp.body.restarted).to.equal(true);

                });
        });

    });
});