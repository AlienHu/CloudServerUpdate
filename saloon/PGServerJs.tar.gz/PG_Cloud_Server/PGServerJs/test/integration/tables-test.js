require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;

var request = require('supertest');
var app;
var profitGuruFaker = require('../common/profitGuruFaker.js');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');

describe('All Tables functionalities:', function() {
    this.timeout(100000);
    var aTable = {
        table_no: 1,
        desc: 'Hello World'
    };

    before(function(done) {
        require('../../dbManagers/couchDbManager').initCouchDb(true).then(function() {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                // commonTestUtils.initPGServer(newEmployee4CreateNLogin).then(function() {
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });

                //  });
            });
        });
    });

    beforeEach(function() {});

    it('create Tables', function() {
        return authenticatedUserRequest
            .post('/tables/createTableRestApi')
            .send(aTable)
            .expect(200).then(function(resp) {
                //store the id and use it for update and delete
                //Todo: add validation here                
            });
    });

    it('get Tables', function() {
        return authenticatedUserRequest
            .get('/tables/get')
            .send({
                data: {}
            })
            .expect(200).then(function(resp) {
                //store the id and use it for update and delete
                //Todo: add validation here                
            });
    });

    it('delete Table', function() {
        return authenticatedUserRequest
            .delete('/tables/deleteTableApiRestApi')
            .send({

                table_no: 1

            })
            .expect(200).then(function(resp) {
                //store the id and use it for update and delete
                //Todo: add validation here                
            });
    });
});