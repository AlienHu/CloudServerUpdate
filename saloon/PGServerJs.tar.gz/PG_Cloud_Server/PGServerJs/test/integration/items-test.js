require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;
var profitGuruFaker = require('../common/profitGuruFaker.js');
var commonTestUtils = require('../common/commonUtils.js');
var request = require('supertest');
var requestAsPromised = require("supertest-as-promised");
const couchDbManager = require('../../dbManagers/couchDbManager');
var app;

var authenticatedUserRequest;
describe('All Items functionalities:', function() {
    this.timeout(500000);
    before(function(done) {

        couchDbManager.initCouchDb(true).then(function(resp) {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });

                //  });

            });

        });

    });

    it('create Item', function() {

        var anItem = {
            item: profitGuruFaker.getFakerItem()
        };

        return authenticatedUserRequest
            .post('/items/create')
            .send(anItem)
            .expect(200);
    });

    it('update item', function() {

        var anItem = {
            item: profitGuruFaker.getFakerItem()
        };

        return authenticatedUserRequest
            .post('/items/create')
            .send(anItem)
            .expect(200).then(function(resp) {

                var aItem4Update = {
                    item: profitGuruFaker.getFakerItem()
                };

                aItem4Update.item.item_id = resp.body.item_id;
                return authenticatedUserRequest
                    .put('/items/update')
                    .send(aItem4Update)
                    .expect(200);

            });
    });

    it('export items', function() {

        var anItem = {
            item: profitGuruFaker.getFakerItem()
        };

        return authenticatedUserRequest
            .post('/items/create')
            .send(anItem)
            .expect(200).then(function(resp) {

                var reqData = {
                    item: {
                        file: 'ExportedItems.csv'
                    }
                };

                return authenticatedUserRequest
                    .put('/items/export')
                    .send(reqData)
                    .expect(200);

            });
    });

    //Todo: import and export uts validation has to be added
    it('import items', function() {

        var anItem = {
            item: profitGuruFaker.getFakerItem()
        };

        return authenticatedUserRequest
            .post('/items/create')
            .send(anItem)
            .expect(200).then(function(resp) {

                var reqData = {
                    item: {
                        file: 'ExportedItems.csv'
                    }
                };

                return authenticatedUserRequest
                    .put('/items/import')
                    .send(reqData)
                    .expect(500);

            });
    });

    it('delete Item', function() {

        var anItem = {
            item: profitGuruFaker.getFakerItem()
        };

        return authenticatedUserRequest
            .post('/items/create')
            .send(anItem)
            .expect(200).then(function(resp) {

                var aItem4Delete = {
                    item: {
                        item_id: resp.body.item_id
                    }
                };
                return authenticatedUserRequest
                    .delete('/items/delete')
                    .send(aItem4Delete)
                    .expect(200);

            });
    });
});