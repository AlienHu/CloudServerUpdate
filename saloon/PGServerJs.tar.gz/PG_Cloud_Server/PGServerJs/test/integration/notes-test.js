require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;

var request = require('supertest');
var app;

var profitGuruFaker = require('../common/profitGuruFaker.js');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');

describe('All Notes functionalities:', function() {
    this.timeout(100000);
    var faker = require('faker');
    var randomNote = faker.lorem.word() + ' ' + faker.lorem.word() + ' ' + faker.lorem.word();

    var aNote = {
        data: {
            notes: randomNote
        }
    };

    before(function(done) {
        require('../../dbManagers/couchDbManager').initCouchDb(true).then(function() {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                //  commonTestUtils.initPGServer(newEmployee4CreateNLogin).then(function() {
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });

                //});
            });
        });
    });

    it('create/update Notes', function() {
        return authenticatedUserRequest
            .post('/notes/saveNotes')
            .send(aNote)
            .expect(200).then(function(resp) {
                //store the id and use it for update and delete
                //Todo: add validation here                
            });
    });

    it('get Notes', function() {
        return authenticatedUserRequest
            .get('/notes/getNotes')
            .send({
                data: {}
            })
            .expect(200).then(function(resp) {
                //store the id and use it for update and delete
                //Todo: add validation here                
            });
    });

});