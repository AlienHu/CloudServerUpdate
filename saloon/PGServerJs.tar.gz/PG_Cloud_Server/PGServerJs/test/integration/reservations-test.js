require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;

var request = require('supertest');

var app;
var q = require('q');
var faker = require('faker');
var moment = require('moment');
var profitGuruFaker = require('../common/profitGuruFaker.js');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');

describe('All Reservation functionalities', function() {
    this.timeout(100000);
    before(function(done) {
        require('../../dbManagers/couchDbManager').initCouchDb(true).then(function() {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                // commonTestUtils.initPGServer(newEmployee4CreateNLogin).then(function() {
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });

                // });
            });
        });
    });

    it('save reservations', function() {
        var reservationData = {};
        reservationData.table_no = 1;
        reservationData.bookingTime = moment().format('YYYY-MM-DD HH:mm:ss');
        reservationData.bookingEndTime = moment(reservationData.bookingTime).add(91, 'm').format('YYYY-MM-DD HH:mm:ss');
        reservationData.contactInfo = faker.lorem.word();
        reservationData.Reservation_desc = faker.lorem.word();

        var req = {};
        req.data = reservationData;
        return authenticatedUserRequest
            .post('/reservations/saveReservation')
            .send(req)
            .expect(200).then(function(resp) {
                //Todo: add validation here                
            });
    });

    it('selectTable', function() {
        var req = {};
        req.data = {};
        req.data.bookingTime = moment().format('YYYY-MM-DD HH:mm:ss');
        req.data.bookingEndTime = moment(req.data.bookingTime).add(30, 'm').format('YYYY-MM-DD HH:mm:ss');
        return authenticatedUserRequest
            .get('/reservations/selectTable')
            .send(req)
            .expect(200).then(function(resp) {
                //Todo: add validation here                
            });
    });

    it('minimumReservationDuration', function() {
        var req = {};
        req.data = {};
        return authenticatedUserRequest
            .get('/reservations/minimumReservationDuration')
            .send(req)
            .expect(200).then(function(resp) {
                //Todo: add validation here                
            });
    });

    it('getReservationDetails', function() {
        var req = {};
        req.data = {};
        return authenticatedUserRequest
            .get('/reservations/getReservationDetails')
            .send(req)
            .expect(200).then(function(resp) {
                //Todo: add validation here                
            });
    });

    it('getReservationDetails4TableColorChange', function() {
        var req = {};
        req.data = {};
        return authenticatedUserRequest
            .get('/reservations/getReservationDetails4TableColorChange')
            .send(req)
            .expect(200).then(function(resp) {
                //Todo: add validation here                
            });
    });

    it('checkReservation4table', function() {
        var req = {};
        req.data = {};
        req.data.tableNo = 1; //Todo: use proper tableno    
        return authenticatedUserRequest
            .get('/reservations/checkReservation4table')
            .send(req)
            .expect(200).then(function(resp) {
                //Todo: add validation here                
            });
    });

    it('checkAlreadyReserved', function() {
        var req = {};
        req.data = {};
        req.data.table_no = 1; //Todo: use proper table no
        return authenticatedUserRequest
            .get('/reservations/checkAlreadyReservedRestApi')
            .send(req)
            .expect(200).then(function(resp) {
                //Todo: add validation here                
            });
    });

    it('reservationWindow', function() {
        var req = {};
        req.data = {};
        req.data.starttime = moment().format('YYYY-MM-DD HH:mm:ss');
        req.data.endtime = moment(req.data.starttime).add(30, 'm').format('YYYY-MM-DD HH:mm:ss');
        return authenticatedUserRequest
            .get('/reservations/reservationsWindow')
            .send(req)
            .expect(200).then(function(resp) {
                //Todo: add validation here                
            });
    });

    it('delete reservation', function() {
        //Todo : use the id from reservations window
        var req = {};
        req.data = {
            reservation_id: 1
        };
        return authenticatedUserRequest
            .delete('/reservations/deleteReservation')
            .send(req)
            .expect(200).then(function(resp) {});
    });
});