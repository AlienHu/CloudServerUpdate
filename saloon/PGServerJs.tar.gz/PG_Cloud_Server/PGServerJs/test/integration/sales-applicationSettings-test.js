require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
var profitGuruFaker = require('../common/profitGuruFaker.js');
var commonTestUtils = require('../common/commonUtils.js');
const couchDbManager = require('../../dbManagers/couchDbManager');

var app;
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;

var ItemModel = Models.profitGuru_items;
var itemList;

var newEmployee4ThisTest = profitGuruFaker.getFakerExpressUserCouchEmployee();
var authenticatedUserRequest;

describe('Sales Settings changes', function() {
    this.timeout(500000);

    before(function(done) {
        couchDbManager.initCouchDb(true).then(function(resp) {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4ThisTest).then(function(resp) {
                    authenticatedUserRequest = resp.authenticatedRequest;
                    return commonTestUtils.createSomeItems(5);
                }).then(function(resp) {
                    return ItemModel.all().then(function(allItem) {
                        itemList = allItem;
                    });
                }).then(function() {
                    done();
                });
            });
        });
    });

    it('Settings Update Validation by changing defaultSalesDiscount', function() {
        //Change a setting lets say tax_included and see whether that has the automatic effect
        expect(itemList.length).greaterThan(0);
        var totalBeforeDiscountSettingChange, currentSettings;
        return commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4ThisTest).then(function(result) {
            var authenticatedRequest = result.authenticatedRequest;

            return authenticatedRequest
                .post('/sales/additemRestApi')
                .send({
                    item: itemList[0].dataValues.item_id
                })
                .expect(200).then(function(resp) {
                    totalBeforeDiscountSettingChange = resp.body.total;

                    expect(resp.body.cart.length).to.equal(1);

                    return authenticatedUserRequest
                        .get('/applicationSettings/getApplicationSettings')
                        .expect(200);
                }).then(function(resp) {
                    currentSettings = resp.body;
                    //Increasing discount percentage lets say by 5%
                    currentSettings.discount.defaultSalesDiscount = currentSettings.discount.defaultSalesDiscount + 5;

                    return authenticatedUserRequest
                        .put('/applicationSettings/updateApplicationSettings')
                        .send(currentSettings)
                        .expect(200);

                }).then(function() {

                    return authenticatedRequest
                        .post('/sales/cancel_saleRestApi')
                        .expect(200);

                }).then(function() {

                    return authenticatedRequest
                        .post('/sales/additemRestApi')
                        .send({
                            item: itemList[0].dataValues.item_id
                        })
                        .expect(200);

                }).then(function(resp) {
                    var totalAfterDiscountSettingChange = resp.body.total;
                    console.log('cart Total Old=' + totalBeforeDiscountSettingChange + ' New=' + totalAfterDiscountSettingChange);
                    expect(totalBeforeDiscountSettingChange).to.not.equal(totalAfterDiscountSettingChange);
                });
        });

    });

});