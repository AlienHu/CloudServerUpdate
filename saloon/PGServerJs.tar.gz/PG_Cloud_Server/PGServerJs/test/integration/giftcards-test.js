require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;

var request = require('supertest');

var app;
var q = require('q');
var profitGuruFaker = require('../common/profitGuruFaker.js');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');

describe('All Giftcard functionalities:', function() {
    this.timeout(100000);
    var aCustomer = {
        customer: profitGuruFaker.getFakerCustomer()
    };

    var aGiftcard = profitGuruFaker.getFakerGiftcard();

    before(function(done) {
        require('../../dbManagers/couchDbManager').initCouchDb(true).then(function() {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                // commonTestUtils.initPGServer(newEmployee4CreateNLogin).then(function() {
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });

                // });
            });
        });
    });

    it('create Customer', function() {
        return authenticatedUserRequest
            .post('/customer/create')
            .send(aCustomer)
            .expect(200).then(function(resp) {
                //store the id and use it for update and delete
                //Todo: add validation here                
            });
    });

    it('create giftcard', function() {
        aGiftcard.customer = 1; //Todo:: to get customer from previous test
        return authenticatedUserRequest
            .post('/giftcards/saveGiftCardRestApi')
            .send(aGiftcard)
            .expect(200).then(function(resp) {
                //Todo: add validation here
            });
    });

    it('update giftcard', function() {
        aGiftcard.customer = 1; //Todo:: to get customer from previous test
        aGiftcard.preValue = aGiftcard.giftcardvalue;
        return authenticatedUserRequest
            .put('/giftcards/update')
            .send(aGiftcard)
            .expect(200).then(function(resp) {
                //Todo: add validation here
            });
    });

    it('get all giftcard', function() {
        var requestData = {};
        requestData.giftcard = {};
        return authenticatedUserRequest
            .get('/giftcards/getGiftCardsRestApi')
            .send(requestData)
            .expect(200).then(function(resp) {
                //Todo: add validation here
            });
    });

    it('delete giftcards', function() {
        var requestData = {};
        requestData.ids = [];
        requestData.ids.push(1);
        return authenticatedUserRequest
            .delete('/giftcards/delete')
            .send(requestData)
            .expect(200).then(function(resp) {
                //Todo: add validation here
            });
    });

});