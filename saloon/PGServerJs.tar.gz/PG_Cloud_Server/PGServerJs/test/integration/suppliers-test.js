require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;

var profitGuruFaker = require('../common/profitGuruFaker.js');

var request = require('supertest');
var requestAsPromised = require("supertest-as-promised");

var app;
var q = require('q');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');
describe('All Supplier functionalities:', function() {
    this.timeout(100000);

    before(function(done) {
        require('../../dbManagers/couchDbManager').initCouchDb(true).then(function() {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                //commonTestUtils.initPGServer(newEmployee4CreateNLogin).then(function() {
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });

                // });
            });
        });
    });

    it('create Supplier', function() {

        var aSupplier = {
            supplier: profitGuruFaker.getFakerSupplier()
        };

        return authenticatedUserRequest
            .post('/suppliers/create')
            .send(aSupplier)
            .expect(200);
    });

    it('update Supplier', function() {

        var aSupplier = {
            supplier: profitGuruFaker.getFakerSupplier()
        };

        return authenticatedUserRequest
            .post('/suppliers/create')
            .send(aSupplier)
            .expect(200).then(function(resp) {

                var aSupplier4Update = {
                    supplier: profitGuruFaker.getFakerSupplier()
                };
                aSupplier4Update.supplier.person_id = resp.body.person_id;
                return authenticatedUserRequest
                    .put('/suppliers/update')
                    .send(aSupplier4Update)
                    .expect(200);

            });
    });

    it('delete Supplier', function() {

        var aSupplier = {
            supplier: profitGuruFaker.getFakerSupplier()
        };

        return authenticatedUserRequest
            .post('/suppliers/create')
            .send(aSupplier)
            .expect(200).then(function(resp) {
                aSupplier.supplier.person_id = resp.body.person_id;
                return authenticatedUserRequest
                    .delete('/suppliers/delete')
                    .send(aSupplier)
                    .expect(200);

            });
    });
});