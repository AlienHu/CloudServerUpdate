require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;
var assert = require('assert');
var app;
var profitGuruFaker = require('../common/profitGuruFaker.js');
var authenticatedUserRequest;
var commonTestUtils = require('../common/commonUtils.js');

describe('All Licence functionalities:', function() {
    this.timeout(100000);

    before(function(done) {
        Models.dropAllDbs({
            dropSqlDbs: false,
            dropCouchDbs: true
        }).then(function() {
            app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                // commonTestUtils.initPGServer(newEmployee4CreateNLogin).then(function() {
                commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(app, newEmployee4CreateNLogin).then(function(result) {
                    authenticatedUserRequest = result.authenticatedRequest;
                    done();
                });

                // });
            });
        });
    });

    describe('amIAuthorized2Connect:(should generate the trial licence)', function(done) {

        it('Checking whther amIAuthorized2Connect', function() {
            return authenticatedUserRequest
                .get('/licence/amIAuthorized2Connect?clientType=DeskTopApp&appType=' + process.env.APP_TYPE)
                .expect(200).then(function(result) {
                    console.log(result.body);
                    assert.equal(result.body.hasApplied, true);
                    assert.equal(result.body.isAuthorized, true);
                    assert.equal(result.body.daysLeft4LicenceExpiry <= 15, true);
                    assert.equal(result.body.isTrial, true);

                });
        });

    });
});