require('dotenv-safe').load({
    path: __dirname + '/../../.env',
    sample: __dirname + '/../../env.example'
});;

var chai = require("chai");
var expect = chai.expect;
var unAuthenticatedReq;

describe('change admin password test', function() {

    this.timeout(100000);
    before(function(done) {
        const couchDbManager = require('../../dbManagers/couchDbManager');
        couchDbManager.initCouchDb(false).then(function(resp) {
            var app = require('../../bin/PGServerJs.js');
            app.on("PGuruNodeServerStarted", function() {
                var request = require('supertest');
                unAuthenticatedReq = request.agent(app);
                done();
            });
        });

    });

    it('change admin password', function() {
        var reqData = {
            name: 'admin',
            password: 'naidu2',
            password_again: 'naidu2'
        };

        return unAuthenticatedReq.post('/employees/changeAdminPassword').send(reqData).expect(200).then(function(resp) {

        });
    });

    it('change some other user password', function() {
        var reqData = {
            name: 'randomUser',
            password: 'naidu2',
            password_again: 'naidu2'
        };

        return unAuthenticatedReq.post('/employees/changeAdminPassword').send(reqData).expect(400).then(function(resp) {

        });
    });

});