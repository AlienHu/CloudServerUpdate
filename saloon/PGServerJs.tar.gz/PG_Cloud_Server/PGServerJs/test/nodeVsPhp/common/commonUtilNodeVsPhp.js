var ItemModel = Models.profitGuru_items;
var linuxShell = require('shelljs');
var ItemController = require('../../../controllers/Items');
var commonTestUtils = require('../../common/commonUtils.js');
var profitGuruFaker = require('../../common/profitGuruFaker.js');
var request = require('supertest');
var profitGuruNodeServer;
var PGServerJs;
var BPromise = require('bluebird');

var spex = require('spex')(BPromise);
var employee4PHPAuth, employee4NodeAuth;
var itemList = [];
var commonNodeVsPhpTestUtils = function() {
    var _self = this;

    function source(index) {
        if (index < itemList.length) {
            return _self.createNodeItemAfterPhpSuccess(itemList[index]);
        }
    }

    function dest(index, data) {
        console.log(data);
        // data = resolved data from readFile;
    }

    this.dropAndRecreateMysqlDBs = function() {
        // linuxShell.exec('../../../profitGuruNodeServer/Utils/dropAndRecreateMysqlDBs.sh');
        var absScriptPath = __dirname + '/../../../../profitGuruNodeServer/Utils/resetProfitGuruDBs.sh';
        console.log(absScriptPath);
        linuxShell.exec(absScriptPath);
    };

    this.callPhpServerApi = function(restApi, paramJson) {
        return this.phpAuthenticatedRequest().then(function(authenticatedRequest) {
            authenticatedRequest
                .get(restApi)
                .query(paramJson)
                .expect(200)
                .end(function(err, res) {
                    if (!err) {
                        return Promise.resolve(res)
                    } else {
                        return Promise.reject(err);
                    }
                });
        });
    };

    function getPhpAdminAuthenticatedRequest() {
        var phpAdminLoginData = {
            username: "admin",
            password: "profitGuru",
            clientType: "DeskTopApp"
        };
        //var authenticatedRequest = request.agent(server);
        return new Promise(function(resolve, reject) {
            var authenticatedRequest = request.agent(profitGuruNodeServer);
            authenticatedRequest
                .get('/profitGuruRestSvc_retail/index.php/login/loginRestApi')
                .query(phpAdminLoginData)
                .end(function(error, response) {
                    if (error) {
                        throw error;
                    }
                    resolve(authenticatedRequest);
                });
        });

    }
    this.phpCreateFirstEmployeeIfNotExists = function(newEmployeeData) {
        return getPhpAdminAuthenticatedRequest().then(function(phpAdminAuthenticatedRequest) {
            //return this.phpAuthenticatedRequest().then(function(authenticatedRequest) {
            phpAdminAuthenticatedRequest
                .get('/profitGuruRestSvc_retail/index.php/employees/employeeSaveRestApi')
                .query(newEmployeeData)
                .expect(200)
                .end(function(err, res) {
                    if (!err) {
                        return Promise.resolve(res)
                    } else {
                        return Promise.reject(err);
                    }
                });
            //  });
        });
    };

    this.getPhpItemList = function() {
        return this.phpAuthenticatedRequest().then(function(request) {
            return request
                .get('/profitGuruRestSvc_retail/index.php/items/getItemsRestApi')
                .expect(200)

        }).then(function(res) {
            return Promise.resolve(res.text);
        });
    };

    this.phpCreateItem = function(newItemData) {

        return this.phpAuthenticatedRequest().then(function(request) {

            return request
                .get('/profitGuruRestSvc_retail/index.php/items/saveItemRestApi')
                .query(newItemData)

        }).then(function(res) {
            //console.log(res.text);
            return Promise.resolve(res.text);
            // if (!err && res.text.length < 70) {
            //     return Promise.resolve(res)
            // } else {
            //     return Promise.reject(err);
            // }
        }).catch(function(reason) {
            console.log(reason);
            return Promise.resolve(reason);
        });
    };

    this.createNodeItemAfterPhpSuccess = function(itemData) {

        return new Promise(function(resolve, reject) {

            // var sleepSecs = Math.floor(Math.random() * (20 - 5) + 5);

            //console.log('Sleeping for ', sleepSecs);
            //   sleep.sleep(sleepSecs);
            _self.phpCreateItem(itemData).then(function(resp) {
                return ItemController.createItem(itemData);
            }).then(function(resp) {
                resolve(resp);
            }).catch(function(reason) {
                reject(reason);
            });
        });

    };

    this.createSomeItems = function(noItem2Create) {
        var noOfItems2Create = noItem2Create || 5;
        var promiseList = [];

        //  var oldFaker = require('../../../../profitGuruNodeServer/UTs/profitGuruPhpServer/common/profitGuruFakerData.js');
        var createItemResponse = [];
        for (var i = 0; i < noOfItems2Create; ++i) {

            var newItemData = profitGuruFaker.getFakerItem(undefined, undefined, true);
            //  var phpItemData = profitGuruFaker.getPhpItemData()
            //var oldItemData = oldFaker.getFakerItem();
            //sleep.sleep(1);
            //promiseList.push(ItemController.createItem(newItemData));
            //promiseList.push(this.phpCreateItem(newItemData));
            itemList.push(newItemData);
            //promiseList.push(this.createNodeItemAfterPhpSuccess(newItemData));
        }

        // return Promise.resolve().then(function() {
        //         return BPromise.each(promiseList, function(resp) {
        //             createItemResponse.push(resp);
        //         });
        //     })
        //     .then(function() {
        //         return Promise.resolve(createItemResponse);
        //     });
        return spex.sequence(source, dest);
        // .then(function(data) {
        //     // finished the sequence;
        // })
        // .catch(function(error) {
        //     // error;
        // });
    };

    this.getAllItemsInSqlDb = function() {
        return ItemModel.all();
    };

    this.phpAuthenticatedRequest = function() {
        return new Promise(function(resolve) {

            var authenticatedRequest = request.agent(profitGuruNodeServer);
            authenticatedRequest
                .get('/profitGuruRestSvc_retail/index.php/login/loginRestApi')
                .query(employee4PHPAuth)
                .end(function(error, response) {
                    if (error) {
                        throw error;
                    }
                    resolve(authenticatedRequest);
                });
        });

    };
    this.nodeAuthenticatedRequest = function() {
        var authenticatedRequest = request.agent(PGServerJs);
        return new Promise(function(resolve) {
            authenticatedRequest
                .post('/employees/signin')
                .redirects(1)
                .send(employee4NodeAuth)
                .expect(200)
                .end(function(error) {
                    if (error) {
                        throw error;
                    }
                    resolve(authenticatedRequest);
                });
        });

    };

    this.InitTestNodeVsPhp = function(newEmployeeData) {
        return new Promise(function(resolve, reject) {
            newEmployeeData = newEmployeeData || profitGuruFaker.getFakerPhpAndExpressUserCouchEmployee();
            var nodeEmployeeData = profitGuruFaker.getFakerExpressUserCouchEmployee();
            nodeEmployeeData.name = newEmployeeData.name;
            nodeEmployeeData.first_name = newEmployeeData.first_name;
            nodeEmployeeData.last_name = newEmployeeData.last_name;
            nodeEmployeeData.password = newEmployeeData.password;
            nodeEmployeeData.password_again = newEmployeeData.password_again;
            nodeEmployeeData.email = newEmployeeData.email;

            employee4NodeAuth = nodeEmployeeData;
            employee4PHPAuth = newEmployeeData;

            _self.dropAndRecreateMysqlDBs();

            profitGuruNodeServer = require('../../../../profitGuruNodeServer/app.js', {
                bustCache: true
            });
            profitGuruNodeServer.on("PGuruNodeServerStarted", function() {
                console.log('Server set up is Done.started createing Init Data');
                //Not droping the Dbs, if needed uncomment this
                couchDbManager.initCouchDb(true)().then(function() {
                    PGServerJs = require('../../../bin/PGServerJs.js');
                    PGServerJs.on("PGuruNodeServerStarted", function() {
                        console.log('Received PGServerJs:PGuruNodeServerStarted');
                        return Promise.all([_self.phpCreateFirstEmployeeIfNotExists(employee4PHPAuth), commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(PGServerJs, nodeEmployeeData)])
                            .then(function() {
                                console.log('Server initial set up is Done');
                                return _self.createSomeItems();
                            }).then(function(resp) {
                                resolve(resp);
                            });
                    });

                });
            });

        });
    };
};

module.exports = new commonNodeVsPhpTestUtils();