#!/usr/bin/env node

require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .example('$0 items 100', 'Create ProfitGuru Data')
    .alias('c', 'customers')
    .default('c', 0)
    .describe('c', 'Number of Customers to Add')
    .alias('i', 'items')
    .default('i', 0)
    .describe('i', 'Number of Items to Add')
    .alias('s', 'suppliers')
    .default('s', 0)
    .describe('s', 'Number of suppliers to Add')
    .alias('e', 'employees')
    .describe('e', 'Number of employees to Add')
    .default('e', 0)
    .alias('clientType', 'cl')
    .default('cl', 'DeskTopApp')
    .describe('cl', 'clientType DeskTopApp/MobileApp')
    .alias('a', 'appType')
    .alias('d', 'debug')
    .default('d', 0)
    .default('appType', 'retail')
    .describe('appType', 'One of the available appTypes [retail,restaurant]')
    .help('h')
    .alias('h', 'help')
    .argv;

var dataCreationParama = {
    clientType: argv.cl,
    appType: argv.appType,
    customers: argv.c,
    suppliers: argv.s,
    employees: argv.e,
    items: argv.i,
    debug: argv.d
};
var chalk = require('chalk');
var moment = require('moment');

var log = console.log;
var startTime = moment();

var profitGuruDataCreator = require('./profitGuruDataCreator.js');
profitGuruDataCreator = new profitGuruDataCreator();

//Lets set up the ulimit so that we can create more number elements lets say more than 1k

var profitGuruEvents = profitGuruDataCreator.startStandAloneProfitGuruDataCreation(dataCreationParama);
profitGuruEvents.on('profitGuruDataCreatorDone', function() {
    tellMeDurationUTook();
    log(chalk.red('profitGuruDataCreatorDone, U can kill me or I will commit suicide in another 10 Secs'));
    process.exit(0);
});

function tellMeDurationUTook() {
    var currentTimeFromWeb = moment();
    var timeTaken = moment.duration(currentTimeFromWeb.diff(startTime)).humanize();
    log(chalk.green('It took ', timeTaken, ' To complete the task, Have a good Day!!'));

}