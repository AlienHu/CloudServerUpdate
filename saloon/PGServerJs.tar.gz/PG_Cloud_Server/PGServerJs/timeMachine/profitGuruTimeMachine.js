/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */

// var requestAsPromised = require("supertest-as-promised");
// var fs = require('fs');
// var assert = require('assert');
// var jsonfile = require('jsonfile');
// var q = require('q');
// var request = require('supertest');

var chalk = require('chalk');
var log = console.log;
var sleep; // = require('sleep');
var extend = require('util')._extend;
var deepcopy = require("deepcopy");
var setUpMachineTime = require('./setUp.js')(true);

// var dataCreationParamas = {
// 	clientType: '',
// 	appType: '',
// 	customers: 0,
// 	suppliers: 0,
// 	employees: 0,
// 	items: 0,
// 	debug: 0
// };
// var txnCreationParams = {
// 	clientType: '',
// 	appType: '',
// 	sales: 0,
// 	receivings: 0,
// 	debug: 0
// };
var moment = require('moment');

var profitGuruFaker = require('../test/common/profitGuruFaker.js');
var profitGuruDataCreator = require('./profitGuruDataCreator.js');
profitGuruDataCreator = new profitGuruDataCreator();

var profitGuruTxnsMaker = require('./profitGuruTxnsMaker.js');
profitGuruTxnsMaker = new profitGuruTxnsMaker();
var _self;

var profitGuruTimeMachine = function() {
    _self = this;
    var initialDataCreationParamas;
    var diaylyDataCreationParamas, dailyTxnCreationParams;
    var machineStartDate = moment(new Date());
    var profitGuruNodeServer;
    var timeMachineParams;
    var authenticatedUserRequest;

    this.startTimeMachine = function(Params, profitGuruNodeServerParam, authenticatedUserRequestParam) {
        timeMachineParams = Params;
        authenticatedUserRequest = authenticatedUserRequestParam;

        initialDataCreationParamas = {
            clientType: timeMachineParams.clientType,
            appType: timeMachineParams.appType,
            customers: timeMachineParams.iCustomers,
            suppliers: timeMachineParams.iSuppliers,
            employees: timeMachineParams.iEmployees,
            items: timeMachineParams.iItems,
            debug: timeMachineParams.debug,
            isApplyRandomness: timeMachineParams.isApplyRandomness
        };

        diaylyDataCreationParamas = {
            clientType: timeMachineParams.clientType,
            appType: timeMachineParams.appType,
            customers: timeMachineParams.customersAday,
            suppliers: timeMachineParams.suppliersAday,
            employees: timeMachineParams.employeesAday,
            items: timeMachineParams.itemsAday,
            debug: timeMachineParams.debug,
            isApplyRandomness: timeMachineParams.isApplyRandomness
        };
        dailyTxnCreationParams = {
            clientType: timeMachineParams.clientType,
            appType: timeMachineParams.appType,
            sales: timeMachineParams.salesTxnADay,
            receivings: timeMachineParams.receiveTxnADay,
            salesDuration: timeMachineParams.salesDuration,
            receiveDuration: timeMachineParams.receiveDuration,
            debug: timeMachineParams.debug,
            isApplyRandomness: timeMachineParams.isApplyRandomness
        };

        log(chalk.cyan('initialDataCreationParamas=', JSON.stringify(initialDataCreationParamas), 'diaylyDataCreationParamas=', JSON.stringify(diaylyDataCreationParamas), 'dailyTxnCreationParams=', JSON.stringify(dailyTxnCreationParams)));

        //Make use of Sockets to create the Data on other than host machines
        if (!profitGuruNodeServerParam) {
            profitGuruNodeServer = require('../bin/PGServerJs.js', {
                bustCache: true
            });
            profitGuruNodeServer.on("PGuruNodeServerStarted", function() {
                kickStart();
            });
        } else {
            profitGuruNodeServer = profitGuruNodeServerParam;
            kickStart();
        }

        return profitGuruNodeServer;
    };

    function kickStart() {
        log(chalk.green('received PGuruNodeServerStarted'));
        profitGuruNodeServer.on('profitGuruDataCreatorDone', startDailyTxnMachine);
        profitGuruNodeServer.on('profitGuruTxnsMakerDone', startDailyDataCreatorMachine);

        goIntoPastAndStartTraversing().then(function(resp) {
            setUpInitialProfitGuruDataAndStartUp();

        });
    }

    function haveIReachedStartDay() {
        var tmp = new Date();
        var today = moment(new Date());
        return !today.isBefore(machineStartDate);
    }

    function setUpInitialProfitGuruDataAndStartUp() {
        log(chalk.yellow('Calling:profitGuruDataCreator start ', initialDataCreationParamas));
        profitGuruDataCreator.start(initialDataCreationParamas, profitGuruNodeServer, profitGuruFaker, authenticatedUserRequest, true);

    }

    function runTimeMachine(isDataCreation) {
        if (haveIReachedStartDay()) {
            profitGuruNodeServer.emit('profitGuruTimeMachineDone');
        } else {

            if (isDataCreation) {

                traverseADay().then(function(resp) {
                    console.log(resp);
                    log(chalk.yellow('Calling:profitGuruDataCreator start ', JSON.stringify(diaylyDataCreationParamas)));

                    var todaysDataCreationParams = deepcopy(diaylyDataCreationParamas);
                    profitGuruDataCreator.start(todaysDataCreationParams, profitGuruNodeServer, profitGuruFaker, authenticatedUserRequest, true);
                });

            } else {

                var todaysTxnCreationParams = deepcopy(dailyTxnCreationParams);
                log(chalk.yellow('Calling:profitGuruTxnsMaker start ', JSON.stringify(todaysTxnCreationParams)));
                profitGuruTxnsMaker.start(todaysTxnCreationParams, profitGuruNodeServer, profitGuruFaker, authenticatedUserRequest, true);

            }
        }

    }

    function traverseADay() {
        var today = moment(new Date());
        var nextDay = moment(new Date());
        nextDay = nextDay.add(1, 'days');

        if (dailyTxnCreationParams.debug) {
            log(chalk.cyan('Traversing a Day , today: ', today.toString(), ' nextDay: ', nextDay.toString()));
            if (!sleep) {
                sleep = require('sleep');
            }
            sleep.usleep(2000000);
        }

        // return setUpMachineTime.clock.set(nextDay.unix().toString());
        return setUpMachineTime.clock.set(nextDay);
    }

    function startDailyTxnMachine() {
        runTimeMachine();
    }

    function startDailyDataCreatorMachine() {
        runTimeMachine(true);

    }
    var timeMachineStartTime;

    function goIntoPastAndStartTraversing() {

        var days2GoBackInThePast = 0;
        if (timeMachineParams.days > 0) {
            days2GoBackInThePast += timeMachineParams.days;
        }

        if (timeMachineParams.weeks > 0) {
            days2GoBackInThePast += timeMachineParams.weeks * 7;
        }

        if (timeMachineParams.months > 0) {
            days2GoBackInThePast += timeMachineParams.months * 30;
        }

        if (timeMachineParams.years > 0) {
            days2GoBackInThePast += timeMachineParams.years * 360;
        }

        timeMachineStartTime = moment(new Date());
        timeMachineStartTime = timeMachineStartTime.subtract(days2GoBackInThePast, 'days');

        //return setUpMachineTime.clock.set(timeMachineStartTime.unix().toString()).then(function(resp) {
        return setUpMachineTime.clock.set(timeMachineStartTime).then(function(resp) {
            console.log(resp);
        });

    }

};

module.exports = new profitGuruTimeMachine();