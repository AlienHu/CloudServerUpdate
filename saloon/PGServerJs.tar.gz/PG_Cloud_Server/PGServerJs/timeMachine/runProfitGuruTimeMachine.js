#!/usr/bin/env node

require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .example('$0 --items 100', 'Create 100 Items')
    .alias('c', 'customers')
    .default('c', 0)
    .describe('c', 'Number of Customers to Add')
    .alias('ic', 'initialCustomers')
    .default('ic', 2)
    .alias('i', 'items')
    .default('i', 0)
    .describe('i', 'Number of Items to Add')
    .alias('ii', 'initialItems')
    .default('ii', 5)
    .alias('s', 'suppliers')
    .default('s', 0)
    .alias('is', 'initialSuppliers')
    .default('is', 2)
    .describe('s', 'Number of suppliers to Add')
    .alias('e', 'employees')
    .describe('e', 'Number of employees to Add')
    .default('e', 0)
    .alias('ie', 'initialEmployees')
    .default('ie', 1)
    .alias('clientType', 'cl')
    .default('cl', 'DeskTopApp')
    .describe('cl', 'clientType DeskTopApp/MobileApp')
    .alias('a', 'appType')
    .default('a', 'retail')
    .describe('a', 'One of the available appTypes [retail,restaurant]')
    .alias('d', 'debug')
    .default('d', 0)
    .alias('y', 'years')
    .default('y', 0)
    .describe('y', 'No of Years to create past/history Data')
    .alias('m', 'months')
    .default('m', 0)
    .describe('m', 'No of months to create past/history Data')
    .alias('w', 'weeks')
    .default('w', 0)
    .describe('w', 'No of Weeks to create past/history Data')
    .alias('da', 'days')
    .default('da', 0)
    .describe('da', 'No of Days to create past/history Data')
    .alias('cADay', 'customersADay')
    .default('cADay', 3)
    .alias('iADay', 'itemsADay')
    .default('iADay', 5)
    .alias('sADay', 'suppliersADay')
    .default('sADay', 1)
    .alias('eADay', 'employeesADay')
    .default('eADay', 1)
    .alias('sTxnAday', 'salesTxnADay')
    .default('sTxnAday', 10)
    .describe('sTxnAday', 'Sales Txns to make A day')
    .alias('rTxnAday', 'receiveTxnADay')
    .default('rTxnAday', 2)
    .describe('rTxnAday', 'Receivings Txns to make A day')
    .alias('sd', 'salesDuration')
    .default('sd', 15)
    .describe('sd', 'Duration between sales in minutes')
    .alias('rd', 'receiveDuration')
    .default('rd', 180)
    .describe('rd', 'Duration between receivings in minutes')
    .help('h')
    .alias('h', 'help')
    .argv;

var ON_DEATH = require('death');
var chalk = require('chalk');
//var sleep = require('sleep');
var setUpMachineTime = require('./setUp.js');
var moment = require('moment');

var profitGuruTimeMachine = require('./profitGuruTimeMachine.js');
var log = console.log;
var timeMachineParamas = {
    clientType: argv.cl,
    appType: argv.a,
    customers: argv.c,
    suppliers: argv.s,
    employees: argv.e,
    items: argv.i,
    debug: argv.d,
    iCustomers: argv.ic,
    iSuppliers: argv.is,
    iEmployees: argv.ie,
    iItems: argv.ii,
    years: argv.y,
    months: argv.m,
    weeks: argv.w,
    days: argv.da,
    customersAday: argv.customersAday,
    suppliersAday: argv.suppliersAday,
    employeesAday: argv.employeesAday,
    itemsAday: argv.itemsAday,
    salesTxnADay: argv.sTxnAday,
    receiveTxnADay: argv.rTxnAday,
    salesDuration: argv.sd,
    receiveDuration: argv.rd
};
var request = require('request');
//Lets set up the ulimit so that we can create more number elements lets say more than 1k
var timeMachineStartTime = moment(new Date());
var timeMachineStartTime4m_timeapi;
console.log(timeMachineParamas);
var profitGuruEvents = profitGuruTimeMachine.startTimeMachine(timeMachineParamas);

request('http://www.timeapi.org/utc/now', {
    headers: {
        'User-Agent': 'request'
    }
}, (error, response, time) => {
    console.log('start time=', time);
    timeMachineStartTime4m_timeapi = time;
});

ON_DEATH(function(signal, err) {

    resetSystem2CurrentTimeFromWebAndDie();
});

function resetSystem2StartTimeAndDie() {
    //    setUpMachineTime(true).clock.set(timeMachineStartTime.unix().toString()).then(function(resp) {
    setUpMachineTime(true).clock.set(timeMachineStartTime).then(function(resp) {
        log(chalk.red('Resetting the time back to machine Start time(looks like, I am not able to get the web time) ', resp));
        //sleep.usleep(10000000);
        process.exit(0);
    });
}

function resetSystem2CurrentTimeFromWebAndDie() {

    request('http://www.timeapi.org/utc/now', {
        headers: {
            'User-Agent': 'request'
        }
    }, (error, response, time) => {
        if (!error) {
            console.log('End time=', time);
            var currentTimeFromWeb = moment(time);
            var timeTakenByTimeMachine = moment.duration(currentTimeFromWeb.diff(timeMachineStartTime)).humanize();
            log(chalk.green('It took ', timeTakenByTimeMachine, ' To complete the task, Have a good Day!!'));
            log(chalk.green(' Resetting Sytem time to current web time:', time));
            //sleep.usleep(10000000);

            // setUpMachineTime(true).clock.set(currentTimeFromWeb.unix().toString()).then(function(resp) {
            setUpMachineTime(true).clock.set(currentTimeFromWeb).then(function(resp) {
                console.log(resp);
                process.exit(0);
            });
        } else {
            resetSystem2StartTimeAndDie();
        }
    });

}

profitGuruEvents.on('profitGuruTimeMachineDone', resetSystem2CurrentTimeFromWebAndDie);