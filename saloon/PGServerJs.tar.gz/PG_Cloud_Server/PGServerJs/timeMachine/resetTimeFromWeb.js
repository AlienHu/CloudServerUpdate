#!/usr/bin/env node

var chalk = require('chalk');
var sleep = require('sleep');
var moment = require('moment');
var request = require('request');
var setUpMachineTime = require('./setUp.js');

request('http://www.timeapi.org/utc/now', {
    headers: {
        'User-Agent': 'request'
    }
}, (error, response, time) => {
    if (!error) {
        console.log('End time=', time);
        var currentTimeFromWeb = moment(time);

        //   setUpMachineTime(true).clock.set(currentTimeFromWeb.unix().toString()).then(function(resp) {
        setUpMachineTime(true).clock.set(currentTimeFromWeb).then(function(resp) {
            console.log(resp);
            process.exit(0);
        });
    } else {
        console.log(error);
    }
});