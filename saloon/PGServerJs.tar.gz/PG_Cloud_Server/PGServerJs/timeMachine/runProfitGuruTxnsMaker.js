#!/usr/bin/env node

require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .example('$0 items 100', 'Create ProfitGuru Txns')
    .alias('clientType', 'cl')
    .default('cl', 'DeskTopApp')
    .describe('cl', 'clientType DeskTopApp/MobileApp')
    .alias('a', 'appType')
    .default('appType', 'retail')
    .describe('appType', 'One of the available appTypes [retail,restaurant]')
    .alias('st', 'sales')
    .default('st', 0)
    .describe('st', 'Number of sales txns to perform')
    .alias('sd', 'salesDuration')
    .default('sd', 15)
    .describe('sd', 'Duration between sales in minutes')
    .alias('rt', 'receivings')
    .default('rt', 0)
    .describe('rt', 'Number of receivings txns to perform')
    .alias('rd', 'receiveDuration')
    .default('rd', 180)
    .describe('rd', 'Duration between receivings in minutes')
    .alias('d', 'debug')
    .default('d', 0)
    .help('h')
    .alias('h', 'help')
    .argv;

var txnCreationParams = {
    clientType: argv.cl,
    appType: argv.appType,
    sales: argv.st,
    receivings: argv.rt,
    debug: argv.d,
    salesDuration: argv.sd,
    receiveDuration: argv.rd
};
var chalk = require('chalk');
var sleep = require('sleep');
var moment = require('moment');

var profitGuruTxnsMaker = require('./profitGuruTxnsMaker.js');
profitGuruTxnsMaker = new profitGuruTxnsMaker();

var log = console.log;
//Lets set up the ulimit so that we can create more number elements lets say more than 1k
var startTime = moment();
var profitGuruEvents = profitGuruTxnsMaker.startStandAloneProfitGuruTxns(txnCreationParams);

function tellMeDurationUTook() {
    var currentTimeFromWeb = moment();
    var timeTaken = moment.duration(currentTimeFromWeb.diff(startTime)).humanize();
    log(chalk.green('It took ', timeTaken, ' To complete the task, Have a good Day!!', JSON.stringify(txnCreationParams)));

}
profitGuruEvents.on('profitGuruTxnsMakerDone', function() {
    tellMeDurationUTook();
    log(chalk.red('profitGuruTxnsMakerDone, U can kill me or I will commit suicide in another 10 Secs'));
    sleep.usleep(10000000);
    process.exit(0);
});