/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */

var requestAsPromised = require("supertest-as-promised");
var fs = require('fs');
var assert = require('assert');
var jsonfile = require('jsonfile');
var q = require('q');
var request = require('supertest');

var chalk = require('chalk');
var log = console.log;
var sleep; // = require('sleep');
var nano = require('nano');
var nanoPrms = require('nano-promises');
var moment = require('moment');
var chance = require('chance')();

var defaultDailyLikeliHood = {
    salesTxn: 50,
    receiveTxn: 25
};

var setUpMachineTime = require('./setUp.js')(true);

var extend = require('util')._extend;
var authenticatedUserRequest;

var profitGuruTxnsMaker = function(profitGuruNodeServer, profitGuruFaker, dailyLikeliHoodParams) {
    _self = this;
    var dailyLikeliHood = dailyLikeliHoodParams === undefined ? defaultDailyLikeliHood : dailyLikeliHoodParams;
    var shouldIDoThis;
    var isTimeMachineSet = false;
    var profitGuruConfig;
    var couchClient;
    var dbUrl;
    var itemList;
    var supplierList;
    var customerList;
    var loginData = {
        username: "admin",
        password: "profitGuru",
        clientType: "DeskTopApp"
    };
    var add2CartParams = {
        item: ''
    };

    var txnCreationParams;
    var commonTestUtils;

    function initAndStart(authenticatedUserRequestParam) {

        setUpCouchClient().then(function(resp) {
            if (itemList.length >= 1) {
                // getTrialLicence().then(function(licenceResp) {
                // 	console.log('Calling createAllElements');
                // 	createTxnsInBatches();
                // });
                commonTestUtils = require('../test/common/commonUtils.js');
                var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
                if (!authenticatedUserRequest) {
                    commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(profitGuruNodeServer, newEmployee4CreateNLogin).then(function(result) {
                        authenticatedUserRequest = result.authenticatedRequest;
                        createTxnsInBatches();
                    });
                } else {
                    authenticatedUserRequest = authenticatedUserRequestParam;
                    createTxnsInBatches();
                }

            } else {
                log(chalk.red('Without Items, Trasactions are not possible, first create them using runProfitGuruElementsDataCreator.js'));
                process.exit(0);
            }
        });
    }
    this.start = function(Params, profitGuruNodeServerParam, profitGuruFakerParam, authenticatedUserRequestParam, isTimeMachineSetParam) {

        isTimeMachineSet = isTimeMachineSetParam ? isTimeMachineSetParam : true;
        profitGuruNodeServer = profitGuruNodeServerParam;
        profitGuruFaker = profitGuruFakerParam;
        log(chalk.green('profitGuruTxnsMaker:received start Event', Params));
        txnCreationParams = extend(Params, {});

        if (txnCreationParams.debug) {
            sleep = require('sleep');
        }
        initAndStart(authenticatedUserRequestParam);
    };
    this.startStandAloneProfitGuruTxns = function(Params) {
        txnCreationParams = Params;
        if (txnCreationParams.debug) {
            sleep = require('sleep');
        }

        if (!profitGuruFaker) {
            profitGuruFaker = require('../test/common/profitGuruFaker.js');
        }

        //Make use of Sockets to create the Data on other than host machines

        if (!profitGuruNodeServer)
            profitGuruNodeServer = require('../bin/PGServerJs.js', {
                bustCache: true
            });

        profitGuruNodeServer.on("PGuruNodeServerStarted", function() {
            log(chalk.green('received PGuruNodeServerStarted'));
            initAndStart();

        });
        return profitGuruNodeServer;
    };

    // function getTrialLicence() {
    //     return new Promise(function(resolve, reject) {
    //         requestAsPromised(profitGuruNodeServer)
    //             .get('/amIAuthorized2Connect?clientType=' + txnCreationParams.clientType + '&appType=' + txnCreationParams.appType)
    //             .then(function(result) {
    //                 if (result.body.isAuthorized === true) {
    //                     //log(chalk.red(result.body));
    //                     resolve(result.body.isAuthorized);
    //                 } else {
    //                     reject(result.body.isAuthorized);
    //                 }
    //             });
    //     });
    // }

    function setUpCouchClient() {
        return new Promise(function(resolve, reject) {
            var appConfig = require('../config/configProfitGuruNodeServer.js');
            const configState = require('../common/configState');

            configState.getAppConfig().then(function(configData) {
                profitGuruConfig = configData;
                dbUrl = appConfig.getCouchUrl(profitGuruConfig.localCouch);
                couchClientTxnsMaker = nanoPrms(nano(dbUrl)).db.use('pg_collection_' + process.env.APP_TYPE + '_maindb');
                var initTxnResources = [getAllProfitGuruItems(), getAllProfitGuruSuppliers(), getAllProfitGuruCustomers()];
                q.all(initTxnResources).done(function(response) {
                    console.log('Done initTxnResources');
                    resolve(response);
                });
            }).catch(function(error) {
                console.log(error);
                reject(error);
            });

        });
    }

    function getAllProfitGuruItems() {
        return couchClientTxnsMaker.view('all_items_data', 'all_items_data').then(function(result) {
            itemList = result[0].rows;
            log(chalk.yellow('Got  ' + result[0].total_rows + ' Items to make Sales Txns'));
            if (txnCreationParams.debug)
                sleep.usleep(2000000);

        });
    }

    function getAllProfitGuruCustomers() {
        return couchClientTxnsMaker.view('all_customers_data', 'all_customers_data').then(function(result) {
            customerList = result[0].rows;
            log(chalk.yellow('Got  ' + result[0].total_rows + ' Customers to make Sales Txns'));
            if (txnCreationParams.debug)
                sleep.usleep(2000000);
        });
    }

    function getAllProfitGuruSuppliers() {
        return couchClientTxnsMaker.view('all_suppliers_data', 'all_suppliers_data').then(function(result) {
            supplierList = result[0].rows;
            log(chalk.yellow('Got  ' + result[0].total_rows + ' Suppliers to make Receivings Txns'));
            if (txnCreationParams.debug)
                sleep.usleep(2000000);
        });
    }

    function createTxnsInBatches() {
        var noOfTxns2Make = 0;
        var batchSize = 1;
        console.log('create Txns ', JSON.stringify(txnCreationParams));

        if (txnCreationParams.sales > 0) {
            noOfTxns2Make = txnCreationParams.sales % batchSize;
            if (noOfTxns2Make === 0) {
                noOfTxns2Make = batchSize;
                txnCreationParams.sales = txnCreationParams.sales - batchSize;
            } else {
                txnCreationParams.sales = txnCreationParams.sales - noOfTxns2Make;
            }

            if (noOfTxns2Make > 0) {
                log(chalk.yellow('Adding ' + noOfTxns2Make + ' Sales Txns'));
                if (txnCreationParams.debug)
                    sleep.usleep(2000000);

                if (txnCreationParams.isApplyRandomness) {
                    shouldIDoThis = chance.bool({
                        likelihood: dailyLikeliHood.salesTxn
                    });
                } else {
                    shouldIDoThis = true;
                }

                if (shouldIDoThis || !isTimeMachineSet) {
                    makeBatchSales(noOfTxns2Make).then(function(resp) {
                        log(chalk.green('Added ' + noOfTxns2Make + ' Sales Txns'));
                        log(chalk.cyan('Remaining ' + txnCreationParams.sales + ' Sales Txns more to make'));
                        //sleep.usleep(2000000);
                        createTxnsInBatches();
                    });
                } else {
                    log(chalk.bgMagenta('Skipping this SaleTxn'));
                    if (txnCreationParams.debug)
                        sleep.usleep(2000000);

                    createTxnsInBatches();
                }
            } else {
                return;
            }

        } else if (txnCreationParams.receivings > 0) {
            noOfTxns2Make = txnCreationParams.receivings % batchSize;
            if (noOfTxns2Make === 0) {
                noOfTxns2Make = batchSize;
                txnCreationParams.receivings = txnCreationParams.receivings - batchSize;
            } else {
                txnCreationParams.receivings = txnCreationParams.receivings - noOfTxns2Make;
            }

            if (noOfTxns2Make > 0) {
                log(chalk.yellow('Adding ' + noOfTxns2Make + ' Receivings Txns'));
                if (txnCreationParams.debug)
                    sleep.usleep(2000000);
                if (txnCreationParams.isApplyRandomness) {
                    shouldIDoThis = chance.bool({
                        likelihood: dailyLikeliHood.receiveTxn
                    });
                } else {
                    shouldIDoThis = true;
                }

                if (shouldIDoThis || !isTimeMachineSet) {
                    makeBatchReceivings(noOfTxns2Make).then(function(resp) {
                        log(chalk.green('Added ' + noOfTxns2Make + ' Receivings Txns'));
                        log(chalk.cyan('Remaining ' + txnCreationParams.receivings + ' Receivings Txns more to make'));
                        //sleep.usleep(2000000);
                        createTxnsInBatches();
                    });
                } else {
                    log(chalk.bgMagenta('Skipping this Receivings Txn'));
                    if (txnCreationParams.debug)
                        sleep.usleep(2000000);
                    createTxnsInBatches();
                }
            }
        } else {

            log(chalk.magenta('DONE: executed All the Sales Txns: Emitting profitGuruTxnsMakerDone'));
            if (txnCreationParams.debug)
                sleep.usleep(2000000);

            profitGuruNodeServer.emit('profitGuruTxnsMakerDone');
            return;
        }

    }

    function addItem2SalesCart(add2CartParams) {
        return new Promise(function(resolve, reject) {
            return authenticatedUserRequest
                .post('/sales/additemRestApi')
                .send(add2CartParams)
                .expect(200).then(function(resp) {
                    resolve(resp);
                });
        });
    }

    function addItem2ReceivingsCart(add2CartParams) {
        return new Promise(function(resolve, reject) {
            return authenticatedUserRequest
                .put('/receivings/additem2ReceivingsRestApi')
                .send(add2CartParams)
                .expect(200).then(function(resp) {
                    resolve(resp);
                });
        });
    }

    var paymentParams = {
        payment_type: 'cash',
        amount_tendered: ''
    };

    var recvPaymentParams = {
        payment_type: 'cash',
        amount_tendered: '',
        comment: ' No comment'
    };
    var add2Supplier2RecParams = {
        supplier_id: ''
    };
    var add2Customer2SaleParams = {
        customer_id: ''
    };

    function addCustmer2Sale(request) {

        return new Promise(function(resolve, reject) {
            var aCustomer = customerList[getRandomInt(0, customerList.length)];

            log(chalk.yellow('Adding Customer: ' + aCustomer.key.full_name + ' to Sale'));
            if (txnCreationParams.debug)
                sleep.usleep(2000000);
            add2Customer2SaleParams.customer_id = aCustomer.id.substring(9); //customer_

            return authenticatedUserRequest
                .post('/sales/addCustomer2SaleRestApi')
                .send(add2Customer2SaleParams)
                .expect(200).then(function(res) {
                    resolve(res);
                }).catch(console.log);;
        });
    }

    function addSupplier2Receivings() {
        return new Promise(function(resolve, reject) {
            var aSupplier = supplierList[getRandomInt(0, supplierList.length)];
            add2Supplier2RecParams.supplier_id = aSupplier.id.substring(9); //supplier_

            log(chalk.yellow('Adding Supplier: ' + aSupplier.key.company_name + ' to Sale'));
            if (txnCreationParams.debug)
                sleep.usleep(2000000);

            return authenticatedUserRequest
                .put('/receivings/addSupplier2RecRestApi')
                .send(add2Customer2SaleParams)
                .expect(200).then(function(res) {
                    resolve(res);
                });
        });
    }

    function completeReceivings() {
        return new Promise(function(resolve, reject) {
            return authenticatedUserRequest
                .put('/receivings/completeReceiveRestApi')
                .send(recvPaymentParams)
                .expect(200).then(function(res) {
                    resolve(res);
                });
        });
    }

    function completeSale() {
        return new Promise(function(resolve, reject) {
            return authenticatedUserRequest
                .post('/sales/completeSaleRestApi')
                .send(paymentParams)
                .expect(200).then(function(res) {
                    resolve(res);
                });
        });
    }

    function makePaymentAndCompleteSale() {
        return new Promise(function(resolve, reject) {

            return authenticatedUserRequest
                .post('/sales/add_paymentRestApi')
                .send(paymentParams)
                .expect(200).then(function() {
                    completeSale().then(function(res) {
                        resolve(res);
                    });
                });
        });
    }

    function makeBatchSales(noOfTxns2Make) {

        var txnsList = [];
        for (i = 0; i < noOfTxns2Make; ++i) {
            if (isTimeMachineSet)
                txnsList.push(setTimeAndMakeSale());
            else
                txnsList.push(MakeASale());
        }
        return q.all(txnsList);
    }

    function makeBatchReceivings(noOfTxns2Make) {

        var txnsList = [];
        for (i = 0; i < noOfTxns2Make; ++i) {
            txnsList.push(MakeAReceiving());
        }
        return q.all(txnsList);
    }

    function getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min)) + min;
    }

    function MakeAReceiving() {
        return new Promise(function(resolve, reject) {

            var add2RCartItemsList = [];

            var noOfItems2Add = getRandomInt(1, 7);
            var totalCostPrice = 0.0;

            for (i = 0; i < noOfItems2Add; ++i) {
                var aItem = itemList[getRandomInt(0, itemList.length)];
                totalCostPrice += parseFloat(aItem.key.cost_price);
                add2CartParams.item = aItem.id.substring(5); //item_
                add2RCartItemsList.push(add2CartParams);
            }

            recvPaymentParams.amount_tendered = totalCostPrice;
            //Adding Suppliers

            addItem2ReceiveCartSequentially(add2RCartItemsList, 0).then(function(resultist) {
                log(chalk.green('Added ' + noOfItems2Add + ' to Cart'));
                if (txnCreationParams.debug)
                    sleep.usleep(2000000);

                return addSupplier2Receivings();
            }).then(function() {
                completeReceivings().then(function() {
                    resolve(true);
                });

            });
        });
    }

    //Otherwise we will have session cuncurrency error from session store by adding the Items to cart in parallel.
    function addItem2ReceiveCartSequentially(add2RCartItemsList, index) {
        return new Promise(function(resolve, reject) {
            if (index >= add2RCartItemsList.length) {
                resolve('success');
            } else {
                resolve(addItem2ReceivingsCart(add2RCartItemsList[index]).then(function(resp) {
                    return addItem2ReceiveCartSequentially(add2RCartItemsList, index + 1);
                }).catch(function(err) {
                    logger.error(err);
                    return Promise.reject(err);
                }));
            }
        });
    }

    function isAddCustmer2Sale(noOfItems2Add) {
        return getRandomInt(0, 2);
    }

    function setTimeAndMakeSale() {
        return new Promise(function(resolve, reject) {
            var today = moment(new Date());
            var nextSaleTime = moment(new Date());
            nextSaleTime.add(txnCreationParams.salesDuration, 'minutes');
            if (txnCreationParams.debug) {
                log(chalk.yellow('Adding  ' + txnCreationParams.salesDuration + ' Min to CurrentTime'));
                log(chalk.cyan('CuurentTime: ', today.toString(), ' nextSaleTime: ', nextSaleTime.toString()));
                sleep.usleep(2000000);
            }

            // setUpMachineTime.clock.set(nextSaleTime.unix().toString()).then(function(resp) {
            setUpMachineTime.clock.set(nextSaleTime).then(function(resp) {
                MakeASale().then(function(resp) {
                    resolve(resp);
                });
            });

        });
    }

    function MakeASale() {

        return new Promise(function(resolve, reject) {
            var txnCreatePromiseList = [];
            var add2CartItemsList = [];
            var noOfItems2Add = getRandomInt(1, 7);
            var totalRetailPrice = 0.0;

            for (i = 0; i < noOfItems2Add; ++i) {
                var aItem = itemList[getRandomInt(0, itemList.length)];
                totalRetailPrice += aItem.key.unit_price;
                add2CartParams.item = parseInt(aItem.id.substring(5)); //item_
                add2CartItemsList.push(add2CartParams);
            }

            paymentParams.amount_tendered = parseFloat(totalRetailPrice);
            addItem2SalesCartSequentially(add2CartItemsList, 0).then(function() {
                log(chalk.green('Added ' + noOfItems2Add + ' to Cart'));

                if (isAddCustmer2Sale()) {
                    return addCustmer2Sale();
                } else {
                    return Promise.resolve();
                }
            }).then(function() {
                return makePaymentAndCompleteSale().then(function() {
                    resolve(true);
                });
            });
        });
    }

    //Otherwise we will have session cuncurrency error from session store by adding the Items to cart in parallel.
    function addItem2SalesCartSequentially(add2CartItemsList, index) {
        return new Promise(function(resolve, reject) {
            if (index >= add2CartItemsList.length) {
                resolve('success');
            } else {
                resolve(addItem2SalesCart(add2CartItemsList[index]).then(function(resp) {
                    return addItem2SalesCartSequentially(add2CartItemsList, index + 1);
                }).catch(function(err) {
                    logger.error(err);
                    return Promise.reject(err);
                }));
            }
        });
    }
};

module.exports = profitGuruTxnsMaker;