/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */

var requestAsPromised = require("supertest-as-promised");
var fs = require('fs');
var assert = require('assert');
var jsonfile = require('jsonfile');
var q = require('q');
var request = require('supertest');
var BPromise = require("bluebird");
var chalk = require('chalk');
var log = console.log;
var sleep;
var chance = require('chance')();
var commonTestUtils;

var defaultDailyLikeliHood = {
    customers: 70,
    suppliers: 2,
    items: 15,
    employees: 1,
};

var profitGuruDataCreator = function(profitGuruNodeServer, profitGuruFaker, dailyLikeliHoodParams) {
    var authenticatedUserRequest;

    var dailyLikeliHood = dailyLikeliHoodParams === undefined ? defaultDailyLikeliHood : dailyLikeliHoodParams;
    var shouldIDoThis;
    var loginData = {
        username: "admin",
        password: "profitGuru",
        clientType: "DeskTopApp"
    };

    var profitGuruFakerExt = require('../test/common/profitGuruFakerExt.js');

    var dataCreationParams;
    var isTimeMachineSet = false;
    var initShop = true;
    this.start = function(Params, profitGuruNodeServerParam, profitGuruFakerParam, authenticatedUserRequestParam, isTimeMachineSetParam) {
        commonTestUtils = require('../test/common/commonUtils.js');
        isTimeMachineSet = isTimeMachineSetParam ? isTimeMachineSetParam : true;
        profitGuruNodeServer = profitGuruNodeServerParam;
        authenticatedUserRequest = authenticatedUserRequestParam;
        profitGuruFaker = profitGuruFakerParam;

        dataCreationParams = Params;
        //Because sleep with PM2 doesn't work'
        if (dataCreationParams.debug) {
            sleep = require('sleep');
        }

        log(chalk.green('profitGuruTxnsMaker:received start Event', Params));

        //would be automatically applied in createExpressUserCouchNewUserAuthenticatedRequest
        // getTrialLicence().then(function(licenceResp) {
        console.log('Calling createAllInElementsInBatches');
        return createGlobalConfigs().then(function(resp) {
            createAllInElementsInBatches();
        });
        // });
    };

    this.startStandAloneProfitGuruDataCreation = function(Params) {
        commonTestUtils = require('../test/common/commonUtils.js');
        dataCreationParams = Params;

        //Because sleep with PM2 doesn't work'
        if (dataCreationParams.debug) {
            sleep = require('sleep');
        }

        if (!profitGuruFaker) {
            profitGuruFaker = require('../test/common/profitGuruFaker.js');
        }

        //Make use of Sockets to create the Data on other than host machines

        if (!profitGuruNodeServer) {
            profitGuruNodeServer = require('../bin/PGServerJs.js', {
                bustCache: true
            });
        }

        profitGuruNodeServer.on("PGuruNodeServerStarted", function() {
            log(chalk.green('received PGuruNodeServerStarted'));
            ////would be automatically applied in createExpressUserCouchNewUserAuthenticatedRequest
            //   getTrialLicence().then(function(licenceResp) {
            console.log('Calling createAllElements');
            var newEmployee4CreateNLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
            commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(profitGuruNodeServer, newEmployee4CreateNLogin).then(function(result) {
                authenticatedUserRequest = result.authenticatedRequest;
                return createGlobalConfigs();
            }).then(function(resp) {
                createAllInElementsInBatches();
            });
            //            });

        });

        return profitGuruNodeServer;

    };

    function createGlobalConfigs() {
        return Promise.all([commonTestUtils.createGlobalConfigs(5), commonTestUtils.getPeople(5, 'supplier')]);
    }

    function createAllInElementsInBatches() {
        var elementUnits2Create = 0;
        var batchSize = 1; //Some random prime less than 100 
        //more than the gives error to handle simultanious txns
        console.log('createAllElements ', JSON.stringify(dataCreationParams));

        if (dataCreationParams.customers > 0) {
            elementUnits2Create = dataCreationParams.customers % batchSize;
            if (elementUnits2Create === 0) {
                elementUnits2Create = batchSize;
                dataCreationParams.customers = dataCreationParams.customers - batchSize;
            } else {
                dataCreationParams.customers = dataCreationParams.customers - elementUnits2Create;
            }

            if (elementUnits2Create > 0) {
                log(chalk.yellow('Adding ' + elementUnits2Create + ' Customers'));

                if (dataCreationParams.isApplyRandomness) {
                    shouldIDoThis = chance.bool({
                        likelihood: dailyLikeliHood.customers
                    });
                } else {
                    shouldIDoThis = true;
                }

                if (shouldIDoThis || !isTimeMachineSet || initShop) {
                    createCustomers(elementUnits2Create).then(function(resp) {
                        log(chalk.green('Added ' + elementUnits2Create + ' Customers'));
                        log(chalk.cyan('Remaing ' + dataCreationParams.customers + ' Customers more to Add'));
                        if (dataCreationParams.debug)
                            sleep.usleep(2000000);
                        createAllInElementsInBatches();
                    });
                } else {
                    log(chalk.bgMagenta('Skipping this Adding Customers'));
                    if (dataCreationParams.debug)
                        sleep.usleep(2000000);
                    createAllInElementsInBatches();
                }
            } else {
                return;
            }
        } else if (dataCreationParams.suppliers > 0) {
            elementUnits2Create = dataCreationParams.suppliers % batchSize;
            if (elementUnits2Create === 0) {
                elementUnits2Create = batchSize;
                dataCreationParams.suppliers = dataCreationParams.suppliers - batchSize;
            } else {
                dataCreationParams.suppliers = dataCreationParams.suppliers - elementUnits2Create;
            }

            if (elementUnits2Create > 0) {
                log(chalk.yellow('Adding ' + elementUnits2Create + ' suppliers'));

                if (dataCreationParams.isApplyRandomness) {
                    shouldIDoThis = chance.bool({
                        likelihood: dailyLikeliHood.suppliers
                    });
                } else {
                    shouldIDoThis = true;
                }
                if (shouldIDoThis || !isTimeMachineSet || initShop) {
                    createSuppliers(elementUnits2Create).then(function(resp) {
                        log(chalk.green('Added ' + elementUnits2Create + ' suppliers'));
                        log(chalk.cyan('Remaing ' + dataCreationParams.suppliers + ' suppliers more to Add'));
                        if (dataCreationParams.debug)
                            sleep.usleep(2000000);
                        createAllInElementsInBatches();
                    });
                } else {
                    log(chalk.bgMagenta('Skipping this Adding suppliers'));
                    if (dataCreationParams.debug)
                        sleep.usleep(2000000);
                    createAllInElementsInBatches();
                }
            } else {
                return;
            }

        } else if (dataCreationParams.employees > 0) {
            elementUnits2Create = dataCreationParams.employees % batchSize;
            if (elementUnits2Create === 0) {
                elementUnits2Create = batchSize;
                dataCreationParams.employees = dataCreationParams.employees - batchSize;
            } else {
                dataCreationParams.employees = dataCreationParams.employees - elementUnits2Create;
            }

            if (elementUnits2Create > 0) {
                log(chalk.yellow('Adding ' + elementUnits2Create + ' employees'));
                if (dataCreationParams.isApplyRandomness) {
                    shouldIDoThis = chance.bool({
                        likelihood: dailyLikeliHood.suppliers
                    });
                } else {
                    shouldIDoThis = true;
                }
                if (shouldIDoThis || !isTimeMachineSet || initShop) {
                    createEmployees(elementUnits2Create).then(function(resp) {
                        log(chalk.green('Added ' + elementUnits2Create + ' employees'));
                        log(chalk.cyan('Remaing ' + dataCreationParams.employees + ' employees more to Add'));
                        if (dataCreationParams.debug)
                            sleep.usleep(2000000);
                        createAllInElementsInBatches();
                    });
                } else {
                    log(chalk.bgMagenta('Skipping this Adding employees'));
                    if (dataCreationParams.debug)
                        sleep.usleep(2000000);
                    createAllInElementsInBatches();
                }
            } else {
                return;
            }

        } else if (dataCreationParams.items > 0) {
            elementUnits2Create = dataCreationParams.items % batchSize;
            if (elementUnits2Create === 0) {
                elementUnits2Create = batchSize;
                dataCreationParams.items = dataCreationParams.items - batchSize;
            } else {
                dataCreationParams.items = dataCreationParams.items - elementUnits2Create;
            }

            if (elementUnits2Create > 0) {
                log(chalk.yellow('Adding ' + elementUnits2Create + ' items'));

                if (dataCreationParams.isApplyRandomness) {
                    shouldIDoThis = chance.bool({
                        likelihood: dailyLikeliHood.suppliers
                    });
                } else {
                    shouldIDoThis = true;
                }

                if (shouldIDoThis || !isTimeMachineSet || initShop) {
                    createItems(elementUnits2Create).then(function(resp) {
                        log(chalk.green('Added ' + elementUnits2Create + ' items'));
                        log(chalk.cyan('Remaing ' + dataCreationParams.items + ' items more to Add'));
                        if (dataCreationParams.debug)
                            sleep.usleep(2000000);
                        createAllInElementsInBatches();
                    });
                } else {
                    log(chalk.bgMagenta('Skipping this Adding Items'));
                    if (dataCreationParams.debug)
                        sleep.usleep(2000000);
                    createAllInElementsInBatches();
                }
            } else {
                return;
            }
        } else {
            log(chalk.green('Emitting profitGuruDataCreatorDone'));
            if (dataCreationParams.debug)
                sleep.usleep(2000000);
            if (initShop) {
                initShop = false;
            }
            profitGuruNodeServer.emit('profitGuruDataCreatorDone');
            return;
        }

    }

    // function createAuthenticatedRequest(createElementPromise) {
    //     return new Promise(function(resolve,reject){
    //     var authenticatedRequest = request.agent(profitGuruNodeServer);
    //     authenticatedRequest
    //         .get('/profitGuruRestSvc_' + dataCreationParams.appType + '/index.php/login/loginRestApi')
    //         .set('Connection', 'keep-alive')
    //         .query(loginData)
    //         .end(function(error, response) {
    //             if (error) {
    //                 reject(error);
    //             }
    //             createElementPromise(authenticatedRequest).then(function(resp) {
    //                 resolve(resp);
    //             }).catch(function(reason) {
    //                 reject(reason);
    //             });
    //         });

    //     });
    // }

    // function getTrialLicence() {
    //     return new Promise(function(resolve,reject){
    //     requestAsPromised(profitGuruNodeServer)
    //         .get('/amIAuthorized2Connect?clientType=' + dataCreationParams.clientType + '&appType=' + dataCreationParams.appType)
    //         .then(function(result) {
    //             if (result.body.isAuthorized === true) {
    //                 //log(chalk.red(result.body));
    //                 resolve(result.body.isAuthorized);
    //             } else {
    //                 reject(result.body.isAuthorized);
    //             }
    //         });
    //     });
    // }

    function addCustomer() {

        var aCustomer = {
            customer: profitGuruFaker.getFakerCustomer()
        };

        return authenticatedUserRequest
            .post('/customers/create')
            .send(aCustomer)
            .expect(200);

    }

    function createCustomers(NoOfCustomers2Create) {
        var customerCreatePromiseList = [];
        console.log('Creating ' + NoOfCustomers2Create + ' Customers');
        for (i = 0; i < NoOfCustomers2Create; ++i) {

            customerCreatePromiseList.push(addCustomer());

        }

        return Promise.all(customerCreatePromiseList).then(function(resultist) {
            log(chalk.green('Done with ' + resultist.length + ' Customer creation'));
            return Promise.resolve(true);
        });

        // return BPromise.each(customerCreatePromiseList, function(result) {
        //     console.log(result);
        // }).then(function(resultist) {
        //     log(chalk.green('Done with ' + resultist.length + ' Customer creation'));

        //     //sleep.usleep(200000);
        //     //   return addCustomer();
        //     return Promise.resolve(true);
        // });
    }

    function addSupplier() {
        var aSupplier = {
            supplier: profitGuruFaker.getFakerSupplier()
        };

        return authenticatedUserRequest
            .post('/suppliers/create')
            .send(aSupplier)
            .expect(200);
    }

    function createSuppliers(NoOfSuppliers2Create) {
        return new Promise(function(resolve, reject) {

            var SuppliersCreatePromiseList = [];
            console.log('Creating ' + NoOfSuppliers2Create + ' Suppliers');
            for (i = 0; i < NoOfSuppliers2Create; ++i) {
                SuppliersCreatePromiseList.push(addSupplier());
            }

            return Promise.all(SuppliersCreatePromiseList).then(function(resultist) {
                log(chalk.green('Done with ' + resultist.length + ' Supplier creation'));
                resolve(true);
            });
        });

    }

    function addEmployee() {

        var newNodeUserOrEmployee = profitGuruFaker.getFakerExpressUserCouchEmployee();
        //console.log('Adding User/Employee:', newNodeUserOrEmployee);

        return authenticatedUserRequest
            .post('/employees')
            .send(newNodeUserOrEmployee);
        //removed expect(200) intentionally

    }

    function createEmployees(NoOfEmployees2Create) {
        return new Promise(function(resolve, reject) {
            var EmployeesPromiseList = [];
            console.log('Creating ' + NoOfEmployees2Create + ' Employees');
            for (i = 0; i < NoOfEmployees2Create; ++i) {
                EmployeesPromiseList.push(addEmployee());
            }

            return Promise.all(EmployeesPromiseList).then(function(resultist) {
                log(chalk.green('Done with ' + resultist.length + ' Employee creation'));
                resolve(true);
            });
        });
    }

    //TODO BK, Need to take care of adding different items
    //for restaurant, i,e prepared, bought outside etc

    async function addItem() {
        var anItem = {
            item: await profitGuruFakerExt.getFakerItem({
                bFillAll: true,
                bSerialized: false
            })
        };

        return authenticatedUserRequest
            .post('/items/create')
            .send(anItem)
            .expect(200);
    }

    function createItems(Items2Create) {
        return new Promise(function(resolve, reject) {

            var CreateItemsPromiseList = [];
            console.log('Creating ' + Items2Create + ' Items');
            for (i = 0; i < Items2Create; ++i) {
                CreateItemsPromiseList.push(addItem());
            }

            return Promise.all(CreateItemsPromiseList).then(function(resultist) {
                log(chalk.green('Done with ' + resultist.length + ' Item creation'));
                resolve(true);
            });

        });
    }

    //TODO Item Kits
};

module.exports = profitGuruDataCreator;