//Make Sure u run this with admin privilages on Windows
var argv = require('yargs')
    .usage('Usage: $0 -e <envirnment> -app <AppName> -p <platform> ')
    .alias('e', 'env')
    .describe('e', 'environment(development/production)')
    .choices('e', ['development', 'production'])
    .alias('a', 'app')
    .describe('a', 'Apptype to run (combo/retail/restaurant)')
    .default('a', 'retail')
    .alias('u', 'selfUpdate')
    .describe('u', 'software update')
    .alias('m', 'myself')
    .describe('m', 'Source Name')
    .default('m', 'PGServerJs')
    .help('h')
    .alias('h', 'help')
    .argv;

var shelljs = require('shelljs');

//if (!process.env.APP_TYPE) {
console.log('Env Apptype=', process.env.APP_TYPE);
process.env.APP_TYPE = argv.app;
//}
if (argv.selfUpdate) {
    process.env.enableSelfUpdate = argv.selfUpdate;
}
if (!process.env.MYSELF) {
    process.env.MYSELF = argv.myself;
}

console.log('selfUpdate=', process.env.enableSelfUpdate, ' AppType=', process.env.APP_TYPE);
var startWithUpdater = process.env.enableSelfUpdate && shelljs.test('-d', '../profitGuruUpdater');
var startCommand;

//On Builder these Links are created during build time
process.env.UpdaterDir = __dirname + '/../profitGuruUpdater';

//Lets marry PGServerJs  and profitGuruUpdater
if (!shelljs.test('-f', shelljs.pwd() + '/updater/updateConfig.js')) {
    console.log('ERROR:Can not find PGServerJs updater config');
    process.exit(1);
}
//Createing the profitGuruUpdater structure for integration
if (!shelljs.test('-d', shelljs.pwd() + '/../profitGuruUpdater/config')) {
    shelljs.mkdir(shelljs.pwd() + '/../profitGuruUpdater/config');
}
//softLink for update config file
//Make Sure u run this with admin privilages on Windows
shelljs.cp(shelljs.pwd() + '/updater/updateConfig.js', shelljs.pwd() + '/../profitGuruUpdater/config/updateConfig.js');

//softlink to point to cuurentLive PGServerJs
shelljs.rm('-rf', shelljs.pwd() + '/../profitGuruUpdater/installedServers/currentLive/PGServerJs')
shelljs.ln('-sf', shelljs.pwd(), shelljs.pwd() + '/../profitGuruUpdater/installedServers/currentLive/PGServerJs');