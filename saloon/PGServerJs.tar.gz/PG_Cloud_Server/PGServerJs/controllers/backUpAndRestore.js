var logger = require('../common/Logger');
var shelljs = require('shelljs');
var path = require('path');
var _self;
var couchdbBackupRestore = require('../couchdb-backup-restore');
var fs = require('fs');
var moment = require('moment');

var BackUpController = function() {
    _self = this;

    function getBackUpLocationDir(reason) {
        var now = moment().format('YYYY-MM-DD-HH-mm-ss-SSS');
        var currentBackUpLocation = now;
        if (!reason || reason === '') {
            reason = 'casual';
        }
        reason = reason.toLowerCase();

        switch (reason) {
            case 'b4_update':
                currentBackUpLocation = 'b4_update/' + now;
                break;
            case 'b4_restore':
                currentBackUpLocation = 'b4_restore/' + now;
                break;
            default:
                logger.info('Reason for BackUp Unknown');
        }
        return currentBackUpLocation;
    }

    this.takeBackUp = async function(backUpConfig) {
        backUpConfig.backUpLocation = path.resolve(backUpConfig.backUpBaseLocationDir + '/' + getBackUpLocationDir(backUpConfig.reason4Backup));

        try {
            if (shelljs.mkdir('-p', backUpConfig.backUpLocation).code === 0) {
                //Lets start the Back up
                logger.info('Back Up Started');
                await couchdbBackupRestore.backup(backUpConfig);
                logger.info('BackUp Done!!');
                return true;
            } else {
                throw 'Could Not Create backUp Location Folder';
            }
        } catch (error) {
            throw error;
        }
    };

    //Returns all the backups -> ordered by descending timeStamp
    this.getBackUpsList = async function(backUpBaseLocationDir) {

        try {
            var backupList = shelljs.ls('-d', backUpBaseLocationDir + '/**/*/');
            if (backupList.length > 0) {
                backupList = backupList.sort('-r').split('\n');
                backupList.splice(backupList.length - 1, 1);
            }

            return backupList;
        } catch (error) {
            throw error;
        }
    };

    this.restoreFromBackUp = async function(restoreConfig, maxRetries) {
        try {
            //take backup first
            await _self.takeBackUp(restoreConfig);
        } catch (error) {
            logger.error(error);
            logger.error('taking backup failed');
            throw 'taking backup failed';
        }

        try {
            await couchdbBackupRestore.restore(restoreConfig);
            logger.info('Restore Done!!');
            return true;
        } catch (error) {

            logger.error(error);
            let errMsg = 'Restore Failed';
            logger.error(errMsg);
            throw errMsg;
        }

    };

    this.changeDatabaseDir = function(params) {
        return couchdbBackupRestore.changeDatabaseDir(params);
    };

};
module.exports = new BackUpController();