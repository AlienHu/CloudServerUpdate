var Receivings = function() {
    var validator = require('validator');

    this.editItem = function(data) {
        let errMsg = '';
        var bIsValid = true;

        if (data.discountId) {
            if (validator.isNumeric(data.discountId + '')) {
                if (data.discountId === '0') {
                    delete data.discountId;
                }
            } else {
                errMsg += 'discount id should be numeric ';
                bIsValid = false;
            }
        }

        if (data.quantity === undefined || null) {
            errMsg += ' quantity is not defined';
            bIsValid = false;
        } else if (!validator.isFloat(data.quantity + '')) {
            errMsg += ' quantity should be numeric';
            bIsValid = false;
        }
        var isSellingPriceValid = false;
        if (data.sellingPrice === '') {
            isSellingPriceValid = true;
        } else if (validator.isFloat(data.sellingPrice + '')) {
            isSellingPriceValid = true;
        } else {
            isSellingPriceValid = false;
        }

        var isMRPValid = false;
        if (data.mrp === '') {
            isMRPValid = true;
        } else if (validator.isFloat(data.mrp + '')) {
            isMRPValid = true;
        } else {
            isMRPValid = false;
        }

        if (!(validator.isFloat(data.purchasePrice + '') && isSellingPriceValid && isMRPValid)) {
            errMsg += 'price should be numeric';
            bIsValid = false;
        }

        return {
            bIsValid: bIsValid,
            errMsg: errMsg
        };
    };

};

module.exports = new Receivings();