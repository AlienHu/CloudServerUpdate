var Sales = function() {
    var validator = require('validator');

    this.editItem = function(data, errMsg) {
        errMsg = '';
        var bIsValid = true;

        if (data.discountId) {
            if (validator.isNumeric(data.discount + '')) {
                if (data.discountId === '0') {
                    delete data.discountId;
                }
            } else {
                errMsg += 'discount id should be numeric ';
                bIsValid = false;
            }
        }

        if (data.quantity === undefined || null) {
            errMsg += ' quantity is not defined';
            bIsValid = false;
        } else if (!validator.isFloat(data.quantity + '')) {
            errMsg += ' quantity should be numeric';
            bIsValid = false;
        }

        if (!(validator.isFloat(data.price + ''))) {
            errMsg += 'price should be numeric';
            bIsValid = false;
        }

        return bIsValid;
    };

};

module.exports = new Sales();