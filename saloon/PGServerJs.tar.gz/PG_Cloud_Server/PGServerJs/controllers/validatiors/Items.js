"use strict";

let Items = function() {

    //RelaxTodo check if expiry date is a problem. With faker expiry moment doesn't work

    let _self = this;

    const couchDBUtils = require('../common/CouchDBUtils');
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const utils = require('../common/Utils');
    const logger = require('../../common/Logger');
    const validator = require('validator');
    const controllerLib = require('../libraries/itemsControllerLib');
    const ARRAY_LENGTH = utils.getArrayLength; //Example of a macro
    const ASSIGN_IF_TRUE = utils.assignIfTrue;
    const DELETE_IF_NO_VALUE = utils.deleteIfNoValue;
    const DELETE_KEY_IF_EXIST = utils.deleteKeyIfExist;
    const IS_EMPTY_OBJECT = utils.isEmptyObject;

    this.validateItemInfo = async function(itemData, invData, bUpdate) {
        let bValid = true;
        let errMsg = '';

        if (!IS_EMPTY_OBJECT(itemData.info)) {
            itemData.info.ItemType = ASSIGN_IF_TRUE(itemData.info.ItemType, controllerLib.ITEM_TYPE.Normal);
            itemData.info.reorderLevel = ASSIGN_IF_TRUE(itemData.info.reorderLevel, 0);
            DELETE_KEY_IF_EXIST("item_id", itemData.info);
            if (!controllerLib.ITEM_TYPE.hasOwnProperty(itemData.info.ItemType)) {
                logger.error('Invalid item type ' + itemData.info.ItemType);
                errMsg += ' Internal server error';
                bValid = false;
            }
            if (itemData.info.hasOwnProperty('supplier_id')) {
                if (!itemData.info.supplier_id) {
                    delete itemData.info.supplier_id;
                } else if (!validator.isNumeric(itemData.info.supplier_id + '')) {
                    errMsg += ' Invalid Supplier';
                    bValid = false;
                }
            }

            DELETE_KEY_IF_EXIST("discountId", itemData.info);
            DELETE_KEY_IF_EXIST("expiry", itemData.info);
        }

        for (let stockKey in itemData.batches) {
            let batch = itemData.batches[stockKey];

            if (!itemData.info.hasExpiryDate) {
                DELETE_KEY_IF_EXIST("expiry", batch);
            }

            let tempResp = _self.validateBatchInfo(batch, true, itemData.info.hasExpiryDate);
            bValid = bValid && tempResp.bValid;
            errMsg += tempResp.errMsg;
        }

        if (bValid) {
            try {
                bValid = await uniqueConstraint(itemData, invData, bUpdate);
                return bValid;
            } catch (error) {
                throw error;
            }
        } else {
            throw errMsg;
        }
    };

    this.validateBatchInfo = function(batch, bUpdate, bHasExpiryDate) {

        let errMsg = '';

        let bValid = true;

        if (bUpdate && !batch.stockKey) {
            bValid = false;
            errMsg += ' Internal Server Error';
            logger.error('stockKey is missing');
        }

        if (bHasExpiryDate && !batch.expiry) {
            bValid = false;
            errMsg += ' Expiry Date is required';
        } else if (batch.expiry) {
            if (!validator.isDate(batch.expiry)) {
                bValid = false
                errMsg += ' Expiry Date is invalid';
            }
        }

        if (!batch.locationId) {
            batch.locationId = 1; //RelaxTodo keep either locationId or location_id
        }
        if (!batch.location_id) {
            batch.location_id = 1; //RelaxTodo keep either locationId or location_id
        }

        DELETE_KEY_IF_EXIST("employeeId", batch);
        DELETE_KEY_IF_EXIST("item_id", batch);
        DELETE_KEY_IF_EXIST("quantity", batch);
        DELETE_IF_NO_VALUE("discountId", batch);

        return {
            bValid: bValid,
            errMsg: errMsg
        };
    }

    //RelaxTodo: Add uniqueDetails as per the items.md
    //RelaxTodoRepeat: This function is repetitive with maindbViews.js uid view
    //RelaxTodo: batchId should be unique
    function getUniqueNumbers(invData) {
        let uniqueNumbers = [];

        if (invData) {
            for (let stockKey in invData.stock) {
                let details = invData.stock[stockKey].uniqueDetails;
                for (let detailKey in details) {
                    let detailInfo = details[detailKey];
                    if (detailInfo.info.serialnumber) {
                        uniqueNumbers.push(detailInfo.info.serialnumber);
                    }
                    Array.prototype.push.apply(uniqueNumbers, detailInfo.info.imeiNumbers);
                }
            }
        }

        return uniqueNumbers;
    }

    this.validateUniqueDetails = async function(invData) {
        let uniqueNumbers = getUniqueNumbers(invData);
        if (uniqueNumbers.length) {
            return await uniqueIMEIDetails(uniqueNumbers);
        }

        return true;
    }

    this.validateUniqueNumbers = async function(uniqueNumbers) {
        if (uniqueNumbers.length) {
            return await uniqueIMEIDetails(uniqueNumbers);
        }
        return true;
    }
    this.validateBulkUniqueNumbers = async function(uniqueNumbers) {
        let resp = false;
        let serialnumbers = [];
        let imeiNumbers = [];
        let errMsg = "";
        for (let i = 0; i < uniqueNumbers.length; i++) {
            if (uniqueNumbers[i].serialnumber) {
                if (!serialnumbers[uniqueNumbers[i].serialnumber]) {
                    serialnumbers[uniqueNumbers[i].serialnumber] = 1;
                } else {
                    serialnumbers[uniqueNumbers[i].serialnumber]++;
                    errMsg += uniqueNumbers[i].serialnumber + ',';
                }
            }
            for (let j = 0; j < uniqueNumbers[i].imeiNumbers.length; j++) {
                if (!imeiNumbers[uniqueNumbers[i].imeiNumbers[j]]) {
                    imeiNumbers[uniqueNumbers[i].imeiNumbers[j]] = 1;
                } else {
                    imeiNumbers[uniqueNumbers[i].imeiNumbers[j]]++;
                    errMsg += uniqueNumbers[i].imeiNumbers[j] + ',';
                }
            }
            if (errMsg) {
                errMsg = errMsg.substring(0, errMsg.length - 1);
                errMsg = "Enter Unique Serial/IMEI Numbers. " + errMsg;
                throw errMsg;
            }
            var uniqueNumbersArry = uniqueNumbers[i].imeiNumbers;
            uniqueNumbersArry.push(uniqueNumbers[i].serialnumber);
            resp = await _self.validateUniqueNumbers(uniqueNumbersArry);
        }
        return resp;
    }

    async function uniqueConstraint(itemData, invData, bUpdate) {
        try {
            await uniqueItemDetails(itemData, bUpdate);
            await _self.validateUniqueDetails(invData)
        } catch (error) {
            throw error;
        }

        return true;
    }

    async function uniqueItemDetails(data, bUpdate) {
        //RelaxTodoRepeat Make the below key generation common code
        let key = data.info.name + '-' + data.info.categoryId;
        if (data.info.item_number) {
            key += '-' + data.info.item_number;
        }

        let queryResp = {};
        try {
            queryResp = await couchDBUtils.getView('all_items_data', 'item-hash', {
                key: key
            }, mainDBInstance);
        } catch (error) {
            throw "Unique Validation Failed";
        }

        let bUnique = true;
        if (bUpdate) {
            if (queryResp.length > 1) { //Unlikely. This condition means the unique constraint is already broken
                bUnique = false;
            } else if (queryResp.length === 1) {
                if (queryResp[0].value !== data.item_id) {
                    bUnique = false;
                }
            }
        } else if (queryResp.length !== 0) {
            bUnique = false;
        }

        if (!bUnique) {
            let errMsg = "Enter Unique Details. Item with " + data.info.name + " ";
            if (data.info.item_number) {
                errMsg += " Batch Number " + data.info.item_number + " ";
            }
            errMsg += "already exists in this category";
            throw errMsg;
        }

        return true;
    }

    /**
     *  RelaxTodo Store maxBatchId in item document and pass it everytime
     *      initialStock
     *      purchase        
     *  RelaxTodo autoIncrement for batch also. With this we can edit the batch id also.
     *  RelaxTodo locks - add locks whenever unique constraint is required
     *  RelaxTodoOld If IMEI Numbers are allowed to add directly during sale, it is not handled currently
     */

    async function uniqueIMEIDetails(uniqueNumbers) {

        let uniqueCount = {};
        let errMsg = '';
        for (let i = 0; i < uniqueNumbers.length; i++) {
            if (!uniqueCount[uniqueNumbers[i]]) {
                uniqueCount[uniqueNumbers[i]] = 1;
            } else {
                uniqueCount[uniqueNumbers[i]]++;
                errMsg += uniqueNumbers[i] + ',';
            }
        }

        if (errMsg) {
            errMsg = errMsg.substring(0, errMsg.length - 1);
            errMsg = "Enter Unique Serial/IMEI Numbers. " + errMsg;
            throw errMsg;
        }

        let queryResp = {};
        try {
            queryResp = await couchDBUtils.getView('all_inventory_data', 'uids', {
                keys: uniqueNumbers
            }, mainDBInstance);
        } catch (error) {
            throw "Unique Serial/IMEI Numbers Validation Failed";
        }

        if (queryResp.length !== 0) {
            errMsg = 'Enter Unique Serial/IMEI Numbers. ';
            for (let i = 0; i < queryResp.length; i++) {
                errMsg += queryResp[i].key + ' ';
            }
            errMsg += 'already exists.'

            throw errMsg;
        }

        return true;
    }

};

module.exports = new Items();