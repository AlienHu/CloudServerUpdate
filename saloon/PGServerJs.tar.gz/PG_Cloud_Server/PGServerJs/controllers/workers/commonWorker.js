let Items = function() {

    const moment = require('moment');

    const logger = require('../../common/Logger');
    const utils = require('../common/Utils');
    const couchDBUtils = require('../common/CouchDBUtils');
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const CLONE = utils.clone;

    const lockUtils = require('../../common/lockUtils');
    lockUtils.createLockDir('locks/items');
    const itemsLockPath = 'locks/items/items.lock';
    const lockOptions = lockUtils.lockOptions();

    //RelaxTodo Beware of locks
    //RelaxRead module
    //RelaxDanger The order of execution of transactitons is not maintained --> merge logic is required

    let bFreeze = false; //Used for UTs to test status docs
    this.setFreeze = function(_bFreeze) {
        if (bFreeze === _bFreeze) {
            logger.error('Already in correct state<' + bFreeze + '>');
            return;
        }

        bFreeze = _bFreeze;
        logger.silly('Worker Freeze<' + bFreeze + '>');
        if (!bFreeze) {
            wakeUp();
        }
    };

    let bAwake = false;
    let pendingInventoryTransactions = [];
    let pendingItemUpdates = [];
    let pendingElementUpdates = [];
    let pendingParentSalesTransactions = [];
    let pendingParentReceivingsTransactions = [];
    let pendingParentReturns = [];
    let pendingReverseInvTransactions = [];

    let allPendingTransactions = [{
        transactions: pendingInventoryTransactions,
        updateFunName: 'write_inv_trans',
        lockPath: itemsLockPath
    }, {
        transactions: pendingItemUpdates,
        updateFunName: 'update_batch_info', //The problem with this is if 2 transaction happens, the order or write is not maintained
        lockPath: undefined
    }, {
        transactions: pendingParentSalesTransactions,
        updateFunName: 'delta_pending_amount',
        lockPath: undefined
    }, {
        transactions: pendingParentReceivingsTransactions,
        updateFunName: 'delta_pending_amount',
        lockPath: undefined
    }, {
        transactions: pendingElementUpdates,
        updateFunName: 'delta_element_trans', //This can break because we are doing +/- what if we do 2 times?
        lockPath: undefined
    }, {
        transactions: pendingParentReturns,
        updateFunName: 'update_returns_docId',
        lockPath: undefined
    }, {
        transactions: pendingReverseInvTransactions,
        updateFunName: 'rev_inv_trans',
        lockPath: itemsLockPath
    }];

    this.start = async function() {
        let pendingTransactionsCount = 0;
        try {
            pendingTransactionsCount = await queryPendingJobs(); //This function is not expected to throw
        } catch (error) {
            logger.error(error); //Not expected to come here
            throw error;
        }

        if (pendingTransactionsCount) {
            wakeUp();
        }
    }

    async function queryPendingJobs() {
        if (bFreeze) {
            return;
        }

        try {
            //This function is not expected to throw
            let salesQueryResp = await couchDBUtils.getView('all_pending_transactions_info', 'pending_transactions', {
                endkey: moment().format('x')
            }, mainDBInstance);

            for (let i = 0; i < salesQueryResp.length; i++) {
                let job = salesQueryResp[i];
                switch (job.value[0]) {
                    case 1:
                        pendingInventoryTransactions.push(job);
                        break;
                    case 2:
                        pendingItemUpdates.push(job);
                        break;
                    case 3:
                        pendingParentSalesTransactions.push(job);
                        break;
                    case 4:
                        pendingElementUpdates.push(job);
                        break;
                    case 5:
                        pendingParentReceivingsTransactions.push(job);
                        break;
                    case 6:
                        pendingParentReturns.push(job);
                        break;
                    case 7:
                        pendingReverseInvTransactions.push(job);
                }
            }

            return salesQueryResp.length;
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    function mergeTrans() {

    }

    //Sales and purchase call this directly
    //every insert can try to merge
    //key is timestamp
    //value: [a, b] a is the type of transaction and b is the status doc
    //key and a will not be used in this case.. they are filled dummies
    //key and a are useful only when they come from view all_pending_transactions
    this.insertTrans = function(params) {
        for (let key in params.transactions) {
            pendingInventoryTransactions.push({
                id: params.parentDocId,
                key: 0,
                value: [0, params.transactions[key]]
            });
        }

        for (let key in params.itemUpdates) {
            pendingItemUpdates.push({
                id: params.parentDocId,
                key: 0,
                value: [0, params.itemUpdates[key]]
            });
        }

        for (let key in params.elementUpdates) {
            pendingElementUpdates.push({
                id: params.parentDocId,
                key: 0,
                value: [0, params.elementUpdates[key]]
            });
        }

        for (let key in params.returnUpdates) {
            pendingParentReturns.push({
                id: params.parentDocId,
                key: 0,
                value: [0, params.returnUpdates[key]]
            });
        }

        for (let key in params.reverseTransactions) {
            pendingReverseInvTransactions.push({
                id: params.parentDocId,
                key: 0,
                value: [0, params.reverseTransactions[key]]
            });
        }

        wakeUp(); //MultiThreaded Behaviour
    };

    this.insertParentSalestrans = function(parentDocId, transactions, elementUpdates) {
        for (let key in transactions) {
            pendingParentSalesTransactions.push({
                id: parentDocId,
                key: 0,
                value: [0, transactions[key]]
            });
        }

        for (let key in elementUpdates) {
            pendingElementUpdates.push({
                id: parentDocId,
                key: 0,
                value: [0, elementUpdates[key]]
            });
        }

        wakeUp(); //MultiThreaded Behaviour
    };

    this.insertParentReceivingstrans = function(parentDocId, transactions, elementUpdates) {
        for (let key in transactions) {
            pendingParentReceivingsTransactions.push({
                id: parentDocId,
                key: 0,
                value: [0, transactions[key]]
            });
        }

        for (let key in elementUpdates) {
            pendingElementUpdates.push({
                id: parentDocId,
                key: 0,
                value: [0, elementUpdates[key]]
            });
        }

        wakeUp(); //MultiThreaded Behaviour
    };

    function wakeUp() {
        //To make it non-blocking making this as promise
        return Promise.resolve(true).then(function() {
            logger.silly('Calling Process. State<' + bAwake + '>');
            process();
        });
    }

    function getTransactionType(parentDocId) {
        let index = parentDocId.indexOf('_');

        return parentDocId.substr(0, index);
    }

    //lock the write to db     
    async function completeJob(data) {
        let jobs = data.transactions;
        let updateFunName = data.updateFunName;
        let dbInstance = mainDBInstance;
        let lockPath = data.lockPath;
        let job = jobs.shift(); //Removing the element. If it fails, instead of trying immediately proceeding with others and then attempting next cycle.        
        let transactionType = getTransactionType(job.id);

        let jobData = job.value[1];
        let curTime = parseInt(moment().format('x'));

        let doc = jobData.doc;
        let errMsg = 'Failed to make the transaction. ' + transactionType + '<' + job.id + '> Job<' + doc._id + '>';
        try {
            lockPath ? await lockUtils.lockAsync(lockPath, CLONE(lockOptions)) : true;
            let transResponse = await couchDBUtils.updateHandler(doc._id, doc, dbInstance, updateFunName, errMsg);
            lockPath ? await lockUtils.unlockAsync(lockPath) : true;

            let statusUpdateJson = {};
            statusUpdateJson[doc._id] = {
                status: 0
            };
            errMsg = 'Failed to Update Status of Transaction. ' + transactionType + '<' + job.id + '> Job<' + doc._id + '>';
            //Todo: This keeps failing mainly for purchase
            let salesUpdateResponse = await couchDBUtils.updateHandler(job.id, statusUpdateJson, mainDBInstance, 'update_transaction_status', errMsg);
        } catch (error) {
            lockPath ? await lockUtils.unlockAsync(lockPath) : true;
            logger.error(error);

            let waitTime = jobData.waitTime ? jobData.waitTime * 2 : 2;
            let statusUpdateJson = {};
            statusUpdateJson[doc._id] = {
                lastAttempt: curTime,
                waitTime: waitTime
            };
            let salesUpdateResponse = await couchDBUtils.updateHandler(job.id, statusUpdateJson, mainDBInstance, 'update_transaction_status', errMsg).catch(function(error) {
                logger.error(error);
            });
        }
    }

    async function processTransactions(data) {
        logger.silly('processTrnasactions In');
        while (data.transactions.length) {
            if (bFreeze) {
                break;
            }
            //RelaxThink What is stopping from executing this transactions in parallel? Merge the documents by _id so that the update can be 1 shot.
            //Write a function to output next batch and after success remove them from the main array
            //Reasons? Locks (IMEI)?
            let job = data.transactions[0];
            let transactionType = job.id.indexOf('sale') === 0 ? 'Sale' : 'Purchase';
            let id = job.value[1].doc._id;
            let msg = transactionType + '<' + data.transactions[0].id + '> Job<' + id + '>';
            logger.silly('completeJob In ' + msg);
            await completeJob(data);
            logger.silly('completeJob Out ' + msg);
        }
        logger.silly('processTrnasactions Out');
    }

    //RelaxTodo List down all possible places for locks and lock them appropriately

    //If pending transactions are empty. Query Pending Transactions and Sleep
    //Ongoing transactions can be marked as in progress to avoid any conflict in merging
    async function process() {
        if (bFreeze) {
            logger.info('Freeze Worker Thread');
            return;
        }
        logger.silly('Inside Process. State<' + bAwake + '>');
        if (bAwake) {
            return;
        }
        bAwake = true;

        logger.info('Worker Process Triggered');
        try {

            for (let i = 0; i < allPendingTransactions.length; i++) {
                if (bFreeze) {
                    break;
                }

                if (allPendingTransactions[i].transactions.length) {
                    await processTransactions(allPendingTransactions[i]);
                }
            }

            logger.info('Worker Process Completed The Tasks');
            let pendingTransactionsCount = await queryPendingJobs();
            if (pendingTransactionsCount) {
                logger.info('Worker Process Found Tasks');
                bAwake = false;
                process();
                return; //Notice the return process(); vs process(); return; We don't want the call stack to grow and these are promises. We will leave it async
            }
        } catch (error) {
            logger.error('Worker Process Exception. Starting Again');
            logger.error(error);
            bAwake = false;
            process();
            return;
        }

        bAwake = false;
    }

};

module.exports = new Items();