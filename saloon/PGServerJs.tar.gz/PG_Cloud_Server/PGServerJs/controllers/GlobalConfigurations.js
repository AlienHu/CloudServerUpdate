// var models = require('../models');
var logger = require('../common/Logger.js');
var status = require('../common/StatusCode');
var BPromise = require('bluebird');
const lockUtils = require('../common/lockUtils');
lockUtils.createLockDir('locks/items');
var validator = require('validator');
const moment = require('moment');
/** BMTodo 
 *  Send Proper error messages 
 *  Already Exist/DeletedAt 
 **/

/**
 * RemoveSequelizeTodo: Use Autoincrement
 */

var GlobalConfigurations = function() {

    var _self = this;

    // var sequelize = models.sequelize;
    var logger = require('../common/Logger');
    var couchDBUtils = require('./common/CouchDBUtils');
    var mainDBInstance = couchDBUtils.getMainCouchDB();

    const lockPath = 'locks/items/items.lock';
    const lockOptions = lockUtils.lockOptions();
    var utils = require('./common/Utils');
    const ARRAY_LENGTH = utils.getArrayLength;
    const configState = require('../common/configState');
    let itemTypes;

    function getItemTypes() {
        let applicationSettings = configState.getApplicationSettings();
        itemTypes = Object.keys(applicationSettings.itemType);
        let index = itemTypes.indexOf('Ingredient');
        if (index != -1) {
            itemTypes.splice(index, 1);
        }
        for (let i = 0; i < itemTypes.length; i++) {
            itemTypes[i] = itemTypes[i].toLowerCase();
        }
    }

    this.createCategory = function(requestData) {
        return createConfig(requestData, 'category');
    };

    this.updateCategory = function(requestData) {
        return updateConfig(requestData, 'category');
    };

    this.deleteCategory = function(requestData) {
        return deleteConfig(requestData, 'category');
    };

    this.createDiscount = function(requestData) {
        return createConfig(requestData, 'discount');
    };

    this.updateDiscount = function(requestData) {
        return updateConfig(requestData, 'discount');
    };

    this.deleteDiscount = function(requestData) {
        return deleteConfig(requestData, 'discount');
    };

    this.createUnit = function(requestData) {
        return createConfig(requestData, 'unit');
    };

    this.updateUnit = function(requestData) {
        return updateConfig(requestData, 'unit');
    };

    this.deleteUnit = async function(requestData) {
        var defaultUnitId = await _self.getDefaultUnitId();
        if (requestData.id !== defaultUnitId) {
            return deleteConfig(requestData, 'unit');
        } else {
            return sendRejectError({}, 'This default unit cannot be deleted. Delete Failed.');
        }
    };

    this.createTax = function(requestData) {
        return createConfig(requestData, 'tax');
    };

    this.updateTax = function(requestData) {
        return updateConfig(requestData, 'tax');
    };

    this.deleteTax = function(requestData) {
        return deleteConfig(requestData, 'tax');
    };

    this.createCharge = function(requestData) {
        return createConfig(requestData, 'charge');
    };

    this.updateCharge = function(requestData) {
        return updateConfig(requestData, 'charge');
    };

    this.deleteCharge = function(requestData) {
        return deleteConfig(requestData, 'charge');
    };

    this.createSlab = function(requestData) {
        return createConfig(requestData, 'slab');
    };

    this.updateSlab = function(requestData) {
        return updateConfig(requestData, 'slab');
    };

    this.deleteSlab = function(requestData) {
        return deleteConfig(requestData, 'slab');
    };

    this.createProfile = function(requestData) {
        return createConfig(requestData, 'profile');
    };

    this.updateProfile = function(requestData) {
        return updateConfig(requestData, 'profile');
    };

    this.deleteProfile = function(requestData) {
        return deleteConfig(requestData, 'profile');
    };

    this.createLoyality = function(requestData) {
        return createConfig(requestData, 'loyality');
    };

    this.updateLoyality = function(requestData) {
        return updateConfig(requestData, 'loyality');
    };

    this.deleteLoyality = function(requestData) {
        return deleteConfig(requestData, 'loyality');
    };

    this.createBrand = function(requestData) {
        return createConfig(requestData, 'brand');
    };

    this.updateBrand = function(requestData) {
        return updateConfig(requestData, 'brand');
    };

    this.deleteBrand = function(requestData) {
        return deleteConfig(requestData, 'brand');
    };

    this.createDefaultConfigs = async function() {
        var promisesArray = [];
        var configModelsArray = ['category', 'discount', 'unit',
            'tax', 'brand', 'loyality'
        ];

        for (var i = 0; i < configModelsArray.length; i++) {
            var modelName = configModelsArray[i];

            //CommitTodo Add default configs ; use hardcoded values from config_model
            // var defaultConfigs = _self.getAll(modelName);
            // if (defaultConfigs.length) {
            //     promisesArray.push(insertConfigArray(defaultConfigs, modelName));
            // }

            promisesArray.push(formDefaultConfigsArray(modelName));
        }

        return await Promise.all(promisesArray);

    };

    async function formDefaultConfigsArray(type) {

        let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
        var defaultConfigs = _self.getAll(type);

        //Assumption: 1st time, creating default config is successful
        //Todo: Loop and check if default config is already created
        let response = {};
        if (resp.length === 0) {
            response = await insertConfigArray(defaultConfigs, type);
        }

        return response;
    }

    /**
     * Alternative flow is query all the configs at 1 shot, then whichever is missing insert them 1 by 1 
     * If deleted don't create again
     */
    async function insertConfigArray(dataArray, modelName) {
        for (let i = 0; i < dataArray.length; i++) {
            await createConfig(dataArray[i], modelName);
        }
        return;
    }

    function sendError(response, err, msg) {
        logger.error(err);
        logger.error(msg);
        response.err = err;
        response.msg = msg;
        return Promise.reject(response);
    }

    function sendRejectError(response, msg) {
        logger.error(msg);
        response.msg = msg;
        return Promise.reject(response);
    }

    function getUniqueHash(data, type) {
        let uniqueHash = data.name.toLowerCase();
        if (type === 'discount') {
            uniqueHash += '_' + data.discount;
        } else if (type === 'tax' || type === 'loyality' || type === 'charge') {
            uniqueHash += '_' + data.percent;
        }

        return uniqueHash;
    }

    function runSettingsValidations(requestData, type, isUpdate) {

        if (validator.isEmpty(String(requestData.name)) && type !== 'unit') {
            delete requestData.name;
            return Promise.reject(' Name Cannot be empty');
        }

        if (type === 'discount') {
            if (validator.isEmpty(String(requestData.discount))) {
                delete requestData.discount;
                return Promise.reject(' Discount percent Cannot be empty');
            }
        }

        if (type === 'tax' || type === 'charge') {
            if (validator.isEmpty(String(requestData.percent))) {
                delete requestData.percent;
                return Promise.reject(' Tax percent Cannot be empty');
            }
        }

        if (!isUpdate) { //Create customer Validations

            if (requestData.hasOwnProperty('_rev')) {

                delete requestData._rev;
            }

            if (requestData.hasOwnProperty('_id')) {

                delete requestData._id;
            }

            if (requestData.hasOwnProperty('id')) {
                logger.info('Field requestData[\'id\']', 'should not Exist while creating New Config');
                delete requestData.id;
            }

        } else {

            if (!requestData.hasOwnProperty('id')) {
                return Promise.reject(' Should pass id, while update');
            }
        }

        let uniqueHash = getUniqueHash(requestData, type);

        var params = {
            keys: [uniqueHash]
        };
        if (isUpdate && !requestData._id) {
            requestData._id = type + '_' + requestData.id;
        }

        return couchDBUtils.getView('all_items_data', 'item-settings_unique_' + type, params, mainDBInstance).then(function(resp) {
            var msg = type + ' ' + uniqueHash + ' Already Exists. Enter Unique Values';

            var bUnique = true;
            for (var i = 0; i < resp.length; i++) {
                if (isUpdate && resp[i].id === requestData._id) {
                    continue;
                }

                var key = resp[i].key;

                if (uniqueHash === key) {
                    bUnique = false;
                }
            }

            if (!bUnique) {
                return Promise.reject(msg);
            }
        });
    }

    function createConfig(requestData, modelName) {
        var data = {};
        var response = {
            status: status.ERR_UNDEFINED,
            msg: ''
        };

        var configModel = modelName;
        if (!configModel) {
            return sendRejectError(response, 'Invalid Config');
        };

        try {
            data = requestData;
        } catch (err) {
            return sendRejectError(response, 'Invalid Data');
        }
        var configName = configModel;
        var config_id = null;
        var bCalledCreate = false;
        return lockUtils.lockAsync(lockPath, utils.clone(lockOptions)).then(function() {
            return runSettingsValidations(requestData, configName);
        }).then(function() {
            var timeStamp = moment().valueOf();
            requestData.id = timeStamp;
            requestData._id = configName + '_' + timeStamp;
            bCalledCreate = true;
            return couchDBUtils.create(requestData, mainDBInstance, 1, 'Internal Server Error Try Again');
        }).then(function(resp) {
            lockUtils.unlockAsync(lockPath);
            logger.silly(resp);
            //var category_id = resp[0].id;
            response.id = requestData.id; // category_id.substring(9);
            response.status = status.SUCCESS;
            response.msg = configName + '  Creation Success';

            return response;
        }).catch(function(err) {
            lockUtils.unlockAsync(lockPath);
            return sendError(response, err, err);
        });
    }

    function updateConfig(requestData, modelName) {
        var data = {};
        var response = {
            status: status.ERR_UNDEFINED,
            msg: ''
        }

        var configModel = modelName;
        if (!configModel) {
            return sendRejectError(response, 'Invalid Config');
        };

        try {
            data = requestData; // configModel.getJson(requestData);
            if (!requestData.id) {
                return sendRejectError(response, 'Invalid Id');
            }
            id = requestData.id;
        } catch (err) {
            return sendRejectError(response, 'Invalid Data');
        }
        var configName = modelName;

        var bCalledUpdate = false;
        return lockUtils.lockAsync(lockPath, utils.clone(lockOptions)).then(function() {
            return runSettingsValidations(requestData, modelName, true);
        }).then(function(resp) {
            var doc = requestData;
            return couchDBUtils.update(doc, mainDBInstance, 2);
        }).then(function(resp) {
            lockUtils.unlockAsync(lockPath);
            logger.silly(resp);
            response.status = status.SUCCESS;
            response.msg = requestData.name + ' ' + configName + ' Update Success';
            response.id = requestData.id;
            return response;
        }).catch(function(err) {
            lockUtils.unlockAsync(lockPath);
            return sendError(response, err, err);
        });
    };

    async function canDelete(requestData, type) {
        requestData._id = requestData._id ? requestData._id : (type + '_' + requestData.id);

        let params = {
            keys: [requestData._id]
        };

        let queryResponse = await couchDBUtils.getView('all_items_data', 'item-settings', params, mainDBInstance);
        return queryResponse;
    }

    function deleteConfig(requestData, modelName) {
        var response = {
            status: status.ERR_UNDEFINED,
            msg: ''
        };

        if (!requestData.id) {
            return sendRejectError(response, 'Invalid Id');
        }

        var configModel = modelName;
        if (!modelName) {
            return sendRejectError(response, 'Invalid Config');
        };
        var configName = modelName;
        return lockUtils.lockAsync(lockPath, utils.clone(lockOptions)).then(function() {
            return canDelete(requestData, modelName);
        }).then(function(resp) {
            if (!resp || !resp.length) {
                return couchDBUtils.addDeleteFlag({
                    _id: modelName + "_" + requestData.id
                }, mainDBInstance);
            } else {
                return sendRejectError(response, configName + ' is used by few items. Delete Failed.');
            }
        }).then(function() {
            // permnentlyRemoveDefaultConfigs(configName, requestData);
            lockUtils.unlockAsync(lockPath);
            response.status = status.SUCCESS;
            response.msg = 'SuccesFully deleted ' + configName;
            return response;
        }).catch(function(reason) {
            lockUtils.unlockAsync(lockPath);
            var msg = reason.msg;
            if (!msg) {
                msg = configName + ' Delete Failed';
            }
            return sendError(response, reason, msg);
        });
    };

    var defaultConfig = [];

    var defaultUnits = [{
        name: '',
        description: 'Unit'
    }, {
        name: 'Kg',
        description: 'Kilograms',
        shortName: 'kgs',
        _id: 'KGS-KILOGRAM'
    }, {
        name: 'gm',
        description: 'Grams',
        shortName: 'gms',
        _id: 'GMS-GRAMS'
    }, {
        name: 'Pkt',
        description: 'Packets',
        shortName: 'pac',
        _id: 'PAC-PACKS'
    }, {
        name: 'L',
        description: 'Litre',
        _id: 'LTR-LITERS',
        shortName: 'ltr'
    }, {
        name: 'ml',
        description: 'Millilitre',
        _id: 'MGS-MILLI GRAMS',
        shortName: 'mgs'
    }];

    var defaultCategories = [];

    var defaultBrands = [];
    /**
     * GST's
     * Cgst 2.5
     * Sgst  2.5            5% 
     * Cgst  6
     * Sgst  6               12% 
     * Cgst  9
     * Sgst   9              18%
     * Cgst 14
     * Sgst 14              28%
     */
    var defaultTaxes = [{
        name: 'GST',
        percent: 5
    }, {
        name: 'GST',
        percent: 12
    }, {
        name: 'GST',
        percent: 18
    }, {
        name: 'GST',
        percent: 28
    }];
    var defaultLoyality = [];
    var defaultDiscounts = [];

    this.getAll = function(type) {
        switch (type) {
            case 'category':
                return defaultCategories;
            case 'unit':
                return defaultUnits;

            case 'brand':
                return defaultBrands;

            case 'discount':
                return defaultDiscounts;

            case 'tax':
                return defaultTaxes;

            case 'loyality':
                return defaultLoyality;
            default:
                return defaultConfig;

        }

    };

    this.getAllConfigDocsByType = function(type) {
        return couchDBUtils.getAllDocsByType(type, mainDBInstance);
    }

    this.getConfigsCount = async function(type) {

        let params = {
            reduce: true
        };

        let queryResponse = await couchDBUtils.getView('all_items_data', 'item-settings_unique_' + type, params, mainDBInstance);
        return queryResponse;
    };

    // All units are queried, see if it can be optimized
    this.getDefaultUnitId = function() {
        var defaultUnitId = -1;
        return _self.getAllConfigDocsByType('unit').then(function(resp) {
            for (var unitIdx in resp) {
                if (resp[unitIdx].doc.name === '') {
                    defaultUnitId = resp[unitIdx].doc.id;
                }
            }
            return defaultUnitId;
        });
    };

    this.getProfileInfo = async function(id) {
        if (!itemTypes) {
            getItemTypes();
        }

        try {
            let profileDoc = await couchDBUtils.getDoc('profile_' + id, mainDBInstance);
            let docIds = [];

            for (let i = 0; i < itemTypes.length; i++) {
                let taxKey = itemTypes[i] + 'Taxes';
                for (let i = 0; i < ARRAY_LENGTH(profileDoc[taxKey]); i++) {
                    docIds.push('tax_' + profileDoc[taxKey][i]);
                }
            }

            if (profileDoc.slab) {
                docIds.push('slab_' + profileDoc.slab);
            }

            for (let i = 0; i < ARRAY_LENGTH(profileDoc.charges); i++) {
                docIds.push('charge_' + profileDoc.charges[i]);
            }

            let queryResponse = await couchDBUtils.getAllDocs(docIds, mainDBInstance);
            let count = 0;
            for (let i = 0; i < itemTypes.length; i++) {
                let taxKey = itemTypes[i] + 'Taxes';
                for (let i = 0; i < ARRAY_LENGTH(profileDoc[taxKey]); i++) {
                    if (queryResponse[count].error === 'not found') {
                        logger.error(queryResponse[count]);
                        throw 'Internal Error';
                    }

                    profileDoc[taxKey][i] = queryResponse[count++].doc;
                }
            }

            if (profileDoc.slab) {
                if (queryResponse[count].error === 'not found') {
                    logger.error(queryResponse[count]);
                    throw 'Internal Error';
                }

                profileDoc.slab = queryResponse[count++].doc;
            }

            for (let i = 0; i < ARRAY_LENGTH(profileDoc.charges); i++) {
                if (queryResponse[count].error === 'not found') {
                    logger.error(queryResponse[count]);
                    throw 'Internal Error';
                }

                profileDoc.charges[i] = queryResponse[count++].doc;
            }

            return profileDoc;
        } catch (error) {
            logger.error(error);
            throw error;
        }
    };

};
module.exports = new GlobalConfigurations();