/*jshint sub:true*/

const moment = require('moment');
const validator = require('validator');
const BPromise = require('bluebird');
const utils = require('./common/Utils');
const utils_short_url = require('../common/Utils');
const IS_UNDEFINED_OR_NULL = utils.isUndefinedOrNull2;
const ASSIGN_IFNOT_UNDEFINED = utils.assignifNotUndefined;
const CLONE = utils.clone;
const logger = require('../common/Logger');
const status = require('../common/StatusCode');
const responseUtil = require('../common/responseJson');
const sendSMSUtil = require('../sms/sms');
const helper = require("../licencer/licenceHelper")
const customerCntrller = require('./Elements');
// foo.form_validation.set_rulesRestApi('price', 'lang:items_price', 'required|numeric');
//             foo.form_validation.set_rulesRestApi('quantity', 'lang:items_quantity', 'required|numeric');
//             foo.form_validation.set_rulesRestApi('discount', 'lang:items_discount', 'required|numeric');

function salesController(requestSession, applicationSettings) {

    var salesControllerLib = new require('./libraries/salesControllerLib')(requestSession);
    const salesControllerLib2 = new require('./libraries/salesControllerLib2');
    salesControllerLib.applicationSettings = applicationSettings;
    var suspendSalesLib = require('./libraries/SuspendSalesLib');
    var creditPaymentsLib = require('./libraries/creditPaymentsLib');
    var couchDBUtils = require('./common/CouchDBUtils');
    const commonLib = require('./libraries/commonLib');

    var mainDBInstance = couchDBUtils.getMainCouchDB();

    var salesValidator = require('./validatiors/Sales');

    let foo = {};
    var _self = foo;

    salesControllerLib.setLoggedInEmployee(requestSession.user.name);

    /**
     *      addCustomer2SaleRestApi
     */
    foo.addCustomer2Sale = function(requestData) {
        var customer_id = requestData.customer_id;
        var response = {
            succs_customer_id: null
        };

        return salesControllerLib.set_customer(customer_id).then(async function(resp) {
            if (resp.status === status.SUCCESS) {
                response.succs_customer_id = customer_id;
            }
            // ADD MEMBERSHIP HANDLER HERE
            // await salesControllerLib.handleDiscountForMembership();

            return prepareAndDispatchResponse(response);
        }).catch(function(err) {
            logger.error(err);
            return response;
        });
    };

    foo.addEmployee2Sale = async function(requestData) {
        var employee = requestData.employee_id;
        if (!employee) {
            employee = requestSession.user.name;
        }
        var response = {
            succs_employee: null
        };
        try {
            var resp = await salesControllerLib.setCartEmployeeDetails(employee)
            if (resp.status === status.SUCCESS) {
                response.succs_employee = employee;
            }

            response = await prepareAndDispatchResponse(response);
            return response;
        } catch (err) {
            logger.error(err);
            throw err;
        };
    };

    foo.addPrescription2Sale = function(requestData) {
        var prescriptionDetails = requestData.prescriptionDetails;
        var response = {};
        if (salesControllerLib.set_prescriptionDetails(prescriptionDetails) === status.SUCCESS) {
            response.prescriptionDetails = prescriptionDetails;
            return prepareAndDispatchResponse(response);
        } else {
            logger.error('Failed to add prescription details');
            throw 'Failed to add prescription details';
        };
    }

    foo.addRoom2Sale = async function(data) {
        if (IS_UNDEFINED_OR_NULL(data.customer_id) || IS_UNDEFINED_OR_NULL(data.refBookingId)) {
            throw 'Customer Id and Booking Id is mandatory';
        }

        salesControllerLib.setRefBookingId(data.refBookingId);

        return foo.addCustomer2Sale(data);
    };

    foo.additemRestApi = function(requestData, bRemoveItem) {
        var reverseQuantitySign = 1;
        if (!utils.isUndefinedOrNull(bRemoveItem)) {
            reverseQuantitySign = -1;
        }

        var response = {};
        var requestItemId = requestData.item;
        var requestStockKey = requestData.stockKey;
        var uniqueDetails = requestData.uniqueDetails ? requestData.uniqueDetails : {};
        var itemLocation = salesControllerLib.get_sale_location();
        return new Promise(function(resolve, reject) {
            Promise.resolve().then(function() {
                var mode = salesControllerLib.get_mode();
                var quantity = (mode == 'return' ? -1 : 1) * reverseQuantitySign;
                if (requestData.quantity) {
                    quantity *= requestData.quantity;
                }

                if (mode == 'return') {

                } else {
                    let discount = requestData.discount;
                    if (applicationSettings.discount.defaultSalesDiscount && discount === undefined) {
                        discount = applicationSettings.discount.defaultSalesDiscount;
                    }
                    return salesControllerLib.addItem2Cart(requestItemId, requestStockKey, quantity, itemLocation, discount, requestData.price, undefined, undefined, undefined, requestData.itemTaxList, requestData.bSPTaxInclusive, requestData.appointmentData);
                }
            }).then(function(cartItem) {
                if (cartItem.is_serialized || cartItem.imeiCount) {
                    //have logic inside the lib iteself
                    var params = {
                        line: cartItem.line,
                        description: cartItem.description,
                        serialnumber: uniqueDetails.serialnumber,
                        imeiNumbers: uniqueDetails.imeiNumbers,
                        price: cartItem.price,
                        quantity: cartItem.quantity,
                        discount: cartItem.discount
                    };

                    return _self.editItemRestApi(params);
                }
            }).then(function() {
                return salesControllerLib.out_of_stock(requestItemId, requestStockKey, itemLocation);
            }).then(async function(itemStockStatus) {
                // await salesControllerLib.handleDiscountForMembership();
                response.warning = itemStockStatus;
                resolve(prepareAndDispatchResponse(response));
            }).catch(async function(err) {
                logger.error('additemRestApi exception')
                logger.error(err);
                logger.error(requestData);
                response.warning = err;
                // await salesControllerLib.handleDiscountForMembership();
                resolve(prepareAndDispatchResponse(response));
            });
        });
    };

    foo.setAppointmentDate = function(params) {
        salesControllerLib.setAppointmentDate(params.date);
        return prepareAndDispatchResponse();
    }

    foo.editItemRestApi = function(requestData) {

        var response = {};
        return Promise.resolve().then(function() {

            //foo.form_validation.set_rulesRestApi('price', 'lang:items_price', 'required|numeric');
            // foo.form_validation.set_rulesRestApi('quantity', 'lang:items_quantity', 'required|numeric');
            // foo.form_validation.set_rulesRestApi('discount', 'lang:items_discount', 'required|numeric');
            var errMsg = '';
            var bIsDataValid = salesValidator.editItem(requestData, errMsg);
            if (!bIsDataValid) {
                Promise.reject(errMsg);
            } else {

                var line = requestData.line;
                var description = requestData.description;
                var serialnumber = requestData.serialnumber;
                var imeiNumbers = requestData.imeiNumbers;
                var price = requestData.price;
                var quantity = requestData.quantity;
                var discount = requestData.discount;
                var itemLocation = requestData.item_location;
                var appointmentData = requestData.appointmentData;
                let membershipDiscount = requestData.membershipDiscount ? requestData.membershipDiscount : 0;

                salesControllerLib.edit_item(line, description, serialnumber, imeiNumbers, quantity, discount, price, appointmentData, membershipDiscount);
                return salesControllerLib.out_of_stock(salesControllerLib.get_item_id(line), salesControllerLib.getStockKey(line), itemLocation);
            }
        }).then(function(itemStockStatus) {
            response.warning = itemStockStatus;
            return prepareAndDispatchResponse(response);
        });
    };

    /**
     * {
     * bPercent: true
     * value: 5
     * }
     * For tests, discountMethod has to be old method i.e. onTaxable
     */
    foo.setGlobalDiscount = async function(requestData) {
        if (!requestData.discountMethod) {
            //This change was done for sale edit
            requestData.discountMethod = (applicationSettings.salesConfig.discountMethod) ? applicationSettings.salesConfig.discountMethod : 'onTaxable';
        }
        await salesControllerLib.setGlobalDiscount(requestData);
        return prepareAndDispatchResponse();
    };

    /**
     *      removeitemRestApi
     */
    foo.removeItem = function(requestData) {
        return _self.additemRestApi(requestData, 1);
    };

    /**
     * DeleteItemFromCartRestApi
     * Todo 
     *          requestData.item is actually line number. Please validate
     */
    foo.delteItemFromCart = function(requestData) {
        var response = {};
        response.status = salesControllerLib.deleteItemByLine(requestData.item);
        if (requestData.rescheduleServiceTimings) {
            salesControllerLib.rearrangeServiceTimes();
        }
        return prepareAndDispatchResponse(response);
    };

    async function prepareAndDispatchResponse(response, setRevAndId) {

        response = response || {};
        await salesControllerLib.handleDiscountForMembership(); // verify if computation is correct TODO
        await salesControllerLib.computeCart(1, 0);
        response.cart = CLONE(salesControllerLib.get_cart());
        response.totalNoSpotDiscount = salesControllerLib.get_total();
        response.discount = salesControllerLib.get_discount();
        if (requestSession.gDiscountValue) {
            await salesControllerLib.computeCart(); // CULPRIT 
        }
        let total = salesControllerLib.get_total(response);
        if (requestSession.discountMethod === 'onTaxable') {
            response.discount = salesControllerLib.get_discount();
        } else {
            response.discount += response.totalNoSpotDiscount - total;
        }
        response.discount = +response.discount.toFixed(2);
        response.bLocalTax = requestSession.settings.sales.bLocalTax;
        var allCartTaxes = salesControllerLib.get_taxes();
        response.charges = salesControllerLib.getAllCharges(response.cart);
        var amountDue = salesControllerLib.get_amount_due();

        //TODO
        // taxArray is moved to cart, each cart Itme would have its tax info
        //This cart taxt summary
        response.taxes = allCartTaxes;
        response.bReadyForCheckout = salesControllerLib.isCartReadyForCheckout();
        response.refBookingId = salesControllerLib.getRefBookingId();
        //TODO
        //var person_info = foo.Employee.get_logged_in_employee_info();                
        response.modes = {
            sale: 'Sale',
            return: 'Return'
        };
        response.mode = salesControllerLib.get_mode();
        response.profileId = salesControllerLib.getProfileId();
        response.globalDiscountInfo = await salesControllerLib.getGlobalDiscountInfo();
        //TODO looks foo is not needed at client side
        //response.stock_locations = foo.Stock_location.get_allowed_locations('sales');
        response.stock_location = salesControllerLib.get_sale_location();
        response.subtotal = salesControllerLib.get_subtotal(true, true);
        response.tax_exclusive_subtotal = salesControllerLib.get_subtotal(true);
        response.noTaxNoDiscountNoCharges = salesControllerLib.get_subtotal(false);
        response.totalTax = salesControllerLib.getTaxAmt(allCartTaxes);

        //response.taxesArray = foo.getAllCartItemTaxes();
        //TODO looks like we dont need foo
        //response.taxesArray = salesControllerLib.allCartTaxes;

        response.total = total;
        response.payments = salesControllerLib.get_payments();
        response.saleOnCreditAmt = salesControllerLib.getSaleOnCreditAmt(response.payments);

        //TODO Need get the Employee Permissions
        //response.items_module_allowed = foo.Employee.has_grant('items', loggedInEmployeeId);

        response.items_module_allowed = [];

        response.comment = salesControllerLib.get_comment();
        response.email_receipt = salesControllerLib.get_email_receipt();
        response.payments_total = +salesControllerLib.get_payments_total().toFixed(2);
        response.amount_due = amountDue;
        response.stock_location = salesControllerLib.get_sale_location();
        //TODO might have to create new table with payment options and its names
        response.payment_options = {};
        // broken after merge: TODO if proper
        for (let i in applicationSettings.paymentTerms.value) {
            response.payment_options[applicationSettings.paymentTerms.value[i]] = applicationSettings.paymentTerms.value[i];
        }
        response.payment_options['Sale on credit'] = 'Sale on credit';

        //TODO invoice generation

        var cust_info = salesControllerLib.getCartCustomerDetails();
        if (!utils.isUndefinedOrNull(cust_info) && cust_info.person_id !== null) {
            var custLastName = cust_info.last_name ? cust_info.last_name : '';
            var custCompanyName = cust_info.company_name ? cust_info.company_name : '';

            response.customer = custCompanyName + ' ' + cust_info.first_name + ' ' + custLastName;
            response.customer_email = cust_info.email;
            response.customer_id = cust_info.person_id;
            response.loyalityeligible = cust_info.loyalty;
            response.customer_isCreditAllowed = cust_info.allow_credit;
            response.customer_credit_limit = cust_info.credit_limit;
            response.customer_walletBalance = cust_info.walletBalance;
            response.phone_number = cust_info.phone_number;
        }
        response.employee_id = requestSession.user.name;
        var emp_info = salesControllerLib.getCartEmployeeDetails();
        if (!utils.isUndefinedOrNull(emp_info)) {
            response.employee_id = emp_info.name;
        }
        // response.invoice_number = foo._substitute_invoice_number(cust_info);

        response.invoice_number_enabled = salesControllerLib.is_invoice_number_enabled();
        response.print_after_sale = salesControllerLib.is_print_after_sale();
        response.payments_cover_total = doesPaymentsCoverTotal(response.total);
        salesControllerLib.getTempDetails(response);
        salesControllerLib.handleIsAppointmentFlag();
        response.isAppointment = salesControllerLib.getIsAppointment();
        if (response.isAppointment)
            response.appointmentDate = salesControllerLib.getAppointmentDate();
        response.status = salesControllerLib.getStatus();
        if (setRevAndId) {
            response.suspendSaleInfoForUpdate = salesControllerLib.getSuspendedSalesDocInfo()
        }
        if (!response.discounted_subtotal)
            response.discounted_subtotal = salesControllerLib.get_subtotal(true);
        return response;
    }

    function doesPaymentsCoverTotal(salesTotal) {

        var total_payments = 0;
        for (var index in salesControllerLib.get_payments()) {
            var payment = salesControllerLib.get_payments()[index];
            total_payments += payment.payment_amount;
        }

        if (salesControllerLib.get_mode() == 'sale' && (salesTotal - total_payments) > 1.0E-6) {
            return false;
        }
        return true;
    }

    /**
     *      setPrintAfterSaleRestApi
     */
    foo.setPrintAfterSale = function(requestData) {
        salesControllerLib.set_print_after_sale(requestData.sales_print_after_sale);
        return Promise.resolve({
            status: 'success'
        });
    }

    foo.cancel_saleRestApi = function() {
        salesControllerLib.clear_all();
        return prepareAndDispatchResponse();
    };

    foo.completeReturn = function(requestData) {
        if (!requestData.employee_id) {
            requestData.employee_id = requestSession.user.name;
        }
        let invoiceCheckpointObj = commonLib.getCurrentCheckpoint(applicationSettings);
        requestData.invoiceCheckpoint = invoiceCheckpointObj.value;
        requestData.sReturnPrefix = invoiceCheckpointObj.sReturnPrefix;
        return salesControllerLib2.commitSaleReturn(requestData);
    };

    foo.suspendReturn = function(requestData) {
        return commonLib.suspendReturn(requestData);
    };

    foo.allSuspendedReturns = function() {
        return commonLib.getAllSuspendedReturns();
    };

    foo.unsuspendReturn = function(requestData) {
        return commonLib.unsuspendReturn(requestData);
    };
    /**
     * Quick sale : add payments + complete sale
     */

    foo.add_paymentRestApi = async function(paymentData) {
        try {
            var payment_type = paymentData.payment_type;
            var thePaymentAmount = paymentData.amount_tendered;
            var thePaymentRefNo = paymentData.ref_no;
            if (!thePaymentAmount) {
                throw "Enter amount to pay";

            }
            if (!payment_type) {
                throw "Select payment type";
            }
            if (salesControllerLib.add_payment(payment_type, thePaymentAmount, thePaymentRefNo)) {
                return await foo.updateWalletBalance(payment_type, thePaymentAmount);
            }
        } catch (error) {
            throw {
                'message': error
            };
        }
    };

    foo.updateWalletBalance = async function(payment_type, thePaymentAmount) {
        try {
            if (payment_type != "Wallet") return prepareAndDispatchResponse(response);
            var customer = salesControllerLib.getCartCustomerDetails();
            if (customer.person_id) {
                customer.walletBalance -= thePaymentAmount * (1 / applicationSettings.salesConfig.walletValue);
                await couchDBUtils.update(customer, mainDBInstance);
                var response = {};
                return prepareAndDispatchResponse(response);
            } else
                return prepareAndDispatchResponse(response);
        } catch (err) {
            throw {
                'message': error
            };
        }

    }
    /**
     * Quick Payment
     */
    foo.quickSale = async function(quickParams) {
        var quickSaleParams = {
            payment_type: quickParams.payment_type,
            amount_tendered: quickParams.amount_tendered
        };
        let resp = await _self.add_paymentRestApi(quickSaleParams);
        var completeQuickParams = {
            comment: '',
            table_no: quickParams.table_no,
            order_no: quickParams.order_no,
            print_after_sale: quickParams.print_after_sale,
            timeStamp: quickParams.timeStamp
        };
        if (quickParams.wcInfo) {
            completeQuickParams.wcInfo = quickParams.wcInfo;
        }
        if (quickParams.saleIdToEdit) {
            completeQuickParams.saleIdToEdit = quickParams.saleIdToEdit;
            completeQuickParams.invoiceCheckpoint = quickParams.invoiceCheckpoint;
            completeQuickParams.num = quickParams.num;
            completeQuickParams.prefix = quickParams.prefix;
        }
        if (quickParams.bQuickOrder) {
            resp = await _self.completeTakeOrder(completeQuickParams);
        } else {
            resp = await _self.completeSaleRestApi(completeQuickParams);
        }

        return resp;
    }

    /**
     *      Todo: There is a problem with amount change and customer details
     */

    let get_short_url = async function(applicationSettings, response) {
        var saleId = response.sale_id.substr(response.sale_id.indexOf(" ") + 1, response.sale_id.length);
        var generate_short_url_payload = {
            feed_id: applicationSettings.enableFeedback.question_id,
            custumer_id: response.customer_id,
            sales_id: saleId,
            mac: helper.getServerSerialNum(),
            app_type: process.env.APP_TYPE

        };
        var url = `http://alienhu.com/user_feedback_view.html?f=${generate_short_url_payload.feed_id}&c=${generate_short_url_payload.custumer_id}&m=${generate_short_url_payload.mac}&a=${generate_short_url_payload.app_type}&s=${generate_short_url_payload.sales_id}`;
        return utils_short_url.getShortUrl(url);
    }

    foo.completeSaleRestApi = async function(requestData) {
        if (requestData.item_id) {
            //Petrol Bunk
            salesControllerLib.clear_all();
            requestData.item = requestData.item_id;
            await _self.additemRestApi(requestData);
            if (requestData.discounted_total) {
                await _self.add_paymentRestApi({
                    payment_type: 'Cash',
                    amount_tendered: requestData.discounted_total
                });
            }
        }

        var editSaleId = requestData.saleIdToEdit ? requestData.saleIdToEdit : null;
        let saleNum = requestData.num ? requestData.num : null;
        let invoiceCheckpointObj = commonLib.getCurrentCheckpoint(applicationSettings);
        let invoiceCheckpoint = requestData.invoiceCheckpoint ? requestData.invoiceCheckpoint : invoiceCheckpointObj.value;
        let invoicePrefix = requestData.prefix ? requestData.prefix : invoiceCheckpointObj.prefix;

        let comment = requestData ? requestData.comment : '';
        if (comment) {
            salesControllerLib.set_comment(comment);
        }
        let state_name = requestData ? requestData.state_name : '';
        var response = {};
        //Because we don't want to include global discount in cart
        await salesControllerLib.computeCart(1, 0);
        response.cart = CLONE(salesControllerLib.get_cart());
        response.discount = salesControllerLib.get_discount();
        response.totalNoSpotDiscount = salesControllerLib.get_total();
        if (requestSession.gDiscountValue) {
            await salesControllerLib.computeCart();
        }
        let onlyDiscount = salesControllerLib.get_discount();
        let total = salesControllerLib.get_total(response);
        if (requestSession.discountMethod === 'onTaxable') {
            response.discount = onlyDiscount;
        } else {
            response.discount += response.totalNoSpotDiscount - total;
        }
        response.bLocalTax = requestSession.settings.sales.bLocalTax;
        var taxes = salesControllerLib.get_taxes(true);
        var taxesWithpercentages = salesControllerLib.gettaxesByPercentage(true);
        response.charges = salesControllerLib.getAllCharges(response.cart);
        var amount_due = salesControllerLib.get_amount_due();

        let timeStamp;
        let checkNo;
        let shippingAddress;
        if (requestData) {
            if (requestData.timeStamp) {
                var curTime = new Date();
                timeStamp = new Date(requestData.timeStamp);
                timeStamp.setSeconds(curTime.getSeconds());
                timeStamp = timeStamp.toISOString();
            }
            checkNo = requestData.chequeNo;
            if (requestData.shippingDetails || requestData.state_name) {
                state_name = requestData.state_name;
                shippingAddress = requestData.shippingDetails;
                response.shippingAddress = shippingAddress;
                response.state_name = state_name;
            }
        }
        response.taxesWithPercents = taxesWithpercentages;
        response.taxDetailed = {};
        response.taxNames = {};
        response.hsnTaxes = {};
        // get taxDetailed and taxNames
        salesControllerLib.gettaxesByPercentageDetailed(response.taxDetailed, response.taxNames, response.hsnTaxes);
        if (requestData.chequeNo) {
            response.cheQueNo = requestData.chequeNo;
        }
        let membershipCardInSale = salesControllerLib.ifCartHasMembership(response.cart);
        response.taxes = taxes;
        response.total = total;
        response.payments = salesControllerLib.get_payments();
        response.saleOnCreditAmt = salesControllerLib.getSaleOnCreditAmt(response.payments);

        response.amount_due = amount_due;

        var quantity = 0;
        for (var i = 0; i < response.cart.length; i++) {
            quantity = quantity + (response.cart[i].quantity);
        }
        response.totalQuantity = quantity;
        response.subtotal = salesControllerLib.get_subtotal(true);

        response.discounted_subtotal = salesControllerLib.get_subtotal(true);

        response.totalWithoutTax = (onlyDiscount + response.discounted_subtotal);

        response.tax_exclusive_subtotal = salesControllerLib.get_subtotal(true);

        response.receipt_title = 'Sales Receipt';

        response.comments = salesControllerLib.get_comment();
        response.amount_change = amount_due * -1;
        response.employee = requestSession.user.first_name + ' ' + requestSession.user.last_name;
        let salesEmployeeName = requestSession.user.name;
        let salesEmployee = salesControllerLib.getCartEmployeeDetails();
        if (salesEmployee) {
            response.employee = salesEmployee.first_name + ' ' + salesEmployee.last_name;
            salesEmployeeName = salesEmployee.name;
        }
        response.company_info = {
            0: applicationSettings.ownersInfo.address,
            1: applicationSettings.ownersInfo.phone,
            2: applicationSettings.ownersInfo.account_number,
            3: applicationSettings.ownersInfo.company
        };
        response.company_address = applicationSettings.ownersInfo.address;
        response.company_phone = applicationSettings.ownersInfo.phone;
        response.company_account = applicationSettings.ownersInfo.account_number;
        response.company_name = applicationSettings.ownersInfo.company;
        response.globalDiscountInfo = await salesControllerLib.getGlobalDiscountInfo();

        var customerInfo = salesControllerLib.getCartCustomerDetails();
        if (customerInfo.person_id !== null) {
            if (customerInfo.company_name) {
                response.customer_compnay_name = customerInfo.company_name;
            }
            response.customer = customerInfo.first_name;
            if (customerInfo.last_name) {
                response.customer += ' ' + customerInfo.last_name;
            }

            response.customer_id = customerInfo.person_id;

            response.customer_address = customerInfo.address_1;
            response.customer_location = customerInfo.zip + ' ' + customerInfo.city;
            response.account_number = customerInfo.account_number;
            response.customerGSTIN = customerInfo.gstin_number;
            response.phone_number = customerInfo.phone_number;

            response.customer_info = {
                0: response.customer,
                1: customerInfo.address_1,
                2: customerInfo.zip + ' ' + customerInfo.city,
                3: customerInfo.account_number,
                4: customerInfo.gstin_number,
                5: customerInfo.phone_number
            };
        } else if (requestData.wcInfo) {
            let name = requestData.wcInfo.name;
            let phone_number = requestData.wcInfo.phone_number;
            response.customer = name;
            response.phone_number = phone_number;
            if (phone_number) {
                if (!name) {
                    name = phone_number;
                }
                requestData.wcInfo.bWC = true;
                requestData.wcInfo.type = 'customer_';
                requestData.wcInfo.first_name = name;

                try {
                    let resp = await customerCntrller.create(requestData.wcInfo);
                    response.customer_id = resp.data.id;
                    response.customer = resp.data.name;
                    response.phone_number = resp.data.phone_number;
                    response.customer_info = {
                        0: response.customer,
                        1: customerInfo.phone_number
                    };
                    customerInfo.person_id = resp.data.id;
                } catch (err) {
                    logger.info('walkin customer create fail ' + requestData.wcInfo.name + ' ' + requestData.wcInfo.phone_number);
                }
            }

        } else {
            response.customer = '';
        }
        response.globalDiscountInfo.discountMethod = applicationSettings.salesConfig.discountMethod;
        response.table_no = (requestData.table_no) ? requestData.table_no : undefined;
        response.tableNo = response.table_no;
        //response.cart is not used below because it doesn't have globalDiscountPercent
        salesControllerLib.handleIsAppointmentFlag();
        response.isAppointment = salesControllerLib.getIsAppointment();
        if (response.isAppointment) {
            response.appointmentDate = salesControllerLib.getAppointmentDate();
        }
        let saleResponse = await salesControllerLib.commitSale(salesControllerLib.get_cart(), editSaleId, customerInfo.person_id, salesEmployeeName, response.comments, null, response.payments, response.total, response.saleOnCreditAmt, timeStamp, checkNo, state_name, applicationSettings.numberFormat.roundOffMethod, requestData.wcInfo, response.customerGSTIN, shippingAddress, response.globalDiscountInfo, response.table_no, response.isAppointment, response.appointmentDate, invoiceCheckpoint, invoicePrefix, saleNum);
        if (response.isAppointment) {
            let suspendSaleToDelete = salesControllerLib.getSuspendedSalesDocInfo();
            if (suspendSaleToDelete && suspendSaleToDelete.id) {
                var doc = {
                    _id: suspendSaleToDelete.id,
                    _rev: suspendSaleToDelete.rev
                }
                try {
                    await couchDBUtils.delete(doc, mainDBInstance, undefined, 'Failed to delete saved appointment');
                } catch (err) {
                    logger.error(err);
                }
            }
        }
        if (membershipCardInSale) {
            let membershipInfo = '';
            if (membershipCardInSale.membership.offerScope == 'all') {
                membershipInfo = 'Discount: ' + membershipCardInSale.membership.offerPercent + '% on all items';
            } else {
                membershipInfo = 'Custom Discount per Item/Category';
            }
            try {
                await salesControllerLib.addMembershipToCustomer(response.customer_id, membershipCardInSale, saleResponse.timeStamp);
                if (applicationSettings.enableSMS.membership && applicationSettings.enableSMS.membershipSMS && applicationSettings.enableSMS.value) {
                    var jsonParam = {
                        saleId: response.sale_id,
                        membership: membershipCardInSale.name,
                        membershipInfo: membershipInfo,
                        company: response.company_name,
                        date: response.transaction_time,
                        customer: response.customer ? response.customer : 'Customer'
                    };
                    let msg = utils.getSMSMessage(applicationSettings.enableSMS.membershipSMS, jsonParam);
                    sendSMS(applicationSettings, response, msg);
                }
            } catch (err) {
                throw err;
            }
        }

        response.sale_id = invoicePrefix + saleResponse.num;
        // response.transaction_time = saleResponse.timeStamp;
        response.transaction_time = moment(saleResponse.timeStamp).format(applicationSettings.dateTime.dateformat +
            ' ' + applicationSettings.dateTime.timeformat);

        response.transaction_date = moment(saleResponse.timeStamp).format(applicationSettings.dateTime.dateformat);
        //send SMS
        /* TODO
            1. add counter for SMS to track usage per client
            2. Mechanism to restrict setting change by end user
        */

        /***
         * call function ( response.customer_id , response.sale_id ) 
         * return get short url 
         *  * where we need to append the url
         */
        if (applicationSettings.enableSMS.afterSale && applicationSettings.enableSMS.saleSMS && applicationSettings.enableSMS.value) {
            var jsonParam = {
                amount: response.total,
                saleId: response.sale_id,
                company: response.company_name,
                date: response.transaction_time,
                customer: response.customer ? response.customer : 'Customer'
            };
            if (applicationSettings.enableFeedback && applicationSettings.enableFeedback.enableSms) {
                jsonParam['short_url'] = await get_short_url(applicationSettings, response)
            }
            let msg = utils.getSMSMessage(applicationSettings.enableSMS.saleSMS, jsonParam);
            sendSMS(applicationSettings, response, msg);
        }
        response.print_after_sale = salesControllerLib.is_print_after_sale();
        salesControllerLib.clear_all();

        if (response.sale_id == 'POS -1') {
            response.error_message = 'Sales Transactions Failed';
            throw response;
        } else {
            response.discount = +response.discount.toFixed(2);
            response.total = total;

            if (!requestData.item_id && requestData.print_after_sale) {
                //Petrol Bunk
                response.print_after_sale = requestData.print_after_sale;
                if (requestSession.clientType === 'MobileApp') {
                    utils.sendSocketEvent('printSalesReceipt', response);
                }
            }
            return response;
        }

    };

    function sendSMS(applicationSettings, response, msg) {
        if (applicationSettings.enableSMS.value) {
            var params = {
                To: '',
                Type: 'TRANS',
                Msg: msg
            };
            if (applicationSettings.ownersInfo.phone && applicationSettings.enableSMS.toOwner) {
                params.To = applicationSettings.ownersInfo.phone;
            }

            if (applicationSettings.enableSMS.toCustomer && response.phone_number) {
                if (params.To == '') params.To = response.phone_number;
                else params.To += ',' + response.phone_number;
            }
            if (params.To == '' || params.To.toString().length < 10) {
                console.log('no number given');
            } else {
                var smsResp = "";
                try {
                    smsResp = sendSMSUtil(params);
                    logger.info(smsResp);
                } catch (err) {
                    logger.error(err);
                }
            }

        } else {
            logger.silly('SMS functionality not enabled for ' + applicationSettings.ownersInfo.company);
        }
    }

    /**
     * suspendSaleRestApi
     * Todo: 
     *      create lang files
     *      loggedInEmployeeId
     *      check front end and remove unused variables/calculations and comments
     *      prepareAndDispatchResponse is not required 
     * 
     */
    foo.suspendSale = async function(doc) {
        // TODO : DPK update handle
        if (doc && doc.wcInfo) {
            let name = doc.wcInfo.name;
            let phone_number = doc.wcInfo.phone_number;
            if (phone_number) {
                if (!name) {
                    name = phone_number;
                }
                doc.wcInfo.bWC = true;
                doc.wcInfo.type = 'customer_';
                doc.wcInfo.first_name = name;
                try {
                    let resp = await customerCntrller.create(doc.wcInfo);
                    // setCartCustomer        
                    await salesControllerLib.setCartCustomerDetails(resp.data.id);
                } catch (err) {
                    logger.info('walkin customer create fail ' + doc.wcInfo.name + ' ' + doc.wcInfo.phone_number);
                }
            }
        }
        var employeeId = 1;
        let customerInfo = salesControllerLib.getCartCustomerDetails();
        var cart = salesControllerLib.get_cart();
        var comment = salesControllerLib.get_comment();
        var invoice_number = salesControllerLib.get_invoice_number();
        var payments = salesControllerLib.get_payments();
        var employee = requestSession.user.first_name + requestSession.user.last_name;
        salesControllerLib.handleIsAppointmentFlag();
        var isAppointment = salesControllerLib.getIsAppointment();
        if (isAppointment) {
            var appointmentDate = salesControllerLib.getAppointmentDate();
        }
        let globalDiscountInfo = await salesControllerLib.getGlobalDiscountInfo();
        let invoiceCheckpointObj = commonLib.getCurrentCheckpoint(applicationSettings);
        return suspendSalesLib.saveSuspendSaleExt(cart, customerInfo.person_id, customerInfo.first_name + ' ' + customerInfo.last_name, employee, requestSession.user.name, comment, invoice_number, payments, undefined, undefined, isAppointment, doc, appointmentDate, globalDiscountInfo).then(function(resp) {
            var response = {};
            if (resp.sale_id == -1) {
                response.error_message = 'suspend sales failed';
            } else {
                response.sale_id = resp.sale_id;
                salesControllerLib.clear_all();
                response.success = 'sales_successfully_suspended_sale. ' + invoiceCheckpointObj.prefix + resp.sale_id.toString();
            }
            return prepareAndDispatchResponse(response);
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.getSuspendSale = function(requestData) {
        var saleId = requestData.suspended_sale_id;
        salesControllerLib.clear_all();
        return salesControllerLib.copy_entire_suspended_sale(saleId, undefined, true).then(function() {}).then(function(resp) {
            return prepareAndDispatchResponse(undefined, true);
        }).catch(function(err) {
            salesControllerLib.clear_all();
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.updateStatus = async function(params) {
        salesControllerLib.setStatus(params.status.status);
        await foo.suspendSale(params.status);
    }

    foo.updateSuspendSale = function(suspendSaleId) { // REMOVE NO ONE IS USING
        var employeeId = 1;
        let customerInfo = salesControllerLib.getCartCustomerDetails();
        var cart = salesControllerLib.get_cart();
        var comment = salesControllerLib.get_comment();
        var invoice_number = salesControllerLib.get_invoice_number();
        var payments = salesControllerLib.get_payments();
        var employee = requestSession.user.first_name + requestSession.user.last_name;
        salesControllerLib.handleIsAppointmentFlag();
        var isAppointment = salesControllerLib.getIsAppointment();
        return suspendSalesLib.saveSuspendSaleExt(cart, customerInfo.person_id, customerInfo.first_name + ' ' + customerInfo.last_name, employee, requestSession.user.name, comment, invoice_number, payments, undefined, undefined, isAppointment, _rev, status).then(function(resp) {
            var response = {};
            if (resp.sale_id == -1) {
                response.error_message = 'suspend sales failed';
            } else {
                response.sale_id = resp.sale_id;
                salesControllerLib.clear_all();
                response.success = 'sales_successfully_suspended_sale. ' + 'POS ' + resp.sale_id.toString();
            }
            return prepareAndDispatchResponse(response);
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });

    }

    foo.unsuspendSale = function(requestData) {
        var saleId = requestData.suspended_sale_id;
        salesControllerLib.clear_all();
        return salesControllerLib.copy_entire_suspended_sale(saleId).then(function() {
            return suspendSalesLib.deleteExt(saleId);
        }).then(function(resp) {
            return prepareAndDispatchResponse();
        }).catch(function(err) {
            salesControllerLib.clear_all();
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.deleteSuspendedSale = async function(requestData) {
        var saleId = 'suspendedSale_' + requestData.suspended_sale_id;
        salesControllerLib.clear_all();
        let saleDoc = await couchDBUtils.getDoc(saleId, mainDBInstance, "could not fetch sale document");
        let resp = await couchDBUtils.delete(saleDoc, mainDBInstance, 3, "Failed to delete suspended sale");
        return resp;
    }

    /**
     *  allSuspendedSalesRestApi
     *      Todo: return structure changed
     */

    foo.allSuspendedSales = function() {
        return suspendSalesLib.getAll();
    };

    /**
     *    getSalesRestApi    
     *    see if the below call can be optimized, should it be called everytime
     *    calling updateSalesProfileSettings, to see if any changes to taxes have been made 
     */
    foo.getSales = async function(params) {
        salesControllerLib.handleIsAppointmentFlag();
        await salesControllerLib.updateSalesProfileSettings();
        return prepareAndDispatchResponse();
    };

    foo.setLocalTax = async function(requestData) {
        await salesControllerLib.setLocalTax(requestData.bLocalTax);
        return prepareAndDispatchResponse();
    };

    /**
     *      delete_paymentRestApi
     */
    foo.deletePayment = function(requestData) {
        salesControllerLib.delete_payment(requestData.payment_id);
        return prepareAndDispatchResponse();
    };

    /**
     *      setInvoiceNumberEnabledRestApi
     */
    foo.setInvoiceNumberEnabled = function(requestData) {
        salesControllerLib.set_invoice_number_enabled(requestData.sales_invoice_number_enabled);
        return Promise.resolve({
            status: status.SUCCESS
        });
    };

    /**
     *      changeModeRestApi
     *      Todo: handle different sales locations
     */
    foo.changeMode = function(requestData) {
        salesControllerLib.set_mode(requestData.mode);
        return _self.cancel_saleRestApi();
    };

    /**
     *      saveTableOrderRestApi      
     *      Todo: if error, act on the error. Currently just sending error
     *      Todo: kot print     
     *      Todo: prepareAndDispatchResponse is not required
     *      Todo: if edit kot, delete suspendedsale item also
     */
    foo.saveTableOrder = function(requestData) {
        var response = {};
        response.status = status.ERR_UNDEFINED;

        var orderInfoJson4Couch = {};
        var kotOrderInfoJson4Couch = {
            'order_no': -1,
            'kotInfo': {}
        };

        var propsJson = {};

        var tableNo = requestData.table_no;
        var orderNo = requestData.order_no;
        var bNewOrder = requestData.isNewOrder;
        var employee = requestSession.user.first_name + requestSession.user.last_name;
        var salesEmployeeName = requestSession.user.name;
        var salesEmployee = salesControllerLib.getCartEmployeeDetails();
        if (salesEmployee) {
            employee = salesEmployee.first_name + ' ' + salesEmployee.last_name;
            salesEmployeeName = salesEmployee.name;
        }
        var deleteKotParams = {
            'order_no': orderNo,
            'kotInfo': {
                'saleId': requestData.sales_id4kot
            }
        };
        if (requestData.deleteKOT) {
            return couchDBUtils.deleteKot(tableNo, deleteKotParams, mainDBInstance).then(function(resp) {

                var params = {
                    table_no: tableNo,
                    order_no: orderNo
                }
                if (requestData.noOfKos === 1) {
                    return _self.cancelOrder(params).then(function(resp) {
                        return resp;
                    });
                } else {
                    return resp;
                }

            }).catch(function(error) {
                logger.error(error);
                return error;
            })
        }
        if (bNewOrder === true) {
            propsJson.maxOrderNo = _self.getMaxOrderNo({
                table_no: tableNo
            });
        }

        if (requestData.isItEditKot === true) {
            var oldSaleId = requestData.sales_id4kot;
            if (!utils.isUndefinedOrNull(oldSaleId)) {
                propsJson.deleteSuspendedItems = suspendSalesLib.deleteExt(oldSaleId);
                propsJson.deleteKotCouch = couchDBUtils.deleteKot(tableNo, deleteKotParams, mainDBInstance)
            } else {
                logger.error('editkot:: old sale id is null');
            }
        }

        return BPromise.props(propsJson).then(function(respJson) {
            if (!utils.isUndefinedOrNull(respJson.maxOrderNo)) {
                orderNo = respJson.maxOrderNo.order_no;
            }
            if (utils.isUndefinedOrNull(orderNo)) {
                throw {
                    status: status.ERR_UNDEFINED,
                    status: 'order no is not defined'
                };
            }

            var employeeId = 1; //Todo: get proper employee id       
            var customerId = salesControllerLib.get_customer();
            var cart = salesControllerLib.get_cart();
            var comment = salesControllerLib.get_comment();
            var invoice_number = salesControllerLib.get_invoice_number();
            var payments = salesControllerLib.get_payments();

            var customerInfo = salesControllerLib.getCartCustomerDetails();
            var customer = customerInfo.first_name + ' ' + customerInfo.last_name;
            kotOrderInfoJson4Couch.order_no = orderNo;

            //Todo: sale_time should be same for sql and couch
            var sale_time = requestData.kotSaleTime ? moment(requestData.kotSaleTime).format('YYYY-MM-DD HH:mm:ss') : moment().format('YYYY-MM-DD HH:mm:ss');
            var isKOT = true;
            kotOrderInfoJson4Couch.kotInfo = suspendSalesLib.getJson4Couch(sale_time, customerId, cart);
            return suspendSalesLib.saveSuspendSaleExt(cart, customerId, customer, employee, salesEmployeeName, comment, invoice_number, payments, requestData.kotSaleTime, isKOT, undefined);
        }).then(function(resp) {
            var saleId = resp.sale_id;
            if (saleId === -1) {
                return Promise.resolve(response);
            }

            response.status = status.SUCCESS;
            kotOrderInfoJson4Couch.kotInfo.sale_id = saleId;

            var propsJson2 = {};

            if (bNewOrder) {
                var guests = requestData.guests;
                var orderDesc = requestData.order_desc;
                var reservationId = requestData.reservation_id;
                orderInfoJson4Couch = {
                    'order_no': orderNo,
                    'guests': guests,
                    'order_desc': orderDesc,
                    'parent_order_no': -1,
                    'reservation_id': reservationId === undefined ? 0 : reservationId,
                    'Kots': []
                };
            }

            return BPromise.props(propsJson2);
        }).then(function() {
            //couchdb sync            
            if (bNewOrder) {
                return couchDBUtils.addOrder(tableNo, orderInfoJson4Couch, mainDBInstance).then(function(resp) {
                    return couchDBUtils.addKot(tableNo, kotOrderInfoJson4Couch, mainDBInstance);
                });
            } else {
                return couchDBUtils.addKot(tableNo, kotOrderInfoJson4Couch, mainDBInstance);
            }
        }).then(function() {
            if (response.status === status.SUCCESS) {
                kotOrderInfoJson4Couch.user = employee;
                kotOrderInfoJson4Couch.tableNo = tableNo;
                if (requestSession.clientType === 'MobileApp') {
                    utils.sendSocketEvent('printKotReceipt', kotOrderInfoJson4Couch);
                }
                response.kotPrintInfo = kotOrderInfoJson4Couch;
                salesControllerLib.clear_all();
            }
            return prepareAndDispatchResponse(response);

        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    function deleteOrder(tableNo, orderNo) {
        return getAllSales(tableNo, orderNo).then(function(resp) {
            var promisesArray = [];
            for (let i = 0; i < resp.length; i++) {
                promisesArray.push(suspendSalesLib.deleteExt(resp[i]));
            }

            var params = {
                'order_no': orderNo
            };
            promisesArray.push(couchDBUtils.deleteOrder(tableNo, params, mainDBInstance));

            return Promise.all(promisesArray);
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    }

    /**
     * deleteOrdersOfTableRestApi 
     * */
    foo.cancelOrder = function(requestData) {
        var tableNo = requestData.table_no;
        var orderNo = requestData.order_no;

        return deleteOrder(tableNo, orderNo)
            .then(function() {
                return {
                    status: status.SUCCESS
                };
            }).catch(function(err) {
                logger.error(err);
                return Promise.reject(err);
            });
    };

    /**
     *      getItemsForTableOrderRestApi
     */
    foo.getItemsForTableOrder = function(requestData) {
        var tableNo = requestData.table_no;
        var orderNo = requestData.order_no;
        var response = {};
        response.orderItems = {};
        response.status = status.ERR_UNDEFINED;

        return getAllSales(tableNo, orderNo).then(function(resp) {
            return suspendSalesLib.getItems(resp);
        }).then(function(resp) {
            response.status = status.SUCCESS;
            response.orderItems = resp;
            return response;
        }).catch(function(err) {
            logger.error(err);
            return response;
        });
    };

    /**
     *      addCustomer2OrdersRestApi
     *      deleteCustomer4OrderRestApi
     */

    foo.removeCustomer = async function() {
        try {
            let resp = await salesControllerLib.removeCustomer();
            return resp;
        } catch (error) {
            return error;
        }

    }

    foo.getAllCompletedAppointments = async function() {
        try {
            var resp = await couchDBUtils.getView("all_sales_info", "all_completed_appointments", {
                include_docs: true
            }, mainDBInstance);
            return resp;
        } catch (err) {
            logger.error(err);
            throw error = {
                err: err,
                msg: "failed to get all completed appointments"
            };
        }
    }
    foo.addCustomer2Order = function(requestData) {
        async function setCustomer4Order(data) {
            var tableNo = data.table_no;
            var orderNo = data.order_no;
            var response = {};
            response.status = status.ERR_UNDEFINED;
            try {
                let resp = await getAllSales(tableNo, orderNo);
                resp = await suspendSalesLib.setCustomer(resp, data.customer_id);

                response.status = status.SUCCESS;
                return response;
            } catch (err) {
                logger.error(err);
                return response;
            };
        }

        var response = {
            succs_customer_id: null
        };

        return setCustomer4Order(requestData).then(function(resp) {
            if (resp.status !== status.SUCCESS) {
                return response;
            }

            return _self.addCustomer2Sale(requestData);
        }).catch(function(err) {
            logger.error(err);
            return response;
        });
    };

    async function getAllSales(tableNo, orderNo) {
        try {
            let tableDoc = await couchDBUtils.getDoc('table_' + tableNo, mainDBInstance);
            let sales = [];
            for (let i = 0; i < tableDoc.orders.length; i++) {
                if (tableDoc.orders[i].order_no === orderNo) {
                    for (let j = 0; j < tableDoc.orders[i].Kots.length; j++) {
                        sales.push(tableDoc.orders[i].Kots[j].sale_id);
                    }
                    break;
                }
            }

            return sales;
        } catch (err) {
            logger.error(err);
            return [];
        }
    }

    /**
     *      loadAllOrderItemBeforeCheckOutRestApi
     */
    foo.loadAllOrdersToCart = function(requestData) {
        salesControllerLib.clear_all();

        var tableNo = requestData.table_no;
        var orderNo = parseInt(requestData.order_no);
        return getAllSales(tableNo, orderNo).then(function(resp) {
            return salesControllerLib.addSuspendedSalesToCart(resp);
        }).then(function(resp) {
            if (resp.status !== status.SUCCESS) {
                salesControllerLib.clear_all();
            }

            return prepareAndDispatchResponse();
        }).catch(function(err) {
            logger.error(err);
            salesControllerLib.clear_all();
            return prepareAndDispatchResponse();
        });
    };

    /**
     *      completeTakeOrderRestApi
     */
    foo.completeTakeOrder = function(requestData) {
        var response = {};
        return _self.completeSaleRestApi(requestData).then(function(resp) {
            var tableNo = requestData.table_no;
            response = resp;
            response.tableNo = tableNo;
            var promisesArray = [];
            var reservationId = requestData.reservation_id;
            if (!utils.isUndefinedOrNull(reservationId) && reservationId !== 0) {
                var query = {
                    where: {
                        reservation_id: reservationId
                    }
                };
                //NoSQLTodo: move this function to nosql
                // promisesArray.push(Models.profitGuru_table_reservation.destroy(query));

                var params = {
                    'reservation_id': reservationId
                };
                promisesArray.push(couchDBUtils.deleteReservation(tableNo, params, mainDBInstance));
            }
            promisesArray.push(deleteOrder(tableNo, requestData.order_no));
            return Promise.all(promisesArray);

        }).then(function() {
            return response;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    /**
     *  loadKotToCartRestApi
     */
    foo.loadKotToCart = function(requestData) {
        var saleId = requestData.sale_id;
        salesControllerLib.clear_all();
        return salesControllerLib.copy_entire_suspended_sale(saleId).then(function() {
            return prepareAndDispatchResponse(undefined, setRevAndId);
        }).catch(function(err) {
            logger.error(err);
            salesControllerLib.clear_all();
            return prepareAndDispatchResponse();
        });
    };

    /**
     *      get_max_order_numberRestApi
     */
    foo.getMaxOrderNo = function(requestData) {

        return couchDBUtils.getDoc('table_' + requestData.table_no, mainDBInstance).then(function(tableData) {
            return {
                order_no: (tableData.maxOrderNo + 1)
            };
        }).catch(function(error) {
            let errMsg = 'Table Not Found';
            logger.error(errMsg);
            return Promise.reject(errMsg);
        });
    };

    /**
     *      getDateRangesRestApi
     */
    foo.getDateRanges = function() {
        var response = {
            date_range: []
        };

        var dateRange = utils.getDateRangesJson();
        for (key in dateRange) {
            response.date_range.push({
                date: key,
                label: dateRange[key]
            })
        }

        return Promise.resolve(response);
    };

    foo.loadSale = function(requestData) {
        var response = {
            data: {},
            msg: ''
        };

        if (validator.isNumeric(requestData.saleId + '') === false) {
            response.msg = 'saleId should be a number';
            return Promise.reject(response);
        }

        return salesControllerLib.loadSaleHelper(requestData).then(function(resp) {
            response.data = resp;
            //check error code

            return response;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.multipleReprint = async function(saleIds) {
        var salesInfoArray = [];
        var SaleData = {};
        if (saleIds) {
            for (var id in saleIds) {
                SaleData = {
                    saleId: saleIds[id]
                };
                var saleDta = await _self.rePrint(SaleData);
                salesInfoArray.push(saleDta);
            }
        }

        return await salesInfoArray;
    }

    foo.rePrint = function(requestData) {
        var response = {
            data: {},
            message: ''
        };

        // if (validator.isNumeric(requestData.saleId + '') === false) {
        //     response.message = 'saleId should be a number';
        //     return Promise.reject(response);
        // }

        return salesControllerLib.getJsonForPrint(requestData, applicationSettings).then(function(resp) {
            response = resp;
            return response;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });
    };

    foo.makeCustomerCreditPayment = function(requestData) {
        requestData.employeeId = requestSession.user.name;
        return creditPaymentsLib.makeCustomerCreditPayment(requestData).then(function(response) {
            if (requestData.print_after_sale) {
                response.print_after_sale = requestData.print_after_sale;
                if (requestSession.clientType === 'MobileApp') {
                    utils.sendSocketEvent('printCreditReceipt', response);
                }
            }
            return response;
        }).catch(function(error) {
            logger.error(error);
            return Promise.reject(error);
        });
    };

    foo.resetSalesInfo = async function(type) {
        try {
            await commonLib.cleanTxnsByType(type);
            // setTimeout(async function() {
            //     // let saleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);

            //     // for (let i = 0; i < saleDocs.length; i++) {
            //     //     console.log(saleDocs[i].id);
            //     //     await _self.deleteSaleById(saleDocs[i].id);

            //     // }
            //     await commonLib.cleanTxnsByType('sale');
            // }, 20000);

            // saleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
            // if (saleDocs.length !== 0) {
            //     for (let i = 0; i < saleDocs.length; i++) {

            //         await _self.deleteSaleById(saleDocs[i].doc._id);

            //     }
            // }
            return;
        } catch (error) {
            console.log(error);
            logger.error(error);
            throw 'ResetSalesInfo Failed';
        }
    }

    foo.deleteSaleById = async function(docId) {
        let respArry = [];
        for (let i = 0; i < docId.length; i++) {
            respArry.push(await commonLib.reverseTransaction(docId[i], undefined, undefined, applicationSettings.bUpdateStockOnSalesDelete));
        }
        return respArry;
    }

    foo.rejectSale = function(params) {
        return commonLib.reverseTransaction(params.id, params.breject, params.reason, applicationSettings.bUpdateStockOnSalesDelete);
    }

    foo.getSalesDocById = function(saleId) {
        return commonLib.getTansDocument(saleId);
    }

    /**
     * Taxes
     * Inc/Ex Tax
     * If he deletes item .. exception will come
     */
    foo.initEditSalesSession = async function(requestData) {
        try {
            let saleDoc = await commonLib.getTansDocument(requestData.saleId);
            if (saleDoc.status.status) {
                throw {
                    'message': 'Not ready for Edit'
                };
            }
            await _self.cancel_saleRestApi();
            let temParamFields = ['wcInfo', 'sale_time', 'shippingDetails', 'checkNo', 'comment', 'state_name'];
            var tempParams = {};
            for (var i = 0; i < temParamFields.length; i++) {
                tempParams[temParamFields[i]] = saleDoc.sales_info[temParamFields[i]];
            }
            salesControllerLib.setTempDetails(tempParams);

            for (var i = 0; i < saleDoc.sale_items.length; i++) {
                //ganesh
                var params = {
                    item: saleDoc.sale_items[i].item_id,
                    stockKey: saleDoc.sale_items[i].stockKey,
                    discount: saleDoc.sale_items[i].discount_percent,
                    price: saleDoc.sale_items[i].sellingPrice,
                    quantity: saleDoc.sale_items[i].quantity_purchased,
                    bSPTaxInclusive: saleDoc.sale_items[i].bSPTaxInclusive,
                    itemTaxList: saleDoc.sale_items[i].itemTaxList,
                    warranty: saleDoc.sale_items[i].warranty,
                    warrantyTerms: saleDoc.sale_items[i].warrantyTerms,
                    appointmentData: saleDoc.sale_items[i].appointmentData,
                    membershipDiscount: saleDoc.sale_items[i].membershipDiscount ? saleDoc.sale_items[i].membershipDiscount : 0,
                }
                if (saleDoc.sale_items[i].ItemType == 'Membership') {
                    params.membership = saleDoc.sale_items[i].membership;
                }
                if (saleDoc.sale_items[i].serialnumber || saleDoc.sale_items[i].imeiNumbers.length) {
                    params.uniqueDetails = {};

                    if (saleDoc.sale_items[i].serialnumber) {
                        params.uniqueDetails.serialnumber = saleDoc.sale_items[i].serialnumber;
                    }
                    if (saleDoc.sale_items[i].imeiNumbers.length) {
                        params.uniqueDetails.imeiNumbers = saleDoc.sale_items[i].imeiNumbers;
                    }
                }

                await _self.additemRestApi(params);
            }

            if (saleDoc.sales_info.customer_id) {
                await _self.addCustomer2Sale({
                    'customer_id': saleDoc.sales_info.customer_id
                });
            }
            salesControllerLib.handleIsAppointmentFlag();
            if (salesControllerLib.getIsAppointment()) {
                await salesControllerLib.setAppointmentDate(saleDoc.sales_info.appointmentDate);;
            }
            if (saleDoc.sales_info.employee_id) {
                await _self.addEmployee2Sale({
                    'employee_id': saleDoc.sales_info.employee_id
                });
            }

            let globalDiscountInfo = saleDoc.sales_info.globalDiscountInfo;
            if (globalDiscountInfo) {
                globalDiscountInfo.value = globalDiscountInfo.percent;
                globalDiscountInfo.bPercent = true;
                await _self.setGlobalDiscount(globalDiscountInfo);
            }
            let resp = await commonLib.addPaymentsForEdit(saleDoc.payments, _self.add_paymentRestApi, true);
            return resp;
        } catch (error) {
            throw error;
        }

    }

    foo.getOrderBill = async function(requestData) {
        /** 
         * for simpler bill only name, qty , total;
                 let tableData = await couchDBUtils.getDoc('table_' + requestData.table_no, mainDBInstance, 'Failed to fetch the table details');
         let orderDetails = {};
         for (var i = 0; i < tableData.orders.length; i++) {
             if (tableData.orders[i].order_no === parseInt(requestData.order_no)) {
                 orderDetails = tableData.orders[i];
                 break;
             }
         }
         let orderItems = [];
         let totalBillAmount = 0;
         for (var j = 0; j < orderDetails.Kots.length; j++) {
             for (var k = 0; k < orderDetails.Kots[j].kot_items.length; k++) {
                 totalBillAmount += orderDetails.Kots[j].kot_items[k].item_total;
                 orderItems.push(orderDetails.Kots[j].kot_items[k]);

             }
         }
         orderDetails.table_no = tableData.table_no;
         orderDetails.itemsList = orderItems;
         orderDetails.orderTotal = totalBillAmount;
         delete orderDetails.Kots;

         return orderDetails;

         let resp = await _self.completeTakeOrder(requestData, 1);
         */
        let resp = await _self.loadAllOrdersToCart(requestData);
        salesControllerLib.clear_all();
        resp.tableNo = requestData.table_no;
        resp.order_no = requestData.order_no;
        return resp;
    }

    return foo;
}

module.exports = function(requestSession, applicationSettings) {
    return salesController(requestSession, applicationSettings);
};