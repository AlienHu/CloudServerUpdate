"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const couchDBUtils = require("./common/CouchDBUtils");
const logger = require("../common/Logger");
const coreDBInstance = couchDBUtils.getCoreCouchDB();
exports.save = function (base64) {
    return __awaiter(this, void 0, void 0, function* () {
        logger.info("*** appLogo.save");
        let response = {};
        let bCreate = false;
        let appLogo;
        try {
            appLogo = yield couchDBUtils.getDoc('appLogo', coreDBInstance, 'propagate');
        }
        catch (error) {
            if (error.reason === 'missing' || error.reason === 'deleted') {
                logger.info('appLogo is missing creating appLogo ...');
                bCreate = true;
            }
        }
        try {
            if (bCreate) {
                appLogo = {
                    _id: 'appLogo',
                    logo: base64
                };
            }
            else {
                appLogo.logo = base64;
            }
            yield couchDBUtils.createOrUpdate(appLogo, coreDBInstance);
        }
        catch (error) {
            logger.error(error);
            response.error = 'logo save failed';
            throw response;
        }
        response.msg = 'Logo saved';
        return response;
    });
};
//# sourceMappingURL=appLogo.js.map