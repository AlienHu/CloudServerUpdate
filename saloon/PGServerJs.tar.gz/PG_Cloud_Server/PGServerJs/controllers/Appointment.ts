import { APPOINTMENT } from "../types/saloon/dataInterfaces/appointment";
import { RESPONSE, STATUS, APPOINTMENTS } from "../types/saloon/functionInterface/status";
// const cauch_db_utils = require("../controllers/common/CouchDBUtils");
import * as cauch_db_utils from "../controllers/common/CouchDBUtils";

const mainDBInstance = cauch_db_utils.getMainCouchDB();
let couchUsersDbUrl = `http:// ${process.env.COUCHDB_USERNAME}:${process.env.COUCHDB_PASSWORD}@127.0.0.1:${process.env.COUCH_PORT}`;
// var nano = require('nano-blue')(couchUsersDbUrl);

export const postAppointment = async function (payload: APPOINTMENT) {
    /* dump json into db */
    let response: STATUS;
    try {
        // console.log('appointment', payload);
        let insertResult = await cauch_db_utils.create(payload, mainDBInstance, 2, 'Coutch Db insert issue');
        // console.log("insert=======", insertResult);
        response = { code: "success", message: 'sucessfully added', data: insertResult };
        console.log('----------response---------', response);
        return response;
    } catch (e) {
        console.log('errr========', e);
        response = { code: "failed", message: 'failed to add', data: e };
        return response;
    }
};

export const putAppointment = async function (payload: APPOINTMENT) {
    /* dump json into db */
    let response: STATUS;
    try {
        console.log('appointment', payload);
        let updateResult = await cauch_db_utils.update(payload, mainDBInstance, 2, 'Coutch Db update issue');
        console.log("updateResult=======", updateResult);
        response = { code: "success", message: 'sucessfully update', data: updateResult };
        return response;
    } catch (e) {
        console.log('errr========', e);
        response = { code: "failed", message: 'failed to update', data: e };
        return response;
    }
};

export const getAllAppointments = async function () {
    try {
        let resp = await cauch_db_utils.getView('all_saloon_data', 'all_saved_appointments', { include_docs: true }, mainDBInstance)
        return resp;
    } catch (e) {
        let err = {
            message: 'failed',
            error: e
        };
        throw err;
    }
};

export const getAppointmentById = async function (id) {
    try {
        let resp = await cauch_db_utils.getDoc(id, mainDBInstance)
        return resp;
    } catch (e) {
        let err = {
            message: 'failed',
            error: e
        };
        throw err;
    }
};




//let itemDoc = await cauch_db_utils.getdoc('item_'+ service_id, mainDBInstance);
