import * as couchDBUtils from './common/CouchDBUtils';
import * as logger from '../common/Logger';
const mainDBInstance: any = couchDBUtils.getMainCouchDB();
const CUSTOMER_TAGS = 'customer_tags'

export let importElements = function (data) {

}
export let updateTags = async function (tags: string[]): Promise<string> {

    //console.log("*** updateTags" + JSON.stringify(tags, null, 2));
    let allTagsDoc: CustomerTags = {
        _id: CUSTOMER_TAGS,
        tags: []
    };
    try {
        allTagsDoc = await couchDBUtils.getDocEx(CUSTOMER_TAGS, mainDBInstance);
    } catch (error) {
        if (error.reason !== 'missing') {
            throw 'Tags get failed'
        }
        logger.log("*** Missing doc, creating customer tags...")
    }
    try {
        let bUpdate: boolean = false;
        tags.forEach(function (tg) {
            if (allTagsDoc.tags.indexOf(tg) === -1) {
                bUpdate = true;
                allTagsDoc.tags.push(tg);
            }
        });
        if (bUpdate) {
            await couchDBUtils.createOrUpdate(allTagsDoc, mainDBInstance);
        }
    } catch (error) {
        logger.error(error);
        throw "Tags update failed"
    }
    return 'Tags updated successfully';
}

export interface CustomerTags {
    _id: string,
    tags: Tag[]
}

type Tag = string;