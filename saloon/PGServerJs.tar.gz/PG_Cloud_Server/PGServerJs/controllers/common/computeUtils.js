var computeUtils = function() {

    var _self = this;

    /**
     * in place formatting. Input is modified
     */
    this.formatGSTTaxes = function(taxes, bLocalTax) {
        for (let i = 0; i < taxes.length; i++) {
            let tax = taxes[i];
            /**
             * Assumption: CGST, SGST, IGST are restricted from UI
             * Assumption: GST is also capital Letter and constraints are imposed from UI
             */
            if (tax.name === 'GST') {
                taxes.splice(i, 1);
                if (bLocalTax) {
                    taxes.push({
                        name: 'CGST',
                        percent: tax.percent / 2
                    });
                    taxes.push({
                        name: 'SGST',
                        percent: tax.percent / 2
                    });
                } else {
                    taxes.push({
                        name: 'IGST',
                        percent: tax.percent
                    });
                }

                break;
            }
        }
    };

    this.getTaxFromSlab = function(slab, price) {
        let rates = slab.rates;
        let percent = 0;
        for (let i = 0; i < rates.length; i++) {
            if (price >= rates[i].min && price <= rates[i].max) {
                percent = rates[i].percent;
                break;
            }
        }

        return {
            name: slab.taxName,
            percent: percent
        };
    };

    this.getSlabFromTax = function(slab, itemTaxList) {
        //get gst percent
        //get slab
        let taxPercent = -1;

        for (let i = 0; i < itemTaxList.length; i++) {
            if (itemTaxList[i].name.indexOf('CGST') > -1) {
                taxPercent = itemTaxList[i].percent * 2;
                break;
            } else if (itemTaxList[i].name.indexOf('IGST') > -1) {
                taxPercent = itemTaxList[i].percent;
                break;
            }
        }

        if (taxPercent === -1) {
            throw 'getSlabFromTax:: Not expected to come here.';
        }

        let matchedSlab;
        for (let i = 0; i < slab.rates.length; i++) {
            if (slab.rates[i].percent === taxPercent) {
                matchedSlab = slab.rates[i];
                break;
            }
        }
        if (!matchedSlab) {
            throw 'getSlabFromTax2:: Not expected to come here.';
        }

        return matchedSlab;
    };

    this.calculatePriceExcludingTax = function(price, taxPercent) {
        var factor = 1 + (taxPercent * 0.01);
        var priceExTax = price / factor;

        return priceExTax;
    };

    this.getTotalTaxPercent = function(taxes) {
        var totalTaxPercent = 0;

        for (var taxIdx in taxes) {
            var tax = taxes[taxIdx].taxInfo;
            totalTaxPercent += tax.percent;
        }

        return totalTaxPercent;
    };

    this.getTotalTaxPercent2 = function(taxes) {
        var totalTaxPercent = 0;

        for (var taxIdx in taxes) {
            totalTaxPercent += taxes[taxIdx].percent;
        }

        return totalTaxPercent;
    };

    this.getPriceTaxEx = function(price, bTaxInclusive, totalTaxPercent) {
        var priceExcludingTax = price;
        if (bTaxInclusive) {
            priceExcludingTax = _self.calculatePriceExcludingTax(price, totalTaxPercent);
        };

        return priceExcludingTax;
    };
    this.computepxax0dot01 = function(p, a) {
        return (p * a * 0.01);
    };

};
module.exports = new computeUtils();