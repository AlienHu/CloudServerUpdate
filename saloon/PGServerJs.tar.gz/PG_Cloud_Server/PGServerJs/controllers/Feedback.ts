const utils = require("../controllers/common/Utils");
const cauch_db_utils = require("../controllers/common/CouchDBUtils");
const coredbInstance = cauch_db_utils.getCoreCouchDB();
const mainDb = cauch_db_utils.getMainCouchDB();
const helper = require("../licencer/licenceHelper")

let feedCtrl = function () {

    this.add_feedback = async (req) => {
        try {
            let response = {
                error: true,
                message: "",
                data: {}
            };
            let app_type = process.env.APP_TYPE;

            let unique_feedback_id = Date.now();
            let request_body = req.generated_form;

            let payload = {
                _id: `feedbackForm_${unique_feedback_id}`,
                form: request_body.form,
                id: unique_feedback_id,
                title: request_body.title
            };

            let create_feed_db = await coredbInstance;
            if (!create_feed_db) {
                response.message = "DB Not Found";
                throw response;
                // res.send(response_payload)
            } else {
                let insrt_db = await create_feed_db.insert(payload);
                let response_data = { msg: "successfully added", data: { success: insrt_db } };
                return response_data;
                // res.send();
            }
        } catch (e) {
            // res.send({msg: "Failed added", err: e})
            throw e
        }
    };

    this.getFeedBackForm = async (req) => {
        try {
            let response = {
                error: true,
                message: "",
                data: {}
            };
            let create_feed_db = await coredbInstance;
            if (!create_feed_db) {
                response.message = "DB Not Found";
                throw response;
            } else {
                let get_data = await cauch_db_utils.getAllDocsByType("feedbackForm", create_feed_db);
                console.log('get_data', get_data);
                let response_data = { msg: "successfully added", data: { success: get_data } };
                return response_data;
            }
        } catch (e) {
            console.log('e', e)
            throw e;
        }
    }
    this.deleteFeedBackForm = async (req) => {
        try {
            let create_feed_db = await coredbInstance;
            if (!create_feed_db) {
                let response = {
                    message: ''
                };
                response.message = "DB Not Found";
                throw response;
            } else {
                let get_data = await cauch_db_utils.delete(req.body, create_feed_db);
                console.log('get_data', get_data);
                let response_data = { msg: "successfully added", data: { success: get_data } };
                return response_data;
            }
        } catch (e) {
            console.log('e', e)
            throw e;
        }
    }
    interface repliesReportInput {
        feedbackFormId?: number,
        questionId?: number,
        customerId?: number,
        dateStart?: string,
        dateEnd?: string
    }

    interface formFormat {
        [index: number]: formFormat;
    }
    interface responseFormat {
        message?: string,
        error?: boolean,
        data: repliesOutput[]
    }
    interface repliesOutput {
        feedbackFormId?: number,
        title?: number,
        form?: formFormat,
        replies?: formFormat[]
    }

    interface queryParam {
        startKey?: string,
        endKey?: string
    }

    //paging
    /**
     * paging
     * accumulated stats - background thread
     * customer -> do using views -> in memory is not ideal
     */
    this.getRepliesForForm = async function (param) {
        /*
        f_time_formId
        */
        let startKey = 'f', endKey = 'f';
        startKey += param.dateStart ? "_" + param.dateStart : "_1000000000000";
        startKey += param.feedbackformId ? "_" + param.feedbackformId : "_a";
        endKey += param.dateEnd ? "_" + param.dateEnd : "_9999999999999";
        endKey += param.feedbackformId ? "_" + param.feedbackformId : "_z";
        // var response: responseFormat;
        var response = {
            error: true,
            message: "",
            data: []
        };
        // var queryParam: queryParam;
        var queryParam = {
            startKey: startKey,
            endKey: endKey
        }
        try {
            let dbInstance = await mainDb;
            if (!dbInstance) {
                response.message = "DB Not Found";
            } else {
                let replies = await cauch_db_utils.getView("all_feedback_data", "all_feedback_replies", queryParam, dbInstance);
                console.log('get_data', replies);
                response = {
                    error: false,
                    message: "Success",
                    data: replies
                };
                return response;
            }
        } catch (e) {
            console.log('e', e)
            response.message = "Error finding replies.";
        }
        response.data = [];
        throw response;
    }
};

module.exports = new feedCtrl();
// try {
//     var x = new feedCtrl();
//     var y = x.getRepliesForForm();
//     console.log(y);
// }
// catch (err) {
//     console.log(err);
// }
