import * as cron from 'cron';
import * as moment from 'moment';
import * as logger from '../../common/Logger'
import * as couchDBUtils from '../common/CouchDBUtils';
import * as crmSMSHelper from './crmSMSHelper';
import Moment = moment.Moment;
import { COMPLETED, Campaign, ScheduledCampaign, Timestamp, ScheduleStatus, PENDING, FAILED, CmpCustomers, Wisher, WISHER } from '../crm';
import * as scheduleCampaignHelper from './scheduleCampaignHelper';
import { Customer } from '../interfaces/customer';
const mainDBInstance: any = couchDBUtils.getMainCouchDB();
const RETRY_TIME_INTR_IN_MIN = 2;
let JOB_FREQUENCY = 60;//in seconds
const MAX_RETRY_COUNT = 3;
let MAX_RETRY_COUNT_STR: string = MAX_RETRY_COUNT.toString();
if (MAX_RETRY_COUNT < 10) {
    MAX_RETRY_COUNT_STR = '0' + MAX_RETRY_COUNT_STR;
}
export let setJobFrequency = function (f: number) {
    if (f === JOB_FREQUENCY) {
        return;
    }

    JOB_FREQUENCY = f;
    job.stop();
    job = new cron.CronJob({
        cronTime: '*/' + JOB_FREQUENCY + ' * * * * *',
        // cronTime: '* * * * * *',
        onTick: onTick,
        start: false,
        timeZone: 'Asia/Colombo'
    });
    job.start();
}
async function getAllPendingCampaigns(viewName: string) {
    // http://localhost:5984/pg_collection_retail_maindb/_design/crm/_view/pending_cmp?endkey="11-2518766603776"
    let params = {
        endkey: MAX_RETRY_COUNT_STR,
        include_docs: true
    };
    let results = await couchDBUtils.getView('crm', viewName, params, mainDBInstance);
    return results;
}

let bPause = false;

export let pause = function pause() {
    bPause = true;
};

export let play = function play() {
    bPause = false;
};

let job = new cron.CronJob({
    cronTime: '*/' + JOB_FREQUENCY + ' * * * * *',
    // cronTime: '* * * * * *',
    onTick: onTick,
    start: false,
    timeZone: 'Asia/Colombo'
});

export let isRunning = function (): boolean {
    return job.running;
};

export let startJob = function () {
    if (!job.running) {
        logger.info("Scheduler started");
        job.start();
    } else {
        logger.info("Scheduler is running");
    }

};

let bInTick = false;

async function onTick() {
    if (bInTick) {
        logger.info('Processing.. come later');
        return;
    }
    bInTick = true;
    try {
        logger.info('*** job onTick');
        if (bPause) {
            return true;
        }

        await processCampaigns();
        await processScheduledCampaigns();
        await processWisher();

        await killSelf();
    } catch (error) {
        logger.error(error);
        logger.error('onTick catch block');
    } finally {
        bInTick = false;
    }
}

async function killSelf(): Promise<void> {
    let allFuturePendingCapaigns = await getAllPendingCampaigns('pending_cmp');
    let allpendingSchedules = await getAllPendingCampaigns('pending_schedules');
    let allPendingWishers = await getAllPendingCampaigns('pending_wishers');
    if (allFuturePendingCapaigns.length === 0 && allpendingSchedules.length === 0 && allPendingWishers.length === 0) {
        logger.info('*** job stopping');
        job.stop();
    }
}

async function getBdayCustomers(type, startDate, endDate): Promise<CmpCustomers[]> {
    try {
        let customerDocArr = await couchDBUtils.getAllDocsByType('customer', mainDBInstance);
        let start: Moment = moment(startDate);
        let end: Moment = moment(endDate);
        let bcArr: CmpCustomers[] = [];
        let wishCusArr: CmpCustomers[] = customerDocArr.filter(item => {
            let cus: Customer = item.doc;
            if (!cus[type]) {
                return;
            }
            let eDate = moment(cus[type]);
            console.log(eDate);
            if (eDate >= start && eDate <= end) {
                console.log(start, end);
                bcArr.push({
                    _id: cus._id,
                    status: 'pending',
                    email: cus.email
                })
                return true;
            }
            return false;
        });
        return bcArr;
    } catch (e) {
        throw e
    }
}

/** 
 * step2: update doc with acampaign for today .. step1: check the doc if it has acampaign for today
 * schCmp._id = 'aschedule_' + doc._id + '_' + ts_date; this will autofail in step 3
 * add schedule in wish doc only and make the prev schedule empty
*/
async function processWisher(): Promise<void> {
    try {
        let ts: string = moment().startOf('day').toISOString();
        let day: number = parseInt(moment().format('e'));
        let allPendingWishers = await getAllPendingCampaigns('pending_wishers');
        allPendingWishers.forEach(async (element) => {
            let doc: Wisher = element.doc;
            if (doc.dayOfWeekArr.indexOf(day) === -1) {
                return;
            }
            if (doc.startDate && doc.startDate === ts) {
                return;
            }
            let daysBefore = doc.daysBefore;
            if (doc.onType === "true") {
                daysBefore = 0; // send sms only on birthdays
            }
            doc.startDate = ts;
            if (doc.onType === "false" && doc.repeat === "false") {
                ts = moment().add(daysBefore, 'days').startOf('day').toISOString();//send sms only once.
            }
            let bdate = moment().add(daysBefore, 'days').endOf('day').toISOString();
            doc.customers = await getBdayCustomers(doc.type, ts, bdate);
            doc.endDate = bdate;
            scheduleCampaignHelper.generateSchedules(doc);
            console.log("Created wisher" + JSON.stringify(doc, null, 2));
            doc.scheduleStatusArr.forEach(function (item) { // just to log the date in IST
                let d = new Date(parseInt(item.timestamp));
                console.log(d);
            });
            await couchDBUtils.update(doc, mainDBInstance);
        });
    } catch (e) {
        throw e;
    }
}

async function processCampaigns(): Promise<void> {
    try {
        let ts: string = moment().format('x');
        let allpendingCampaigns = await getAllPendingCampaigns('pending_cmp');

        if (!allpendingCampaigns.length) {
            return;// kill the scheduler???
        }

        let docArray = [];
        // allpendingCampaigns.forEach(async function (cmp) {
        for (let i = 0; i < allpendingCampaigns.length; i++) {
            let cmp = allpendingCampaigns[i];
            if (cmp.value > ts) {
                //future campaign so skipping
                continue;
            }

            let doc: Campaign = cmp.doc;

            let totalC = doc.customers ? doc.customers.length : 0;
            let count = await crmSMSHelper.sendPromos(doc);

            if (totalC === count) {
                doc.status = COMPLETED;
            } else {
                doc.nextTime = moment().add(RETRY_TIME_INTR_IN_MIN, 'minutes').format('x');
                doc.retryCount = doc.retryCount ? doc.retryCount + 1 : 1;
                if (doc.retryCount >= MAX_RETRY_COUNT) {
                    doc.status = 'failed';
                }
            }
            docArray.push(doc);
        }
        // });

        //bulk update
        await couchDBUtils.bulkDocs(docArray, mainDBInstance);
    } catch (error) {
        logger.error(error);
        logger.error('OnTick Campaigns Error');
        throw error;
    }
}

async function processScheduledCampaigns() {
    try {
        let ts: string = moment().format('x');
        let allpendingSchedules = await getAllPendingCampaigns('pending_schedules');

        if (!allpendingSchedules.length) {
            return;// kill the scheduler???
        }

        let docArray = [];
        // allpendingCampaigns.forEach(async function (cmp) {
        for (let i = 0; i < allpendingSchedules.length; i++) {
            let schedule = allpendingSchedules[i];
            // console.log(schedule.value, ts);
            if (schedule.value > ts) {
                //future campaign so skipping
                continue;
            }

            let doc: ScheduledCampaign = schedule.doc;

            let totalC = doc.customers ? doc.customers.length : 0;
            let count = await crmSMSHelper.sendPromos(doc);

            doc.nextTime = getNextScheduledTime(doc, totalC === count);
            docArray.push(doc);
        }
        // });

        //bulk update
        await couchDBUtils.bulkDocs(docArray, mainDBInstance);
    } catch (error) {
        logger.error(error);
        logger.error('OnTick Scheduled Campaigns Error');
        throw error;
    }
}
function resetCusStatus(cmpCusArr: CmpCustomers[]): void {
    cmpCusArr.forEach(cus => { cus.status = 'pending' });
}
function getNextScheduledTime(doc: ScheduledCampaign, bCompleted: boolean): Timestamp {
    let nextTime: Timestamp;
    for (let i: number = 0; i < doc.scheduleStatusArr.length; i++) {
        if (doc.scheduleStatusArr[i].status === PENDING) {
            doc.retryCount = doc.retryCount ? doc.retryCount + 1 : 1;
            if (bCompleted) {
                doc.scheduleStatusArr[i].status = COMPLETED;
            } else if (doc.retryCount >= MAX_RETRY_COUNT) {
                doc.scheduleStatusArr[i].status = FAILED;
            }

            nextTime = moment().add(RETRY_TIME_INTR_IN_MIN, 'minutes').format('x');
            if (bCompleted || doc.retryCount >= MAX_RETRY_COUNT) {
                if ((i + 1) === doc.scheduleStatusArr.length) {
                    //finished all schedules so break and mark it as completed
                    nextTime = undefined;
                    break;
                }
                doc.retryCount = 0;
                nextTime = doc.scheduleStatusArr[i + 1].timestamp;
                resetCusStatus(doc.customers);
            }
            break;
        }
    }

    if (nextTime === undefined && doc._id.indexOf(WISHER) === -1) {
        doc.status = COMPLETED;
    }

    return nextTime;
}

export let processWisher4UT = processWisher;
export let getBdayCustomers4UT = getBdayCustomers;