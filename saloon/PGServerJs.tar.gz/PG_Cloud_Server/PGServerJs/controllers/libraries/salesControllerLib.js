/*jshint sub:true*/
var itemsController = require('../Items.js');
const globalConfigurations = require('../GlobalConfigurations');
var validator = require('validator');
var BPromise = require("bluebird");
var math = require('mathjs');
var logger = require('../../common/Logger');
var utils = require('../common/Utils');
var status = require('../../common/StatusCode');
var couchDBUtils = require('../common/CouchDBUtils');
var computeUtils = require('../common/computeUtils');
var mainDBInstance = couchDBUtils.getMainCouchDB();
var moment = require('moment');
const itemsLib = require('./itemsControllerLib');
const ITEM_TYPE = itemsLib.ITEM_TYPE;
const salesLib2 = require('./salesControllerLib2');
const commonLib = require('./commonLib');
const ARRAY_LENGTH = utils.getArrayLength;
const IS_EMPTY_OBJECT = utils.isEmptyObject;
const ASSING_IFNOT_UNDEFINED = utils.assignifNotUndefined;
const CLONE = utils.clone;

module.exports = function(requestSession) {
    return salesControllerLib(requestSession);
};

function salesControllerLib(session) {

    let foo = {};
    var _self = foo;
    if (!session.salesTempInfo) {
        session.salesTempInfo = {}
    }

    if (!session.cart) {
        session.cart = [];
    }
    if (!session.isAppointment) session.isAppointment = false;
    if (!session.gDiscountMembership) session.gDiscountMembership = 0;
    if (!session.settings) {
        session.settings = {
            sales: {
                profile: {},
                bLocalTax: true
            }
        };
    }

    if (!session.settings.sales) {
        session.settings.sales = {
            profile: {},
            bLocalTax: true
        };
    }

    let bComputeTax = false;

    function formatProfileGSTTaxes() {
        if (IS_EMPTY_OBJECT(session.settings.sales.profile)) {
            return;
        }

        let taxes = session.settings.sales.profile.preparedTaxes;
        let formattedTaxes = [];
        for (let i = 0; i < taxes.length; i++) {
            formattedTaxes.push(taxes[i]);
        }

        computeUtils.formatGSTTaxes(formattedTaxes, session.settings.sales.bLocalTax);
        session.settings.sales.profile.formattedPreparedTaxes = formattedTaxes;
    }

    /**
     * profileId is optional
     * updating everytime getsales is called, as there may be change in taxes
     * It will get all the taxes, slab, charges from the db
     * This function is used in UT
     */
    foo.updateSalesProfileSettings = async function(profileId) {

        session.settings.sales.profileId = profileId;
        if (!profileId) {
            session.settings.sales.profile = {};
        }

        try {
            if (profileId) {
                session.settings.sales.profile = await globalConfigurations.getProfileInfo(profileId);
                formatProfileGSTTaxes();
            }

        } catch (error) {
            session.settings.sales.profile = {};
            logger.error(error);
            throw error;
        }
    };

    foo.setLocalTax = async function(bLocalTax) {
        session.settings.sales.bLocalTax = bLocalTax;
        formatProfileGSTTaxes();
        bComputeTax = true;
    };

    foo.setIsAppointment = function(bFlag) {
        session.isAppointment = bFlag;
    }

    foo.getIsAppointment = function() {
        return session.isAppointment;
    }

    async function prepareGlobalMembershipDiscount(membershipPercent) {
        if (!membershipPercent) membershipPercent = 0;
        let preGlobalDiscountInfo = {
            discountMethod: session.discountMethod ? session.discountMethod : foo.applicationSettings.salesConfig.discountMethod,
            value: session.gInputDiscountValue ? session.gInputDiscountValue : 0,
            bPercent: session.bGDiscountPercent,
            gDiscountMembership: session.gDiscountMembership ? session.gDiscountMembership : 0
        }
        if (preGlobalDiscountInfo.bPercent === undefined) preGlobalDiscountInfo.bPercent = true;
        if (preGlobalDiscountInfo.bPercent) {
            preGlobalDiscountInfo.value -= preGlobalDiscountInfo.gDiscountMembership;
            preGlobalDiscountInfo.gDiscountMembership = membershipPercent;
            preGlobalDiscountInfo.value += membershipPercent;
        } else {
            preGlobalDiscountInfo.value -= await getMembershipAmt(preGlobalDiscountInfo.gDiscountMembership);
            preGlobalDiscountInfo.gDiscountMembership = membershipPercent;
            preGlobalDiscountInfo.value += await getMembershipAmt(membershipPercent);
        }
        await foo.setGlobalDiscount(preGlobalDiscountInfo);
    }

    foo.setCartCustomerDetails = async function(customer_id) {
        var response = {
            status: status.ERR_UNDEFINED
        };

        if (!utils.isUndefinedOrNull(customer_id)) {

            if (session.gDiscountMembership) { // reset membership discount if customer changed
                await prepareGlobalMembershipDiscount(0);
            }

            return couchDBUtils.getDoc('customer_' + customer_id, mainDBInstance).then(function(customer4Cart) {
                if (customer4Cart) {
                    session.customerDetails = customer4Cart;
                    response.status = status.SUCCESS;
                    return response;
                }
                return response;
            }).catch(function(err) {
                logger.error(err);
                return response;
            });
        } else {
            session.customerDetails = {
                person_id: null
            };
            await prepareGlobalMembershipDiscount(0);
            return Promise.resolve(response);
        }
    };

    foo.getCartCustomerDetails = function() {
        if (utils.isUndefinedOrNull(session.customerDetails)) {
            session.customerDetails = {
                person_id: null
            };
        }
        return session.customerDetails;
    };

    foo.setCartEmployeeDetails = async function(empId) {
        var response = {
            status: status.ERR_UNDEFINED
        };
        let errMsg = "User does't exist";
        if (!utils.isUndefinedOrNull(empId)) {
            try {
                session.salesEmployeeInfo = await couchDBUtils.getDoc('org.couchdb.user:' + empId, couchDBUtils.getUserCouchDB(), errMsg);
                response.status = status.SUCCESS;
            } catch (ex) {
                throw errMsg;
            }
        } else {
            session.salesEmployeeInfo = null;
        }
        return response;

    };

    foo.getCartEmployeeDetails = function() {
        return session.salesEmployeeInfo;
    };

    foo.getProfileId = function() {
        return session.settings.sales.profileId;
    };

    foo.get_mode = function() {

        if (!session.sale_mode) {
            session.sale_mode = 'sale';
        }
        return session.sale_mode;
    };

    foo.setAppointmentDate = function(date) {
        session.appointmentDate = date;
    }

    foo.getAppointmentDate = function() {
        return session.appointmentDate;
    }

    foo.get_cart = function() {

        if (!session.cart) {
            session.cart = [];
        }
        return session.cart;
    };

    foo.set_cart = function(salesCartData) {
        session.cart = salesCartData;
    };
    foo.set_mode = function(mode) {
        session.sale_mode = mode;
    };

    foo.get_sale_location = function() {
        //TODO should return location and location name
        session.location_id = 1;
        return session.location_id;
    };

    foo.getSaleIdFromReceiptOrInvoiceNumber = function(receiptNumberOrInvoiceNumber) {

        var parts = receiptNumberOrInvoiceNumber.split(' ');
        if (parts.length === 2 && parts[0].toLowerCase() === 'pos') {
            var saleId = parts[1];
            return salesModel.isSaleExists(saleId);
        } else {

            return salesModel.getSaleIdFromInvoiceNumber(receiptNumberOrInvoiceNumber);
        }

    };

    foo.isValidItemKit = function(itemKitId) {

        //TODO find out why we need here split
        //itemKitId = itemKitId.split(' ', itemKitId)[1];
        return ItemKitsModel.findById(itemKitId);

    };

    foo.emptyCart = function() {
        session.cart = [];
    };

    /**
     *      Todo
     *          This calculation should include discount also, addItem2Cart calls with discount argument
     *          refer receivingsLib similar funciton           
     * 
     */
    function getItemTotal(quantity, price) {

        return math.multiply(quantity, price);
    }

    foo.setStatus = function(status) {
        session.status = status;
    }
    foo.getStatus = function(status) {
        return session.status;
    }

    foo.setLoggedInEmployee = function(name) {
        session.loggedInEmployee = name;
    }
    foo.getLoggedInEmployee = function(name) {
        return session.loggedInEmployee;
    }

    foo.get_subtotal = function(bIncludeDiscount, bIncludeCharges) {
        var subtotal = 0;
        var thisSalesCart = _self.get_cart();
        for (var index in thisSalesCart) {
            var item = thisSalesCart[index];
            if (bIncludeCharges) {
                // Price - Discount + Charges    
                subtotal += item.totalAfterDisAndCharges;
            } else if (bIncludeDiscount) {
                //No Charges
                subtotal += item.discounted_total;
            } else {
                //No Charges, No Discount
                subtotal += item.total;
            }

        }

        return subtotal;
    };

    foo.getTaxAmt = function(taxArray) {
        let taxAmt = 0;
        for (let tax in taxArray) {
            taxAmt += taxArray[tax];
        }
        return taxAmt;
    }
    foo.getAllCharges = function(thisSalesCart) {
        let allCharges = {};

        for (let index in thisSalesCart) {
            let item = thisSalesCart[index];
            for (let i = 0; i < ARRAY_LENGTH(item.chargesList); i++) {
                let chargeInfo = item.chargesList[i];
                let key = chargeInfo.name + ' @' + chargeInfo.percent;
                if (!allCharges.hasOwnProperty(key)) {
                    allCharges[key] = 0;
                }
                allCharges[key] += chargeInfo.Amt;
            }
        }

        return allCharges;
    };

    function removeMembershipOffers() {
        let cart = _self.get_cart();
        for (let i = 0; i < cart.length; i++) {
            if (cart[i].membershipDiscount) {
                cart[i].discount -= cart[i].membershipDiscount;
                cart[i].membershipDiscount = 0;
            }
        }
    }

    foo.removeCustomer = async function() {
        delete session.customer;
        delete session.customerDetails;
        var message = "successfully removed customer from cart";
        if (session.gDiscountMembership) { // reset membership discount if customer changed
            await prepareGlobalMembershipDiscount(0);
        }
        removeMembershipOffers();
        return message;
    };

    foo.removeSalesEmployee = function() {
        delete session.salesEmployeeInfo;
        var message = "successfully removed sales employee from cart";
        return message;
    };

    foo.setRefBookingId = function(id) {
        session.refBookingId = id;
    };

    foo.getRefBookingId = function(id) {
        return session.refBookingId;
    };

    foo.set_customer = function(customer_id) {
        session.customer = null;
        return foo.setCartCustomerDetails(customer_id).then(async function(resp) {

            if (!session.customerDetails.person_id) {
                if (session.gDiscountMembership) { // reset membership discount if customer changed
                    await prepareGlobalMembershipDiscount(0);
                }
                removeMembershipOffers();
            }
            if (session.customerDetails !== undefined) {
                session.customer = session.customerDetails.person_id;
            }

            return resp;
        }).catch(function(err) {
            if (session.customerDetails !== undefined) {
                session.customer = session.customerDetails.person_id;
            }
            return Promise.reject(err);
        });
    };

    foo.get_customer = function() {
        if (!session.customer) {
            session.customer = null;
        }
        return session.customer;
    };

    foo.get_taxes = function(bForReceipt) {
        var allCartTaxes = {};

        function getTaxesByName(taxes) {
            for (var j = 0; j < taxes.length; j++) {
                var taxName = taxes[j].name;
                if (!allCartTaxes[taxName]) {
                    allCartTaxes[taxName] = 0;
                }
                allCartTaxes[taxName] += taxes[j].Amt;
            }
        }

        for (var i = 0; i < session.cart.length; i++) {
            var taxes = session.cart[i].itemTaxList;
            getTaxesByName(session.cart[i].itemTaxList);
            getTaxesByName(session.cart[i].chargesTaxList);
        }

        //CommitTest   
        if (bForReceipt) {
            for (var taxName in allCartTaxes) {
                allCartTaxes[taxName] = +allCartTaxes[taxName].toFixed(2);
            }
        }

        return allCartTaxes;
    };

    foo.gettaxesByPercentage = function(bForReceipt) {
        var allCartTaxes = {};

        function getAllTaxes(taxes) {
            for (var j = 0; j < taxes.length; j++) {
                var taxName = taxes[j].name + ' @' + taxes[j].percent + '%';
                if (!allCartTaxes[taxName]) {
                    allCartTaxes[taxName] = 0;
                }
                allCartTaxes[taxName] += taxes[j].Amt;
            }
        }

        for (var i = 0; i < session.cart.length; i++) {
            var taxes = session.cart[i].itemTaxList;
            getAllTaxes(session.cart[i].itemTaxList);
            getAllTaxes(session.cart[i].chargesTaxList);

        }

        //CommitTest   
        if (bForReceipt) {
            for (var taxName in allCartTaxes) {
                allCartTaxes[taxName] = +allCartTaxes[taxName].toFixed(2);
            }
        }

        return allCartTaxes;
    };

    function getDetailedTaxByPerc(item, taxDetailedObj, taxNamesObj, hsnObj) {
        let taxes = item.itemTaxList;
        let hasHSN = (item.hsn) ? true : false;
        if (hasHSN && !hsnObj[item.hsn]) hsnObj[item.hsn] = {};
        for (var j = 0; j < taxes.length; j++) {
            let percent = (taxes[j].percent) ? taxes[j].percent.toString() : "0";
            let name = taxes[j].name;
            let amtTemp = taxes[j].Amt;
            if (hasHSN) {
                if (hsnObj[item.hsn][name] && hsnObj[item.hsn][name][percent]) {
                    hsnObj[item.hsn][name][percent] += amtTemp;
                    if (name != "SGST") hsnObj[item.hsn].taxable += item.totalAfterDisAndCharges;
                } else {
                    if (!hsnObj[item.hsn][name]) hsnObj[item.hsn][name] = {};
                    hsnObj[item.hsn][name][percent] = amtTemp;
                    hsnObj[item.hsn].taxable = item.totalAfterDisAndCharges;
                }
            }
            if (taxDetailedObj[percent] && taxDetailedObj[percent][name] || (taxDetailedObj[percent] && taxDetailedObj[percent][name] === 0)) {
                taxDetailedObj[percent][name] = taxDetailedObj[percent][name] + amtTemp;
                // sgst is hardcoded to avoid adding two times in case of cgst and sgst
                if (name != "SGST") taxDetailedObj[percent].taxable = taxDetailedObj[percent].taxable + item.totalAfterDisAndCharges;
            } else {
                if (!taxNamesObj[name]) taxNamesObj[name] = true;
                if (!taxDetailedObj[percent]) {
                    taxDetailedObj[percent] = {};
                    taxDetailedObj[percent].taxable = item.totalAfterDisAndCharges;
                }
                taxDetailedObj[percent][name] = amtTemp;
            }
        }

    }

    foo.gettaxesByPercentageDetailed = function(taxDetailedObj, taxNamesObj, hsnObj) {
        for (var i = 0; i < session.cart.length; i++) {
            getDetailedTaxByPerc(session.cart[i], taxDetailedObj, taxNamesObj, hsnObj);
        }
    };

    function findIndexOfItemByItemId(itemId, cart) {
        var index = -1;
        for (var index in cart) {
            if (cart[index].item_id === itemId /*&& cartItem.item_location == itemLocation*/ ) {
                index = index;
                break;
            }
        }

        return index;
    }

    function findIndexOfItemByLine(line, cart) {
        var index = -1;
        for (var index in cart) {
            if (cart[index].line === line) {
                index = index;
                break;
            }
        }

        return index;
    }

    /**      
     * @param {*json having all the information on taxes} profile 
     * @param {*Ingredient Should Not come here} itemType 
     */
    function getProfileTaxesByItemType(profile, itemType) {
        if (!ITEM_TYPE.hasOwnProperty(itemType)) {
            logger.error('Unknown Item Type<' + itemType + '>');
            throw 'Internal Error';
        }

        let key = itemType.toLowerCase() + 'Taxes';
        return profile[key];
    }

    /**
     * 
     * @param {* Array salesTaxes 3rd priority} taxes 
     * @param {* Object salesSlab 1st priority} slab 
     * @param {* float depending on the price, tax rate for slab is decided} price 
     * @param {* Array output taxes} formattedTaxes      
     * This function is used in UTs other than in this file
     */
    foo.getTaxesForItem = function(taxes, slab, price, formattedTaxes, formattedChargesTaxes, bSPTaxInclusive, itemType) {

        let totalTaxPercent = 0;
        formattedTaxes.length = 0;
        formattedChargesTaxes.length = 0;
        /**
         * profile is stored in session. Every call to getSalesRestApi, the profile gets refreshed
         * This is not fool proof but okay
         */
        let profile = session.settings.sales.profile;
        let profileTaxes = [];
        if (profile) {
            if (IS_EMPTY_OBJECT(slab) && !IS_EMPTY_OBJECT(profile.slab)) {
                slab = profile.slab;
            }

            let taxes = getProfileTaxesByItemType(profile, itemType);
            if (ARRAY_LENGTH(taxes)) {
                profileTaxes = taxes;
            }
            taxes = profile.formattedPreparedTaxes;
            if (ARRAY_LENGTH(taxes)) {
                for (let i = 0; i < taxes.length; i++) {
                    formattedChargesTaxes.push({
                        name: taxes[i].name,
                        percent: taxes[i].percent
                    });
                }
            }
        }
        if (!IS_EMPTY_OBJECT(slab) && bSPTaxInclusive) {
            logger.error('tax slab and tax inclusive is not implemented');
            throw 'Internal Error';
        }

        let formattedTaxesCount = {};
        if (slab) {
            let taxFromSlab = computeUtils.getTaxFromSlab(slab, price);

            if (taxFromSlab.percent !== 0) {
                formattedTaxes.push(taxFromSlab);
                formattedTaxesCount[taxFromSlab.name] = 1;
                totalTaxPercent += taxFromSlab.percent;
            }
        }

        for (let taxIdx in taxes) {
            let tax = taxes[taxIdx].taxInfo;
            if (!formattedTaxesCount[tax.name]) {
                let itemTaxInfo = {};
                itemTaxInfo.name = tax.name;
                itemTaxInfo.percent = tax.percent;
                totalTaxPercent += tax.percent;
                formattedTaxes.push(itemTaxInfo);
                formattedTaxesCount[tax.name] = 1;
            }
        }

        for (let i = 0; i < profileTaxes.length; i++) {
            let tax = profileTaxes[i];
            if (!formattedTaxesCount[tax.name]) {
                formattedTaxes.push(tax);
                formattedTaxesCount[tax.name] = 1;
                totalTaxPercent += tax.percent;
            }
        }

        computeUtils.formatGSTTaxes(formattedTaxes, session.settings.sales.bLocalTax);
        return totalTaxPercent;
    }

    /**
     * BMTodo check proper usage of arguments. 
     * These may come from suspend sales or returns in which case these values only should be used instead from the item/batch table
     * pItemTaxList,pBSPTaxInclusive -- this is used when editing sale to use taxes from the sale document
     */
    function addItem2CartHelper(itemId, stockKey, quantity, itemLocation, discount, price, description, serialnumber, imeiNumbers, insertkey, pItemTaxList, pBSPTaxInclusive, appointmentData, membershipDiscount) {
        var itemQueryParams = {
            item_id: itemId,
            stockKey: stockKey
        };

        return itemsLib.getThisItemInfo(itemQueryParams).then(function(itemInfo) {
            if (!itemInfo) {
                return Promise.reject('Item Not Found ' + itemId);
            }

            if (itemInfo.batches.length === 0) {
                return Promise.reject('Out of Stock ' + itemInfo.name + ' stockKey ' + stockKey);
            }

            var batchInfo = itemInfo.batches[0];
            itemInfo.conversionFactor = itemInfo.conversionFactor ? itemInfo.conversionFactor : 1;
            var factor = math.divide(1, itemInfo.conversionFactor);

            //overwriting with discount from db
            if (discount === undefined && batchInfo.discount) {
                discount = batchInfo.discount.discount
            };

            if (!price) {
                price = batchInfo.sellingPrice; // utils.roundOffNumber(batchInfo.sellingPrice, foo.applicationSettings);
            };

            //Adding Item taxes                        
            var taxList = [];
            let chargesTaxList = [];
            var taxes = pItemTaxList;
            let slab = itemInfo.salesSlab;
            if (!pItemTaxList) {
                taxes = itemInfo.salesTaxes;
            } else {
                //for sale edit we are overwriting values
                taxes = [];
                for (let i = 0; i < pItemTaxList.length; i++) {
                    taxes.push({
                        taxInfo: pItemTaxList[i]
                    });
                }
                itemInfo.bSPTaxInclusive = pBSPTaxInclusive;
                slab = undefined;
            }
            var totalTaxPercent = _self.getTaxesForItem(taxes, slab, price, taxList, chargesTaxList, itemInfo.bSPTaxInclusive, itemInfo.ItemType);
            var sellingPriceExcludingTax = computeUtils.getPriceTaxEx(price, itemInfo.bSPTaxInclusive, totalTaxPercent);

            if (!IS_EMPTY_OBJECT(itemInfo.salesSlab) && itemInfo.bSPTaxInclusive) {
                logger.error('Not Implemented. Inclusive Tax and slab');
                return Promise.reject('Internal Error');
            }

            //purchase slabTax is not required for computation because inclusive tax no slab, for exclusive tax doesn't matter
            var totalPurchaseTaxPercent = computeUtils.getTotalTaxPercent(itemInfo.purchaseTaxes);
            var purchasePrice = math.multiply(batchInfo.purchasePrice, factor);
            var purchasePriceExTax = computeUtils.getPriceTaxEx(purchasePrice, itemInfo.bPPTaxInclusive, totalPurchaseTaxPercent);
            var purchaseTaxAmount = computeUtils.computepxax0dot01(totalPurchaseTaxPercent, purchasePriceExTax);
            var cartItem = {
                'item_id': itemId,
                'batchId': batchInfo.batchId,
                'ItemType': itemInfo.ItemType,
                'stockKey': stockKey,
                'item_location': itemLocation,
                'stock_name': batchInfo.stockLocation.location_name,
                'line': insertkey,
                'name': itemInfo.name,
                'item_number': itemInfo.item_number,
                'description': description !== null ? description : itemInfo.description,
                'serialnumber': serialnumber !== null ? serialnumber : '',
                'imeiNumbers': imeiNumbers ? imeiNumbers : [],
                'is_serialized': itemInfo.is_serialized,
                'hasBatchNumber': itemInfo.hasBatchNumber,
                'bOTG': itemInfo.bOTG,
                'hsn': itemInfo.hsn,
                'hasExpiryDate': itemInfo.hasExpiryDate,
                'bSPTaxInclusive': itemInfo.bSPTaxInclusive,
                'bPPTaxInclusive': itemInfo.bPPTaxInclusive,
                'expiry': batchInfo.expiry,
                'unit': itemInfo.sellingUnit.name,
                'quantity': quantity,
                'discount': discount ? discount : 0,
                'price': price,
                'sellingPriceExcludingTax': sellingPriceExcludingTax,
                'totalTaxPercent': totalTaxPercent,
                // 'loyaltyPerc': batchInfo.Discounts.loyaltyPerc,
                'purchasePrice': purchasePriceExTax, //This is added for reports purpose
                'purchaseTax': purchaseTaxAmount,
                'mrp': batchInfo.mrp,
                'reorder_level': itemInfo.reorderLevel,
                'imeiCount': itemInfo.imeiCount,
                'chargesList': [],
                'chargesTaxList': chargesTaxList,
                'isWarranty': itemInfo.isWarranty,
                'warranty': itemInfo.warranty,
                'warrantyTerms': itemInfo.warrantyTerms,
                'membership': itemInfo.membership,
                "serviceDuration": itemInfo.serviceDuration ? itemInfo.serviceDuration : 0,
                "taggedEmployees": itemInfo.taggedEmployees ? itemInfo.taggedEmployees : [],
                "employeeCommission": itemInfo.employeeCommission ? itemInfo.employeeCommission : 0
            };

            if (itemInfo.sellingUnit.shortName) {
                cartItem.unit = itemInfo.sellingUnit.shortName;
            }

            if (batchInfo.attributeInfo) {
                cartItem.attributeInfo = batchInfo.attributeInfo;
                cartItem.skuName = batchInfo.skuName;
            }

            cartItem.itemTaxList = taxList;
            cartItem.origTaxes = taxes;
            cartItem.slab = slab;
            cartItem.membershipDiscount = membershipDiscount;
            if (appointmentData) cartItem.appointmentData = appointmentData;
            else if (cartItem.ItemType === 'Service') assignDefaultAppointmentData(cartItem);
            var salesCart = _self.get_cart();
            salesCart.push(cartItem);

            return salesCart.length - 1;
        }).catch(function(err) {
            return Promise.reject(err);
        });
    }

    function getTimeHTMLFormat(time) {
        if (time) return new Date(moment(time).format('MM/DD/YYYY hh:mm A'));
        return new Date(moment().format('MM/DD/YYYY hh:mm A'));
    }

    function getEndTimeForService(startTime, minutesToAdd) {
        minutesToAdd = minutesToAdd ? parseInt(minutesToAdd) : foo.applicationSettings.defaultServiceDuration;
        if (isNaN(minutesToAdd)) minutesToAdd = parseInt(foo.applicationSettings.defaultServiceDuration); // parseInt fails
        var start = moment(startTime);
        var newStart = start.add(minutesToAdd, 'minutes');
        return getTimeHTMLFormat(newStart);
    }

    function assignDefaultAppointmentData(cartItem, dontAddDuration) {
        let fullCart = foo.get_cart();
        if (!cartItem.appointmentData) cartItem.appointmentData = {};
        if (!foo.ifCartHasService()) {
            cartItem.appointmentData.start = getTimeHTMLFormat();
        } else {
            cartItem.appointmentData.start = getImmediateLastServiceEndTime(cartItem.line);
        }
        cartItem.appointmentData.end = getEndTimeForService(cartItem.appointmentData.start, cartItem.serviceDuration);
        cartItem.appointmentData.employees = [handleDefaultEmployeeTagging(cartItem)];
    }

    foo.rearrangeServiceTimes = function() {
        let cart = foo.get_cart();
        for (let i = 0; i < cart.length; i++) {
            if (cart[i].ItemType !== 'Service') continue
            else {
                assignDefaultAppointmentData(cart[i], true);
            }
        }
    }

    function getImmediateLastServiceEndTime(currentLine) {
        let fullCart = foo.get_cart();
        let lineIndex = fullCart.length;
        for (let i = 0; i < fullCart.length; i++) {
            if (fullCart[i].line === currentLine) lineIndex = i;
        }
        for (let i = lineIndex - 1; i >= 0; i--) { // cur line is not added to cart, and line = index+1
            if (fullCart[i].ItemType != 'Service') continue;
            else {
                return getTimeHTMLFormat(fullCart[i].appointmentData.end)
            }
        }
        return getTimeHTMLFormat();
    }

    function handleDefaultEmployeeTagging(cartItem) {
        let loggedInEmployee = foo.getLoggedInEmployee();
        if (!cartItem.taggedEmployees || !cartItem.taggedEmployees.length) return loggedInEmployee;
        else if (checkSameEmployee(cartItem.taggedEmployees, loggedInEmployee)) return loggedInEmployee;
        else return cartItem.taggedEmployees[0].name;
    }

    //To check Weather Login Employee and Tagged Employee is Same
    function checkSameEmployee(taggedEmployeesDoc, loggedInEmployee) {
        for (let i = 0; i < taggedEmployeesDoc.length; i++) {
            if (taggedEmployeesDoc[i].name === loggedInEmployee) return true;
        }
        return false;
    }

    //Any computation for an item in cart
    function computeItemCart(cartItem, iAddDiscount) {
        var quantity = cartItem.quantity;
        var priceExcludingTax = cartItem.sellingPriceExcludingTax;

        var total = getItemTotal(quantity, priceExcludingTax);

        cartItem.gDiscountPercent = 0;
        if (cartItem.gDiscountValue) {
            cartItem.gDiscountPercent = cartItem.gDiscountValue;
            if (!cartItem.bGDiscountPercent) {
                cartItem.gDiscountPercent = 100 * cartItem.gDiscountValue / total;
            }
        }
        cartItem.discount = cartItem.discount ? cartItem.discount : 0;
        var discountPercent = (cartItem.discount + cartItem.gDiscountPercent) * iAddDiscount;
        var discountedPrice = getDiscountedPrice(total, discountPercent);
        var discountedTotal = getPriceAfterDiscount(total, discountedPrice);
        cartItem.gDiscountAmt = getDiscountedPrice(total, cartItem.gDiscountPercent);
        cartItem.total = total;
        cartItem.discounted_total = discountedTotal;
        cartItem.discounted_price = discountedPrice;

        let charges = session.settings.sales.profile.charges;
        cartItem.chargesList = [];
        if (ARRAY_LENGTH(charges)) {

            for (let i = 0; i < charges.length; i++) {
                cartItem.chargesList.push({
                    name: charges[i].name,
                    percent: charges[i].percent
                });
            }
        }

        let totalChargesAmt = 0;
        for (let i = 0; i < ARRAY_LENGTH(cartItem.chargesList); i++) {
            let chargesAmt = computeTax(discountedTotal, cartItem.chargesList[i].percent);
            cartItem.chargesList[i].Amt = chargesAmt;
            totalChargesAmt += chargesAmt;
        }
        cartItem.totalAfterDisAndCharges = discountedTotal + totalChargesAmt;
        cartItem.totalWithTax = cartItem.totalAfterDisAndCharges;

        cartItem.itemTaxList.forEach(function(itemTaxInfo) {
            let taxAmt = computeTax(discountedTotal, itemTaxInfo.percent);
            itemTaxInfo.Amt = taxAmt;
            cartItem.totalWithTax += taxAmt;
        });

        for (let i = 0; i < cartItem.chargesTaxList.length; i++) {
            let tax = cartItem.chargesTaxList[i];
            tax.Amt = computeTax(totalChargesAmt, tax.percent);
            cartItem.totalWithTax += tax.Amt;
        }
    }

    async function checkIfAlreadyHasMembership(customerId) {
        let membership = undefined;
        if (!customerId) return flag;
        let customerDoc = await couchDBUtils.getDoc('customer_' + customerId, mainDBInstance);
        if (customerDoc.membership && Object.keys(customerDoc.membership).length > 0) {
            membership = customerDoc.membership;
        }
        return membership;
    }
    async function setMembershipDiscount(membershipDetails) {
        if (membershipDetails.membership.offerScope == 'all') {
            // removeMembershipOffers();
            let discountPercentage = membershipDetails.membership.offerPercent;

            await prepareGlobalMembershipDiscount(discountPercentage);

        } else if (membershipDetails.membership.offerScope == 'category' || membershipDetails.membership.offerScope == 'items') {
            var cart = _self.get_cart();
            for (let i = 0; i < cart.length; i++) {
                if (membershipDetails.membership.offerScope == 'category') {
                    let itemInfo = await couchDBUtils.getDoc('item_' + cart[i].item_id, mainDBInstance);
                    if (itemInfo.info.categoryId) {
                        let discountPercentage = ifCategoryHasMembershipDiscount(membershipDetails, itemInfo.info.categoryId);
                        if (cart[i].membershipDiscount) { // reset if already added
                            cart[i].discount -= cart[i].membershipDiscount;
                        }
                        cart[i].discount += discountPercentage;
                        cart[i].membershipDiscount = discountPercentage;
                    }
                } else {
                    var discountPercentage = ifItemHasMembershipDiscount(membershipDetails, cart[i].item_id);
                    if (discountPercentage) {
                        if (cart[i].membershipDiscount) { // reset if already added
                            cart[i].discount -= cart[i].membershipDiscount;
                        }
                        cart[i].discount += discountPercentage;
                        cart[i].membershipDiscount = discountPercentage;
                    }
                }
                console.log(cart[i]);
            }
        }
    }

    function ifCategoryHasMembershipDiscount(membershipDetails, categoryId, elementType) {
        let discountPercentage = 0;
        if (!membershipDetails.membership.elements) return discountPercentage;
        for (let i = 0; i < membershipDetails.membership.elements.length; i++) {
            if (membershipDetails.membership.elements[i].doc.id === categoryId) return membershipDetails.membership.elements[i].discountPercentage;
        }
        return discountPercentage;
    }

    function ifItemHasMembershipDiscount(membershipDetails, item_id) {
        let discountPercentage = 0;
        if (!membershipDetails.membership.elements) return discountPercentage;
        for (let i = 0; i < membershipDetails.membership.elements.length; i++) {
            if (membershipDetails.membership.elements[i].item_id === item_id) return membershipDetails.membership.elements[i].discountPercentage;
        }
        return discountPercentage;
    }

    foo.handleDiscountForMembership = async function() {

        let customer = _self.getCartCustomerDetails();
        if (!customer.person_id) return;
        // put this in setCustomer only
        let membershipDoc = await checkIfAlreadyHasMembership(customer.person_id);
        if (!membershipDoc) return;
        let membershipStarted = moment(membershipDoc.date);
        let membershipDetails = await couchDBUtils.getDoc('item_' + membershipDoc.item_id, mainDBInstance);
        let isExpiry = membershipDetails.info.isWarranty;

        if (isExpiry) {
            let durationFormat = 'day';
            let durationValue = membershipDetails.info.warranty;
            if (!durationValue || durationValue < 0) return;
            if (membershipDetails.info.warrantyTerms == 'M') {
                durationValue *= 30;
                // durationFormat = 'month';
            } else if (membershipDetails.info.warrantyTerms == 'Y') {
                durationValue *= 365;
                // durationFormat = 'year';
            }
            // duration format is days....converting to days when month or year
            let cur = moment(); // remove now TODO
            if (cur.diff(membershipStarted, durationFormat) > durationValue) { // exccluding the current day
                return; // membership expired
            }
        }
        await setMembershipDiscount(membershipDetails.info);
    }

    //Any computation for all items in cart
    foo.computeCart = async function(iAddDiscount, iAddGlobalDiscount) {
        iAddDiscount = ASSING_IFNOT_UNDEFINED(iAddDiscount, 1);
        iAddGlobalDiscount = ASSING_IFNOT_UNDEFINED(iAddGlobalDiscount, 1);
        if (foo.applicationSettings.taxProfile && session.settings.sales.profileId !== foo.applicationSettings.taxProfile.id) {
            await foo.updateSalesProfileSettings(foo.applicationSettings.taxProfile.id);
            bComputeTax = true;
        }
        let gDiscountValue = session.gDiscountValue ? session.gDiscountValue : 0;
        let bGDiscountPercent = session.bGDiscountPercent ? session.bGDiscountPercent : false;
        if (!bGDiscountPercent) {
            let itemCount = getTotalItemCount();
            if (itemCount !== 0) {
                gDiscountValue = gDiscountValue / itemCount;
            }
        }
        gDiscountValue *= iAddGlobalDiscount;

        var salesCart = foo.get_cart();
        for (var i = 0; i < salesCart.length; i++) {
            var cartItem = salesCart[i];
            cartItem.gDiscountValue = gDiscountValue;
            cartItem.bGDiscountPercent = bGDiscountPercent;

            if (bComputeTax) {
                var totalTaxPercent = _self.getTaxesForItem(cartItem.origTaxes, cartItem.slab, cartItem.price, cartItem.itemTaxList, cartItem.chargesTaxList, cartItem.bSPTaxInclusive, cartItem.ItemType);
            }
            cartItem.bReadyForCheckout = isReadyForCheckout(cartItem);
            computeItemCart(cartItem, iAddDiscount);
        }
    }

    function getDiscountedPrice(price, discountPercent) {
        return price * discountPercent * 0.01;
    }

    function getPriceAfterDiscount(price, discountedPrice) {
        return price - discountedPrice;
    }

    function computeTax(price, taxPercent) {
        return taxPercent * 0.01 * price;
    }

    foo.isCartReadyForCheckout = function() {
        var cart = foo.get_cart();
        var bReadyForCheckout = true;
        for (var i = 0; i < cart.length; i++) {
            var cartItem = cart[i];
            if (!isReadyForCheckout(cartItem)) {
                bReadyForCheckout = false;
            }
        }

        return bReadyForCheckout;
    };

    function isReadyForCheckout(cartItem) {
        var bReadyForCheckout = true;
        if ((cartItem.is_serialized && !cartItem.serialnumber) || (cartItem.imeiCount !== 0 && (!cartItem.imeiNumbers || cartItem.imeiNumbers.length !== cartItem.imeiCount))) {
            bReadyForCheckout = false;
        }

        return bReadyForCheckout;
    }

    foo.addItem2Cart = function(itemId, stockKey, quantity, itemLocation, discount, price, description, serialnumber, imeiNumbers, pItemTaxList, pBSPTaxInclusive, appointmentData, membershipDiscount) {
        //TODO check whats really their in the old code and then modify
        //BMTodo all the arguments are for suspendsales 
        quantity = quantity || 1;
        discount = discount;
        membershipDiscount = membershipDiscount ? membershipDiscount : 0;
        price = price || null;
        description = description || null;
        serialnumber = serialnumber || null;
        imeiNumbers = imeiNumbers || [];

        if (!stockKey) {
            logger.error('stockKey is mandatory');
            return Promise.reject('Internal Error');
        }

        var salesCart = foo.get_cart();
        var maxkey = 0;

        var itemIndex = -1;
        var itemalreadyinsale = false;
        //We did not find the item yet.
        var insertkey = 0;
        var bItemIsSerialized = false;
        //Key to use for new entry.                    

        for (var index in salesCart) {

            var cartItem = salesCart[index];
            //We primed the loop so maxkey is 0 the first time.
            //Also, we have stored the key in the element itself so we can compare.
            if (maxkey <= cartItem.line) {
                maxkey = cartItem.line;
            }

            if (cartItem.item_id === itemId && cartItem.stockKey === stockKey && cartItem.item_location === itemLocation) {
                itemalreadyinsale = true;
                itemIndex = index;
                if (!cartItem.is_serialized && cartItem.imeiCount === 0) {
                    quantity = (parseFloat(quantity) + parseFloat(cartItem.quantity));
                    break;
                } else {
                    bItemIsSerialized = true;
                }
            }
        }

        insertkey = maxkey + 1;

        return Promise.resolve().then(function() {
            //Item already exists and is not serialized, add to quantity            
            if (!itemalreadyinsale || bItemIsSerialized) {
                return addItem2CartHelper(itemId, stockKey, quantity, itemLocation, discount, price, description, serialnumber, imeiNumbers, insertkey, pItemTaxList, pBSPTaxInclusive, appointmentData, membershipDiscount);
            } else {
                return Promise.resolve(itemIndex);
            }
        }).then(function(index) {
            var cartItem = salesCart[index];
            if (quantity <= 0) {
                _self.deleteItemByLine(cartItem.line);
                salesCart = foo.get_cart(); //reloading cart, as in the previous operation, the array changed
            } else {
                cartItem.quantity = quantity;
                cartItem.bReadyForCheckout = isReadyForCheckout(cartItem);
            }

            foo.set_cart(salesCart);

            return cartItem;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });

    };

    foo.edit_item = function(line, description, serialnumber, imeiNumbers, quantity, discount, price, appointmentData, membershipDiscount) {
        discount = discount || 0;
        discount = parseFloat(discount);

        var thisCartItem = _self.get_cart().filter(function(cartItem) {
            return cartItem.line === line;
        });
        if (thisCartItem.length <= 0) {
            throw new Error('No item Found in cart with line Number', line);
        } else {
            thisCartItem = thisCartItem[0];
            if (thisCartItem.price !== price) {
                if (!IS_EMPTY_OBJECT(thisCartItem.slab)) {
                    //if tax slab exist, then it is taxexclusive
                    thisCartItem.totalTaxPercent = _self.getTaxesForItem(thisCartItem.origTaxes, thisCartItem.slab, price, thisCartItem.itemTaxList, thisCartItem.chargesTaxList, thisCartItem.bSPTaxInclusive, thisCartItem.ItemType);
                }
                var sellingPriceExcludingTax = computeUtils.getPriceTaxEx(price, thisCartItem.bSPTaxInclusive, thisCartItem.totalTaxPercent);
                thisCartItem.price = price;
                thisCartItem.sellingPriceExcludingTax = sellingPriceExcludingTax;
            }

            thisCartItem.description = description;
            thisCartItem.serialnumber = serialnumber;
            thisCartItem.imeiNumbers = imeiNumbers;

            if (!thisCartItem.is_serialized && thisCartItem.imeiCount === 0) {
                thisCartItem.quantity = parseFloat(quantity);
            }

            thisCartItem.discount = discount;
            if (thisCartItem.membershipDiscount) {
                thisCartItem.discount -= thisCartItem.membershipDiscount; // reset old membership discount
            }
            thisCartItem.membershipDiscount = membershipDiscount ? membershipDiscount : 0;
            thisCartItem.discount += thisCartItem.membershipDiscount; // apply membership discount again // how this is good ??? NO USE
            thisCartItem.bReadyForCheckout = isReadyForCheckout(thisCartItem);
            if (appointmentData) thisCartItem.appointmentData = appointmentData;
        }

    };

    foo.deleteItemByLine = function(line) {
        var cart = foo.get_cart();
        var index = findIndexOfItemByLine(line, cart);
        if (index > -1) {
            cart.splice(index, 1);
            return true;
        } else {
            return false;
        }
    };

    foo.get_quantity_already_added = function(item_id, stockKey, item_location) {

        var quanity_already_added = 0;
        var thisSalesCart = _self.get_cart();

        for (var index in thisSalesCart) {
            var item = thisSalesCart[index];
            if (item.item_id === item_id && item.item_location === item_location && item.stockKey === stockKey) {
                quanity_already_added += item.quantity;
            }
        }
        return quanity_already_added;
    };

    foo.out_of_stock = function(itemId, stockKey, itemLocation) {
        //TODO as of now going ahead with single Item location
        //RelaxTodo get item quantities
        var stockStatus = "";
        return itemsLib.getQuantity({

            item_id: itemId,
            stockKey: stockKey
        }).then(function(quantityInfo) {
            let totalQuantity = quantityInfo.totalQuantity;
            let thisStockQuantity = quantityInfo.stockQuantity;
            let itemInfo = quantityInfo.info;

            var stockStatus = false;
            var quantity_added = _self.get_quantity_already_added(itemId, stockKey, itemLocation);
            if ((thisStockQuantity - quantity_added < 0) && !itemInfo.isprepared) {
                stockStatus = 'Item stock level is less than zero, Current Stock is ' + thisStockQuantity + '. Do you want to proceed with this sale?';
                if (totalQuantity > quantity_added) {
                    stockStatus = 'Consider selling stock from different batch as item stock level in this batch is less than zero, Current Stock is ' + thisStockQuantity + '. Do you want to proceed with this sale?';
                }
            } else if (((totalQuantity - quantity_added) < itemInfo.reorderLevel) && !itemInfo.isprepared) {
                stockStatus = 'Item stock level less than reorder level, Current Stock is ' + thisStockQuantity + ' Do you want to proceed with this sale?';
            }
            return stockStatus;
        }) //If Error it is directly propagated to parent ;

    };

    foo.get_discount = function() {
        var discount = 0;
        var thisSalesCart = _self.get_cart();
        for (var index in thisSalesCart) {
            var item = thisSalesCart[index];
            discount += item.discounted_price;
        }

        return discount;
    };

    foo.get_total = function(obj) {
        var allCartTaxes = foo.get_taxes();

        var total = _self.get_subtotal(true, true);
        for (var index in allCartTaxes) {
            var tax = allCartTaxes[index];
            total = math.add(total, tax);
        }

        let totalAfterRoundOff = +utils.roundOffNumber(total, foo.applicationSettings);
        if (obj) {
            obj.addedRoundOffValue = totalAfterRoundOff - total;
        }

        return totalAfterRoundOff;
    };

    foo.getSaleOnCreditAmt = function(payments) {
        var saleOnCreditAmt = 0;
        for (var i = 0; i < payments.length; i++) {
            if (payments[i].payment_type === "Sale on credit") {
                saleOnCreditAmt += payments[i].payment_amount;
            }
        }
        return saleOnCreditAmt;
    };

    foo.get_comment = function() {
        // avoid returning a null that results in a 0 in the comment if nothing is set/available

        return !session.comment ? '' : session.comment;
    };

    foo.get_email_receipt = function() {
        return session.email_receipt;
    };

    foo.get_payments_total = function() {

        var subtotal = 0;
        var payments = foo.get_payments();
        for (var index in payments) {
            var payment = payments[index];
            subtotal = math.add(payment.payment_amount, subtotal);
        }
        //TODO
        //return to_currency_no_money(subtotal);

        return subtotal;
    };

    foo.get_payments = function() {
        if (!session.payments) {
            session.payments = [];
        }
        return session.payments;
    };

    foo.set_payments = function(payments_data) {
        session.payments = payments_data;
    };

    foo.get_amount_due = function() {

        var sales_total = foo.get_total();
        var amount_due = 0;
        var payment_total = foo.get_payments_total();
        amount_due = math.subtract(sales_total, payment_total);
        return amount_due;
    };

    foo.is_print_after_sale = function() {
        return session.sales_print_after_sale === true || session.sales_print_after_sale === '1';
    };

    foo.set_print_after_sale = function(print_after_sale) {
        session.sales_print_after_sale = print_after_sale;
    };

    foo.is_invoice_number_enabled = function() {
        return session.sales_invoice_number_enabled === true || session.sales_invoice_number_enabled === '1';
    };

    foo.clear_all = function() {
        foo.clear_mode();
        foo.emptyCart();
        foo.clear_comment();
        foo.clear_email_receipt();
        foo.clear_invoice_number();
        foo.empty_payments();
        foo.removeCustomer();
        foo.setLocalTax(true);
        foo.clearTempDetails();
        foo.setGlobalDiscount({
            value: 0,
            bPercent: true,
            gDiscountMembership: 0,
            gDiscountMembershipAmt: 0
        });
        foo.setIsAppointment(false);
        foo.setAppointmentDate(undefined);

        if (foo.refBookingId) {
            delete foo.refBookingId;
        }
        foo.clearTempDetails();
    };

    foo.set_comment = function(comment) {
        session.comment = comment;
    };
    foo.clear_comment = function() {
        session.comment = null;
    };
    foo.set_email_receipt = function(email_receipt) {
        session.email_receipt = email_receipt;
    };
    foo.clear_email_receipt = function() {
        session.email_receipt = null;
    };

    foo.get_invoice_number = function() {
        return session.sales_invoice_number;
    };

    foo.set_invoice_number = function(invoice_number, keep_custom) {
        keep_custom = keep_custom || false;
        var current_invoice_number = session.sales_invoice_number;

        if (!keep_custom || validator.isEmpty(current_invoice_number)) {
            session.sales_invoice_number = invoice_number;
        }
    };

    foo.clear_invoice_number = function() {
        session.sales_invoice_number = null;
    };

    foo.set_invoice_number_enabled = function(invoice_number_enabled) {
        session.sales_invoice_number_enabled = invoice_number_enabled;
    };

    function getTotalItemCount() {
        let itemCount = 0;

        let cart = _self.get_cart();
        for (let i = 0; i < cart.length; i++) {
            itemCount += cart[i].quantity;
        }

        return itemCount;
    }

    /**
     * Todo: Compute all the totals everytime
     */
    foo.setGlobalDiscount = async function(data) {
        session.discountMethod = data.discountMethod;
        session.gInputDiscountValue = data.value;
        session.gInputDiscountPercent = data.bPercent;
        session.bGDiscountPercent = data.bPercent;
        session.gDiscountMembership = data.gDiscountMembership ? data.gDiscountMembership : 0; // membership percent
        session.gDiscountMembershipAmt = data.gDiscountMembershipAmt ? data.gDiscountMembershipAmt : 0; // membership amount
        if (data.discountMethod == 'onTaxable') {
            session.gDiscountValue = data.value;
        } else {
            await computeGlobalDiscountPercent(data);
        }
    };

    /**
     * prevTotal -> total without spot discount
     * noDiscountTotal -> total no item discount no spot discount
     * finalTotal -> total with item discount with spot
     * 
     */
    async function computeGlobalDiscountPercent(data) {
        if (data.value === 0) {
            session.gDiscountValue = 0;
            return;
        }

        await _self.computeCart(1, 0);
        let prevTotal = _self.get_total();
        await _self.computeCart(0, 0);
        let noDiscountTotal = _self.get_total();
        let finalTotal;
        //using previous total .. get final total
        if (data.bPercent) {
            finalTotal = prevTotal * (1 - (data.value * 0.01));
        } else {
            finalTotal = prevTotal - data.value;
        }

        if (noDiscountTotal !== 0) {
            session.gDiscountValue = (100 * (prevTotal - finalTotal) / noDiscountTotal);
        } else {
            session.gDiscountValue = 0;
        }

        session.bGDiscountPercent = true; // check if required WHY TODO
    }

    async function getMembershipAmt(percent) {
        if (!percent) {
            return 0;
        }

        await _self.computeCart(1, 0);
        let prevTotal = _self.get_total();
        await _self.computeCart(0, 0);
        let noDiscountTotal = _self.get_total();
        //using previous total .. get final total

        let finalTotal = prevTotal * (1 - (percent * 0.01));

        if (noDiscountTotal !== 0) {
            return (prevTotal - finalTotal);
        }
        return 0;
    }

    //This has to be modified according to new/old way
    foo.getGlobalDiscountInfo = async function() {
        //get total without discount, without charges
        let subtotal = _self.get_subtotal();
        let gDiscountInfo = {
            amt: 0,
            percent: 0,
            spotPercent: 0,
            spotAmt: 0,
            gDiscountMembership: 0,
            gDiscountMembershipAmt: 0
        };

        if (session.gDiscountMembership) {
            gDiscountInfo.gDiscountMembership = session.gDiscountMembership;
            if (!session.gDiscountValue) {
                console.error('should not come here ideally, cliend should send discountValue having membershipDiscount');
                session.gDiscountValue = session.gDiscountMembership;
            }
        }

        if (!session.gDiscountValue) {
            return gDiscountInfo;
        }

        if (session.discountMethod == 'onTaxable') {
            let cart = _self.get_cart();
            for (let i = 0; i < cart.length; i++) {
                gDiscountInfo.amt += cart[i].gDiscountAmt;
            }
            gDiscountInfo.percent = 100 * gDiscountInfo.amt / subtotal;
        } else {
            await _self.computeCart(1, 1);
            let finalTotal = _self.get_total();
            await _self.computeCart(1, 0);
            let prevTotal = _self.get_total();
            if (prevTotal !== 0) {
                gDiscountInfo.amt = prevTotal - finalTotal;
                gDiscountInfo.percent = 100 * gDiscountInfo.amt / prevTotal;
            }
            //recomputing so that whoever is using the cart should not be impacted
            await _self.computeCart();
        }
        gDiscountInfo.gDiscountMembershipAmt = (gDiscountInfo.gDiscountMembership / gDiscountInfo.percent) * gDiscountInfo.amt;
        gDiscountInfo.spotPercent = gDiscountInfo.percent - gDiscountInfo.gDiscountMembership;
        gDiscountInfo.spotAmt = gDiscountInfo.amt - gDiscountInfo.gDiscountMembershipAmt;

        gDiscountInfo.amt = +gDiscountInfo.amt.toFixed(2);
        gDiscountInfo.percent = +gDiscountInfo.percent.toFixed(2);
        gDiscountInfo.gDiscountMembershipAmt = +gDiscountInfo.gDiscountMembershipAmt.toFixed(2);
        gDiscountInfo.spotPercent = +gDiscountInfo.spotPercent.toFixed(2);
        gDiscountInfo.spotAmt = +gDiscountInfo.spotAmt.toFixed(2);
        // To resolve rounding issue
        if (session.gInputDiscountPercent) {
            gDiscountInfo.percent = session.gInputDiscountValue;
        } else {
            gDiscountInfo.amt = session.gInputDiscountValue;
        }

        return gDiscountInfo;
    };

    foo.add_payment = function(paymentType, paymentAmount, paymentRefNo) {
        var payments = foo.get_payments();
        var thisPayment = payments.filter(function(payment) {
            return payment.payment_type === paymentType;
        });

        if (thisPayment.length > 0) {
            //payment_method already exists, add to payment_amount            
            thisPayment = thisPayment[0];
            thisPayment.payment_amount = +(thisPayment.payment_amount + paymentAmount).toFixed(2);
        } else {
            //add to existing array
            var payment = {
                'payment_type': paymentType,
                'payment_amount': +paymentAmount.toFixed(2),
                'ref_no': paymentRefNo
            };

            payments.push(payment);
        }
        // foo.set_payments(payments);
        return true;
    };
    foo.edit_payment = function(paymentType, paymentAmount) {
        var payments = foo.get_payments();

        var thisPayment = payments.filter(function(payment) {
            return payment.payment_type === paymentType;
        });

        // var payments = foo.get_payments();
        if (thisPayment.length > 0) {
            thisPayment = thisPayment[0];
            if (thisPayment[paymentType]) {
                thisPayment.payment_type = paymentType;
                thisPayment.payment_amount = paymentAmount;
                //foo.set_payments(payments);
            } else {
                throw new Error('Payment with paymentId=' + paymentType + ' Does not exists');
            }
        } else {
            throw new Error('Payment with paymentId=' + paymentType + ' Does not exists');
        }

    };

    foo.delete_payment = function(paymentType) {
        var payments = foo.get_payments();

        payments = payments.filter(function(aPayment) {
            return aPayment.payment_type !== paymentType;
        });

        foo.set_payments(payments);
    };

    foo.empty_payments = function() {
        session.payments = [];
    };

    foo.get_item_id = function(line_to_get) {

        var cartItems = foo.get_cart();
        for (var index in cartItems) {
            if (cartItems[index].line == line_to_get) {
                return cartItems[index].item_id;
            }
        }
        return -1;
    };

    foo.getStockKey = function(line_to_get) {

        var cartItems = foo.get_cart();
        for (var index in cartItems) {
            if (cartItems[index].line == line_to_get) {
                return cartItems[index].stockKey;
            }
        }
        return -1;
    };

    foo.commitSale = async function(items, editSaleId, customer_id, employee_id, comment, invoice_number, payments, total, saleOnCreditAmt, timeStamp, checkNo, state_name, roundOffMethod, wcInfo, customerGSTIN, shippingAddress, globalDiscountInfo, tableNo, isAppointment, appointmentDate, invoiceCheckpoint, prefix, saleNum) {
        return await salesLib2.commitSale(items, editSaleId, customer_id, foo.getRefBookingId(), employee_id, comment, invoice_number, payments, total, saleOnCreditAmt, timeStamp, checkNo, state_name, roundOffMethod, wcInfo, customerGSTIN, shippingAddress, globalDiscountInfo, tableNo, isAppointment, appointmentDate, invoiceCheckpoint, prefix, saleNum);
    };

    /**
     * 
     * IMEITodo : no unique details table for suspsended sale
     */
    function addSuspendedItem2Cart(itemInfo) {
        return _self.addItem2Cart(itemInfo.item_id, itemInfo.stockKey, itemInfo.quantity_purchased, itemInfo.item_location, itemInfo.discount_percent, itemInfo.sellingPrice, itemInfo.description, itemInfo.serialnumber, itemInfo.imeiNumbers, undefined, undefined, itemInfo.appointmentData, itemInfo.membershipDiscount);
    }

    foo.addMembershipToCustomer = async function(customerId, membership, timestamp) {
        try {
            let doc = await couchDBUtils.getDoc('customer_' + customerId, mainDBInstance);
            if (!doc.membership) doc.membership = [];
            doc.membership = membership; // single membership 
            doc.membership.date = timestamp ? moment(timestamp).format() : moment().format();
            let resp = await couchDBUtils.update(doc, mainDBInstance);
            return resp;
        } catch (err) {
            throw err;
        }
    }

    foo.ifCartHasMembership = function(salesCart) {
        let membership = undefined;
        for (let i = 0; i < salesCart.length; i++) {
            if (salesCart[i].ItemType == 'Membership') {
                membership = salesCart[i];
            }
        }
        return membership;
    }

    //RelaxTodo Form all the documents in 1 common placce
    foo.copy_entire_suspended_sale = async function(saleId, bOnlyItems, setRevAndId) {

        if (utils.isUndefinedOrNull(bOnlyItems)) {
            bOnlyItems = false;
        }

        try {
            let suspendedSaleDoc = await couchDBUtils.getDoc('suspendedSale_' + saleId, mainDBInstance, 'Suspended Sale Not Found.');
            if (suspendedSaleDoc.sales_info.isAppointment) {
                _self.setIsAppointment(true);
                _self.setAppointmentDate(suspendedSaleDoc.sales_info.appointmentDate);
                _self.setStatus(suspendedSaleDoc.status);
            }
            if (suspendedSaleDoc.sales_info.globalDiscountInfo) {
                await _self.setGlobalDiscount({
                    bPercent: true,
                    value: suspendedSaleDoc.sales_info.globalDiscountInfo.spotPercent
                });
            }
            if (suspendedSaleDoc.sales_info.customer_id) {
                _self.set_customer(suspendedSaleDoc.sales_info.customer_id);
            }
            for (let i = 0; i < suspendedSaleDoc.sales_items.length; i++) {
                await addSuspendedItem2Cart(suspendedSaleDoc.sales_items[i]);
            }
            if (!bOnlyItems) {
                for (var i = 0; i < ARRAY_LENGTH(suspendedSaleDoc.payments); i++) {
                    var suspendedPayment = suspendedSaleDoc.payments[i];
                    //Todo: If customersLoyality is the payment type we have to check it's validity now. This is not handled in phpCode as well
                    _self.add_payment(suspendedPayment.payment_type, suspendedPayment.payment_amount);
                }
                var suspendedInfo = suspendedSaleDoc.sales_info;
                if (!utils.isUndefinedOrNull(suspendedInfo)) {
                    _self.set_customer(suspendedInfo.customer_id);
                    _self.set_comment(suspendedInfo.comment);
                    _self.set_invoice_number(suspendedInfo.invoice_number);
                }
            }
            if (setRevAndId) {
                setSuspendedSalesDocInfo(suspendedSaleDoc); // set info needed for update
            }
            return true;
        } catch (error) {
            logger.error(error);
            throw error
        }
    };

    function setSuspendedSalesDocInfo(suspendedSaleDoc) {
        session.tempSuspendeSaleInfo = {
            id: suspendedSaleDoc._id,
            rev: suspendedSaleDoc._rev
        };
    }

    foo.getSuspendedSalesDocInfo = function() {
        return session.tempSuspendeSaleInfo;
    }

    var addSuspendedCustomer = async function(saleId) {
        try {
            let salesDoc = await couchDBUtils.getDoc("suspendedSale_" + saleId, mainDBInstance);
            if (salesDoc.sales_info.customer_id !== null) {
                await _self.set_customer(salesDoc.sales_info.customer_id);
            }

            return status.SUCCESS;
        } catch (err) {
            logger.error(err);
            throw err;
        }
    }

    foo.addSuspendedSalesToCart = async function(saleIdArray) {
        try {

            var response = {
                status: status.ERR_UNDEFINED
            };
            if (saleIdArray.length === 0) {
                response.status = status.SUCCESS;
                return Promise.resolve(response);
            }

            let suspendedItemsArray = [];
            for (let i = 0; i < saleIdArray.length; i++) {
                let SuspendedSalesDoc = await couchDBUtils.getDoc("suspendedSale_" + saleIdArray[i], mainDBInstance);
                for (let j = 0; j < SuspendedSalesDoc.sales_items.length; j++) {
                    suspendedItemsArray.push(SuspendedSalesDoc.sales_items[j]);
                }
            }

            var promisesArray = [];
            promisesArray.push(addSuspendedCustomer(saleIdArray[0]));
            promisesArray.push(BPromise.each(suspendedItemsArray, addSuspendedItem2Cart));
            await Promise.all(promisesArray);
            response.status = status.SUCCESS;
            return response;
        } catch (err) {
            logger.error(err);
            throw response;
        }
    };

    foo.clear_mode = function() {
        session.sale_mode = null;
    };

    /**
     *      Currently search by id is only supported  
     *      Started writing this function for returns
     */
    foo.loadSaleHelper = function(params) {
        session.saleDetails = {
            sale_id: params.saleId
        };

        return salesModel.getSaleDetails(params).then(function(resp) {
            resp.sale_id = params.saleId;
            session.saleDetails = resp;

            return session.saleDetails;
        }).catch(function(err) {
            logger.error(err);
            response.err = err;
            return Promise.reject(response);
        });
    };

    foo.ifCartHasService = function() {
        let cart = foo.get_cart();
        for (let i = 0; i < cart.length; i++) {
            if (cart[i].ItemType === 'Service') {
                return true;
            }
        }
        return false;
    }

    foo.handleIsAppointmentFlag = function() {
        if (foo.ifCartHasService()) {
            foo.setIsAppointment(true);
            if (!foo.getAppointmentDate()) {
                foo.setAppointmentDate(moment());
            }

        } else {
            foo.setIsAppointment(false);
            foo.setAppointmentDate(undefined)
        }
    }

    foo.getJsonForPrint = function(params, applicationSettings) {
        function ROUNDOFFNUMBER(number) {
            var result = +utils.roundOffNumber(number, applicationSettings);
            return result;
        }
        //todo :comment and employee name to be fixed in reprint
        function addInfoForPrint(saleDetails, data, customerInfo, employeeInfo) {
            let invoicePrefix;

            if (saleDetails.sales_info) {
                invoicePrefix = saleDetails.sales_info.invoicePrefix ? saleDetails.sales_info.invoicePrefix : "POS ";
            }

            if (saleDetails.info) {
                invoicePrefix = saleDetails.info.invoicePrefix ? saleDetails.info.invoicePrefix : "POSR";
            }
            data.sale_id = saleDetails.sales_info ? invoicePrefix + saleDetails.sales_info.sale_id : invoicePrefix + saleDetails.info.id;
            data.comments = saleDetails.sales_info ? saleDetails.sales_info.comment : saleDetails.info.comment;
            var saleTime = saleDetails.sales_info ? saleDetails.sales_info.sale_time : saleDetails.info.time;
            data.transaction_time = moment(saleTime).format(applicationSettings.dateTime.dateformat +
                ' ' + applicationSettings.dateTime.timeformat);

            data.transaction_date = moment(saleTime).format(applicationSettings.dateTime.dateformat);
            data.receipt_title = saleDetails.sales_info ? 'Sales Receipt' : 'Sales Returns Receipt';
            if (customerInfo) {
                var lastName = customerInfo.last_name ? customerInfo.last_name : '';

                data.customer = customerInfo.first_name + ' ' + lastName;
                if (customerInfo.company_name) {
                    data.customer_compnay_name = customerInfo.company_name;
                }
                data.customer_id = customerInfo.person_id;
                data.customer_address = customerInfo.address_1;
                data.customer_location = customerInfo.zip + ' ' + customerInfo.city;
                data.account_number = customerInfo.account_number;
                data.customerGSTIN = customerInfo.gstin_number;
                data.phone_number = customerInfo.phone_number;

                data.customer_info = {
                    0: data.customer,
                    1: customerInfo.address_1,
                    2: customerInfo.zip + ' ' + customerInfo.city,
                    3: customerInfo.account_number,
                    4: customerInfo.gstin_number,
                    5: customerInfo.phone_number
                };
            } else if (saleDetails.sales_info && saleDetails.sales_info.wcInfo || saleDetails.info && saleDetails.info.wcInfo) {
                data.customer = saleDetails.sales_info ? saleDetails.sales_info.wcInfo.name : saleDetails.info.wcInfo.name;
                data.phone_number = saleDetails.sales_info ? saleDetails.sales_info.wcInfo.phone_number : saleDetails.info.wcInfo.phone_number;
            } else {
                data.customer = '';
            }

            data.employee = employeeInfo.first_name + ' ' + employeeInfo.last_name;
            data.company_info = {
                0: applicationSettings.ownersInfo.address,
                1: applicationSettings.ownersInfo.phone,
                2: applicationSettings.ownersInfo.account_number,
                3: applicationSettings.ownersInfo.company
            };
            data.tableNo = (saleDetails.sales_info && saleDetails.sales_info.tableNo) ? saleDetails.sales_info.tableNo : undefined;
            data.isAppointment = saleDetails.sales_info ? saleDetails.sales_info.isAppointment : saleDetails.info.isAppointment;
            if (data.isAppointment) {
                data.appointmentDate = data.appointmentDate;
            }
            data.company_address = applicationSettings.ownersInfo.address;
            data.company_phone = applicationSettings.ownersInfo.phone;
            data.company_account = applicationSettings.ownersInfo.account_number;
            data.company_name = applicationSettings.ownersInfo.company;

        }

        function getEmptyDataJson() {
            return {
                sale_id: 0,
                totalChargesAmt: 0,
                totalQuantity: 0,
                total: 0,
                subtotal: 0,
                discount: 0,
                discounted_subtotal: 0,
                totalTax: 0,
                amount_due: 0,
                amount_change: 0,
                receipt_title: 'Sales Receipt',
                transaction_time: '',
                transaction_date: '',
                comments: '',
                cart: [],
                taxes: {},
                taxesWithPercents: {},
                charges: {},
                payments: [],
                taxDetailed: {},
                taxNames: {},
                hsnTaxes: {},
                tableNo: 0,
                isAppointment: false,
                appointmentDate: undefined,
                description: ''
            };
        }

        function computeReprintCart(items, data, iAddGlobalDiscount) {
            iAddGlobalDiscount = ASSING_IFNOT_UNDEFINED(iAddGlobalDiscount, 1);
            if (!data) {
                data = getEmptyDataJson();
            }
            let taxes = data.taxes;
            let taxesWithPercents = data.taxesWithPercents;
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                item.totalTaxPercent = 0;
                for (var j = 0; j < item.itemTaxList.length; j++) {
                    var tax = item.itemTaxList[j];
                    // totalTaxPercent += tax.percent;
                    item.totalTaxPercent += tax.percent;
                }
                var price = computeUtils.getPriceTaxEx(item.sellingPrice, item.bSPTaxInclusive, item.totalTaxPercent);
                item.price = item.sellingPrice;
                item.quantity = item.quantity_purchased;
                data.totalQuantity += item.quantity;
                item.total = price * item.quantity_purchased;
                item.gDiscountPercent = item.gDiscountPercent ? item.gDiscountPercent : 0;
                item.discount_percent = (item.discount_percent ? item.discount_percent : 0) + (item.gDiscountPercent * iAddGlobalDiscount);
                item.discount = item.discount_percent;
                item.discounted_price = item.discount_percent * 0.01 * item.total;
                item.discounted_total = item.total - item.discounted_price;
                let totalChargesAmt = 0;
                for (let i = 0; i < ARRAY_LENGTH(item.chargesList); i++) {
                    let chargesAmt = computeTax(item.discounted_total, item.chargesList[i].percent);
                    item.chargesList[i].Amt = chargesAmt;
                    totalChargesAmt += chargesAmt;
                }
                item.totalAfterDisAndCharges = item.discounted_total + totalChargesAmt;
                item.totalTax = 0;
                for (var j = 0; j < item.itemTaxList.length; j++) {
                    var thisTax = item.itemTaxList[j];
                    var taxName = thisTax.name;
                    if (!taxes.hasOwnProperty(taxName)) {
                        taxes[taxName] = 0;

                    }
                    if (!taxesWithPercents.hasOwnProperty(taxName + ' @' + thisTax.percent + '%')) {
                        taxesWithPercents[taxName + ' @' + thisTax.percent + '%'] = 0;
                    }
                    let amt = thisTax.percent * 0.01 * item.discounted_total;
                    thisTax.Amt = amt;
                    taxes[taxName] += amt;
                    taxesWithPercents[taxName + ' @' + thisTax.percent + '%'] += amt;
                    item.totalTax += amt;
                }
                getDetailedTaxByPerc(item, data.taxDetailed, data.taxNames, data.hsnTaxes);
                for (var j = 0; j < item.chargesTaxList.length; j++) {
                    var thisTax = item.chargesTaxList[j];
                    var taxName = thisTax.name;
                    if (!taxes.hasOwnProperty(taxName)) {
                        taxes[taxName] = 0;
                    }
                    if (!taxesWithPercents.hasOwnProperty(taxName + ' @' + thisTax.percent + '%')) {
                        taxesWithPercents[taxName + ' @' + thisTax.percent + '%'] = 0;
                    }
                    let amt = thisTax.percent * 0.01 * totalChargesAmt;
                    thisTax.Amt = amt;
                    taxes[taxName] += amt;
                    taxesWithPercents[taxName + ' @' + thisTax.percent + '%'] += amt;
                    item.totalTax += amt;
                }

                item.totalWithTax = item.totalAfterDisAndCharges + item.totalTax;
                data.tableNo = (data.table_no) ? data.table_no : undefined;
                data.isAppointment = data.isAppointment;
                if (data.isAppointment) {
                    data.appointmentDate = data.appointmentDate;
                }
                data.subtotal += item.total;
                data.discount += item.discounted_price;
                data.totalChargesAmt += totalChargesAmt;
                data.totalTax += item.totalTax;
            }

            for (var taxName in taxes) {
                taxes[taxName] = +taxes[taxName].toFixed(2);
            }
            data.charges = _self.getAllCharges(items);
            data.saleOnCreditAmt = _self.getSaleOnCreditAmt(data.payments)
            data.totalWithoutTax = data.subtotal;

            data.discounted_subtotal = data.subtotal - data.discount;
            data.subtotal = data.subtotal - data.discount;
            data.tax_exclusive_subtotal = data.subtotal; //redundant variable tax_exclusive_subtotal
            data.total = data.discounted_subtotal + data.totalChargesAmt + data.totalTax;
            var totalBeforeRoundOff = data.total;
            var total = ROUNDOFFNUMBER(totalBeforeRoundOff);
            data.addedRoundOffValue = total - totalBeforeRoundOff;

            var totalPaid = commonLib.getTotalPaidForReprint(data.payments, true);

            data.amount_due = ROUNDOFFNUMBER(data.total) - totalPaid;
            data.amount_change = -1 * data.amount_due;
            data.total = ROUNDOFFNUMBER(data.total);
            data.discount = +data.discount.toFixed(2);

            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                item.discounted_total = item.discounted_total;
                item.discounted_price = +item.discounted_price.toFixed(2);
            }
            return data;
        }

        //BMTodo Danger Danger decisions and caluclations are done second time. Use the functions written while sale         
        function compute(data) {
            let cloneCart = CLONE(data.cart);
            //The order of the call is important don't change it
            //it was done for spot discount .. in cart computation we should not add global discount and in total summary we have to add it
            computeReprintCart(cloneCart, data);
            let tempData = computeReprintCart(data.cart, undefined, 0);
            //total without spot discount
            data.totalNoSpotDiscount = tempData.total;
            if (data.globalDiscountInfo && data.globalDiscountInfo.discountMethod === 'onTotal') {
                data.discount = tempData.discount + (data.totalNoSpotDiscount - data.total);
            }
        }

        var data = getEmptyDataJson();

        var itemTaxes = [];
        var saleDetails = {};

        return couchDBUtils.getDoc(params.saleId, mainDBInstance).then(function(resp) {
            if (!resp || resp.statusCode === -1) {
                var msg = {};
                msg.message = 'Sale Id Not Found';
                logger.error('Sale Id Not Found');
                return Promise.reject(msg);
            }

            saleDetails = resp;

            var props = {};
            var customerId = resp.sales_info ? resp.sales_info.customer_id : resp.info.customer_id;
            if (customerId) {
                props.customerInfo = couchDBUtils.getDoc('customer_' + customerId, mainDBInstance);
            }
            if (saleDetails.sales_info && saleDetails.sales_info.hasOwnProperty('num')) {
                data.num = saleDetails.sales_info.invoicePrefix + saleDetails.sales_info.num;
            }

            var empId = saleDetails.sales_info ? saleDetails.sales_info.employee_id : saleDetails.info.employee_id
            props.employeeInfo = couchDBUtils.getDoc('org.couchdb.user:' + empId, couchDBUtils.getUserCouchDB());

            return BPromise.props(props);
        }).then(function(resp) {
            data.cart = saleDetails.sale_items ? saleDetails.sale_items : saleDetails.items;
            data.payments = saleDetails.payments;
            if (saleDetails.sales_info) {
                data.globalDiscountInfo = saleDetails.sales_info.globalDiscountInfo;
            }
            if (saleDetails.sales_info && saleDetails.sales_info.checkNo) {
                data.cheQueNo = saleDetails.sales_info.checkNo;
            }
            compute(data);
            addInfoForPrint(saleDetails, data, resp.customerInfo, resp.employeeInfo); //employee customer shop details

            data.payment_options = {};
            for (let i in applicationSettings.paymentTerms) {
                data.payment_options[i] = applicationSettings.paymentTerms[i];
            }
            data.payment_options['Purchase On Credit'] = 'Purchase On Credit';

            return data;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });

    };

    foo.setTempDetails = function(params) {
        for (var key in params) {
            session.salesTempInfo[key] = params[key];
        }
    };

    foo.getTempDetails = function(output) {
        for (var key in session.salesTempInfo) {
            output[key] = session.salesTempInfo[key];
        }

        if (output.sale_time) {
            output.sale_time = moment(output.sale_time).local().format(); //moment(tempDetails.sale_time).format('DD/MM/YYYY,hh:mm:ss');
        }
    }

    foo.clearTempDetails = function() {
        for (var key in session.salesTempInfo) {
            session.salesTempInfo[key] = null;
        }
    };

    return foo;
};