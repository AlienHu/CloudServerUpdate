const math = require('mathjs');
const moment = require('moment');
const logger = require('../../common/Logger');
const couchDBUtils = require('../common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const coreDBInstance = couchDBUtils.getCoreCouchDB();
const utils = require('../common/Utils');
const ARRAY_LENGTH = utils.getArrayLength;

let commonLib = function() {

    let _self = this;

    this.formatSaleId = function(id) {
        return 'sale_' + id;
    };

    this.formatSaleCreditId = function(id) {
        return 'saleCredit_' + id;
    };

    this.formatReceivingCreditId = function(id) {
        return 'receivingCredit_' + id;
    };

    this.formatRoomSaleId = function(id) {
        return 'roomSale_' + id;
    };

    this.formatReceivingId = function(id) {
        return 'receiving_' + id;
    };

    this.formatSaleReturnId = function(id) {
        return 'saleReturn_' + id;
    };

    this.formatReceivingReturnId = function(id) {
        return 'receivingReturn_' + id;
    };

    this.getParamsForGettingInvTrans = function(cartItem, timeStamp, employeeId, comment, bSale, bReturn) {
        let params = {
            item_id: cartItem.item_id,
            batchId: cartItem.batchId,
            stockKey: cartItem.stockKey,
            newQuantity: cartItem.quantity,
            comment: comment,
            employeeId: employeeId,
            locationId: cartItem.item_location,
            timeStamp: timeStamp,
            skuName: cartItem.skuName
        };

        if (bSale) {
            params.newQuantity *= -1;
        } else {
            params.newQuantity *= cartItem.conversionFactor;
        }
        if (bReturn) {
            params.newQuantity *= -1;
        }

        params.uniqueDetails = cartItem.uniqueDetails;

        return params;
    };

    this.add_payment = function(paymentType, paymentAmount, session, ref_no) {
        let payments = this.get_payments(session);
        let thisPayment = payments.filter(function(payment) {
            return payment.payment_type === paymentType;
        });

        if (thisPayment.length > 0) {
            //payment_method already exists, add to payment_amount            
            thisPayment = thisPayment[0];
            thisPayment.payment_amount = +math.add(thisPayment.payment_amount, paymentAmount).toFixed(2);
        } else {
            //add to existing array
            let payment = {
                'payment_type': paymentType,
                'payment_amount': +paymentAmount.toFixed(2),
                'ref_no': ref_no
            };

            payments.push(payment);
        }
        // this.set_payments(payments);
        return true;
    };

    this.get_payments = function(session) {
        if (!session.recvPayments) {
            session.recvPayments = [];
        }
        return session.recvPayments;
    };

    this.get_payments_total = function(session) {

        let subtotal = 0;
        let payments = this.get_payments(session);
        for (let index in payments) {
            let payment = payments[index];
            subtotal = math.add(payment.payment_amount, subtotal);
        }
        //TODO
        //return to_currency_no_money(subtotal);

        return subtotal;
    };

    this.get_amount_due = function(session, total) {

        let amount_due = 0;
        let payment_total = this.get_payments_total(session);
        amount_due = math.subtract(total, payment_total);
        return amount_due;

    };

    this.set_payments = function(payments_data, session) {
        session.recvPayments = payments_data;
    };

    this.delete_payment = function(paymentType, session) {
        let payments = this.get_payments(session);

        payments = payments.filter(function(aPayment) {
            return aPayment.payment_type !== paymentType;
        });

        this.set_payments(payments, session);
    };

    function getReturnPrefix(bPurchase) {
        let prefix = 'suspendSaleReturn';
        if (bPurchase) {
            prefix = 'suspendReceivingReturn';
        }

        return prefix;
    }
    this.getApplicationSettings = async function() {
        return await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstance);

    }
    this.getCurrentCheckpoint = function(applicationSettings) {
        let invoiceCheckpoint = applicationSettings.invoiceCurrentCheckpoint;
        if (invoiceCheckpoint == applicationSettings.invoiceDefaultCheckpoint.value || !applicationSettings.invoiceCheckpointValue.length)
            return applicationSettings.invoiceDefaultCheckpoint;

        for (var i = 0; i < applicationSettings.invoiceCheckpointValue.length; i++) {
            if (invoiceCheckpoint == applicationSettings.invoiceCheckpointValue[i].value)
                return applicationSettings.invoiceCheckpointValue[i];
        }

    }

    this.suspendReturn = async function(data, bPurchase) {
        data._id = getReturnPrefix(bPurchase) + '_' + moment().format('x');
        try {
            await couchDBUtils.create(data, mainDBInstance, 2, 'Suspend Return Failed. Try Again');
            return {
                message: 'Suspend Return Success'
            }
        } catch (error) {
            logger.error(error);
            throw {
                error: error
            };
        }
    };

    this.unsuspendReturn = async function(data) {
        try {
            let errMsg = 'Unsuspend Return Failed. Try Again';
            let resp = await couchDBUtils.getDoc(data._id, mainDBInstance, errMsg);
            await couchDBUtils.delete(data, mainDBInstance, 2, errMsg);
            return {
                message: 'Unsuspend Return Success',
                data: resp
            }
        } catch (error) {
            logger.error(error);
            throw {
                error: error
            };
        }
    };

    this.getAllSuspendedReturns = async function(bPurchase) {
        try {
            return {
                message: 'All Suspended Returns Success',
                data: await couchDBUtils.getAllDocsByType(getReturnPrefix(bPurchase), mainDBInstance, undefined, true)
            };
        } catch (error) {
            throw {
                error: 'Unable to fetch suspended returns'
            };
        }
    };

    /**
     * return
     */
    function getReverseStatusJson(doc, bReject, reason) {
        const itemLib = require('./itemsControllerLib');
        let status = {
            status: 4,
            reverseInvTrans: {}
        };

        if (bReject) {
            status.bReject = true;
            status.reason = reason;
        } else {
            status.bReverse = true;
        }

        let formatDocFun;
        let elementPrefix = 'customer';
        let reverseSign = -1;
        let itemsKey = 'items';
        let infoKey = 'info';
        let timeStampKey = 'time';
        let itemAvailable;
        let sold;
        if (doc._id.indexOf('sale_') === 0) {
            itemsKey = 'sale_items';
            infoKey = 'sales_info';
            timeStampKey = 'sale_time';
            sold = false;
            formatDocFun = _self.formatSaleId;
        } else if (doc._id.indexOf('receiving_') === 0) {
            itemsKey = 'receiving_items';
            infoKey = 'receivings_info';
            timeStampKey = 'receiving_time';
            itemAvailable = false;
            elementPrefix = 'supplier';
            formatDocFun = _self.formatReceivingId;
        } else if (doc._id.indexOf('saleReturn_') === 0) {
            sold = true;
            reverseSign = 1;
            formatDocFun = _self.formatSaleId;
        } else if (doc._id.indexOf('receivingReturn_') === 0) {
            itemAvailable = true;
            elementPrefix = 'supplier';
            reverseSign = 1;
            formatDocFun = _self.formatReceivingId;
        }

        let timeStamp = doc[infoKey][timeStampKey];

        for (let i = 0; i < doc[itemsKey].length; i++) {
            let item = doc[itemsKey][i];
            let invDocId = itemLib.formatInvDocId(item.item_id);

            let uniqueDetails = [];
            if (ARRAY_LENGTH(item.uniqueDetails)) {
                //purchase and purchase return
                uniqueDetails = item.uniqueDetails;
            } else if (item.serialnumber || ARRAY_LENGTH(item.imeiNumbers)) {
                // sale and sale return
                uniqueDetails = [{
                    serialnumber: item.serialnumber,
                    imeiNumbers: item.imeiNumbers
                }];
            }

            if (!status.reverseInvTrans[invDocId]) {
                status.reverseInvTrans[invDocId] = {
                    status: 4,
                    doc: {
                        bReverse: true,
                        _id: invDocId,
                        stock: {},
                        transactions: {}
                    }
                };
            }

            let stockKey = item.stockKey;
            if (!status.reverseInvTrans[invDocId].doc.stock[stockKey]) {
                status.reverseInvTrans[invDocId].doc.stock[stockKey] = {
                    uniqueDetails: {}
                };
            }

            status.reverseInvTrans[invDocId].doc.transactions[timeStamp + '_' + item.stockKey] = 1;
            if (ARRAY_LENGTH(uniqueDetails)) {
                itemLib.getUniqueDetailsJson(uniqueDetails, itemAvailable, sold, status.reverseInvTrans[invDocId].doc.stock[stockKey].uniqueDetails);
            }
        }

        let elementId = doc[infoKey][elementPrefix + '_id'];
        if (elementId) {
            status[elementPrefix + 's'] = {};
            let elementDocId = elementPrefix + '_' + elementId;
            status[elementPrefix + 's'][elementDocId] = {
                status: 4,
                doc: {
                    _id: elementDocId,
                    total: reverseSign * parseFloat(doc[infoKey].total), //RelaxDanger This is rounded off total. get total without manipulation
                    balance: reverseSign * doc[infoKey].pending_amount
                }
            }
        };

        if (doc[infoKey].parentId) {
            let parentDocId = formatDocFun(doc[infoKey].parentId);
            status.parentDoc = {};
            status.parentDoc[parentDocId] = {
                status: 4,
                doc: {
                    _id: parentDocId,
                    returnDocId: doc[infoKey].id,
                    bReverse: true
                }
            };
        }

        return status;
    }

    this.reverseTransaction = async function(docId, bReject, reason, bUpdateStockOnDelete) {
        if (bUpdateStockOnDelete === undefined) {
            bUpdateStockOnDelete = true;
        }

        let commonWorker = require('../workers/commonWorker');
        try {
            let doc = await couchDBUtils.getDoc(docId, mainDBInstance, 'Transaction Doesnot exist');
            if (doc.bRejected) {
                if (bReject) {
                    throw 'Already Rejected.'
                }
                await couchDBUtils.delete(doc, mainDBInstance, 1, 'Delete Failed');
                return {
                    message: 'Success'
                };
            }

            if (ARRAY_LENGTH(doc.mods)) {
                throw 'Please Delete Child Transactions First';

            }
            if (doc.status.status) {
                logger.error('Reversing with pending transaction<' + doc._id + '>');
                throw 'Please try after some time';

            }

            let statusJson = getReverseStatusJson(doc, bReject, reason);
            doc.status = statusJson;
            if (!bUpdateStockOnDelete) {
                delete statusJson.reverseInvTrans;
                if (statusJson.customers) {
                    delete statusJson.customers;
                }
                if (statusJson.suppliers) {
                    delete statusJson.suppliers;
                }
                if (!statusJson.parentDoc) {
                    //Sale And Purchase the below flags have to be set here.
                    //For returns no problem.. in status it is set
                    if (bReject) {
                        doc.bRejected = true;
                    } else {
                        doc._deleted = true;
                    }
                }
            }

            commonWorker.setFreeze(true);
            await couchDBUtils.create(doc, mainDBInstance, 2, 'Reverse Transaction Failed');

            let params = {
                parentDocId: doc._id
            };
            if (statusJson.reverseInvTrans) {
                //If stock update is false .. it doesn't come here
                params.reverseTransactions = statusJson.reverseInvTrans
            }
            if (statusJson.customers) {
                params.elementUpdates = statusJson.customers;
            } else if (statusJson.suppliers) {
                params.elementUpdates = statusJson.suppliers;
            }
            if (statusJson.parentDoc) {
                //Sale Return And Purchase Return
                params.returnUpdates = statusJson.parentDoc;
            }

            commonWorker.insertTrans(params);
            commonWorker.setFreeze(false);

            return {
                message: 'Success'
            };
        } catch (error) {
            commonWorker.setFreeze(false);
            throw {
                error: error
            }
        }
    };

    this.cleanTxnsByType = async function(type) {
        try {
            let docs = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
            console.log(docs);
            for (let j = 0; j < docs.length; j++) {
                console.log(docs[j].id);
                await _self.reverseTransaction(docs[j].id);
            }
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    this.getTansDocument = async function(docId) {
        try {
            let doc = await couchDBUtils.getDoc(docId, mainDBInstance, 'Transaction Doesnot exist');
            return doc;
        } catch (error) {
            logger.error(error);
            throw error;
        }
    };

    this.mergeStatus = function(status, oldDoc, newTimeStamp, bSale) {
        let itemsLib = require('./itemsControllerLib');

        let timeStampKey = 'sale_time';
        let itemsKey = 'sale_items';
        let infoKey = 'sales_info';
        let elementKey = 'customer_id';
        let element = 'customer';
        let mulSign = 1;
        let itemAvailable;
        let sold;

        if (!bSale) {
            itemAvailable = true;
            mulSign = -1;
            timeStampKey = 'receiving_time';
            itemsKey = 'receiving_items';
            infoKey = 'receivings_info';
            elementKey = 'supplier_id';
            element = 'supplier';
        } else {
            sold = true;
        }

        let oldTimeStamp = oldDoc[infoKey][timeStampKey];
        let bTimeStampChanged = oldTimeStamp != newTimeStamp;

        let inventoryStatus = status.inventoryTrans;

        let items = oldDoc[itemsKey];
        for (let i = 0; i < items.length; i++) {
            let invDocId = itemsLib.formatInvDocId(items[i].item_id);
            let stockKey = items[i].stockKey;
            let transKey = itemsLib.formatInvTransKey(oldTimeStamp, stockKey);

            if (!inventoryStatus[invDocId]) {
                inventoryStatus[invDocId] = {
                    status: 4,
                    doc: {
                        _id: invDocId,
                        stock: {}
                    }
                }
            }
            let invStatusDoc = inventoryStatus[invDocId].doc;
            if (!invStatusDoc.transactions2Delete) {
                invStatusDoc.transactions2Delete = {};
            }

            if (bTimeStampChanged || !invStatusDoc.transactions || !invStatusDoc.transactions[transKey]) {
                //If timestamp changes we have to delete all the previous keys
                //If timestamp is same but the stock is not present in the edit
                invStatusDoc.transactions2Delete[transKey] = {
                    trans_stockKey: stockKey
                };
            }

            //Merging
            if (!invStatusDoc.stock[stockKey]) {
                //stock got removed while editing
                invStatusDoc.stock[stockKey] = {
                    quantity: 0,
                    bDeleted: true,
                    uniqueDetails: {}
                }
            }

            let conversionFactor = 1;
            if (!bSale) {
                conversionFactor = items[i].conversionFactor;
            }
            invStatusDoc.stock[stockKey].quantity = invStatusDoc.stock[stockKey].quantity + (mulSign * conversionFactor * items[i].quantity_purchased);
            let unqDet = items[i].uniqueDetails;
            if (bSale) {
                unqDet = [];
                if (items[i].serialnumber || items[i].imeiNumbers.length) {
                    unqDet.push({});
                    if (items[i].serialnumber) {
                        unqDet[0].serialnumber = items[i].serialnumber;
                    }
                    if (items[i].imeiNumbers.length) {
                        unqDet[0].imeiNumbers = items[i].imeiNumbers;
                    }
                }
            }

            itemsLib.uniqueDetailsJsonForEdit(unqDet, itemAvailable, sold, invStatusDoc.stock[stockKey].uniqueDetails);
        }

        let oldInventoryStatus = oldDoc.status.inventoryTrans;
        for (let invDocId in inventoryStatus) {
            let nextV = 0;
            if (oldInventoryStatus[invDocId]) {
                if (oldInventoryStatus[invDocId].v) {
                    nextV = oldInventoryStatus[invDocId].v;
                } else {
                    nextV = 2; //This is to cover the initial mistake which caused bug #2250
                }
            }
            nextV++;
            for (let transKey in inventoryStatus[invDocId].doc.transactions) {
                inventoryStatus[invDocId].doc.transactions[transKey].v = nextV;
            }
            inventoryStatus[invDocId].v = nextV;
        }

        let elementId = oldDoc[infoKey][elementKey];
        if (elementId) {
            let elementDocId = element + '_' + elementId;
            let v = 0;
            if (element === 'customer') {
                v = oldDoc.status[element + 's'][elementDocId].v++;
            }
            if (!status[element + 's'][elementDocId]) {
                status[element + 's'][elementDocId] = {
                    status: 4,
                    doc: {
                        _id: elementDocId,
                        total: 0,
                        balance: 0,
                        v: v
                    },
                    v: v
                };
            }
            status[element + 's'][elementDocId].doc.balance += -1 * oldDoc[infoKey].pending_amount;
            status[element + 's'][elementDocId].doc.total += -1 * oldDoc[infoKey].total;
        }

    };

    this.getTotalPaidForReprint = function(payments, bSale) {
        let creditType = 'Purchase On Credit';
        let paymentIdKey = 'payment_receiving_id';
        if (bSale) {
            creditType = 'Sale on credit';
            paymentIdKey = 'payment_sale_id';
        }
        let totalPaid = 0;
        let creditIndex = -1;
        let creditClearedAmt = 0;
        for (let i = 0; i < payments.length; i++) {
            if (payments[i].payment_type === creditType) {
                creditIndex = i;
                continue;
            }
            totalPaid += payments[i].payment_amount;
            if (payments[i][paymentIdKey]) {
                creditClearedAmt += payments[i].payment_amount;
            }
        }

        let creditAmt = 0;
        if (creditIndex !== -1) {
            creditAmt = payments[creditIndex].payment_amount - creditClearedAmt;
            if (creditAmt <= 0) {
                creditAmt = 0;
                payments.splice(creditIndex, 1);
            } else {
                payments[creditIndex].payment_amount = creditAmt;
            }
        }
        totalPaid += creditAmt;

        return totalPaid;
    };

    this.addPaymentsForEdit = async function(payments, addPaymentRestApi, bSale) {
        let creditType = 'Purchase On Credit';
        let paymentIdKey = 'payment_receiving_id';
        if (bSale) {
            creditType = 'Sale on credit';
            paymentIdKey = 'payment_sale_id';
        }

        let resp;
        let creditIndex = -1;
        let creditPaidAmt = 0;
        for (var j = 0; j < payments.length; j++) {
            if (payments[j].payment_type === creditType) {
                creditIndex = j;
                continue;
            }
            if (payments[j][paymentIdKey]) {
                creditPaidAmt += payments[j].payment_amount;
            }

            payments[j].amount_tendered = payments[j].payment_amount;
            resp = await addPaymentRestApi(payments[j]);
        }
        if (creditIndex !== -1) {
            payments[creditIndex].amount_tendered = payments[creditIndex].payment_amount - creditPaidAmt;
            if (payments[creditIndex].amount_tendered > 0) {
                resp = await addPaymentRestApi(payments[creditIndex]);
            }
        }

        return resp;
    };

    return this;

};

module.exports = new commonLib();