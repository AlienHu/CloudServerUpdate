/*jshint sub:true*/
const logger = require('../../common/Logger');
const utils = require('../common/Utils');
const CLONE = utils.clone;
const IS_UNDEFINED_OR_NULL = utils.isUndefinedOrNull2;
const ARRAY_LENGTH = utils.getArrayLength;
const ASSIGN_IF_TRUE = utils.assignIfTrue;
const couchDBUtils = require('../common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const moment = require('moment');
const itemsLib = require('./itemsControllerLib');
const workerProcess = require('../workers/commonWorker');
const commonLib = require('./commonLib');
const autoIncrementHelper = require('../common/autoIncrementHelper');
let maxReturnId = autoIncrementHelper.getMaxSaleReturnId();

const lockUtils = require('../../common/lockUtils');
lockUtils.createLockDir('locks/sales');
const lockPath = 'locks/sales/sales.lock';
const lockOptions = lockUtils.lockOptions();

let salesControllerLib2 = function() {

    function getItemJson(cartItem) {
        cartItem.gDiscountPercent = ASSIGN_IF_TRUE(cartItem.gDiscountPercent, 0);

        let json = {
            name: cartItem.name,
            hsn: cartItem.hsn,
            item_id: cartItem.item_id,
            ItemType: cartItem.ItemType,
            hsn: cartItem.hsn,
            stockKey: cartItem.stockKey,
            batchId: cartItem.batchId,
            skuName: cartItem.skuName,
            unit: cartItem.unit,
            line: cartItem.line,
            description: cartItem.description,
            quantity_purchased: cartItem.quantity,
            discount_percent: cartItem.discount,
            gDiscountPercent: cartItem.gDiscountPercent,
            purchasePrice: cartItem.purchasePrice,
            sellingPrice: cartItem.price,
            mrp: cartItem.mrp,
            item_location: cartItem.item_location,
            bSPTaxInclusive: cartItem.bSPTaxInclusive,
            bPPTaxInclusive: cartItem.bPPTaxInclusive,
            itemTaxList: [],
            expiry: cartItem.expiry,
            stock_name: cartItem.stock_name,
            chargesList: [],
            chargesTaxList: [],
            warranty: cartItem.warranty,
            warrantyTerms: cartItem.warrantyTerms,
            appointmentData: cartItem.appointmentData,
            membershipDiscount: cartItem.membershipDiscount,
            employeeCommission: cartItem.employeeCommission
        };

        //Not assigning directly because, Amt is not required, it can be computed directly
        for (let i = 0; i < ARRAY_LENGTH(cartItem.chargesList); i++) {
            json.chargesList.push({
                name: cartItem.chargesList[i].name,
                percent: cartItem.chargesList[i].percent
            });
        }
        for (let i = 0; i < ARRAY_LENGTH(cartItem.chargesTaxList); i++) {
            json.chargesTaxList.push({
                name: cartItem.chargesTaxList[i].name,
                percent: cartItem.chargesTaxList[i].percent
            });
        }
        for (let i = 0; i < ARRAY_LENGTH(cartItem.itemTaxList); i++) {
            json.itemTaxList.push({
                name: cartItem.itemTaxList[i].name,
                percent: cartItem.itemTaxList[i].percent
            });
        }

        if (cartItem.serialnumber) {
            json.serialnumber = cartItem.serialnumber;
        }

        json.imeiNumbers = [];
        if (cartItem.imeiNumbers && cartItem.imeiNumbers.length !== 0) {
            json.imeiNumbers = cartItem.imeiNumbers;
        }

        if (cartItem.attributeInfo) {
            json.attributeInfo = cartItem.attributeInfo;
        }

        return json;
    }

    /**
     * maxSaleId
     * write a document
     *  info
     *  taxes
     *  payment
     *  items
     *  status
     */
    //RelaxClientTodo inv and sales timestamp format changed

    this.commitSale = async function(items, editSaleId, customer_id, refBookingId, employee_id, comment, invoice_number, payments, total, saleOnCreditAmt, timeStamp, checkNo, state_name, roundOffMethod, wcInfo, GSTIN, shippingAddress, globalDiscountInfo, tableNo, isAppointment, appointmentDate, invoiceCheckpoint, iPrefix, saleNum) {

        try {
            await lockUtils.lockAsync(lockPath, CLONE(lockOptions));
            let maxCouchSquence = autoIncrementHelper.getMaxCouchSquenceId() + 1;
            let sale_id = editSaleId ? parseInt(editSaleId.substring(5, editSaleId.length)) : maxCouchSquence;
            let num = editSaleId ? saleNum : autoIncrementHelper.getMaxSaleId() + 1;
            let invoicePrefix = iPrefix;
            if (!timeStamp) {
                timeStamp = parseInt(moment().format('x'));
            } else {
                timeStamp = parseInt(moment(timeStamp).format('x'));
            }

            function getSalesInfo() {
                return {
                    sale_id: sale_id, //Redundant. Remove if no one is using
                    num: num,
                    invoicePrefix: invoicePrefix,
                    invoiceCheckpoint: invoiceCheckpoint,
                    sale_time: timeStamp,
                    refBookingId: refBookingId,
                    checkNo: checkNo,
                    wcInfo: wcInfo,
                    customer_id: customer_id,
                    employee_id: employee_id,
                    comment: comment,
                    invoice_number: invoice_number,
                    total: parseFloat(total),
                    pending_amount: saleOnCreditAmt,
                    type: 1, //sale = 1 return = 2
                    state_name: state_name,
                    GSTIN: GSTIN,
                    round_off_method: roundOffMethod,
                    shippingDetails: shippingAddress,
                    globalDiscountInfo: globalDiscountInfo,
                    tableNo: tableNo,
                    isAppointment: isAppointment,
                    appointmentDate: appointmentDate
                };
            }

            function getItemsAndTaxesAndStatus() {

                //RelaxClientTodo Make sure Json doesn't change for salesdoc                            
                let sale_items = [];
                let saleItemStatus = {};
                for (let key in items) {
                    let cartItem = items[key];
                    sale_items.push(getItemJson(cartItem));

                    let itemAvailable; //undefined so that we don't modify this variable in stock                    
                    let docId = itemsLib.formatInvDocId(cartItem.item_id);
                    let invTrans = {};
                    if (saleItemStatus[docId] && saleItemStatus[docId].doc) {
                        invTrans = saleItemStatus[docId].doc;
                    }
                    var uniqueDetails = {};
                    uniqueDetails = {
                        serialnumber: cartItem.serialnumber,
                        imeiNumbers: cartItem.imeiNumbers
                    }

                    if (cartItem.is_serialized || cartItem.imeiCount !== 0) {
                        cartItem.uniqueDetails = [uniqueDetails];
                    }
                    itemsLib.updateStockHelper(commonLib.getParamsForGettingInvTrans(cartItem, timeStamp, employee_id, invoicePrefix + num, true), invTrans, itemAvailable, true);
                    saleItemStatus[invTrans._id] = {
                        status: 4,
                        doc: invTrans
                    };
                }

                return {
                    sale_items: sale_items,
                    saleItemStatus: saleItemStatus
                };

            }

            let itemsAndTaxesAndStatus = getItemsAndTaxesAndStatus();
            let salesDoc = {
                _id: commonLib.formatSaleId(maxCouchSquence),
                sale_id: sale_id

            };
            salesDoc.sales_info = getSalesInfo();
            salesDoc.payments = payments;
            salesDoc.sale_items = itemsAndTaxesAndStatus.sale_items;

            salesDoc.status = {
                status: 4,
                inventoryTrans: itemsAndTaxesAndStatus.saleItemStatus,
                customers: {}
            }

            let customerVersion = 1;

            if (customer_id) {
                let customerDocId = 'customer_' + customer_id;
                salesDoc.status.customers[customerDocId] = {
                    status: 4,
                    doc: {
                        _id: customerDocId,
                        total: total, //RelaxDanger This is rounded off total. get total without manipulation
                        balance: saleOnCreditAmt,
                        timeStamp: timeStamp,
                        v: customerVersion
                    },
                    v: customerVersion
                }
            };
            let salesCreateResp;
            workerProcess.setFreeze(true);
            if (editSaleId) {
                //sale edit
                var doc = await couchDBUtils.getDoc(editSaleId, mainDBInstance, 'Failed to get  sales Doc. Try Again');
                salesDoc._id = doc._id;
                salesDoc._rev = doc._rev;
                commonLib.mergeStatus(salesDoc.status, doc, timeStamp, true);
                salesCreateResp = await couchDBUtils.update(salesDoc, mainDBInstance, 3, 'Edit Sales Transaction Failed. Try Again');
            } else {
                //sale
                salesCreateResp = await couchDBUtils.create(salesDoc, mainDBInstance, 3, 'Sales Transaction Failed. Try Again');
                autoIncrementHelper.incrementSaleId();
                autoIncrementHelper.incrementCouchSquenceId();
            }

            await lockUtils.unlockAsync(lockPath);
            workerProcess.insertTrans({
                parentDocId: salesDoc._id,
                transactions: salesDoc.status.inventoryTrans,
                itemUpdates: {},
                elementUpdates: salesDoc.status.customers
            });
            workerProcess.setFreeze(false);

            let saleResponse = {
                sale_id: sale_id,
                num: num,
                timeStamp: timeStamp
            };

            return saleResponse;
        } catch (error) {
            await lockUtils.unlockAsync(lockPath);
            workerProcess.setFreeze(false);
            logger.error(error);
            throw error;
        }
    };

    /**
     * rTodo write api validation to check proper data is passed
     * {
     *      items: [], //refer getItemJson for structure
     *      timeStamp: 14511413321,
     *      checkNo: 132321,
     *      customer_id: 1343242,
     *      employee_id: 'admin',
     *      comment: 'hello world',
     *      parentId: 23,
     *      payments: [],
     *      total: 100,
     *      creditAmt: 10
     * }
     * 
     * For Sale Return there is no edit
     */
    this.commitSaleReturn = async function(data) {
        try {

            await lockUtils.lockAsync(lockPath, CLONE(lockOptions));
            let returnId = maxReturnId + 1;
            let retPrefix = data.sReturnPrefix;
            if (!data.timeStamp) {
                data.timeStamp = parseInt(moment().format('x'));
            } else {
                let timeStamp = parseInt(data.timeStamp);
                if (timeStamp === NaN) {
                    timeStamp = data.timeStamp;
                }
                data.timeStamp = parseInt(moment(timeStamp).format('x'));
            }

            function getInfo() {
                return {
                    id: returnId,
                    invoicePrefix: retPrefix,
                    time: data.timeStamp,
                    checkNo: data.checkNo,
                    customer_id: data.customer_id,
                    employee_id: data.employee_id,
                    wcInfo: data.wcInfo,
                    comment: data.comment,
                    parentId: data.parentId,
                    total: parseFloat(data.total),
                    round_off_method: data.round_off_method,
                    GSTIN: data.GSTIN,
                    state_name: data.state_name,
                    globalDiscountInfo: data.globalDiscountInfo,
                    isAppointment: data.isAppointment ? data.isAppointment : false,
                    appointmentDate: data.appointmentDate
                };
            }

            function getItemsAndStatus() {

                //RelaxClientTodo Make sure Json doesn't change for salesdoc                            
                let items = [];
                let inventoryTrans = {};
                for (let key in data.items) {
                    let cartItem = data.items[key];
                    items.push(getItemJson(cartItem));

                    let itemAvailable; //undefined so that we don't modify this variable in stock                    
                    let docId = itemsLib.formatInvDocId(cartItem.item_id);
                    let invTrans = {};
                    if (inventoryTrans[docId] && inventoryTrans[docId].doc) {
                        invTrans = inventoryTrans[docId].doc;
                    }
                    var uniqueDetails = {};
                    if (cartItem.serialnumber || cartItem.imeiNumbers.length) {
                        uniqueDetails = {
                            serialnumber: cartItem.serialnumber,
                            imeiNumbers: cartItem.imeiNumbers
                        }
                    }

                    if (Object.keys(uniqueDetails).length) {
                        cartItem.uniqueDetails = [uniqueDetails];
                    }

                    itemsLib.updateStockHelper(commonLib.getParamsForGettingInvTrans(cartItem, data.timeStamp, data.employee_id, data.sReturnPrefix + returnId, true, true), invTrans, itemAvailable, false);
                    inventoryTrans[invTrans._id] = {
                        status: 4,
                        doc: invTrans
                    };
                }

                return {
                    items: items,
                    inventoryTrans: inventoryTrans
                };

            }

            let itemsAndStatus = getItemsAndStatus();

            let doc = {
                _id: commonLib.formatSaleReturnId(returnId),
                id: returnId,
                num: returnId,
                invoicePrefix: retPrefix
            };
            doc.info = getInfo();
            doc.payments = data.payments;
            doc.items = itemsAndStatus.items;

            doc.status = {
                status: 4,
                inventoryTrans: itemsAndStatus.inventoryTrans,
                customers: {},
                parentDoc: {}
            };

            if (data.customer_id) {
                let customerVersion = 1;
                let customerDocId = 'customer_' + data.customer_id;
                doc.status.customers[customerDocId] = {
                    status: 4,
                    doc: {
                        _id: customerDocId,
                        total: -parseFloat(data.total), //RelaxDanger This is rounded off total. get total without manipulation
                        balance: -data.creditAmt,
                        timeStamp: data.timeStamp,
                        v: customerVersion
                    },
                    v: customerVersion
                }
            };

            let parentDocId = commonLib.formatSaleId(data.parentId);
            doc.status.parentDoc[parentDocId] = {
                status: 4,
                doc: {
                    _id: parentDocId,
                    returnDocId: returnId
                }
            };

            workerProcess.setFreeze(true);
            await couchDBUtils.create(doc, mainDBInstance, 3, 'Sales Return Transaction Failed. Try Again');
            maxReturnId++;
            await lockUtils.unlockAsync(lockPath);
            workerProcess.insertTrans({
                parentDocId: doc._id,
                transactions: doc.status.inventoryTrans,
                itemUpdates: {},
                elementUpdates: doc.status.customers,
                returnUpdates: doc.status.parentDoc
            });
            workerProcess.setFreeze(false);

            return {
                message: 'Return Successful',
                data: {
                    id: returnId
                }
            };
        } catch (error) {
            await lockUtils.unlockAsync(lockPath);
            workerProcess.setFreeze(false);
            logger.error(error);
            throw {
                error: error
            };
        }
    };

};

module.exports = new salesControllerLib2();