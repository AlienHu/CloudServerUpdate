import * as sendSMS from '../../sms/sms';
import * as sendPromoEmail from '../sendPromoEmail'
import * as couchDBUtils from '../common/CouchDBUtils';
const promoKeywords = ['CUSTOMER', 'BIRTHDAY', 'ANNIVERSARY', 'URL'];
const mainDBInstance: any = couchDBUtils.getMainCouchDB();
import * as helper from "../../licencer/licenceHelper";
import * as utils from "../common/Utils";

import { COMPLETED, CmpCustomers, BasicCampaign } from '../crm';
import * as logger from '../../common/Logger';

let sendEmail = async function (doc: BasicCampaign, customer: CmpCustomers, message: string) {
    if (doc.sendEmail && customer.email) {
        console.log("*** have email")
        let requestData = {
            message: message,
            email: customer.email,
            subject: 'Greetings',
        }
        await sendPromoEmail(requestData);
    }
}
/**
 * 
 * @param doc campaign.
 * send promos to the customers and returns count of success;
 * 
 * send Single/Multiple sms based on the message uses keywords
 */
export let sendPromos = async function (doc: BasicCampaign) {
    let count: number = 0;
    let params = {
        Type: "PROMO",
        type: 'promo',
        Multiple: false,
        Msg: doc.message,
        To: ''
    }
    let hasKeyword = promoKeywords.some(k => doc.message.includes(k));

    let custKeys: string[] = [];
    for (let i: number = 0; i < doc.customers.length; i++) {
        custKeys.push(doc.customers[i]._id);
    }

    let allCustomers = await couchDBUtils.getAllDocs(custKeys, mainDBInstance);

    for (let i = 0; i < allCustomers.length; i++) {
        if (!allCustomers[i].doc || allCustomers[i].error) {
            logger.info(doc.customers[i]._id);
            throw allCustomers[i].error;
        }

        if (doc.customers[i].status === COMPLETED) {
            count++;
            continue;
        }

        let customer = allCustomers[i].doc;
        params.Msg = doc.message;
        // commenting bcoz its not tested!
        // if (doc.feedbackFormId) {
        //     var generate_short_url_payload = {
        //         feed_id: doc.feedbackFormId,
        //         custumer_id: customer._id,
        //         mac: helper.getServerSerialNum(),
        //         app_type: process.env.APP_TYPE,
        //         cmp_id: doc._id

        //     };
        //     let url = `http://alienhu.com/user_feedback_view.html?f=${generate_short_url_payload.feed_id}&c=${generate_short_url_payload.custumer_id}&m=${generate_short_url_payload.mac}&a=${generate_short_url_payload.app_type}&s=${generate_short_url_payload.cmp_id}`;
        //     let shortURL: string = await utils.getShortUrl(url);
        //     if (params.Msg.indexOf('URL') === -1) {
        //         params.Msg = params.Msg + ' ' + shortURL;
        //     }
        //     else {
        //         params.Msg = params.Msg.replace(/URL/g, shortURL);
        //     }
        // }

        if (hasKeyword) {
            params.Msg = params.Msg.replace(/CUSTOMER/g, customer.first_name);
            params.Msg = params.Msg.replace(/BIRTHDAY/g, customer.birth_date);
            params.Msg = params.Msg.replace(/ANNIVERSARY/g, customer.anniversary);
            params.To = customer.phone_number;
            try {
                await sendSMS(params);
                await sendEmail(doc, customer, params.Msg);
                count++;
                doc.customers[i].status = COMPLETED;
            } catch (error) {
                //
            }
        } else {
            params.To = params.To ? params.To + ',' + customer.phone_number : customer.phone_number;
        }
    }

    if (!hasKeyword) {
        params.Msg = doc.message;
        params.Multiple = true;
        try {
            await sendSMS(params);
            //This is inaccurate. As few sms would have sent successfully and few failed. Improve the logic.
            count = allCustomers.length;
            doc.customers.forEach(async function (cus, i) {
                cus.status = COMPLETED;
                await sendEmail(doc, allCustomers[i].doc, params.Msg);
            });
        } catch (error) {
            logger.error(error);
        }
    }

    return count;
}