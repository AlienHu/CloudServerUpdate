import * as moment from 'moment';
import Moment = moment.Moment;

import { ScheduledCampaign, ScheduleStatus, PENDING } from "../crm";

//https://momentjs.com/docs/
export let generateSchedules = function (data: ScheduledCampaign): void {
    data.timeOfDayArr.sort();
    data.dayOfWeekArr.sort();

    // let scheduleStatusArr: ScheduleStatus[] = data.scheduleStatusArr = [];
    let startTime: Moment = moment(data.startDate).startOf('day');
    let endTime: Moment = moment(data.endDate).endOf('day');
    data.scheduleStatusArr = getAllScheduleStatusArr(startTime, endTime, data.dayOfWeekArr, data.timeOfDayArr);

}

function getAllScheduleStatusArr(startDate: Moment, endDate: Moment, dayOfWeekArr: number[], timeOfDayArr: string[]): ScheduleStatus[] {
    let scheduleStatusArr: ScheduleStatus[] = [];
    let curDateTime: Moment = moment();
    if (startDate < curDateTime) {
        startDate = moment(curDateTime);
    }
    while (startDate <= endDate) {
        let day = parseInt(startDate.format('e'));
        if (dayOfWeekArr.indexOf(day) !== -1) {
            timeOfDayArr.forEach(function (time) {
                let date = new Date(time);
                let hours: number = date.getHours();
                let minutes: number = date.getMinutes();
                let ts: string = moment(startDate).startOf('day').add(hours, 'h').add(minutes, 'm').format('x');
                scheduleStatusArr.push({ timestamp: ts, status: PENDING });
            });
        }
        startDate.add(1, 'day');
    }
    return scheduleStatusArr;
}