var validator = require('validator');
var math = require('mathjs');
var responseUtil = require('../common/responseJson');
var lockUtils = require('../common/lockUtils');
lockUtils.createLockDir('locks/variants');

var Variants = function() {
    var _self = this;
    var moment = require('moment');
    var BPromise = require('bluebird');

    require('errors');

    var lockPath = 'locks/variants/variant.lock';
    var lockOptions = {
        stale: 5000,
        retries: 5,
        retryWait: 1000
    };

    var utils = require('./common/Utils');
    var couchDBUtils = require('./common/CouchDBUtils');
    var mainDBInstance = couchDBUtils.getMainCouchDB();
    var logger = require('../common/Logger');
    var respJsonUtil = require('../common/responseJson');

    var maxId = require('./common/autoIncrementHelper').getMaxVariantId();

    function perProcessInputData(requestData) {
        var preProcessedArray = [];
        preProcessedArray.name = requestData.name;
        for (value in requestData.values) {
            preProcessedArray.push(requestData[value]);
        }
        return preProcessedArray;
    }

    function isValidInput(inputArray) {

        for (var i = 0; i < inputArray.values.length; i++) {
            for (var j = i + 1; j < inputArray.values.length; j++) {
                if (inputArray.values[i] == inputArray.values[j]) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * {
        name:"Color",
        headers: ["name", "code", "alias"],
        value:[{name:"Red",code:"#Red", alias: "R"},{"name":"Blue",code:"#blue", alias: "B"}]
    }
     */
    this.runVariantValidations = function(requestData, bUpdate) {
        if (validator.isEmpty(String(requestData.name))) {
            delete requestData.name;
            return Promise.reject('Variant name cannot be empty');
        }

        if (!requestData.values) {
            return Promise.reject("Variant values cannot be empty");
        }

        var preProcessInputArray = {};
        preProcessInputArray.values = {};
        preProcessInputArray.name = requestData.name;

        if (!bUpdate) {
            for (var i = 0; i < requestData.values.length; i++) {
                preProcessInputArray.values[i + 1] = requestData.values[i];
            }
        } else {
            var i = 1;
            //Assuming that new values are added at the top of input 
            var valuesObj = Object.keys(requestData.values);
            var ids = [];
            for (var val in valuesObj) {
                if (!isNaN(valuesObj[val])) {
                    ids.push(parseInt(valuesObj[val]));
                }
            }
            ids.sort(function(a, b) {
                return parseInt(a) - parseInt(b);
            })
            var lastValueId = ids[ids.length - 1] + 1;

            for (var valueIdx in requestData.values) {
                if (isNaN(valueIdx)) {
                    preProcessInputArray.values[lastValueId + ""] = utils.clone(requestData.values[valueIdx]);
                    lastValueId++;
                } else {
                    preProcessInputArray.values[valueIdx] = utils.clone(requestData.values[valueIdx]);
                }

            }
        }
        var valueIds = Object.keys(preProcessInputArray.values).length;
        if (!valueIds) {
            return Promise.reject("Variant values cannot be empty");
        } else {
            var namesObj = {};
            for (var i = 1; i <= valueIds; i++) {
                var value = preProcessInputArray.values[i];

                var name = value.name;
                name = name.toLowerCase();
                if (namesObj.hasOwnProperty(name)) {
                    return Promise.reject("Duplicate variant values found (" + name + ")");
                } else {
                    namesObj[name] = 1;
                }
            }
        }

        let nameLowerCase = requestData.name.toLowerCase();
        var params = {
            key: nameLowerCase
        };
        return couchDBUtils.getView('all_variants_data', 'all_variants_unique_data', params, mainDBInstance).then(function(resp) {
            var msg = "should be unique";
            var bUnique = true;
            for (var i = 0; i < resp.length; i++) {

                if (resp[i].key == nameLowerCase) {
                    if (bUpdate && requestData._id === resp[i].id) {
                        continue;
                    }
                    return Promise.reject("Variant name " + requestData.name + " already exist");
                }
            }
            preProcessInputArray.values = preProcessInputArray.values;
            return preProcessInputArray;
        });
    }

    this.create = function(requestData) {
        var response = respJsonUtil.get2();
        var newVariantId;
        var bCalledCreate = false;
        var variantName = requestData.name;
        return lockUtils.lockAsync(lockPath, utils.clone(lockOptions)).then(function() {
            return _self.runVariantValidations(requestData);
        }).then(function(processedInputData) {
            var newId = maxId + 1;
            processedInputData._id = "variant_" + newId;
            processedInputData.id = newId;
            newVariantId = newId;
            bCalledCreate = true;
            return couchDBUtils.create(processedInputData, mainDBInstance);
        }).then(function(couchResponse) {
            maxId++;
            lockUtils.unlockAsync(lockPath);
            response.message = variantName + " created Successfully";
            response.data.id = couchResponse[0].id;
            response.data.var_id = newVariantId;
            return response;
        }).catch(function(error) {
            lockUtils.unlockAsync(lockPath);
            if (bCalledCreate) {
                response.error = variantName + " creation failed";
                response.msg = variantName + " creation failed";
            } else {
                response.error = error;
                response.msg = error;
            }
            return Promise.reject(response);
        });

    }

    this.update = function(requestData) {
        var response = responseUtil.get2();
        var bCalledUpdate = false;
        return lockUtils.lockAsync(lockPath, utils.clone(lockOptions)).then(function() {
            return _self.runVariantValidations(requestData, true);
        }).then(function(processedInputData) {
            bCalledUpdate = true;
            processedInputData.id = requestData.id;
            processedInputData._id = "variant_" + requestData.id;
            return couchDBUtils.update(processedInputData, mainDBInstance);
        }).then(function(couchResponse) {
            lockUtils.unlockAsync(lockPath);
            response.message = "Variant updated successfully";
            response.data.id = couchResponse[0].id;
            return response;
        }).catch(function(error) {
            lockUtils.unlockAsync(lockPath);
            if (bCalledUpdate) {
                response.message = "Failed to update variant";
            } else {
                response.error = error;
            }
            return Promise.reject(response);
        });
    }

    this.delete = function(requestData) {
        var response = responseUtil.get2();
        if (!requestData.id) {
            response.error = "Invalid variant id";
            return Promise.reject(response);
        }
        return lockUtils.lockAsync(lockPath, utils.clone(lockOptions)).then(function() {
            return couchDBUtils.addDeleteFlag({
                _id: "variant_" + requestData.id
            }, mainDBInstance);
        }).then(function(couchResponse) {
            lockUtils.unlockAsync(lockPath);
            response.message = "Variant deleted successfully";
            response.data.id = requestData.id;
            return response;
        }).catch(function(error) {
            lockUtils.unlockAsync(lockPath);
            response.error = "Failed to delete variant";
            return Promise.reject(response);
        });
    }

};
module.exports = new Variants();