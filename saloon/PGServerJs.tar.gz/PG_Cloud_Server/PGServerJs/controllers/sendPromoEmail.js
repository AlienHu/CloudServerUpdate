//To Do: Add email-template and nodemailer in package.json

var EmailTemplate = require('email-templates').EmailTemplate;
var nodemailer = require('nodemailer');
var path = require('path');
const moment = require('moment');
var templateDir = path.resolve(__dirname, '../templates');
var template = new EmailTemplate(path.join(templateDir, 'promoEmailTemplate'));

//function to send email to customer
var sendMailToCustomer = function(requestData, response) {
    return new Promise(function(resolve, reject) {
        //3. sender's credentials -- This should also come from app config file
        var credentials = {
            service: 'gmail',
            auth: {
                user: 'profitguruhelpdesk@gmail.com',
                pass: 'wearethebest'
            }
        };

        //define nodemailer transporter with the credentials
        var transporter = nodemailer.createTransport(credentials);

        //variable to store emailId
        var custEmailId = requestData.email;

        // ToDo:
        // This data will come in requestData argument. Need to read data and populate it template.
        // Template needs to be finalized.
        var locals = {
            message: requestData.message,
            date: moment()
        };

        template.render(locals, function(err, results) {
            if (err) {
                console.log(err);
                reject(err);
            }

            console.log(results.html.toString());
            console.log(results.text.toString());

            // ToDo : This mail options needs to be read from app config file
            var mailOptions = {
                from: '"ProfitGuru POS" <profitguruhelpdesk@gmail.com>', // sender address
                to: custEmailId, // list of receivers
                subject: requestData.subject,
                html: results.html,
                text: results.text,
            };

            transporter.sendMail(mailOptions, function(err, responseStatus) {
                if (err) {
                    console.error(err);
                    reject(err);
                };
                console.log(responseStatus);
                resolve(responseStatus);
            })

            console.log(err);
        });
    });
}

module.exports = function(requestData, resposne) {
    return sendMailToCustomer(requestData, resposne);
};