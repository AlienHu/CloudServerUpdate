/**
 * import/export -> variable/function/interface/class
 *
 */

import * as couchDBUtils from './common/CouchDBUtils';
import * as schedular from './libraries/scheduler';

import * as moment from 'moment';
import Moment = moment.Moment;
import * as logger from '../common/Logger';
import { fail } from 'assert';
import { generateSchedules } from './libraries/scheduleCampaignHelper';
const mainDBInstance: any = couchDBUtils.getMainCouchDB();

export let COMPLETED = 'completed';
export let PENDING = 'pending';
export let FAILED = 'failed';
export const WISHER = 'wisher';
const VISIT_PREFIX = 'visit';
const CRM_TEMPLATE_PREFIX = 'ct';

export let createCampaign = function (data: Campaign): Promise<apiResponse> {
    let ts = moment().format('x');
    data._id = 'cmp_' + ts;
    if (!data.eventDateTime) {
        throw 'EventDateTime is Mandatory.';
    }
    data.eventDateTime = moment(data.eventDateTime).format('x');
    return create(data);
}

export let create = async function (data: BasicCampaign): Promise<apiResponse> {
    let response: apiResponse = {} as apiResponse;
    //console.log(JSON.stringify(data, null, 2));
    try {
        let dataArray = [];
        let { templateType, template, bUpdate }: PrepareTemplateOut = prepareTemplateDoc(data);
        //to create/update document
        if (bUpdate) {
            data.templateType = templateType;
            data.template = template;
            dataArray.push(data.templateType);
        }
        dataArray.push(data);
        await couchDBUtils.bulkDocs(dataArray, mainDBInstance);
        schedular.startJob();

    } catch (error) {
        logger.error(error);
        response.error = 'campaign create failed';
        throw response;
    }

    response.msg = 'campaign create success';
    return response;

}
export let updateCampaign = function (data: Campaign): Promise<apiResponse> {
    if (!data.eventDateTime) {
        throw 'EventDateTime is Mandatory.';
    }
    data.eventDateTime = moment(data.eventDateTime).format('x');
    return update(data);
}
//campaign update
//todo allow to create/update templates from update campaign also
export let update = async function (data: BasicCampaign): Promise<apiResponse> {
    let response: apiResponse = {} as apiResponse;

    try {
        let { templateType, template, bUpdate }: PrepareTemplateOut = prepareTemplateDoc(data);
        data.templateType = templateType;
        data.template = template;
        let dataArray = [];
        if (bUpdate) {
            //to create/update document
            dataArray.push(data.templateType);
        }
        dataArray.push(data);
        await couchDBUtils.bulkDocs(dataArray, mainDBInstance);
    } catch (error) {
        response.error = 'campaign update failed';
        throw response;
    }
    return response;
}

export let deleteCampaign = async function (data: BasicCampaign): Promise<apiResponse> {
    let response: apiResponse = {} as apiResponse;
    try {
        await couchDBUtils.delete(data, mainDBInstance);
    } catch (error) {
        response.error = 'campaign delete failed';
        throw response;
    }
    return response;
}

function prepareTemplateDoc(data: BasicCampaign): PrepareTemplateOut {
    let ts = moment().format('x');
    let template: Template = {
        "message": data.message
    };
    let templateType: TemplateType;

    let bUpdate: boolean = false;
    if (data.templateTypeName && data.isTemplate) { // add the new template
        templateType = {
            "name": data.templateTypeName,
            "templates": [template],
            "_id": CRM_TEMPLATE_PREFIX + '_' + ts

        }
        bUpdate = true;
    } else if (data.templateType && data.isTemplate) { // update the template
        templateType = data.templateType;
        templateType.templates.push(template);
        bUpdate = true;
    } else {
        //no create/update is required
    }

    return { templateType: templateType, template: template, bUpdate: bUpdate };
}

//isDeleted = "1"
export let updateTemplateType = async function (data: TemplateType): Promise<apiResponse> {
    let bUpdate: boolean = false;
    if (data._rev) {
        bUpdate = true;
    }

    let ts: string = moment().format('x');
    if (!bUpdate) {
        data._id = CRM_TEMPLATE_PREFIX + '_' + ts;
    }

    let response: apiResponse = {} as apiResponse;
    try {
        await couchDBUtils.createOrUpdate(data, mainDBInstance);
        response.msg = 'Template Type Updated Successfully.';
    } catch (error) {
        logger.error(error);
        response.error = 'Template Type Update failed';
        throw response;
    }

    return response;
}
async function getUpdatedTransactions(data: Visit) {
    let custKeys: string[] = [];
    data.customers.forEach(c => {
        custKeys.push(c._id);
    });

    let allCustomers = await couchDBUtils.getAllDocs(custKeys, mainDBInstance);
    let customerDocs = [];

    for (let i = 0; i < allCustomers.length; i++) {
        if (!allCustomers[i].doc || allCustomers[i].error) {
            throw allCustomers[i].error;
        }
        let ts: string = moment().format('x');
        let doc = allCustomers[i].doc;
        let date = new Date(parseInt(ts));
        let year = date.getFullYear();
        let month = date.getMonth();
        let key = year + '-' + month;

        if (!doc.stats) {
            doc.stats = {};
        }
        if (!doc.stats[key]) {
            doc.stats[key] = 0;
        }
        if (!doc.visitCount) {
            doc.visitCount = 0;
        }
        doc.stats[key]++;
        doc.visitCount++;
        doc.lastTS = ts;
        doc.total += data.total;
        customerDocs.push(doc);
    }
    return customerDocs;

}

export let visit = async function (data: Visit): Promise<apiResponse> {

    // console.log("*** crm.visit" + JSON.stringify(data));
    let bUpdate: boolean = false;
    let response: apiResponse = {} as apiResponse;
    if (data._rev) {
        bUpdate = true;
    }
    let ts: string = moment().format('x');
    if (!bUpdate) {
        data._id = VISIT_PREFIX + '_' + ts;
    }
    let dataArray = [];
    dataArray.push(data);
    let customerDocs = await getUpdatedTransactions(data);
    if (!customerDocs.length) {
        console.log("*** No customers found");
        throw "No customers found";
    }
    dataArray = dataArray.concat(customerDocs);
    try {
        await couchDBUtils.bulkDocs(dataArray, mainDBInstance);
        response.msg = 'Visit added successfully';
    } catch (error) {
        logger.error(error);
        response.error = 'Visit update failed';
        throw response;
    }

    return response;
}

export let createSchedule = async function (data: ScheduledCampaign): Promise<apiResponse> {
    let ts = moment().format('x');
    data._id = 'schedule_' + ts;
    if (!data.timeOfDayArr.length) {
        throw 'Time is Mandatory.';
    }
    generateSchedules(data);
    return create(data);
}

export let updateSchedule = async function (data: ScheduledCampaign): Promise<apiResponse> {
    if (!data.timeOfDayArr) {
        throw 'Time is Mandatory.';
    }
    return update(data);
}

export let saveWisher = async function (data: Wisher): Promise<apiResponse> {
    let ts = moment().format('x');
    if (!data.timeOfDayArr.length) {
        throw 'Time is Mandatory.';
    }
    if (!data._rev) {
        data._id = WISHER + '_' + ts;
        return create(data);
    }
    return update(data);
}

export interface Wisher extends ScheduledCampaign {
    daysBefore: number;
    type: string;//birth_date,anniversary,
    onType: string,
    repeat: string
}

export interface ScheduledCampaign extends BasicCampaign {
    startDate: Timestamp; //Javascrpt Date Object
    endDate: Timestamp;
    dayOfWeekArr: number[]; //0 -6
    timeOfDayArr: string[]; //Javascript Date Object
    scheduleStatusArr: ScheduleStatus[]
}

export interface ScheduleStatus {
    timestamp: Timestamp;
    status: string;
}

export type Timestamp = string;

interface Visit {
    _id: string,
    _rev: string,
    total: number,
    comments: string,
    customers: CmpCustomers[],
    date: string
}

export interface Campaign extends BasicCampaign {
    eventDateTime: string;
}

interface TemplateType {
    _id: string;
    _rev?: string;
    name: string; //Birthday, Christmas
    templates: Template[];
}
interface Template {
    message: string;
}
export interface CmpCustomers {
    _id: string,
    status: string,
    email: string
}

export interface apiResponse {
    msg: string;
    data: any;
    error: string;
}

interface PrepareTemplateOut {
    templateType: TemplateType;
    template: Template;
    bUpdate: boolean;
}

export interface BasicCampaign {
    message: string;
    template: Template; //Selected Template from TemplateType
    templateType: TemplateType; //Birthday, Christmas full details
    _id: string;
    _rev?: string;
    templateTypeName?: string; //Birthday, Christmas
    isTemplate: boolean; //Save the template checkbox in UI
    sendEmail: boolean;
    sendSMS: boolean;
    customers: CmpCustomers[];
    status: string;
    nextTime: string;
    retryCount: number;
    feedbackFormId?: string;
}