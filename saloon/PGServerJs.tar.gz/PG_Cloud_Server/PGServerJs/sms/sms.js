/*
 * 0. enableSMS (serverId, noSMS, pgsettings, profiles)
 * 1. sendSMS(to, body, senderId) -> (fail: (nointernet, balance over)
 * 2. getSMSStats(senderId) -> (fail: noInternet) (balance, pack1000)
 *      send apiurl where the delivery report can be called. have some logic to count based on senderid -> serverID
 * 
 * 1. User settings - multiple, smstype(promo/trans)
 * 2. PG Settings - apiURl, apiKey,promolinkadd
 * 3. user form 
 * 
 * OTP
 * 1. sendOTP(to) -> (fail: nointernet)(success)
 * 2. validateOTP(otp) -> (success, fail)
 * 3. resendOTP(to) -> (fail: nointernet)
 * 4. getSMSStats(): NOT STARTED
 */

const couchMain = require('../couchDb/couchDBMain.js');
var couchDBUtils = require('../controllers/common/CouchDBUtils.js');
var coreDBInstance = couchDBUtils.getCoreCouchDB();
var mainDBInstance = couchDBUtils.getMainCouchDB();
const licenceDBInstance = couchDBUtils.getLicenceDB();
var request = require('request');
const httpUtils = require('../common/httpUtils');
const logger = require('../common/Logger');
const follow = require('follow');

//TODO: read from db
var apiUrl = '';
var apiKey = '';
var promoLinkAdd = '';
let sender = 'ALNTST';
let linkAddOn = '';
const customerId = '';
const smsDb = 'pg_seller_sms';
var sms_setting_seller_doc = 'sms_settings_seller';
var sms_setting_pg_doc = 'sms_settings_pg';
var otpDb = '';

/**
 * 
 * @param {*} params 
 * throws in the following cases
 * 1. smsConfig not set
 * 2. smsConfig is not valid
 * 3. msg is empty
 * 4. Multiple is false but To has multiple phone numbers
 * 5. Quota crossed
 * 6. Internet or some other error
 */
var sendSMS = async function(params) {
    var app = params.app;
    var response = {};
    var msgCount = 1;
    var toCount = 1;
    let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstance);

    // await couchDBUtils.update(applicationSettings, nanoCore, 2);
    /*
     * params={
     *      To:'9572362138',
     *      Msg: 'sms message'
     *      Multiple: true [OPTIONAL],
     *      Type: 'PROMO' [OPTIONAL],
     *      From: 'ALNHPG' [OPTIONAL]
     * }
     *
     */
    if (!smsConfig) {
        var resp = {};
        resp.msg = 'sms config json not set';
        resp.status = 'error';
        throw resp;
    }
    if (!smsConfig.apiUrl || !smsConfig.apiKey || !smsConfig.promoLinkAdd || !smsConfig.promoQuota || !smsConfig.transQuota) {
        logger.error('sms config not set')
        var resp = {};
        resp.msg = 'sms config json not set';
        resp.status = 'error';
        throw resp;
    } else {
        apiUrl = smsConfig.apiUrl;
        apiKey = smsConfig.apiKey;
        transLinkAdd = smsConfig.transLinkAdd;
        promoLinkAdd = smsConfig.promoLinkAdd;
    }
    if (!params.Type) {
        params.Type = 'PROMO';
    }
    if (!params.From) {
        params.From = sender;
    }
    if (smsConfig.sender) {
        params.From = smsConfig.sender;
    }
    if (!params.Msg) {
        response.msg = 'empty msg';
        throw response;
    }
    if (params.Msg.length > 160) {
        response.msg = 'msg length should be max of 160 characters';
        msgCount = parseInt(parseInt(params.Msg.length / 160) + 1);
    }
    if (!params.Multiple) {
        params.Multiple = true;
    }

    if (params.Multiple == false && params.To.length > 13) {
        response.msg = 'trying to send sms to multiple users';
        throw response;

    }

    if (params.Type == 'TRANS') {
        linkAddOn = transLinkAdd;
    } else {
        linkAddOn = promoLinkAdd;
    }
    var requestBuilder;
    let viaGupshup = false;
    if (smsConfig.gupshup && smsConfig.gupshup.value && smsConfig.gupshup.query.override_dnd) {
        logger.info("Send sms using gupshup");
        viaGupshup = true;
        if (params.bWelcome) {
            params.Msg += " To opt out SMS " + smsConfig.sender + " to 9220092200";
        }
        if (params.Type == 'PROMO') {
            logger.info("Checking dnd numbers.." + params.To);
            let numberArr = params.To.split(',');
            logger.info("DND numbers " + DND_CUS_ARR);
            let nonDNDNos = numberArr.filter(function(num) { //find the non dnd no's
                if (num.length <= 10) {
                    num = '91' + num;
                }
                return !DND_CUS_ARR.includes(num);
            });
            params.To = nonDNDNos.toString();
            logger.info("Non DND number(s) : " + params.To);
            if (nonDNDNos.length === 0) {
                response.msg = 'Found a dnd numner';
                throw 'Found a dnd numner';
            }
        }
        let q1 = {
            send_to: params.To,
            msg: params.Msg,
            mask: smsConfig.sender
        }
        let query = Object.assign(smsConfig.gupshup.query, q1);
        requestBuilder = {
            url: smsConfig.gupshup.url,
            method: "GET",
            json: true,
            qs: query,
            headers: {
                "Content-Type": "application/json"
            }
        }
    } else {
        requestBuilder = {
            url: apiUrl + '/' + apiKey + '/' + linkAddOn,
            method: "POST",
            json: true,
            body: params,
            headers: {
                "Content-Type": "application/json"
            }
        }
    }
    try {
        toCount = params.To.split(',').length;
    } catch (err) {
        toCount = ((params.To.length - 1) % 10) + 1;
    }
    var totalSMSCount = parseInt(msgCount * toCount);
    if (params.Type == 'PROMO' && smsConfig.promoQuota && (smsConfig.promoQuota < applicationSettings.smsCounter.promoCounter + totalSMSCount)) {
        response.msg = 'promo sms quota reached';
        throw response;
    } else if (params.Type == 'TRANS' && smsConfig.transQuota && (smsConfig.transQuota < applicationSettings.smsCounter.transCounter + totalSMSCount)) {
        response.msg = 'trans sms quota reached';
        throw response;
    }
    try {
        let response = await httpUtils.http(requestBuilder);
        if (viaGupshup && response.body.response.status === 'error') { // Send sms failed from gupshup
            logger.error(response.body.response.details);
            throw response.body.response.details;
        }
        if (response.msg == 'Success' || response.body.response.status === 'success') {

            if (!applicationSettings.smsCounter.promoCounter) applicationSettings.smsCounter.promoCounter = 0;
            if (!applicationSettings.smsCounter.transCounter) applicationSettings.smsCounter.transCounter = 0;
            if (params.Type == 'PROMO') applicationSettings.smsCounter.promoCounter += parseInt(msgCount * toCount);
            else applicationSettings.smsCounter.transCounter += parseInt(msgCount * toCount);
            response.msg = 'Success' // for gupshup
            try {
                let resp = await couchDBUtils.update(applicationSettings, coreDBInstance);
            } catch (err) {
                err.msg = 'couldnt update counter';
                logger.error(err);
            }
        }
        return response;
    } catch (error) {
        response.err = error;
        response.msg = 'failed due to internet';
        throw response;
    }
}

var getSMSStats = async function(customerId) {
    if (!customerId) {
        response.msg = 'empty customer Id';
        throw response;
    }
    try {
        var resp = couchBDUtils.getDoc(customerId, 'pg_seller_sms');
        response = resp;
        response.msg = 'permitted';
        // console.log(response);
        return response;
    } catch (err) {
        response.msg('Failed to check your quota.');
        throw response;
    }
}
var setSMSSettingsforSeller = async function(params) {
    var response = {};
    if (!params.type) {
        params.type = 'PROMO';
    }
    if (!params.multiple) {
        params.multiple = false;
    }
    var jsonDOC = {
        serverId: params.serverId,
        senderId: params.senderId,
        type: params.type,
        multiple: params.multiple,
    }
    try {
        //update if already exists
        await couchBDUtils.update(jsonDOC, smsDb, 1);
        response.msg = 'updated settings';
        return response;
    } catch (err) {
        try {
            // insert new doc 
            await couchBDUtils.create(jsonDOC, smsDb, 1, 'failed to set the settings');
            response.msg = 'created settings for sms';
            return response;
        } catch (err) {
            response.msg = 'failed to update settings';
            throw response;
        }

    }
}
var setSMSSettingsforPG = async function(params) {
    if (!params.apiUrl || !params.apiKey || !params.packLinkAddOn) {
        response.msg = 'empty settings';
        throw response;
    }
    var jsonDOC = {
        _id: sms_setting_pg_doc,
        apiUrl: params.apiUrl,
        apiKey: params.apiKe,
        packLinkAddOn: params.packLinkAddOn
    }
    // should be in sync from cloud
    try {
        //update ifalready exists
        await couchBDUtils.update(jsonDOC, smsDb, 1);
    } catch (err) {
        try {
            // insert new doc 
            await couchBDUtils.create(jsonDOC, smsDb, 1, 'failed to set the settings');
        } catch (err) {
            response.msg = 'failed to update settings';
            throw response;
        }

    }
}
var enableSMS = async function(params) {
    if (!params.sellerId || !params.noOfSMS) {
        response.msg = 'insufficient inputs';
        throw response;
    }
    // TODO: check maximum number of noOfSMS...10000?
    if (!params.type) params.type = 'PROMO';
    if (!params.multiple) params.multiple = false;
    try {
        await setSMSSettingsforSeller(params);
    } catch (err) {
        response.msg = 'failed to enable sms feature';
        response.err = err;
        throw response;
    }

}
var sendOTP = async function(to) {
    var options = {
        method: 'GET',
        url: apiUrl + '/' + apiKey + '/' + '/SMS/' + to + '/AUTOGEN',
        headers: {
            'content-type': 'application/x-www-form-urlencoded'
        },
        form: {}
    };
    try {
        let resp = await request(options);
        var sessionID = resp.Details;
        // TODO: push sessionID on cloud for verification
        var now = new Date();
        var jsonDOC = {
            _id: now + '_' + sessionID,
            sessionID: sessionID,
            user: to,
            timestamp: now
        }
        // TODO: remove db 
        resp = couchBDUtils.create(jsonDOC, otpDb, 1, 'failed to store otp to cloud');
        response.msg = 'otp pushed to cloud';
        response.docId = now + '_' + sessionID;
        return response;
    } catch (error) {
        response.msg = 'failed while pushing otp to cloud';
        response.err = error;
        throw response;
    }
}

var reSendOTP = async function(sessionDoc) {
    let to = '';
    try {
        var resp = await couchBDUtils.getDoc(sessionDoc, otpDb, 'propagate');
        to = resp.user;
    } catch (err) {
        response.msg = 'failed to get sessionId';
        response.err = err;
        throw response;
    }
    try {
        couchBDUtils.delete({
            _id: sessionDoc
        }, otpDb);
    } catch (err) {}
    return (await sendOTP(to));
}
var validateOTP = async function(sessionDoc, otp) {
    var sessionId = '';
    try {
        var resp = await couchBDUtils.getDoc(sessionDoc, otpDb, 'propagate');
        sessionID = resp.sessionID;
    } catch (err) {
        response.msg = 'failed to get otp from sessionDoc';
        response.err = err;
        throw response;
    }

    var options = {
        method: 'GET',
        url: apiUrl + '/' + apiKey + '/' + '/SMS/' + to + '/' + otp,
        headers: {
            'content-type': 'application/x-www-form-urlencoded'
        },
        form: {}
    };
    try {
        var resp = await request(options);
        if (resp.Details == 'OTP Matched' && resp.Status == 'Success') {
            response.msg = 'success';
            return response;
        } else {
            response = resp;
            response.msg = 'session expired';
            throw response;
        }
    } catch (err) {
        response = err;
        response.msg = 'otp not verified';
        throw response;
    }
}

// try {
//     console.log(getSMSStats({
//         customerId: 'dpk',
//     }));
// } catch (err) {
//     console.log(err);
// }

// try {
//     console.log('...');
//     var resp = sendSMS({
//         "To": 9742998737,
//         "Msg": "dpk here"
//     });
//     return resp;
// } catch (err) {
//     console.log(err);
//     throw err;
// }

const SMS_INFO_DOC_NAME = 'smsInfo';
async function listenToChanges() {
    try {
        let smsInfo = await couchDBUtils.getDoc(SMS_INFO_DOC_NAME, licenceDBInstance);
        logger.info('smsinfo found');
        setSMSConfig(smsInfo);
    } catch (error) {
        logger.info('smsinfo is not set ' + JSON.stringify(error));
    }

    let count = 0;
    follow({
        db: couchMain.getLicencedbUrl(),
        include_docs: true,
        // doc_ids: [SMS_INFO_DOC_NAME],
        filter: function(doc, req) {
            if (doc._id != SMS_INFO_DOC_NAME) {
                return false;
            }
            return true;
        },
        since: 'now'
    }, function(error, change) {
        if (!error) {
            count++;
            setTimeout(function() {
                count--;
                if (count === 0) {
                    //handle delete
                    if (change.deleted) {
                        smsConfig = undefined;
                    } else {
                        setSMSConfig(change.doc);
                    }
                }
            }, 1000);

        }
    });
}

async function listenToDNDCus() {
    try {
        logger.info("*** listenToDNDCus.sms.js SENDERID : " + SENDERID);
        let doc = await couchDBUtils.getDoc(SENDERID, mainDBInstance);
        logger.info('DND_CUS_ARR found');
        updateDNDNums(doc);
    } catch (error) {
        logger.info("DND customers are not exists");
    }

    let count = 0;
    follow({
        db: couchMain.getMaindbUrl(),
        include_docs: true,
        // doc_ids: [SENDERID],
        filter: function(doc, req) {
            if (doc._id === SENDERID) {
                return true;
            }
            return false;
        },
        since: 'now'
    }, function(error, change) {
        if (!error) {
            count++;
            setTimeout(function() {
                count--;
                if (count === 0) {
                    //handle delete
                    if (change.deleted) {
                        DND_CUS_ARR = [];
                    } else {
                        updateDNDNums(change.doc);
                    }
                }
            }, 1000);

        }
    });
}

let smsConfig;
let SENDERID;
let DND_CUS_ARR = [];

function updateDNDNums(customerArr) {
    if (!customerArr.numberArr) {
        return;
    }
    DND_CUS_ARR = customerArr.numberArr;
    logger.info("updated DND numbers new DND_CUS_ARR is " + DND_CUS_ARR);
}

function setSMSConfig(smsInfo) {
    logger.info('new config found');
    smsConfig = {
        "apiUrl": smsInfo.apiUrl,
        "apiKey": smsInfo.apiKey,
        "transLinkAdd": smsInfo.transLinkAdd,
        "promoLinkAdd": smsInfo.promoLinkAdd,
        "sender": smsInfo.sender,
        "transQuota": 0,
        "promoQuota": 0,
        "gupshup": smsInfo.gupshup
    };
    SENDERID = 'senderId_' + smsInfo.sender;
    for (let i = 0; i < smsInfo.transQuotaList.length; i++) {
        smsConfig.transQuota += smsInfo.transQuotaList[i].count;
    }

    for (let i = 0; i < smsInfo.promoQuotaList.length; i++) {
        smsConfig.promoQuota += smsInfo.promoQuotaList[i].count;
    }
    listenToDNDCus();
    //logger.info(smsConfig);
}

listenToChanges();

module.exports = function(params) {
    return sendSMS(params);
};