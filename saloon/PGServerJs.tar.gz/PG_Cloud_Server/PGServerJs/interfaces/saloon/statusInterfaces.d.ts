import { APPOINTMENT } from "../../types/saloon/dataInterfaces/appointment";
export interface STATUS {
    code: string;
    message: string;
}

export interface FUNCTIONS {
    (appoint: APPOINTMENT): STATUS;
}