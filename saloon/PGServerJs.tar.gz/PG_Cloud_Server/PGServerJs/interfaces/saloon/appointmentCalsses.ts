import { APPOINTMENT } from "../../types/saloon/dataInterfaces/appointment";
import { FUNCTIONS, STATUS } from "./statusInterfaces";
// import * as appointData from "./sales_merge_appointment.json";
const appointData = {
    "_id": "appointment_booking",
    "_rev": "2-5dc8eb066e5017485a1bf520077e2958",
    "sale_id": "appointment_id",
    "sales_info": {
        "sale_id": "sale_id",
        "sale_time": "service_checkout_time",
        "customer_id": "customer_id",
        "employee_id": "employee_id",
        "comment": "",
        "invoice_number": null,
        "total": 1.11,
        "pending_amount": 0,
        "type": "undefiend",
        "round_off_method": "none",
        "globalDiscountInfo": {
            "amt": 0,
            "percent": 0,
            "discountMethod": "onTotal"
        }
    },
    "payments": [
        {
            "payment_type": "Cash",
            "payment_amount": 1.11
        }
    ],
    "tracking_status": [
        {
            "status": "string",
            "tracking_code": "string",
            "time": "string"
        },
        {
            "status": "string",
            "tracking_code": "string",
            "time": "string"
        }
    ],
    "sale_items": [
        {
            "name": "service_name",
            "hsn": 8517,
            "item_id": "service_id",
            "ItemType": "service_type",
            "ResourcesUsages": "chair1",
            "stockKey": "id_3_batch_1516196300952",
            "batchId": "",
            "unit": "",
            "line": 2,
            "quantity_purchased": 1,
            "discount_percent": 1,
            "gDiscountPercent": 0,
            "purchasePrice": 0,
            "sellingPrice": 1,
            "mrp": null,
            "item_location": 1,
            "bSPTaxInclusive": false,
            "bPPTaxInclusive": false,
            "itemTaxList": [
                {
                    "name": "CGST",
                    "percent": 6
                },
                {
                    "name": "SGST",
                    "percent": 6
                }
            ],
            "stock_name": "India",
            "chargesList": [],
            "chargesTaxList": [],
            "imeiNumbers": []
        }
    ],
    "status": {
        "status": 0,
        "inventoryTrans": {
            "inventory_3": {
                "status": 0
            }
        },
        "customers": {}
    }
};

export let PostAppointment: FUNCTIONS = (appointment: APPOINTMENT): STATUS => {
    /* dump json into db */
    let out: STATUS = { code: "skd", message: "skgkf" };
    return out;
};
const PutAppointment: FUNCTIONS = (appointment: APPOINTMENT): STATUS => {
    /* dump json into db */
    let out: STATUS = { code: "skd", message: "skgkf" };
    return out;

};


