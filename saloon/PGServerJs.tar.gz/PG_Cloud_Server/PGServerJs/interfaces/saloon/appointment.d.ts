﻿export interface appointment {
    booking_id: string;
    booking_date: string;
    created_at: string;
    services: (ServicesEntity)[] | null;
    client_detail: ClientDetail;
    tracking_status: (TrackingStatusEntity)[] | null;
    [propName: string]: any;
}

export interface ServicesEntity {
    service_name: string;
    state_time: string;
    end_time: string;
    average_time: string;
    Use_resources?: string;
    average_time_to_complete_services?: string;
    price: Price;
    calculated_price?: string;
    staff_info: StaffInfo;
}

export interface Price {
    Retail_price: string;
    include_tax?: string;
    Discount?: string;
    special_discount?: string;
}

export interface StaffInfo {
    staff_id: string;
    staff_name: string;
    staff_mobile: string;
}

export interface ClientDetail {
    client_id: string;
    name: string;
    mobile: string;
    email?: string;
    gender: string;
    dob?: string;
    doa?: string;
    address?: Address;
    vouchers?: (VouchersEntity)[] | null;
}

export interface Address {
    address1: string;
    address2: string;
    city: string;
    state: string;
    pincode: string;
}

export interface VouchersEntity {
    voucher_name: string;
    voucher_code: string;
    start_date: string;
    end_date: string;
    status: string;
}

export interface TrackingStatusEntity {
    status: string;
    tracking_code: string;
    time: string;
}
