/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;
        try {
            var params = {};
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            var allUsersDoc = [];
            var json = {
                "apis": ["/common/sendEmailApi"],
                "common": true,
                "allowed": false,
                "desc": "Allows to Send the Email to the Customer after takeaway"
            };
            for (var i = 0; i < allUsers.length; i++) {
                try {
                    allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                } catch (error) {
                    logger.error(error);
                    continue;
                }

                if (allUsers[i].value.roles[1] === 'admin') {
                    json.allowed = true;
                }
                if (allUsers[i].value.roles[0].takeAway) {
                    allUsers[i].value.roles[0].takeAway.sendEmail = {};
                    allUsers[i].value.roles[0].takeAway.sendEmail = json;
                }
                if (allUsers[i].value.roles[0].sales) {
                    allUsers[i].value.roles[0].sales.sendEmail = {};
                    allUsers[i].value.roles[0].sales.sendEmail = json;
                }
                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);

                allUsersDoc.push(allUsers[i].value);
            }

            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);

        } catch (error) {
            logger.error(error);
            throw migrationName + ' entitlement migration failed';
        }
        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            applicationSettings.enableEmail = {
                value: false,
                afterSale: false,
                toOwner: false,
                toCustomer: false,
                toOthers: false,
                othersEmail: null
            };
            console.log('...');
            var appSettingsDoc = [applicationSettings];

            await couchDBUtils.bulkInsert(nanoCore, appSettingsDoc);

        } catch (err) {
            logger.error(error);
            throw migrationName + ' setting migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            var params = {};
            let allUsersDoc = [];
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            for (var i = 0; i < allUsers.length; i++) {
                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);

                if (allUsers[i].value.roles[0].takeAway && allUsers[i].value.roles[0].takeAway.hasOwnProperty('sendEmail')) {
                    delete allUsers[i].value.roles[0].takeAway.sendEmail;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('sendEmail property not found in takeAway');
                }
                if (allUsers[i].value.roles[0].sales && allUsers[i].value.roles[0].sales.hasOwnProperty('sendEmail')) {
                    delete allUsers[i].value.roles[0].sales.sendEmail;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('sendEmail property not found in sales');
                }
                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                allUsersDoc.push(allUsers[i].value);
            }

            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);
        } catch (error) {
            logger.error(error);
            logger.error('entitlement down migration failed');
            throw error;
        }
        try {
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            if (applicationSettings.hasOwnProperty('enableEmail')) {
                delete applicationSettings.enableEmail;
            } else {
                logger.error('Not expected to come here');
                logger.error('enableEmail property not found');
            }
            await couchDBUtils.update(applicationSettings, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' enableEmail setting down migration failed';
        }
    }
};