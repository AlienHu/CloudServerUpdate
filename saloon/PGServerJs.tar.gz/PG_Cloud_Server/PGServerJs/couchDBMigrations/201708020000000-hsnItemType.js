/**
 */

'use strict';

var path = require('path');
let migrationName = path.basename(__filename, '.js');
let errMsg = migrationName + ' Migration Failed';

module.exports = {
    up: async function(params) {
        const appRootPath = params.migrationsBasePath + '/../';
        const utils = require(appRootPath + 'controllers/common/Utils');
        const ARRAY_LENGTH = utils.getArrayLength;
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let logger = params.logger;

        try {
            let mainDBInstance = params.nanoClients.maindb;

            try {
                let nanoCore = params.nanoClients.coredb;
                let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
                applicationSettings.HSN.restaurant = 'HSN/SAC';
                await couchDBUtils.update(applicationSettings, nanoCore, 2);
            } catch (error) {
                logger.error(error);
                throw errMsg;
            }

            let allSaleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
            let allItemIds = [];
            for (let i = 0; i < ARRAY_LENGTH(allSaleDocs); i++) {
                let sale_items = allSaleDocs[i].doc.sale_items;
                for (let j = 0; j < ARRAY_LENGTH(sale_items); j++) {
                    //forming the id get it from some utility
                    allItemIds.push('item_' + sale_items[j].item_id);
                }
            }
            allItemIds = Array.from(new Set(allItemIds)); //Getting unique ids
            let allItemDocs = [];
            if (ARRAY_LENGTH(allItemIds)) {
                allItemDocs = await couchDBUtils.getAllDocs(allItemIds, mainDBInstance);
            }

            let itemsDictionary = {};
            for (let i = 0; i < ARRAY_LENGTH(allItemDocs); i++) {
                if (allItemDocs[i].error === 'not found') {
                    logger.error('Item Doc<' + allItemIds[i] + '> not found');
                    allItemDocs[i].doc = {
                        info: {
                            hsn: '',
                            ItemType: 'Normal',
                            item_id: allItemIds[i].substr(5)
                        }
                    };
                }
                itemsDictionary[allItemDocs[i].doc.item_id] = allItemDocs[i].doc;
            }

            let newDocs = [];
            for (let i = 0; i < ARRAY_LENGTH(allSaleDocs); i++) {
                let sale_items = allSaleDocs[i].doc.sale_items;
                for (let j = 0; j < ARRAY_LENGTH(sale_items); j++) {
                    let item_id = sale_items[j].item_id;
                    sale_items[j].hsn = itemsDictionary[item_id].info.hsn;
                    sale_items[j].ItemType = itemsDictionary[item_id].info.ItemType;
                    if (!sale_items[j].chargesList) {
                        sale_items[j].chargesList = [];
                    }
                    if (!sale_items[j].chargesTaxList) {
                        sale_items[j].chargesTaxList = [];
                    }
                }
                newDocs.push(allSaleDocs[i].doc);
            }
            if (newDocs.length) {
                await couchDBUtils.bulkInsert(mainDBInstance, newDocs);
            }
        } catch (error) {
            logger.error(error);
            throw errMsg;
        }
    },

    down: async function(params) {
        let logger = params.logger;
        const appRootPath = params.migrationsBasePath + '/../';
        const utils = require(appRootPath + 'controllers/common/Utils');
        const ARRAY_LENGTH = utils.getArrayLength;
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        try {
            let mainDBInstance = params.nanoClients.maindb;
            let allSaleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
            let newDocs = [];
            for (let i = 0; i < ARRAY_LENGTH(allSaleDocs); i++) {
                let sale_items = allSaleDocs[i].doc.sale_items;
                for (let j = 0; j < ARRAY_LENGTH(sale_items); j++) {
                    let item_id = sale_items[j].item_id;
                    delete sale_items[j].hsn;
                    delete sale_items[j].ItemType;
                }
                newDocs.push(allSaleDocs[i].doc);
            }

            if (newDocs.length) {
                await couchDBUtils.bulkInsert(mainDBInstance, newDocs);
            }
        } catch (error) {
            logger.error(error);
            throw errMsg;
        }
    }
};