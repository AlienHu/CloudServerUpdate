'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var path = require('path');
exports.up = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        params.couchDBUtils = couchDBUtils;
        const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        params.dbInstance = maindb;
        yield batchProcess(100, 'item', processFun, params);
        yield batchProcess(100, 'inventory', processFun, params);
    });
};
exports.down = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
    });
};
function processFun(allDocsRespRowArr, params) {
    return __awaiter(this, void 0, void 0, function* () {
        let docs2UpdateArr = [];
        for (let i = 0; i < allDocsRespRowArr.length; i++) {
            let doc = allDocsRespRowArr[i].doc;
            if (doc.txDocIdArr) {
                continue;
            }
            doc.txDocIdArr = [];
            docs2UpdateArr.push(doc);
        }
        if (!docs2UpdateArr.length) {
            return;
        }
        yield bulkInsert(params.dbInstance, docs2UpdateArr, params.logger);
    });
}
function bulkInsert(db, docsArray, logger) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let resp = yield db.bulk({
                docs: docsArray
            });
            return resp;
        }
        catch (error) {
            logger.error(error);
            throw 'Bulk Update Failed';
        }
    });
}
;
//# sourceMappingURL=201807080000000-iteminvtxdocid.js.map