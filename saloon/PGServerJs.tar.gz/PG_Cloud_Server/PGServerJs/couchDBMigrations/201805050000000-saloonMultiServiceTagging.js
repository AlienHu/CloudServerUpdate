'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;

        try {
            let nanoClients = params.nanoClients;
            let nanoMain = nanoClients.maindb;
            const appRootPath = params.migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            let updatedSavedAppointments = [];

            let savedAppointments = await couchDBUtils.getAllDocsByType('suspendedSale', nanoMain);
            for (let a = 0; a < savedAppointments.length; a++) {
                if (!savedAppointments[a].doc.sales_info.isAppointment) continue;
                for (let s = 0; s < savedAppointments[a].doc.sales_items.length; s++) {
                    if (savedAppointments[a].doc.sales_items[s].appointmentData && savedAppointments[a].doc.sales_items[s].appointmentData.employee) {
                        savedAppointments[a].doc.sales_items[s].appointmentData.employees = [];
                        let oldEmployeeData = savedAppointments[a].doc.sales_items[s].appointmentData.employee;
                        if (oldEmployeeData) {
                            if (savedAppointments[a].doc.sales_items[s].appointmentData.employeesBackup) {
                                savedAppointments[a].doc.sales_items[s].appointmentData.employees = savedAppointments[a].doc.sales_items[s].appointmentData.employeesBackup;
                                delete(savedAppointments[a].doc.sales_items[s].appointmentData.employeesBackup);
                            } else {
                                savedAppointments[a].doc.sales_items[s].appointmentData.employees.push(savedAppointments[a].doc.sales_items[s].appointmentData.employee);
                            }
                            delete(savedAppointments[a].doc.sales_items[s].appointmentData.employee);
                        }
                    } else {
                        continue;
                    }
                }
                updatedSavedAppointments.push(savedAppointments[a].doc);
            }

            savedAppointments = await couchDBUtils.getAllDocsByType('sale', nanoMain);
            for (let a = 0; a < savedAppointments.length; a++) {
                if (!savedAppointments[a].doc.sales_info.isAppointment) continue;
                for (let s = 0; s < savedAppointments[a].doc.sale_items.length; s++) {
                    if (savedAppointments[a].doc.sale_items[s].ItemType === 'Service' && savedAppointments[a].doc.sale_items[s].appointmentData && savedAppointments[a].doc.sale_items[s].appointmentData.employee) {
                        savedAppointments[a].doc.sale_items[s].appointmentData.employees = [];
                        let oldEmployeeData = savedAppointments[a].doc.sale_items[s].appointmentData.employee;
                        if (oldEmployeeData) {
                            if (savedAppointments[a].doc.sale_items[s].appointmentData.employeesBackup) {
                                savedAppointments[a].doc.sale_items[s].appointmentData.employees = savedAppointments[a].doc.sale_items[s].appointmentData.employeesBackup;
                                delete(savedAppointments[a].doc.sale_items[s].appointmentData.employeesBackup);
                            } else {
                                savedAppointments[a].doc.sale_items[s].appointmentData.employees.push(savedAppointments[a].doc.sale_items[s].appointmentData.employee);
                            }
                            delete(savedAppointments[a].doc.sale_items[s].appointmentData.employee);
                        }
                    } else {
                        continue;
                    }
                }
                updatedSavedAppointments.push(savedAppointments[a].doc);
            }

            let resp = await couchDBUtils.bulkDocs(updatedSavedAppointments, nanoMain, 2);
        } catch (error) {
            logger.error(error);
            logger.error('upgrading to multi service tagging failed');
            throw error;
        }
    },

    down: async function(params) {
        let logger = params.logger;
        try {
            let nanoClients = params.nanoClients;
            let nanoMain = nanoClients.maindb;
            const appRootPath = params.migrationsBasePath + '/../';
            const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
            let updatedSavedAppointments = [];

            let savedAppointments = await couchDBUtils.getAllDocsByType('suspendedSale', nanoMain);
            for (let a = 0; a < savedAppointments.length; a++) {
                if (!savedAppointments[a].doc.sales_info.isAppointment) continue;
                for (let s = 0; s < savedAppointments[a].doc.sales_items.length; s++) {
                    if (savedAppointments[a].doc.sales_items[s].appointmentData && savedAppointments[a].doc.sales_items[s].appointmentData.employees) {
                        let oldEmployeeData = savedAppointments[a].doc.sales_items[s].appointmentData.employees;
                        if (oldEmployeeData) {
                            savedAppointments[a].doc.sales_items[s].appointmentData.employee = savedAppointments[a].doc.sales_items[s].appointmentData.employees[0];
                            savedAppointments[a].doc.sales_items[s].appointmentData.employeesBackup = savedAppointments[a].doc.sales_items[s].appointmentData.employees;
                            delete(savedAppointments[a].doc.sales_items[s].appointmentData.employees);
                        }
                    } else {
                        continue;
                    }
                }
                updatedSavedAppointments.push(savedAppointments[a].doc);
            }

            savedAppointments = await couchDBUtils.getAllDocsByType('sale', nanoMain);
            for (let a = 0; a < savedAppointments.length; a++) {
                if (!savedAppointments[a].doc.sales_info.isAppointment) continue;
                for (let s = 0; s < savedAppointments[a].doc.sale_items.length; s++) {
                    if (savedAppointments[a].doc.sale_items[s].ItemType === 'Service' && savedAppointments[a].doc.sale_items[s].appointmentData && savedAppointments[a].doc.sale_items[s].appointmentData.employees) {
                        let oldEmployeeData = savedAppointments[a].doc.sale_items[s].appointmentData.employees;
                        if (oldEmployeeData) {
                            savedAppointments[a].doc.sale_items[s].appointmentData.employee = savedAppointments[a].doc.sale_items[s].appointmentData.employees[0];
                            savedAppointments[a].doc.sale_items[s].appointmentData.employeesBackup = savedAppointments[a].doc.sale_items[s].appointmentData.employees;
                            delete(savedAppointments[a].doc.sale_items[s].appointmentData.employees);
                        }
                    } else {
                        continue;
                    }
                }
                updatedSavedAppointments.push(savedAppointments[a].doc);
            }
            await couchDBUtils.bulkDocs(updatedSavedAppointments, nanoMain, 2);
        } catch (error) {
            logger.error(error);
            logger.error('multi to single service tagging downgrade failed');
            throw error;
        }
    }
};