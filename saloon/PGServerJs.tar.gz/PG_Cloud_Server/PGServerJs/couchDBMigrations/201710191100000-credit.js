/**
 * No UT because it is copy paste of prev migration
 */

'use strict';

var path = require('path');
let migrationName = path.basename(__filename, '.js');
let errMsg = migrationName + ' Migration Failed';

async function updateCustomerValues(customerDoc, couchDBUtils, mainDBInstance) {
    customerDoc.total = 0;
    customerDoc.credit_balance = 0;

    let params = {
        startkey: customerDoc.person_id + '-0',
        endkey: customerDoc.person_id + '-z',
        include_docs: true
    };

    let total = 0;
    let credit_balance = 0;
    let queryResponse = await couchDBUtils.getView('all_sales_info', 'all_customer_time', params, mainDBInstance);
    for (let i = 0; i < queryResponse.length; i++) {
        let doc = queryResponse[i].doc;
        if (doc.sales_info) {
            total += doc.sales_info.total;
            credit_balance += doc.sales_info.pending_amount;
        } else if (doc.info) {
            //Return
            total -= doc.info.total;
        }
    }

    customerDoc.total = total;
    customerDoc.credit_balance = credit_balance;
    await couchDBUtils.create(customerDoc, mainDBInstance, 1, 'Customer Update Error');
}

async function updateSupplierValues(supplierDoc, couchDBUtils, mainDBInstance) {
    supplierDoc.total = 0;
    supplierDoc.credit_balance = 0;

    let params = {
        startkey: supplierDoc.person_id + '-0',
        endkey: supplierDoc.person_id + '-z',
        include_docs: true
    };

    let total = 0;
    let credit_balance = 0;
    let queryResponse = await couchDBUtils.getView('all_receivings_info', 'all_supplier_time', params, mainDBInstance);
    for (let i = 0; i < queryResponse.length; i++) {
        let doc = queryResponse[i].doc;
        if (doc.receivings_info) {
            total += doc.receivings_info.total;
            credit_balance += doc.receivings_info.pending_amount;
        }
    }

    supplierDoc.total = total;
    supplierDoc.credit_balance = credit_balance;
    await couchDBUtils.create(supplierDoc, mainDBInstance, 1, 'Supplier Update Error');
}

module.exports = {
    /**
     * 1. Query customers in a loop
     *      1. Query all sales and returns related to the customer
     *      2. Calculate the total and credit_balance
     *      3. Update the customer
     * 2. Query suppliers in a loop
     *      1. Query all purchases related to supplier
     *      2. Calculate the total and credit_balance
     *      3. Update the supplier
     */
    up: async function(params) {
        const appRootPath = params.migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require(appRootPath + 'couchDb/couchDBUtils2');

        let logger = params.logger;

        try {
            let mainDBInstance = params.nanoClients.maindb;
            await couchDBUtils2.createCouchDbAndViews(mainDBInstance, 'maindb');

            let skip = 0;
            while (true) {
                let params = {
                    skip: skip,
                    limit: 1,
                    include_docs: true
                };
                let docs = await couchDBUtils.getView('all_customers_data', 'all_customers_data', params, mainDBInstance);
                if (!docs.length) {
                    break;
                }
                skip++;
                await updateCustomerValues(docs[0].doc, couchDBUtils, mainDBInstance);
            }

            skip = 0;
            while (true) {
                let params = {
                    skip: skip,
                    limit: 1,
                    include_docs: true
                };
                let docs = await couchDBUtils.getView('all_suppliers_data', 'all_suppliers_data', params, mainDBInstance);
                if (!docs.length) {
                    break;
                }
                skip++;
                await updateSupplierValues(docs[0].doc, couchDBUtils, mainDBInstance);
            }

        } catch (error) {
            logger.error(error);
            throw errMsg;
        }
    },

    //Fixing bug .. so now down function
    down: async function(params) {

    }
};