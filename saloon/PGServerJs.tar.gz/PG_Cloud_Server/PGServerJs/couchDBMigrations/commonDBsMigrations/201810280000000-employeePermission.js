/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require('fs');
var path = require('path');
function allowCommFun(role, singleRole, isAllowAll) {
    let bAllowed = false;
    if (role === 'admin') {
        bAllowed = true;
    }
    else if (role === 'inventoryManager' && singleRole == "forInventoryPer") {
        bAllowed = true;
    }
    else if (role === 'salesPerson' && singleRole == "forSalesPer") {
        bAllowed = true;
    }
    else if (role === '' && isAllowAll) {
        bAllowed = true;
    }
    return bAllowed;
}
function createObject(role1, desc, singleRole1, unUsedVariable) {
    var bAdmin = false;
    if (role1 === 'admin') {
        bAdmin = true;
    }
    return {
        "allowed": allowCommFun(role1, singleRole1, bAdmin),
        "desc": desc
    };
}
function createMissingObject(role1, descMsg, singleRole1) {
    var bAdmin = false;
    if (role1 === 'admin') {
        bAdmin = true;
    }
    return {
        "desc": descMsg,
        "allowNone": !allowCommFun(role1, singleRole1, bAdmin),
        "allowAll": allowCommFun(role1, singleRole1, bAdmin),
        "viewOnMenu": allowCommFun(role1, singleRole1, bAdmin)
    };
}
exports.up = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = params.logger;
        const usersDBInstance = params.nanoClients.users;
        let migrationName = path.basename(__filename, '.js');
        try {
            let allUsers = yield getAllUserDocs(usersDBInstance, {}, true, logger);
            let allUsersDoc = [];
            for (let i = 0; i < allUsers.length; i++) {
                if (!allUsers[i].roles[0])
                    continue;
                try {
                    allUsers[i].roles[0] = JSON.parse(allUsers[i].roles[0]);
                }
                catch (error) {
                    logger.error(error);
                    continue;
                }
                let role = allUsers[i].roles[1];
                let APP_TYPE = allUsers[i].APP_TYPE;
                if (!APP_TYPE && allUsers[i].name === 'nadmin') {
                    allUsers[i].APP_TYPE = 'tito_retail';
                    APP_TYPE = allUsers[i].APP_TYPE;
                }
                if (APP_TYPE.indexOf('_')) {
                    //tito_retail
                    //tito_restaurant 
                    APP_TYPE = APP_TYPE.split('_')[1];
                }
                //added by sai
                if (!allUsers[i].roles[0].store.stockTransfer) {
                    allUsers[i].roles[0].store.stockTransfer = createObject(role, "Allow Stock Transfer", 'none', undefined);
                }
                if (!allUsers[i].roles[0].store.disableAdminApproval) {
                    allUsers[i].roles[0].store.disableAdminApproval = createObject(role, "Disable Admin Approval for Stock Transfer", 'none', undefined);
                }
                if (!allUsers[i].roles[0].storeHeadOffice.shareSMS) {
                    allUsers[i].roles[0].storeHeadOffice.shareSMS = createObject(role, "Allow Share SMS", 'none', undefined);
                }
                let reportObj = allUsers[i].roles[0].reports;
                if (!allUsers[i].roles[0].tables && APP_TYPE === "restaurant") {
                    allUsers[i].roles[0].tables = {};
                }
                let tablesObject = allUsers[i].roles[0].tables;
                if (!allUsers[i].roles[0].homeDelivery) {
                    allUsers[i].roles[0].homeDelivery = {};
                }
                let hdObject = allUsers[i].roles[0].homeDelivery;
                if (!allUsers[i].roles[0].takeAway && APP_TYPE === "restaurant") {
                    allUsers[i].roles[0].takeAway = {};
                }
                let taObject = allUsers[i].roles[0].takeAway;
                if (!allUsers[i].roles[0].sales && APP_TYPE !== "restaurant") {
                    allUsers[i].roles[0].sales = {};
                }
                let salesObject = allUsers[i].roles[0].sales;
                if (!allUsers[i].roles[0].salesOrder) {
                    allUsers[i].roles[0].salesOrder = {};
                }
                let soObject = allUsers[i].roles[0].salesOrder;
                let salesRestaurant = {};
                if (allUsers[i].roles[0].salesRestaurant) {
                    salesRestaurant = allUsers[i].roles[0].salesRestaurant;
                }
                if (APP_TYPE === "restaurant") {
                    tableMigration();
                    salesRestaurantMigration();
                    taAndSalesMigration(taObject); // Take Away
                    createNewModuleObj(); // BOM | PP  | US | Auto Report
                }
                else if (APP_TYPE === "retail") {
                    taAndSalesMigration(salesObject); // Sales for retail
                }
                if (APP_TYPE === "restaurant" || APP_TYPE === "retail") {
                    hdMigration();
                    reportMigration();
                    createCommonNewModuleObj();
                }
                function tableMigration() {
                    if (!tablesObject) {
                        tablesObject = createMissingObject(role, "Allow to place order in Table", "forSalesPer");
                    }
                    const tableApi = ["createtablerestapi", "deleteTableApiRestApi", "mergeTables", "changeTable"];
                    const tab_obj_filed_arr = ["billSplit", "completeOrder", "takePayment", "editDiscounts", "editKot", "cancelOreder", "takeOrder", "editDiscount", "editPrice"];
                    const tablesFeature = ['createTable', 'deleteTable'];
                    tablesObject.apis = tableApi;
                    tablesObject.changeTable = tablesObject.changeTable !== undefined ? tablesObject.changeTable : createObject(role, "Allows to Change Table", "forSalesPer", tablesObject.allowAll); //creating new filed 
                    tablesObject.mergeTable = tablesObject.mergeTable !== undefined ? tablesObject.mergeTable : createObject(role, "Allows to Merge Table", "forSalesPer", tablesObject.allowAll);
                    if (role === 'admin') {
                        tablesObject.changeTable = createObject(role, "Allows to Change Table", "forSalesPer", true); //creating new filed 
                        tablesObject.mergeTable = createObject(role, "Allows to Merge Table", "forSalesPer", true);
                    }
                    deleteModuleObject(tab_obj_filed_arr, tablesObject); //deleting old object migrated to saleRestaurant inside Restaurant
                    deletApiFunc(tablesFeature, tablesObject, undefined, undefined); //deleting api
                }
                function salesRestaurantMigration() {
                    if (!salesRestaurant || salesRestaurant.kotReport === undefined) {
                        const saleRestaurantApi = ["additemRestApi",
                            "add_paymentRestApi",
                            "completeSaleRestApi",
                            "getCartTaxes",
                            "addCustomer2SaleRestApi",
                            "receiptRestApi",
                            "printReceiptApi",
                            "setPrintAfterSaleRestApi",
                            "setInvoiceNumberEnabledRestApi",
                            "setInvoiceNumberRestApi",
                            "invoiceRestApi",
                            "DeleteItemFromCartRestApi",
                            "getItemsRestApi",
                            "checkAlreadyReservedRestApi",
                            "getReservationDetails",
                            "cancel_saleRestApi",
                            "saveTableOrderRestApi",
                            "getSalesRestApi",
                            "getItemsForTableOrderRestApi",
                            "loadAllOrderItemBeforeCheckOutRestApi",
                            "addEmployee2SaleRestApi",
                            "getOrderBill",
                            "loadKotToCartRestApi",
                            "editItemRestApi",
                            "deleteOrdersOfTableRestApi",
                            "deleteTableApiRestApi",
                            "changeTable",
                            "mergeTables",
                            "completeTakeOrderRestApi",
                            "addCustomer2OrdersRestApi",
                            "quickSaleRestApi",
                            "saveGlobalDiscount"
                        ];
                        const salesRestaurantObj = {
                            "desc": "",
                            "allowNone": salesRestaurant.allowNone !== undefined ? salesRestaurant.allowNone : !allowCommFun(role, 'forSalesPer', tablesObject.viewOnMenu),
                            "allowAll": salesRestaurant.allowAll !== undefined ? salesRestaurant.allowAll : allowCommFun(role, 'none', tablesObject.allowAll),
                            "viewOnMenu": salesRestaurant.viewOnMenu !== undefined ? salesRestaurant.viewOnMenu : allowCommFun(role, 'forSalesPer', tablesObject.allowAll),
                            'takeOrder': salesRestaurant.takeOrder !== undefined ? salesRestaurant.takeOrder : createObject(role, 'Allows to Take Order For the Table', 'forSalesPer', tablesObject.allowAll),
                            'editPrice': salesRestaurant.editPrice !== undefined ? salesRestaurant.editPrice : createObject(role, 'Allows to Edit price of the item', 'forSalesPer', tablesObject.allowAll),
                            'editDiscount': salesRestaurant.editDiscount !== undefined ? salesRestaurant.editDiscount : createObject(role, 'Allows to Edit Discount of the Item', 'forSalesPer', tablesObject.allowAll),
                            'editKot': salesRestaurant.editKot !== undefined ? salesRestaurant.editKot : createObject(role, "Allows to Edit KOT", 'forSalesPer', tablesObject.allowAll),
                            'takePayment': salesRestaurant.takePayment !== undefined ? salesRestaurant.takePayment : createObject(role, 'Allows to Make Payment', 'forSalesPer', tablesObject.allowAll),
                            'completeOrder': salesRestaurant.completeOrder !== undefined ? salesRestaurant.completeOrder : createObject(role, 'Allows to Complete the Order', 'forSalesPer', tablesObject.allowAll),
                            'spotDiscount': salesRestaurant.spotDiscount !== undefined ? salesRestaurant.spotDiscount : createObject(role, 'Allows to give Spot Discount', 'forSalesPer', tablesObject.allowAll),
                            'printBill': salesRestaurant.printBill !== undefined ? salesRestaurant.printBill : createObject(role, 'Allows to print Bill', 'forSalesPer', tablesObject.allowAll),
                            'deleteOrder': salesRestaurant.deleteOrder !== undefined ? salesRestaurant.deleteOrder : createObject(role, 'Allows to delete the order', 'forSalesPer', tablesObject.allowAll),
                            'multiplePrintBill': salesRestaurant.multiplePrintBill !== undefined ? salesRestaurant.multiplePrintBill : createObject(role, 'Allows to do print bill  only one time', tablesObject.allowAll, false),
                            'kotReport': salesRestaurant.kotReport !== undefined ? salesRestaurant.kotReport : createObject(role, 'Allows to see KOT reports', 'forSalesPer', tablesObject.allowAll)
                        };
                        if (allUsers[i].roles[1] === 'admin') {
                            salesRestaurantObj.allowNone = false;
                            salesRestaurantObj.allowAll = true;
                            salesRestaurantObj.viewOnMenu = true;
                            let keys = [
                                "takeOrder",
                                "editPrice",
                                "editDiscount",
                                "editKot",
                                "takePayment",
                                "completeOrder",
                                "spotDiscount",
                                "printBill",
                                "deleteOrder",
                                "multiplePrintBill",
                                "kotReport"
                            ];
                            let descriptions = [
                                'Allows to Take Order For the Table',
                                'Allows to Edit price of the item',
                                'Allows to Edit Discount of the Item',
                                "Allows to Edit KOT",
                                'Allows to Make Payment',
                                'Allows to Complete the Order',
                                'Allows to give Spot Discount',
                                'Allows to print Bill',
                                'Allows to delete the order',
                                'Allows to do print bill  only one time',
                                'Allows to see KOT reports'
                            ];
                            for (let i = 0; i < keys.length; i++) {
                                salesRestaurantObj[keys[i]] = createObject(role, descriptions[i], 'forSalesPer', true);
                            }
                        }
                        allUsers[i].roles[0].salesRestaurant = salesRestaurantObj;
                        allUsers[i].roles[0].salesRestaurant.takeOrder.apis = saleRestaurantApi;
                    }
                }
                function hdMigration() {
                    const hdFeature = ['editOrder', 'completeDelivery', 'deleteOrder'];
                    const hd_obj_filed_arr = ['takeOrder', 'viewOrder', 'takeOrderPayment'];
                    if (!hdObject || hdObject.saleSetting === undefined) {
                        const hd_api_arr = [
                            "addCustomer2OrdersRestApi",
                            "saveDeliveryRetailRestApi",
                            "additemRestApi",
                            "cancel_saleRestApi",
                            "getCartTaxes",
                            "editItemRestApi",
                            "getEditRestApi",
                            "removeitemRestApi",
                            "getItemDiscountRestApi",
                            "DeleteItemFromCartRestApi",
                            "getItemsRestApi",
                            "getSalesRestApi",
                            "saveHDOrderRestApi",
                            "loadHDOrderRestApi",
                            "printHDOrderRestApi",
                            "addCustomer2SaleRestApi",
                            "add_paymentRestApi",
                            "completeHDOrder",
                            "quickHDOrder",
                            "setLocalTax",
                            "updateApplicationSettings"
                        ];
                        if (!hdObject) {
                            hdObject = createMissingObject(role, "Allow to place order in HomeDelivery", 'forSalesPer');
                        }
                        else {
                            hdObject.allowAll = hdObject.allowAll ? hdObject.allowAll : allowCommFun(role, 'forSalesPer', false);
                            hdObject.viewOnMenu = hdObject.viewOnMenu ? hdObject.viewOnMenu : allowCommFun(role, 'forSalesPer', false);
                            if (role === 'admin') {
                                hdObject.allowAll = true;
                                hdObject.viewOnMenu = true;
                            }
                        }
                        deleteModuleObject(hd_obj_filed_arr, hdObject);
                        hdObject.editOrder = hdObject.editOrder ? hdObject.editOrder : createObject(role, "Allows to edit the HomeADelivery Order", 'forSalesPer', hdObject.allowAll);
                        hdObject.completeDelivery = hdObject.completeDelivery ? hdObject.completeDelivery : createObject(role, "Allows to Complete the HomeDelivery Transaction", 'forSalesPer', hdObject.allowAll);
                        hdObject.deleteOrder = hdObject.deleteOrder ? hdObject.deleteOrder : createObject(role, "Allows to Delete the HomeDelivery Order", 'forSalesPer', hdObject.allowAll);
                        hdObject.sendSms = hdObject.sendSms ? hdObject.sendSms : createObject(role, "Allows to Send SMS to the Customer", 'forSalesPer', hdObject.allowAll);
                        hdObject.sendSms.apis = ["/common/sendSMS"];
                        hdObject.sendSms.common = true;
                        hdObject.homeDelivery = hdObject.homeDelivery ? hdObject.homeDelivery : createObject(role, "Allows to Take Order For Home Delivery", 'forSalesPer', hdObject.allowAll);
                        hdObject.homeDelivery.apis = hd_api_arr;
                        hdObject.newOrder = hdObject.newOrder ? hdObject.newOrder : createObject(role, 'Allows to take new HomeADelivery Order', 'forSalesPer', hdObject.allowAll);
                        hdObject.printBill = hdObject.printBill ? hdObject.printBill : createObject(role, 'Allows to print bill in Home Delivery', 'forSalesPer', hdObject.allowAll);
                        hdObject.editPrice = hdObject.editPrice ? hdObject.editPrice : createObject(role, 'Allows to Modify the Price While making the Sale.', 'forSalesPer', hdObject.allowAll);
                        hdObject.editDiscount = hdObject.editDiscount ? hdObject.editDiscount : createObject(role, 'Allows to Modify Discount', 'forSalesPer', hdObject.allowAll);
                        hdObject.globalDiscount = hdObject.globalDiscount ? hdObject.globalDiscount : createObject(role, 'Allows to Modify Global Discount', 'forSalesPer', hdObject.allowAll);
                        hdObject.saleSetting = hdObject.saleSetting ? hdObject.saleSetting : createObject(role, 'Allows to edit sale setting', 'forSalesPer', hdObject.allowAll);
                        if (role === 'admin') {
                            let keys = [
                                "editOrder",
                                "completeDelivery",
                                "deleteOrder",
                                "sendSms",
                                "homeDelivery",
                                "newOrder",
                                "printBill",
                                "editPrice",
                                "editDiscount",
                                "globalDiscount",
                                "saleSetting"
                            ];
                            let descriptions = [
                                "Allows to edit the HomeADelivery Order",
                                "Allows to Complete the HomeDelivery Transaction",
                                "Allows to Delete the HomeDelivery Order",
                                "Allows to Send SMS to the Customer",
                                "Allows to Take Order For Home Delivery",
                                "Allows to take new HomeADelivery Order",
                                "Allows to print bill in Home Delivery",
                                "Allows to Modify the Price While making the Sale.",
                                "Allows to Modify Discount",
                                "Allows to Modify Global Discount",
                                "Allows to edit sale setting"
                            ];
                            for (let j = 0; j < keys.length; j++) {
                                hdObject[keys[j]] = createObject(role, descriptions[j], 'forSalesPer', true);
                            }
                        }
                    }
                }
                function taAndSalesMigration(taAndSalesObj) {
                    const taFeature = ['editPrice', 'editDiscount', 'suspendSales', 'unsuspendSales'];
                    const ta_salesHistory_Feature = ['view', 'update', 'delete'];
                    const ta_makeSales = ["addEmployee2SaleRestApi",
                        "editItemRestApi",
                        "setGlobalDiscount",
                        "addCustomer2OrdersRestApi",
                        "quickSaleRestApi",
                        "suspendSaleRestApi",
                        "allSuspendedSalesRestApi",
                        "unsuspendSaleRestApi",
                        "update",
                        "delete_paymentRestApi",
                        "deleteSuspendedSale",
                        "setLocalTax",
                        "updateApplicationSettings"
                    ];
                    if (!taAndSalesObj) {
                        taAndSalesObj = createMissingObject(role, "Allow to place items in TakeAway", "forSalesPer");
                    }
                    else {
                        delete taAndSalesObj.viewOthersSuspendedSales;
                        deletApiFunc(taFeature, taAndSalesObj, undefined, undefined);
                        deletApiFunc(ta_salesHistory_Feature, taAndSalesObj.salesHistory, undefined, undefined);
                    }
                    taAndSalesObj.makeSale.apis = taAndSalesObj.makeSale.apis.concat(ta_makeSales);
                    if (taAndSalesObj.makeReturn.apis.indexOf('completeReturn') == -1) {
                        taAndSalesObj.makeReturn.apis.push('completeReturn');
                    }
                    if (!taAndSalesObj || taAndSalesObj.globalDiscount === undefined) {
                        taAndSalesObj.saleSetting = taAndSalesObj.saleSetting ? taAndSalesObj.saleSetting : createObject(role, "Allows to edit sale setting", "forSalesPer", taAndSalesObj.allowAll);
                        taAndSalesObj.saleSetting.common = true;
                        taAndSalesObj.globalDiscount = taAndSalesObj.globalDiscount ? taAndSalesObj.globalDiscount : createObject(role, "Allows to Modify Global Discount", "forSalesPer", taAndSalesObj.allowAll);
                    }
                    if (role === 'admin') {
                        taAndSalesObj.saleSetting = createObject(role, "Allows to edit sale setting", "forSalesPer", true);
                        taAndSalesObj.saleSetting.common = true;
                        taAndSalesObj.globalDiscount = createObject(role, "Allows to Modify Global Discount", "forSalesPer", true);
                    }
                }
                function reportMigration() {
                    const reportFeature = ["purchases",
                        "items",
                        "employees",
                        "suppliers",
                        "sales",
                        "discounts",
                        "taxes",
                        "inventory",
                        "categories",
                        "payments",
                        "customers",
                        "gstreports"
                    ];
                    const reportApi = ["common/sendEmailApi", "gstr1_12", "gstr2"];
                    if (!reportObj) {
                        reportObj = createMissingObject(role, "Allow to access Report", undefined);
                    }
                    else {
                        for (let i = 0; i < reportFeature.length; i++) {
                            try {
                                // console.log(reportFeature[i]);
                                delete reportObj[reportFeature[i]].apis;
                                if (reportFeature[i] === "sales") {
                                    delete reportObj[reportFeature[i]]["salesHistory"].apis;
                                }
                            }
                            catch (error) {
                                logger.error(error);
                                continue;
                            }
                        }
                    }
                    reportObj.apis = reportApi;
                    if (!reportObj || reportObj.purchaseDelete === undefined) {
                        reportObj.editSale = reportObj.editSale ? reportObj.editSale : createObject(role, "Allows to edit and delete sale", 'none', reportObj.allowAll);
                        reportObj.rejectSale = reportObj.rejectSale ? reportObj.rejectSale : createObject(role, "Allows reject sale", 'none', reportObj.allowAll);
                        reportObj.deleteSale = reportObj.deleteSale ? reportObj.deleteSale : createObject(role, "Allows delete sale", 'none', reportObj.allowAll);
                        reportObj.purchaseEdit = reportObj.purchaseEdit ? reportObj.purchaseEdit : createObject(role, "Allows to edit and delete purchase", 'none', reportObj.allowAll);
                        reportObj.purchaseReject = reportObj.purchaseReject ? reportObj.purchaseReject : createObject(role, "Allows reject purchase", 'none', reportObj.allowAll);
                        reportObj.purchaseDelete = reportObj.purchaseDelete ? reportObj.purchaseDelete : createObject(role, "Allows delete purchase", 'none', reportObj.allowAll);
                    }
                    reportObj.displayProfitAndCost = reportObj.displayProfitAndCost ? reportObj.displayProfitAndCost : createObject(role, "Allows to Display Cost And Profit", 'none', reportObj.allowAll);
                    if (role === 'admin') {
                        let keys = [
                            "editSale",
                            "rejectSale",
                            "deleteSale",
                            "purchaseEdit",
                            "purchaseReject",
                            "purchaseDelete"
                        ];
                        let descriptions = [
                            "Allows to edit and delete sale",
                            "Allows reject sale",
                            "Allows delete sale",
                            "Allows to edit and delete purchase",
                            "Allows reject purchase",
                            "Allows delete purchase",
                        ];
                        for (let j = 0; j < keys.length; j++) {
                            reportObj[keys[j]] = createObject(role, descriptions[j], 'none', true);
                        }
                    }
                }
                function deletApiFunc(salesFeature, salesObject, module, role) {
                    for (var i = 0; i < salesFeature.length; i++) {
                        delete salesObject[salesFeature[i]].apis;
                        if (module === 'HD' && role) {
                            salesObject[salesFeature[i]].allowed = true;
                        }
                    }
                }
                ;
                function deleteModuleObject(obj_field_Arr, object) {
                    for (var i = 0; i < obj_field_Arr.length; i++) {
                        delete object[obj_field_Arr[i]];
                    }
                }
                ;
                // function createModuleObject(obj_field_Arr, object) {
                //     for (var i = 0; i < obj_field_Arr.length; i++) {
                //         object[obj_field_Arr[i]] = createObject
                //     }
                // }
                function createNewModuleObj() {
                    let bAdmin = false;
                    if (allUsers[i].roles[1] === 'admin') {
                        bAdmin = true;
                    }
                    if (!allUsers[i].roles[0].bom) {
                        allUsers[i].roles[0].bom = {
                            "desc": "Allow to create BOM",
                            "allowNone": !allowCommFun(role, "forInventoryPer", bAdmin),
                            "allowAll": allowCommFun(role, "forInventoryPer", bAdmin),
                            "viewOnMenu": allowCommFun(role, "forInventoryPer", bAdmin),
                            "createBom": createObject(role, "Allows to create BOM", "forInventoryPer", bAdmin),
                            "editBom": createObject(role, "Allows to edit BOM", "forInventoryPer", bAdmin),
                            "deleteBom": createObject(role, "Allows to delete BOM", "forInventoryPer", bAdmin)
                        };
                    }
                    ;
                    if (!allUsers[i].roles[0].productionPlanning) {
                        allUsers[i].roles[0].productionPlanning = {
                            "desc": "Allow to create Production Planning",
                            "allowNone": !allowCommFun(role, "forInventoryPer", bAdmin),
                            "allowAll": allowCommFun(role, "forInventoryPer", bAdmin),
                            "viewOnMenu": allowCommFun(role, "forInventoryPer", bAdmin),
                            "createProPlan": createObject(role, "Allows to create Production Planning", "forInventoryPer", bAdmin),
                            "approveProPlan": createObject(role, "Allows to Approve Production Planning", "forInventoryPer", bAdmin),
                            "deleteProPlan": createObject(role, "Allows to delete Production Planning", "forInventoryPer", bAdmin),
                            "revertProPlan": createObject(role, "Allows to Revert Approvle Production Planning", "forInventoryPer", bAdmin)
                        };
                    }
                    ;
                    if (!allUsers[i].roles[0].updateStock) {
                        allUsers[i].roles[0].updateStock = {
                            "desc": "Allow to update stock",
                            "allowNone": !allowCommFun(role, "forInventoryPer", bAdmin),
                            "allowAll": allowCommFun(role, "forInventoryPer", bAdmin),
                            "viewOnMenu": allowCommFun(role, "forInventoryPer", bAdmin),
                            "Wastage": createObject(role, "Allows to update stock using wastage", "forInventoryPer", bAdmin),
                            "addBack": createObject(role, "Allows to update stock using add back", "forInventoryPer", bAdmin)
                        };
                    }
                    ;
                }
                ;
                function createCommonNewModuleObj() {
                    let bAdmin = false;
                    if (allUsers[i].roles[1] === 'admin') {
                        bAdmin = true;
                    }
                    if (!allUsers[i].roles[0].expenses) {
                        allUsers[i].roles[0].expenses = {
                            "desc": "Allow to create BOM",
                            "allowNone": !allowCommFun(role, undefined, bAdmin),
                            "allowAll": allowCommFun(role, undefined, bAdmin),
                            "viewOnMenu": allowCommFun(role, undefined, bAdmin),
                            "createExpenses": createObject(role, "Allows to update stock using add back", undefined, bAdmin),
                            "createSaleExpenses": createObject(role, "Allows to update stock using add back", undefined, bAdmin),
                            "createPurchaseExpenses": createObject(role, "Allows to update stock using add back", undefined, bAdmin),
                            "expensesReport": createObject(role, "Allows to update stock using add back", undefined, bAdmin),
                            "createCategory": createObject(role, "Allows to update stock using add back", undefined, bAdmin)
                        };
                    }
                    ;
                    if (!allUsers[i].roles[0].autoReporter) {
                        allUsers[i].roles[0].autoReporter = {
                            "desc": "Allow to create schedular report",
                            "allowNone": !allowCommFun(role, undefined, bAdmin),
                            "allowAll": allowCommFun(role, undefined, bAdmin),
                            "viewOnMenu": allowCommFun(role, undefined, bAdmin),
                            "apis": ["crm/autoReporter"]
                        };
                    }
                    ;
                    if (!soObject || soObject.report === undefined) {
                        const so_api_arr = [
                            "addCustomer2OrdersRestApi",
                            "saveDeliveryRetailRestApi",
                            "saveDeliveryRestApi",
                            "additemRestApi",
                            "cancel_saleRestApi",
                            "getCartTaxes",
                            "editItemRestApi",
                            "getEditRestApi",
                            "removeitemRestApi",
                            "getItemDiscountRestApi",
                            "DeleteItemFromCartRestApi",
                            "getItemsRestApi",
                            "getSalesRestApi",
                            "addCustomer2SaleRestApi",
                            "add_paymentRestApi",
                            "setLocalTax",
                            "updateApplicationSettings",
                            "saveSOOrderRestApi",
                            "loadSOOrderRestApi",
                            "printSOOrderRestApi",
                            "completeSOOrderRestApi",
                            "quickSOOrderRestApi",
                            "addEmployee2SaleRestApi",
                            "setGlobalDiscount"
                        ];
                        if (!allUsers[i].roles[0].salesOrder) {
                            soObject = createMissingObject(role, "Allows to Make the SalesOrder", 'forSalesPer');
                        }
                        else {
                            // soObject.allowNone = soObject.allowNone ? soObject.allowNone : !allowCommFun(role, 'forSalesPer')
                            soObject.allowAll = bAdmin ? true : (soObject.allowAll ? soObject.allowAll : allowCommFun(role, 'forSalesPer', false));
                            soObject.viewOnMenu = bAdmin ? true : (soObject.viewOnMenu ? soObject.viewOnMenu : allowCommFun(role, 'forSalesPer', false));
                        }
                        soObject.sales = soObject.sales ? soObject.sales : createObject(role, "Allows to Take Order For Sales Order", 'forSalesPer', soObject.allowAll);
                        soObject.sales.apis = so_api_arr;
                        soObject.sendSms = soObject.sendSms ? soObject.sendSms : createObject(role, "Allows to Send SMS to the Customer", 'forSalesPer', soObject.allowAll);
                        soObject.sendSms.apis = ["/common/sendSMS"];
                        soObject.sendSms.common = true;
                        soObject.newOrder = soObject.newOrder ? soObject.newOrder : createObject(role, "Allows to take new Sales Order", 'forSalesPer', soObject.allowAll);
                        soObject.editOrder = soObject.editOrder ? soObject.editOrder : createObject(role, "Allows to edit the Sales Order ", 'forSalesPer', soObject.allowAll);
                        soObject.deleteOrder = soObject.deleteOrder ? soObject.deleteOrder : createObject(role, "Allows to Delete the Sales Order ", 'forSalesPer', soObject.allowAll);
                        soObject.printBill = soObject.printBill ? soObject.printBill : createObject(role, "Allows to print bill in Sales Order", 'forSalesPer', soObject.allowAll);
                        soObject.editPrice = soObject.editPrice ? soObject.editPrice : createObject(role, "Allows to Modify the Price While making the Sale.", 'forSalesPer', soObject.allowAll);
                        soObject.editDiscount = soObject.editDiscount ? soObject.editDiscount : createObject(role, "Allows to Modify Discount", 'forSalesPer', soObject.allowAll);
                        soObject.globalDiscount = soObject.globalDiscount ? soObject.globalDiscount : createObject(role, "Allows to Modify Global Discount", 'forSalesPer', soObject.allowAll);
                        soObject.saleSetting = soObject.saleSetting ? soObject.saleSetting : createObject(role, 'Allows to edit sale setting', 'forSalesPer', soObject.allowAll);
                        soObject.checkOut = soObject.checkOut ? soObject.checkOut : createObject(role, 'Allows to Complete the Sales Order Transaction', 'forSalesPer', soObject.allowAll);
                        soObject.cancelOrder = soObject.cancelOrder ? soObject.cancelOrder : createObject(role, 'Allows to cancel the Sales Order', 'forSalesPer', soObject.allowAll);
                        soObject.advancePayment = soObject.advancePayment ? soObject.advancePayment : createObject(role, 'Allows to do advance payment of Sales Order', 'forSalesPer', soObject.allowAll);
                        soObject.editDeliveryInfo = soObject.editDeliveryInfo ? soObject.editDeliveryInfo : createObject(role, 'Allows to change the delievry info', 'forSalesPer', soObject.allowAll);
                        soObject.report = soObject.report ? soObject.report : createObject(role, 'Allows to show report', 'forSalesPer', soObject.allowAll);
                        if (bAdmin) {
                            let keys = ["sales",
                                "sendSms",
                                "newOrder",
                                "editOrder",
                                "deleteOrder",
                                "printBill",
                                "editPrice",
                                "editDiscount",
                                "globalDiscount",
                                "saleSetting",
                                "checkOut",
                                "cancelOrder",
                                "advancePayment",
                                "editDeliveryInfo",
                                "report"];
                            let descriptions = ["Allows to Take Order For Sales Order",
                                "Allows to Send SMS to the Customer",
                                "Allows to take new Sales Order",
                                "Allows to edit the Sales Order ",
                                "Allows to Delete the Sales Order ",
                                "Allows to print bill in Sales Order",
                                "Allows to Modify the Price While making the Sale.",
                                "Allows to Modify Discount",
                                "Allows to Modify Global Discount",
                                "Allows to edit sale setting",
                                "Allows to Complete the Sales Order Transaction",
                                "Allows to cancel the Sales Order",
                                "Allows to do advance payment of Sales Order",
                                "Allows to change the delievry info",
                                "Allows to show report"
                            ];
                            for (let i = 0; i < keys.length; i++) {
                                soObject[keys[i]] = createObject(role, descriptions[i], 'forSalesPer', true);
                            }
                        }
                        allUsers[i].roles[0].salesOrder = soObject;
                    }
                    if (!allUsers[i].roles[0].salesQuotation) {
                        allUsers[i].roles[0].salesQuotation = {
                            "desc": "Allow to create SalesQuotation",
                            "allowNone": !allowCommFun(role, 'forSalesPer', bAdmin),
                            "allowAll": allowCommFun(role, 'forSalesPer', bAdmin),
                            "viewOnMenu": allowCommFun(role, 'forSalesPer', bAdmin),
                            "apis": [
                                "saveSQRestApi",
                                "addCustomer2OrdersRestApi",
                                "saveDeliveryRetailRestApi",
                                "saveDeliveryRestApi",
                                "additemRestApi",
                                "cancel_saleRestApi",
                                "getCartTaxes",
                                "editItemRestApi",
                                "getEditRestApi",
                                "removeitemRestApi",
                                "getItemDiscountRestApi",
                                "DeleteItemFromCartRestApi",
                                "getItemsRestApi",
                                "getSalesRestApi",
                                "addCustomer2SaleRestApi",
                                "add_paymentRestApi",
                                "setLocalTax",
                                "updateApplicationSettings",
                                "saveSOOrderRestApi",
                                "loadSOOrderRestApi",
                                "printSOOrderRestApi",
                                "addEmployee2SaleRestApi",
                                "setGlobalDiscount"
                            ]
                        };
                    }
                    ;
                    if (!allUsers[i].roles[0].tally) {
                        allUsers[i].roles[0].tally = {
                            "desc": "Allow to export and import from PG to Tally",
                            "allowNone": !allowCommFun(role, undefined, bAdmin),
                            "allowAll": allowCommFun(role, undefined, bAdmin),
                            "viewOnMenu": allowCommFun(role, undefined, bAdmin),
                            "apis": ["convertAlienhuToTally",
                                "convertCustomerT2AH",
                                "convertItemT2AH"
                            ]
                        };
                    }
                    ;
                }
                // console.log("allser up data", allUsers[i].roles[0]);
                allUsers[i].roles[0] = JSON.stringify(allUsers[i].roles[0]);
                allUsersDoc.push(allUsers[i]);
            }
            // console.log("allUsersDoc", allUsersDoc);
            if (allUsersDoc.length)
                yield bulkInsert(usersDBInstance, allUsersDoc, logger);
        }
        catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    });
};
exports.down = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let bthrow = true;
        if (bthrow) {
            throw 'not implemented. migrations for usersdb';
        }
        let logger = params.logger;
        const usersDBInstance = params.nanoClients.users;
        let migrationName = path.basename(__filename, '.js');
        try {
            let allUsers = yield getAllUserDocs(usersDBInstance, {}, true, logger);
            let allUsersDoc = [];
            for (let i = 0; i < allUsers.length; i++) {
                if (!allUsers[i].roles[0])
                    continue;
                try {
                    allUsers[i].roles[0] = JSON.parse(allUsers[i].roles[0]);
                }
                catch (error) {
                    logger.error(error);
                    continue;
                }
                let role = allUsers[i].roles[1];
                let APP_TYPE = allUsers[i].APP_TYPE;
                if (APP_TYPE.indexOf('_')) {
                    //tito_retail
                    //tito_restaurant 
                    APP_TYPE = APP_TYPE.split('_')[1];
                }
                let reportObj = allUsers[i].roles[0].reports;
                let tablesObject = allUsers[i].roles[0].tables;
                let hdObject = allUsers[i].roles[0].homeDelivery;
                let taObject = allUsers[i].roles[0].takeAway;
                let salesObject = allUsers[i].roles[0].sales;
                if (APP_TYPE === "restaurant") {
                    tableDMigration();
                    salesDRestaurantMigration();
                    taAndSalesDMigration(taObject); // Take Away
                }
                else if (APP_TYPE === "retail") {
                    taAndSalesDMigration(salesObject); // Sales for retail
                }
                if (APP_TYPE === "restaurant" || APP_TYPE === "retail") {
                    hdDMigration();
                    reportDMigration();
                    deleteExpenseObj();
                    delNewModuleObj();
                }
                function tableDMigration() {
                    const table_TO = [
                        "additemRestApi",
                        "add_paymentRestApi",
                        "completeSaleRestApi",
                        "getCartTaxes",
                        "addCustomer2SaleRestApi",
                        "receiptRestApi",
                        "printReceiptApi",
                        "setPrintAfterSaleRestApi",
                        "setInvoiceNumberEnabledRestApi",
                        "setInvoiceNumberRestApi",
                        "invoiceRestApi",
                        "DeleteItemFromCartRestApi",
                        "getItemsRestApi",
                        "checkAlreadyReservedRestApi",
                        "getReservationDetails"
                    ];
                    const tablesFeature = {
                        "createTable": ["createTableRestApi"],
                        "deleteTable": ["deleteTableApiRestApi"],
                        "editPrice": ["editItemRestApi"],
                        "editDiscount": ["editItemRestApi"],
                        "cancelOreder": ["cancel_saleRestApi"],
                        "editKot": ["editSaveKOTRestApi"],
                        "editDiscounts": ["editItemRestApi"],
                        "takePayment": ["add_paymentRestApi"],
                        "completeOrder": ["completeTakeOrderRestApi"],
                        "billSplit": ["splitBillRestApi"]
                    };
                    const tableFeatureArr = ['changeTable', 'mergeTable']; //
                    delete tablesObject.apis;
                    tablesObject.editPrice = createObject(role, "Allows to Edit price of the item", 'forSalesPer', tablesObject.allowAll);
                    tablesObject.editDiscount = createObject(role, "Allows to Edit Discount of the Item", 'forSalesPer', tablesObject.allowAll);
                    tablesObject.cancelOreder = createObject(role, "Allows to Cancel the Order", 'forSalesPer', tablesObject.allowAll);
                    tablesObject.editKot = createObject(role, "Allows to Edit KOT", 'forSalesPer', tablesObject.allowAll);
                    tablesObject.editDiscounts = createObject(role, "Allows to Edit the Discount", 'forSalesPer', tablesObject.allowAll);
                    tablesObject.takePayment = createObject(role, "Allows to Make Payment", 'forSalesPer', tablesObject.allowAll);
                    tablesObject.completeOrder = createObject(role, "Allows to Complete the Order", 'forSalesPer', tablesObject.allowAll);
                    tablesObject.billSplit = createObject(role, "Allows to Split the Order Bill", 'forSalesPer', tablesObject.allowAll);
                    tablesObject.takeOrder = createObject(role, "Allows to Take Order For the Table", 'forSalesPer', tablesObject.allowAll);
                    deleteObj(tableFeatureArr, tablesObject);
                    addApiFunc(tablesFeature, tablesObject);
                    tablesObject.takeOrder.apis = table_TO;
                }
                function salesDRestaurantMigration() {
                    if (allUsers[i].roles[0].salesRestaurant) {
                        delete allUsers[i].roles[0].salesRestaurant;
                    }
                    ;
                }
                function hdDMigration() {
                    const hdFeatureArr = ['newOrder', 'homeDelivery', 'printBill', 'editPrice', 'editDiscount', 'globalDiscount', 'saleSetting'];
                    const hdFeature = {
                        "editOrder": ["getEditRestApi", "editItemRestApi"],
                        "viewOrder": ["allSuspendedSalesRestApi"],
                        "takeOrderPayment": ["add_paymentRestApi"],
                        "completeDelivery": ["completeDeliverySaleApiRestApi"],
                        "deleteOrder": ["deleteHomeDeliveryRestApi"]
                    };
                    const hd_to_api = [
                        "addCustomer2OrdersRestApi",
                        "saveDeliveryRetailRestApi",
                        "additemRestApi",
                        "cancel_saleRestApi",
                        "getCartTaxes",
                        "editItemRestApi",
                        "getEditRestApi",
                        "removeitemRestApi",
                        "getItemDiscountRestApi",
                        "DeleteItemFromCartRestApi",
                        "getItemsRestApi"
                    ];
                    deleteObj(hdFeatureArr, hdObject);
                    hdObject.takeOrder = createObject(role, "Allows to Take Order For Home Delivery", 'forSalesPer', hdObject.allowAll);
                    hdObject.takeOrder.apis = hd_to_api;
                    hdObject.viewOrder = createObject(role, "Allows to View All HomeDelivery Orders", 'forSalesPer', hdObject.allowAll);
                    hdObject.takeOrderPayment = createObject(role, "Allows to Take the Payment of the HomeDelivery", 'forSalesPer', hdObject.allowAll);
                    addApiFunc(hdFeature, hdObject);
                }
                ;
                function taAndSalesDMigration(taAndSalesObj) {
                    const taFeatureArr = ['saleSetting', 'globalDiscount'];
                    const taFeature = {
                        "editPrice": ["editItemRestApi"],
                        "editDiscount": ["editItemRestApi", "getItemDiscountRestApi"],
                        "suspendSales": ["allSuspendedSalesRestApi", "suspendSaleRestApi"],
                        "unsuspendSales": ["unsuspendSaleRestApi"]
                    };
                    const ta_salesHistoryFeature = {
                        "view": ["handled@ClientSide", "manageRestApi"],
                        "update": ["update", "saveEditSalesRestApi"],
                        "delete": ["delete", "deleteSaleRestApi"]
                    };
                    const ta_makeSales = ["addEmployee2SaleRestApi",
                        "editItemRestApi",
                        "setGlobalDiscount",
                        "addCustomer2OrdersRestApi",
                        "quickSaleRestApi",
                        "suspendSaleRestApi",
                        "allSuspendedSalesRestApi",
                        "unsuspendSaleRestApi",
                        "update",
                        "delete_paymentRestApi",
                        "deleteSuspendedSale",
                        "setLocalTax",
                        "updateApplicationSettings"
                    ];
                    deleteObj(taFeatureArr, taAndSalesObj);
                    taAndSalesObj.viewOthersSuspendedSales = createObject(role, "Allows to View Suspened Sales of OtherUsers", 'forSalesPer', taAndSalesObj.allowAll);
                    addApiFunc(taFeature, taAndSalesObj);
                    addApiFunc(ta_salesHistoryFeature, taAndSalesObj.salesHistory);
                    do {
                        let tempIndex1 = taAndSalesObj.makeReturn.apis.indexOf('completeReturn');
                        taAndSalesObj.makeReturn.apis.splice(tempIndex1, 1);
                    } while (taAndSalesObj.makeReturn.apis && taAndSalesObj.makeReturn.apis.indexOf('completeReturn') !== -1);
                    // let tempIndex1 = taAndSalesObj.makeReturn.apis.indexOf('completeReturn');
                    // taAndSalesObj.makeReturn.apis.splice(tempIndex1, 1);
                    let apiDirtyObj = {};
                    for (let k = 0; k < taAndSalesObj.makeSale.apis.length; k++) {
                        if (!apiDirtyObj[taAndSalesObj.makeSale.apis[k]]) {
                            apiDirtyObj[taAndSalesObj.makeSale.apis[k]] = true;
                            continue;
                        }
                        taAndSalesObj.makeSale.apis.splice(k, 1);
                        k = k - 1;
                    }
                    for (var j = 0; j < taAndSalesObj.makeSale.apis.length; j++) {
                        let cancel_index = ta_makeSales.indexOf(taAndSalesObj.makeSale.apis[j]);
                        if (cancel_index === -1) {
                            continue;
                        }
                        let tempIndex = taAndSalesObj.makeSale.apis.indexOf(ta_makeSales[cancel_index]);
                        taAndSalesObj.makeSale.apis.splice(tempIndex, 1);
                        j = j - 1;
                    }
                }
                function reportDMigration() {
                    const reportFeatureArr = ['editSale', 'rejectSale', 'deleteSale', 'purchaseEdit', 'purchaseReject', 'purchaseDelete'];
                    const reportFeature = {
                        "purchases": ["DetailedEmpRestAPI"],
                        "items": ["graphicalSummaryItemGraphRestAPI", "SummaryItemRestAPI"],
                        "employees": ["graphicalSummaryEmployeeGraphRestAPI", "SummaryEmployeeRestAPI", "DetailedEmpRestAPI"],
                        "suppliers": ["graphicalSummarySupGraphRestAPI", "SummarySupplierRestAPI"],
                        "sales": ["graphicalSummarySaleGraphRestAPI", "SummarySaleRestAPI"],
                        "discounts": ["graphicalSummaryDiscountGraphRestAPI", "SummaryDiscountRestAPI", "DetailedDisRestAPI"],
                        "taxes": ["graphicalSummaryTaxGraphRestAPI", "SummaryDiscountRestAPI", "DetailedDisRestAPI"],
                        "inventory": ["LowInventoryRestAPI", "InventorySumRestAPI"],
                        "categories": ["graphicalSummaryCategoriesGraphRestAPI", "SummaryCategoryRestAPI"],
                        "payments": ["graphicalSummaryPaymentGraphRestAPI", "SummaryPaymentRestAPI"],
                        "customers": ["graphicalSummaryCustomerGraphRestAPI", "SummaryCustomerRestAPI", "DetailedCustRestAPI"],
                        "gstreports": ["gstr1_12", "gstr2"],
                    };
                    deleteObj(reportFeatureArr, reportObj);
                    delete reportObj.apis;
                    for (let ele in reportFeature) {
                        reportObj[ele].apis = reportFeature[ele];
                        if (ele === "sales") {
                            reportObj[ele].salesHistory.apis = ["DetailedSaleRestAPI"];
                        }
                    }
                }
                function deleteObj(objectFeature, object) {
                    for (var i = 0; i < objectFeature.length; i++) {
                        delete object[objectFeature[i]];
                    }
                }
                ;
                function addApiFunc(salesFeature, salesObject) {
                    for (let ele in salesFeature) {
                        salesObject[ele].apis = salesFeature[ele];
                    }
                }
                function delNewModuleObj() {
                    if (allUsers[i].roles[0].bom) {
                        delete allUsers[i].roles[0].bom;
                    }
                    ;
                    if (allUsers[i].roles[0].productionPlanning) {
                        delete allUsers[i].roles[0].productionPlanning;
                    }
                    ;
                    if (allUsers[i].roles[0].updateStock) {
                        delete allUsers[i].roles[0].updateStock;
                    }
                    ;
                    if (allUsers[i].roles[0].autoReporter) {
                        delete allUsers[i].roles[0].autoReporter;
                    }
                    ;
                    if (allUsers[i].roles[0].salesOrder) {
                        delete allUsers[i].roles[0].salesOrder;
                    }
                    ;
                    if (allUsers[i].roles[0].salesQuotation) {
                        delete allUsers[i].roles[0].salesQuotation;
                    }
                    ;
                    if (allUsers[i].roles[0].tally) {
                        delete allUsers[i].roles[0].tally;
                    }
                    ;
                }
                ;
                function deleteExpenseObj() {
                    if (allUsers[i].roles[0].expenses) {
                        delete allUsers[i].roles[0].expenses;
                    }
                    ;
                }
                allUsers[i].roles[0] = JSON.stringify(allUsers[i].roles[0]);
                allUsersDoc.push(allUsers[i]);
            }
            if (allUsersDoc)
                yield bulkInsert(usersDBInstance, allUsersDoc, logger);
        }
        catch (error) {
            logger.error(error);
            throw migrationName + ' down migration failed';
        }
    });
};
function getAllUserDocs(db, params, bOnlyDocs, logger) {
    return __awaiter(this, void 0, void 0, function* () {
        params = params || {};
        params.include_docs = true;
        try {
            let [body, header] = yield db.fetch({}, params);
            if (!bOnlyDocs) {
                return body.rows;
            }
            else {
                //This is just wasting of 1 for loop for the inconvinience of having to write body.rows[i].doc everytime
                //Bad don't use it
                let resp = [];
                for (let i = 0; i < body.rows.length; i++) {
                    if (body.rows[i].id.indexOf('_design/') === 0) {
                        continue;
                    }
                    if (body.rows[i].doc.APP_TYPE === process.env.APP_TYPE || body.rows[i].doc.strRegistrationId) {
                        let doc = body.rows[i].doc;
                        resp.push(doc);
                    }
                }
                return resp;
            }
        }
        catch (err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        }
    });
}
function bulkInsert(db, docsArray, logger) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let resp = yield db.bulk({
                docs: docsArray
            });
            return resp;
        }
        catch (error) {
            logger.error(error);
            throw 'Bulk Update Failed';
        }
    });
}
;
//# sourceMappingURL=201810280000000-employeePermission.js.map