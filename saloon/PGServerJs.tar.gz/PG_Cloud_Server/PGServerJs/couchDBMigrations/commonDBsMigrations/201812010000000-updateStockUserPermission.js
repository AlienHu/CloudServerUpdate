/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require('fs');
var path = require('path');
function allowCommFun(role, singleRole, isAllowAll) {
    let bAllowed = false;
    if (role === 'admin') {
        bAllowed = true;
    }
    else if (role === 'inventoryManager' && singleRole == "forInventoryPer") {
        bAllowed = true;
    }
    else if (role === 'salesPerson' && singleRole == "forSalesPer") {
        bAllowed = true;
    }
    else if (role === '' && isAllowAll) {
        bAllowed = true;
    }
    return bAllowed;
}
function createObject(role1, desc, singleRole1, isAllowAll) {
    var bAdmin = false;
    if (role1 === 'admin') {
        bAdmin = true;
    }
    return {
        "allowed": allowCommFun(role1, singleRole1, bAdmin),
        "desc": desc
    };
}
exports.up = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = params.logger;
        const usersDBInstance = params.nanoClients.users;
        let migrationName = path.basename(__filename, '.js');
        try {
            let allUsers = yield getAllUserDocs(usersDBInstance, {}, true, logger);
            let allUsersDoc = [];
            for (let i = 0; i < allUsers.length; i++) {
                if (!allUsers[i].roles[0])
                    continue;
                try {
                    allUsers[i].roles[0] = JSON.parse(allUsers[i].roles[0]);
                }
                catch (error) {
                    logger.error(error);
                    continue;
                }
                let role = allUsers[i].roles[1];
                let APP_TYPE = allUsers[i].APP_TYPE;
                if (APP_TYPE.indexOf('_')) {
                    //tito_retail
                    //tito_restaurant 
                    APP_TYPE = APP_TYPE.split('_')[1];
                }
                if (APP_TYPE === "retail") {
                    createMissingModuleObj();
                }
                function createMissingModuleObj() {
                    let bAdmin = false;
                    if (allUsers[i].roles[1] === 'admin') {
                        bAdmin = true;
                    }
                    if (!allUsers[i].roles[0].updateStock) {
                        allUsers[i].roles[0].updateStock = {
                            "desc": "Allow to update stock",
                            "allowNone": !allowCommFun(role, "forInventoryPer", bAdmin),
                            "allowAll": allowCommFun(role, "forInventoryPer", bAdmin),
                            "viewOnMenu": allowCommFun(role, "forInventoryPer", bAdmin),
                            "Wastage": createObject(role, "Allows to update stock using wastage", "forInventoryPer", bAdmin),
                            "addBack": createObject(role, "Allows to update stock using add back", "forInventoryPer", bAdmin)
                        };
                    }
                    ;
                }
                allUsers[i].roles[0] = JSON.stringify(allUsers[i].roles[0]);
                allUsersDoc.push(allUsers[i]);
            }
            // console.log("allUsersDoc", allUsersDoc);
            if (allUsersDoc.length)
                yield bulkInsert(usersDBInstance, allUsersDoc, logger);
        }
        catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    });
};
exports.down = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
    });
};
function getAllUserDocs(db, params, bOnlyDocs, logger) {
    return __awaiter(this, void 0, void 0, function* () {
        params = params || {};
        params.include_docs = true;
        try {
            let [body, header] = yield db.fetch({}, params);
            if (!bOnlyDocs) {
                return body.rows;
            }
            else {
                //This is just wasting of 1 for loop for the inconvinience of having to write body.rows[i].doc everytime
                //Bad don't use it
                let resp = [];
                for (let i = 0; i < body.rows.length; i++) {
                    if (body.rows[i].id.indexOf('_design/') === 0) {
                        continue;
                    }
                    if (body.rows[i].doc.APP_TYPE === process.env.APP_TYPE || body.rows[i].doc.strRegistrationId) {
                        let doc = body.rows[i].doc;
                        resp.push(doc);
                    }
                }
                return resp;
            }
        }
        catch (err) {
            logger.error(err);
            throw 'Fatal! Not expected to come here. This API doesnt throw any error';
        }
    });
}
function bulkInsert(db, docsArray, logger) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let resp = yield db.bulk({
                docs: docsArray
            });
            return resp;
        }
        catch (error) {
            logger.error(error);
            throw 'Bulk Update Failed';
        }
    });
}
;
//# sourceMappingURL=201812010000000-updateStockUserPermission.js.map