/*
 *		https://github.com/winstonjs/winston
 *		{ error: 0, warn: 1, info: 2, verbose: 3, debug: 4, silly: 5 }  https://github.com/winstonjs/winston#logging-levels		
 *		https://github.com/winstonjs/winston/blob/master/docs/transports.md for arguments
 *		Todo: Uncaught exception logger. How to configure it?
 *		Todo: Configure Log Dir Path
 */

var Logger = function() {
    'use strict';

    var path = require('path');
    var winston = require('winston');
    var env = process.env.ENVIRONMENT || "development";
    var config = require(path.join(__dirname, '..', 'config', 'config.json'))[env];

    var logger;
    var moment = require('moment');

    function getCurrentTime() {
        return moment().format('YYYYMMDDHHmmss');
    }

    function initLogger() {

        var timeStamp = moment().format('YYYYMMDDHHmmss');
        logger = new(winston.Logger)({
            level: 'error',
            transports: [
                new(winston.transports.Console)({
                    level: 'error' //Todo: This has to come from configuration				
                }),
                new(winston.transports.File)({
                    name: 'info-logger',
                    filename: 'pgserverjs_info_' + timeStamp + '.log',
                    level: config.logLevel, //Todo: This has to come from configuration
                    maxsize: 1048576, // 1MB in Bytes
                    maxFiles: 25,
                    maxRetries: 10,
                    json: false,
                    tailable: true,
                    zippedArchive: false,
                    timestamp: getCurrentTime
                    // 		// }),
                    // 		// new(winston.transports.File)({
                    // 		// 	name: 'error',
                    // 		// 	filename: 'error_' + timeStamp + '.log',
                    // 		// 	level: 'error'
                })
            ]
        });

        logger.add(winston.transports.File, {
            filename: 'pgserverjs_exception_' + timeStamp + '.log',
            handleExceptions: true,
            timestamp: getCurrentTime,
            humanReadableUnhandledException: true,
            json: false,
            maxRetries: 10,
            maxsize: 1048576, // 1MB in Bytes
            maxFiles: 25,
            tailable: true
        });
        logger.exitOnError = false;
    }

    initLogger();

    //Commenting this function to force use the other log functions
    // //default level is error 
    // this.log = function (logMsgObj, level) {
    // 	if(level === 'undefined')
    // 		level = 'error'; 
    // 	return logger.log(level, logMsgObj);
    // };

    this.error = function(logMsgObj) {
        return logger.error(logMsgObj);
    };

    this.warn = function(logMsgObj) {
        return logger.warn(logMsgObj);
    };

    this.info = function(logMsgObj) {
        return logger.info(logMsgObj);
    };

    this.verbose = function(logMsgObj) {
        return logger.verbose(logMsgObj);
    };

    this.debug = function(logMsgObj) {
        return logger.debug(logMsgObj);
    };

    this.silly = function(logMsgObj) {
        return logger.silly(logMsgObj);
    };

};
module.exports = new Logger();