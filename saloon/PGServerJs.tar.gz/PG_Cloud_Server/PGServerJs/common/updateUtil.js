var fs = require("fs");

var CommonUtils = function() {

    function isDataValid(data, type, checkLength) {
        if (data == null) return false;
        if (type != null && typeof(data) != type) return false;
        if (type == "object" && checkLength === true) {
            if (data.constructor.name !== "Array") return false;
        }
        if ((checkLength != null) && checkLength && data.length == 0) {
            return false;
        }
        return true;
    }

    function readFileSync(filePath, toJsonObj) {
        try {
            var data = fs.readFileSync(filePath, 'utf8');
            if (toJsonObj) {
                try {
                    if (typeof data === 'object')
                        return data;
                    if (typeof data === 'string')
                        return JSON.parse(data);
                } catch (e) {
                    return {
                        error: true,
                        message: e.message
                    };
                }
            } else
                return data;
        } catch (ex) {
            return {
                error: true,
                message: ex.message
            };
        }
    }

    var deleteFolderRecursive = function(path) {
        try {
            if (fs.existsSync(path)) {
                fs.readdirSync(path).forEach(function(file, index) {
                    var curPath = path + "/" + file;
                    if (fs.lstatSync(curPath).isDirectory()) {
                        deleteFolderRecursive(curPath);
                    } else {
                        fs.unlinkSync(curPath);
                    }
                });
                fs.rmdirSync(path);
            }
        } catch (ex) {
            console.error(ex);
            return ex;
        }
    };

    var deleteFolder = function(dirPath) {
        try {
            if (!fs.existsSync(dirPath)) {
                return null;
            }
            var stat = fs.statSync(dirPath);
            if (stat.isDirectory()) {
                return deleteFolderRecursive(dirPath);
            }
        } catch (err) {
            console.error(err);
            return err;
        }
        return null;
    }

    var deleteFile = function(file) {
        try {
            if (fs.existsSync(file)) {
                fs.unlinkSync(file);
            }
        } catch (err) {
            return err;
        }
        return null;
    }

    var compareVersion = function(actual, expected) {
        if (!isDataValid(actual, "string", true) || !isDataValid(expected, "string", true)) {
            throw "Invalid data for comparison"
        }
        var actArr = actual.split('.');
        var expArr = expected.split('.');
        for (var i in expArr) {
            if (actArr.length <= i)
                break;
            var res = actArr[i].localeCompare(expArr[i]);
            if (res == 0)
                continue;
            return res;
        }
        return 0;
    }

    this.isDataValid = isDataValid;
    this.readFileSync = readFileSync;
    this.deleteFile = deleteFile;
    this.deleteFolder = deleteFolder;
    this.compareVersion = compareVersion;
}

module.exports = new CommonUtils();