let googl = require('goo.gl');
// const GOOGLE_SECRET_KEY = 'AIzaSyArygfKxZoNDqD4Poeg1aAMrLiPCIUAvSk';
const GOOGLE_SECRET_KEY = 'AIzaSyB-liupK_6WJ_t83s5L_RNfaX--AhnhqOw';
googl.setKey(GOOGLE_SECRET_KEY);
var Utils = function() {
    'use strict';

    let _self = this;

    function isObject(obj) {
        return obj === Object(obj);
    }

    this.compareKeys = function(refObj, insObj, excludeKeys, errorsArray) {
        if (!errorsArray) {
            errorsArray = [];
        }
        if (!excludeKeys) {
            excludeKeys = [];
        }

        for (var key in refObj) {
            if (excludeKeys.indexOf(key) !== -1) {
                continue;
            }

            if (!refObj.hasOwnProperty(key)) {
                continue;
            }

            if (!insObj.hasOwnProperty(key)) {
                let errMsg = key + " not found in insObj";
                errorsArray.push(errMsg);
                continue;
            }

            let ref = refObj[key];
            let ins = insObj[key];
            if (typeof(ref) !== typeof(ins)) {
                let errMsg = 'Type mismatch. key<' + key + '> ref<' + typeof(ref) + '> ins<' + typeof(ins) + '>';
                errorsArray.push(errMsg);
            }

            if (Array.isArray(ref)) {
                continue;
            } else if (isObject(ref)) {
                _self.compareObject(ref, ins, excludeKeys, errorsArray);
            }
        }

        return errorsArray.length === 0;
    };

    this.syncKeys = function(refObj, insObj, excludeKeys, errorsArray) {
        if (!errorsArray) {
            errorsArray = [];
        }

        copyKeys(refObj, insObj, excludeKeys, errorsArray);
        deleteKeys(refObj, insObj, excludeKeys, errorsArray);
        return errorsArray.length === 0;
    }

    function copyKeys(refObj, insObj, excludeKeys, errorsArray) {
        if (!errorsArray) {
            errorsArray = [];
        }
        if (!excludeKeys) {
            excludeKeys = [];
        }

        for (var key in refObj) {
            if (excludeKeys.indexOf(key) !== -1) {
                continue;
            }

            if (!refObj.hasOwnProperty(key)) {
                continue;
            }

            if (!insObj.hasOwnProperty(key)) {
                let errMsg = key + " not found in insObj";
                errorsArray.push(errMsg);
                insObj[key] = refObj[key];
                continue;
            }

            let ref = refObj[key];
            let ins = insObj[key];
            if (typeof(ref) !== typeof(ins)) {
                let errMsg = 'Type mismatch. key<' + key + '> ref<' + typeof(ref) + '> ins<' + typeof(ins) + '>';
                errorsArray.push(errMsg);
                insObj[key] = refObj[key];
                continue;
            }

            if (Array.isArray(ref)) {
                continue;
            } else if (isObject(ref)) {
                copyKeys(ref, ins, excludeKeys, errorsArray);
            }
        }

        return errorsArray.length === 0;
    }

    function deleteKeys(refObj, insObj, excludeKeys, errorsArray) {
        if (!errorsArray) {
            errorsArray = [];
        }
        if (!excludeKeys) {
            excludeKeys = [];
        }

        for (var key in insObj) {
            if (excludeKeys.indexOf(key) !== -1) {
                continue;
            }

            if (!insObj.hasOwnProperty(key)) {
                continue;
            }

            if (!refObj.hasOwnProperty(key)) {
                let errMsg = key + " not found in refObj";
                errorsArray.push(errMsg);
                delete insObj[key];
                continue;
            }

            let ref = refObj[key];
            let ins = insObj[key];
            if (typeof(ref) !== typeof(ins)) {
                let errMsg = 'Type mismatch. key<' + key + '> ref<' + typeof(ref) + '> ins<' + typeof(ins) + '>';
                errorsArray.push(errMsg);
                insObj[key] = refObj[key];
            }

            if (Array.isArray(ref)) {
                continue;
            } else if (isObject(ref)) {
                deleteKeys(ref, ins, excludeKeys, errorsArray);
            }
        }

        return errorsArray.length === 0;
    }

    this.getShortUrl = async function(url) {
        let shortUrl = await googl.shorten(url);
        console.log("============short url================", shortUrl);
        return shortUrl
    }

};
module.exports = new Utils();