/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */

var profitGuruStatusEvents = require('../common/profitGuruStatusEvents.js');
var createSingleton = require('create-singleton');
var _self;
var BPromise = require('bluebird');
var q = require('q');
var DbManagers = require('../dbManagers');

var couchDbMain = require('../couchDb/couchDBMain.js');
var featuresCouchHandler = require('../couchDb/featuresCouchHandler')(couchDbMain);
var coreCouchHandler = require('../couchDb/coreCouchHandler.js');

var PGConfigSingleton = createSingleton(function profitGuruConfig() {

    _self = this;

    var prodConfigs;
    var appType = process.env.APP_TYPE;

    this.isValidClientType = function(clinetType) {
        return ["MobileApp", "DeskTopApp"].indexOf(clinetType) >= 0;
    };

    this.getCouchUrl = function(dbInfo) {
        return couchDbMain.getCouchUrl(dbInfo);
    };

    this.getProdEnvConfigs = function() {
        return {
            //WIth Request get these setting from couchDB + Cloud Apis
        };
    };

    this.initProfitGuruServer = function() {
        //TODO
        //get the session db name from here itself,and dont return it from couchdbManager        
        //once after initing the progitGuruServer with new couch based settings

        return new Promise(function(resolve, reject) {
            var response = {};
            couchDbMain.initAllCouchDBs().then(function(couchDbMainResp) {
                BPromise.props({
                    userOrEmployeeAllEntitlements: coreCouchHandler.getAllUserOrEmployeeEntitlements(appType),
                    allowedApplicationFeatures: featuresCouchHandler.getAllowedApplicationFeatures(appType),
                }).then(function(promiseResults) {
                    response = promiseResults;
                    response.applicationSettings = couchDbMainResp.applicationSettings;
                    response.sessionDbName = couchDbMainResp.sessionDbName;
                    response.config = couchDbMain.getprofitGuruNodeServerConfig();
                    resolve(response);
                }).catch(function(reason) {
                    reject(reason);
                });

            }).catch(function(reason) {
                reject(reason);
            });
        });

    };
});
module.exports = new PGConfigSingleton();