let item = {
    "$index": 0,
    "item_id": 1,
    "_id": "item_1",
    "name": "Samsung E 1200 GURU 1200",
    "categoryId": 1516196300273,
    "item_number": "",
    "purchasePrice": null,
    "sellingPrice": 0,
    "mrp": null,
    "reorderLevel": 0,
    "reorderQuantity": 0,
    "is_serialized": false,
    "imeiCount": 0,
    "hasExpiryDate": false,
    "purchaseUnitId": 1516196299075,
    "sellingUnitId": 1516196299075,
    "conversionFactor": 1,
    "hasBatchNumber": false,
    "bOTG": true,
    "bSPTaxInclusive": false,
    "bPPTaxInclusive": false,
    "purchaseTaxes": [
        1516196300111
    ],
    "salesTaxes": [
        1516196300111
    ],
    "hasVariants": false,
    "attributes": [],
    "ItemType": "Normal",
    "hsn": 8517,
    "density": 0,
    "categoryInfo": {
        "itemCount": 1,
        "salesItemCount": 1,
        "purchaseItemCount": 1,
        "name": "Samsung",
        "doc": {
            "$index": 0,
            "name": "Samsung",
            "description": "Default Categories",
            "id": 1516196300273,
            "_id": "category_1516196300273",
            "_rev": "1-495e2817c5a6e02349c9ac0c7e7563b6"
        }
    },
    "quantity": 28
}


export default item;