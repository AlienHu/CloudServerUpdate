import target from './items';
import source from './pouchItem';

let targetKeys: Array<string> = Object.keys(target);
let sourceKeys: Array<string> = Object.keys(source);

let directMatches: Array<string> = [];
let missingMatches: Array<string> = [];
for (let i: number = 0; i < targetKeys.length; i++) {
    let key = targetKeys[i];
    if (sourceKeys.indexOf(key) > -1) {
        directMatches.push(key);
    } else {
        missingMatches.push(key);
        console.log('You die <' + key + '>');
    }
}

import * as jsonfile from "jsonfile";
jsonfile.writeFileSync('./directMatches.json', directMatches);
jsonfile.writeFileSync('./missingMatches.json', missingMatches);

console.log('Total Keys<' + targetKeys.length + '> Matched Keys<' + directMatches.length + '> Missed<' + missingMatches.length + '>');

