/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */
var express = require('express');
var httpProxy = require('http-proxy');
var arp = require('node-arp');
var LicenceGenerator = require('./LicenceGenerator.js');
var apply4trialLicence = require('./apply4TrialLicence.js');
var router = express.Router();

/* GET home page. */
var request = require('request');

router.all('/', function(req, res, next) {
    try {

        LicenceGenerator.genLicence(function(licence) {
            console.log(licence);
            res.json(licence);
            res.end();
        });
    } catch (exp) {
        console.log(exp);
        res.send({
            error: "Failed to generate Licence"
        });
        res.end();
    }


});



module.exports = router;