/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */
//var mysql = require('mysql');
var createSingleton = require('create-singleton');
var q = require('q');
var dns = require('dns');
var moment = require('moment');
//var couchDbCommon = require('./../couchRoutes/sql2CouchSyncHandlers/couchDBMain.js');
var licenceCouchHandler = require('../couchDb/licenceCouchHandler.js');
var profitGuruStatusEvents = require('../common/profitGuruStatusEvents.js');
var apply4trialLicence = require('./apply4TrialLicence.js');
var genLicenceSeed = require('./licenceGenerator.js');
var logger = require('../common/Logger');
var HashMap = require('hashmap');
var _ = require('underscore');
var crypto = require('crypto'),
    algorithm = 'aes-256-ctr';
//var serialNumber = require('serial-number');
//var serverSerialNumber;
//serialNumber.preferUUID = true;
var profitGuruPos_comIp;
var ip = require("ip");
var publicIp = require('public-ip');
const macUtils = require('../common/macUtils');
var isServerRunningOnProfitGuruCloud = true;
//Get the IpAddress of alienhu.com
dns.lookup('alienhu.com', function (err, addresses) {
    if (err) {
        console.log('Could not find The IpAddress for alienhu.com');
        profitGuruPos_comIp = false;
    } else {
        publicIp.v4().then(function (pubIp) {
            if (pubIp === profitGuruPos_comIp) {
                isServerRunningOnProfitGuruCloud = true;
            }
        });
        profitGuruPos_comIp = addresses;
    }
});

var licenceHelperSingleton = createSingleton(function licenceHelper() {
    var _self = this;
    var serverSerialNumber;
    var serverLicence;
    var serverMacs = [];
    var serverLicences = [];
    var hostIp;

    this.setServerLicence = function (serverLicence) {
        var decryptedServerLicence = _self.decryptLicence(serverLicence);
        serverLicences.push(decryptedServerLicence);
        if (serverLicences.length === 1) {
            serverSerialNumber = decryptedServerLicence.clientId;
            loadLicences();
            profitGuruStatusEvents.emit('ServerUUID_Available', serverSerialNumber);
        }
    };

    this.getCloudParams = function () {
        return serverLicences[0].cloudCouch;
    };

    this.generateServerLicence = function () {
        var defered = q.defer();
        if (_self.serverLicence) {
            defered.resolve(_self.serverLicence);
        } else {
            genLicenceSeed.genLicence(true).then(function (serverLicence) {
                _self.serverLicence = serverLicence;
                defered.resolve(_self.serverLicence);
            }).catch(function (reason) {
                console.log(reason);
                defered.reject(reason);
            });
        }
        return defered.promise;
    };

    this.getHostIp = function () {
        return _self.hostIp;
    };
    this.genAndProvideTrialLicence = function (appType, serverPort, bDistributor) {
        return apply4trialLicence.genAndProvideTrialLicence(appType, serverPort, bDistributor);
    };
    this.getServerSerialNum = function () {
        return serverSerialNumber;
    };

    this.AuthorizedClientsMap = new HashMap();
    this.AuthorizedClientsMapByMac = {};

    this.AppliedClientsMap = new HashMap();
    this.AppliedClientsMapByMac = new HashMap();

    this.getAllClientsList = function () {

        var clientsList = {
            authorized: [],
            applied: [],
            serverSerialNumber: serverSerialNumber
        };

        _self.AuthorizedClientsMap.forEach(function (value, key) {
            var thisLicence = {
                clientId: key,
                licenceInfo: value
            };
            clientsList.authorized.push(thisLicence);
        });

        _self.AppliedClientsMap.forEach(function (value, key) {
            //if (!_self.AuthorizedClientsMap.get(key)) {
            var thisLicence = {
                clientId: key,
                licenceInfo: value
            };
            clientsList.applied.push(thisLicence);
            //}
        });

        return clientsList;
    };

    this.numberOfDaysLeft4LicenceExpiry = function (licence, callBack) {
        try {
            licence = JSON.parse(licence);
            var isvalidClient = {};
            var decLicence = _self.decryptLicence(licence);
            var storedLicence = _self.AuthorizedClientsMap.get(decLicence.clientId);
            var first = serverMacs.indexOf(storedLicence.macs[0]) >= 0;
            var today = new Date();
            var licStartDate = new Date(storedLicence.licStartDate);
            var totDays = getValidDays(licStartDate);
            callBack(storedLicence.validity - totDays);
        } catch (e) {
            console.log('Could not get Days left for Licence Expiry:', e);
            callBack();
        }

    };

    let awsTimeStamp = parseInt(moment().format('x'));
    let refAWSTimeStamp = parseInt(moment().format('x'));
    this.setCloudTime = function (timeStamp) {
        logger.info('Cloud Timestamp received<' + timeStamp + '>');
        awsTimeStamp = parseInt(timeStamp);
        refAWSTimeStamp = parseInt(moment().format('x'));
    };

    function getValidDays(licStartDate) {
        let isLicenceIsValid2Day = moment(getCurrentTime()).diff(licStartDate, 'days');
        return isLicenceIsValid2Day;
    }

    function getCurrentTime() {
        let delta = moment().diff(moment(refAWSTimeStamp));
        if (delta < 0) {
            logger.error('System Time Changed. Restart Server.');
            return awsTimeStamp + 7 * 24 * 60 * 60 * 1000; //adding 7 days
        }

        return awsTimeStamp + delta;
    }

    this.isLicencedProfitGuruClient = function (clientMac) {
        var result = {
            isLicenced: false,
            hasApplied: false
        };

        if (isServerRunningOnProfitGuruCloud) {
            return {
                isLicenced: true,
                hasApplied: false
            };
        } else {
            try {
                var storedLicence = getStoredLicence(clientMac);
                if (storedLicence) {
                    var today = new Date();
                    var licStartDate = new Date(storedLicence.licStartDate);
                    var isLicenceIsValid2Day = getValidDays(licStartDate);
                    if (serverSerialNumber === storedLicence.serverSerialNumber && isLicenceIsValid2Day < storedLicence.validity) {
                        result.isLicenced = true;
                        return result;
                    }
                } else {
                    if (hasThisClientBeenGivenTrialLicence(clientMac)) {
                        result.hasApplied = true;
                    }
                    return result;
                }

                logger.error('not expected to come here');
                return result;
            } catch (e) {
                logger.error('Error while parsing the licence');
                logger.error(e);
                throw e;
            }
        }
    };

    this.isLicencedClient = function (clientMac) {
        var defered = q.defer();
        try {
            var storedLicence = getStoredLicence(clientMac);
            var today = new Date();
            var licStartDate = new Date(storedLicence.licStartDate);
            var isLicenceIsValid2Day = getValidDays(licStartDate);
            if (serverSerialNumber == storedLicence.serverSerialNumber && isLicenceIsValid2Day < storedLicence.validity) {
                defered.resolve(true);
            } else {
                defered.reject('Inavlid Client');
            }
        } catch (e) {
            console.log('Error while parsing the licence:', e);
            defered.reject(e);
        }
        return defered.promise;

    };

    this.validateDeskTopClientLicence = function (clientMac) {
        var defered = q.defer();
        try {
            var storedLicence = getStoredLicence(clientMac);
            var today = new Date();
            var licStartDate = new Date(storedLicence.licStartDate);
            var isLicenceIsValid2Day = getValidDays(licStartDate);
            if (serverSerialNumber == storedLicence.serverSerialNumber && isLicenceIsValid2Day < storedLicence.validity) {
                defered.resolve(true);
            } else {
                defered.reject('Inavlid Client');
            }
        } catch (e) {
            console.log('Error while parsing the licence:', e);
            defered.reject(e);
        }
        return defered.promise;

    };

    //Validating Mobile apps
    this.validateMobileAppClientLience = function (deviceInfo, clientMac) {

        var defered = q.defer();
        try {
            deviceInfo = JSON.parse(deviceInfo);
            deviceInfo = deviceInfo.device;
            var storedLicence = _self.AuthorizedClientsMap.get(deviceInfo.uuid);

            var today = new Date();
            var licStartDate = new Date(storedLicence.licStartDate);
            var isLicenceIsValid2Day = getValidDays(licStartDate);

            if (typeof storedLicence != "undefined") {
                if (storedLicence.macs[0] == clientMac && storedLicence.serverSerialNumber == serverSerialNumber && deviceInfo.uuid == storedLicence.uuid && isLicenceIsValid2Day < storedLicence.validity) {
                    defered.resolve(true);
                } else {
                    defered.reject('Invalid Client');
                }
            } else {
                defered.reject('Invalid Client');
            }
        } catch (e) {
            console.log('Error while parsing the licence:', e);
            defered.reject(e);
        }
        return defered.promise;
    };

    this.decryptLicence = function (thisEncLicence) {

        var decipher, decLicence;
        if (thisEncLicence.candClientId) {
            decipher = crypto.createDecipher(algorithm, thisEncLicence.candClientId);
            decLicence = decipher.update(thisEncLicence.enDeviceInfo, 'hex', 'utf8');
        } else if (thisEncLicence.clientId) {
            decipher = crypto.createDecipher(algorithm, thisEncLicence.clientId);
            decLicence = decipher.update(thisEncLicence.enlicence, 'hex', 'utf8');
        } else {
            console.log('No Id for licence decryption');
        }

        decLicence += decipher.final('utf8');
        decLicence = JSON.parse(decLicence);
        return decLicence;
    };

    // profitGuruStatusEvents.on('ServerUUID_Available', function() {
    //     loadLicences();
    // });

    function loadLicences() {
        _self.prepareAppliedClientMap();
        _self.prepareAuthorizedClientMap();
    }
    let isLicenceExist = "";

    this.prepareAuthorizedClientMap = function () {
        licenceCouchHandler.prepareAuthorizedClientMap().then(function (licenceList) {
            // console.log(licenceList);
            if (licenceList) {
                licenceList.forEach(function (oneLicence) {
                    var decOneLicence = _self.decryptLicence(oneLicence.key);
                    decOneLicence.clientType = oneLicence.key.clientType;
                    _self.AuthorizedClientsMap.set(oneLicence.key.clientId, decOneLicence);

                    // if (decOneLicence.clientType === 'DeskTopApp') {
                    for (var i = 0; i < decOneLicence.macs.length; ++i) {
                        let pgMAC = getPGMAC(decOneLicence.macs[i]);
                        _self.AuthorizedClientsMapByMac[pgMAC] = decOneLicence;
                    }
                    if (!isLicenceExist && !decOneLicence.isTrial && decOneLicence.clientType === 'DeskTopApp' && _self.isLicencedProfitGuruClient(oneLicence.key.clientId)) {
                        isLicenceExist = oneLicence.key.clientId.replace(/-/g, "");
                    }
                    //}
                });
            }
            profitGuruStatusEvents.emit('PGuruLicencesLoadedInMem');
            licenceCouchHandler.listenToChanges(_self.prepareAuthorizedClientMap);
        });
    };

    this.prepareAppliedClientMap = function (appType) {
        licenceCouchHandler.prepareAppliedClientMap().then(function (appliedLicenceList) {
            if (appliedLicenceList) {
                appliedLicenceList.forEach(function (oneLicence) {
                    var decOneLicence = _self.decryptLicence(oneLicence.key);
                    decOneLicence.clientType = oneLicence.key.clientType;
                    _self.AppliedClientsMap.set(oneLicence.key.candClientId, decOneLicence);

                    //if (decOneLicence.clientType === 'DeskTopApp') {
                    for (var i = 0; i < decOneLicence.macs.length; ++i) {
                        _self.AppliedClientsMapByMac.set(decOneLicence.macs[i], decOneLicence);
                    }
                    //}
                });
            }
        });
    };

    this.encrypt = function (text, password) {
        var cipher = crypto.createCipher(algorithm, password);
        var crypted = cipher.update(text, 'utf8', 'hex');
        crypted += cipher.final('hex');
        return crypted;
    };

    this.amIAuthorized2Connect = function (appType, clientMac) {
        var result = {
            hasApplied: false,
            isAuthorized: false,
            daysLeft4LicenceExpiry: -1,
            isTrial: false,
            allowAccess: false,
            clientId: clientMac
        };

        if (isServerRunningOnProfitGuruCloud) {
            return {
                hasApplied: true,
                isAuthorized: true,
                daysLeft4LicenceExpiry: 100,
                isTrial: false,
                allowAccess: true
            };
        } else {
            var storedLicence;
            try {

                storedLicence = getStoredLicence(clientMac);

                if (typeof storedLicence !== "undefined") {
                    var today = new Date();
                    var licStartDate = new Date(storedLicence.licStartDate);
                    var noOfUsedDays = getValidDays(licStartDate);

                    result.daysLeft4LicenceExpiry = storedLicence.validity - noOfUsedDays;

                    if (result.daysLeft4LicenceExpiry > 0) {
                        result.isAuthorized = true;
                        result.hasApplied = true;
                    } else {
                        result.isAuthorized = true;
                        result.hasApplied = true;
                    }

                    if (storedLicence.isTrial) {
                        result.isTrial = true;
                    } else {
                        result.isTrial = false;
                    }

                    if (storedLicence.allowAccess) {
                        result.allowAccess = true;
                    }

                    return result;
                } else {
                    //IMP** sometime I see these maps not getting properly updated so, loading them here once again
                    //
                    var clientInfo = {
                        mac: clientMac
                    };
                    if (isLicenceAlreadyApplied4ThisClient(clientInfo)) {
                        result.hasApplied = true;
                    }
                    return result;
                }

            } catch (e) {
                console.log(e);
                throw new Error(e);
            }
        }
    };

    function hasThisClientBeenGivenTrialLicence(clientMac) {
        return _self.AppliedClientsMapByMac.get(clientMac);
    };

    function isLicenceAlreadyApplied4ThisClient(clientInfo) {
        //Now validation is only by macAddress
        // return _self.AppliedClientsMapByMac.get(clientInfo.mac) || _self.AppliedClientsMap.get(clientInfo.clientId);
        return _self.AppliedClientsMapByMac.get(clientInfo.mac);
    }

    this.apply4Licence = function (clientMac, appType, deviceInfo, clientType, isLocalHostClient, isTrial, callBack) {

        //try {
        var defered = q.defer();
        var dbObject2Insert = {};
        var result = {
            isApplied: false,
            hasAlreadyApplied: false
        };
        var clientInfo = {
            mac: clientMac,
            clientId: ""
        };

        if (clientType == "MobileApp") {
            clientInfo.clientId = deviceInfo.uuid;
            if (isLicenceAlreadyApplied4ThisClient(clientInfo)) {
                result.hasAlreadyApplied = true;
                defered.resolve(result);
            } else {
                dbObject2Insert.macs = [clientMac];
                deviceInfo.macs = [clientMac];
                deviceInfo.allowAccess = false;
                deviceInfo.isTrial = isTrial;
                dbObject2Insert.candClientId = deviceInfo.uuid;
                dbObject2Insert.clientType = clientType;
                dbObject2Insert.allowAccess = false
                dbObject2Insert.isLocalHostClient = false;
                dbObject2Insert.enDeviceInfo = _self.encrypt(JSON.stringify(deviceInfo), deviceInfo.uuid);

            }

        } else if (clientType == "DeskTopApp") {

            clientInfo.clientId = deviceInfo.clientId;
            if (isLicenceAlreadyApplied4ThisClient(clientInfo)) {
                result.hasAlreadyApplied = true;
                defered.resolve(result);
            } else {
                dbObject2Insert.candClientId = deviceInfo.clientId;
                dbObject2Insert.clientType = clientType;
                dbObject2Insert.enDeviceInfo = deviceInfo.enlicence;
                dbObject2Insert.allowAccess = isLocalHostClient ? true : false;
                dbObject2Insert.isLocalHostClient = isLocalHostClient ? true : false;
                if (isLocalHostClient)
                    dbObject2Insert.allowAccess = true;
            }

        } else {
            console.log("Unknown app");
            result.error = "Unknown app Type";
            defered.reject(result);
        }

        licenceCouchHandler.licenceApplyCouchInsert(appType, dbObject2Insert).then(function (response) {
            defered.resolve(response);
        }).catch(function (reason) {
            defered.reject(reason);
        });

        return defered.promise;
    };

    this.prepareLicence = function (appType, client2Provision, validity, isLocalHostClient) {
        client2Provision.validity = validity;
        client2Provision.clientId = client2Provision.candClientId;
        delete client2Provision.candClientId;
        client2Provision.enlicence = client2Provision.enDeviceInfo;
        delete client2Provision.enDeviceInfo;
        decLicence = _self.decryptLicence(client2Provision);
        decLicence.validity = validity;
        decLicence.allowAccess = isLocalHostClient ? true : false;
        decLicence.isLocalHostClient = isLocalHostClient ? true : false;
        decLicence.serverSerialNumber = serverSerialNumber;
        decLicence.licStartDate = new Date().toString();
        client2Provision.enlicence = _self.encrypt(JSON.stringify(decLicence), client2Provision.clientId);
        return client2Provision;
        //licenceCouchHandler.licenceProvisionCouchInsert(appType, client2Provision, callBack);
    };
    this.provisionLicence = function (appType, clientId, validity, isLocalHostClient) {
        var defered = q.defer();
        var licProvsnResult = {
            hasAlreadyProvisioned: false,
            isProvisioned: false
        };
        var client2Provision;
        licenceCouchHandler.getAppliedLicenceInfo4thisClient(appType, clientId).then(function (appliedLicence) {
            client2Provision = _self.prepareLicence(appType, appliedLicence, validity, isLocalHostClient);
            return licenceCouchHandler.licenceProvisionCouchInsert(appType, client2Provision);
        }).then(function (licProvsnResult) {
            defered.resolve(licProvsnResult);
        }).catch(function (reason) {
            console.log(reason);
            defered.reject(reason);
        });

        return defered.promise;
    };
    var m_allowAccess2client = function (client2AllowAccess, access) {
        var decLicence = _self.decryptLicence(client2AllowAccess);
        decLicence.allowAccess = access;
        client2AllowAccess.enlicence = _self.encrypt(JSON.stringify(decLicence), client2AllowAccess.clientId);
        return client2AllowAccess;
    };
    this.allowAccess2client = function (appType, clientId, validity, access) {
        var defered = q.defer();
        var allowAccessResult = {
            isAccessAllowed: false
        };
        var client2AllowAccess;
        licenceCouchHandler.getAuthorizedLicenceInfo4thisClient(appType, clientId).then(function (appliedLicence) {
            client2AllowAccess = m_allowAccess2client(appliedLicence, access);
            if (access === true) {

                return licenceCouchHandler.grantClientAccessCouchInsert(appType, client2AllowAccess);
            } else {
                return licenceCouchHandler.revokeClientAccessCouchInsert(appType, client2AllowAccess);
            }
        }).then(function (allowAccessResult) {
            defered.resolve(allowAccessResult);
        }).catch(function (reason) {
            console.log(reason);
            defered.reject(reason);
        });

        return defered.promise;
    };
    this.requestLicenceActivation = function (appType, clientId) {
        var defered = q.defer();
        var allowAccessResult = {
            isAccessAllowed: false
        };
        var client2AllowAccess;
        licenceCouchHandler.getAppliedLicenceInfo4thisClient(appType, clientId).then(function (appliedLicence) {
            const moment = require('moment');
            var timeStamp = moment().valueOf();
            appliedLicence.Activate = {
                bAcivate: true,
                timestamp: timeStamp
            };

            licenceCouchHandler.licenceActiveRequestInsert(appType, appliedLicence);
        }).then(function (activateRequestResults) {
            defered.resolve(activateRequestResults);
        }).catch(function (reason) {
            console.log(reason);
            defered.reject(reason);
        });

        return defered.promise;
    };

    this.loadHostAndProfitGuruPos_comIps = function () {
        dns.lookup('alienhu.com', function (err, addresses, family) {
            if (err) {
                console.log('Could not find The IpAddress for alienhu.com');
            } else {
                profitGuruPos_comIp = addresses;
            }
            _self.hostIp = ip.address();
        });

    };

    this.isNodeSvcRunningOnProfitGuruPos = function () {
        if (!_self.hostIp) {
            _self.hostIp = ip.address();
        }
        //_self.hostIp = 127.0.0.1  when not connected to internet
        return (_self.hostIp !== '127.0.0.1' && _self.hostIp === profitGuruPos_comIp);

    };

    function getPGMAC(mac) {
        let pgMAC = mac.toLowerCase();
        pgMAC = pgMAC.replace(/\-/g, '');
        pgMAC = pgMAC.replace(/\:/g, '');
        return pgMAC;
    }

    function getStoredLicence(mac) {
        let pgMAC = getPGMAC(mac);
        if (isLicenceExist) {
            pgMAC = isLicenceExist;
        }
        return _self.AuthorizedClientsMapByMac[pgMAC];
    }

    this.isPrivateProfitGuruPosNodeSvc = function () {

        if (!_self.hostIp) {
            _self.hostIp = ip.address();
        }
        //_self.hostIp = 127.0.0.1  when not connected to internet
        return (_self.hostIp === '127.0.0.1' || _self.hostIp !== profitGuruPos_comIp);

    };

    var profitGuruStatusEvents = require('../common/profitGuruStatusEvents.js');
    profitGuruStatusEvents.on('connected2LAN', function () {
        _self.hostIp = ip.address();
    }).on('notConnected2LAN', function () {
        _self.hostIp = ip.address();
    });

});

module.exports = new licenceHelperSingleton();