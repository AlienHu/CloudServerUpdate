"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const couchDBApis = require("../TSCouchDB/Common/couchDBApis");
const dbInstanceHelper_1 = require("../TSCouchDB/Common/dbInstanceHelper");
const crypto = require("../controllers/libraries/crypto");
const changesUtil_1 = require("../TSCouchDB/Common/changesUtil");
const dbInstanceHelper_2 = require("../TSCouchDB/Common/dbInstanceHelper");
const logger = require("../common/Logger");
exports.createOrUpdate = (dbContext, doc, reTryCount, errMsg) => __awaiter(this, void 0, void 0, function* () {
    let licence = {
        _id: doc._id,
        allowAccess: doc.allowAccess,
        clientId: doc.clientId,
        clientType: doc.clientType,
        isLocalHostClient: doc.isLocalHostClient,
        isTrial: doc.isTrial,
        licStartDate: doc.licStartDate,
        validity: doc.validity,
        macArray: doc.macArray,
        enlicence: crypto.encrypt(doc)
    };
    if (doc._rev) {
        licence._rev = doc._rev;
    }
    yield couchDBApis.createOrUpdate(dbContext, licence, dbInstanceHelper_1.getLicenceDBInstance, reTryCount, errMsg);
    return;
});
exports.getDoc = (dbContext, docId) => __awaiter(this, void 0, void 0, function* () {
    let doc = yield couchDBApis.getDocEx(dbContext, docId, dbInstanceHelper_1.getLicenceDBInstance);
    let licence = exports.decrypt(doc);
    licence._rev = doc._rev;
    return licence;
});
function filterLicenceResp(liceArray) {
    let newLicenceArray = [];
    for (let i = 0; i < liceArray.length; i++) {
        if (liceArray[i].id.split('-').length < 2) {
            newLicenceArray.push(liceArray[i]);
        }
    }
    return newLicenceArray;
}
exports.getAllDocsByType = (dbContext) => __awaiter(this, void 0, void 0, function* () {
    let docArr = yield couchDBApis.getAllDocsByType(dbContext, 'licence', dbInstanceHelper_1.getLicenceDBInstance);
    docArr = filterLicenceResp(docArr);
    return docArr;
});
exports.decrypt = function (doc) {
    return crypto.decrypt(doc.enlicence);
};
exports.listenLicenceDocs = (dbContext) => {
    let listening = false;
    return function () {
        if (!listening) {
            listening = true;
            changesUtil_1.followChanges(dbInstanceHelper_2.getLicenceDBUrl(dbContext), 'licence', filterLicence, handleLicenceChange, dbContext);
        }
    };
};
exports.grantClientAccess = function (dbContext, clientId, bAllow) {
    return __awaiter(this, void 0, void 0, function* () {
        let message = bAllow ? 'grant' : 'revoke';
        try {
            let m_licence = yield exports.getDoc(dbContext, clientId);
            m_licence.allowAccess = bAllow;
            let resp = yield exports.createOrUpdate(dbContext, m_licence);
            return 'Access ' + message + ' Successfully ';
        }
        catch (e) {
            logger.error(e);
            return new Error('Failed to' + message + 'Access');
        }
    });
};
let filterLicence = (doc) => {
    if (doc._id.split('_')[0] === 'licence') {
        return true;
    }
    return false;
};
let handleLicenceChange = (change, dbContext) => __awaiter(this, void 0, void 0, function* () {
    if (change.deleted) {
        logger.error("Deleted licence, We will create again, ha.. ha.. ha ...");
        try {
            yield couchDBApis.createOrUpdate(dbContext, change.doc, dbInstanceHelper_1.getLicenceDBInstance);
        }
        catch (e) {
            logger.error(e);
        }
    }
});
//# sourceMappingURL=licenceDAO.js.map