require('errors');
//Shuould not be included in production release
var bodyParser = require('body-parser');
var demoEmployeeRoute = require('express').Router();

var profitGuruFaker = require('../test/common/profitGuruFaker.js');
var commonTestUtils = require('../test/common/commonUtils.js');

demoEmployeeRoute.use(bodyParser.urlencoded({
    extended: true
}));

demoEmployeeRoute.use(bodyParser.json());

demoEmployeeRoute.post('/', function(req, res) {
    var result = {
        message: 'Demo Employee Login Credentials'
    };

    var newEmployee4DemoLogin = profitGuruFaker.getFakerExpressUserCouchEmployee();
    newEmployee4DemoLogin.name = newEmployee4DemoLogin.name.toLowerCase();
    newEmployee4DemoLogin.password = newEmployee4DemoLogin.password.toLowerCase();
    commonTestUtils.createExpressUserCouchNewUserAuthenticatedRequest(req.app.get('rootApp'), newEmployee4DemoLogin).then(function() {
        result.userName = newEmployee4DemoLogin.name;
        result.password = newEmployee4DemoLogin.password;

        res.send(result);
        res.end();
    });

});

module.exports = demoEmployeeRoute;