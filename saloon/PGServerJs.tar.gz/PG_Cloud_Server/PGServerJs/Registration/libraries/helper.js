"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const controller = require("../controller");
const registrationHack = require("../../common/registrationHack");
const init_1 = require("../../init/init");
const logger = require("../../common/Logger");
const couchdb_1 = require("../../TSControllers/interfaces/couchdb");
exports.getRegistrationDoc = () => __awaiter(this, void 0, void 0, function* () {
    const registrationInfoArr = registrationHack(); //read from registrationName.json
    let registrationName = registrationInfoArr[0];
    let bNewRegistration = false;
    let registrationDoc;
    try {
        registrationDoc = yield controller.getRegistrationId(registrationName);
    }
    catch (error) {
        logger.error(error);
        logger.error('getRegistrationDoc. Proceeding Further.');
        if (["UNKNOWN", "EADDRINUSE"].indexOf(error.code) !== -1) {
            logger.error(error);
            throw error.error;
        }
        else if (couchdb_1.COUCH_FAILED_NO_INTERNET_CODES.indexOf(error.code) !== -1) {
            //no internet
            if (!registrationInfoArr[1]) {
                throw 'Internet is must for setup. Try Again Later.';
            }
            else {
                registrationDoc = {
                    _id: registrationInfoArr[1],
                    name: registrationInfoArr[0],
                    ip: ''
                };
                yield init_1.init(registrationDoc._id);
            }
        }
        else {
            bNewRegistration = true;
            if (registrationInfoArr[1]) {
                logger.info('getRegistrationDoc::Not expected to come here. But proceeding by doing some hack');
                logger.info('Registration Name<' + registrationInfoArr[0] + '> Registration Id<' + registrationInfoArr[1] + '> Some problem.');
                throw 'getRegistrationDoc::Not expected to come here.';
                // registrationName = moment().format('x');
                // registrationInfoArr[1] = '';
            }
        }
    }
    if (bNewRegistration) {
        registrationDoc = yield controller.register({
            name: registrationName,
            ip: ''
        }).catch((error) => {
            throw 'Registration Failed';
        });
    }
    if (!registrationInfoArr[1]) {
        registrationHack(registrationDoc);
    }
    return registrationDoc;
});
//# sourceMappingURL=helper.js.map