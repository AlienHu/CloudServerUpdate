var express = require('express');
var router = express.Router();
var reportEmailController = require('../controllers/SendReportEmail');
var receiptEmailController = require('../controllers/sendRceiptEmail');
var licenceEmailController = require('../controllers/sendLicenceEmail');
var licanceController = require('../controllers/licence.js');
var sendSMS = require('../sms/sms');

router.put('/sendLicenceEmail', function(req, res) {
    var requestData = req.body;
    return licanceController.activationRequest(requestData.data.clientId).then(function(resp) {
        return licenceEmailController(requestData);
    }).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        var errResponse = {}
        errResponse.error = {};
        errResponse.error = reason;
        if (reason.code === 'ECONNECTION') {
            reason.error = "Apply Licence Failed , Check your Internet Connection";
            errResponse.error.message = "Apply Licence Failed , Check your Internet Connection";
        }
        errResponse = JSON.stringify(errResponse);
        res.send(new Error(errResponse));
        res.end();
    });
});

router.put('/sendEmailApi', function(req, res) {
    var requestData = req.body;

    return reportEmailController(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        var errResponse = {}
        errResponse.error = {};
        errResponse.error = reason;
        if (reason.code === 'ECONNECTION') {
            reason.error = "Sending Email Failed , Check your Internet Connection";
            errResponse.error.message = "Sending Email Failed , Check your Internet Connection";
        }
        errResponse = JSON.stringify(errResponse);
        res.send(new Error(errResponse));
        res.end();
    });
});

router.put('/sendReceiptEmail', function(req, res) {
    var requestData = req.body;

    return receiptEmailController(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        var errResponse = {}
        errResponse.error = {};
        errResponse.error = reason;
        if (reason.code === 'ECONNECTION') {
            reason.error = "Sending Email Failed , Check your Internet Connection";
            errResponse.error.message = "Sending Email Failed , Check your Internet Connection";
        }
        errResponse = JSON.stringify(errResponse);
        res.send(new Error(errResponse));
        res.end();
    });
});

router.put('/sendSMS', function(req, res) {
    return sendSMS(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(err) {
        res.send(err);
        res.end();
    });
});

module.exports = router;