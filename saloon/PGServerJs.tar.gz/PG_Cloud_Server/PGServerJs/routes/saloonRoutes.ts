import * as express from 'express';

let router = express.Router();
import { postAppointment, putAppointment, getAllAppointments, getAppointmentById } from '../controllers/Appointment';

router.post('/addAppointment', async function (req, res) {
    let appointmentData = req.body;
    // console.log('requestData', appointmentData);
    // console.log('req req req', req);
    try {
        let response = await postAppointment(appointmentData);
        console.log("========response=============", response);
        res.send(response);
    }
    catch (reason) {
        console.log("========reason=============", reason);
        res.send(reason);
        res.end();
    }
});

router.put('/addAppointment', async function (req, res) {
    let appointmentData = req.body;
    // console.log('requestData', appointmentData);
    // console.log('req req req', req);
    try {
        let response = await putAppointment(appointmentData);
        console.log("====================response======================", response)
        res.send(response);
    }
    catch (reason) {
        console.log("====================reason======================", reason)
        res.send(reason);
        res.end();
    }
});

router.get('/getAllAppointments', async function (req, res) {
    try {
        let response = await getAllAppointments();
        res.send(response);
    }
    catch (reason) {
        res.send(reason);
        res.end();
    }
});

router.post('/getAppointmentById', async function (req, res) {
    try {
        let response = await getAppointmentById(req.body.id);
        res.send(response);
    }
    catch (reason) {
        res.send(reason);
        res.end();
    }
});


module.exports = router;
