var crmController = require('../controllers/crm');
var bodyParser = require('body-parser');
require('errors');
var router = require('express').Router();
router.use(bodyParser.urlencoded({
    extended: true
}));
router.use(bodyParser.json());

//http://racksburg.com/choosing-an-http-status-code/

router.post('/create', function(req, res, next) {
    var campaign = req.body;
    campaign.type = "cmp_";
    crmController.createCampaign(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

router.put('/update', function(req, res, next) {
    var campaign = req.body;
    campaign.type = "cmp_";
    crmController.updateCampaign(campaign).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

router.delete('/delete', function(req, res, next) {
    var campaign = req.body;
    campaign.type = "cmp_";
    crmController.deleteCampaign(campaign).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

router.post('/createSchedule', function(req, res, next) {
    var schedule = req.body;
    schedule.type = "schedule_";
    crmController.createSchedule(schedule).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});
router.post('/updateSchedule', function(req, res, next) {
    var schedule = req.body;
    schedule.type = "schedule_";
    crmController.updateSchedule(schedule).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

// use this api for create/update/delete
router.post('/crmTemplate', function(req, res, next) {
    var template = req.body;
    crmController.updateTemplateType(template).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

// use this api for create/update/delete
router.post('/visit', function(req, res, next) {
    var visit = req.body;
    crmController.visit(visit).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

// use this api for create/update/delete
router.post('/wisher', function(req, res, next) {
    var wisher = req.body;
    crmController.saveWisher(wisher).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

module.exports = router;