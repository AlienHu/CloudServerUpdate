var controller = require('../controllers/Tables.js');
var bodyParser = require('body-parser');
require('errors');
var router = require('express').Router();
router.use(bodyParser.urlencoded({
    extended: true
}));
router.use(bodyParser.json());

//http://racksburg.com/choosing-an-http-status-code/

router.post('/createTableRestApi', function(req, res, next) {
    controller.createTable(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

//TODO Ganesh delete method should be changed to delete ; we shouldnt use post for deleting
router.post('/deleteTableApiRestApi', function(req, res, next) {
    controller.deleteTable(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.get('/get', function(req, res, next) {
    controller.getTables(req.body.data).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

module.exports = router;