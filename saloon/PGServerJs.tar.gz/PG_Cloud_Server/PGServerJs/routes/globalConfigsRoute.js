var express = require('express');
var router = express.Router();
var controller = require('../controllers/GlobalConfigurations');
var variantsController = require('../controllers/Variants');

router.post('/createCategory', function(req, res) {
    var requestData = req.body;

    controller.createCategory(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.put('/updateCategory', function(req, res) {
    var requestData = req.body;

    controller.updateCategory(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.delete('/deleteCategory', function(req, res) {
    var requestData = req.body;

    controller.deleteCategory(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.post('/createDiscount', function(req, res) {
    var requestData = req.body;

    controller.createDiscount(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.put('/updateDiscount', function(req, res) {
    var requestData = req.body;

    controller.updateDiscount(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.delete('/deleteDiscount', function(req, res) {
    var requestData = req.body;

    controller.deleteDiscount(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.post('/createUnit', function(req, res) {
    var requestData = req.body;

    controller.createUnit(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.put('/updateUnit', function(req, res) {
    var requestData = req.body;

    controller.updateUnit(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.delete('/deleteUnit', function(req, res) {
    var requestData = req.body;

    controller.deleteUnit(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.post('/createTax', function(req, res) {
    var requestData = req.body;

    controller.createTax(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.put('/updateTax', function(req, res) {
    var requestData = req.body;

    controller.updateTax(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.delete('/deleteTax', function(req, res) {
    var requestData = req.body;

    controller.deleteTax(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.post('/createCharge', function(req, res) {
    var requestData = req.body;

    controller.createCharge(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.put('/updateCharge', function(req, res) {
    var requestData = req.body;

    controller.updateCharge(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.delete('/deleteCharge', function(req, res) {
    var requestData = req.body;

    controller.deleteCharge(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.post('/createSlab', function(req, res) {
    var requestData = req.body;

    controller.createSlab(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.put('/updateSlab', function(req, res) {
    var requestData = req.body;

    controller.updateSlab(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.delete('/deleteSlab', function(req, res) {
    var requestData = req.body;

    controller.deleteSlab(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.post('/createProfile', function(req, res) {
    var requestData = req.body;

    controller.createProfile(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.put('/updateProfile', function(req, res) {
    var requestData = req.body;

    controller.updateProfile(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.delete('/deleteProfile', function(req, res) {
    var requestData = req.body;

    controller.deleteProfile(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.post('/createLoyality', function(req, res) {
    var requestData = req.body;

    controller.createLoyality(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.put('/updateLoyality', function(req, res) {
    var requestData = req.body;

    controller.updateLoyality(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.delete('/deleteLoyality', function(req, res) {
    var requestData = req.body;

    controller.deleteLoyality(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.post('/createBrand', function(req, res) {
    var requestData = req.body;

    controller.createBrand(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.put('/updateBrand', function(req, res) {
    var requestData = req.body;

    controller.updateBrand(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.delete('/deleteBrand', function(req, res) {
    var requestData = req.body;

    controller.deleteBrand(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.post('/createVariant', function(req, res) {
    var requestData = req.body;

    variantsController.create(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.put('/updateVariant', function(req, res) {
    var requestData = req.body;

    variantsController.update(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.delete('/deleteVariant', function(req, res) {
    var requestData = req.body;

    variantsController.delete(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason.msg));
        res.end();
    });
});

module.exports = router;