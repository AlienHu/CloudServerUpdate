 var urlParser = require('url');
 //This middleWare validates to check whether the user is allowed to make this profitGuru Api request.
 var HashMap = require('hashmap');
 var userWhiteListModulesSet = new HashMap();
 var UserApiMap = new HashMap();

 var path = require('path');
 var setClass = require('simplesets');

 var serverConfig = require(path.join(__dirname, '../../config', 'config.json'));
 //var defaultWhiteListApiList = ['/user/signin', '/user/signout', '/user/signup', '/core/profitGuruRestApis', '/core/profitGuruElements', '/licence/amiauthorized2connect'];
 var whiteListApis = [];
 serverConfig.defaultWhiteListApis.forEach(function(api, index) {
     whiteListApis.push(api.toLowerCase());
 });

 var whiteListModulesSet = new setClass.Set([]);
 serverConfig.defaultWhiteListModules.forEach(function(module, index) {
     whiteListModulesSet.add(module.toLowerCase());
 });

 function prepareUserApiList(username, usersAllEntitlements) {

     var userApisSet = new setClass.Set([]);
     var userModuleSet = new setClass.Set([]);
     var thisApi;
     for (var module in usersAllEntitlements) {
         if (usersAllEntitlements[module].allowAll) {
             if (module === 'takeAway' || module === 'tables') {
                 userModuleSet.add('sales');
             }

             userModuleSet.add(module.toLowerCase());

         }
         if (usersAllEntitlements[module].apis) {
             if ((usersAllEntitlements[module].viewOnMenu) && !usersAllEntitlements[module].allowNone) {
                 usersAllEntitlements[module].apis.forEach(function(api) {
                     if (module === 'tables') {
                         thisApi = '/takeAway/' + api;
                     } else {
                         thisApi = '/' + module + '/' + api;
                     }
                     userApisSet.add(thisApi.toLowerCase())
                 });
             }
         }

         for (var feature in usersAllEntitlements[module]) {

             if (typeof usersAllEntitlements[module][feature] === 'object') {
                 if (usersAllEntitlements[module][feature].apis) {
                     if ((usersAllEntitlements[module][feature].allowed || usersAllEntitlements[module].allowAll) && !usersAllEntitlements[module].allowNone) {

                         if (usersAllEntitlements[module][feature].common === undefined || usersAllEntitlements[module][feature].common === false) {
                             usersAllEntitlements[module][feature].apis.forEach(function(api) {
                                 if (module === 'tables') {
                                     thisApi = '/takeAway/' + api;
                                 } else {
                                     thisApi = '/' + module + '/' + api;
                                 }
                                 userApisSet.add(thisApi.toLowerCase())
                             });
                         }

                         if (usersAllEntitlements[module][feature].common === true) {
                             usersAllEntitlements[module][feature].apis.forEach(function(commonApi) {
                                 //todo : consider tables module ; for which api will have takeaway as module name 
                                 thisApi = commonApi + ':' + module;

                                 //example::thisApi /common/sendEmail:customer
                                 //This will avoid the need for creating duplicate routes
                                 userApisSet.add(thisApi.toLowerCase());

                             });
                         }
                     }

                 }
             }
         }

     }

     UserApiMap.set(username, userApisSet);
     userWhiteListModulesSet.set(username, userModuleSet);
 }

 function entitlementAuthorizer(whiteListApiList) {

     if (whiteListApiList) {
         whiteListApis.push(whiteListApiList);
     }

     return function entitlementAuthorizer(req, res, next) {

         var urlPath = urlParser.parse(req.url).pathname.toLowerCase();
         //to Remove / at the end of url, to get the match properly

         urlPath = urlPath.replace(/\/\s*$/, "");
         //  var commonType = urlPath.split(':');
         //  var commonTypeModule = commonType[1] ? commonType[1].toLowerCase() : '';
         var commonTypeModule = req.body.type ? req.body.type : (req.query.type ? req.query.type : '');
         var urlElements = urlPath.split('/');
         var moduleName = urlElements[1].toLowerCase();
         if (process.env.APP_TYPE === 'restaurant' && moduleName === 'sales') {
             urlPath = '/takeAway/' + urlElements[2];
         };
         urlPath = commonTypeModule !== '' ? (urlPath + ':' + commonTypeModule) : urlPath;
         urlPath = urlPath.toLowerCase();

         if (req.session.user !== undefined) {
             if (whiteListApis.indexOf(urlPath) >= 0 || whiteListModulesSet.has(moduleName)) {
                 return next(); //whitelisted Apis, No authentication needed
             } else {
                 //Lets validate the user is entitled to this Api
                 if (!UserApiMap.get(req.session.user.name) || !userWhiteListModulesSet.get(req.session.user.name)) {
                     prepareUserApiList(req.session.user.name, JSON.parse(req.session.user.roles[0]));
                 }
                 if (UserApiMap.get(req.session.user.name).has(urlPath) || userWhiteListModulesSet.get(req.session.user.name).has(moduleName)) {
                     //reset
                     if (urlElements.length > 2 && urlElements[1].toLowerCase() === 'employees') {
                         userWhiteListModulesSet = new HashMap();
                         UserApiMap = new HashMap();
                     }
                     return next();
                 } else {
                     res.send(new Error(moduleName + ' Entitlement Error: Module Is not permitted for you, Contact your Admin'));
                     res.end();
                 }
             }

         } else {
             //Passing whiteListApiList Api before signin
             return next();
         }
     };
 }

 module.exports = entitlementAuthorizer;