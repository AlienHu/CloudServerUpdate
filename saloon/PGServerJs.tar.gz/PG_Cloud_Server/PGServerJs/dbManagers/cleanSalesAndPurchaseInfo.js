require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .alias('s', 'cleanSalesInfo')
    .default('s', false)
    .alias('p', 'cleanPurchaseInfo')
    .default('p', false)
    .help('h')
    .alias('h', 'help')
    .argv;

var curSession = {};
var applicationSettings = {};
const logger = require('../common/Logger');
const couchDbManager = require('./couchDbManager');
// async function initProfitGuru() {
//     console.log("hello");
//     await couchDbManager.initCouchDb(false);
// }
// initProfitGuru();
async function resetSales(type) {
    try {
        // console.log('hello ==== ' + type);
        await couchDbManager.initCouchDb(false);
        const salesController = require('../controllers/Sales')(curSession, applicationSettings);
        let resp = await salesController.resetSalesInfo(type);
        logger.info('Sales Done!!');
    } catch (reason) {
        logger.error(reason);
        throw 'Sales Reset Failed';
    };
}

async function resetPurchase(type) {

    try {
        await couchDbManager.initCouchDb(false);
        const receivingsController = require('../controllers/Receivings')(curSession, applicationSettings);
        let resp = await receivingsController.resetPurchaseInfo(type);
        logger.info('Purchase Done!!');
    } catch (reason) {
        logger.error(reason);
        throw 'Purchase Reset Failed';
    };
}

let promisesArray = [];
let returnPromisesArray = [];

if (argv.s) {
    returnPromisesArray.push(resetSales('saleReturn'));
    promisesArray.push(resetSales('sale'));

}
if (argv.p) {
    returnPromisesArray.push(resetPurchase('receivingReturn'));
    promisesArray.push(resetPurchase('receiving'));

}

function cleanSalesandPurchase() {
    return Promise.all(promisesArray).then(function() {
        process.exit(0);
    });
}

return Promise.all(returnPromisesArray).then(function() {
    setTimeout(function() {
        cleanSalesandPurchase();
    }, 10000);
}).catch(function(error) {
    process.exit(1);
})
// .then(function() {
//     process.exit(0);
// }).catch(function(error) {
//     process.exit(1);
// });
// })
// .then(function() {

// })