'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDbManager = require('./couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const globalConfigController = require('../controllers/GlobalConfigurations');

var itemsArray = [];
var csv = require('csvtojson')
console.log("Hello ");
csv()
    .fromFile(__dirname + '/medTally.csv')
    .on('json', (jsonObj) => {
        itemsArray.push(jsonObj);
    })
    .on('done', (error) => {
        console.log(itemsArray.length);
        console.log('end');
        console.log(error);

        return run();
    });

async function createConfig(key) {
    let foo = '';
    if (key === 'Cat') {
        foo = 'createCategory';
    } else if (key === 'subCat') {
        foo = 'createSubCategory';
    }

    //process is to get unique config names
    let count = {};
    for (let i = 0; i < itemsArray.length; i++) {

        let configName = itemsArray[i][key];
        if (!configName) {
            //To ignore empty category/unit
            continue;
        }

        count[configName] = 1;
    }
    //here creating config
    let namesArray = Object.keys(count);
    for (let i = 0; i < namesArray.length; i++) {
        let info;
        if (key === 'Cat') {
            info = {
                name: namesArray[i],
                description: "Default Categories"
            };
        } else if (key === 'subCat') {
            info = {
                name: namesArray[i],
                description: "Default Categories"
            };
        }
        try {
            //create configtigoriesng cte
            await globalConfigController[foo](info);
        } catch (error) {
            console.log(namesArray[i] + ' already exist');
        }
    }
}

async function prepare() {
    await createConfig('Cat');
    await createConfig('subCat');
    // await createConfig('unit');

}

let categoryObj = {};
let unitObj = {};
let subCatObj = {};
async function getIds() {
    //tax, category, saleUnit, purchaseUnit
    let categoryArray = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
    let subCategoryArray = await couchDBUtils.getAllDocsByType('subCategory', mainDBInstance);
    let unitArray = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);
    for (let i = 0; i < categoryArray.length; i++) {
        categoryObj[categoryArray[i].doc.name] = categoryArray[i].doc.id;
    }
    for (let i = 0; i < unitArray.length; i++) {
        unitObj[unitArray[i].doc.name] = unitArray[i].doc.id;
    }
    for (let i = 0; i < subCategoryArray.length; i++) {
        subCatObj[subCategoryArray[i].doc.name] = subCategoryArray[i].doc.id;
    }

}

let requiredFields = ["name", "item_number", "hasMeasurementUnit", "isNewBatch", "rackId", "uniqueItemCode", "manufacturerId", "description", "purchasePrice", "sellingPrice", "mrp", "reorderLevel", "reorderQuantity", "is_serialized", "imeiCount", "isprepared", "issellable", "isbought", "hasExpiryDate", "conversionFactor", "discountId", "hasBatchNumber", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive", "hasVariants", "attributes", "ItemType", "hsn", "salesSlab", "purchaseSlab", "density", "quantity"];
let pgItemsArray = [];

async function createItemArray() {
    let itemController = require('../controllers/Items');
    let pgItem = {
        initialStock: [{}]
    };
    let prevCategory = "";

    for (let i = 0; i < itemsArray.length; i++) {

        itemsArray[i].is_serialized = "false";
        let uniqueDetails = [];

        if (uniqueDetails.length) {

            pgItem.initialStock[0].uniqueDetails = uniqueDetails;
            itemsArray[i].is_serialized = "true";
        }

        itemsArray[i].conversionFactor = "1";
        itemsArray[i].itemType = "Normal";
        for (let j = 0; j < requiredFields.length; j++) {

            let value = itemsArray[i][requiredFields[j]];

            if (["purchasePrice", "mrp", "sellingPrice", "manufacturerId", "rackId", "reorderLevel", "reorderQuantity", "imeiCount", "hsn", "density", "quantity"].indexOf(requiredFields[j]) > -1) {
                value = "0";
            } else if (["hasExpiryDate", "isNewBatch", "hasMeasurementUnit", "hasVariants", "hasBatchNumber", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive"].indexOf(requiredFields[j]) > -1) {
                value = "false";
            } else if (["item_number"].indexOf(requiredFields[j]) > -1) {
                value = "";
            }
            if (value === undefined) {
                value = "undefined";
            }

            if (parseFloat(value).toString() === value) {
                value = parseFloat(value);
            } else if (value.toLowerCase() === 'false') {
                value = false;
            } else if (value.toLowerCase() === 'true') {
                value = true;
            } else if (value.toLowerCase() === 'undefined') {
                value = undefined;
            }
            pgItem[requiredFields[j]] = value;
        }

        pgItem.attributes = [];
        pgItem.purchasePrice = parseFloat(itemsArray[i].Price);
        pgItem.quantity = parseFloat(itemsArray[i].quantity);
        pgItem.hasBatchNumber = true;
        pgItem.mrp = pgItem.purchasePrice;
        pgItem.sellingPrice = pgItem.purchasePrice + 1;
        // let quantityStringArray = pgItem.quantity;
        pgItem.initialStock[0].quantity = pgItem.quantity; //parseInt(quantityStringArray[0]);
        pgItem.initialStock[0].purchasePrice = pgItem.purchasePrice;
        pgItem.initialStock[0].mrp = pgItem.mrp;
        pgItem.initialStock[0].batchId = 1;
        pgItem.initialStock[0].sellingPrice = pgItem.sellingPrice;
        delete pgItem.quantity;
        if (itemsArray[i].Cat) {
            prevCategory = itemsArray[i].Cat;
        }
        pgItem.categoryId = categoryObj[prevCategory];
        pgItem.purchaseUnitId = unitObj[""];
        pgItem.sellingUnitId = unitObj[""];
        pgItem.subCategoryId = subCatObj[itemsArray[i].subCat];
        pgItemsArray.push(pgItem);
        try {
            await itemController.createItem(pgItem);
        } catch (error) {
            console.log(error);
        }

        if (uniqueDetails.length) {
            i = k - 1;
        }
    }
}

async function deleteType(type) {
    let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
    console.log(type + '<' + resp.length + '>');
    let bulkDocs = [];
    for (let i = 0; i < resp.length; i++) {
        resp[i].doc._deleted = true;
        bulkDocs.push(resp[i].doc);
    }

    if (bulkDocs.length) {
        await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
    }
}

async function run() {
    //mandatory to initialize the server -> equivalent to node bin/PGServerJs.js
    await couchDbManager.initCouchDb(true);

    await prepare();
    await getIds();
    await createItemArray();
    console.log('done');
    process.exit(0);
}

/**
 * serialnumber
 * units - pcs
 * categorys
 * name
 * quantity
 * mrp 0
 * selling price 0
 * purchase price
 * tax 18%
 * 
 * rest -> default value
 * 
 * 0. read the csv -- done
 * 1. categories -- done
 * 2. units -- done
 * 3. use isItem variable
 * 4. create item -> make the data -> create
 */