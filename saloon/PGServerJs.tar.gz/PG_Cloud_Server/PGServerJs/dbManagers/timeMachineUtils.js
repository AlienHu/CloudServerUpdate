'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDbManager = require('./couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();

async function run() {
    //false -- no db reset
    //true -- db reset
    await couchDbManager.initCouchDb(false);
    let testUtils = require('../test/common/commonUtils2');

    //To create customers 
    //100 customers are created below
    await testUtils.createElements('customer', {}, 100);

    //To create supplier
    //100 suppliers are created below
    await testUtils.createElements('supplier', {}, 100);

    //To create categories, slabs, taxes, .. (item mangagement)
    //for 1000 items few cat/slabs/taxes/dis are created
    //100 -- no of items
    await testUtils.preProcessItems(100);

    //To create items
    //100 items are created below
    await testUtils.createElements('item', {}, 100);

    //To make purchases
    //10 is number of purchases
    //1498144485000 is the start date (epoch time https://www.epochconverter.com/)
    //Takes time
    await testUtils.makeTransactions('receiving', 10, 1498144485000);


    //To make sales
    //10 is number of sales
    //1498144485000 is the start date (epoch time https://www.epochconverter.com/)
    //Takes time
    await testUtils.makeTransactions('sale', 100, 1498144485000);
}

run().then(() => {
    process.exit(0);
});