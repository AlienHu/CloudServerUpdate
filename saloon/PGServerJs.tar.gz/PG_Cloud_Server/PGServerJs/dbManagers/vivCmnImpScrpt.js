'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDbManager = require('./couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const globalConfigController = require('../controllers/GlobalConfigurations');
const variantController = require('../controllers/Variants.js');

var itemsArray = [];
var csv = require('csvtojson')
console.log("Hello ");
csv()
    .fromFile(__dirname + '/commonImportImportCSV.csv')
    // .fromFile('/home/ganesh/Downloads/restaurantItems.csv')
    .on('json', (jsonObj) => {
        itemsArray.push(jsonObj);
    })
    .on('done', (error) => {
        console.log(itemsArray.length);
        console.log('end');
        console.log(error);

        return run();
    });

async function createConfig(key) {
    let foo = '';
    let csvKey = key;
    if (key === 'category') {
        csvKey = 'Category';
        foo = 'createCategory';
    } else if (key === 'unit') {
        foo = 'createUnit';
    } else if (key == 'tax') {
        foo = 'createTax';
    }

    //process is to get unique config names
    let count = {};
    for (let i = 0; i < itemsArray.length; i++) {

        let configName = itemsArray[i][csvKey];
        if (!configName) {
            //To ignore empty category/unit
            continue;
        }

        count[configName] = 1;
    }
    //here creating config
    let namesArray = Object.keys(count);
    for (let i = 0; i < namesArray.length; i++) {
        try {
            //create configtigoriesng cte
            await globalConfigController[foo](taxes[i]);
        } catch (error) {
            console.log(namesArray[i] + ' already exist');
        }
    }
    for (let i = 0; i < namesArray.length; i++) {
        let info;
        if (key === 'category') {
            info = {
                name: namesArray[i],
                description: itemsArray[i]["description"]
            };
        }
        try {
            //create configtigoriesng cte
            await globalConfigController[foo](info);
        } catch (error) {
            console.log(namesArray[i] + ' already exist');
        }
    }
}

async function prepare() {
    await createConfig('category');
    await createConfig('unit');
    //create tax cess and gst 0
    await createConfig('tax');
    // await createConfig('variant');

}

let categoryObj = {};
let unitObj = {};
let taxObj = {};
let pProfileObj = {};
let defaultProfileId;
async function getIds() {
    //tax, category, saleUnit, purchaseUnit
    let categoryArray = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
    let unitArray = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);
    let taxArray = await couchDBUtils.getAllDocsByType('tax', mainDBInstance);
    if (hasUnitInfo) {
        let pProfileArray = await couchDBUtils.getAllDocsByType('pProfile', mainDBInstance);
        defaultProfileId = pProfileArray[0].doc.id;
    }
    for (let i = 0; i < categoryArray.length; i++) {
        categoryObj[categoryArray[i].doc.name] = categoryArray[i].doc.id;
    }
    for (let i = 0; i < unitArray.length; i++) {
        unitObj[unitArray[i].doc.name] = unitArray[i].doc.id;
    }
    for (let i = 0; i < taxArray.length; i++) {
        taxObj[taxArray[i].doc.name + '-' + taxArray[i].doc.percent] = taxArray[i].doc.id;
    }
}
//"bSPTaxInclusive":"TaxInclusive", "bPPTaxInclusive":"TaxInclusive" change as per requirement
let map = {
    "name": "Name",
    "item_number": "Barcode",
    "uniqueItemCode": "Item Code",
    "description": "Description",
    "purchasePrice": "Purchase Price",
    "sellingPrice": "Selling Price",
    "mrp": "MRP",
    "reorderLevel": "Reorder Level",
    "reorderQuantity": "Reorder Quantity",
    "is_serialized": "Is Serialized",
    "imeiCount": "IMEI",
    "isprepared": "Is Prepared",
    "issellable": "Is Sellable",
    "isbought": "Is bought",
    "hasExpiryDate": "Has ExpiryDate",
    "conversionFactor": "Conversion Factor",
    "discountId": "discountId",
    "hasBatchNumber": "Has BatchNumber",
    "bOTG": "OTG",
    "bSPTaxInclusive": "SP Tax Inclusive",
    "bPPTaxInclusive": "PP Tax Inclusive",
    "hasVariants": "Has Variants",
    "attributes": "Attributes",
    "ItemType": "Item Type",
    "hsn": "HSN",
    "salesSlab": "Sales Slab",
    "purchaseSlab": "Purchase Slab",
    "density": "Density",
    "quantity": "Quantity",
    "salesTaxGST": "GST Purchase Taxes%",
    "purchaseTaxGST": "SP Tax Inclusive%",
    "purchaseUnit": "Purchase Unit Name",
    "salesUnit": "Selling Unit Name"
}

//Column Names are different so handle it
let requiredFields = Object.keys(map);
let csvRequiredFields = Object.values(map);
let pgItemsArray = [];
let hasUnitInfo = false;
async function createItemArray() {
    let itemController = require('../controllers/Items');
    let pgItem = {
        initialStock: [{}]
    };
    let prevCategory = "";
    for (let i = 0; i < itemsArray.length; i++) {

        itemsArray[i][map.is_serialized] = "false";
        let uniqueDetails = [];

        if (uniqueDetails.length) {

            pgItem.initialStock[0].uniqueDetails = uniqueDetails;
            itemsArray[i][map.is_serialized] = "true";
        }

        pgItem.ItemType = itemsArray[i][map.ItemType];
        itemsArray[i][map.conversionFactor] = "1"; // make them enter

        for (let j = 0; j < requiredFields.length; j++) {

            let value = itemsArray[i][csvRequiredFields[j]];

            if (["purchasePrice", "mrp", "reorderLevel", "reorderQuantity", "imeiCount", "hsn", "density", "quantity"].indexOf(requiredFields[j]) > -1) {
                value = "0";
            } else if (["hasExpiryDate", "hasVariants", "hasBatchNumber", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive"].indexOf(requiredFields[j]) > -1) {
                value = "false";
            }
            // else if (["item_number"].indexOf(requiredFields[j]) > -1) {
            //     value = "";
            // }
            if (value === undefined) {
                value = "undefined";
            }
            if (parseFloat(value).toString() === value) {
                value = parseFloat(value);
            } else if (value.toLowerCase() === 'false') {
                value = false;
            } else if (value.toLowerCase() === 'true') {
                value = true;
            } else if (value.toLowerCase() === 'yes') {
                value = true;
            } else if (value.toLowerCase() === 'no') {
                value = false;
            } else if (csvRequiredFields[j] === 'TaxInclusive' && value === '') {
                //Only for TaxINclusive
                value = false;
            } else if (csvRequiredFields[j] === 'Purchase Price include Tax' && value === '') {
                value = false;
            } else if (csvRequiredFields[j] === 'Selling Price include Tax' && value === '') {
                value = false;
            } else if (value.toLowerCase() === 'undefined') {
                value = undefined;
            }
            pgItem[requiredFields[j]] = value;
        }

        pgItem.attributes = [];
        pgItem.hsn = itemsArray[i][map.hsn];
        pgItem.uniqueItemCode = itemsArray[i][map.uniqueItemCode];
        pgItem.item_number = itemsArray[i][map.item_number];
        pgItem.description = itemsArray[i][map.description];
        pgItem.quantity = parseFloat(itemsArray[i][map.quantity]);
        pgItem.bOTG = itemsArray[i].OTG == 'Yes' ? true : false;
        pgItem.hasBatchNumber = itemsArray[i].hasBatchNumber == 'Yes' ? true : false;

        //   //parseInt(quantityStringArray[0]);
        if (pgItem.bOTG) {
            pgItem.sellingPrice = 0;
        } else {
            pgItem.sellingPrice = parseFloat(itemsArray[i][map.sellingPrice]);
        }
        pgItem.mrp = parseFloat(itemsArray[i][map.mrp]);
        pgItem.purchasePrice = parseFloat(itemsArray[i][map.purchasePrice]);
        pgItem.initialStock[0].purchasePrice = pgItem.purchasePrice;
        pgItem.initialStock[0].sellingPrice = pgItem.sellingPrice;
        pgItem.initialStock[0].mrp = pgItem.mrp;
        if (pgItem.hasBatchNumber)
            pgItem.initialStock[0].batchId = itemsArray[i].BatchId;
        pgItem.initialStock[0].quantity = pgItem.quantity;
        delete pgItem.quantity;
        if (hasUnitInfo) {
            if (itemsArray[i][map.purchaseUnit]) {
                pgItem.purchaseUnitId = unitObj[itemsArray[i][map.purchaseUnit]];

            } else {
                pgItem.sellingUnitId = unitObj["Nos"];

            }
            if (itemsArray[i][map.salesUnit]) {
                pgItem.purchaseUnitId = unitObj[itemsArray[i][map.salesUnit]];

            } else {
                pgItem.purchaseUnitId = unitObj["Nos"];
            }
            let unitsInfo = {};
            let obj1 = {};
            let obj2 = {};
            obj1.refUnitId = pgItem.sellingUnitId;
            obj1.factor = 1;
            obj1.purchasePrice = pgItem.purchasePrice;
            obj1.mrp = pgItem.mrp;
            obj2.sellingPrice = pgItem.sellingPrice;
            unitsInfo[pgItem.sellingUnitId] = obj1;
            unitsInfo[pgItem.sellingUnitId].pProfilesData = {};
            unitsInfo[pgItem.sellingUnitId].pProfilesData[defaultProfileId] = obj2;
            pgItem.unitsInfo = {};
            pgItem.unitsInfo = unitsInfo;
            pgItem.initialStock[0].unitsInfo = {};
            pgItem.initialStock[0].unitsInfo = unitsInfo;
            pgItem.baseUnitId = pgItem.sellingUnitId;
            pgItem.defaultPurchaseUnitId = pgItem.purchaseUnitId;
            pgItem.defaultSellingUnitId = pgItem.sellingUnitId;
            console.log(unitsInfo);
        }

        if (itemsArray[i].Category) {
            prevCategory = itemsArray[i].Category;
        }

        pgItem.categoryId = categoryObj[prevCategory];
        if (!hasUnitInfo) {

            if (itemsArray[i][map.purchaseUnit]) {
                pgItem.purchaseUnitId = unitObj[itemsArray[i][map.purchaseUnit]];

            } else {
                pgItem.sellingUnitId = unitObj[""];

            }
            if (itemsArray[i][map.salesUnit]) {
                pgItem.purchaseUnitId = unitObj[itemsArray[i][map.salesUnit]];

            } else {
                pgItem.purchaseUnitId = unitObj[""];
            }
        }
        pgItem.salesTaxes = [];
        pgItem.purchaseTaxes = [];
        let gstSell = parseFloat(itemsArray[i][map.salesTaxGST]);
        if (!isNaN(gstSell)) {
            pgItem.salesTaxes.push(taxObj["GST-" + itemsArray[i][map.salesTaxGST]])
            pgItem.bSPTaxInclusive = itemsArray[i][map.bSPTaxInclusive] == 'Yes' ? true : false;
        }
        let gstPurchase = parseFloat(itemsArray[i][map.purchaseTaxGST]);
        if (!isNaN(gstPurchase)) {
            pgItem.purchaseTaxes.push(taxObj["GST-" + itemsArray[i][map.purchaseTaxGST]])
            pgItem.bPPTaxInclusive = itemsArray[i][map.bPPTaxInclusive] == 'Yes' ? true : false;
        }
        pgItemsArray.push(pgItem);
        try {
            await itemController.createItem(pgItem);
        } catch (error) {
            console.log(error);
        }

        if (true || i % 10 === 0) {
            console.log("I finished 10 <" + i + '>');
        }

        if (uniqueDetails.length) {
            i = k - 1;
        }
    }
}

async function deleteType(type) {
    let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
    console.log(type + '<' + resp.length + '>');
    let bulkDocs = [];
    for (let i = 0; i < resp.length; i++) {
        resp[i].doc._deleted = true;
        bulkDocs.push(resp[i].doc);
    }

    if (bulkDocs.length) {
        await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
    }
}
async function createVariant(json) {
    try {
        await couchDBUtils.create(json, mainDBInstance);
    } catch (err) {
        console.error('variant create failed: ' + JSON.stringify(json));
        console.error(err);
        throw err;
    }
}

async function run() {
    //mandatory to initialize the server -> equivalent to node bin/PGServerJs.js
    await couchDbManager.initCouchDb(true);
    await prepare();
    await getIds();
    await createItemArray();
    console.log('done');
    process.exit(0);
}

/**
 * serialnumber
 * units - pcs
 * categorys
 * name
 * quantity
 * mrp 0
 * selling price 0
 * purchase price
 * tax 18%
 * 
 * rest -> default value
 * 
 * 0. read the csv -- done
 * 1. categories -- done
 * 2. units -- done
 * 3. use isItem variable
 * 4. create item -> make the data -> create
 */

/**
 * createattribute -> variants.create
 get ids
 attribute []
 initialstock[]
 skuname, attributeinfo
 */