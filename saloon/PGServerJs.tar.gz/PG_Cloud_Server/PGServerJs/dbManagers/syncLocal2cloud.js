// let productionHost = '51.15.200.57';
// let trialHost = '51.15.133.206';
//aws '52.66.110.58'
//let cloudIp ="cloud ip"  //'51.15.200.57';
// trupti :20-e6-17-03-48-8c
//dpk 'd4-be-d9-52-c4-f7'
//vijay lakshmo 'a98c4530-d044-423d-869b-923cc3f13df0'
//ganesh 54-53-ed-23-c4-ef
//http://couchadmin:test@51.15.133.206:5984/pg_collection_cloud_retail_maindb_54-53-ed-23-c4-ef
let serverid = '54-53-ed-23-c4-ef'; //'3c-a9-f4-55-b9-2c';
let appName = 'retail'; //retail
let dbSufix = 'maindb';
let localDbName = 'pg_collection_' + appName + '_' + dbSufix;
let remoteDbName = 'pg_collection_cloud_' + appName + '_' + dbSufix + '_' + serverid;

return sync();

async function sync() {
    let nano = require('nano-blue')("http://couchadmin:test@127.0.0.1:5984");
    let nano1 = require('nano-blue')("http://couchadmin:test@" + cloudIp + ":5984");
    try {
        await nano1.db.destroy(localDbName);
    } catch (error) {
        console.log('Failed to delete local db');
    }

    // let syncCloudCouchUrl = 'http://couchadmin:test@' + cloudIp + ':5984/' + remoteDbName;
    let syncCloudCouchUrl = 'http://couchadmin:test@localhost' + ':5984/' + localDbName //remoteDbName;
    let localCouchUrl = 'http://couchadmin:test@' + cloudIp + ':5984/' + localDbName; //localDbName;

    await replicateDB(nano1, syncCloudCouchUrl, localCouchUrl);
}

function replicateDB(sourceCouchDdClient, sourceDBUrl, targetDBUrl) {
    return new Promise((resolve, reject) => {
        //couchdbClient.replicate('http://couchadmin:test@52.66.118.212:5984/profit_guru_licence', {
        sourceCouchDdClient.db.replicate(sourceDBUrl, targetDBUrl, {
                create_target: true
            },
            function(err, resp) {
                if (!err) {
                    console.log('couchDb', resp);
                    resolve(resp);
                } else {
                    console.log('Replcaition to cloud failed ', err);
                    reject(err);
                }
            });
    });
}