'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

let productionHost = '51.15.200.57';
let trialHost = '51.15.133.206';
let cloudIp = '51.15.200.57'; //51.15.200.57 //51.15.133.206 52.66.110.58

let appName = 'retail'; //retail restaurant
let serverid = '20-e6-17-03-48-8c';
let dbSufix = 'maindb';
let localDbName = 'pg_collection_' + appName + '_' + dbSufix;
if (dbSufix === '_users') {
    localDbName = dbSufix;
}
let remoteDbName = 'pg_collection_cloud_' + appName + '_' + dbSufix + '_' + serverid;

const couchDbManager = require('./couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();

importitems();
async function importitems() {
    await deleteType('item');
    await deleteType('category');
    await deleteType('unit');
    await deleteType('tax');
    await sync('all_items_data/item_import', false);
    console.log('replication completed');
    await deleteSupplier();
    console.log('deleting supplier completed');
    await makeStockZero();
    process.exit(0);
}

async function sync(filter, bDestroy) {
    let nano = require('nano-blue')("http://couchadmin:test@127.0.0.1:5984");

    if (bDestroy === undefined) {
        bDestroy = true;
    }

    if (bDestroy) {
        try {
            await nano.db.destroy(localDbName);
        } catch (error) {
            console.log('Failed to delete local db');
        }
    }

    let syncCloudCouchUrl = 'http://couchadmin:test@' + cloudIp + ':5984/' + remoteDbName;
    let localCouchUrl = 'http://couchadmin:test@localhost:5984/' + localDbName;

    await replicateDB(nano, syncCloudCouchUrl, localCouchUrl, filter, bDestroy);
}

function replicateDB(sourceCouchDdClient, sourceDBUrl, targetDBUrl, filter, bDestroy) {
    return new Promise((resolve, reject) => {
        //couchdbClient.replicate('http://couchadmin:test@52.66.118.212:5984/profit_guru_licence', {
        sourceCouchDdClient.db.replicate(sourceDBUrl, targetDBUrl, {
                create_target: bDestroy,
                filter: filter
            },
            function(err, resp) {
                if (!err) {
                    console.log('couchDb', resp);
                    resolve(resp);
                } else {
                    console.log('Replcaition to cloud failed ', err);
                    reject(err);
                }
            });
    });
}

async function deleteType(type) {
    let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
    console.log(type + '<' + resp.length + '>');
    let bulkDocs = [];
    for (let i = 0; i < resp.length; i++) {
        resp[i].doc._deleted = true;
        bulkDocs.push(resp[i].doc);
    }

    if (bulkDocs.length) {
        await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
    }
}

async function deleteSupplier() {
    let resp = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
    let bulkDocs = [];
    for (let i = 0; i < resp.length; i++) {
        resp[i].doc.info.supplier_id = undefined;
        bulkDocs.push(resp[i].doc);
    }

    if (bulkDocs.length) {
        await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
    }
}

async function makeStockZero() {
    let inventoryResp = await couchDBUtils.getAllDocsByType('inventory', mainDBInstance);
    console.log('inventory<' + inventoryResp.length + '>');
    let bulkDocs = [];
    for (let i = 0; i < inventoryResp.length; i++) {
        let inventoryDoc = inventoryResp[i].doc;
        let stockKey = Object.keys(inventoryDoc.stock)[0];
        inventoryDoc.stock[stockKey].quantity = 0;
        inventoryDoc.transactions = {};
        inventoryDoc.transactions['1510574251487_' + stockKey] = {
            "trans_date": 1510574251487,
            "trans_items": inventoryDoc.item_id,
            "trans_user": "admin",
            "trans_comment": "Initial Stock",
            "trans_inventory": 0,
            "trans_batchId": "",
            "trans_stockKey": stockKey
        }
        bulkDocs.push(inventoryDoc);
    }
    if (bulkDocs.length) {
        await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
    }
}

//"function(doc, req) {    var doctype, uidx;    if (doc._id && (uidx = doc._id.indexOf('_')) > 0) {        doctype = doc._id.substring(0, uidx);        if (doctype === 'item' || doctype === 'inventory' || doctype ==='category' || doctype ==='unit' || doctype ==='discount' || doctype ==='tax' || doctype ==='variant') {            return true;        }    }    return false;}"

//delete items
//delete supplier