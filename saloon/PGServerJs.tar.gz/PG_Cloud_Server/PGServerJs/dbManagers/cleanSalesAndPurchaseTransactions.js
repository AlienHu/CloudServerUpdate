require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .alias('s', 'cleanSalesInfo')
    .default('s', true)
    .alias('p', 'cleanPurchaseInfo')
    .default('p', true)
    .help('h')
    .alias('h', 'help')
    .argv;

var curSession = {};
var applicationSettings = {};
const logger = require('../common/Logger');
var couchDBUtils = require('../controllers/common/CouchDBUtils');

var mainDBInstance = couchDBUtils.getMainCouchDB();

async function cleanSales() {
    try {

        let inventoryDocs = await couchDBUtils.getAllDocsByType('inventory', mainDBInstance);
        let docsToUpdate = [];
        for (let j = 0; j < inventoryDocs.length; j++) {
            for (let trans in inventoryDocs[j].doc.transactions) {
                let type = inventoryDocs[j].doc.transactions[trans].trans_comment ? inventoryDocs[j].doc.transactions[trans].trans_comment.substring(0, 3) : '';
                if (type === 'POS') {
                    delete inventoryDocs[j].doc.transactions[trans];
                }
            }

            docsToUpdate.push(inventoryDocs[j].doc);
        }

        let saleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);

        if (saleDocs.length !== 0) {
            for (let i = 0; i < saleDocs.length; i++) {
                saleDocs[i].doc._deleted = true;
                docsToUpdate.push(saleDocs[i].doc);
            }
        }
        let updateResp = await couchDBUtils.bulkInsert(mainDBInstance, docsToUpdate);
        logger.info('Sales Done!!');
        return;
    } catch (error) {
        logger.error(error);
        throw 'ResetSalesInfo Failed';
    }
}

async function resetPurchaseInfo() {

    try {

        let inventoryDocs = await couchDBUtils.getAllDocsByType('inventory', mainDBInstance);
        let docsToUpdate = [];
        for (let j = 0; j < inventoryDocs.length; j++) {
            for (let trans in inventoryDocs[j].doc.transactions) {
                // console.log(inventoryDocs[j].doc.transactions[trans].trans_comment);trans_comment

                let type = inventoryDocs[j].doc.transactions[trans].trans_comment ? inventoryDocs[j].doc.transactions[trans].trans_comment.substring(0, 3) : '';
                if (j === 0) {
                    console.log(type === 'PUR');
                    // console.log(inventoryDocs[j].doc.transactions[trans]);
                }
                if (type === 'PUR') {
                    delete inventoryDocs[j].doc.transactions[trans];
                }
            }
            // console.log(inventoryDocs[0].doc);
            docsToUpdate.push(inventoryDocs[j].doc);
        }

        let receivingsDocs = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance);

        if (receivingsDocs.length !== 0) {
            for (let i = 0; i < receivingsDocs.length; i++) {
                receivingsDocs[i].doc._deleted = true;
                docsToUpdate.push(receivingsDocs[i].doc);
            }
        }
        let updateResp = await couchDBUtils.bulkInsert(mainDBInstance, docsToUpdate);
        logger.info('Purchase Done!!');
        return;
    } catch (error) {
        logger.error(error);
        throw 'Reset Purchase Failed';
    }
}

let promisesArray = [];
if (argv.s) {
    promisesArray.push(cleanSales());
}
if (argv.p) {
    console.log('hello');
    promisesArray.push(resetPurchaseInfo());
}

return Promise.all(promisesArray).then(function() {
        process.exit(0);
    }).catch(function(error) {
        process.exit(1);
    })
    // });