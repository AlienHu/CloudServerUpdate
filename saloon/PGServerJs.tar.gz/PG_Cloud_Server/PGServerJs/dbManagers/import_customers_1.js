(function () {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../.env',
        sample: __dirname + '/../env.example'
    });

    const couchDbManager = require('./couchDbManager');
    const couchDBUtils = require('../controllers/common/CouchDBUtils');
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const globalConfigController = require('../controllers/GlobalConfigurations');

    // const utils = require('../../../PGServerJs/test/common/commonUtils2.js');
    // const couchDBUtils = require('../../../controllers/common/CouchDBUtils');

    var csv = require('csvtojson');
    var custArray = [];
    csv()
        .fromFile(__dirname + '/cust1.csv')
        .on('json', (jsonObj) => {
            custArray.push(jsonObj);
        })
        .on('done', (error) => {
            console.log('found rows: ' + custArray.length)
            if (error) {
                console.log('error in reading csv');
                console.log(error);
                return;
            }
            return run();
        });

    var bulkArray = [];
    async function createItemArray() {
        console.log('customer import started...')
        for (let i = 0; i < custArray.length; i++) {
            let customer = {
                _id: 'customer_' + (i + 1),
                id: i + 1,
                address_1: await filterNAData(custArray[i].address_1),
                agency_name: await filterNAData(custArray[i].agency_name),
                city: await filterNAData(custArray[i].city),
                company_name: await filterNAData(custArray[i].company_name),
                country: await filterNAData(custArray[i].country),
                credit_limit: await filterNAData(custArray[i].credit_limit),
                first_name: await filterFname(custArray[i].first_name, custArray[i].phone_number),
                last_name: await filterNAData(custArray[i].last_name),
                email: await filterNAData(custArray[i].email),
                gender: await filterGender(custArray[i].gender),
                pan_number: await filterNAData(custArray[i].pan_number),
                phone_number: await getPhoneNumber(custArray[i].phone_number, i),
                state: await filterNAData(custArray[i].state),
                zip: await filterNAData(custArray[i].zip),
                credit_balance: 0
            }
            customer.person_id = customer.id;

            if (i % 100 === 0) {
                console.log(i);
            }

            // let requiredFields = ["credit_balance"];
            // for (let r = 0; r < requiredFields.length; r++) {
            //     customer[requiredFields[r]] = (customer[requiredFields[r]] === undefined) ? customer[requiredFields[r]] : 0;
            // }

            bulkArray.push(customer);
        }
        try {
            await couchDBUtils.bulkInsert(mainDBInstance, bulkArray);
        } catch (error) {
            console.log(error);
        }
    }

    async function getPhoneNumber(phone_number, i) {
        let LENGTH = 10;
        if (phone_number == 'N/A') phone_number = "";
        let idLength = i.toString().length;
        let prefixCount = LENGTH - phone_number.length - idLength;
        if (prefixCount <= 0) return phone_number;
        for (let i = 0; i < prefixCount; i++) {
            phone_number += '5';
        }
        phone_number += i;
        return phone_number;
    }
    async function filterNAData(data) {
        data = (data == 'N/A' || data === undefined || data === null) ? "" : data;
        return data;
    }
    async function filterGender(data) {
        data = (data == 'M' || !data || data == "N/A" || data.toString().trim()) ? 0 : 1;
        return data;
    }
    async function filterFname(fname, number) {
        fname = (fname === undefined || fname == "N/A" || fname === null) ? number : fname;
        return fname;
    }

    async function deleteType(type) {
        console.log('cleaning old ' + type);
        let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
        console.log(type + '<' + resp.length + '>');
        let bulkDocs = [];
        for (let i = 0; i < resp.length; i++) {
            resp[i].doc._deleted = true;
            bulkDocs.push(resp[i].doc);
        }

        if (bulkDocs.length) {
            await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
        }
    }

    async function deleteHandler() {
        await deleteType('customer');
        console.log('cleanup done');
    }

    async function run() {
        await couchDbManager.initCouchDb(false);
        await deleteHandler();
        await createItemArray();
        console.log('customer import done.');
        process.exit(0);
    }
})();