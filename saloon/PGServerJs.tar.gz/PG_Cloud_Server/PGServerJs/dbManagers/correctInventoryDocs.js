require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .alias('s', 'cleanSalesInfo')
    .default('s', true)
    .alias('p', 'cleanPurchaseInfo')
    .default('p', true)
    .help('h')
    .alias('h', 'help')
    .argv;

var curSession = {};
var applicationSettings = {};
const logger = require('../common/Logger');
var couchDBUtils = require('../controllers/common/CouchDBUtils');

var mainDBInstance = couchDBUtils.getMainCouchDB();

async function cleanSales() {
    try {

        let inventoryDocs = await couchDBUtils.getAllDocsByType('inventory', mainDBInstance);
        let docsToUpdate = [];
        for (let j = 0; j < inventoryDocs.length; j++) {
            for (let trans in inventoryDocs[j].doc.transactions) {
                if (!inventoryDocs[j].doc.transactions[trans].trans_comment) {
                    inventoryDocs[j].doc.transactions[trans].trans_comment = "No Comment";
                }
            }

            docsToUpdate.push(inventoryDocs[j].doc);
        }

        let saleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
        let updateResp = await couchDBUtils.bulkInsert(mainDBInstance, docsToUpdate);
        logger.info('Inv Docs 1 Done!!');
        return;
    } catch (error) {
        logger.error(error);
        throw 'Inv Docs 1 Failed';
    }
}

async function resetPurchaseInfo() {

    try {

        let inventoryDocs = await couchDBUtils.getAllDocsByType('inventory', mainDBInstance);
        let docsToUpdate = [];
        for (let j = 0; j < inventoryDocs.length; j++) {
            for (let trans in inventoryDocs[j].doc.transactions) {
                // console.log(inventoryDocs[j].doc.transactions[trans].trans_comment);trans_comment
                if (!inventoryDocs[j].doc.transactions[trans].trans_comment) {
                    inventoryDocs[j].doc.transactions[trans].trans_comment = "No Comment";
                }
            }
            // console.log(inventoryDocs[0].doc);
            docsToUpdate.push(inventoryDocs[j].doc);
        }
        let updateResp = await couchDBUtils.bulkInsert(mainDBInstance, docsToUpdate);
        logger.info('Inv docs 1 Done!!');
        return;
    } catch (error) {
        logger.error(error);
        throw 'Inventory DOcs 2 Failed';
    }
}

let promisesArray = [];
if (argv.s) {
    promisesArray.push(cleanSales());
}
if (argv.p) {
    console.log('hello');
    promisesArray.push(resetPurchaseInfo());
}

return Promise.all(promisesArray).then(function() {
    process.exit(0);
}).catch(function(error) {
    process.exit(1);
})
// });