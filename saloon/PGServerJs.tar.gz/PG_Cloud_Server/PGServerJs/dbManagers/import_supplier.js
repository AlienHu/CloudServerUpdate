(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../.env',
        sample: __dirname + '/../env.example'
    });

    const couchDbManager = require('./couchDbManager');
    const couchDBUtils = require('../controllers/common/CouchDBUtils');
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const globalConfigController = require('../controllers/GlobalConfigurations');

    // const utils = require('../../../PGServerJs/test/common/commonUtils2.js');
    // const couchDBUtils = require('../../../controllers/common/CouchDBUtils');

    var csv = require('csvtojson');
    var suppArray = [];
    csv()
        .fromFile(__dirname + '/sup1.csv')
        .on('json', (jsonObj) => {
            suppArray.push(jsonObj);
        })
        .on('done', (error) => {
            console.log('found rows: ' + suppArray.length)
            if (error) {
                console.log('error in reading csv');
                console.log(error);
                return;
            }
            return run();
        });

    var bulkArray = [];
    async function createItemArray() {
        console.log('supplier import started...')
        for (let i = 0; i < suppArray.length; i++) {
            let supplier = {
                _id: 'supplier_' + (i + 1),
                id: i + 1,
                address_1: await filterNAData(suppArray[i].address_1),
                agency_name: await filterNAData(suppArray[i].agency_name),
                city: await filterNAData(suppArray[i].city),
                company_name: await filterNAData(suppArray[i].company_name),
                country: await filterNAData(suppArray[i].country),
                credit_limit: await filterNAData(suppArray[i].credit_limit),
                first_name: await filterFname(suppArray[i].first_name, suppArray[i].phone_number),
                last_name: await filterNAData(suppArray[i].last_name),
                email: await filterNAData(suppArray[i].email),
                gender: await filterGender(suppArray[i].gender),
                pan_number: await filterNAData(suppArray[i].pan_number),
                phone_number: await getPhoneNumber(suppArray[i].phone_number, i),
                state: await filterNAData(suppArray[i].state),
                zip: await filterNAData(suppArray[i].zip),
                credit_limit: 50000,
                credit_balance: 0,
                allow_credit: "Allow",
                tin_number: await filterNAData(parseFloat(suppArray[i].tin_number)),
                payment_terms: "months",
                by_months: 1
            }
            supplier.person_id = supplier.id;

            if (i % 100 === 0) {
                console.log(i);
            }

            // let requiredFields = ["credit_balance"];
            // for (let r = 0; r < requiredFields.length; r++) {
            //     supplier[requiredFields[r]] = (supplier[requiredFields[r]] === undefined) ? supplier[requiredFields[r]] : 0;
            // }

            bulkArray.push(supplier);
        }
        try {
            await couchDBUtils.bulkInsert(mainDBInstance, bulkArray);
        } catch (error) {
            console.log(error);
        }
    }

    async function getPhoneNumber(phone_number, i) {
        let LENGTH = 10;
        if (phone_number == 'N/A') phone_number = "";
        let idLength = i.toString().length;
        let prefixCount = LENGTH - phone_number.length - idLength;
        if (prefixCount <= 0) return phone_number;
        for (let i = 0; i < prefixCount; i++) {
            phone_number += '5';
        }
        phone_number += i;
        return phone_number;
    }
    async function filterNAData(data) {
        data = (data == 'N/A' || data === undefined || data === null) ? "" : data;
        return data;
    }
    async function filterGender(data) {
        data = (data == 'M' || !data || data == "N/A" || data.toString().trim()) ? 0 : 1;
        return data;
    }
    async function filterFname(fname, number) {
        fname = (fname === undefined || fname == "N/A" || fname === null) ? number : fname;
        return fname;
    }

    async function deleteType(type) {
        console.log('cleaning old ' + type);
        let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
        console.log(type + '<' + resp.length + '>');
        let bulkDocs = [];
        for (let i = 0; i < resp.length; i++) {
            resp[i].doc._deleted = true;
            bulkDocs.push(resp[i].doc);
        }

        if (bulkDocs.length) {
            await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
        }
    }

    async function deleteHandler() {
        await deleteType('supplier');
        console.log('cleanup done');
    }

    async function run() {
        await couchDbManager.initCouchDb(false);
        await deleteHandler();
        await createItemArray();
        console.log('supplier import done.');
        process.exit(0);
    }
})();