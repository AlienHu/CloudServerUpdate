require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .alias('d', 'dropCouchDbs')
    .default('d', true)
    .alias('c', 'createCouchDbs')
    .default('c', false)
    .alias('env', 'environment')
    .default('env', 'development')
    .describe('env', 'One of the available environments [development,production]')
    .alias('nodeApp', 'nodeAppType')
    .describe('nodeApp', 'One of the available nodeApp appTypes [combo,cloud,retail,restaurant]')
    .help('h')
    .alias('h', 'help')
    .argv;

var couchDbManager = require('./couchDbManager');

if (argv.d && argv.c) {
    couchDbManager.initCouchDb(true)
        .then(function(resp) {
            console.log('Done!!');
            process.exit(0);
        }).catch(function(reason) {
            console.log(reason);
        });
} else if (argv.d) {
    couchDbManager.dropAllCouchDBs().then(function(resp) {
        console.log('Done!!');
        process.exit(0);
    }).catch(function(reason) {
        console.log(reason);
    });
} else if (argv.c) {
    //Todo: check if we can just create tables without dropping data 
    couchDbManager.initCouchDb()
        .then(function(resp) {
            console.log('Done!!');
            process.exit(0);
        }).catch(function(reason) {
            console.log(reason);
        });
} else {
    console.log('Error:Apss proper arguments!!!!(Help -h)');
    process.exit(0);
}