'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDbManager = require('./couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const globalConfigController = require('../controllers/GlobalConfigurations');

var itemsArray = [];
var csv = require('csvtojson')
console.log("Hello ");
csv()
    .fromFile(__dirname + '/sheet2.csv')
    // .fromFile('/home/ganesh/Downloads/restaurantItems.csv')
    .on('json', (jsonObj) => {
        itemsArray.push(jsonObj);
    })
    .on('done', (error) => {
        console.log(itemsArray.length);
        console.log('end');
        console.log(error);

        return run();
    });

async function createConfig(key) {
    let foo = '';
    let csvKey = key;
    if (key === 'category') {
        csvKey = 'Category';
        foo = 'createCategory';
    } else if (key === 'unit') {
        foo = 'createUnit';
    } else if (key == 'tax') {
        foo = 'createTax';
    }
    //process is to get unique config names
    let count = {};
    for (let i = 0; i < itemsArray.length; i++) {

        let configName = itemsArray[i][csvKey];
        if (!configName) {
            //To ignore empty category/unit
            continue;
        }

        count[configName] = 1;
    }
    //here creating config
    let namesArray = Object.keys(count);
    for (let i = 0; i < namesArray.length; i++) {
        let info;
        if (key === 'category') {
            info = {
                name: namesArray[i],
                description: "Default Categories"
            };
        }
        try {
            //create configtigoriesng cte
            await globalConfigController[foo](info);
        } catch (error) {
            console.log(namesArray[i] + ' already exist');
        }
    }

    if (key !== 'tax') {
        return;
    }
    //make it automatic
}

async function prepare() {
    await createConfig('category');
    await createConfig('unit');
    //create tax cess and gst 0
    await createConfig('tax');

}

let categoryObj = {};
let unitObj = {};
let taxObj = {};
async function getIds() {
    //tax, category, saleUnit, purchaseUnit
    let categoryArray = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
    let unitArray = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);
    let taxArray = await couchDBUtils.getAllDocsByType('tax', mainDBInstance);
    for (let i = 0; i < categoryArray.length; i++) {
        categoryObj[categoryArray[i].doc.name] = categoryArray[i].doc.id;
    }
    for (let i = 0; i < unitArray.length; i++) {
        unitObj[unitArray[i].doc.name] = unitArray[i].doc.id;
    }
    for (let i = 0; i < taxArray.length; i++) {
        taxObj[taxArray[i].doc.name + '-' + taxArray[i].doc.percent] = taxArray[i].doc.id;
    }

}
//"bSPTaxInclusive":"TaxInclusive", "bPPTaxInclusive":"TaxInclusive" change as per requirement
let map = {
    "name": "Name",
    "item_number": "Barcode",
    "ItemType": "itemType",
    "uniqueItemCode": "Item Code",
    "description": "Description",
    "purchasePrice": "Purchase Price",
    "sellingPrice": "Selling Price",
    "mrp": "MRP",
    "reorderLevel": "Reorder Level",
    "reorderQuantity": "Reorder Quantity",
    "is_serialized": "Is Serialized",
    "imeiCount": "IMEI",
    "isprepared": "Is Prepared",
    "issellable": "Is Sellable",
    "isbought": "Is bought",
    "hasExpiryDate": "Has ExpiryDate",
    "conversionFactor": "Conversion Factor",
    "discountId": "discountId",
    "hasBatchNumber": "Has BatchNumber",
    "bOTG": "OTG",
    "bSPTaxInclusive": "Selling TaxInclusive",
    "bPPTaxInclusive": "Purchase TaxInclusive",
    "hasVariants": "Has Variants",
    "attributes": "Attributes",
    "hsn": "HSN",
    "salesSlab": "Sales Slab",
    "purchaseSlab": "Purchase Slab",
    "density": "Density",
    "quantity": "Quantity"
}

//Column Names are different so handle it
let requiredFields = Object.keys(map);
let csvRequiredFields = Object.values(map);
// let requiredFields = ["name", "item_number", "uniqueItemCode", "description", "purchasePrice", "sellingPrice", "mrp", "reorderLevel", "reorderQuantity", "is_serialized", "imeiCount", "isprepared", "issellable", "isbought", "hasExpiryDate", "conversionFactor", "discountId", "hasBatchNumber", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive", "hasVariants", "attributes", "ItemType", "hsn", "salesSlab", "purchaseSlab", "density", "quantity"];
// let csvRequiredFields = ["Name", "Barcode", "Item Code", "description", "purchasePrice", "sellingPrice", "mrp", "reorderLevel", "reorderQuantity", "is_serialized", "imeiCount", "isprepared", "issellable", "isbought", "hasExpiryDate", "conversionFactor", "discountId", "hasBatchNumber", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive", "hasVariants", "attributes", "ItemType", "hsn", "salesSlab", "purchaseSlab", "density", "quantity"];
let pgItemsArray = [];

async function createItemArray() {
    let itemController = require('../controllers/Items');
    let pgItem = {
        initialStock: [{}]
    };
    let prevCategory = "";

    for (let i = 0; i < itemsArray.length; i++) {

        itemsArray[i][map.is_serialized] = "false";
        let uniqueDetails = [];

        if (uniqueDetails.length) {

            pgItem.initialStock[0].uniqueDetails = uniqueDetails;
            itemsArray[i][map.is_serialized] = "true";
        }

        //if no unit make it Pkt
        itemsArray[i][map.conversionFactor] = "1"; // make them enter

        for (let j = 0; j < requiredFields.length; j++) {

            let value = itemsArray[i][csvRequiredFields[j]];

            if (["purchasePrice", "mrp", "reorderLevel", "reorderQuantity", "imeiCount", "hsn", "density", "quantity"].indexOf(requiredFields[j]) > -1) {
                value = "0";
            } else if (["hasExpiryDate", "hasVariants", "hasBatchNumber", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive"].indexOf(requiredFields[j]) > -1) {
                value = "false";
            }
            // else if (["item_number"].indexOf(requiredFields[j]) > -1) {
            //     value = "";
            // }
            if (value === undefined) {
                value = "undefined";
            }

            if (parseFloat(value).toString() === value) {
                value = parseFloat(value);
            } else if (value.toLowerCase() === 'false') {
                value = false;
            } else if (value.toLowerCase() === 'true') {
                value = true;
            } else if (value.toLowerCase() === 'yes') {
                value = true;
            } else if (value.toLowerCase() === 'no') {
                value = false;
            } else if (csvRequiredFields[j] === 'TaxInclusive' && value === '') {
                //Only for TaxINclusive
                value = false;
            } else if (value.toLowerCase() === 'undefined') {
                value = undefined;
            }
            pgItem[requiredFields[j]] = value;
        }

        pgItem.attributes = []; //put var head same as in script var
        let itmtype;
        if (itemsArray[i][map.ItemType] == "prepared") {
            itmtype = "Prepared"
        } else {
            itmtype = "Normal"
        }
        pgItem.ItemType = itmtype;
        pgItem.description = itemsArray[i][map.description];
        pgItem.uniqueItemCode = itemsArray[i][map.uniqueItemCode];
        pgItem.sellingPrice = parseFloat(itemsArray[i][map.sellingPrice]);
        pgItem.mrp = parseFloat(itemsArray[i][map.mrp]);
        pgItem.purchasePrice = 0;

        // let quantityStringArray = pgItem.quantity;
        pgItem.initialStock[0].quantity = 0; //parseInt(quantityStringArray[0]);
        pgItem.initialStock[0].purchasePrice = pgItem.purchasePrice;
        pgItem.initialStock[0].sellingPrice = pgItem.sellingPrice;
        pgItem.initialStock[0].mrp = pgItem.mrp;

        if (itemsArray[i].Category) {
            prevCategory = itemsArray[i].Category;
        }
        pgItem.categoryId = categoryObj[prevCategory];
        pgItem.sellingUnitId = unitObj[""];
        pgItem.purchaseUnitId = unitObj[""];
        pgItem.salesTaxes = [taxObj["GST-" + 5]]; //gst ans sas add as in excell sheet
        // samptaxobj = {
        //     "GST-12": 456789,
        //     "GST-18": 456789,
        //     "CESS-12": 45678998545678
        // }
        pgItem.purchaseTaxes = [taxObj["GST-" + 5]];

        pgItemsArray.push(pgItem);
        try {
            await itemController.createItem(pgItem);
        } catch (error) {
            console.log(error);
        }

        if (i % 10 === 0) {
            console.log("I finished 10 <" + i + '>');
        }

        if (uniqueDetails.length) {
            i = k - 1;
        }
    }
}

async function deleteType(type) {
    let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
    console.log(type + '<' + resp.length + '>');
    let bulkDocs = [];
    for (let i = 0; i < resp.length; i++) {
        resp[i].doc._deleted = true;
        bulkDocs.push(resp[i].doc);
    }

    if (bulkDocs.length) {
        await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
    }
}

async function run() {
    //mandatory to initialize the server -> equivalent to node bin/PGServerJs.js
    await couchDbManager.initCouchDb(true);

    await prepare();
    await getIds();
    await createItemArray();
    console.log('done');
    process.exit(0);
}

/**
 * serialnumber
 * units - pcs
 * categorys
 * name
 * quantity
 * mrp 0
 * selling price 0
 * purchase price
 * tax 18%
 * 
 * rest -> default value
 * 
 * 0. read the csv -- done
 * 1. categories -- done
 * 2. units -- done
 * 3. use isItem variable
 * 4. create item -> make the data -> create
 */