// this file to give a category ID or category name to the item which do not content any category ID or category name
// note this will not delete any data 
// to run this copy .env to dbManagers file
// --by Ganesh M.  

require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

var argv = require('yargs')
    .usage('Usage: $0 <command> [options]')
    .alias('i', 'Items')
    .default('i', true)
    .help('h')
    .alias('h', 'help')
    .argv;

var curSession = {};
var applicationSettings = {};
// var globalConfigController
const logger = require('../common/Logger');
var couchDBUtils = require('../controllers/common/CouchDBUtils');

const couchDbManager = require('./couchDbManager');

var mainDBInstance = couchDBUtils.getMainCouchDB();
async function deleteItem(id) {
    const globalConfigController = require('../controllers/GlobalConfigurations');
    const itemsController = require('../controllers/Items');

    // return await itemsController.deleteItem({
    //     'item_id': id
    // });
}
async function deleteItemsOfEmptyCategory() {
    try {
        await couchDbManager.initCouchDb(false);
        console.log('hello');
        const globalConfigController = require('../controllers/GlobalConfigurations');
        let resp = await globalConfigController.createCategory({
            'name': 'Unknown',
            'description': 'category for items with no category'
        });
        let allItems = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
        let unCatId = resp.id;
        let docsToUpdate = [];
        for (let j = 0; j < allItems.length; j++) {
            if (!allItems[j].doc.info.categoryId) {
                allItems[j].doc.info.categoryId = unCatId;
                console.log("deleteing " + allItems[j].doc.info.name + " item_id:" + allItems[j].doc.item_id);
                // await deleteItem(allItems[j].doc.item_id);
            }
            docsToUpdate.push(allItems[j].doc);
            let updateResp = await couchDBUtils.bulkInsert(mainDBInstance, docsToUpdate);
        }
        logger.info('Delete Docs Docs 1 Done!!');
        return;
    } catch (error) {
        logger.error(error);
        throw 'Delete Docs 1 Failed';
    }
}
let promisesArray = [];
console.log('hello 1');
if (argv.i) {
    promisesArray.push(deleteItemsOfEmptyCategory());
}
console.log(promisesArray);
return Promise.all(promisesArray).then(function() {
    process.exit(0);
}).catch(function(error) {
    process.exit(1);
})
// });