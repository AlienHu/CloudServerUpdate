'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});



const couchDbManager = require('./couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();

cleanTransactions();
async function cleanTransactions() {
    await deleteType('sale');
    await deleteType('receiving');
    await deleteType('saleReturn');
    await deleteType('receivingReturn');
    process.exit(0);
}



async function deleteType(type) {
    let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
    console.log(type + '<' + resp.length + '>');
    let bulkDocs = [];
    for (let i = 0; i < resp.length; i++) {
        resp[i].doc._deleted = true;
        bulkDocs.push(resp[i].doc);
    }

    if (bulkDocs.length) {
        await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
    }
}
async function makeStockZero() {
    let inventoryResp = await couchDBUtils.getAllDocsByType('inventory', mainDBInstance);
    console.log('inventory<' + inventoryResp.length + '>');
    let bulkDocs = [];
    for (let i = 0; i < inventoryResp.length; i++) {
        let inventoryDoc = inventoryResp[i].doc;
        let stockKey = Object.keys(inventoryDoc.stock)[0];
        inventoryDoc.stock[stockKey].quantity = 0;
        inventoryDoc.transactions = {};
        inventoryDoc.transactions['1510574251487_' + stockKey] = {
            "trans_date": 1510574251487,
            "trans_items": inventoryDoc.item_id,
            "trans_user": "admin",
            "trans_comment": "Initial Stock",
            "trans_inventory": 0,
            "trans_batchId": "",
            "trans_stockKey": stockKey
        }
        bulkDocs.push(inventoryDoc);
    }
    if (bulkDocs.length) {
        await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
    }
}

//"function(doc, req) {    var doctype, uidx;    if (doc._id && (uidx = doc._id.indexOf('_')) > 0) {        doctype = doc._id.substring(0, uidx);        if (doctype === 'item' || doctype === 'inventory' || doctype ==='category' || doctype ==='unit' || doctype ==='discount' || doctype ==='tax' || doctype ==='variant') {            return true;        }    }    return false;}"

//delete items
//delete supplier