'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDbManager = require('./couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const globalConfigController = require('../controllers/GlobalConfigurations');
const variantController = require('../controllers/Variants.js');

var itemsArray = [];
var pcId = "";
var var1 = [];
var var2 = [];
var csv = require('csvtojson')
console.log("Hello ");
csv()
    .fromFile(__dirname + '/biba.csv')
    // .fromFile('/home/ganesh/Downloads/restaurantItems.csv')
    .on('json', (jsonObj) => {
        itemsArray.push(jsonObj);
    })
    .on('done', (error) => {
        console.log(itemsArray.length);
        console.log('end');
        console.log(error);

        return run();
    });

async function createConfig(key) {
    let foo = '';
    let csvKey = key;
    if (key === 'category') {
        csvKey = 'Category';
        foo = 'createCategory';
    } else if (key === 'unit') {
        foo = 'createUnit';
    } else if (key == 'tax') {
        foo = 'createTax';
    }

    //process is to get unique config names
    let count = {};
    for (let i = 0; i < itemsArray.length; i++) {

        let configName = itemsArray[i][csvKey];
        if (!configName) {
            //To ignore empty category/unit
            continue;
        }

        count[configName] = 1;
    }
    //here creating config
    let namesArray = Object.keys(count);

    //make it automatic
    for (let i = 0; i < namesArray.length; i++) {
        try {
            //create configtigoriesng cte
            await globalConfigController[foo](taxes[i]);
        } catch (error) {
            console.log(namesArray[i] + ' already exist');
        }
    }
    for (let i = 0; i < namesArray.length; i++) {
        let info;
        if (key === 'category') {
            info = {
                name: namesArray[i],
                description: itemsArray[i]["description"]
            };
        }
        try {
            //create configtigoriesng cte
            await globalConfigController[foo](info);
        } catch (error) {
            console.log(namesArray[i] + ' already exist');
        }
    }
}

async function prepare() {
    await createConfig('category');
    await createConfig('unit');
    //create tax cess and gst 0
    await createConfig('tax');
    // await createConfig('variant');

}

let categoryObj = {};
let unitObj = {};
let taxObj = {};
let varObj = {};
async function getIds() {
    //tax, category, saleUnit, purchaseUnit
    let categoryArray = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
    let unitArray = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);
    let taxArray = await couchDBUtils.getAllDocsByType('tax', mainDBInstance);
    let variantArray = await couchDBUtils.getAllDocsByType('variant', mainDBInstance);
    for (let i = 0; i < categoryArray.length; i++) {
        categoryObj[categoryArray[i].doc.name] = categoryArray[i].doc.id;
    }
    for (let i = 0; i < unitArray.length; i++) {
        unitObj[unitArray[i].doc.name] = unitArray[i].doc.id;
    }
    for (let i = 0; i < taxArray.length; i++) {
        taxObj[taxArray[i].doc.name + '-' + taxArray[i].doc.percent] = taxArray[i].doc.id;
    }
    for (let i = 0; i < variantArray.length; i++) {
        varObj[variantArray[i].doc.name] = variantArray[i].doc.id;
    }
}
//"bSPTaxInclusive":"TaxInclusive", "bPPTaxInclusive":"TaxInclusive" change as per requirement
let map = {
    "name": "Name",
    "item_number": "Barcode",
    "uniqueItemCode": "Item Code",
    "description": "Describtion",
    "purchasePrice": "Purchase Price",
    "sellingPrice": "Selling Price",
    "mrp": "MRP",
    "reorderLevel": "Reorder Level",
    "reorderQuantity": "Reorder Quantity",
    "is_serialized": "Is Serialized",
    "imeiCount": "IMEI",
    "isprepared": "Is Prepared",
    "issellable": "Is Sellable",
    "isbought": "Is bought",
    "hasExpiryDate": "Has ExpiryDate",
    "conversionFactor": "Conversion Factor",
    "discountId": "discountId",
    "hasBatchNumber": "Has BatchNumber",
    "bOTG": "OTG",
    "bSPTaxInclusive": "Selling Price include Tax",
    "bPPTaxInclusive": "Purchase Price include Tax",
    "hasVariants": "Has Variants",
    "attributes": "Attributes",
    "ItemType": "Item Type",
    "hsn": "HSN",
    "salesSlab": "Sales Slab",
    "purchaseSlab": "Purchase Slab",
    "density": "Density",
    "quantity": "Quantity"
}

//Column Names are different so handle it
let requiredFields = Object.keys(map);
let csvRequiredFields = Object.values(map);
// let requiredFields = ["name", "item_number", "uniqueItemCode", "description", "purchasePrice", "sellingPrice", "mrp", "reorderLevel", "reorderQuantity", "is_serialized", "imeiCount", "isprepared", "issellable", "isbought", "hasExpiryDate", "conversionFactor", "discountId", "hasBatchNumber", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive", "hasVariants", "attributes", "ItemType", "hsn", "salesSlab", "purchaseSlab", "density", "quantity"];
// let csvRequiredFields = ["Name", "Barcode", "Item Code", "description", "purchasePrice", "sellingPrice", "mrp", "reorderLevel", "reorderQuantity", "is_serialized", "imeiCount", "isprepared", "issellable", "isbought", "hasExpiryDate", "conversionFactor", "discountId", "hasBatchNumber", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive", "hasVariants", "attributes", "ItemType", "hsn", "salesSlab", "purchaseSlab", "density", "quantity"];
let pgItemsArray = [];

async function createItemArray() {
    let itemController = require('../controllers/Items');
    let pgItem = {
        initialStock: [{}]
    };
    let prevCategory = "";

    for (let i = 0; i < itemsArray.length; i++) {

        itemsArray[i][map.is_serialized] = "false";
        let uniqueDetails = [];

        if (uniqueDetails.length) {

            pgItem.initialStock[0].uniqueDetails = uniqueDetails;
            itemsArray[i][map.is_serialized] = "true";
        }

        //if no unit make it Pkt
        itemsArray[i][map.conversionFactor] = "1"; // make them enter

        for (let j = 0; j < requiredFields.length; j++) {

            let value = itemsArray[i][csvRequiredFields[j]];

            if (["purchasePrice", "mrp", "reorderLevel", "reorderQuantity", "imeiCount", "hsn", "density", "quantity"].indexOf(requiredFields[j]) > -1) {
                value = "0";
            } else if (["hasExpiryDate", "hasVariants", "hasBatchNumber", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive"].indexOf(requiredFields[j]) > -1) {
                value = "false";
            }
            // else if (["item_number"].indexOf(requiredFields[j]) > -1) {
            //     value = "";
            // }
            if (value === undefined) {
                value = "undefined";
            }
            if (parseFloat(value).toString() === value) {
                value = parseFloat(value);
            } else if (value.toLowerCase() === 'false') {
                value = false;
            } else if (value.toLowerCase() === 'true') {
                value = true;
            } else if (value.toLowerCase() === 'yes') {
                value = true;
            } else if (value.toLowerCase() === 'no') {
                value = false;
            } else if (csvRequiredFields[j] === 'TaxInclusive' && value === '') {
                //Only for TaxINclusive
                value = false;
            } else if (csvRequiredFields[j] === 'Purchase Price include Tax' && value === '') {
                value = false;
            } else if (csvRequiredFields[j] === 'Selling Price include Tax' && value === '') {
                value = false;
            } else if (value.toLowerCase() === 'undefined') {
                value = undefined;
            }
            pgItem[requiredFields[j]] = value;
        }

        pgItem.attributes = [];
        pgItem.uniqueItemCode = itemsArray[i][map.uniqueItemCode];
        pgItem.item_number = itemsArray[i][map.uniqueItemCode];
        pgItem.hasVariants = true;
        pgItem.quantity = 0;
        pgItem.hsn = itemsArray[i][map.hsn];
        //   //parseInt(quantityStringArray[0]);

        if (!pgItem.hasVariants) {
            pgItem.sellingPrice = parseFloat(itemsArray[i][map.sellingPrice]);
            pgItem.mrp = parseFloat(itemsArray[i][map.purchasePrice]);
            pgItem.purchasePrice = parseFloat(itemsArray[i][map.purchasePrice]);
            pgItem.initialStock[0].purchasePrice = pgItem.purchasePrice;
            pgItem.initialStock[0].sellingPrice = pgItem.sellingPrice;
            pgItem.initialStock[0].mrp = pgItem.mrp;
            pgItem.initialStock[0].quantity = 0;
        } else {
            pgItem.sellingPrice = 0;
            pgItem.mrp = 0;
            pgItem.purchasePrice = 0;
            var variantsArray;
            if (itemsArray[i].SKU.includes("/")) {
                variantsArray = itemsArray[i].SKU.split("/");
            }
            var docJSON = [];
            if (variantsArray) {

                var1.push(variantsArray[0]);
                var2.push(variantsArray[1]);
            } else {
                var1.push(itemsArray[i].SKU);
            }
            var tempJSON = {
                "purchasePrice": parseFloat(itemsArray[i][map.purchasePrice]),
                "mrp": parseFloat(itemsArray[i][map.mrp]),
                "sellingPrice": parseFloat(itemsArray[i][map.sellingPrice]),
                "quantity": 0,
                "attributeInfo": {
                    "1": "1",
                    "2": "1"
                },
                "skuName": itemsArray[i].SKU
            }
            if (!variantsArray) {
                delete tempJSON.attributeInfo[2];
            }
            docJSON.push(tempJSON);
            pgItem.initialStock = docJSON;
            pgItem.attributes.push(1);
        }
        //  delete pgItem.quantity;    //delete

        if (itemsArray[i].Category) {
            prevCategory = itemsArray[i].Category;
        }

        pgItem.categoryId = categoryObj[prevCategory];
        pgItem.sellingUnitId = pcId;
        pgItem.purchaseUnitId = pcId;
        pgItem.salesTaxes = []; //gst ans sas add as in excell sheet
        // samptaxobj = {
        //     "GST-12": 456789,
        //     "GST-18": 456789,
        //     "CESS-12": 45678998545678
        // }
        pgItem.purchaseTaxes = [];
        let gst = (itemsArray[i].GST).slice(0, -1);
        let gstPercate = parseFloat(gst);
        if (!isNaN(gstPercate)) {
            pgItem.salesTaxes.push(taxObj["GST-" + itemsArray[i].GST.slice(0, -1)])
            pgItem.purchaseTaxes.push(taxObj["GST-" + itemsArray[i].GST.slice(0, -1)])
            // pgItem.bPPTaxInclusive = true;
            // pgItem.bSPTaxInclusive = true;
        }

        pgItemsArray.push(pgItem);
        try {
            await itemController.createItem(pgItem);
        } catch (error) {
            console.log(error);
        }

        if (i % 10 === 0) {
            console.log("I finished 10 <" + i + '>');
        }

        if (uniqueDetails.length) {
            i = k - 1;
        }
    }
}

async function deleteType(type) {
    let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
    console.log(type + '<' + resp.length + '>');
    let bulkDocs = [];
    for (let i = 0; i < resp.length; i++) {
        resp[i].doc._deleted = true;
        bulkDocs.push(resp[i].doc);
    }

    if (bulkDocs.length) {
        await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
    }
}
async function createVariant(json) {
    try {
        await couchDBUtils.create(json, mainDBInstance);
    } catch (err) {
        console.error('variant create failed: ' + JSON.stringify(json));
        console.error(err);
        throw err;
    }
}

async function createVariantIfNot1(name1) {
    var doc;
    try {
        doc = await couchDBUtils.getDoc("variant_1", mainDBInstance);
    } catch (err) {
        console.error(err);
    }
    var flag = (doc.name.indexOf(name1) > -1)
    if (!flag) {
        doc.values.push({
            name: name1
        });
        try {
            var resp = await couchDBUtils.update(doc, mainDBInstance);
        } catch (err) {
            console.error(err);
        }
    }
}

async function createVariantIfNot2(name1) {
    var doc;
    try {
        doc = await couchDBUtils.getDoc("variant_2", mainDBInstance);
    } catch (err) {
        console.error(err);
    }
    var flag = (doc.name.indexOf(name1) > -1)
    if (!flag) {
        doc.values.push({
            name: name1
        });
        try {
            var resp = await couchDBUtils.update(doc, mainDBInstance);
        } catch (err) {
            console.error(err);
        }
    }
}
async function createUnit(name, shortName) {

    var id = "";
    if (!shortName) shortName = name;
    let doc = {
        name: name,
        type: 'unit' + '_',
        shortName: shortName.toString().toUpperCase(),
        id: Date.now()
    }
    doc._id = doc.type + doc.id;
    let resp = await couchDBUtils.create(doc, mainDBInstance);
    // return await formatId(resp[0].id);
    id = await formatId(resp[0].id)
    return id;
}

function removeDuplicates(arr) {
    let unique_array = []
    for (let i = 0; i < arr.length; i++) {
        if (unique_array.indexOf(arr[i]) == -1) {
            unique_array.push(arr[i])
        }
    }
    return unique_array
}
async function putVariant() {
    var uniqueVar1 = removeDuplicates(var1);
    var uniqueVar2 = removeDuplicates(var2);
    for (var k = 0; k < uniqueVar1.length; k++) {
        await createVariantIfNot1(uniqueVar1[k]);
    }
    for (var l = 0; l < uniqueVar2.length; l++) {
        await createVariantIfNot2(uniqueVar2[l]);
    }
}
async function formatId(id) {
    let index = id.toString().indexOf('_');
    return parseInt(id.substr(index + 1));
}

async function run() {
    //mandatory to initialize the server -> equivalent to node bin/PGServerJs.js
    await couchDbManager.initCouchDb(true);
    let variantJSON = {
        "_id": "variant_1",
        "id": 1,
        "name": "SIZE",
        "values": []
    };
    await createVariant(variantJSON);
    let variantJSON1 = {
        "_id": "variant_2",
        "id": 2,
        "name": "COLOR",
        "values": []
    };
    pcId = await createUnit('PC');
    await createVariant(variantJSON1);
    await prepare();
    await getIds();
    await createItemArray();
    await putVariant();
    console.log('done');
    process.exit(0);
}

/**
 * serialnumber
 * units - pcs
 * categorys
 * name
 * quantity
 * mrp 0
 * selling price 0
 * purchase price
 * tax 18%
 * 
 * rest -> default value
 * 
 * 0. read the csv -- done
 * 1. categories -- done
 * 2. units -- done
 * 3. use isItem variable
 * 4. create item -> make the data -> create
 */

/**
 * createattribute -> variants.create
 get ids
 attribute []
 initialstock[]
 skuname, attributeinfo
 */