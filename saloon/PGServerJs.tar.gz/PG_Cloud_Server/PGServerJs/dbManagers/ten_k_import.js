'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const couchDbManager = require('./couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const globalConfigController = require('../controllers/GlobalConfigurations');

var itemsArray = [];
var csv = require('csvtojson')
console.log("Hello ");
csv()
    .fromFile(__dirname + '/itemImport.csv')
    // .fromFile('/home/ganesh/Downloads/restaurantItems.csv')
    .on('json', (jsonObj) => {
        itemsArray.push(jsonObj);
    })
    .on('done', (error) => {
        console.log(itemsArray.length);
        console.log('end');
        console.log(error);

        return run();
    });

async function createConfig(key) {
    let foo = '';
    if (key === 'category') {
        foo = 'createCategory';
    } else if (key === 'unit') {
        foo = 'createUnit';
    }

    //process is to get unique config names
    let count = {};
    for (let i = 0; i < itemsArray.length; i++) {

        let configName = itemsArray[i][key];
        if (!configName) {
            //To ignore empty category/unit
            continue;
        }

        count[configName] = 1;
    }
    //here creating config
    let namesArray = Object.keys(count);
    for (let i = 0; i < namesArray.length; i++) {
        let info;
        if (key === 'category') {
            info = {
                name: namesArray[i],
                description: "Default Categories"
            };
        }
        try {
            //create configtigoriesng cte
            await globalConfigController[foo](info);
        } catch (error) {
            console.log(namesArray[i] + ' already exist');
        }
    }
}

async function prepare() {
    await createConfig('category');
    await createConfig('unit');

}

let categoryObj = {};
let unitObj = {};
let taxObj = {};
async function getIds() {
    //tax, category, saleUnit, purchaseUnit
    let categoryArray = await couchDBUtils.getAllDocsByType('category', mainDBInstance);
    let unitArray = await couchDBUtils.getAllDocsByType('unit', mainDBInstance);
    let taxArray = await couchDBUtils.getAllDocsByType('tax', mainDBInstance);
    for (let i = 0; i < categoryArray.length; i++) {
        categoryObj[categoryArray[i].doc.name] = categoryArray[i].doc.id;
    }
    for (let i = 0; i < unitArray.length; i++) {
        unitObj[unitArray[i].doc.name] = unitArray[i].doc.id;
    }
    for (let i = 0; i < taxArray.length; i++) {
        taxObj[taxArray[i].doc.name + '-' + taxArray[i].doc.percent] = taxArray[i].doc.id;
    }

}

let requiredFields = ["name", "item_number", "uniqueItemCode", "description", "purchasePrice", "sellingPrice", "mrp", "reorderLevel", "reorderQuantity", "is_serialized", "imeiCount", "isprepared", "issellable", "isbought", "hasExpiryDate", "conversionFactor", "discountId", "hasBatchNumber", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive", "hasVariants", "attributes", "ItemType", "hsn", "salesSlab", "purchaseSlab", "density", "quantity"];
let pgItemsArray = [];

async function createItemArray() {
    let itemController = require('../controllers/Items');
    let pgItem = {
        initialStock: [{}]
    };
    let prevCategory = "";

    for (let i = 0; i < itemsArray.length; i++) {
        if (i % 100 == 0) {
            console.log("item iport Count: " + i);
        }
        let stockIndex = pgItem.initialStock.length - 1;
        itemsArray[i].is_serialized = "false";
        let uniqueDetails = [];

        if (uniqueDetails.length) {

            pgItem.initialStock[stockIndex].uniqueDetails = uniqueDetails;
            itemsArray[i].is_serialized = "true";
        }

        itemsArray[i].conversionFactor = "1";
        itemsArray[i].ItemType = "Normal";

        for (let j = 0; j < requiredFields.length; j++) {

            let value = itemsArray[i][requiredFields[j]];

            if (["purchasePrice", "mrp", "reorderLevel", "reorderQuantity", "imeiCount", "hsn", "density", "quantity"].indexOf(requiredFields[j]) > -1) {
                value = "0";
            } else if (["hasExpiryDate", "hasVariants", "bOTG", "bSPTaxInclusive", "bPPTaxInclusive"].indexOf(requiredFields[j]) > -1) {
                value = "false";
            }
            // else if (["item_number"].indexOf(requiredFields[j]) > -1) {
            //     value = "";
            // }
            if (value === undefined) {
                value = "undefined";
            }

            if (parseFloat(value).toString() === value) {
                value = parseFloat(value);
            } else if (value.toLowerCase() === 'false') {
                value = false;
            } else if (value.toLowerCase() === 'true') {
                value = true;
            } else if (value.toLowerCase() === 'undefined') {
                value = undefined;
            }
            pgItem[requiredFields[j]] = value;
        }

        if (stockIndex === 0) {
            pgItem.hasBatchNumber = false;
        } else {
            pgItem.hasBatchNumber = true;
        }

        pgItem.attributes = [];
        pgItem.sellingPrice = parseFloat(itemsArray[i].sellingprice);
        pgItem.mrp = parseFloat(itemsArray[i].sellingprice);
        pgItem.purchasePrice = parseFloat(itemsArray[i].purchasePrice);
        pgItem.item_number = parseFloat(itemsArray[i].item_number);
        // let quantityStringArray = pgItem.quantity;
        pgItem.initialStock[stockIndex].quantity = parseFloat(itemsArray[i].quantity); //parseInt(quantityStringArray[0]);
        pgItem.initialStock[stockIndex].purchasePrice = pgItem.purchasePrice;
        pgItem.initialStock[stockIndex].sellingPrice = pgItem.sellingPrice;
        pgItem.initialStock[stockIndex].mrp = pgItem.mrp;
        pgItem.initialStock[stockIndex].description = pgItem.description;
        pgItem.initialStock[stockIndex].batchId = 'b_' + (stockIndex + 1);

        delete pgItem.quantity;

        if (itemsArray[i].category) {
            prevCategory = itemsArray[i].category;
        }
        pgItem.categoryId = categoryObj[prevCategory];
        pgItem.sellingUnitId = unitObj[""];
        pgItem.purchaseUnitId = unitObj[""];
        pgItem.salesTaxes = [];
        pgItem.purchaseTaxes = [];

        let uniqueName = getUniqueName(itemsArray[i]);
        if (i + 1 !== itemsArray.length) {
            let uniqueNameNext = getUniqueName(itemsArray[i + 1]);
            if (uniqueName === uniqueNameNext) {
                pgItem.initialStock.push({});
                continue;
            }
        }


        pgItemsArray.push(pgItem);
        try {
            //  console.log("molu:_" + pgItem.name + '-' + pgItem.hasBatchNumber);
            await itemController.createItem(pgItem);
        } catch (error) {
            console.log(error);
        }

        if (uniqueDetails.length) {
            i = k - 1;
        }
        pgItem.hasBatchNumber = false;
        pgItem.initialStock = [{}];
    }
}

function getUniqueName(item) {
    return item.item_number + '-' + item.name + '-' + item.category.toLowerCase()
}

async function deleteType(type) {
    let resp = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
    console.log(type + '<' + resp.length + '>');
    let bulkDocs = [];
    for (let i = 0; i < resp.length; i++) {
        resp[i].doc._deleted = true;
        bulkDocs.push(resp[i].doc);
    }

    if (bulkDocs.length) {
        await couchDBUtils.bulkDocs(bulkDocs, mainDBInstance);
    }
}

function validate() {
    let barcodeObj = {};
    for (let i = 0; i < itemsArray.length; i++) {
        let item_number = itemsArray[i].item_number + '-' + itemsArray[i].name.toLowerCase();
        if (!barcodeObj[item_number]) {
            barcodeObj[item_number] = [];
        }
        barcodeObj[item_number].push(i);
    }

    let count = 0;
    for (let item_number in barcodeObj) {
        let length = barcodeObj[item_number].length;
        if (length > 1) {
            if (barcodeObj[item_number][length - 1] - barcodeObj[item_number][0] !== (length - 1)) {

                console.log(item_number + ' ' + barcodeObj[item_number]);
            }
            count++;
        }
    }
    console.log(count);

    // process.exit(0);
}

async function run() {
    //mandatory to initialize the server -> equivalent to node bin/PGServerJs.js
    await couchDbManager.initCouchDb(true);

    // validate();

    await prepare();
    await getIds();
    await createItemArray();
    console.log('done');
    process.exit(0);
}

/**
 * serialnumber
 * units - pcs
 * categorys
 * name
 * quantity
 * mrp 0
 * selling price 0
 * purchase price
 * tax 18%
 * 
 * rest -> default value
 * 
 * 0. read the csv -- done
 * 1. categories -- done
 * 2. units -- done
 * 3. use isItem variable
 * 4. create item -> make the data -> create
 */