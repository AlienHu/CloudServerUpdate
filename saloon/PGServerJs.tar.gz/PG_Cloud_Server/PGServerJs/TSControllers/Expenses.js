"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const couchDBUtils = require("../controllers/common/CouchDBUtils");
const mainDBInstance = couchDBUtils.getMainCouchDB();
const logger = require("../common/Logger");
const utils = require("../controllers/common/Utils");
var CLONE = utils.clone;
const autoIncrementHelper_1 = require("../controllers/common/autoIncrementHelper");
let maxExpneseId = autoIncrementHelper_1.getMaxExpensesId();
const moment = require("moment");
exports.saveExpenseCategory = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!data._id) {
            let ts = moment().format('x');
            data._id = getExpenseCategoryId(parseInt(ts));
            data.total = 0;
            data.count = 0;
        }
        try {
            //make it create or update
            yield couchDBUtils.create(data, mainDBInstance);
            return 'Saving Expense Category Success.';
        }
        catch (error) {
            throw 'Saving Expense Category Failed';
        }
    });
};
//#ectodo cyclic dependency in client side
exports.saveExpense = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        let resp;
        resp = {
            message: ''
        };
        if (!data._id) {
            data._id = 'ex_' + (++maxExpneseId);
        }
        try {
            //make it create or update
            data.info.timestamp = data.info.timestamp.toString();
            let respData = yield couchDBUtils.create(data, mainDBInstance);
            resp.data = respData[0].id;
            resp.message = 'Saving Expense Success.';
            return resp;
        }
        catch (error) {
            resp.bError = true;
            resp.error = error;
            resp.message = 'Saving Expense Failed';
            throw resp;
        }
    });
};
exports.getExpenses = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let bGetAllExpenses = !params.categoryId;
        let viewParams = {
            startkey: params.startDate.toString(),
            endkey: params.endDate.toString(),
            include_docs: true
        };
        let expensesReport = {
            summary: {
                count: 0,
                total: 0
            },
            expensesArr: []
        };
        let allCategoriesItrObj = {};
        if (params.bIncludeChildren) {
            let tempResp = yield couchDBUtils.getAllDocsByType('exc', mainDBInstance);
            allCategoriesItrObj = makeKeyValue(tempResp);
        }
        let resp = yield couchDBUtils.getView('all_expenses', 'all_time', viewParams, mainDBInstance);
        for (let i = 0; i < resp.length; i++) {
            let doc = resp[i].doc;
            if (!bGetAllExpenses && !params.bIncludeChildren && doc.info.categoryId !== params.categoryId) {
                continue;
            }
            if (!bGetAllExpenses && params.bIncludeChildren && !isParentChild(params.categoryId, doc.info.categoryId, allCategoriesItrObj)) {
                continue;
            }
            expensesReport.expensesArr.push(doc);
            expensesReport.summary.count++;
            expensesReport.summary.total += doc.info.total;
        }
        return expensesReport;
    });
};
exports.getExpensesForCatArr = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!params.categoryIdArr) {
            params.categoryIdArr = [];
        }
        let viewParams = {
            startkey: params.startDate.toString(),
            endkey: params.endDate.toString(),
            include_docs: true
        };
        let summary = {
            count: 0,
            total: 0
        };
        let allCategoriesItrObj = {};
        if (params.bIncludeChildren) {
            allCategoriesItrObj = yield getAllCategoriesItrObj();
        }
        if (params.categoryIdArr.length === 0) {
            //All Categories
            if (!params.bIncludeChildren) {
                allCategoriesItrObj = yield getAllCategoriesItrObj();
            }
            params.categoryIdArr = Object.keys(allCategoriesItrObj);
        }
        let output = {
            summary: CLONE(summary),
            categoryReport: {}
        };
        if (params.categoryIdArr.length === 0) {
            return output;
        }
        for (let i = 0; i < params.categoryIdArr.length; i++) {
            output.categoryReport[params.categoryIdArr[i]] = CLONE(summary);
        }
        let resp = yield couchDBUtils.getView('all_expenses', 'all_time', viewParams, mainDBInstance);
        for (let i = 0; i < resp.length; i++) {
            let doc = resp[i].doc;
            let categoryId = doc.info.categoryId;
            if (!params.bIncludeChildren && params.categoryIdArr.indexOf(categoryId)) {
                continue;
            }
            output.summary.count++;
            output.summary.total += doc.info.total;
            if (!params.bIncludeChildren) {
                output.categoryReport[categoryId] = initSummary(output.categoryReport[categoryId], summary);
                output.categoryReport[categoryId].count++;
                output.categoryReport[categoryId].total += doc.info.total;
                continue;
            }
            //bIncludeChildren
            let curParentId = categoryId;
            while (true) {
                output.categoryReport[curParentId] = initSummary(output.categoryReport[curParentId], summary);
                output.categoryReport[curParentId].count++;
                output.categoryReport[curParentId].total += doc.info.total;
                if (!allCategoriesItrObj[curParentId]) {
                    //just to be sure
                    break;
                }
                curParentId = allCategoriesItrObj[curParentId].parentId;
                if (!curParentId || curParentId === 'TOP') {
                    break;
                }
            }
        }
        return output;
    });
};
function initSummary(summary, freshSummary) {
    if (!summary) {
        summary = freshSummary;
    }
    return summary;
}
function isParentChild(parentId, childId, allDocItrObj) {
    let bParentChild = false;
    let curParentId = childId;
    while (true) {
        if (curParentId === parentId) {
            bParentChild = true;
            break;
        }
        if (!allDocItrObj[curParentId]) {
            logger.error('something wrong. isParentChild');
            break;
        }
        curParentId = allDocItrObj[curParentId].parentId;
        if (!curParentId || curParentId === 'TOP') {
            break;
        }
    }
    return bParentChild;
}
function makeKeyValue(allDocs) {
    let out = {};
    for (let i = 0; i < allDocs.length; i++) {
        out[allDocs[i].id] = allDocs[i].doc;
    }
    return out;
}
function getAllCategoriesItrObj() {
    return __awaiter(this, void 0, void 0, function* () {
        let tempResp = yield couchDBUtils.getAllDocsByType('exc', mainDBInstance);
        let allCategoriesItrObj = makeKeyValue(tempResp);
        return allCategoriesItrObj;
    });
}
function createDefaultCategories() {
    return __awaiter(this, void 0, void 0, function* () {
        let allDocs = yield couchDBUtils.getAllDocsByType('exc', mainDBInstance);
        if (allDocs.length) {
            //default categories already created
            return;
        }
        let docs2Create = [];
        let ts = parseInt(moment().format('x'));
        for (let i = 0; i < defaultExpenses.length; i++) {
            let parentId = getExpenseCategoryId(ts++);
            docs2Create.push({
                _id: parentId,
                name: defaultExpenses[i].name,
                parentId: 'TOP',
                description: ''
            });
            for (let j = 0; j < defaultExpenses[i].children.length; j++) {
                let parentId1 = getExpenseCategoryId(ts++);
                docs2Create.push({
                    _id: parentId1,
                    name: defaultExpenses[i].children[j].name,
                    parentId: parentId,
                    description: ''
                });
                for (let k = 0; defaultExpenses[i].children[j].children && k < defaultExpenses[i].children[j].children.length; k++) {
                    docs2Create.push({
                        _id: getExpenseCategoryId(ts++),
                        name: defaultExpenses[i].children[j].children[k].name,
                        parentId: parentId1,
                        description: ''
                    });
                }
            }
        }
        try {
            yield couchDBUtils.bulkDocs(docs2Create, mainDBInstance);
        }
        catch (error) {
            throw 'Not expected to come here. createDefaultCategories';
        }
    });
}
function getExpenseCategoryId(ts) {
    return 'exc_' + ts.toString();
}
const defaultExpenses = [{
        name: 'Direct Expenses',
        children: [{
                name: 'Stock Expenses',
                children: [{
                        name: 'Cost of Goods Sold'
                    },
                    {
                        name: 'Stock Adjustment'
                    },
                    {
                        name: 'Expenses Included In Valuation'
                    }]
            }]
    }, {
        name: 'Indirect Expenses',
        children: [{
                name: 'Administrative Expenses'
            }, {
                name: 'Commission on Sales'
            }, {
                name: 'Depreciation'
            }, {
                name: 'Entertainment Expenses'
            }, {
                name: 'Exchange Gain/Loss'
            }, {
                name: 'Freight and Forwarding Charges'
            }, {
                name: 'Gain/Loss on Asset Disposal'
            }, {
                name: 'Legal Expenses'
            }, {
                name: 'Marketing Expenses'
            }, {
                name: 'Miscellaneous Expenses'
            }, {
                name: 'Office Maintenance Expenses'
            }, {
                name: 'Office Rent'
            }, {
                name: 'Postal Expenses'
            }, {
                name: 'Print and Stationary'
            }, {
                name: 'Rounded Off'
            }, {
                name: 'Salary'
            }, {
                name: 'Sales Expenses'
            }, {
                name: 'Telephone Expenses'
            }, {
                name: 'Travel Expenses'
            }, {
                name: 'Utility Expenses'
            }]
    }];
createDefaultCategories();
//# sourceMappingURL=Expenses.js.map