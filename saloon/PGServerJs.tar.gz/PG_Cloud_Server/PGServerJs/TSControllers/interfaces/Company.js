"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_COMPANY_DOCID = 'company_1';
//# sourceMappingURL=Company.js.map