"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const couchdb_1 = require("./couchdb");
const formatDocIds_1 = require("../../TSControllers/utils/formatDocIds");
exports.dbConfig = {
    "host": "127.0.0.1",
    "port": 5984,
    "dbPrefix": "pg",
    "username": '',
    "password": '',
    "onRegistrationId": {
        [couchdb_1.REPLICATIOR_DB_PREFIX]: {
            "name": couchdb_1.REPLICATIOR_DB_PREFIX,
            "bAddPrefix": false,
            "bAddCompanyStoreIDSufix": false,
            "bAddRegistrationIDSufix": false,
            "bReplicate": false,
            "bCreateViews": false,
            "bSync2Client": false,
            "bBackup": false,
            "excludeDocTypeArr": []
        },
        [couchdb_1.SESSIONS_DB_PREFIX]: {
            "name": couchdb_1.SESSIONS_DB_PREFIX,
            "bAddPrefix": true,
            "bAddCompanyStoreIDSufix": false,
            "bAddRegistrationIDSufix": false,
            "bCreateViews": true,
            "bReplicate": false,
            "bSync2Client": false,
            "bBackup": false,
            "excludeDocTypeArr": []
        },
        [couchdb_1.COUCH_USERS_DB_PREFIX]: {
            "name": couchdb_1.COUCH_USERS_DB_PREFIX,
            "bAddPrefix": false,
            "bAddCompanyStoreIDSufix": false,
            "bAddRegistrationIDSufix": false,
            "bReplicate": true,
            "bCreateViews": true,
            "bSync2Client": true,
            "bBackup": true,
            "excludeDocTypeArr": []
        },
        [couchdb_1.LICENCE_DB_PREFIX]: {
            "name": couchdb_1.LICENCE_DB_PREFIX,
            "bAddPrefix": true,
            "bAddCompanyStoreIDSufix": false,
            "bAddRegistrationIDSufix": true,
            "bReplicate": true,
            "bCreateViews": true,
            "bSync2Client": true,
            "bBackup": true,
            "excludeDocTypeArr": [formatDocIds_1.LOCK_PREFIX, formatDocIds_1.MASTER_PREFIX]
        }
    },
    "onStoreSelect": {
        [couchdb_1.MAIN_DB_PREFIX]: {
            "name": couchdb_1.MAIN_DB_PREFIX,
            "bAddPrefix": true,
            "bAddCompanyStoreIDSufix": true,
            "bAddRegistrationIDSufix": true,
            "bReplicate": false,
            "bCreateViews": true,
            "bSync2Client": true,
            "bBackup": true,
            "excludeDocTypeArr": []
        },
        [couchdb_1.CORE_DB_PREFIX]: {
            "name": couchdb_1.CORE_DB_PREFIX,
            "bAddPrefix": true,
            "bAddCompanyStoreIDSufix": true,
            "bAddRegistrationIDSufix": true,
            "bReplicate": false,
            "bCreateViews": true,
            "bSync2Client": true,
            "bBackup": true,
            "excludeDocTypeArr": []
        }
    }
};
//# sourceMappingURL=dbConfig.js.map