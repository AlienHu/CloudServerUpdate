"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const couchDBApis = require("../TSCouchDB/Common/couchDBApis");
const dbInstanceHelper_1 = require("../TSCouchDB/Common/dbInstanceHelper");
const logger = require("../common/Logger");
const autoIncrementHelper_1 = require("./libraries/autoIncrementHelper");
const formatDocIds_1 = require("./utils/formatDocIds");
exports.saveCompany = function (data, dbContext) {
    return __awaiter(this, void 0, void 0, function* () {
        let bNew = false;
        if (!data._id) {
            data._id = formatDocIds_1.formatCompanyDocId(autoIncrementHelper_1.getMaxCompanyId(dbContext));
            bNew = true;
        }
        try {
            yield couchDBApis.createOrUpdate(dbContext, data, dbInstanceHelper_1.getLicenceDBInstance, 2, 'Failed to save company');
            if (bNew) {
                //#TITO handle delete also. on delete the id should be removed from user
                //#TITO add it to admin not to who created
                var userDoc = yield couchDBApis.getDoc(dbContext, 'org.couchdb.user:' + data.createdBy, dbInstanceHelper_1.getUsersDBInstance); // hard coded prefix todo #tito
                if (!userDoc.companyIdArr) {
                    logger.info('saveCompany. not expected to come');
                    userDoc.companyIdArr = [];
                }
                userDoc.companyIdArr.push(data._id);
                yield couchDBApis.createOrUpdate(dbContext, userDoc, dbInstanceHelper_1.getUsersDBInstance, 2, 'Failed to set company permission');
            }
            return 'Saving Company Success.';
        }
        catch (error) {
            throw 'Saving Company Failed';
        }
    });
};
//#TITO storeArr -> companyIdArr
//# sourceMappingURL=Company.js.map