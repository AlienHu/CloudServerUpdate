/**
 */

'use strict';

var path = require('path');
let migrationName = path.basename(__filename, '.js');
let errMsg = migrationName + ' Migration Failed';

var crypto = require('crypto'),
    algorithm = 'aes-256-ctr';

function encrypt(text, password) {
    var cipher = crypto.createCipher(algorithm, password);
    var crypted = cipher.update(text, 'utf8', 'hex');
    crypted += cipher.final('hex');
    return crypted;
};

function decryptLicence(thisEncLicence) {

    var decipher, decLicence;
    if (thisEncLicence.candClientId) {
        decipher = crypto.createDecipher(algorithm, thisEncLicence.candClientId);
        decLicence = decipher.update(thisEncLicence.enDeviceInfo, 'hex', 'utf8');
    } else if (thisEncLicence.clientId) {
        decipher = crypto.createDecipher(algorithm, thisEncLicence.clientId);
        decLicence = decipher.update(thisEncLicence.enlicence, 'hex', 'utf8');
    } else {
        console.log('No Id for licence decryption');
    }

    decLicence += decipher.final('utf8');
    decLicence = JSON.parse(decLicence);
    return decLicence;
}

function prepareServerLicence(serverLicenceJson, bDelete) {

    let decLicence = decryptLicence(serverLicenceJson);

    if (!bDelete) {
        decLicence.cloudCouch = {
            "host": "vvtq792uog.execute-api.us-east-1.amazonaws.com",
            "ssl": true,
            "apiKey": "rsmtpogY9c5BiR3miNFaa7HPm2CRENTt8H2Kpirn",
            "api": {
                "cloudSyncDetails": "/profitguru/cloud-sync-details"
            }
        };
    } else {
        if (decLicence.cloudCouch) {
            delete decLicence.cloudCouch;
        }
    }
    serverLicenceJson.enlicence = encrypt(JSON.stringify(decLicence), decLicence.clientId);
}

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const configState = require(appRootPath + 'common/configState');
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let licenceDBInstance = params.nanoClients.licencedb;
        let serverLicDoc;
        try {
            serverLicDoc = await couchDBUtils.getDoc('profitGuruServerLicence_', licenceDBInstance, 'propagate');
        } catch (error) {
            logger.info('No licence Added');
            return;
        }

        prepareServerLicence(serverLicDoc);
        try {
            await couchDBUtils.create(serverLicDoc, licenceDBInstance);
        } catch (error) {
            logger.error(error);
            throw errMsg;
        }

    },

    down: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const configState = require(appRootPath + 'common/configState');
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let licenceDBInstance = params.nanoClients.licencedb;
        let serverLicDoc;
        try {
            serverLicDoc = await couchDBUtils.getDoc('profitGuruServerLicence_', licenceDBInstance, 'propagate');
        } catch (error) {
            logger.info('No licence Added');
            return;
        }

        prepareServerLicence(serverLicDoc, true);
        try {
            await couchDBUtils.create(serverLicDoc, licenceDBInstance);
        } catch (error) {
            logger.error(error);
            throw errMsg;
        }
    }
};