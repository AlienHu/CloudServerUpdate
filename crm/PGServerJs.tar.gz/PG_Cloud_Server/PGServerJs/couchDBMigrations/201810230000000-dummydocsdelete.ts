/**
 */

'use strict';

import * as path from 'path';

export const up = async (params) => {
    const logger = params.logger;

    let migrationName = path.basename(__filename, '.js');
    params.migrationName = migrationName;
    let nanoClients = params.nanoClients;
    let dbInstance = nanoClients.maindb;

    let skip = 0;
    let totalDeleted = 0;

    try {
        while (true) {
            let resp = (await dbInstance.fetch({}, {
                include_docs: true,
                limit: 1000,
                skip: skip
            }))[0];

            if (resp.rows.length === 0) {
                break;
            }

            let docs2DeleteArr = [];
            for (let i = 0; i < resp.rows.length; i++) {
                if (Object.keys(resp.rows[i].doc).length !== 2) {
                    continue;
                }
                resp.rows[i].doc._deleted = true;
                docs2DeleteArr.push(resp.rows[i].doc);
            }

            if (docs2DeleteArr.length) {
                await dbInstance.bulk({
                    docs: docs2DeleteArr
                });
            }

            skip += 10000 - docs2DeleteArr.length;
            totalDeleted += docs2DeleteArr.length;
            logger.silly('skip<' + skip + '> totaldelted<' + totalDeleted + '>');
        }
    } catch (err) {
        logger.error(err);
        throw migrationName + ' up migration failed';
    }
};

export const down = async () => {
    //nothing required
    return;
};