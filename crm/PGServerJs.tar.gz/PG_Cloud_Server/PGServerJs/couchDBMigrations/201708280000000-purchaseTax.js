/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

async function batchProcess(batchSize, docType, processFun, params) {
    let skip = 0;
    let itemDocsObj = {};
    while (true) {
        params.logger.info('Current Count <' + skip + ' >');
        let allDocs = await params.couchDBUtils.getAllDocsByType(docType, params.dbInstance, {
            limit: batchSize,
            skip: skip
        });
        skip += allDocs.length;

        await processFun(allDocs, params);

        if (allDocs.length !== batchSize) {
            params.logger.info('Total Process Count<' + skip + '>');
            break;
        }
    }
}

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const configState = require(appRootPath + 'common/configState');
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;

        let mainDBInstance = params.nanoClients.maindb;
        try {
            await batchProcess(10, 'receiving', processReceivings, {
                dbInstance: mainDBInstance,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
        } catch (error) {
            logger.error(error);
            throw migrationName + 'up migration failed';
        }

        async function processReceivings(allReceivingDocs, params) {
            let itemDocsObj = params.itemDocsObj;
            let itemDocIds = [];

            let docs2Update = [];
            for (let i = 0; i < allReceivingDocs.length; i++) {
                if (!allReceivingDocs[i].doc.receiving_items) {
                    continue;
                }

                let taxes = allReceivingDocs[i].doc.receiving_item_taxes;
                let items = allReceivingDocs[i].doc.receiving_items;
                for (let k = 0; taxes && k < taxes.length; k++) {
                    for (let j = 0; j < items.length; j++) {
                        let item_id = items[j].item_id;
                        let stockKey = items[j].stockKey;
                        if (item_id === taxes[k].item_id && stockKey === taxes[k].stockKey) {
                            if (!items[j].itemTaxList) {
                                items[j].itemTaxList = [];
                            }
                            items[j].itemTaxList.push({
                                name: taxes[k].name,
                                percent: taxes[k].percent
                            });
                        }
                    }
                }

                if (taxes) {
                    delete allReceivingDocs[i].doc.receiving_item_taxes;
                }

                docs2Update.push(allReceivingDocs[i].doc);
            }

            if (docs2Update) {
                await couchDBUtils.bulkInsert(mainDBInstance, docs2Update);
            }
        }

    },

    down: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const configState = require(appRootPath + 'common/configState');
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;

        let mainDBInstance = params.nanoClients.maindb;
        try {
            await batchProcess(10, 'receiving', processReceivings, {
                dbInstance: mainDBInstance,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
        } catch (error) {
            logger.error(error);
            throw migrationName + 'up migration failed';
        }

        async function processReceivings(allReceivingDocs, params) {
            let itemDocsObj = params.itemDocsObj;
            let itemDocIds = [];

            let docs2Update = [];
            for (let i = 0; i < allReceivingDocs.length; i++) {
                if (!allReceivingDocs[i].doc.receiving_items) {
                    continue;
                }

                let taxes = [];
                let items = allReceivingDocs[i].doc.receiving_items;

                for (let j = 0; j < items.length; j++) {
                    let item_id = items[j].item_id;
                    let stockKey = items[j].stockKey;
                    if (!items[j].itemTaxList) {
                        continue;
                    }

                    for (let k = 0; k < items[j].itemTaxList.length; k++) {
                        taxes.push({
                            item_id: item_id,
                            stockKey: stockKey,
                            name: items[j].itemTaxList[k].name,
                            percent: items[j].itemTaxList[k].percent
                        });
                    }

                    delete items[j].itemTaxList;
                }

                allReceivingDocs[i].doc.receiving_item_taxes = taxes;
                docs2Update.push(allReceivingDocs[i].doc);
            }

            if (docs2Update) {
                await couchDBUtils.bulkInsert(mainDBInstance, docs2Update);
            }
        }
    }
};
