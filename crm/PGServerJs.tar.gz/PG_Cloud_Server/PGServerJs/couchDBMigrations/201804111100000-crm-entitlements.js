/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;
        try {
            var params = {};
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            var allUsersDoc = [];
            var json = {
                "desc": "",
                "allowNone": false,
                "allowAll": false,
                "viewOnMenu": false,
                "apis": ["create"],
                "create": {
                    "apis": ["/crm/create"],
                    "common": true,
                    "allowed": false,
                    "desc": "Allows to create campaign"
                }
            };
            for (var i = 0; i < allUsers.length; i++) {
                try {
                    allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                } catch (error) {
                    logger.error(error);
                    continue;
                }

                if (allUsers[i].value.roles[1] === 'admin') {
                    json.allowAll = true;
                    json.viewOnMenu = true;
                    json.create.allowed = true;
                }
                allUsers[i].value.roles[0].crm = json;
                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);

                allUsersDoc.push(allUsers[i].value);
            }
            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
        try {
            var allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', nanoCore);
            allowedFeatures.crm = {
                "enabled": true,
                "desc": "crm features"
            }
            await couchDBUtils.update(allowedFeatures, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' up-2 migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            var params = {};
            let allUsersDoc = [];
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            for (var i = 0; i < allUsers.length; i++) {
                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);

                if (allUsers[i].value.roles[0].hasOwnProperty('crm')) {
                    delete allUsers[i].value.roles[0].crm;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('crm property not found');
                }
                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                allUsersDoc.push(allUsers[i].value);
            }

            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);
        } catch (error) {
            logger.error(error);
            logger.error('crm down migration failed');
            throw error;
        }
        try {
            var allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', nanoCore);
            if (allowedFeatures.hasOwnProperty('crm')) {
                delete allowedFeatures.crm;
            }
            await couchDBUtils.update(allowedFeatures, nanoCore);
        } catch (err) {
            logger.error(error);
            throw migrationName + ' allowedFeature down migration failed';
        }
    }
};