console.log('Started:pre Update Hook');
//NOTE: CWD while running this hook is Previous Live Installer only, i.e. currently running

const config = require(__dirname + "/../../updater/updateConfig.js")();
const shelljs = require('shelljs');
const path = require('path');

const updaterBackUpDir = path.resolve(config.UpdaterDir, 'updaterBackUp');
if (shelljs.test('-d', updaterBackUpDir)) {
    //Cleaning the backup directory
    shelljs.rm('-r', updaterBackUpDir);
}
//Creating backup directory
shelljs.mkdir(updaterBackUpDir);

const updateUtil = require(config.UpdaterDir + "/utils/updateUtil.js");
var semver = require('semver');
let currentAppVersionDetails = JSON.parse(updateUtil.readFileSync(path.resolve(config.UpdaterDir, 'package.json')));
let cloudVersion = JSON.parse(updateUtil.readFileSync(path.resolve(config.toBeLiveAppDir, '..', 'profitGuruUpdater/package.json'))).version;
if (semver.gte(currentAppVersionDetails.version, cloudVersion)) {
    console.log('preUpdateHook everything up-to-date');
    process.exit(0);
}

//Backup static files and folders
shelljs.cp('-r', path.resolve(config.UpdaterDir, 'controller'), updaterBackUpDir);
shelljs.cp('-r', path.resolve(config.UpdaterDir, 'utils'), updaterBackUpDir);
shelljs.cp('-r', path.resolve(config.UpdaterDir, 'config'), updaterBackUpDir);
shelljs.cp('-r', path.resolve(config.UpdaterDir, 'routes'), updaterBackUpDir);
shelljs.cp(path.resolve(config.UpdaterDir, 'index.js'), updaterBackUpDir);
shelljs.cp(path.resolve(config.UpdaterDir, 'package.json'), updaterBackUpDir);

//Copy the new files
shelljs.cp('-r', path.resolve(config.toBeLiveAppDir, '..', 'profitGuruUpdater/*'), config.UpdaterDir);
console.log('End:Pre Update Hook');

process.exit(1);