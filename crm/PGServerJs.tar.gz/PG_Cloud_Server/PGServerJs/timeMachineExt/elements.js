let elements = function () {

    this.createItems = function (noItems) {

    };

};

module.exports = new elements();