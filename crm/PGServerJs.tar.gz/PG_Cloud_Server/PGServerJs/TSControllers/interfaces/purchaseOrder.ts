
export namespace PurchaseOrder {
    export interface PurchaseOrderCartItemDoc {
        itemId: string;
        requestedPrice: number;
        itemName: string;
        isPriceAbsolute: boolean;
        requestedQuantity: number;
    }

    export interface UpdatePurchaseOrder {
        _rev: string;
        orderText: string;
        media: InvoiceMedia[];
        comments: Message[]; // user comment
        status: STATUS[];
        address: string;
        mode: string; // pickup; homedelivery; etc
        shopId: string;
        saleReferences: string[]; // arr of sale ids if more sales are done for same purchase order
        _id: string;
        orderTime: string;
        idWithoutPrefix: number; // original timstamp
        alienId: string;
        lastUpdated: number;
        customerId: string; // customer id in seller db
        customerName: string;
        orderItems: PurchaseOrderCartItemDoc[];
    }

    export interface Message {
        timestamp: number;
        message: string;
        author: string;
        status: string;
    }

    export interface STATUS {
        STATUS_NUMBER: number;
        STATUS_NAME: string;
        timestamp?: number;
        bChangedBySeller?: boolean;
    }

    export interface InvoiceMedia {
        type: string;
        media: string;
    }

    export interface POResponse {
        iItemNotFoundCount: number;
        iPriceDifferenceCount: number;
        iOutOfStockCount: number;
        iExpiredStockCount: number;
        iAddItemToCartErrorCount: number;
        iUnExpectedErrorCount: number;
        errorItemInfoArr: ErrorItemInfo[];
        bCustomerError: boolean;
    }

    export interface ErrorItemInfo {
        itemId: string;
        bItemNotFound: boolean;
        name: string;
        requestedPrice: number;
        currentPrice: number; //current price is 0 - it is OTG
        iDeficitQuantity: number;
        bExpired: boolean;
        bAddItemToCartError: boolean;
        bUnExpectedError: boolean;
    }

    export interface AddItemToCartParams {
        item: string,
        stockKey: string,
        unitId: number,
        price: number;
        quantity: number;
        bThrowError: boolean;
    }

    export interface StockKeyQuantityInfo {
        stockKey: string;
        quantity: number;
    }

    const sampleAddItemToCartParams: AddItemToCartParams = {
        "item": "4",
        "stockKey": "id_4_batch_1544256296750_1_3",
        "unitId": 1544255710856,
        "price": 100,
        "quantity": 1,
        "bThrowError": true
    };


}