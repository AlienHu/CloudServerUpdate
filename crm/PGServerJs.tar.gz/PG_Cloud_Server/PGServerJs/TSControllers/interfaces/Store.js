"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var OperationType;
(function (OperationType) {
    OperationType[OperationType["READ_ONLY"] = 0] = "READ_ONLY";
    OperationType[OperationType["CREATE_ONLY"] = 1] = "CREATE_ONLY";
    OperationType[OperationType["GENERAL"] = 2] = "GENERAL";
})(OperationType = exports.OperationType || (exports.OperationType = {}));
exports.REPLICATION_USERS_INFO = {
    read: 'read',
    general: 'general',
    create: 'create',
    prefix: 'pg'
};
var OperationMode;
(function (OperationMode) {
    OperationMode[OperationMode["NONE"] = 0] = "NONE";
    OperationMode[OperationMode["ONLINE"] = 1] = "ONLINE";
    OperationMode[OperationMode["BINDED_OFFLINE"] = 2] = "BINDED_OFFLINE";
    OperationMode[OperationMode["OFFLINE"] = 3] = "OFFLINE";
})(OperationMode || (OperationMode = {}));
var SyncCRUDCondition;
(function (SyncCRUDCondition) {
    SyncCRUDCondition[SyncCRUDCondition["NONE"] = 0] = "NONE";
    SyncCRUDCondition[SyncCRUDCondition["ONCREATE"] = 1] = "ONCREATE";
    SyncCRUDCondition[SyncCRUDCondition["ONUPDATE"] = 2] = "ONUPDATE";
    SyncCRUDCondition[SyncCRUDCondition["ONDELETE"] = 3] = "ONDELETE";
    SyncCRUDCondition[SyncCRUDCondition["ALL"] = 4] = "ALL";
})(SyncCRUDCondition || (SyncCRUDCondition = {}));
exports.ALL_STORE_KEYWORD = 'ALL';
exports.DEFAULT_SYNC_SETTINGS = {
    masters: {
        label: 'Masters',
        description: '',
        dbName: 'maindb',
        docTypeArr: ['category', 'subCategory', 'discount', 'unit', 'tax', 'variant', 'pProfile', 'profile', 'slab', 'brand', 'charge', 'exc', 'item', 'inventory'],
        props: {
            bContinous: true,
            bOnStoreCreate: true,
            enSyncCondition: SyncCRUDCondition.ALL
        },
        parentLevel: '',
        srcStoreDocIdArr: [exports.ALL_STORE_KEYWORD]
    },
    transactions: {
        label: 'Transactions',
        description: '',
        dbName: 'maindb',
        docTypeArr: ['transfer'],
        props: {
            bContinous: true,
            bOnStoreCreate: true,
            enSyncCondition: SyncCRUDCondition.ALL
        },
        parentLevel: '',
        srcStoreDocIdArr: [exports.ALL_STORE_KEYWORD]
    }
};
//we can take inspiration from validate_doc_update
//so each api can run some validation
//# sourceMappingURL=Store.js.map