import { Payment } from "./payments";
import { Timestamp } from "./common";

export namespace Expense {

    export interface Doc {
        _id: string;
        _rev: string;
        id: number;
        itemArr?: Item[];
        info: Info;
        paymentArr: Payment[];
    }

    export interface Item {
        name: string;
        quantity: number;
        price: number;
        total: number;
    }

    export interface Response {
        message: string;
        bError?: boolean;
        error?: any;
        data?: any;
    }

    export interface CategoryInfo {
        _id: string;
        _rev?: string;
        name: string;
        parentId: string;
        description: string;
        total?: number;
        count?: number;
    }

    export interface Info {
        refInvNo?: string;
        timestamp: Timestamp
        employeeId: string;
        partyName?: string;
        partyPhoneNo?: string;
        total: number;
        categoryId: string;
        category: string;
        refSaleInvNo?: string;
        refPurInvNo?: string;
    }

}