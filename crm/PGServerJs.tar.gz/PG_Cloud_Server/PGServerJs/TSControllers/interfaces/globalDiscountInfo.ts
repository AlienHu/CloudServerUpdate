export interface GlobalDiscountInfo {
    readonly amt: number;
    readonly percent: number;
    readonly discountMethod: string;
}
