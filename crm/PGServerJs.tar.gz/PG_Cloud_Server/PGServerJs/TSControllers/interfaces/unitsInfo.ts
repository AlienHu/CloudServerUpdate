interface PProfileInfo {
    sellingPrice: number;
    discountId: number;
}

interface PProfilesData {
    [pProfileId: string]: PProfileInfo;
}

export interface UnitInfo {
    refUnitId: number;
    factor: number;
    pProfilesData: PProfilesData;
    purchasePrice: number;
    mrp: number;
}

export interface UnitsInfo {
    [unitId: string]: UnitInfo
}

export interface UnitDoc {
    _id: string;
    _rev: string;
    name: string;
    description: string;
    shortName: string;
    id: number;
}

export interface UnitDocItrObj {
    [unitId: string]: UnitDoc;
}