/**
 *  Todo: Ideally we want many error status codes. Look for a npm module
 */

var StatusCode = function() {
    'use strict';

    this.SUCCESS = 0;
    this.ERR_UNDEFINED = -1;
    this.ERR_BAD_ARG = -2;
    this.ERR_TIME_OUT = -3
};

module.exports = new StatusCode();