/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */

//TODO We can use EventEmitter2 for wild card events and other features
var util = require('util');
var ip = require("ip");
var EventEmitter = require('events').EventEmitter;

var createSingleton = require('create-singleton');
var _self;
var isOnline = require('is-online');
var serverSerilaNumber;
var profitGuruEventsSingleton = createSingleton(function profitGuruEvents() {
    EventEmitter.call(this);
    _self = this;
    var connected2LAN;
    var isProfitGuruOnline = false;

    this.getInternetStatus = function() {
        return isProfitGuruOnline;
    };

    _self.on('ServerUUID_Available', function(serverSerilaNumberParam) {
        serverSerilaNumber = serverSerilaNumberParam;
    });

    function lanStatusHelper() {
        var myIp = ip.address();
        if (myIp === '127.0.0.1') {
            if (connected2LAN === undefined || connected2LAN === true) {
                console.log('Not connected to LAN');
                _self.emit('notConnected2LAN');
                _self.emit('profitGuruOffline');
                connected2LAN = isProfitGuruOnline = false;
            }
        } else {
            if (connected2LAN === undefined || connected2LAN === false) {
                console.log('conncted to LAN');
                _self.emit('connected2LAN');
                connected2LAN = true;
            }
        }
    }

    setInterval(function() {
        lanStatusHelper();
    }, 5000);

    setInterval(function() {
        isInternetConnected();
    }, 60000);

    //Is connected to interNet
    function isInternetConnected() {
        isOnline().then(function(online) {
            if (online && !isProfitGuruOnline && serverSerilaNumber) {
                _self.emit('profitGuruOnline', serverSerilaNumber);
                isProfitGuruOnline = true;
            } else if (isProfitGuruOnline && !online) {
                _self.emit('profitGuruOffline');
                isProfitGuruOnline = false;
            }
        });
    }

    this.getNetWorkStatusEventer = function() {
        return network;
    };
});

util.inherits(profitGuruEventsSingleton, EventEmitter);
module.exports = new profitGuruEventsSingleton();