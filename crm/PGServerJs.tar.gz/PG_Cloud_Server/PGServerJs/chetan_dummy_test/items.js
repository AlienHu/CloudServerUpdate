"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let item = {
    item_id: 4,
    batchId: "y",
    ItemType: "Normal",
    stockKey: "id_4_batch_y_1_1_2_1_3_1",
    item_location: 1,
    stock_name: "India",
    line: 1,
    name: "Ergonomic Concrete Gloves",
    item_number: "000503",
    description: "Harbor",
    serialnumber: "",
    imeiNumbers: [],
    is_serialized: false,
    hasBatchNumber: true,
    bOTG: false,
    hsn: 7580,
    hasExpiryDate: true,
    bSPTaxInclusive: false,
    bPPTaxInclusive: false,
    expiry: "Sat Jun 09 2018 08:21:46 GMT+0530 (India Standard Time)",
    unit: "gms",
    quantity: 1,
    discount: 26,
    price: 352,
    sellingPriceExcludingTax: 352,
    totalTaxPercent: 10,
    purchasePrice: 0.30338389731621934,
    mrp: 449,
    reorder_level: 104,
    imeiCount: 0,
    chargesList: [],
    chargesTaxList: [],
    attributeInfo: {
        1: 1,
        2: 1,
        3: 1
    },
    itemTaxList: [{
            name: "CGST",
            percent: 5,
            Amt: 13.024000000000001
        },
        {
            name: "SGST",
            percent: 5,
            Amt: 13.024000000000001
        }
    ],
    origTaxes: [{
            taxId: 1511155450843,
            taxInfo: {
                _id: "tax_1511155450843",
                _rev: "1-84d510c63ed3afb07b57aebcf86a1398",
                name: "GST",
                percent: 28,
                id: 1511155450843
            }
        }],
    slab: {
        _id: "slab_1511155452562",
        _rev: "1-7e6fb2f4d23830cc77935420fbc205f3",
        name: "connecting",
        taxName: "GST",
        rates: [{
                min: 0,
                max: 1000,
                percent: 10
            },
            {
                min: 1001,
                max: 2000,
                percent: 28
            },
            {
                min: 2001,
                max: 9999999,
                percent: 4
            }
        ],
        id: 1511155452562
    },
    bReadyForCheckout: true,
    gDiscountValue: 0,
    bGDiscountPercent: true,
    gDiscountPercent: 0,
    gDiscountAmt: 0,
    total: 352,
    discounted_total: 260.48,
    discounted_price: 91.52,
    totalAfterDisAndCharges: 260.48,
    totalWithTax: 286.528
};
exports.default = item;
//# sourceMappingURL=items.js.map