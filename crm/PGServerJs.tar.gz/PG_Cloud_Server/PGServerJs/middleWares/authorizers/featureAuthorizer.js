 var urlParser = require('url');
 var path = require('path');
 //This middleWare validates to check whether the user is allowed to make this profitGuru Api request.

 //TODO make this document in accessible to others, will have seperate app to access this kind of documents
 var allowedFeaturesSet;
 var setClass = require('simplesets');

 var profitGuruStatusEvents = require('../../common/profitGuruStatusEvents.js');
 profitGuruStatusEvents.on('featuresUpdate', prepareAllowedFeaturesModulesList);

 var serverConfig = require(path.join(__dirname, '../../config', 'config.json'));
 //var defaultWhiteListApiList = ['/user/signin', '/user/signout', '/user/signup', '/core/profitGuruRestApis', '/core/profitGuruElements', '/licence/amiauthorized2connect'];
 var whiteListApis = [];
 serverConfig.defaultWhiteListApis.forEach(function(api, index) {
     whiteListApis.push(api.toLowerCase());
 });

 var whiteListModules = [];
 serverConfig.defaultWhiteListModules.forEach(function(api, index) {
     whiteListModules.push(api.toLowerCase());
     //  if (process.env.ENVIRONMENT === 'development') {
     //      whiteListModules.push('demoapp');
     //  }
 });

 function prepareAllowedFeaturesModulesList(allowedProfitGuruFeaturesDoc) {
     delete allowedProfitGuruFeaturesDoc._id;
     delete allowedProfitGuruFeaturesDoc._rev;

     allowedFeaturesSet = new setClass.Set([]);
     for (var module in allowedProfitGuruFeaturesDoc) {
         if (allowedProfitGuruFeaturesDoc[module].enabled) {
             allowedFeaturesSet.add(module.toLowerCase());
         }
     }
 }
 //TODO we need to listen any changes to allowed Features documents and reload the allowedFeaturesSet

 function featureAuthorizer(allowedProfitGuruFeaturesDoc) {
     prepareAllowedFeaturesModulesList(allowedProfitGuruFeaturesDoc);

     return function featureAuthorizer(req, res, next) {

         var urlPath = urlParser.parse(req.url).pathname.toLowerCase();
         //to Remove / at the end of url, to get the match properly
         urlPath = urlPath.replace(/\/\s*$/, "");
         var moduleName = urlPath.split('/');
         moduleName = moduleName[1].toLowerCase();

         if (process.env.APP_TYPE === 'restaurant' && moduleName === 'sales') {
             moduleName = 'takeAway';
             moduleName = moduleName.toLowerCase();
         };

         if (req.session.user !== undefined) {
             if (whiteListApis.indexOf(urlPath) >= 0 || whiteListModules.indexOf(moduleName) >= 0) {
                 return next(); //whitelisted Apis, No authentication needed
             } else {
                 //Lets validate whether the app is allowed to access this Feature

                 if (allowedFeaturesSet.has(moduleName)) {
                     return next();
                 } else {
                     res.send(new Error(moduleName + ' Feature Error:  This Feature Is Not Enabled for your Application, Contact AlienHu/ProfitGuru Team for Help '));
                     res.end();
                 }
             }

         } else {
             //Passing whiteListApiList Api before signin
             return next();
         }
     };
 }

 module.exports = featureAuthorizer;