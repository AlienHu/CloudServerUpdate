/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */
var couchViewHelper = require('./couchViewHelper');
var coredbViews = function() {

    this.updatesDesignDocs = [{
        name: 'all_updates',
        updates: [{
            update_name: 'update',
            function: function(doc, req) {
                var newDoc = JSON.parse(req.body);
                var rev = doc._rev;
                doc = newDoc;
                doc._rev = rev;
                var message = doc._id.toString();
                return [doc, message];
            }
        }]
    }];

    this.designDocs = [{
        name: 'all_profitguru_rest_apis',
        version: 1,
        views: [{
            viewName: 'all_profitguru_rest_apis',
            function: couchViewHelper.generateView('profitGuruRestApis',
                'emit(doc);'
            ),
            version: 1
        }]
    }, {
        name: 'all_profitguru_elements',
        version: 1,
        views: [{
            viewName: 'all_profitguru_elements',
            function: couchViewHelper.generateView('profitGuruElements',
                'emit(doc);'
            ),
            version: 1
        }]
    }, {
        name: 'all_profitguru_profiles',
        version: 1,
        views: [{
            viewName: 'all_profitguru_profiles',
            function: couchViewHelper.generateView('profitGuruProfiles',
                'emit(doc);'
            ),
            version: 1
        }]
    }, {
        name: 'all_feedback_form',
        version: 5,
        views: [{
            viewName: 'all_feedback_form',
            function: function(doc) {
                var doctype, uidx;
                if (doc._id && (uidx = doc._id.indexOf('_')) > 0) {
                    doctype = doc._id.substring(0, uidx);
                    if (doctype === 'feedbackForm') {
                        if (doc.deleted) {
                            return;
                        }
                        emit(doc);

                    }
                }
            },
            version: 1
        }]
    }];

};

module.exports = new coredbViews();