/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */

var _userViews = function() {

    var all = function(doc) {
        if (doc.type === 'user') emit(doc.email, doc);
    };

    var code = function(doc) {
        if (doc.type === 'user' && doc.code) emit(doc.code, doc);
    };

    var verification_code = function(doc) {
        if (doc.type === 'user' && doc.verification_code) emit(doc.verification_code, doc);
    };

    var unique_data = function(doc) {
        var doctype, uidx;
        if (doc._id && (uidx = doc._id.indexOf('org.couchdb.user:')) === 0) {
            if (doc.deleted) {
                return;
            }
            emit(doc.phone_number);
            if (doc.email) {
                emit(doc.email);
            }

        }

    };

    var role = function(doc) {
        doc.roles.forEach(function(role) {
            emit(role, doc);
        });
    };

    this.updatesDesignDocs = [{
        name: 'all_updates',
        updates: [{
            update_name: 'update',
            function: function(doc, req) {
                var newDoc = JSON.parse(req.body);
                var rev = doc._rev;
                doc = newDoc;
                doc._rev = rev;
                var message = doc._id.toString();
                return [doc, message];
            }
        }]
    }];

    this.designDocs = [{
        name: 'employees',
        views: [{
            viewName: 'all',
            function: all,
            version: 1
        }, {
            viewName: 'code',
            function: code,
            version: 1
        }, {
            viewName: 'role',
            function: role,
            version: 1
        }, {
            viewName: 'verification_code',
            function: verification_code,
            version: 1
        }, {
            viewName: 'unique_data',
            function: unique_data,
            version: 1
        }],
        version: 1
    }];

};

module.exports = new _userViews();