'use strict';
require('dotenv-safe').load();
var chaiAsPromised = require("chai-as-promised");
var profitGuruFaker = require('../common/profitGuruFaker.js');
var commonNodeVsPhp = require('./common/commonUtilNodeVsPhp.js');
var BPromise = require('bluebird');
var salesComparisionUtils = require('./common/salesComparisionUtil');
var chai = require("chai");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
//var assert = chai.assert;
//var jsonDiff = require('deep-diff');

var ItemModel = Models.profitGuru_items;
var compareNodeVsPhpResults = require('./common/compareNodeVsPhpResults.js');
var itemList;

describe('Sales NodeVsPhp UTs', function() {

    this.timeout(5000000);

    before(function(done) {
        var newEmployeeData = profitGuruFaker.getFakerPhpAndExpressUserCouchEmployee();
        commonNodeVsPhp.InitTestNodeVsPhp(newEmployeeData)
            .then(function(resp) {
                console.log('Lets get the items for sales');
                console.log(resp);
                ItemModel.all().then(function(allItem) {
                    itemList = allItem;
                    expect(itemList.length).greaterThan(0);
                    commonNodeVsPhp.getPhpItemList().then(function(resp) {
                        console.log(resp);
                        done();
                    });

                });
            });

    });

    it('Add Item to Cart', function() {
        console.log('Adding item details=', itemList[0].dataValues);
        var item2Add = {
            item: itemList[0].dataValues.item_id
        };
        return BPromise.props({
            phpCart: salesComparisionUtils.phpAddItem2Cart(item2Add),
            nodeCart: salesComparisionUtils.nodeAddItem2Cart(item2Add)
        }).then(function(results) {
            // console.log(results);
            // console.log(results.phpCart.taxesArray);
            // console.log(results.phpCart.cart);
            // console.log(results.nodeCart.cart);
            // console.log(results.nodeCart.cart[0].itemTaxList);

            var diffsOtherThanCart = compareNodeVsPhpResults.compareCommonSalesResponse(results.phpCart, results.nodeCart);
            console.log(diffsOtherThanCart);
            expect(diffsOtherThanCart).to.be.an('undefined');

            var cartDiffWthtTaxes = compareNodeVsPhpResults.compareSalesCarts(results.phpCart.cart['1'], results.nodeCart.cart[0]);
            console.log(cartDiffWthtTaxes);
            expect(cartDiffWthtTaxes).to.be.an('undefined');

            var cartItemTaxesDiff = compareNodeVsPhpResults.compareSingleCartItemTax(results.phpCart.taxesArray, results.nodeCart.cart[0].itemTaxList);
            console.log(cartItemTaxesDiff);
            expect(cartItemTaxesDiff).to.be.an('undefined');

        });
    });

    it('Cancel Sale', function() {

        console.log('Adding item details=', itemList[0].dataValues);
        var item2Add = {
            item: itemList[0].dataValues.item_id
        };
        return BPromise.props({
            phpCart: salesComparisionUtils.phpAddItem2Cart(item2Add),
            nodeCart: salesComparisionUtils.nodeAddItem2Cart(item2Add)
        }).then(function(results2) {
            return BPromise.props({
                phpCart: salesComparisionUtils.phpCancelSaleOrClearCart(),
                nodeCart: salesComparisionUtils.nodeCancelSaleOrClearCart()
            }).then(function(results) {

                console.log(results);

                console.log(results.phpCart.cart);
                console.log(results.nodeCart.cart);
                //console.log(results.nodeCart.cart[0].itemTaxList);

                var diffsOtherThanCart = compareNodeVsPhpResults.compareCommonSalesResponse(results.phpCart, results.nodeCart);
                console.log(diffsOtherThanCart);
                expect(diffsOtherThanCart).to.be.an('undefined');
            });
        });
    });

    it('Make Payment', function() {

        var paymentParams = {
            payment_type: "Cash",
            amount_tendered: 10000
        };
        var item2Add = {
            item: itemList[0].dataValues.item_id
        };
        // return BPromise.props({
        //     phpCart_0: salesComparisionUtils.phpAddItem2Cart(item2Add),
        //     nodeCart_0: salesComparisionUtils.nodeAddItem2Cart(item2Add)
        // }).then(function() {
        //  

        return BPromise.props({
            phpCart: salesComparisionUtils.phpAddItem2CartAndMakeSalesPayment(item2Add, paymentParams),
            nodeCart: salesComparisionUtils.nodeAddItem2CartAndMakeSalesPayment(item2Add, paymentParams)
        }).then(function(results) {
            // }).then(function(results) {
            console.log(results);
            console.log(results.phpCart.taxesArray);
            console.log(results.phpCart.cart);
            console.log(results.nodeCart.cart);
            console.log(results.nodeCart.cart[0].itemTaxList);

            var diffsOtherThanCart = compareNodeVsPhpResults.compareCommonSalesResponse(results.phpCart, results.nodeCart);
            if (diffsOtherThanCart) {
                console.log('CartDiff', diffsOtherThanCart);
            }

            var cartDiffWthtTaxes = compareNodeVsPhpResults.compareSalesCarts(results.phpCart.cart['1'], results.nodeCart.cart[0]);
            if (cartDiffWthtTaxes) {
                console.log(cartDiffWthtTaxes);
            }

            var cartItemTaxesDiff = compareNodeVsPhpResults.compareSingleCartItemTax(results.phpCart.taxesArray, results.nodeCart.cart[0].itemTaxList);
            if (cartItemTaxesDiff) {
                console.log(cartItemTaxesDiff);
            }

            var cartPaymentsDiff = compareNodeVsPhpResults.completeSaleComparePayments(results.phpCart, results.nodeCart);
            if (cartPaymentsDiff) {
                console.log(cartPaymentsDiff);
            }

            expect(diffsOtherThanCart).to.be.an('undefined');
            expect(cartDiffWthtTaxes).to.be.an('undefined');
            expect(cartItemTaxesDiff).to.be.an('undefined');
            expect(cartPaymentsDiff).to.be.an('undefined');

        });

    });

    it('Complete Sale', function() {

        var paymentParams = {
            payment_type: "Cash",
            amount_tendered: 10000
        };
        var item2Add = {
            item: itemList[0].dataValues.item_id
        };
        // return BPromise.props({
        //     phpCart_0: salesComparisionUtils.phpAddItem2Cart(item2Add),
        //     nodeCart_0: salesComparisionUtils.nodeAddItem2Cart(item2Add)
        // }).then(function() {
        //  

        return BPromise.props({
            phpCart: salesComparisionUtils.phpAddItem2CartAndMakeSalesPayment(item2Add, paymentParams),
            nodeCart: salesComparisionUtils.nodeAddItem2CartAndMakeSalesPayment(item2Add, paymentParams)
        }).then(function(results) {
            // }).then(function(results) {
            console.log(results);
            console.log(results.phpCart.taxesArray);
            console.log(results.phpCart.cart);
            console.log(results.nodeCart.cart);
            console.log(results.nodeCart.cart[0].itemTaxList);

            var diffsOtherThanCart = compareNodeVsPhpResults.compareCommonSalesResponse(results.phpCart, results.nodeCart);
            if (diffsOtherThanCart) {
                console.log('CartDiff', diffsOtherThanCart);
            }

            var cartDiffWthtTaxes = compareNodeVsPhpResults.compareSalesCarts(results.phpCart.cart['1'], results.nodeCart.cart[0]);
            if (cartDiffWthtTaxes) {
                console.log(cartDiffWthtTaxes);
            }

            var cartItemTaxesDiff = compareNodeVsPhpResults.compareSingleCartItemTax(results.phpCart.taxesArray, results.nodeCart.cart[0].itemTaxList);
            if (cartItemTaxesDiff) {
                console.log(cartItemTaxesDiff);
            }

            var cartPaymentsDiff = compareNodeVsPhpResults.completeSaleComparePayments(results.phpCart, results.nodeCart);
            if (cartPaymentsDiff) {
                console.log(cartPaymentsDiff);
            }

            expect(diffsOtherThanCart).to.be.an('undefined');
            expect(cartDiffWthtTaxes).to.be.an('undefined');
            expect(cartItemTaxesDiff).to.be.an('undefined');
            expect(cartPaymentsDiff).to.be.an('undefined');

        });

    });

});