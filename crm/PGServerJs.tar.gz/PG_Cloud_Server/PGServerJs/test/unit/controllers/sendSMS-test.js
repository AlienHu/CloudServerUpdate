'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

var utils = require('../../common/Utils.js');
var chai = require('chai');
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
var chaiFiles = require('chai-files');
chai.use(chaiFiles);
var file = chaiFiles.file;
chai.should();
var expect = chai.expect;
var q = require('q');
var fs = require('fs');

describe('SendSMS Controller UTs  ', function(done) {
    this.timeout(100000);
    var sendSMS = require('../../../controllers/SendSMS');

    //The phone number for testing is read from env variable
    var requestData = {};
    requestData = {
        email: process.env.TEST_EMAIL_ID,
        phone_number: process.env.TEST_PHONE_NUMBER
    };
    console.log("Sending SMS to phone number ", requestData.phone_number);

    after(function() {
        var logDir = '.';
        utils.deleteFilesOfType(logDir, ['log']);
    });

    beforeEach(function() {});

    it('SMS : test send SMS functionality', function() {
        var response = {};

        return sendSMS(requestData, response).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
        });
    });
});