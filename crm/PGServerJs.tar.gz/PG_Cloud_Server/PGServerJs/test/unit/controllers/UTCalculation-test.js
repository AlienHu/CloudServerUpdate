'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

let chai = require("chai");
let chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
let expect = chai.expect;
let assert = chai.assert;
let profitGuruFaker = require('../../common/profitGuruFaker.js');
let faker = require('faker');
let moment = require('moment');
let utils = require('../../../controllers/common/Utils.js');
let commonTestUtils = require('../../common/commonUtils.js');

const couchDbManager = require('../../../dbManagers/couchDbManager');
let itemController;
let itemControllerLib;
let globalConfigController = require('../../../controllers/GlobalConfigurations');

let couchDBUtils = require('../../../controllers/common/CouchDBUtils');
let mainDBInstance = couchDBUtils.getMainCouchDB();
const jsonfile = require('jsonfile');

let BPromise = require('bluebird');
let itemJson = require('../controllers/item.json');
let getcustomizeFakerData = require('../controllers/customizeData.js');

describe('Item Controller UTS', function() {
    let curItemData = {};
    let resultItemData = [];
    let curBatch = {};
    let curItemDoc = {};
    let curInvDoc = {};
    let curCatData = {};
    let unitObj = {};
    let salesController;
    let applicationSettings = {};
    let cartItemArr = [];
    let curSession = profitGuruFaker.getFakerSession();

    this.timeout(200000);
    this.slow(0);

    before(function() {

        return couchDbManager.initCouchDb(false).then(function(resp) {
            applicationSettings = resp.applicationSettings;
            itemControllerLib = require('../../../controllers/libraries/itemsControllerLib');
            itemController = require('../../../controllers/Items');
            salesController = require('../../../controllers/Sales')(curSession, applicationSettings);
            return Promise.all([commonTestUtils.createGlobalConfigs(5), commonTestUtils.getPeople(5, 'supplier')]);
        });

    });

    it('create item', async function() {

        for (let i = 0; i < itemJson.items.length; i++) {
            curItemData = await getcustomizeFakerData.getcustomizeData(itemJson.items[i]);
            console.log(curItemData);
            try {
                let resp = await itemController.createItem(curItemData);
                expect(resp.success).to.equal("Item Successfully Created");
                console.log('successfully added item' + resp.item_id);
                curItemData.item_id = resp.item_id;
                resultItemData.push(curItemData);
            } catch (err) {
                console.log(err);
                console.log('error in item creation');
                expect(1).to.equal(0);
            }
        }
    });

    it('add item to cart', async function() {
        await addItemToCart(6);
    });

    it('QuickPay the cart', async function() {
        try {
            //call quickSale            
            let resp = await QuickPay()
            expect(resp.totalWithoutTax).to.equal(1185); // read it dynamically
            expect(resp.receipt_title).to.equal('Sales Receipt');
            expect(resp.id).to.greaterThan(0); //todo
            // more checkings
            console.log('Successfully made quick sales payment  :' + resp.sale_id);
        } catch (err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        }
    })
    async function addItemToCart(nItems) {
        for (let v = 0; v < nItems; v++) {
            //get item info for batch 
            let iteminfo = {};
            let curItem = await couchDBUtils.getDoc("item_" + resultItemData[v].item_id, mainDBInstance); //
            iteminfo.item = curItem.item_id;
            iteminfo.stockKey = Object.keys(curItem.batches)[0]; // correct ?
            iteminfo.uniqueDetails = "";
            iteminfo.unitid = curItem.info.defaultPurchaseUnitId;
            try {
                let resp = await salesController.additemRestApi(iteminfo);
                // expect(resp.cart.length).to.equal(v + 1);
                console.log('successfully added item' + resp.cart[resp.cart.length - 1].item_id + "To Cart");
                cartItemArr[0] = resp;

            } catch (err) {
                console.log(err);
                console.log('error in item creation');
                // expect(1).to.equal(0);
            }
        }
    }
    async function QuickPay() {
        let date = new Date();
        console.log(cartItemArr);
        let saleData = {
            amount_tendered: cartItemArr[0].amount_due,
            bQuickOrder: false,
            bSendSMS: undefined,
            payment_type: "Cash",
            print_after_sale: true,
            timeStamp: date.toString(),
            wcInfo: {
                name: "",
                phone_number: ""
            }
        }
        return await salesController.quickSale(saleData);
    }
});

//