(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    //mocha -R spec UT_reservations.js  --timeout 200000
    var q = require('q');
    var faker = require('faker');
    var moment = require('moment');
    var chai = require("chai");
    var chaiAsPromised = require("chai-as-promised");
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var assert = chai.assert;
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var couchDB = couchDBUtils.getMainCouchDB();

    describe('Reservation Controller UTs  ', function(done) {
        this.timeout(100000);
        var tablesController = require('../../../controllers/Tables');
        var reservationController = require('../../../controllers/Reservation');
        var applicationSettings = {};
        var tablesModel = Models.profitGuru_tables_details;
        var maxTableNo = 1;
        var curTimeStr = moment().format();
        var nextDayStr = moment(curTimeStr).endOf('day').format();
        var allReservations = [];
        var todayBookTimeCount = 0;
        var todayBookEndTimeCount = 0;

        function getReservationIndexCouchDB(tableDoc, reservationId) {
            var reservationIndex = -1;
            for (var i = 0; i < tableDoc.reservations.length; i++) {
                if (tableDoc.reservations[i].reservation_id === reservationId) {
                    reservationIndex = i;
                    break;
                }
            }

            return reservationIndex;
        }

        function makeReservation(nextTimeStr, noOfReservations) {
            if (noOfReservations === 0) {
                return;
            }

            if (noOfReservations == 1) {
                nextTimeStr = moment(nextTimeStr).add(1, 'd').format();
            }

            noOfReservations = noOfReservations - 1;
            var reservationData = {};
            reservationData.table_no = faker.random.arrayElement([maxTableNo, maxTableNo + 1]);
            reservationData.bookingTime = moment(nextTimeStr).add(1, 'm').format();
            reservationData.bookingEndTime = moment(reservationData.bookingTime).add(91, 'm').format();
            reservationData.contactInfo = faker.lorem.word();
            reservationData.Reservation_desc = faker.lorem.word();
            return reservationController.saveReservation(reservationData).then(function(resp) {
                expect(resp.status).to.equal('success');
                reservationData.reservation_id = resp.reservation_id;
                allReservations.push(reservationData);
                if (reservationData.bookingTime < nextDayStr)
                    todayBookTimeCount++;
                if (reservationData.bookingEndTime < nextDayStr)
                    todayBookEndTimeCount++;
                return couchDB.get('table_' + reservationData.table_no);
            }).then(function(resp) {
                var tableDoc = resp[0];
                var reservationIndex = getReservationIndexCouchDB(tableDoc, reservationData.reservation_id);
                expect(reservationIndex).to.not.equal(-1);
                expect(reservationIndex).to.equal(tableDoc.reservations.length - 1);

                return makeReservation(reservationData.bookingEndTime, noOfReservations);
            });
        }

        function deleteReservationsRecursively() {
            if (allReservations.length === 0)
                return;

            var reservationId = allReservations[0].reservation_id;
            var tableNo = allReservations[0].table_no;
            allReservations.shift();
            return reservationController.deleteReservation({
                reservation_id: reservationId
            }).then(function(resp) {
                expect(resp.status).to.equal('success');
                return couchDB.get('table_' + tableNo);
            }).then(function(resp) {
                var reservationIndex = getReservationIndexCouchDB(resp[0], reservationId);
                expect(reservationIndex).to.equal(-1);

                return deleteReservationsRecursively();
            });
        }

        before(function() {
            return couchDbManager.initCouchDb(false).then(function(resp) {
                return tablesModel.findOne({
                    order: [
                        ['table_no', 'DESC'],
                    ]
                });
            }).then(function(resp) {
                if (resp) {
                    maxTableNo = resp.table_no + 1;
                }

                applicationSettings = {
                    tableReservations: {
                        MinReservationDuration: 30
                    }
                };
            });
        });

        beforeEach(function() {});

        it('create 2 tables', function() {
            var tableData = {
                table_no: maxTableNo,
                desc: faker.lorem.word()
            };

            return tablesController.createTable(tableData).then(function(resp) {
                expect(resp.hasOwnProperty('status')).to.equal(true);
                expect(resp.status).to.equal('success');

                tableData = {
                    table_no: maxTableNo + 1,
                    desc: faker.lorem.word()
                };
                return tablesController.createTable(tableData);
            }).then(function(resp) {
                expect(resp.hasOwnProperty('status')).to.equal(true);
                expect(resp.status).to.equal('success');
            });
        });

        it('make reservation on a table', function() {
            //making 5 reservations
            return makeReservation(curTimeStr, 5);
        });

        it('select table', function() {
            var queryData = {};
            queryData.bookingTime = moment(curTimeStr).add(80, 'm').format();
            queryData.bookingEndTime = moment(queryData.bookingTime).add(30, 'm').format();
            return reservationController.selectTable(queryData).then(function(resp) {
                expect(resp.data.length).to.equal(2);
            });
        });

        it('minimumReservationDuration', function() {
            var minDuration = 0;
            return reservationController.minimumReservationDuration().then(function(resp) {
                minDuration = resp.MinReservationDurationData.MinReservationDuration;
                expect(minDuration).to.equal(applicationSettings.tableReservations.MinReservationDuration);
            });
        });

        it('getReservationDetails', function() {
            var params = {};
            return reservationController.getReservationDetails(params).then(function(resp) {
                expect(resp.data.length).to.equal(5);
                for (var i = 0; i < resp.data.length; i++) {
                    expect(allReservations[i].reservation_id).to.equal(resp.data[i].reservation_id);
                    expect(allReservations[i].table_no).to.equal(resp.data[i].table_no);
                    expect(allReservations[i].bookingTime).to.equal(resp.data[i].book_time);
                    expect(allReservations[i].bookingEndTime).to.equal(resp.data[i].booking_end_time);
                    expect(allReservations[i].contactInfo).to.equal(resp.data[i].customer_contact_info);
                    expect(allReservations[i].Reservation_desc).to.equal(resp.data[i].Description);
                    expect('Roland Garros').to.equal(resp.data[i].empName);
                }
            });
        });

        it('getReservationDetails4TableColorChange', function() {
            var params = {};
            var reservationsCount = 0;
            return reservationController.getReservationDetails4TableColorChange(params).then(function(resp) {
                expect(resp.data.length).to.equal(todayBookTimeCount);
            });
        });

        it('checkReservation4table', function() {
            var params = {
                tableNo: maxTableNo
            };
            var reservationsCount = 0;
            return reservationController.checkReservation4table(params).then(function(resp) {
                reservationsCount += resp.data.length;
                params.tableNo = maxTableNo + 1;
                return reservationController.checkReservation4table(params);
            }).then(function(resp) {
                reservationsCount += resp.data.length;
                expect(reservationsCount).to.equal(todayBookTimeCount);
            });
        });

        /*
         *   In this test case, we are doing reservations for either for table_no = maxTableNo/maxTableNo+1. So for currentTime, we should find reservation for only 1 table
         */
        it('checkAlreadyReserved', function() {
            var params = {
                table_no: maxTableNo
            };
            var bFoundReservation = false;
            return reservationController.checkAlreadyReserved(params).then(function(resp) {
                if (resp.data.length !== 0)
                    bFoundReservation = true;
                params.table_no = maxTableNo + 1;
                return reservationController.checkAlreadyReserved(params);
            }).then(function(resp) {
                var expectedReservations = 1;
                if (bFoundReservation) {
                    expectedReservations = 0;
                }
                expect(resp.data.length).to.equal(expectedReservations);
            });
        });

        it('reservation window', function() {
            var queryData = {};
            queryData.starttime = moment(curTimeStr).add(80, 'm').format();
            queryData.endtime = moment(queryData.starttime).add(30, 'm').format();
            return reservationController.reservationWindow(queryData).then(function(resp) {
                expect(resp.data.length).to.equal(1);
            });
        });

        it('delete all reservations', function() {
            return deleteReservationsRecursively();
        });

        it('clean up tables', function() {
            return tablesController.deleteTable({
                table_no: maxTableNo
            }).then(function(resp) {
                expect(resp.status).to.equal('success');
                return tablesController.deleteTable({
                    table_no: maxTableNo + 1
                });
            }).then(function(resp) {
                expect(resp.status).to.equal('success');
            });
        });

    });

})();