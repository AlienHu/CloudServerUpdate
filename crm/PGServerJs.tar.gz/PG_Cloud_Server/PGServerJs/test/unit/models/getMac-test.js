'use strict';

// https://www.npmjs.com/package/lockfile
var chai = require('chai');

var expect = chai.expect;

describe('mac address Test UT', function() {
    this.timeout(100000);
    var macaddress = require('macaddress');
    var shelljs = require('shelljs');
    var os = require('os');
    var network = require('network');
    const macUtils = require('../../../common/macUtils');

    after(function() {

    });

    it('getMac', function(done) {
        require('getmac').getMac(function(err, macAddress) {
            console.log(macAddress);
            done();
        });
    });

    it('os', function() {
        console.log(process.platform);
    });

    it('test1', function() {
        //    macaddress.getMac(function(err, macAddress) {
        //        if (err) throw err
        //        console.log(macAddress)
        //    })

        //        var NetworkInfo = require('simple-ifconfig');
        //        var networking = new NetworkInfo();
        //        networking.listInterfaces()
        //            .then(console.log)
        //            .catch(console.error);
        macaddress.all(function(err, all) {
            console.log(JSON.stringify(all, null, 2));
        });
    });

    it('test2', function(done) {
        // var ipConfigVal = shelljs.exec('ipconfig /all');
        //console.log("ipconfig");
        console.log(os.networkInterfaces({
            all: true
        }));
        network.get_interfaces_list(function(err, list) {
            console.log(list);
            done();
        });
    });

    it('generateKey', function() {
        var shelljs = require('shelljs');
        var ipConfigOutput = shelljs.exec('ipconfig /all');

        var out = ipConfigOutput.stdout.trim().split(': ');
        var macAddresses = [];
        var adapters = [];
        for (var i = 0; i < out.length; i++) {
            var tempLength = 0;
            var adapterName = "";
            if (-1 < out[i].indexOf('adapter')) {
                var adapterHead = out[i];
                adapterName = adapterHead.replace(/^\s+|\s+$/g, '');
                adapterName = adapterName.substring(adapterName.indexOf(" "));
                adapterName = adapterName.replace(/\s+/g, ' ').trim();
                adapterName = adapterName.substring(0, adapterName.indexOf(":"));
                //console.log(adapterName + " \n");
                var macName = {};
                macName.name = adapterName;
                adapters.push(macName);
            }

            if (-1 < out[i].indexOf('Phy')) {
                var macAdd = {};
                macAdd.value = out[i + 1].substr(0, 17);
                macAddresses.push(macAdd);
                /*
                for (var j = i; j > tempLength; j--) {
                    if (-1 < out[i].indexOf('Ethernet')) { }
                }
                */

            }

        }
        /*
        console.log("\n\n");
        console.log(macAddresses);
        console.log("\n\n");
        console.log(adapters);
        console.log("\n\n");
        */
        var mac = [];
        // merge both array
        for (var index = 0; index < adapters.length; index++) {
            var temp = {};
            temp.name = adapters[index].name;
            temp.address = macAddresses[index].value;
            mac.push(temp);
        }
        console.log(mac);

        //    out.forEach(function(data) {
        //        if (data.indexOf('Phy')) {

        //        }
        //        var tmp = data.split('Phy');
        //        var i = tmp[0].indexOf('Phy');
        //        if (i < 0 && tmp[0].indexOf("00-00-00-00-00-00-00-E0"))
        //            macAddresses.push(tmp[0].split('\r\n   ')[0]);
        //    });

        //console.log(macAddresses);
    });

    it('macUtils getMacAddressArray', function() {
        console.log(macUtils.getMacAddressArray());
    });

    it('macUtils test macAddress', function() {
        let macAddress = macUtils.getMacAddress();
        console.log(macAddress);
        macAddress = macAddress.replace(/:/gi, '-');
        console.log(macAddress);
    });

});