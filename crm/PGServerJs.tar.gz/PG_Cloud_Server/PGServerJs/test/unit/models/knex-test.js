   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;

   var knex = require('knex')({
       client: 'sqlite3',
       connection: {
           filename: "/home/rg/pg/ws/profitguru/PGServerJs/sqlLiteDb/retail_profitguru.sqlite"
       },
       useNullAsDefault: true,
       debug: true
   });

   describe('Query Interface UT', function() {
       this.timeout(500000);

       before(function() {

       });
       //SELECT type, sql FROM sqlite_master WHERE tbl_name='profitGuru_sales_items' ;
       it('test1 ', function() {

           return knex.schema.table('profitGuru_sales_items', function(table) {
               console.log(table);
               return table.dropColumn('purchasePrice');
           }).then(function(resp) {
               console.log('hello');
               console.log(resp);
           }).then(function(resp) {
               //    done();
           }).catch(function(err) {
               console.log(err);
               //    done();
           });

           console.log('world2');

       });

       it('raw query test', function() {
           return knex.raw("CREATE TABLE \"profitGuru_categories\" (\"id\" INTEGER PRIMARY KEY AUTOINCREMENT, \"name\" VARCHAR(255) NOT NULL, \"description\" VARCHAR(255), \"createdAt\" DATETIME NOT NULL, \"updatedAt\" DATETIME NOT NULL, \"deletedAt\" DATETIME);").then(function(resp) {
               console.log(resp);
           }).catch(function(err) {
               console.log(err);
           });
       });

       it.only('list all tables', function() {
           return knex.raw("SELECT name FROM sqlite_master WHERE type='table';").then(function(resp) {
               console.log(resp);
           }).catch(function(err) {
               console.log(err);
           });
       });

   });

   /**
    *     var knex = require('knex')({
        client: 'sqlite3',
        connection: {
            filename: "/home/rg/pg/ws/profitguru/PGServerJs/sqlLiteDb/retail_profitguru.sqlite"
        },
        useNullAsDefault: true,
        debug: true
    });

    function createTable() {
        knex.schema.createTable('users2', function(table) {
                console.log("creating");
                table.increments('id').primary();
                table.string('username');
                table.string('password');
                table.timestamps();
            })
            .then((resp) => {
                console.log(resp);
            })
            .catch((error) => {
                console.log(error);
            });
    }

    function addColumn() {
        console.log('add column');
        knex.schema.table('users2', function(table) {
                table.string('first_name5221');
                table.string('last_name2521');
                console.log('add column ode');
            }).then(() => {})
            .catch((error) => {
                console.log(error);
            });;
    }

    function removeColumn() {
        console.log('remove column');
        knex.schema.table('users2', function(table) {
                table.dropColumn('username');
            }).then(() => {})
            .catch((error) => {
                console.log(error);
            });
    }

    function changeAttribute() {

    }

    // createTable();
    // addColumn();
    removeColumn();
    */