   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   const coreDBInstancce = couchDBUtils.getCoreCouchDB();
   const usersDBInstance = couchDBUtils.getUserCouchDB();
   const mainDBInstance = couchDBUtils.getMainCouchDB();
   const couchDbManager = require('../../../dbManagers/couchDbManager');
   const migrationHandler = require('../../../couchDb/migrationHandler');

   describe('Migration Tests', function() {
       this.timeout(200000);

       before(function() {
           return couchDbManager.initCouchDb(false);
       });

       it('down', async function() {
           await migrationHandler.migrate('201709080000000-showMRP.js');
           var params = {};

           let allElementsDocs = await couchDBUtils.getAllDocsByType('customer', mainDBInstance);
           for (let i = 0; i < allElementsDocs.length; i++) {
               expect(allElementsDocs[i].doc.hasOwnProperty('company_name')).to.equal(false);
               expect(allElementsDocs[i].doc.hasOwnProperty('agency_name')).to.equal(false)
           }

       });

       it('up', async function() {
           //userentitlements
           //users
           await migrationHandler.migrate('201709090000000-customerCompany.js');
           var params = {};
           let allElementsDocs = await couchDBUtils.getAllDocsByType('customer', mainDBInstance);
           for (let i = 0; i < allElementsDocs.length; i++) {
               expect(allElementsDocs[i].doc.hasOwnProperty('company_name')).to.equal(true);
               expect(allElementsDocs[i].doc.hasOwnProperty('agency_name')).to.equal(true);
           }
       });

   });