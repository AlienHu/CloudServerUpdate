   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   const coreDBInstancce = couchDBUtils.getCoreCouchDB();
   const usersDBInstance = couchDBUtils.getUserCouchDB();
   const couchDbManager = require('../../../dbManagers/couchDbManager');
   const migrationHandler = require('../../../couchDb/migrationHandler');

   describe('Migration Tests', function() {
       this.timeout(200000);

       before(function() {
           return couchDbManager.initCouchDb(false);
       });

       let props = ['transCounter', 'promoCounter', 'transQuota', 'promoQuota'];

       it('down', async function() {
           await migrationHandler.migrate('201710191100000-credit.js');

           let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
           for (let i = 0; i < props.length; i++) {
               expect(applicationSettings.enableSMS.hasOwnProperty(props[i])).to.equal(true);
               expect(applicationSettings.smsCounter.hasOwnProperty(props[i])).to.equal(false);
           }
       });

       it('up', async function() {
           await migrationHandler.migrate('201711022030000-smsCounter.js');
           let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
           for (let i = 0; i < props.length; i++) {
               expect(applicationSettings.enableSMS.hasOwnProperty(props[i])).to.equal(false);
               expect(applicationSettings.smsCounter.hasOwnProperty(props[i])).to.equal(true);
           }
       });

   });