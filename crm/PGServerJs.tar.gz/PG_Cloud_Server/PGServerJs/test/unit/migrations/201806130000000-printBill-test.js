'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
let nanoClients = params.nanoClients;
let nanoCore = nanoClients.coredb;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const coreDBInstancce = couchDBUtils.getCoreCouchDB();
const usersDBInstance = couchDBUtils.getUserCouchDB();
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');
const mainDBInstance = couchDBUtils.getMainCouchDB();

describe('Migration Tests', function() {
    this.timeout(200000);

    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    it('down', async function() {
        await migrationHandler.migrate('201805030000000-tableNumber-test.js');

        let allTableDocs = await couchDBUtils.getAllDocsByType('table', mainDBInstance);
        for (var i = 0; i < allTableDocs.length; i++) {
            let tableDoc = allTableDocs[i].doc;
            expect((tableDoc.printedOrder == undefined)).to.equal(true);
        }
    });

    it('up', async function() {
        await migrationHandler.migrate('201806130000000-printBill.js');
        var applicationSetting = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
        let allTableDocs = await couchDBUtils.getAllDocsByType('table', mainDBInstance);
        for (var i = 0; i < allTableDocs.length; i++) {
            let tableDoc = allTableDocs[i].doc;
            expect((tableDoc.isOnlyPrintBill == undefined)).to.equal(true);
        }
        if (applicationSettings.terminalConfigs) {
            let salesConfigIdx = applicationSettings.terminalConfigs.indexOf('salesConfig');
            expect((salesConfigIdx == -1)).to.equal(true);
        }

    });

});