(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const migrationHandler = require('../../../couchDb/migrationHandler');
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    const licenceDBInstance = couchDBUtils.getLicenceDB();

    /**
     * Note: In this test it is down-up
     * Creating data, going down, then going up
     * This way actual validations can happen
     */

    describe('Licence Migration UTs  ', function(done) {

        this.timeout(100000);
        before(async function() {
            await couchDbManager.initCouchDb(true);
        });

        after(function() {

        });

        var crypto = require('crypto'),
            algorithm = 'aes-256-ctr';

        function decryptLicence(thisEncLicence) {

            var decipher, decLicence;
            if (thisEncLicence.candClientId) {
                decipher = crypto.createDecipher(algorithm, thisEncLicence.candClientId);
                decLicence = decipher.update(thisEncLicence.enDeviceInfo, 'hex', 'utf8');
            } else if (thisEncLicence.clientId) {
                decipher = crypto.createDecipher(algorithm, thisEncLicence.clientId);
                decLicence = decipher.update(thisEncLicence.enlicence, 'hex', 'utf8');
            } else {
                console.log('No Id for licence decryption');
            }

            decLicence += decipher.final('utf8');
            decLicence = JSON.parse(decLicence);
            return decLicence;
        }

        it('down test', async function() {
            await migrationHandler.migrate('201708210000000-purchase.js');

            let licDoc;
            try {
                licDoc = await couchDBUtils.getDoc('profitGuruServerLicence_', licenceDBInstance, 'propagate');
            } catch (error) {
                return;
            }
            let decLic = decryptLicence(licDoc);
            expect(decLic.hasOwnProperty('cloudCouch')).to.equal(false);

        });

        it('up test', async function() {

            await migrationHandler.migrate('201708220000000-licence.js');
            let licDoc
            try {
                licDoc = await couchDBUtils.getDoc('profitGuruServerLicence_', licenceDBInstance, 'propagate');
            } catch (error) {
                return;
            }

            let decLic = decryptLicence(licDoc);
            expect(decLic.hasOwnProperty('cloudCouch')).to.equal(true);
        });

    });

})();