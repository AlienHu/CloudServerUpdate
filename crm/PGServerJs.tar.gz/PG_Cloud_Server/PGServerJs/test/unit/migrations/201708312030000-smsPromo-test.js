   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   const coreDBInstancce = couchDBUtils.getCoreCouchDB();
   const usersDBInstance = couchDBUtils.getUserCouchDB();
   const couchDbManager = require('../../../dbManagers/couchDbManager');
   const migrationHandler = require('../../../couchDb/migrationHandler');

   describe('Migration Tests', function() {
       this.timeout(200000);

       before(function() {
           return couchDbManager.initCouchDb(false);
       });

       it('down', async function() {
           await migrationHandler.migrate('201708301630000-sendInvoicePdf.js');
           var params = {};
           let allUsersDoc = [];
           let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
           for (var i = 0; i < allUsers.length; i++) {
               allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
               expect(allUsers[i].value.roles[0].hasOwnProperty('promo')).to.equal(false);
           }
           let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
           expect(applicationSettings.enableSMS.hasOwnProperty('creditSMS')).to.equal(false);
           expect(applicationSettings.enableSMS.hasOwnProperty('saleSMS')).to.equal(false);
           expect(applicationSettings.enableSMS.hasOwnProperty('promoSMS')).to.equal(false);
       });

       it('up', async function() {
           //userentitlements
           //users
           await migrationHandler.migrate('201708312030000-smsPromo.js');
           var params = {};
           let allUsersDoc = [];
           let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
           for (var i = 0; i < allUsers.length; i++) {
               allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
               expect(allUsers[i].value.roles[0].hasOwnProperty('promo')).to.equal(true);
               expect(allUsers[i].value.roles[0].promo.hasOwnProperty('sendSMS')).to.equal(true);
           }
           let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
           expect(applicationSettings.enableSMS.hasOwnProperty('creditSMS')).to.equal(true);
           expect(applicationSettings.enableSMS.hasOwnProperty('saleSMS')).to.equal(true);
           expect(applicationSettings.enableSMS.hasOwnProperty('promoSMS')).to.equal(true);
       });

   });