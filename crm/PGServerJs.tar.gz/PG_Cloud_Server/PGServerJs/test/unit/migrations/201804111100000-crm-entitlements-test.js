'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const coreDBInstancce = couchDBUtils.getCoreCouchDB();
const usersDBInstance = couchDBUtils.getUserCouchDB();
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');

describe('Migration Tests', function() {
    this.timeout(200000);

    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    it('down', async function() {
        await migrationHandler.migrate('201804020000000-defaultUnitSetting.js');
        var params = {};
        let allUsersDoc = [];
        let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
        for (var i = 0; i < allUsers.length; i++) {
            allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
            expect(allUsers[i].value.roles[0].hasOwnProperty('crm')).to.equal(false);
        }
        let allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', coreDBInstancce, 'propogate');
        expect(allowedFeatures.hasOwnProperty('crm')).to.equal(false);
    });

    it('up', async function() {
        await migrationHandler.migrate('201804111100000-crm-entitlements.js');

        var params = {};
        let allUsersDoc = [];
        let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
        for (var i = 0; i < allUsers.length; i++) {
            allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
            expect(allUsers[i].value.roles[0].hasOwnProperty('crm')).to.equal(true);
        }

        let allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', coreDBInstancce, 'propogate');
        console.log(allowedFeatures);
        expect(allowedFeatures.hasOwnProperty('crm')).to.equal(true);
    });

});