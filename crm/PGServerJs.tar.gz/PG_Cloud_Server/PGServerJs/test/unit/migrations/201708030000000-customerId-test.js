(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const migrationHandler = require('../../../couchDb/migrationHandler');
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    const coreDBInstancce = couchDBUtils.getCoreCouchDB();
    const mainDBInstance = couchDBUtils.getMainCouchDB();

    /**
     * Note: In this test it is down-up
     * Creating data, going down, then going up
     * This way actual validations can happen
     */

    describe('Customer Id Migration UTs  ', function(done) {

        this.timeout(100000);
        before(async function() {
            await couchDbManager.initCouchDb(true);
            let commonUtils2 = require('../../common/commonUtils2');
            let commonWorker = require('../../../controllers/workers/commonWorker');
            commonWorker.setFreeze(true);
            //Creating some customers
            await commonUtils2.createSomeData(true, true);
        });

        after(function() {

        });

        async function validateTotalAndInitalCreditBalance(type, bExpect) {
            let allElementsDocs = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
            for (let i = 0; i < allElementsDocs.length; i++) {
                expect(allElementsDocs[i].doc.hasOwnProperty('total')).to.equal(bExpect);
                expect(allElementsDocs[i].doc.hasOwnProperty('initial_credit_balance')).to.equal(bExpect);
            }
        }

        it('down test', async function() {
            await migrationHandler.migrate('201708020000000-hsnItemType.js');

            await validateTotalAndInitalCreditBalance('customer', false);
            await validateTotalAndInitalCreditBalance('supplier', false);
            let allSaleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
            for (let i = 0; i < allSaleDocs.length; i++) {
                let pendingCustomersUpdates = allSaleDocs[i].doc.status.customers;
                for (let customerDocId in pendingCustomersUpdates) {
                    if (pendingCustomersUpdates[customerDocId].doc) {
                        expect(pendingCustomersUpdates[customerDocId].doc.hasOwnProperty('_id')).to.equal(false);
                    }
                }
            }

            let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance);
            for (let i = 0; i < allPurchaseDocs.length; i++) {
                let doc = allPurchaseDocs[i].doc;
                expect(doc.status.hasOwnProperty('suppliers')).to.equal(false);
            }

        });

        it('up test', async function() {
            await migrationHandler.migrate('201708030000000-customerId.js');

            await validateTotalAndInitalCreditBalance('customer', true);
            await validateTotalAndInitalCreditBalance('supplier', true);

            let allSaleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
            for (let i = 0; i < allSaleDocs.length; i++) {
                let pendingCustomersUpdates = allSaleDocs[i].doc.status.customers;
                for (let customerDocId in pendingCustomersUpdates) {
                    if (pendingCustomersUpdates[customerDocId].doc) {
                        expect(pendingCustomersUpdates[customerDocId].doc.hasOwnProperty('_id')).to.equal(true);
                        expect(pendingCustomersUpdates[customerDocId].doc._id).to.equal(customerDocId);
                    }
                }
            }

            let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', mainDBInstance);
            for (let i = 0; i < allPurchaseDocs.length; i++) {
                let doc = allPurchaseDocs[i].doc;
                expect(doc.status.hasOwnProperty('suppliers')).to.equal(true);
                let pendingSuppliersUpdates = doc.status.suppliers;
                let supplierDocId = 'supplier_' + doc.receivings_info.supplier_id;

                expect(pendingSuppliersUpdates.hasOwnProperty(supplierDocId)).to.equal(true);
                let updateDoc = pendingSuppliersUpdates[supplierDocId].doc;
                if (updateDoc) {
                    expect(updateDoc._id).to.equal(supplierDocId);
                    expect(updateDoc.hasOwnProperty('total')).to.equal(true);
                    expect(updateDoc.hasOwnProperty('balance')).to.equal(true);
                }
            }

        });

    });

})();