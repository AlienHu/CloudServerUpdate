(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });
    var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
    var coreDBInstance = couchDBUtils.getUserCouchDB();
    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    var chai = require("chai");

    const couchDbManager = require('../../../dbManagers/couchDbManager');
    const migrationHandler = require('../../../couchDb/migrationHandler');

    describe('Elemets Controller UTs  ', function(done) {

        this.timeout(100000);
        before(function() {
            //return couchDbManager.initCouchDb(true);
        });

        //Todo: Delete all Fs created. Get proper path of logDir
        after(function() {

        });

        beforeEach(function() {});

        it('up test', async function() {
            await migrationHandler.migrate('201707241314000-removeDistributorEmailFromUserInfo.js');
            //query appsettingjson and make sure key is presne
            var params = {};
            let allUsers = await couchDBUtils.getView('employees', 'all', params, coreDBInstance);

            for (var i = 0; i < allUsers.length; i++) {
                expect(allUsers[i].value.isDistributor).to.equal(undefined);
                expect(allUsers[i].value.distributorEmail).to.equal(undefined);
            }

        });

        it('down test', async function() {

            await migrationHandler.migrate('20170720131500-appDistributorEmail.js');

            var params = {};
            let allUsers = await couchDBUtils.getView('employees', 'all', params, coreDBInstance);

            for (var i = 0; i < allUsers.length; i++) {
                if (allUsers[i].value.roles[1] === 'admin') {
                    expect(allUsers[i].value.isDistributor).to.equal(false);
                    expect(allUsers[i].value.distributorEmail).to.equal('');
                }
            }
        });

    });

})();