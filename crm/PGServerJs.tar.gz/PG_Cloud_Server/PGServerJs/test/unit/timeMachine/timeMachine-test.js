   'use strict';
   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   const chai = require("chai");
   const chaiAsPromised = require("chai-as-promised");

   chai.use(chaiAsPromised);
   chai.should();
   const expect = chai.expect;

   const couchDbManager = require('../../../dbManagers/couchDbManager');
   const couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   const mainDBInstance = couchDBUtils.getMainCouchDB();

   let testUtils;

   describe('Time Machine UTs', function() {

       this.timeout(999999999);

       before(function() {
           return couchDbManager.initCouchDb(true).then(resp => {
               testUtils = require('../../common/commonUtils2');
           });
       });

       async function testElement(noOfElements, type) {
           let resp = await testUtils.createElements(type, {}, noOfElements);
           expect(resp).to.equal(noOfElements);
           let elements = await couchDBUtils.getAllDocsByType(type, mainDBInstance);
           expect(elements.length).to.greaterThan(noOfElements - 1);
       }

       it('customers create test', async function() {
           await testElement(100, 'customer');
       });

       it('suppliers create test', async function() {
           await testElement(100, 'supplier');
       });

       it('preprocess items', async function() {
           await testUtils.preProcessItems(1000);
       });

       it('items create test', async function() {
           await testElement(100, 'item');
       });

       it('receivings test', async function() {
           await testUtils.makeTransactions('receiving', 100, 1498144485000);
       });

       it('sales test', async function() {
           await testUtils.makeTransactions('sale', 1, 1498144485000);
       });

   });