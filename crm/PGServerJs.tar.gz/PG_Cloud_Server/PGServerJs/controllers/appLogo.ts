
import * as couchDBUtils from './common/CouchDBUtils';
import * as logger from '../common/Logger';
const coreDBInstance: any = couchDBUtils.getCoreCouchDB();
import { apiResponse } from "./crm";

export let save = async function (base64: string): Promise<apiResponse> {
    logger.info("*** appLogo.save");
    let response: apiResponse = {} as apiResponse;
    let bCreate: boolean = false;
    let appLogo;
    try {
        appLogo = await couchDBUtils.getDoc('appLogo', coreDBInstance, 'propagate');
    } catch (error) {
        if (error.reason === 'missing' || error.reason === 'deleted') {
            logger.info('appLogo is missing creating appLogo ...');
            bCreate = true;
        }
    }
    try {
        if (bCreate) {
            appLogo = {
                _id: 'appLogo',
                logo: base64
            }
        } else {
            appLogo.logo = base64;
        }
        await couchDBUtils.createOrUpdate(appLogo, coreDBInstance);
    } catch (error) {
        logger.error(error);
        response.error = 'logo save failed';
        throw response;
    }

    response.msg = 'Logo saved';
    return response;

}
