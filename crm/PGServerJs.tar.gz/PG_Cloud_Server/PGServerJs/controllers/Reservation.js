/*
 *       Reservation should have customer phone number/name. If customer doesn't exist. Should be added to customers.
 *       Search based on customers phone number/name
 *       Todo: Ideally we should throw errors in catch so that the return goes to the catch of parent                
 *       Todo: cleanup Repetitive REST APIs
 *       Todo: if some parameter is missing should we throw exception?
 *       Todo: Couchdb sync is not required and not used. Should check if it is really used   
 */
let validator = require('../schema/validator.js')
let restaurantApi = require('../schema/apis/restaurant.js')
var Reservation = function() {
    var q = require('q');
    var moment = require('moment');
    require('errors');

    var _self = this;
    // var reservationsModel = require('../models').profitGuru_table_reservation;
    var couchDBUtils = require('./common/CouchDBUtils');
    var couchDB = couchDBUtils.getMainCouchDB();

    /*
     *      Reservation->saveReservationRestApi
     *      Todo: reservationData.employee get from employee model
     */

    this.saveReservation = function(requestData) {
        var response = {
            err: '',
            status: 'failed'
        };

        var reservationData = {};
        reservationData.table_no = requestData.table_no;
        reservationData.booking_Call_Time = moment().format();
        reservationData.book_time = moment(requestData.bookingTime).format();
        reservationData.booking_end_time = moment(requestData.bookingEndTime).format();
        reservationData.customer_contact_info = requestData.contactInfo;
        reservationData.employee = '';
        reservationData.Description = requestData.Reservation_desc;

        let tempResp = validator.validateApiRequest(reservationData, restaurantApi.saveReservation);
        if (tempResp.message) {
            response.err = tempResp.message;
            return response;
        }
        reservationData = tempResp.data;

        return reservationsModel.create(reservationData).then(function(res) {
            response.status = 'success';
            response.reservation_id = res.dataValues.reservation_id;
            var reservationJson4Couch = reservationsModel.getJson4Couch(response.reservation_id, reservationData);
            return couchDBUtils.addReservation(reservationData.table_no, reservationJson4Couch, couchDB);
        }).then(function() {
            response.status = 'success';
            return response;
        }).catch(function(err) {
            response.err = err;

            return response;
        });
    };

    this.selectTable = function(requestData) {
        var response = {
            err: '',
            status: 'failed'
        };
        let tempResp = validator.validateApiRequest(requestData, restaurantApi.selectTable);
        if (tempResp.message) {
            response.err = tempResp.message;
            return response;
        }
        requestData = tempResp.data;
        var book_time = moment(requestData.bookingTime).format();
        var booking_end_time = moment(requestData.bookingEndTime).format();

        var params = {};
        params.where = {};
        params.where.book_time = {
            $lt: booking_end_time
        };
        params.where.booking_end_time = {
            $gt: book_time
        };

        response.data = [];
        return reservationsModel.findAll(params).then(function(resp) {
            for (var i = 0; i < resp.length; i++) {
                response.data.push(resp[i].dataValues);
            }
            response.status = 'success';
            return response;
        }).catch(function(err) {
            response.err = err;
            return response;
        });
    };

    function getMinimumReservationDuration(applicationSettings) {
        var minDuration = 30;
        if (applicationSettings) {
            minDuration = applicationSettings.tableReservations.MinReservationDuration;
        }

        return minDuration;
    }

    this.minimumReservationDuration = function(requestData, applicationSettings) {
        var response = {};
        response.MinReservationDurationData = {
            MinReservationDuration: getMinimumReservationDuration(applicationSettings)
        };

        return Promise.resolve(response);
    };

    /*
     *       Todo: Get Employee's name
     */
    this.getReservationDetails = function(requestData) {
        var response = {
            err: '',
            status: 'failed'
        };
        let tempResp = validator.validateApiRequest(requestData, restaurantApi.getReservationDetails);

        if (tempResp.message) {
            response.err = tempResp.message;
            return response;
        }
        requestData = tempResp.data;

        response.data = [];

        var params = {};
        params.where = {};
        params.where.book_time = {
            $gte: moment().startOf('day').format()
        };
        return reservationsModel.findAll(params).then(function(resp) {
            for (var i = 0; i < resp.length; i++) {
                response.data.push(resp[i].dataValues);
                response.data[i].empName = 'Roland Garros';
            }
            response.status = 'success';
            return response;
        }).catch(function(err) {
            response.err = err;
            return response;
        });

    };

    this.getReservationDetails4TableColorChange = function(requestData) {
        var response = {
            err: '',
            status: 'failed'
        };
        response.data = [];

        var params = {};
        params.where = {};
        params.where.book_time = {
            $between: [moment().startOf('day').format(), moment().endOf('day').format()]
        };
        return reservationsModel.findAll(params).then(function(resp) {
            for (var i = 0; i < resp.length; i++) {
                response.data.push(resp[i].dataValues);
            }
            response.status = 'success';
            return response;
        }).catch(function(err) {
            response.err = err;
            return response;
        });
    };

    //Todo: table_no is passed as string from front-end. Correct this everywhere
    this.checkReservation4table = function(requestData) {
        /**
         * TO-DO:Restaurant: changed response data formate from response [] to response.data[]
         * handle in ui
         */

        var response = {
            err: '',
            status: 'failed',
            data: []
        };
        let tempResp = validator.validateApiRequest(requestData, restaurantApi.checkReservation4table);

        if (tempResp.message) {
            response.err = tempResp.message;
            return response;
        }
        requestData = tempResp.data;
        //var response = []; what should be the response format?

        var params = {};
        params.where = {};
        params.where.book_time = {
            $between: [moment().startOf('day').format(), moment().endOf('day').format()]
        };
        params.where.table_no = requestData.tableNo;

        return reservationsModel.findAll(params).then(function(resp) {
            for (var i = 0; i < resp.length; i++) {
                response.data.push(resp[i].dataValues);
            }
            response.status = 'success';
            return response;
        }).catch(function(err) {
            console.log(err);
            response.err = err;
            return response;
        });
    };

    this.checkAlreadyReserved = function(requestData, applicationSettings) {
        var response = {
            err: '',
            status: 'failed'
        };
        response.data = [];
        return Promise.resolve(response);
        //TO-DO:restauraunt fix in validate Function
        requestData.table_no = parseInt(requestData.table_no);
        let tempResp = validator.validateApiRequest(requestData, restaurantApi.checkAlreadyReservedRestApi);
        if (tempResp.message) {
            response.err = tempResp.message;
            return response;
        }

        var minDuration = getMinimumReservationDuration(applicationSettings);
        var params = {};
        params.where = {};
        params.where.book_time = {
            $lt: moment().add(parseInt(minDuration), 'minutes').format()
        };
        params.where.booking_end_time = {
            $gt: moment().format()
        };
        params.where.table_no = requestData.table_no;

        return reservationsModel.findAll(params).then(function(resp) {
            for (var i = 0; i < resp.length; i++) {
                response.data.push(resp[i].dataValues);
            }
            response.status = 'success';
            return response;
        }).catch(function(err) {
            response.err = err;
            return response;
        });
    };

    /*
     *       Todo: Duplicate of SelectTable. I don't understand the difference and necessity
     */
    this.reservationWindow = function(requestData) {
        var response = {
            err: '',
            status: 'failed'
        };
        let tempResp = validator.validateApiRequest(requestData, restaurantApi.reservationWindow);

        if (tempResp.message) {
            response.err = tempResp.message;
            return response;
        }
        requestData = tempResp.data;
        var response = {};
        response.data = [];

        var params = {};
        params.where = {};
        params.where.book_time = {
            $between: [moment(requestData.starttime).format(), moment(requestData.endtime).format()]
        };

        return reservationsModel.findAll(params).then(function(resp) {
            for (var i = 0; i < resp.length; i++) {
                response.data.push(resp[i].dataValues);
            }
            response.status = 'success';
            return response;
        }).catch(function(err) {
            response.err = err;
            return response;
        });
    };

    this.deleteReservation = function(requestData) {
        var response = {
            err: '',
            status: 'failed'
        };
        let tempResp = validator.validateApiRequest(requestData, restaurantApi.deleteReservation);

        if (tempResp.message) {
            response.err = tempResp.message;
            return response;
        }
        requestData = tempResp.data;
        var reservationId = requestData.reservation_id;
        var tableNo = -1;
        var query = {
            where: {
                reservation_id: reservationId
            }
        };

        return reservationsModel.findById(reservationId).then(function(resp) {
            tableNo = resp.get({
                plain: true
            }).table_no;
            return reservationsModel.destroy(query);
        }).then(function() {
            response.status = 'success';

            var params = {
                'reservation_id': reservationId
            };
            return couchDBUtils.deleteReservation(tableNo, params, couchDB);
        }).then(function() {
            response.status = 'success';

            return response;
        }).catch(function(err) {
            response.status = 'failed';
            response.err = err;
            return response;
        });
    };

};

module.exports = new Reservation();