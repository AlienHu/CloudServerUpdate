var Utils = function() {
    'use strict';

    require('errors');
    var moment = require('moment');
    var logger = require('../../common/Logger');
    const parentUtils = require('../../common/Utils');
    this.pgTimeOut = parentUtils.pgTimeOut;

    var _self = this;

    this.roundOffNumber = function(number, applicationSettings, rMethod) {
        if (typeof(number) === 'string') {
            number = parseFloat(number.replace(',', ''));
        }
        var value;
        var roundOffMethod = rMethod ? rMethod : applicationSettings.numberFormat.roundOffMethod;
        // var rDigits = rMethod ? 2 : 
        if (roundOffMethod === 'upward') {
            value = Math.ceil(number);
        } else if (roundOffMethod === 'downward') {
            value = Math.floor(number);
        } else if (roundOffMethod === 'round') {
            value = Math.round(number)
        } else {
            value = number.toFixed(applicationSettings.numberFormat.decimalDigits);
        }
        value = parseFloat(value);
        return value;

    }

    this.getSMSMessage = function(msg, jsonParam) {
        if (!jsonParam) {
            return msg;
        }
        var res = msg;
        if (jsonParam.saleId) res = res.replace("SALEID", jsonParam.saleId);
        if (jsonParam.amount) res = res.replace("AMOUNT", jsonParam.amount);
        if (jsonParam.company) res = res.replace("COMPANY", jsonParam.company);
        if (jsonParam.customer) res = res.replace("CUSTOMER", jsonParam.customer);
        if (jsonParam.date) res = res.replace("DATE", jsonParam.date);
        if (jsonParam.short_url) res = res.replace("URL", jsonParam.short_url);
        //add url
        return res;
    }

    this.isUndefinedOrNull = function(arg) {
        return arg === undefined || arg === '' || arg === null;
    };

    this.isUndefinedOrNull2 = function(arg) {
        return arg === undefined || arg === null;
    };

    function isObject(obj) {
        return obj === Object(obj);
    }

    this.compareArray = function(key, array) {
        var bMatches = false;
        for (var i = 0; i < array.length; i++) {
            if (array[i] === key) {
                bMatches = true;
                break;
            }
        }

        return bMatches;
    };

    /**
     *  What is the cost of cloning?
     *  What is the best practice?
     *  https://stackoverflow.com/questions/122102/what-is-the-most-efficient-way-to-deep-clone-an-object-in-javascript/5344074#5344074
     */
    this.clone = function(obj) {
        if (null == obj || "object" != typeof obj) {
            return obj
        };

        let copy = JSON.parse(JSON.stringify(obj));
        return copy;
    };

    this.deleteIfNotNull = function(key, obj) {
        if (obj[key]) {
            delete obj[key];
        }
    };

    this.deleteIfNotNullArr = function(keyArr, obj) {
        for (let i = 0; i < keyArr.length; i++) {
            _self.deleteIfNotNull(keyArr[i], obj);
        }
    };

    this.deleteKeyIfExist = function(key, obj) {
        if (obj.hasOwnProperty(key)) {
            delete obj[key];
        }
    };

    this.deleteIfNoValue = function(key, obj) {
        if (obj.hasOwnProperty(key)) {
            if (!obj[key]) {
                delete obj[key];
            }
        }
    };

    this.getArrayLength = function(arr) {
        if (!arr) {
            return 0;
        } else {
            return arr.length;
        }
    };

    this.assignIfTrue = function(value, defaultValue) {
        if (value) {
            return value;
        } else {
            return defaultValue;
        }
    };

    this.assignifNotUndefined = function(value, defaultValue) {
        if (value !== undefined) {
            return value;
        } else {
            return defaultValue;
        }
    };

    //https://stackoverflow.com/questions/679915/how-do-i-test-for-an-empty-javascript-object
    this.isEmptyObject = function(obj) {
        if (obj && Object.keys(obj).length && obj.constructor === Object) {
            return false;
        }

        return true;
    };

    this.convertObjectToArray = function(obj) {
        var arr = [];
        for (var attr in obj) {
            if (obj.hasOwnProperty(attr)) {
                arr.push(obj[attr]);
            }
        }

        return arr;
    };

    this.copyDatabaseObject = function(obj1, obj2, excludeFieldsArray) {
        for (var key in obj1) {
            if (obj1.hasOwnProperty(key) && (excludeFieldsArray === undefined || (excludeFieldsArray && !_self.compareArray(key, excludeFieldsArray)))) {
                obj2[key] = obj1[key];
            }
        }
    };

    //This util function is written for couchdb sync
    this.copyObjectByFields = function(objSrc, objDst, arrFields) {
        if (_self.isUndefinedOrNull(arrFields)) {
            return _self.copyDatabaseObject(objSrc, objDst);
        }

        for (var i = 0; i < arrFields.length; i++) {
            if (objSrc.hasOwnProperty(arrFields[i])) {
                objDst[arrFields[i]] = objSrc[arrFields[i]];
            }
        }
    };

    this.copyObjectByFields2 = function(objSrc, objDst, srcFields, dstFields) {
        let srcFieldsLength = srcFields.length;
        if (srcFieldsLength !== _self.getArrayLength(dstFields)) {
            return;
        }

        for (var i = 0; i < srcFieldsLength; i++) {
            if (objSrc.hasOwnProperty(srcFields[i])) {
                objDst[dstFields[i]] = objSrc[srcFields[i]];
            }
        }
    };

    /**
     *      Todo: language files
     */
    this.getDateRangesJson = function() {
        var today = moment().startOf('day').format();
        var today_last_year = moment(today).subtract(1, 'years').format();
        var yesterday = moment(today).subtract(1, 'days').format();
        var six_days_ago = moment(today).subtract(6, 'days').format();
        var start_of_this_month = moment().startOf('month').format();
        var end_of_this_month = moment().endOf('month').format();
        var start_of_this_month_last_year = moment(start_of_this_month).subtract(1, 'years').format();
        var end_of_this_month_last_year = moment(end_of_this_month).subtract(1, 'years').format();
        var start_of_last_month = moment(start_of_this_month).subtract(1, 'months').format();
        var end_of_last_month = moment(start_of_last_month).endOf('month').format();
        var start_of_this_year = moment().startOf('year').format();
        var end_of_this_year = moment().endOf('year').format();
        var start_of_last_year = moment(start_of_this_year).subtract(1, 'years').format();
        var end_of_last_year = moment(start_of_last_year).endOf('year').format();
        var start_of_time = moment(today).subtract(50, 'years').format(); //can be done differently?

        var todayEnd = moment(today).endOf('day').format();
        var today_last_year_end = moment(today_last_year).endOf('day').format();
        var yesterdayEnd = moment(yesterday).endOf('day').format();

        var dateRangeJson = {};
        dateRangeJson[today + '/' + todayEnd] = "Today";
        dateRangeJson[today_last_year + '/' + today_last_year_end] = "Today Last Year";
        dateRangeJson[yesterday + '/' + yesterdayEnd] = "Yesterday";
        dateRangeJson[six_days_ago + '/' + todayEnd] = "Last 7 Days";
        dateRangeJson[start_of_this_month + '/' + todayEnd] = "This Month To Today";
        dateRangeJson[start_of_this_month + '/' + end_of_this_month] = "This Month";
        dateRangeJson[start_of_this_month_last_year + '/' + today_last_year_end] = "This Month To Today Last Year";
        dateRangeJson[start_of_this_month_last_year + '/' + end_of_this_month_last_year] = "This Month Last Year";
        dateRangeJson[start_of_last_month + '/' + end_of_last_month] = "Last Month";
        dateRangeJson[start_of_this_year + '/' + end_of_this_year] = "This Year";
        dateRangeJson[start_of_last_year + '/' + end_of_last_year] = "Last Year";
        dateRangeJson[start_of_time + '/' + todayEnd] = "All Time";

        return dateRangeJson;
    };

    var socketServer;
    this.setSocketServer = function(_socketServer) {
        socketServer = _socketServer;
    };

    this.sendSocketEvent = function(event, data) {
        if (socketServer) {
            try {
                logger.info('Sending Socket ' + event)
                socketServer.sockets.emit(event, data);
            } catch (err) {
                logger.error(err);
            }
        }
    };

};
module.exports = new Utils();