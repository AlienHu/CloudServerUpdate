"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const couchDBUtils = require("./common/CouchDBUtils");
const logger = require("../common/Logger");
const mainDBInstance = couchDBUtils.getMainCouchDB();
const CUSTOMER_TAGS = 'customers_tags';
exports.importElements = function (data) {
};
exports.updateTags = function (tags) {
    return __awaiter(this, void 0, void 0, function* () {
        //console.log("*** updateTags" + JSON.stringify(tags, null, 2));
        let allTagsDoc = {
            _id: CUSTOMER_TAGS,
            tags: []
        };
        try {
            allTagsDoc = yield couchDBUtils.getDocEx(CUSTOMER_TAGS, mainDBInstance);
        }
        catch (error) {
            // if (error.reason !== 'missing') {
            //     throw 'Tags get failed'
            // }
            logger.error("*** Missing doc, creating customer tags...");
        }
        try {
            let bUpdate = false;
            tags.forEach(function (tg) {
                if (allTagsDoc.tags.indexOf(tg) === -1) {
                    bUpdate = true;
                    allTagsDoc.tags.push(tg);
                }
            });
            if (bUpdate) {
                yield couchDBUtils.createOrUpdate(allTagsDoc, mainDBInstance);
            }
        }
        catch (error) {
            logger.error(error);
            throw "Tags update failed";
        }
        return 'Tags updated successfully';
    });
};
//# sourceMappingURL=ElementsEx.js.map