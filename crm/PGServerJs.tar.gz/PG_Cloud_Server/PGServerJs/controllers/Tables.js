var Tables = function() {
    require('errors');
    var _self = this;
    var couchDBUtils = require('./common/CouchDBUtils');
    var mainDBInstance = couchDBUtils.getMainCouchDB();
    var logger = require('../common/Logger');

    /*
     **       Tables->createTableRestApi
     **
     */

    this.createTable = async function(requestData) {
        var tableNo = requestData.table_no;
        var description = requestData.desc;

        var response = {};
        if (tableNo.length === 0) {
            response.status = 'Invalid Table Name';
            return response;
        }

        var jsonDoc = {
            _id: 'table_' + tableNo,
            orders: [],
            reservations: [],
            table_no: tableNo,
            maxOrderNo: 0
        };

        try {
            await couchDBUtils.create(jsonDoc, mainDBInstance, 1, 'propagate');
            response.status = 'success';
            return response;
        } catch (err) {
            if (err.statusCode == 409) {
                response.status = 'exists';
                return response;
            } else {
                logger.error(err);
                response.err = 'Internal Server Error';
                response.status = 'create table failed';
                throw response;
            }
        }

    };

    /**
     *      Todo: what if existing orders on this table? Clean up orders, sales also
     */
    this.deleteTable = async function(requestData) {
        var response = {};
        try {
            await couchDBUtils.delete({
                _id: 'table_' + requestData.table_no
            }, mainDBInstance);
            response.status = 'success';
            return response;
        } catch (err) {
            response.err = err;
            response.status = 'failed';
            return response;
        }
    };

};

module.exports = new Tables();