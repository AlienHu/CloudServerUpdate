let BPromise = require("bluebird");
let logger = require('../../common/Logger');
let responseUtil = require('../../common/responseJson');
let couchDBUtils = require('../common/CouchDBUtils');
let mainDBInstance = couchDBUtils.getMainCouchDB();
const commonWorker = require('../workers/commonWorker');

const lockUtils = require('../../common/lockUtils');
lockUtils.createLockDir('locks/purchase');
const lockPath = 'locks/purchase/purchase.lock';
const lockOptions = lockUtils.lockOptions();

const commonLib = require('./commonLib');
const utils = require('../common/Utils');
const CLONE = utils.clone;

const moment = require('moment');

const autoIncrementHelper = require('../common/autoIncrementHelper');
let maxSaleCreditPaymentId = autoIncrementHelper.getMaxSaleCreditPaymentId();
let maxReceivingCreditPaymentId = autoIncrementHelper.getMaxReceivingCreditPaymentId();

let creditPaymentsLib = function() {

    /**
     * ####
     *  CreditsTodo: Take care of round off values
     * ####
     * 1. Create New Sale Entry
     * 2. Update the parent sale pending_amount
     * 3. Update the parent sale payments information
     */

    /**
     *  let params = {
     *          customerId: selectedCustomerId,
     *          payments: {
     *              Cash: selectedCustomerHistory.pending_amount * 0.3,
     *              Cheque: selectedCustomerHistory.pending_amount * 0.2
     *          },
     *          pendingTransactions: selectedCustomerHistory.pendingTransactions
     *          comment: 'hello world',
     *           employeeId: 'admin'
     *      };
     */
    this.makeCustomerCreditPayment = async function(data) {

        if (!data.timeStamp) {
            data.timeStamp = parseInt(moment().format('x'));
        }

        function getInfoJson(total, pending_amount, sale_id) {
            //Todo automatically generate this array by quering for all columns
            let outputFields = ['sale_time', 'customer_id', 'employee_id', 'comment', 'invoice_number'];
            let inputFields = ['timeStamp', 'customerId', 'employeeId', 'comment', 'invoice_number'];

            let jsonData = {
                sale_id: sale_id,
                total: total,
                pending_amount: pending_amount
            };
            utils.copyObjectByFields2(data, jsonData, inputFields, outputFields);

            jsonData.type = 3;

            return jsonData;
        }

        let response = responseUtil.get2();
        try {
            let salesDoc = {};
            let payments = data.paymentsView;
            let paymentsDistributionResponse = getPaymentDistributions(payments, data.pendingTransactions);
            let excessPayment = paymentsDistributionResponse.excessPayment;
            let paymentDistribution = paymentsDistributionResponse.paymentDistribution;
            let parentIds = [];
            //Directly Object.keys(paymentDistribution) was giving strings. So manually converting to integer
            for (id in paymentDistribution) {
                if (paymentDistribution.hasOwnProperty(id)) {
                    parentIds.push(parseInt(id));
                }
            }

            await lockUtils.lockAsync(lockPath, CLONE(lockOptions));
            let sale_id = maxSaleCreditPaymentId + 1;
            //for couchdb
            salesDoc.sale_id = sale_id;
            salesDoc._id = commonLib.formatSaleCreditId(sale_id);
            salesDoc.sales_info = getInfoJson(0, -1 * excessPayment, sale_id);
            salesDoc.sales_info.type = 3;
            salesDoc.parentIds = parentIds;
            salesDoc.parentTotals = [];
            salesDoc.payments = payments;
            salesDoc.status = {
                status: 4,
                parentSalesTrans: {},
                customers: {}
            };

            let totalPaidAmt = getTotalPaymentAmount(payments);
            let customerDocId = 'customer_' + data.customerId;
            salesDoc.status.customers[customerDocId] = {
                status: 4,
                doc: {
                    _id: customerDocId,
                    total: 0,
                    balance: -totalPaidAmt,
                    timeStamp: data.timeStamp,
                    v: 1
                },
                v: 1
            }

            let paymentType = 'mixed';
            if (payments.length === 1) {
                paymentType = payments[0].payment_type;
            }

            for (let i = 0; i < parentIds.length; i++) {
                let parentId = parentIds[i];
                let amount = paymentDistribution[parentId];
                salesDoc.parentTotals.push(amount);

                let doc = getPaymentJsonForCouch(parentId, sale_id, paymentType, amount, data.timeStamp);
                salesDoc.status.parentSalesTrans[doc._id] = {
                    status: 4,
                    doc: doc
                }
            }

            commonWorker.setFreeze(true);
            // let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no'];
            // let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
            // salesDoc = await commonLib.encodeTransDoc(salesDoc, 'sale', infoFields, itemFields);
            await couchDBUtils.create(salesDoc, mainDBInstance);
            maxSaleCreditPaymentId++;
            await lockUtils.unlockAsync(lockPath);
            commonWorker.insertParentSalestrans(commonLib.formatSaleCreditId(sale_id), salesDoc.status.parentSalesTrans, salesDoc.status.customers);
            commonWorker.setFreeze(false);

            response.message = 'Payment Success';
            response.data.id = sale_id;
            response.employee = data.employeeId;
            return response;
        } catch (error) {
            await lockUtils.unlockAsync(lockPath);
            commonWorker.setFreeze(false);
            response.error = 'Payment Failed';
            logger.error(error);
            throw response;
        }
    };

    this.makeCreditPaymentForSupplier = async function(data) {

        if (!data.timeStamp) {
            data.timeStamp = parseInt(moment().format('x'));
        }

        function getInfoJson(total, pending_amount, id) {
            //Todo automatically generate this array by quering for all columns
            let outputFields = ['receiving_time', 'supplier_id', 'employee_id', 'comment', 'invoice_number'];
            let inputFields = ['timeStamp', 'supplierId', 'employeeId', 'comment', 'invoice_number'];

            let supplierJsonData = {
                receiving_id: id,
                total: total,
                pending_amount: pending_amount
            };
            let jsonData = supplierJsonData;
            utils.copyObjectByFields2(data, jsonData, inputFields, outputFields);

            jsonData.type = 3;

            return jsonData;
        }

        let response = responseUtil.get2();
        try {
            let purchaseDoc = {};
            let payments = data.paymentsView;
            let paymentsDistributionResponse = getPaymentDistributionsForReceivins(payments, data.pendingTransactions);
            let excessPayment = paymentsDistributionResponse.excessPayment;
            let paymentDistribution = paymentsDistributionResponse.paymentDistribution;
            let parentIds = [];
            //Directly Object.keys(paymentDistribution) was giving strings. So manually converting to integer
            for (id in paymentDistribution) {
                if (paymentDistribution.hasOwnProperty(id)) {
                    parentIds.push(parseInt(id));
                }
            }

            await lockUtils.lockAsync(lockPath, CLONE(lockOptions));
            let receiving_id = maxReceivingCreditPaymentId + 1;
            //for couchdb
            purchaseDoc.receiving_id = receiving_id;
            purchaseDoc._id = commonLib.formatReceivingCreditId(receiving_id);
            purchaseDoc.receivings_info = getInfoJson(0, -1 * excessPayment, receiving_id);
            purchaseDoc.receivings_info.type = 3;
            purchaseDoc.parentIds = parentIds;
            purchaseDoc.parentTotals = [];
            purchaseDoc.payments = payments;
            purchaseDoc.status = {
                status: 4,
                parentReceivingTrans: {},
                suppliers: {}
            };

            let paymentType = 'mixed';
            if (payments.length === 1) {
                paymentType = payments[0].payment_type;
            }

            for (let i = 0; i < parentIds.length; i++) {
                let parentId = parentIds[i];
                let amount = paymentDistribution[parentId];
                purchaseDoc.parentTotals.push(amount);

                let doc = getPurchasePaymentJsonForCouch(parentId, receiving_id, paymentType, amount, data.timeStamp);
                purchaseDoc.status.parentReceivingTrans[doc._id] = {
                    status: 4,
                    doc: doc
                }
            }

            let totalPaidAmt = getTotalPaymentAmount(payments);
            let supplierDocId = 'supplier_' + data.supplierId;
            purchaseDoc.status.suppliers[supplierDocId] = {
                status: 4,
                doc: {
                    _id: supplierDocId,
                    total: 0,
                    balance: -totalPaidAmt
                }
            }

            commonWorker.setFreeze(true);
            await couchDBUtils.create(purchaseDoc, mainDBInstance);
            maxReceivingCreditPaymentId++;
            await lockUtils.unlockAsync(lockPath);
            commonWorker.insertParentReceivingstrans(commonLib.formatReceivingCreditId(receiving_id), purchaseDoc.status.parentReceivingTrans, purchaseDoc.status.suppliers);
            commonWorker.setFreeze(false);

            response.message = 'Payment Success';
            response.data.id = receiving_id;
            response.employee = data.employeeId;
            return response;
        } catch (error) {
            await lockUtils.unlockAsync(lockPath);
            commonWorker.setFreeze(false);
            response.error = 'Payment Failed';
            logger.error(error);
            throw response;
        }
    };

    function getPaymentDistributions(payments, pendingTransactions) {
        pendingTransactions.sort(function(a, b) {
            //CreditsTodo Test if this sort works
            return a.sales_info.sale_time > b.sales_info.sale_time;
        });

        let excessPayment = 0;
        for (let i = 0; i < payments.length; i++) {
            excessPayment += payments[i].payment_amount;
        }

        let paymentDistribution = {};
        for (let i = 0; i < pendingTransactions.length; i++) {
            if (excessPayment === 0) {
                break;
            }

            let transaction = pendingTransactions[i];

            let parentSaleId = parseInt(transaction.sales_info._id.substring(5, transaction.sales_info._id.length)); // transaction.sales_info.sale_id;
            let pendingAmount = transaction.sales_info.pending_amount;
            if (pendingAmount <= excessPayment) {
                paymentDistribution[parentSaleId] = pendingAmount;
                excessPayment -= pendingAmount;
            } else {
                paymentDistribution[parentSaleId] = excessPayment;
                excessPayment = 0;
            }
        }

        return {
            excessPayment: excessPayment,
            paymentDistribution: paymentDistribution
        };
    };

    function getPaymentDistributionsForReceivins(payments, pendingTransactions) {
        pendingTransactions.sort(function(a, b) {
            //CreditsTodo Test if this sort works
            return a.receivings_info.receiving_time > b.receivings_info.receiving_time;
        });

        let excessPayment = 0;
        for (let i = 0; i < payments.length; i++) {
            excessPayment += payments[i].payment_amount;
        }

        let paymentDistribution = {};
        for (let i = 0; i < pendingTransactions.length; i++) {
            if (excessPayment === 0) {
                break;
            }

            let transaction = pendingTransactions[i];
            let parentReceivingId = parseInt(transaction.receivings_info._id.substring(10, transaction.receivings_info._id.length));
            // let parentReceivingId = transaction.receivings_info.receiving_id;
            let pendingAmount = transaction.receivings_info.pending_amount;
            if (pendingAmount <= excessPayment) {
                paymentDistribution[parentReceivingId] = pendingAmount;
                excessPayment -= pendingAmount;
            } else {
                paymentDistribution[parentReceivingId] = excessPayment;
                excessPayment = 0;
            }
        }

        return {
            excessPayment: excessPayment,
            paymentDistribution: paymentDistribution
        };
    };

    function convertPaymentToArray(payments) {
        let paymentArray = [];
        for (key in payments) {
            if (payments.hasOwnProperty(key)) {
                paymentArray.push({
                    payment_type: key,
                    payment_amount: payments[key]
                });
            }
        }

        return paymentArray;
    }

    function getTotalPaymentAmount(payments) {
        let totalAmt = 0;
        for (let i = 0; i < payments.length; i++) {
            totalAmt += payments[i].payment_amount;
        }

        return totalAmt;
    }

    function getPaymentJsonForCouch(sale_id, paymentSaleId, paymentType, paymentAmount, date) {
        return {
            _id: commonLib.formatSaleId(sale_id),
            paidAmount: paymentAmount,
            newPayments: [{
                'payment_type': paymentType,
                'payment_amount': paymentAmount,
                'payment_sale_id': paymentSaleId,
                'dp': 'saleCredit',
                'date': date
            }]
        };
    }

    function getPurchasePaymentJsonForCouch(receiving_id, paymentReceivingId, paymentType, paymentAmount, date) {
        return {
            _id: commonLib.formatReceivingId(receiving_id),
            paidAmount: paymentAmount,
            newPayments: [{
                'payment_type': paymentType,
                'payment_amount': paymentAmount,
                'payment_receiving_id': paymentReceivingId,
                'dp': 'receivingCredit',
                'date': date
            }]
        };
    }

};

module.exports = new creditPaymentsLib();