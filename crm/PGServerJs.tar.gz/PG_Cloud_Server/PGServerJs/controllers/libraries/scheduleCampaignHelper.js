"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const moment = require("moment");
const crm_1 = require("../crm");
//https://momentjs.com/docs/
exports.generateSchedules = function (data) {
    data.timeOfDayArr.sort();
    data.dayOfWeekArr.sort();
    // let scheduleStatusArr: ScheduleStatus[] = data.scheduleStatusArr = [];
    let startTime = moment(data.startDate).startOf('day');
    let endTime = moment(data.endDate).endOf('day');
    data.scheduleStatusArr = getAllScheduleStatusArr(startTime, endTime, data.dayOfWeekArr, data.timeOfDayArr);
};
function getAllScheduleStatusArr(startDate, endDate, dayOfWeekArr, timeOfDayArr) {
    let scheduleStatusArr = [];
    let curDateTime = moment();
    if (startDate < curDateTime) {
        startDate = moment(curDateTime);
    }
    while (startDate <= endDate) {
        let day = parseInt(startDate.format('e'));
        if (dayOfWeekArr.indexOf(day) !== -1) {
            timeOfDayArr.forEach(function (time) {
                let date = new Date(time);
                let hours = date.getHours();
                let minutes = date.getMinutes();
                let ts = moment(startDate).startOf('day').add(hours, 'h').add(minutes, 'm').format('x');
                scheduleStatusArr.push({ timestamp: ts, status: crm_1.PENDING });
            });
        }
        startDate.add(1, 'day');
    }
    return scheduleStatusArr;
}
//# sourceMappingURL=scheduleCampaignHelper.js.map