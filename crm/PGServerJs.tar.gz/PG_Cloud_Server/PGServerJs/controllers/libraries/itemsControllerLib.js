'use strict';

const moment = require('moment');

const logger = require('../../common/Logger');
const utils = require('../common/Utils');
const couchDBUtils = require('../common/CouchDBUtils');
const itemUtil = require('./itemUtil');
const mainDBInstance = couchDBUtils.getMainCouchDB();

const ARRAY_LENGTH = utils.getArrayLength; //Example of a macro
const ASSIGN_IF_TRUE = utils.assignIfTrue;
const DELETE_KEY_IF_EXIST = utils.deleteKeyIfExist;
const CLONE = utils.clone;
const IS_UNDEFINED_OR_NULL = utils.isUndefinedOrNull2;

const CREATE_ITEM_COMMENT = 'Initial Stock';
const UPDATE_ITEM_COMMENT = 'Item Stock Update';
const SAVE_INV_COMMENT = 'Inventory Update';
const CREATE_BATCH_COMMENT = 'Adding New Batch';

let controllerLIb = function() {

    let _self = this;

    this.enSalesTax = itemUtil.enSalesTax;
    this.enPurchaseTax = itemUtil.enPurchaseTax;
    let applicationSettings = require('../../common/configState').getApplicationSettings();
    if (applicationSettings) {
        //add it in a better place
        this.ITEM_TYPE = applicationSettings.itemType;
    } else {
        //hardcoding for ut purpose
        this.ITEM_TYPE = {
            "Prepared": "Prepared",
            "Ingredient": "Ingredient",
            "Normal": "Normal",
            "Liquor": "Liquor"
        };
    }
    /**
     * The data comes in a different format than required
     * #RelaxTodo     
     * 2. Add employeeId and timeStamp     
     */

    this.getInitialItemData = function(item_id, data, stock) {
        let itemData = {
            _id: _self.formatItemDocId(item_id),
            item_id: item_id
        };
        itemData.info = CLONE(data);
        DELETE_KEY_IF_EXIST('initialStock', itemData.info);
        DELETE_KEY_IF_EXIST('employeeId', itemData.info);

        itemData.batches = {};
        for (let stockKey in stock) {
            let batchInfo = CLONE(stock[stockKey]);
            DELETE_KEY_IF_EXIST('quantity', batchInfo);
            DELETE_KEY_IF_EXIST('uniqueDetails', batchInfo);
            batchInfo.stockKey = stockKey;
            itemData.batches[stockKey] = _self.getStockJsonFromItemData(batchInfo);
        }

        return itemData;
    };

    this.formatStockKey = function(item_id, batchId, attributeInfo) {
        let stockKey = 'id_' + item_id;

        if (batchId) {
            stockKey += '_batch_' + batchId;
        }

        if (attributeInfo) {
            for (let attributeId in attributeInfo) {
                stockKey += '_' + attributeId + '_' + attributeInfo[attributeId];
            }
        }

        return stockKey;
    };

    this.formatInvTransKey = function(timeStamp, stockKey) {
        return timeStamp + '_' + stockKey;
    };

    this.formatInvDocId = function(id) {
        return 'inventory_' + id;
    };

    this.formatItemDocId = function(id) {
        return itemUtil.formatItemDocId(id);
    };

    function fillInitialStock(data) {
        let stock = _self.getStockJsonFromItemData(data);
        stock.quantity = 0;
        if (data.hasExpiryDate) {
            stock.expiry = moment().format(); //RelaxTodo format using application settings
        }

        return stock;
    }

    this.getStock = function(data, item_id) {
        let inputStock = data.initialStock;
        let inputStockLength = ARRAY_LENGTH(inputStock);

        if (inputStockLength === 0 && !data.hasBatchNumber) {
            //Add the details from item data
            inputStock = [fillInitialStock(data)];
            inputStockLength = 1;
        }

        let stock = {};
        let curTime = parseInt(moment().format('x'));
        for (let i = 0; i < inputStockLength; i++, curTime++) {
            let batchId = inputStock[i].batchId;
            if (!batchId) {
                batchId = curTime;
            }
            let key = _self.formatStockKey(item_id, batchId, inputStock[i].attributeInfo); //Add SKU information to the key here to simplify serach
            stock[key] = inputStock[i];
        }

        return stock;
    };
    //TO-DO:Variant - skuName can be form client side , what if name of variant attribute get updated?
    function getInvTransaction(item_id, timeStamp, employeeId, locationId, comment, batchId, stockKey, quantity, skuName, unit, type) {
        //trans_unit is being used for any calculatiion ; saving it for reference to stock update
        if (!type) {
            throw 'unspecified transaction type';
        }
        let invData = {
            'trans_date': timeStamp,
            'trans_items': item_id,
            'trans_user': employeeId,
            'trans_location': locationId,
            'trans_comment': comment,
            'trans_inventory': quantity,
            'trans_batchId': batchId,
            'trans_stockKey': stockKey,
            "trans_skuName": skuName,
            "trans_unit": unit,
            "trans_type": type
        };

        return invData;
    }

    this.uniqueDetailsJsonForEdit = function(uniqueDetails, itemAvailable, sold, uniqueDetailsJson) {
        uniqueDetailsJson = uniqueDetailsJson || {};
        for (let i = 0; i < ARRAY_LENGTH(uniqueDetails); i++) {
            let detail = uniqueDetails[i];
            let detailKey = _self.getUniqueDetailKey(detail);

            if (uniqueDetailsJson[detailKey]) {
                //If the unique details was not removed while edit 
                continue;
            }

            uniqueDetailsJson[detailKey] = {
                info: detail
            };

            if (!IS_UNDEFINED_OR_NULL(itemAvailable)) {
                uniqueDetailsJson[detailKey].itemAvailable = !itemAvailable;
            }
            if (!IS_UNDEFINED_OR_NULL(sold)) {
                uniqueDetailsJson[detailKey].sold = !sold;
            }
        }

        return uniqueDetailsJson;
    };

    this.getUniqueDetailsJson = function(uniqueDetails, itemAvailable, sold, uniqueDetailsJson) {
        uniqueDetailsJson = uniqueDetailsJson || {};
        for (let i = 0; i < ARRAY_LENGTH(uniqueDetails); i++) {
            let detail = uniqueDetails[i];
            let detailKey = _self.getUniqueDetailKey(detail);
            uniqueDetailsJson[detailKey] = {
                info: detail
            };

            if (!IS_UNDEFINED_OR_NULL(itemAvailable)) {
                uniqueDetailsJson[detailKey].itemAvailable = itemAvailable;
            }
            if (!IS_UNDEFINED_OR_NULL(sold)) {
                uniqueDetailsJson[detailKey].sold = sold;
            }
        }

        return uniqueDetailsJson;
    };

    this.getUniqueDetailKey = function(detail) {
        let key = ASSIGN_IF_TRUE(detail.serialnumber, '');
        if (!key) {
            if (ARRAY_LENGTH(detail.imeiNumbers)) {
                key = ASSIGN_IF_TRUE(detail.imeiNumbers[0], '');
            }
        }

        return key;
    }

    // ItemInfo is required for reports. We can add few more fields and the leverage is high
    //There is a choice to just put everything (all the info)
    let reportFilters = ['reorderLevel', 'isprepared'];
    let defaultValues = [0, false];

    this.getInitialInventoryData = function(item_id, employeeId, stock, itemInfo) {
        let invData = {
            _id: _self.formatInvDocId(item_id),
            quantity: 0,
            item_id: item_id,
            info: {}
        };
        for (let i = 0; i < reportFilters.length; i++) {
            let key = reportFilters[i];
            invData.info[key] = ASSIGN_IF_TRUE(itemInfo[key], defaultValues[i]);
        }

        invData.stock = {};
        invData.transactions = {};

        for (let stockKey in stock) {
            let timeStamp = parseInt(moment().format('x'));
            let batchId = ASSIGN_IF_TRUE(stock[stockKey].batchId, '');
            let key = timeStamp + '_' + stockKey;
            let quantity = stock[stockKey].quantity;
            invData.transactions[key] = getInvTransaction(item_id, timeStamp, employeeId, stock[stockKey].locationId, CREATE_ITEM_COMMENT, batchId, stockKey, quantity, stock[stockKey].skuName, itemInfo.baseUnitId, 'initialStock');
            invData.stock[stockKey] = {
                quantity: quantity,
                uniqueDetails: _self.getUniqueDetailsJson(stock[stockKey].uniqueDetails, true, false)
            }
            if ((itemInfo.is_serialized || itemInfo.imeiCount) && Object.keys(invData.stock[stockKey].uniqueDetails).length !== quantity) {
                logger.error('Duplicate serial number/imei number');
                throw 'Duplicate serial number/imei number';
            }

            invData.quantity += quantity;
        }

        return invData;
    };

    //RelaxTodo List down all changes required for clientside
    //1. use filters instead of views
    //2. any effect on stockKey (autoincrement)?
    //3. maxBatchNumber has to be passed otherwise, we will have to query
    //4. stockKey also should be included in each batch

    /**
     * Update Item
     * 1. Update Item Document 
     * 2. If item doesn't have batches update batch    
     * 
     * Write an update function, as user doesn't send everything
     */

    // Relax hardcoding Query this from some common place
    //This function is not used when adding initial stock
    this.getStockJsonFromItemData = function(data) {
        let fields = ["location_id", "expiry", "attributeInfo", "skuName"];

        let stockJson = {};
        for (let i = 0; i < fields.length; i++) {
            stockJson[fields[i]] = data[fields[i]];
        }

        if (!data.unitsInfo) {
            throw 'units info is mandatory';
        }
        let unitsInfo = CLONE(data.unitsInfo);
        for (let uId in unitsInfo) {
            unitsInfo[uId].purchasePrice = ASSIGN_IF_TRUE(unitsInfo[uId].purchasePriceWithGDiscount, unitsInfo[uId].purchasePrice);
        }
        stockJson.unitsInfo = unitsInfo;

        stockJson.batchId = ASSIGN_IF_TRUE(data.batchId, "");
        stockJson.stockKey = ASSIGN_IF_TRUE(data.stockKey, "");
        stockJson.timeStamp = moment().format('x');

        return stockJson;
    };

    //RelaxClientTodo send stockKey with data
    this.getItemDataForUpdate = function(data) {
        let updateData = {
            info: {},
            batches: {}
        };

        updateData._id = _self.formatItemDocId(data.item_id);
        updateData.item_id = data.item_id;

        updateData.info = CLONE(data);
        //Instead of blindly deleting everything here, validate what may come here
        DELETE_KEY_IF_EXIST('initialStock', updateData.info);
        DELETE_KEY_IF_EXIST('employeeId', updateData.info);
        DELETE_KEY_IF_EXIST('item_id', updateData.info);
        DELETE_KEY_IF_EXIST('_id', updateData.info);

        if (!data.hasBatchNumber && data.stockKey && !data.hasVariants) {
            updateData.batches[data.stockKey] = _self.getStockJsonFromItemData(data);
        }

        return updateData;
    };

    this.getInvDataInfoForUpdate = function(itemInfo) {
        let info = {};
        for (let i = 0; i < reportFilters.length; i++) {
            let key = reportFilters[i];
            info[key] = ASSIGN_IF_TRUE(itemInfo[key], defaultValues[i]);
        }

        return info;
    };

    this.getItemDataForBatchUpdate = function(data) {
        let itemData = {
            _id: _self.formatItemDocId(data.item_id),
            info: {},
            batches: {}
        };

        itemData.batches[data.stockKey] = CLONE(data);

        return itemData;
    };

    //RelaxTodo item without batch update
    //RelaxTodo put try catch for not async functions also. Any function may throw at anytime (intentional/unintentional)
    this.updateStockHelper = function(data, invData, itemAvailable, sold, type) {
        let timeStamp = data.timeStamp;
        if (!timeStamp) {
            timeStamp = parseInt(moment().format('x')); //RelaxClientTodo this may affect client side
        } else {
            if (parseInt(timeStamp) !== NaN) {
                timeStamp = parseInt(timeStamp); //for epoch time
            }
            timeStamp = parseInt(moment(timeStamp).format('x'));
        }

        let item_id = data.item_id;
        let stockKey = data.stockKey;
        let quantity = data.newQuantity;
        let key = _self.formatInvTransKey(timeStamp, stockKey);

        let uniqueDetailsLength = ARRAY_LENGTH(data.uniqueDetails);
        if (uniqueDetailsLength && uniqueDetailsLength != Math.abs(quantity)) {
            throw 'Mismatch in Unique Details and Quantity';
        }
        let qtyToRemove = quantity;
        for (var q = 0; q < uniqueDetailsLength; q++) {
            if (data.uniqueDetails[q].isNew) {
                qtyToRemove += 1;
                itemAvailable = true;
            }
        }

        let docId = _self.formatInvDocId(item_id);
        if (!invData._id) {
            invData._id = docId;
            invData.transactions = {};
            invData.stock = {};
        } else {
            if (invData._id !== docId) {
                logger.error('Same Json used for 2 different documents');
                throw 'Internal Error';
            }
        }

        if (!invData.transactions[key]) {
            invData.transactions[key] = getInvTransaction(item_id, timeStamp, data.employeeId, data.locationId, data.comment, data.batchId, stockKey, quantity, data.skuName, data.uUnit, type);
            invData.stock[stockKey] = {
                quantity: 0,
                uniqueDetails: {}
            };
        } else {
            //fix for unique details sales
            //Previously unique details used to come single shot, refactoring has been done because of reprint and it got broken
            invData.transactions[key].trans_inventory += quantity;
        }
        invData.stock[stockKey].quantity += qtyToRemove;
        _self.getUniqueDetailsJson(data.uniqueDetails, itemAvailable, sold, invData.stock[stockKey].uniqueDetails);
    };

    this.getThisItemInfo = function(itemQueryParams) {
        return itemUtil.getThisItemInfo(itemQueryParams, couchDBUtils, mainDBInstance, logger);
    };

    this.getQuantity = async function(params) {

        try {
            let resp = await couchDBUtils.getView('all_items_data', 'batchId-stockKey', {
                keys: ['id_' + params.item_id, params.stockKey]
            }, mainDBInstance);

            if (resp.length < 3) {
                if (resp.length === 1) {
                    logger.error('Item Exists But Stock Not Found');
                }

                logger.error('Item<' + params.item_id + '> stockKey<' + params.stockKey + '> Not Found');
                throw "Stock Not Found";
            } else if (resp.length === 3) {
                //inventory comes before item in sort order
                let quantityInfo = {
                    totalQuantity: resp[0].value.quantity,
                    info: resp[0].value.info,
                    stockQuantity: resp[1].value
                }
                return quantityInfo;
            } else {
                logger.error("getQuantity:: Not expected to come here");
                throw "Duplicate batch names";
            }
        } catch (error) {
            logger.error(error);
            throw 'Operation Failed. Try Again.';
        }

    };

};

module.exports = new controllerLIb();