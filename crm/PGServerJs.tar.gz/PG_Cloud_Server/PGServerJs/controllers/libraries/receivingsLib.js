/*jshint sub:true*/
var itemsController = require('../Items.js');
let itemsControllerLib = require('./itemsControllerLib');

var validator = require('validator');
var diff = require('deep-diff').diff;
var BPromise = require("bluebird");
var math = require('mathjs');
var logger = require('../../common/Logger');
const utils = require('../common/Utils');
const ASSIGN_IF_TRUE = utils.assignIfTrue;
const IS_EMPTY_OBJECT = utils.isEmptyObject;

var status = require('../../common/StatusCode');
var couchDBUtils = require('../common/CouchDBUtils');
var mainCouchDB = couchDBUtils.getMainCouchDB();
var computeUtils = require('../common/computeUtils');
const recvLib2 = require('./receivingsLib2');
const moment = require('moment');
const commonLib = require('./commonLib');
module.exports = function(requestSession, applicationSettings) {
    return receivingsLib(requestSession, applicationSettings);
};

function receivingsLib(session, applicationSettings) {
    var applicationSettings = applicationSettings;
    let foo = {};
    var _self = foo;

    if (!session.settings) {
        session.settings = {
            receivings: {
                bLocalTax: true
            }
        };
    }
    if (!session.tempPurchaseInfo) {
        session.tempPurchaseInfo = {};
    }

    if (!session.settings.receivings) {
        session.settings.receivings = {
            bLocalTax: true
        };
    }

    foo.setCartSupplierDetails = function(supplier_id) {
        var response = {
            status: status.ERR_UNDEFINED
        };

        //Any new code write with async await
        if (!utils.isUndefinedOrNull(supplier_id)) {
            return couchDBUtils.getDoc('supplier_' + supplier_id, mainCouchDB).then(function(supplier4Cart) {
                if (supplier4Cart) {
                    session.supplierDetails = supplier4Cart;
                    response.status = status.SUCCESS;
                    return response;
                }

                return response;
            }).catch(function(err) {
                logger.error(err);
                return response;
            });
        } else {
            session.supplierDetails = {
                person_id: null
            };
            return Promise.resolve(response);
        }
    };

    foo.getCartSupplierDetails = function() {
        if (utils.isUndefinedOrNull(session.supplierDetails)) {
            session.supplierDetails = {
                person_id: null
            };
        }

        return session.supplierDetails;
    };

    foo.get_mode = function() {

        if (!session.recv_mode) {
            session.recv_mode = 'receive';
        }

        return session.recv_mode;
    };

    foo.get_cart = function() {

        if (!session.recvCart) {
            session.recvCart = [];
        }
        return session.recvCart;
    };

    foo.set_cart = function(salesCartData) {
        session.recvCart = salesCartData;
    };
    foo.set_mode = function(mode) {
        session.recv_mode = mode;
    };
    foo.getGlobalDiscount = function() {
        if (session.globalDiscount) return session.globalDiscount;
        return foo.getZeroGlobalDiscount();
    }
    foo.getZeroGlobalDiscount = function() {
        return {
            method: 'onTotal',
            value: 0,
            bPercent: 0,
            amount: 0,
            percent: 0
        }
    }

    foo.setGlobalDiscount = function(discountParam) {
        /*
        @discountParam={
            bPercent: false/true,
            value: value/percent,
            method: 'onTaxable'/ 'onTotal'
        }
        */
        var cart = foo.get_cart();
        var resp = {};
        var total = 0;
        var totalNoTaxWithDiscount = 0;
        if (!discountParam || utils.isUndefinedOrNull(discountParam.value) || utils.isUndefinedOrNull(discountParam.bPercent)) {
            resp.errMsg = 'Param not defined';
            throw resp;
        }
        try {
            foo.compute();
            resp.discount = discountParam;
            cart = foo.get_cart();
            resp.discount = discountParam;
            session.globalDiscount = discountParam;
            return resp;
        } catch (err) {
            err.msg = "Calculation failed for spot discount";
            err.errMsg = err;
            throw err;
        }
    }

    foo.get_stock_source = function() {
        //TODO should return location and location name
        session.recv_stock_source = 1;
        return session.recv_stock_source;
    };

    foo.getIdFromReceiptOrInvoiceNumber = async function(receiptNumberOrInvoiceNumber) {
        return false;
    };

    foo.emptyCart = function() {
        session.recvCart = [];
    };

    function getItemtotalNoTaxNoDiscount(quantity, price) {
        return math.multiply(quantity, price);
    }

    foo.removeSupplier = function() {
        delete session.supplier;
        delete session.supplierDetails;
        foo.setLocalTax(true);
    };

    foo.set_supplier = function(supplier_id) {
        session.supplier = null;
        return foo.setCartSupplierDetails(supplier_id).then(function(resp) {
            if (session.supplierDetails !== undefined) {
                session.supplier = session.supplierDetails.person_id;
            }
            return resp;
        }).catch(function(err) {
            if (session.supplierDetails !== undefined) {
                session.supplier = session.supplierDetails.person_id;
            }
            return Promise.reject(err);
        });
    };

    foo.get_supplier = function() {
        if (!session.supplier) {
            session.supplier = -1;
        }
        return session.supplier;
    };

    function findLineOfItemByItemId(itemId, cart) {
        var lineNo = -1;
        for (var index in cart) {
            if (cart[index].item_id === itemId /*&& cartItem.item_location == itemLocation*/ ) {
                lineNo = index;
                break;
            }
        }

        return lineNo;
    }

    function getItemTax(totalNoTaxNoDiscount, taxPercent) {
        var taxDecimal = math.multiply(taxPercent, 0.01);
        return math.multiply(totalNoTaxNoDiscount, taxDecimal);
    }

    function ROUNDOFFNUMBER(number) {
        var result = +utils.roundOffNumber(number, applicationSettings);
        return result;
    }

    foo.mergeTaxes = function(item) {
        let tempTaxArray = [];
        for (let t = 0; item.itemTaxList && t < item.itemTaxList.length; t++) {
            let thisTax = item.itemTaxList[t];
            if (thisTax.name == "CGST" || thisTax.name == "IGST") {
                let tempTax = {
                    name: "GST",
                    percent: (thisTax.name == "IGST") ? thisTax.percent : thisTax.percent * 2
                };
                tempTaxArray.push(tempTax);
            } else if (thisTax.name != "SGST") tempTaxArray.push(thisTax);
        }
        return tempTaxArray;
    }

    //BMTodo store the values in session and compute differential
    // same session is shared for sales and purchase be cautious 
    var allCartTaxes = {};
    session.totalNoTaxNoDiscount = 0;
    session.totalNoTaxWithDiscount = 0;
    session.total = 0;
    session.totalNoGlobalDiscount = 0;
    foo.compute = function() {
        allCartTaxes = {};
        session.totalNoTaxNoDiscount = 0;
        session.totalNoTaxWithDiscount = 0
        session.total = 0;
        session.totalNoGlobalDiscount = 0;
        var cart = foo.get_cart();
        var globalDiscount = foo.getGlobalDiscount();
        var baseUnitPrice;
        for (var i = 0; i < cart.length; i++) {
            //
            cart[i].discount = cart[i].discount ? cart[i].discount : 0;
            var purchasePrice = commonLib.getPPFromUInfo(cart[i].unitsInfo, cart[i].unitId);
            cart[i].purchasePriceExTax = purchasePrice;
            //exclude tax from purchase price if tax is inclusive
            if (cart[i].bPPTempTaxInclusive) {
                //discount doesn't matter because priceintax is without discount
                baseUnitPrice = commonLib.getBaseUnitPrice(cart[i].purchasePriceExTax, cart[i].unitId, cart[i].baseUnitId, cart[i].unitsInfo);
                cart[i].totalTaxPercent = commonLib.getTaxesForItem(session.settings.receivings.bLocalTax, cart[i].origTaxes, cart[i].slab, cart[i].itemTaxList, baseUnitPrice, cart[i].bPPTempTaxInclusive);
                cart[i].purchasePriceExTax = computeUtils.calculatePriceExcludingTax(purchasePrice, cart[i].totalTaxPercent);
            }
            //item total without adding tax ,before removing discount 
            cart[i].totalNoTaxNoDiscount = getItemtotalNoTaxNoDiscount(cart[i].quantity, cart[i].purchasePriceExTax);
            // let originalTotalNoTaxNoDiscount = cart[i].totalNoTaxNoDiscount;
            //item total without adding tax ,after removing discount 
            cart[i].totalNoTaxWithDiscount = cart[i].totalNoTaxNoDiscount * (1 - cart[i].discount * 0.01);
            cart[i].discounted_price = cart[i].totalNoTaxNoDiscount * cart[i].discount * 0.01;
            // merge cgst-sgst and igst to gst tax list

            // cart[i].itemTaxList = foo.mergeTaxes(cart[i]);
            baseUnitPrice = commonLib.getBaseUnitPrice(cart[i].totalNoTaxWithDiscount / cart[i].quantity, cart[i].unitId, cart[i].baseUnitId, cart[i].unitsInfo);
            cart[i].totalTaxPercent = commonLib.getTaxesForItem(session.settings.receivings.bLocalTax, cart[i].origTaxes, cart[i].slab, cart[i].itemTaxList, baseUnitPrice, cart[i].bPPTempTaxInclusive);

            cart[i].total = cart[i].totalNoTaxWithDiscount * (1 + cart[i].totalTaxPercent * 0.01);
            cart[i].totalNoGlobalDiscount = cart[i].total;
            if (globalDiscount.method == 'onTaxable') {
                /**
                 * apply global discount on taxable (total - local discount - tax)
                 */
                // cart[i].totalNoTaxWithDiscount = (globalDiscount.bPercent) ? cart[i].totalNoTaxWithDiscount * (1 - globalDiscount.value * 0.01) : cart[i].totalNoTaxWithDiscount - ((globalDiscount.value * 100) / cart[i].totalNoTaxWithDiscount);
                cart[i].totalNoTaxWithDiscount = cart[i].totalNoTaxNoDiscount * (1 - (globalDiscount.percent + cart[i].discount) * 0.01);
                baseUnitPrice = commonLib.getBaseUnitPrice(cart[i].totalNoTaxWithDiscount / cart[i].quantity, cart[i].unitId, cart[i].baseUnitId, cart[i].unitsInfo);
                cart[i].totalTaxPercent = commonLib.getTaxesForItem(session.settings.receivings.bLocalTax, cart[i].origTaxes, cart[i].slab, cart[i].itemTaxList, baseUnitPrice, cart[i].bPPTempTaxInclusive);
                cart[i].total = cart[i].totalNoTaxWithDiscount * (1 + cart[i].totalTaxPercent * 0.01);
            } else if (globalDiscount.method == 'onTotal') {
                // cart[i].total = cart[i].totalNoTaxWithDiscount * (1 - (globalDiscount.percent) * 0.01);
                /**
                 * apply global discount on total (total - local discount + tax)
                 */
                cart[i].total = cart[i].total * (1 - (globalDiscount.percent) * 0.01);

                let tempTax = cart[i].totalTaxPercent;
                let bEdgeCaseCount = 0;
                while (true) {
                    // problem in case of slab...which to calculate first tax or discounted amt
                    cart[i].totalNoTaxWithDiscount = ROUNDOFFNUMBER(cart[i].total / (1 + tempTax * 0.01));
                    baseUnitPrice = commonLib.getBaseUnitPrice(cart[i].totalNoTaxWithDiscount / cart[i].quantity, cart[i].unitId, cart[i].baseUnitId, cart[i].unitsInfo);
                    cart[i].totalTaxPercent = commonLib.getTaxesForItem(session.settings.receivings.bLocalTax, cart[i].origTaxes, cart[i].slab, cart[i].itemTaxList, baseUnitPrice, cart[i].bPPTempTaxInclusive);
                    // originalTotalNoTaxNoDiscount = cart[i].totalNoTaxNoDiscount;
                    if (tempTax === cart[i].totalTaxPercent) {
                        break;
                    } else if (tempTax < cart[i].totalTaxPercent && ++bEdgeCaseCount == 2) {
                        bEdgeCase = true;
                        //lower slab change the value .. 
                        break;
                    }
                    tempTax = cart[i].totalTaxPercent;
                }
                if (bEdgeCaseCount === 2) {
                    throw 'Not expected to come here';
                    if (!cart[i].slab || cart[i].itemTaxList.length === 0) {
                        throw 'Not expected to come here.'
                    }
                    baseUnitPrice = commonLib.getBaseUnitPrice(cart[i].totalNoTaxWithDiscount / cart[i].quantity, cart[i].unitId, cart[i].baseUnitId, cart[i].unitsInfo);
                    cart[i].totalTaxPercent = commonLib.getTaxesForItem(session.settings.receivings.bLocalTax, cart[i].origTaxes, cart[i].slab, cart[i].itemTaxList, baseUnitPrice, cart[i].bPPTempTaxInclusive);
                    let matchedSlab = computeUtils.getSlabFromTax(cart[i].slab, cart[i].itemTaxList);
                    cart[i].totalNoTaxWithDiscount = matchedSlab.max;
                    bDirtyGlobalDiscount = true;
                }
                cart[i].totalNoGlobalDiscount = cart[i].totalNoTaxNoDiscount * (1 - cart[i].discount * 0.01) * (1 + cart[i].totalTaxPercent * 0.01);
                cart[i].totalNoTaxNoDiscount = cart[i].totalNoTaxWithDiscount / (1 - ((globalDiscount.percent + cart[i].discount) * 0.01));
                cart[i].total = cart[i].totalNoTaxWithDiscount * (1 + cart[i].totalTaxPercent * 0.01);
            }
            computePPWithGDiscount(cart[i], globalDiscount);
            let taxes = cart[i].itemTaxList;

            for (var j = 0; j < taxes.length; j++) {
                var taxPercent = taxes[j].percent;
                var taxName = taxes[j].name;
                taxes[j].Amt = getItemTax(cart[i].totalNoTaxWithDiscount, taxes[j].percent)
                if (!allCartTaxes[taxName]) {
                    allCartTaxes[taxName] = 0;
                }
                allCartTaxes[taxName] += taxes[j].Amt;
            }

            session.totalNoGlobalDiscount += cart[i].totalNoGlobalDiscount;
            session.totalNoTaxNoDiscount += cart[i].totalNoTaxNoDiscount;
            session.totalNoTaxWithDiscount += cart[i].totalNoTaxWithDiscount;
            session.total += cart[i].total;
        }
        // for (taxName in allCartTaxes) {
        //     if (allCartTaxes.hasOwnProperty(taxName)) {
        //         session.total += allCartTaxes[taxName];
        //     }
        // }
    }

    function computePPWithGDiscount(cartItem, gd) {

        let gdp = gd.percent;
        if (gd.method === "onTotal") {
            let pp = commonLib.getPPFromUInfo(cartItem.unitsInfo, cartItem.unitId);
            let purchasePriceWithGDiscount = cartItem.totalNoTaxWithDiscount / cartItem.quantity;
            if (cartItem.bPPTaxInclusive) {
                purchasePriceWithGDiscount = cartItem.total / cartItem.quantity //(inctax)
            }
            // below link came from this formula -> ppwd = pp*(1-(gdp+idp)*0.01)
            gdp = 100 - (purchasePriceWithGDiscount / pp * 100) - cartItem.discount;
        }

        for (unitId in cartItem.unitsInfo) {
            cartItem.unitsInfo[unitId].purchasePriceWithGDiscount = cartItem.unitsInfo[unitId].purchasePrice * (1 - (gdp + cartItem.discount) * 0.01) //all units
        }
    }

    foo.getTaxes = function() {
        return allCartTaxes;
    };

    foo.gettotalNoTaxNoDiscount = function() {
        return session.totalNoTaxNoDiscount;
    }
    foo.gettotalNoTaxWithDiscount = function() {
        return session.totalNoTaxWithDiscount;
    }
    foo.gettotalNoGlobalDiscount = function() {
        return session.totalNoGlobalDiscount;
    }

    foo.getTotal = function() {
        return session.total;
    };

    function compareAttributes(refAttributeInfo, insAttributeInfo) {
        if (!refAttributeInfo && !insAttributeInfo) {
            return true;
        } else if (!refAttributeInfo || !insAttributeInfo) {
            return false;
        }

        let bEqual = true;
        if (Object.keys(insAttributeInfo).length !== Object.keys(refAttributeInfo).length) {
            logger.error('Attribute Keys Length Doesnt match. Not supposed to come here');
            throw 'Internal Error';
        }

        for (let attributeId in insAttributeInfo) {
            if (refAttributeInfo[attributeId] !== insAttributeInfo[attributeId]) {
                bEqual = false;
                break;
            }
        }

        return bEqual;
    }

    function isItemAlreadyAdded(cartItem, item_id, batchId, attributeInfo, itemLocation) {
        let bItemAlreadyAdded = true;
        batchId = ASSIGN_IF_TRUE(batchId, "");
        if (cartItem.item_id !== item_id) {
            bItemAlreadyAdded = false;
        } else if (cartItem.batchId !== batchId) {
            bItemAlreadyAdded = false;
        } else if (cartItem.item_location !== itemLocation) {
            bItemAlreadyAdded = false
        } else if (!compareAttributes(cartItem.attributeInfo, attributeInfo)) {
            bItemAlreadyAdded = false;
        };

        return bItemAlreadyAdded;
    }

    function getAppliedSlabTax(discount, price, slab, tax) {
        if (discount && slab) {
            let total = price * (1 - discount * 0.01);
            for (let i = 0; i < slab.rates.length; i++) {
                if (total >= slab.rates[i].min && total <= slab.rates[i].max)
                    return slab.rates[i].percent;
            }
        }
    }

    //RelaxTodo write time machine

    /**
     *      Todo    
     *          Not using discount field as we don't have this field in our db. Hardcoding discount= 0 for now
     *          For items with seraial_number, deleteitemfromcart has bug
     *          refer salescontrollerlib .. querying db every time is not required. check for cart first
     * 
     *      item_id, batchId, attributeInfo, skuName, quantity, unitId, expiry, unitsInfo, pItemTaxList, pBPPTaxInclusive
     */
    foo.addItem2Cart = async function(params) {

        let localMemberNames = ["item_id", "batchId", "attributeInfo", "skuName", "quantity", "unitId", "expiry", "unitsInfo", "pItemTaxList", "pBPPTaxInclusive", "discount"];
        for (let i = 0; i < localMemberNames.length; i++) {
            eval("var " + localMemberNames[i] + " = " + JSON.stringify(params[localMemberNames[i]]) + ";");
        }

        //TODO check whats really their in the old code and then modify        
        var rejectMessage = ' Item with ItemId=' + item_id + ' Doesnt Exists, so Cannot add to Cart';
        var itemLocation = 1;
        quantity = quantity || 1;
        try {
            let thisItemInfo = await itemsControllerLib.getThisItemInfo({
                item_id: item_id,
                taxType: itemsControllerLib.enPurchaseTax
            });

            if (!thisItemInfo) {
                throw rejectMessage;
            }

            if (thisItemInfo.attributes.length && !attributeInfo) {
                let errMsg = 'Attribute Info is mandatory';
                logger.error(errMsg);
                throw errMsg;
            } else if (thisItemInfo.attributes.length == 0 && attributeInfo) {
                attributeInfo = undefined;
            }

            var cart = foo.get_cart();

            var maxkey = 0;
            var itemIndex = -1;
            var itemalreadyinsale = false;
            var insertkey = 0;
            var cartItem = {};

            for (var index in cart) {
                var cartItem = cart[index];
                if (maxkey < cartItem.line) {
                    maxkey = cartItem.line;
                }
                if (isItemAlreadyAdded(cartItem, item_id, batchId, attributeInfo, itemLocation)) {
                    itemalreadyinsale = true;
                    itemIndex = index;
                    quantity = parseFloat(cartItem.quantity) + parseFloat(quantity);
                    cartItem = cart[itemIndex];
                    break;
                }
            }

            insertkey = maxkey + 1;

            let taxes = thisItemInfo.taxes;
            let slab = thisItemInfo.slab;
            if (pItemTaxList) {
                //This is for purchase edit
                taxes = [];
                for (let i = 0; i < pItemTaxList.length; i++) {
                    taxes.push({
                        taxInfo: pItemTaxList[i]
                    });
                    thisItemInfo.bPPTaxInclusive = pBPPTaxInclusive;
                }
                slab = params.slab;
            }
            thisItemInfo.bPPTempTaxInclusive = thisItemInfo.bPPTaxInclusive;

            if (!unitId) {
                unitId = thisItemInfo.defaultPurchaseUnitId;
            }

            //make sure we fill all the required fields of unitsinfo with defaults
            if (utils.isUndefinedOrNull(unitsInfo)) {
                unitsInfo = thisItemInfo.unitsInfo;
            } else if (params.baseUnitId != thisItemInfo.baseUnitId) {
                throw 'Base Unit Changed';
            }
            let purchasePrice = commonLib.getPPFromUInfo(unitsInfo, unitId);

            if (!itemalreadyinsale) {
                cartItem = {
                    'item_id': item_id,
                    'batchId': ASSIGN_IF_TRUE(batchId, ""),
                    'item_location': itemLocation,
                    'line': insertkey,
                    'name': thisItemInfo.name,
                    'hsn': thisItemInfo.hsn,
                    'description': thisItemInfo.description,
                    'unit': commonLib.getUnitName(thisItemInfo.unitDocs, unitId),
                    'unitDocs': thisItemInfo.unitDocs,
                    'discount': discount,
                    'discountBy': params.discountBy,
                    'in_stock': thisItemInfo.quantity, //RelaxTodo get from inventory doc
                    // 'totalTaxPercent': totalTaxPercent,
                    'bOTG': thisItemInfo.bOTG,
                    'bPPTaxInclusive': thisItemInfo.bPPTaxInclusive,
                    'bPPTempTaxInclusive': thisItemInfo.bPPTempTaxInclusive,
                    'unitsInfo': unitsInfo,
                    'baseUnitId': thisItemInfo.baseUnitId,
                    'unitId': unitId,
                    'hasExpiryDate': thisItemInfo.hasExpiryDate,
                    'is_serialized': thisItemInfo.is_serialized,
                    'hasBatchNumber': thisItemInfo.hasBatchNumber,
                    'imeiCount': thisItemInfo.imeiCount,
                    'slab': slab,
                    'itemTaxList': [],
                    'origTaxes': taxes,
                    'hasVariants': thisItemInfo.hasVariants,
                    'multipleUnits': thisItemInfo.multipleUnits
                };

                if (attributeInfo) {
                    cartItem.attributeInfo = attributeInfo;
                    cartItem.skuName = skuName;
                }

                if (thisItemInfo.hasExpiryDate) {
                    cartItem.expiry = expiry;
                }
                if (thisItemInfo.is_serialized || thisItemInfo.imeiCount !== 0) {
                    cartItem.uniqueDetails = {};
                    cartItem.maxSubLine = 0;
                }
                if (!thisItemInfo.hasBatchNumber || batchId || attributeInfo) {
                    let stock = getStockFromBatches(thisItemInfo.batches, batchId, attributeInfo);
                    if (stock) {
                        cartItem.stockKey = stock.stockKey;
                        cartItem.oldStock = stock;
                    } else {
                        //First time the stock is getting added. Add a new timeStamped Key
                        let tempBatchId = batchId;
                        if (!tempBatchId) {
                            tempBatchId = moment().format('x');
                        }
                        cartItem.stockKey = itemsControllerLib.formatStockKey(cartItem.item_id, tempBatchId, cartItem.attributeInfo); //make it a common function
                    }
                }

                cart.push(cartItem);
                itemIndex = cart.length - 1;
            }

            if (quantity <= 0) {
                _self.deleteItemByLine(cartItem.line);
                cart = foo.get_cart(); //reloading cart, as in the previous operation, the array changed
            } else {

                cartItem.quantity = quantity;
                var price = computeUtils.getPriceTaxEx(purchasePrice, thisItemInfo.bPPTempTaxInclusive, cartItem.totalTaxPercent);
                cartItem.purchasePriceExTax = price;
                if (params.discountBy === 'value' && params.discount) {
                    let dP = params.discount;
                    dP = params.discount / cartItem.purchasePriceExTax * 100;
                    cartItem.discount = dP / quantity;

                }
                cartItem.discountBy = params.discountBy;
                cartItem.bReadyForCheckout = isReadyForCheckout(cartItem);
            }

            foo.set_cart(cart);
            return cartItem;

        } catch (err) {
            throw err;
        }
    };

    foo.isCartReadyForCheckout = function() {
        var cart = foo.get_cart();
        var bReadyForCheckout = true;
        for (var i = 0; i < cart.length; i++) {
            var cartItem = cart[i];
            if (!isReadyForCheckout(cartItem)) {
                bReadyForCheckout = false;
            }
        }

        return bReadyForCheckout;
    };

    function isReadyForCheckout(cartItem) {
        var bReadyForCheckout = true;
        if (cartItem.hasBatchNumber && !cartItem.batchId) {
            bReadyForCheckout = false;
        } else if (cartItem.hasExpiryDate && !cartItem.expiry) {
            bReadyForCheckout = false;
        }

        return bReadyForCheckout;
    }

    function compareItemWithOldStock(cartItem) {
        var oldStock = cartItem.oldStock;

        cartItem.info = '';
        let oldUnitsInfo = oldStock.unitsInfo;
        let newUnitsInfo = cartItem.unitsInfo;
        if (Object.keys(oldStock.unitsInfo).length !== Object.keys(cartItem.unitsInfo).length) {
            cartItem.info += ' More units has been added since last time.';
        }

        for (let key in oldUnitsInfo) {
            if (!newUnitsInfo[key]) {
                cartItem.info += ' ' + key + ' data not found.';
            }

            let fields = ['purchasePrice', 'mrp'];
            for (let i = 0; i < fields.length; i++) {
                if (newUnitsInfo[key][fields[i]] !== oldUnitsInfo[key][fields[i]]) {
                    cartItem.info += ' ' + key + ' ' + fields[i] + ' changed.';
                }
            }

            if (Object.keys(oldUnitsInfo[key].pProfilesData).length !== Object.keys(newUnitsInfo[key].pProfilesData).length) {
                cartItem.info += ' Pricing Profiles has been added since last time.';
            }

            let oldPProfilesData = oldUnitsInfo[key].pProfilesData;
            let newPProfilesData = newUnitsInfo[key].pProfilesData;
            for (let pProfileKey in oldPProfilesData) {
                if (!newPProfilesData[pProfileKey]) {
                    cartItem.info += ' ' + pProfileKey + ' Not Found.';
                }
                if (oldPProfilesData[pProfileKey].sellingPrice !== newPProfilesData[pProfileKey].sellingPrice) {
                    cartItem.info += ' ' + pProfileKey + '> Selling Price Changed.';
                }
            }
        }
    };

    /**
     * {
     *    line: 2,
     *    uniqueDetails: [{
     *            serialnumber: 'sadf',
     *            imeiNumbers: ["fdgffdfd","jhgjhghhg","jhghgjh"]
     *        },
     *        {
     *            subLine: 3,
     *            serialnumber: 'fsdjak',
     *            imeiNumbers: ["fdgffdfd","jhgjhghhg","jhghgjh"]
     *        }, {
     *            subLine: 4,
     *            bDelete: true
     *        }
     *    ]
     * }
     */
    foo._updateUniqueDetailsBulk = function(params) {
        var response = {
            status: status.ERR_UNDEFINED
        };

        if (!params.uniqueDetails || !params.uniqueDetails.length) {
            response.status = status.SUCCESS;
            return response;
        }

        var thisCartItem = _self.get_cart().filter(function(cartItem) {
            return cartItem.line === params.line;
        });

        if (thisCartItem.length === 0) {
            response.error = 'No item Found in cart with line Number' + params.line;
            return response;
        } else {
            thisCartItem = thisCartItem[0];
            if (!thisCartItem.is_serialized && thisCartItem.imeiCount === 0) {
                response.status = status.SUCCESS;
                return response;
            }

            for (var i = 0; i < params.uniqueDetails.length; i++) {
                var details = params.uniqueDetails[i];
                if (!details.subLine) {
                    thisCartItem.maxSubLine += 1;
                    details.subLine = thisCartItem.maxSubLine;
                    thisCartItem.uniqueDetails[details.subLine] = {};
                }

                thisCartItem.uniqueDetails[details.subLine] = {
                    serialnumber: details.serialnumber,
                    imeiNumbers: details.imeiNumbers
                };
            }
        }

        thisCartItem.bReadyForCheckout = isReadyForCheckout(thisCartItem);

        response.status = status.SUCCESS;
        return response;
    };

    /**
     * update unique details for removed item
     */
    foo._updateUniqueDetailsBulk4RemovedItem = function(params) {
        var response = {
            status: status.ERR_UNDEFINED
        };

        if (!params.uniqueDetails || !params.uniqueDetails.length) {
            response.status = status.SUCCESS;
            return response;
        }

        var thisCartItem = _self.get_cart().filter(function(cartItem) {
            return cartItem.line === params.line;
        });

        if (thisCartItem.length === 0) {
            response.error = 'No item Found in cart with line Number' + params.line;
            return response;
        } else {
            thisCartItem = thisCartItem[0];
            if (!thisCartItem.is_serialized && thisCartItem.imeiCount === 0) {
                response.status = status.SUCCESS;
                return response;
            }

            for (var i = 0; i < params.uniqueDetails.length; i++) {
                var details = params.uniqueDetails[i];
                for (var subItem in thisCartItem.uniqueDetails) {
                    var differences = diff(thisCartItem.uniqueDetails[subItem], details);
                    if (!differences) {
                        delete thisCartItem.uniqueDetails[subItem];
                    }
                }
            }
        }

        thisCartItem.bReadyForCheckout = isReadyForCheckout(thisCartItem);

        response.status = status.SUCCESS;
        return response;
    };

    //If Item doesn't have batches, it returns stockKey of first batch without batchId else null
    //If item has batches, it returns stockKey of first batch that matches else null
    //If result of above 2 is null, then return currentTimeStamp
    function getStockFromBatches(batches, batchId, attributeInfo) {
        batchId = ASSIGN_IF_TRUE(batchId, "");
        let stock;
        for (let key in batches) {
            let curBatchId = ASSIGN_IF_TRUE(batches[key].batchId, "");
            let curAttributeInfo = batches[key].attributeInfo;
            if (curBatchId === batchId && compareAttributes(attributeInfo, batches[key].attributeInfo)) {
                stock = batches[key];
                break;
            }
        }

        return stock;
    }

    async function getStockByBatchId(item_id, batchId, attributeInfo) {
        try {
            let key = itemsControllerLib.formatStockKey(item_id, batchId, attributeInfo);
            let resp = await couchDBUtils.getView('all_items_data', 'batchId-stockKey', {
                key: key
            }, mainCouchDB);

            if (resp.length === 2) {
                return resp[1].value; //inventory comes before item in sort order
            } else if (resp.length > 2 || resp.length === 1) {
                logger.error("getStockKey2:: Not expected to come here");
                throw "Duplicate batch names";
            }
        } catch (error) {
            logger.error(error);
            throw 'Operation Failed. Try Again.';
        }
    }

    function updateItemCartParams(cartItem) {
        let purchasePrice = commonLib.getPPFromUInfo(cartItem.unitsInfo, cartItem.unitId);

        let itemTaxList = [];
        let baseUnitPrice = commonLib.getBaseUnitPrice(purchasePrice, cartItem.unitId, cartItem.baseUnitId, cartItem.unitsInfo);
        cartItem.totalTaxPercent = commonLib.getTaxesForItem(session.settings.receivings.bLocalTax, cartItem.origTaxes, cartItem.slab, cartItem.itemTaxList, baseUnitPrice, cartItem.bPPTempTaxInclusive);

        cartItem.purchasePriceExTax = purchasePrice;
        // var totalIncTax = purchasePriceExTax * (1 + totalTaxPercent * 0.01) * quantity;
        if (cartItem.bPPTempTaxInclusive) {
            cartItem.purchasePriceExTax = computeUtils.calculatePriceExcludingTax(purchasePrice, totalTaxPercent);
        }

    }

    foo.updateUnit = function(data) {
        let cartItem = _self.get_cart().filter(function(item) {
            return item.line === data.line;
        });
        if (cartItem.length <= 0) {
            throw new Error('No item Found in cart with line Number', data.line);
        }

        cartItem = cartItem[0];
        cartItem.unitId = data.unitId;
        cartItem.unit = commonLib.getUnitName(cartItem.unitDocs, cartItem.unitId);
    };

    /**
     * RelaxTodo Unhandled case
     * 1. add an item to cart, edit and provide batchId
     * 2. add same item to cart again, it goes to new line. edit and provide same batchId it accepts     
     */
    foo.edit_item = function(line, quantity, expiry, unitsInfo, batchId, bPPTempTaxInclusive, discount, discountMethod) {

        bPPTempTaxInclusive = bPPTempTaxInclusive === 'true' || bPPTempTaxInclusive === true;

        var thisCartItem = _self.get_cart().filter(function(cartItem) {
            return cartItem.line === line;
        });

        var response = {
            status: status.ERR_UNDEFINED
        };

        if (thisCartItem.length <= 0) {
            response.error = 'No item Found in cart with line Number' + line;
            return Promise.resolve(response);
        } else {

            thisCartItem = thisCartItem[0];
            thisCartItem.discount = discount;
            var dP = discount;

            var purchasePrice = commonLib.getPPFromUInfo(unitsInfo, thisCartItem.unitId);
            var price = computeUtils.getPriceTaxEx(purchasePrice, bPPTempTaxInclusive, thisCartItem.totalTaxPercent);
            thisCartItem.purchasePriceExTax = price;

            if (discountMethod === 'value') {
                dP = dP / thisCartItem.purchasePriceExTax * 100;
            }
            thisCartItem.discount = dP;
            discount = dP;
            thisCartItem.discountBy = discountMethod;
            //purchasePriceExTax

            //If User changes batchId, check if it is unique
            //We can store batches in cartItem but it may be overhead for the http call. Just my feeling   
            let bStockKeyChanged = thisCartItem.hasBatchNumber && batchId && thisCartItem.batchId !== batchId;
            return Promise.resolve().then(function() {
                if (bStockKeyChanged) {
                    return getStockByBatchId(thisCartItem.item_id, batchId, thisCartItem.hasBatchNumber);
                } else {
                    return Promise.resolve();
                }
            }).then(function(batchInfo) {
                if (batchInfo) {
                    response.warning = 'Batch with id<' + batchId + '> already exist. Any change in price will affect previous stock with the same id';
                    thisCartItem.oldStock = batchInfo;
                    thisCartItem.stockKey = thisCartItem.oldStock.stockKey;
                } else if (bStockKeyChanged) {
                    //New Batch
                    thisCartItem.stockKey = itemsControllerLib.formatStockKey(thisCartItem.item_id, batchId, thisCartItem.attributeInfo);
                }

                if (thisCartItem.hasBatchNumber) {
                    thisCartItem.batchId = batchId;
                }
                thisCartItem.quantity = parseFloat(quantity);
                if (thisCartItem.hasExpiryDate) {
                    thisCartItem.expiry = expiry;
                }
                thisCartItem.discount = discount;

                // totalTaxPercent = thisCartItem.totalTaxPercent;
                thisCartItem.bPPTempTaxInclusive = bPPTempTaxInclusive;

                thisCartItem.unitsInfo = unitsInfo;
                thisCartItem.bReadyForCheckout = isReadyForCheckout(thisCartItem);
                if (thisCartItem.oldStock) {
                    compareItemWithOldStock(thisCartItem);
                }
                response.status = status.SUCCESS;
                return response;
            }).catch(function(err) {
                logger.error(err);
                response.error = 'Edit Failed';
                return Promise.reject(response);
            });
        }
    };

    foo.deleteItemByLine = function(line) {
        var cart = foo.get_cart();
        var index = findIndexOfItemByLine(line, cart);
        if (index > -1) {
            cart.splice(index, 1);
            return true;
        }

        return false;
    };

    function findIndexOfItemByLine(line, cart) {
        var index = -1;
        for (var index in cart) {
            if (cart[index].line === line) {
                index = index;
                break;
            }
        }

        return index;
    }

    foo.get_comment = function() {
        // avoid returning a null that results in a 0 in the comment if nothing is set/available

        return !session.recvComment ? '' : session.recvComment;
    };

    foo.get_invoiceNumber = function() {

        return !session.recv_invoice_number ? null : session.recv_invoice_number;
    };

    foo.is_print_after_sale = function() {
        return session.recv_print_after_sale === 'true' || session.recv_print_after_sale === '1';
    };

    foo.set_print_after_sale = function(print_after_sale) {
        session.recv_print_after_sale = print_after_sale;
    };

    foo.is_invoice_number_enabled = function() {
        return session.recv_invoice_number_enabled === 'true' || session.recv_invoice_number_enabled === '1';
    };

    foo.clear_all = function() {
        foo.clear_mode();
        foo.emptyCart();
        foo.clear_comment();
        foo.clear_invoice_number();
        foo.removeSupplier();
        foo.clearPayments();
        foo.clearTempDetails();
        foo.setGlobalDiscount(foo.getZeroGlobalDiscount());
    };

    foo.set_comment = function(comment) {
        session.recvComment = comment;
    };
    foo.clear_comment = function() {
        session.recvComment = null;
    };

    foo.set_invoice_number = function(invoiceNumber) {
        session.recv_invoice_number = invoiceNumber ? invoiceNumber : null;
    };

    foo.clear_invoice_number = function() {
        session.recv_invoice_number = null;
    };
    foo.set_invoice_number_enabled = function(invoice_number_enabled) {
        session.recv_invoice_number_enabled = invoice_number_enabled;
    };

    foo.setLocalTax = function(bLocalTax) {
        session.settings.receivings.bLocalTax = bLocalTax;
    };
    foo.getLocalTax = function() {
        if (session.settings.receivings.bLocalTax === undefined) return true;
        return session.settings.receivings.bLocalTax;
    };

    foo.get_item_id = function(line_to_get) {

        var cartItems = foo.get_cart();
        for (var index in cartItems) {
            if (cartItems[index].line == line_to_get) {
                return cartItems[index].item_id;
            }
        }
        return -1;
    };
    //RelaxTodo Total is also not saved

    foo.save = function(cart, editPurchaseId, supplierId, employeeId, comment, invoiceNumber, payments, paymentType, total, purchaseOnCreditAmt, StockLocation, timeStamp, checkNo, roundOffMethod, amount_tendered, gstin, state, discount, interState, subtotal, taxes, quantity, taxDetailed) {
        return recvLib2.save(cart, editPurchaseId, supplierId, employeeId, comment, invoiceNumber, payments, paymentType, total, purchaseOnCreditAmt, StockLocation, timeStamp, checkNo, roundOffMethod, amount_tendered, gstin, state, discount, interState, subtotal, taxes, quantity, taxDetailed)

    };

    foo.clear_mode = function() {
        session.recv_mode = null;
    };

    foo.clearPayments = function() {
        session.recvPayments = [];
    }

    foo.getPurchaseOnCreditAmt = function() {
        var payments = commonLib.get_payments(session);
        var purchaseOnCreditAmt = 0;
        for (var i = 0; i < payments.length; i++) {
            if (payments[i].payment_type === "Purchase On Credit") {
                purchaseOnCreditAmt += payments[i].payment_amount;
            }
        }
        return purchaseOnCreditAmt;
    };

    foo.computeQuantity = function(cart) {
        var quantity = 0;
        for (var i = 0; i < cart.length; i++) {
            quantity = quantity + (cart[i].quantity ? cart[i].quantity : cart[i].quantity_purchased);
        }
        return quantity;
    }

    foo.getJsonForReprint = function(params, applicationSettings) {
        //todo :comment and employee name to be fixed in reprint
        function addInfoForPrint(purchaseDetails, data, supplierInfo, employeeInfo) {
            data.receiving_id = purchaseDetails.receivings_info ? 'RECV ' + purchaseDetails.receivings_info.receiving_id : 'RECVR ' + purchaseDetails.info.id;
            data.comment = purchaseDetails.receivings_info ? purchaseDetails.receivings_info.comment : purchaseDetails.info.comment;
            var purchaseTime = purchaseDetails.receivings_info ? purchaseDetails.receivings_info.receiving_time : purchaseDetails.info.time;
            data.transaction_time = moment(purchaseTime).format(applicationSettings.dateTime.dateformat +
                ' ' + applicationSettings.dateTime.timeformat);

            data.transaction_date = moment(purchaseTime).format(applicationSettings.dateTime.dateformat);
            data.receipt_title = purchaseDetails.receivings_info ? 'Purchase Receipt' : 'Purchase Returns Receipt';

            if (supplierInfo) {
                data.supplier = supplierInfo.first_name + ' ' + supplierInfo.last_name;
                if (supplierInfo.company_name) {
                    data.supplierr_company_name = supplierInfo.company_name;
                }
                data.supplier_id = supplierInfo.person_id;
                data.supplier_address = supplierInfo.address_1;
                data.supplier_location = supplierInfo.zip + ' ' + supplierInfo.city;
                data.account_number = supplierInfo.account_number;
                data.supplier_info = {
                    0: data.supplier,
                    1: supplierInfo.address_1,
                    2: supplierInfo.zip + ' ' + supplierInfo.city,
                    3: supplierInfo.account_number,
                    4: supplierInfo.gstin_number,
                    5: supplierInfo.phone_number
                };

                data.supplier = supplierInfo.company_name;
                data.supplierGSTIN = supplierInfo.gstin_number;
                data.supplier_phone = supplierInfo.phone_number;

            } else if (purchaseDetails.receivings_info && purchaseDetails.receivings_info.wcInfo || purchaseDetails.info && purchaseDetails.info.wcInfo) {
                data.supplier = purchaseDetails.receivings_info ? purchaseDetails.receivings_info.wcInfo.name : purchaseDetails.info.wcInfo.name;
                data.phone_number = purchaseDetails.receivings_info ? purchaseDetails.receivings_info.wcInfo.phone_number : purchaseDetails.info.wcInfo.phone_number;
            } else {
                data.supplier = '';
            }

            data.employee = employeeInfo.first_name + ' ' + employeeInfo.last_name;
            data.company_info = {
                0: applicationSettings.ownersInfo.address,
                1: applicationSettings.ownersInfo.phone,
                2: applicationSettings.ownersInfo.account_number,
                3: applicationSettings.ownersInfo.company
            };
            data.company_address = applicationSettings.ownersInfo.address;
            data.company_phone = applicationSettings.ownersInfo.phone;
            data.company_account = applicationSettings.ownersInfo.account_number;
            data.company_name = applicationSettings.ownersInfo.company;

        }

        function computeTax(price, taxPercent) {
            return taxPercent * 0.01 * price;
        }

        async function fetItemDetail(item_id) {
            return itemsControllerLib.getThisItemInfo({
                item_id: item_id,
                taxType: itemsControllerLib.enPurchaseTax
            }).then(function(resp) {
                return resp;
            });
        }
        //BMTodo Danger Danger decisions and caluclations are done second time. Use the functions written while sale         
        async function computeForReprint(data) {
            var taxes = data.taxes;
            var taxesWithPercents = data.taxesWithPercents;
            var items = data.cart;
            var payments = data.payments;

            for (var i = 0; i < items.length; i++) {
                var item = items[i];

                //why are we using from database.. becuase it could have changed after purchase
                var thisItemInfo = await fetItemDetail(item.item_id);
                if (!thisItemInfo.hasBatchNumber || thisItemInfo.batchId || thisItemInfo.attributeInfo) {
                    let stock = getStockFromBatches(thisItemInfo.batches, thisItemInfo.batchId, thisItemInfo.attributeInfo);
                    if (stock) {
                        item.stockKey = stock.stockKey;
                        item.oldStock = stock;
                    } else {
                        //First time the stock is getting added. Add a new timeStamped Key
                        item.stockKey = itemsControllerLib.formatStockKey(item.item_id, moment().format('x'), item.attributeInfo); //make it a common function
                    }
                }
                item.slab = thisItemInfo.slab;
                item.totalTaxPercent = 0;
                if (item.is_serialized || item.imeiCount !== 0) {
                    var uniqueItems = item.uniqueDetails.reduce(function(acc, cur, i) {
                        acc[i + 1] = cur;
                        return acc;
                    }, {});
                    item.uniqueDetails = uniqueItems;
                }
                for (var j = 0; j < item.itemTaxList.length; j++) {
                    var tax = item.itemTaxList[j];
                    item.totalTaxPercent += tax.percent;
                }

                item.purchasePrice = commonLib.getPPFromUInfo(item.unitsInfo, item.unitId);
                var price = computeUtils.getPriceTaxEx(item.purchasePrice, item.bPPTaxInclusive, item.totalTaxPercent);
                item.purchasePriceExTax = price;
                item.quantity = item.quantity ? item.quantity : item.quantity_purchased;
                item.total = price * item.quantity;
                delete item.quantity_purchased;

                item.totalNoTaxNoDiscount = item.purchasePriceExTax * item.quantity;
                item.discount = item.discount ? item.discount : 0;
                item.totalNoTaxWithDiscount = item.totalNoTaxNoDiscount * (1 - item.discount * 0.01);

                item.totalWithTax = item.total;
                item.total = item.totalNoTaxWithDiscount * (1 + item.totalTaxPercent * 0.01);
                let globalDiscount = data.discount;
                item.totalNoGlobalDiscount = item.totalNoTaxWithDiscount * (1 + item.totalTaxPercent * 0.01);
                if (globalDiscount && globalDiscount.hasOwnProperty('method')) {
                    if (globalDiscount.method == 'onTaxable') {
                        item.totalNoTaxWithDiscount = item.totalNoTaxNoDiscount * (1 - (globalDiscount.percent + item.discount) * 0.01);
                        item.total = item.totalNoTaxWithDiscount * (1 + item.totalTaxPercent * 0.01);
                    } else if (globalDiscount.method == 'onTotal') {
                        item.total = item.total * (1 - (globalDiscount.percent) * 0.01);
                        item.totalNoTaxWithDiscount = item.total / ((1 + item.totalTaxPercent * 0.01));
                        item.totalNoGlobalDiscount = item.totalNoTaxNoDiscount * (1 - item.discount * 0.01) * (1 + item.totalTaxPercent * 0.01);
                        item.totalNoTaxNoDiscount = item.totalNoTaxWithDiscount / (1 - ((globalDiscount.percent + item.discount) * 0.01));
                        // item.total = item.totalNoTaxWithDiscount * (1 + item.totalTaxPercent * 0.01);
                    }
                }

                for (var j = 0; j < item.itemTaxList.length; j++) {
                    var thisTax = item.itemTaxList[j];
                    var taxName = thisTax.name;
                    if (!taxes.hasOwnProperty(taxName)) {
                        taxes[taxName] = 0;

                    }
                    if (!taxesWithPercents.hasOwnProperty(taxName + ' @' + thisTax.percent + '%')) {
                        taxesWithPercents[taxName + ' @' + thisTax.percent + '%'] = 0;
                    }
                    let amt = thisTax.percent * 0.01 * item.totalNoTaxWithDiscount;
                    thisTax.Amt = amt;
                    taxes[taxName] += amt;
                    taxesWithPercents[taxName + ' @' + thisTax.percent + '%'] += amt;
                    // item.totalTax += tax.percent;
                }

                item.totalTax = item.totalTaxPercent * 0.01 * item.totalNoGlobalDiscount;
                data.totalNoGlobalDiscount += item.totalNoGlobalDiscount;
                data.totalNoTaxNoDiscount += item.totalNoTaxNoDiscount;
                data.totalTax += item.totalTax;
                data.totalNoTaxWithDiscount += item.totalNoTaxWithDiscount;
                data.total += item.total;
            }

            for (var taxName in taxes) {
                taxes[taxName] = +taxes[taxName].toFixed(2);
            }
            data.totalWithoutTax = data.totalNoTaxNoDiscount;
            let totalItemDiscount = data.total - data.totalNoTaxWithDiscount;
            var totalBeforeRoundOff = data.total;
            var total = ROUNDOFFNUMBER(totalBeforeRoundOff);
            data.addedRoundOffValue = total - totalBeforeRoundOff;

            var totalPaid = commonLib.getTotalPaidForReprint(payments);

            data.amountDue = ROUNDOFFNUMBER(data.total) - totalPaid;
            data.amount_change = data.amount_tendered ? (data.amount_tendered - data.total) : (-1 * data.amountDue);
            data.total = ROUNDOFFNUMBER(data.total);
        }

        var data = {
            receiving_id: 0,
            total: 0,
            totalNoTaxNoDiscount: 0,
            totalTax: 0,
            amountDue: 0,
            amount_tendered: 0,
            amount_change: 0,
            receipt_title: 'Purchase Receipt',
            transaction_time: '',
            transaction_date: '',
            comments: '',
            cart: [],
            taxes: {},
            taxesWithPercents: {},
            payments: [],
            invoiceNumber: '',
            checkNo: '',
            supplier_id: '',
            purchaseOnCreditAmt: 0,
            totalNoTaxWithDiscount: 0,
            totalNoTaxNoDiscount: 0,
            totalNoGlobalDiscount: 0
        };

        var itemTaxes = [];
        var purchaseDetails = {};
        let type = 'purchase';
        if (params.purchaseId.indexOf('receivingReturn') !== -1) {
            type = 'purchaseReturn';
        }

        return couchDBUtils.getTransDoc(params.purchaseId, mainCouchDB).then(function(resp) {

            if (!resp || resp.statusCode === -1) {
                var msg = {};
                msg.message = 'Purchase Id Not Found';
                logger.error('Purchase Id Not Found');
                return Promise.reject(msg);
            }

            purchaseDetails = resp;

            var props = {};
            var supplierId = resp.receivings_info ? resp.receivings_info.supplier_id : resp.info.supplier_id;
            if (supplierId) {
                props.supplierInfo = couchDBUtils.getDoc('supplier_' + supplierId, mainCouchDB);
            }

            var empId = purchaseDetails.receivings_info ? purchaseDetails.receivings_info.employee_id : purchaseDetails.info.employee_id
            props.employeeInfo = couchDBUtils.getDoc('org.couchdb.user:' + empId, couchDBUtils.getUserCouchDB());

            return BPromise.props(props);
        }).then(async function(resp) {
            data.cart = purchaseDetails.receiving_items ? purchaseDetails.receiving_items : purchaseDetails.items;
            data.payments = purchaseDetails.payments;
            data.totalQuantity = _self.computeQuantity(data.cart);
            data.invoiceNumber = purchaseDetails.receivings_info ? purchaseDetails.receivings_info.invoice_number : purchaseDetails.info.invoice_number;
            data.purchaseOnCreditAmt = purchaseDetails.receivings_info ? purchaseDetails.receivings_info.pending_amount : purchaseDetails.info.pending_amount;
            data.checkNo = purchaseDetails.receivings_info ? purchaseDetails.receivings_info.checkNo : purchaseDetails.info.checkNo;
            data.amount_tendered = purchaseDetails.receivings_info ? purchaseDetails.receivings_info.amount_tendered : purchaseDetails.info.amount_tendered;
            data.discount = (purchaseDetails.receivings_info) ? (purchaseDetails.receivings_info.discount ? purchaseDetails.receivings_info.discount : 0) : purchaseDetails.info.discount;
            await computeForReprint(data);
            addInfoForPrint(purchaseDetails, data, resp.supplierInfo, resp.employeeInfo); //employee customer shop details

            data.payment_options = {};
            for (let i = 0; i < applicationSettings.paymentTerms.value.length; i++) {
                data.payment_options[applicationSettings.paymentTerms.value[i]] = applicationSettings.paymentTerms.value[i];
            }
            data.payment_options['Purchase On Credit'] = 'Purchase On Credit';

            return data;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });

    };

    foo.setTempDetails = function(params) {
        for (let key in params) {
            session.tempPurchaseInfo[key] = params[key];
        }
    };

    //copies all tempPurchaseInfo to output
    foo.getTempDetails = function(output) {
        for (let key in session.tempPurchaseInfo) {
            output[key] = session.tempPurchaseInfo[key];
            if (output.receiving_time) {
                output.receiving_time = moment(output.receiving_time).local().format();
            }
        }
    }

    foo.clearTempDetails = function() {
        for (let key in session.tempPurchaseInfo) {
            session.tempPurchaseInfo[key] = null;
        }
    };

    return foo;

};