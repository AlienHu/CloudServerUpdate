'use strict';

const moment = require('moment');
const logger = require('../common/Logger');
const genericCRUD = require('./libraries/genericCRUD');
const utils = require('./common/Utils');
const ARRAY_LENGTH = utils.getArrayLength;
const CLONE = utils.clone;
const IS_UNDEFINED_OR_NULL = utils.isUndefinedOrNull2;
const DELETE_IF_NOT_NULL = utils.deleteIfNotNull;

const couchDBUtils = require('./common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();
const commonLib = require('./libraries/commonLib');

const autoIncrementHelper = require('./common/autoIncrementHelper');
let maxPaymentId = autoIncrementHelper.getMaxPaymentId();
let maxSaleId = autoIncrementHelper.getMaxRoomSaleId();

const lockUtils = require('../common/lockUtils');
const lockOptions = lockUtils.lockOptions();
const paymentLockPath = 'locks/payment/payment.lock';
const saleLockPath = 'locks/sales/sales.lock';
lockUtils.createLockDir('locks/room');
lockUtils.createLockDir('locks/addOn');
lockUtils.createLockDir('locks/tariff');
lockUtils.createLockDir('locks/payment');

let foo = function() {

    let _self = this;

    let uniqueConstraintFunParamsObj = {
        tariff: {
            designDocName: 'all_unique_data',
            viewName: 'unique_data'
        },
        roomReservation: undefined
    };
    uniqueConstraintFunParamsObj.room = uniqueConstraintFunParamsObj.tariff;
    uniqueConstraintFunParamsObj.addOn = uniqueConstraintFunParamsObj.tariff;

    let validateFunObj = {
        tariff: function validateTariffData(data) {
            let errMsg = '';
            if (!data.name) {
                errMsg += 'Name is Mandatory';
            }

            if (!errMsg) {
                return true;
            } else {
                return errMsg;
            }
        },
        room: function validateRoomData(data) {
            let errMsg = '';
            if (!data.name) {
                errMsg += 'Room No is mandatory ';
            }
            if (!data.tariffId) {
                errMsg += ' Tariff Id is mandatory';
            }

            if (!errMsg) {
                return true;
            } else {
                return errMsg;
            }
        },
        addOn: function validateAddOnData(data) {
            let errMsg = '';
            if (!data.name) {
                errMsg += 'AddOn No is mandatory ';
            }
            if (!data.count) {
                errMsg += ' AddOn count is mandatory';
            }
            if (!data.price) {
                errMsg += ' AddOn price is mandatory';
            }
            if (!errMsg) {
                return true;
            } else {
                return errMsg;
            }
        }
    };

    validateFunObj.addOn = validateFunObj.tariff;

    let canDeleteParamsObj = {
        tariff: {
            designDocName: 'all_dependents_data',
            viewName: 'dependents_data'
        },
        roomReservation: undefined
    };
    canDeleteParamsObj.room = canDeleteParamsObj.tariff;
    canDeleteParamsObj.addOn = canDeleteParamsObj.tariff;

    this.create = async function(data, docPrefix) {
        let params = {
            crudType: genericCRUD.crudType.CREATE,
            docPrefix: docPrefix,
            uniqueConstraintFunParams: uniqueConstraintFunParamsObj[docPrefix],
            validateDataFun: validateFunObj[docPrefix],
            data: data
        };

        return await genericCRUD.crud(params);
    };

    this.updateSettings = async function(data) {
        let params = data;
        if (!params._id) params._id = "pgHotelSettings_1";
        return await genericCRUD.updateSettings(params);
    }
    this.update = async function(data, docPrefix) {
        let params = {
            crudType: genericCRUD.crudType.UPDATE,
            docPrefix: docPrefix,
            uniqueConstraintFunParams: uniqueConstraintFunParamsObj[docPrefix],
            validateDataFun: validateFunObj[docPrefix],
            data: data
        };

        return await genericCRUD.crud(params);
    };

    this.delete = async function(data, docPrefix) {
        let params = {
            crudType: genericCRUD.crudType.DELETE,
            docPrefix: docPrefix,
            canDeleteParams: canDeleteParamsObj[docPrefix],
            data: data
        };

        return await genericCRUD.crud(params);
    };

    //RoomTodo api validation, make sure the data format is binded
    const elementsCntrlr = require('./Elements');

    function toStringN(number, digits) {
        let output = number.toString();
        let paddingLength = digits - output.length;
        for (let i = 0; i < paddingLength; i++) {
            output = '0' + output;
        }

        return output;
    }

    this.getAllReservations = async function() {
        try {
            var resp = await couchDBUtils.getAllDocsByType('roomTrans', mainDBInstance);
            return resp;
        } catch (err) {
            err.msg = 'error getting reservations data';
            return err;
        }
    }

    this.updateBooking = async function(data) {
        let validateResponse = validateBookingData(data);
        if (validateResponse !== true) {
            throw {
                error: validateResponse
            };
        }

        let customerId = data.bookingInfo.customerId;
        if (data.customerInfo) {
            try {
                let resp = await elementsCntrlr.mergeCustomer(data.customerInfo);
                customerId = resp.data.id;
            } catch (error) {
                throw error;
            }
        }

        let bookingInfo = data.bookingInfo;
        let refBookingId = bookingInfo.refBookingId;
        let timeStamp = moment().format('x');
        if (!refBookingId) {
            refBookingId = timeStamp;
        }

        await lockUtils.lockAsync(paymentLockPath, utils.clone(lockOptions));
        for (let i = 0; i < ARRAY_LENGTH(bookingInfo.payments); i++) {
            if (!bookingInfo.payments[i].hasOwnProperty('id')) {
                bookingInfo.payments[i].id = ++maxPaymentId;
            }
        }

        bookingInfo._id = 'roomTrans_' + refBookingId;
        bookingInfo.refBookingId = refBookingId;
        bookingInfo.customerId = customerId;

        try {
            await couchDBUtils.create(bookingInfo, mainDBInstance);
            await lockUtils.unlockAsync(paymentLockPath);
        } catch (error) {
            await lockUtils.unlockAsync(paymentLockPath);
            logger.error('Not Supposed to fail. Update Booking bulkDocs failed');
            throw {
                error: 'System in bad state. Contact Profitguru Support Team'
            };
        }

        return {
            data: {
                id: bookingInfo.refBookingId
            },
            message: 'Success'
        };
    };

    function isUpdate(data) {
        let bUpdate = true;
        if (IS_UNDEFINED_OR_NULL(data.bookingInfo._rev)) {
            bUpdate = false;
        }

        return bUpdate;
    }

    function validatePaymentsInfo(payments) {
        let errMsg = '';
        if (!Array.isArray(payments)) {
            errMsg += 'PaymentsInfo must be an array. ';
        }
        if (errMsg) {
            return errMsg;
        }

        for (let i = 0; i < payments.length; i++) {
            if (IS_UNDEFINED_OR_NULL(payments[i].payment_amount)) {
                errMsg += 'Payment Amount field is mandaotry. '
            }
            if (IS_UNDEFINED_OR_NULL(payments[i].payment_type)) {
                errMsg += 'Payment Type field is mandatory. '
            }
        }

        if (errMsg) {
            return errMsg;
        } else {
            return true;
        }
    }

    function validateBookingData(data) {
        let bUpdate = isUpdate(data);

        let errMsg = '';

        if (IS_UNDEFINED_OR_NULL(data.customerInfo) && IS_UNDEFINED_OR_NULL(data.bookingInfo.customerId)) {
            errMsg += 'Customer Info not found ';
        }

        if (IS_UNDEFINED_OR_NULL(data.bookingInfo)) {
            errMsg += 'Booking Info not found ';
        }

        if (data.bookingInfo.hasOwnProperty('refBookingId') === !bUpdate || IS_UNDEFINED_OR_NULL(data.bookingInfo.refBookingId) === bUpdate) {
            errMsg += 'Reference BookingId is expeccted/yes/no ';
        }

        if (!IS_UNDEFINED_OR_NULL(data.bookingInfo.payments)) {
            let validatePaymentsResp = validatePaymentsInfo(data.bookingInfo.payments);
            if (validatePaymentsResp !== true) {
                errMsg += validatePaymentsResp;
            }
        }

        if (!errMsg) {
            return true;
        } else {
            return errMsg;
        }
    }

    this.checkOut = async function(data) {
        if (!IS_UNDEFINED_OR_NULL(data.bookingInfo)) {
            data.bookingInfo.status = 2;
        }

        try {
            await _self.updateBooking(data);
        } catch (error) {
            throw error;
        }

        try {
            await lockUtils.lockAsync(saleLockPath, lockOptions);
            let saleDoc = CLONE(data.bookingInfo);
            delete saleDoc._rev;
            saleDoc._id = commonLib.formatRoomSaleId(maxSaleId + 1);
            await couchDBUtils.create(saleDoc, mainDBInstance, 2, 'Checkout Failed. Try Again.');
            maxSaleId++;
            lockUtils.unlockAsync(saleLockPath);
            return {
                message: 'Checkout Successful',
                id: maxSaleId
            };
        } catch (error) {
            lockUtils.unlockAsync(saleLockPath);
            logger.error(error);
            throw {
                error: error
            };
        }

    };

};

module.exports = new foo();