var controller = require('../controllers/Reservation.js');
var bodyParser = require('body-parser');
require('errors');
var router = require('express').Router();
router.use(bodyParser.urlencoded({
    extended: true
}));
router.use(bodyParser.json());

//http://racksburg.com/choosing-an-http-status-code/

router.post('/saveReservation', function(req, res, next) {
    controller.saveReservation(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.delete('/deleteReservation', function(req, res, next) {
    controller.deleteReservation(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.get('/selectTable', function(req, res, next) {
    controller.selectTable(req.query).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.get('/minimumReservationDuration', function(req, res, next) {
    controller.minimumReservationDuration(req.query, req.app.locals.applicationSettings).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.get('/getReservationDetails', function(req, res, next) {
    controller.getReservationDetails(req.query).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.get('/getReservationDetails4TableColorChange', function(req, res, next) {
    controller.getReservationDetails4TableColorChange(req.query).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.get('/checkReservation4table', function(req, res, next) {
    controller.checkReservation4table(req.query).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.get('/checkAlreadyReservedRestApi', function(req, res, next) {
    controller.checkAlreadyReserved(req.query, req.app.locals.applicationSettings).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

router.get('/reservationWindow', function(req, res, next) {
    controller.reservationWindow(req.query).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(new Error(reason));
        res.end();
    });
});

module.exports = router;