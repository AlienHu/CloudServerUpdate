var SuppExpress = require('express');
var controller = require('../controllers/Elements.js');
var bodyParser = require('body-parser');
require('errors');
var router = SuppExpress.Router();
router.use(bodyParser.urlencoded({
    extended: true
}));
router.use(bodyParser.json());

//http://racksburg.com/choosing-an-http-status-code/

router.post('/create', function(req, res, next) {
    var supplierData = req.body.supplier;
    supplierData.type = "supplier_";
    controller.create(supplierData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

router.put('/update', function(req, res, next) {
    var supplierData = req.body.supplier;
    supplierData.type = "supplier_";
    controller.update(supplierData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

router.delete('/delete', function(req, res, next) {
    var supplierData = req.body.supplier;
    supplierData.type = "supplier_";
    controller.delete(supplierData).then(function(resp) {
        res.sendStatus(200);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

router.post('/import', function(req, res, next) {
    var supplierData = req.body.data;

    controller.import(supplierData, "supplier").then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        res.send(reason);
        res.end();
    });

});

module.exports = router;