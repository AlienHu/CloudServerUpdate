var express = require('express');
var router = express.Router();
var controller = require('../Reports/gstr1.js');

router.post('/gstr1_12', function(req, res) {
    var requestData = req.body;

    controller.head_12(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.post('/gstr2', function(req, res) {
    let controller2 = require('../Reports/gstr2.js');
    var requestData = req.body;

    controller2.getReports(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

router.get('/getGSTSummaryByHSN', function(req, res) {
    var requestData = req.query;

    controller.head_12(requestData).then(function(resp) {
        res.send(resp.head_12);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        res.send(new Error(reason.msg));
        res.end();
    });
});

module.exports = router;