var express = require('express');
var router = express.Router();

if (process.env.enableSelfUpdate !== 'true') {
    router.get('/isUpdateAvailable', function (req, res) {
        var resp = {
            updateAvailable: false,
            currentServerVersion: '0.0.0.0'
        }
        res.send(resp);
        res.end();
    });
}

router.get('/isSelfUpdateEnabled', function (req, res) {
    var resp = {
        bSelfUpdate: process.env.enableSelfUpdate === 'true'
    }
    res.send(resp);
    res.end();
});

module.exports = router;