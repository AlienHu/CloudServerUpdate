var express = require('express');
var router = express.Router();
var reportEmailController = require('../controllers/SendReportEmail');
var receiptEmailController = require('../controllers/sendRceiptEmail');
var licenceEmailController = require('../controllers/sendLicenceEmail');
var licanceController = require('../controllers/licence.js');
var fs = require('fs');
var sendSMS = require('../sms/sms');
var smsDAO = require('../sms/smsDAO');

router.put('/sendLicenceEmail', function(req, res) {
    var requestData = req.body;
    return licanceController.activationRequest(requestData.data.clientId).then(function(resp) {
        return licenceEmailController(requestData);
    }).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        var errResponse = {}
        errResponse.error = {};
        errResponse.error = reason;
        if (reason.code === 'ECONNECTION') {
            reason.error = "Apply Licence Failed , Check your Internet Connection";
            errResponse.error.message = "Apply Licence Failed , Check your Internet Connection";
        }
        errResponse = JSON.stringify(errResponse);
        res.send(new Error(errResponse));
        res.end();
    });
});

router.put('/sendEmailApi', function(req, res) {
    var requestData = req.body;

    return reportEmailController(requestData, res).then(function(resp) {
        if (!resp) {
            return;
        }
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        var errResponse = {}
        errResponse.error = {};
        errResponse.error = reason;
        if (reason.code === 'ECONNECTION') {
            reason.error = "Sending Email Failed , Check your Internet Connection";
            errResponse.error.message = "Sending Email Failed , Check your Internet Connection";
        }
        errResponse = JSON.stringify(errResponse);
        res.send(new Error(errResponse));
        res.end();
    });
});

router.put('/sendReceiptEmail', function(req, res) {
    var requestData = req.body;

    return receiptEmailController(requestData).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(reason) {
        console.log(reason);
        var errResponse = {}
        errResponse.error = {};
        errResponse.error = reason;
        if (reason.code === 'ECONNECTION') {
            reason.error = "Sending Email Failed , Check your Internet Connection";
            errResponse.error.message = "Sending Email Failed , Check your Internet Connection";
        }
        errResponse = JSON.stringify(errResponse);
        res.send(new Error(errResponse));
        res.end();
    });
});

router.put('/sendSMS', function(req, res) {
    return sendSMS(req.body).then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(err) {
        console.log(JSON.stringify(err));
        res.status(406).send(err);
        res.end();
    });
});

router.get('/getBarcodeParamsToPrint', function(req, res) {
    try {
        var resp = fs.readFileSync(__dirname + '/../config/barcodeParams.json', 'utf-8');
        res.send(resp);
        res.end();
    } catch (err) {
        res.send(err);
        res.end();
    }
});

router.post('/setBarcodeParamsToPrint', function(req, res) {
    try {
        var resp = fs.writeFileSync(__dirname + '/../config/barcodeParams.json', JSON.stringify(req.body), 'utf-8');
        res.send(resp);
        res.end();
    } catch (err) {
        res.send(err);
        res.end();
    }
});

router.get('/getSMSConfig', function(req, res) {
    return smsDAO.get().then(function(resp) {
        res.send(resp);
        res.end();
    }).catch(function(err) {
        console.log(err);
        res.status(406).send(err);
        res.end();
    });
});
module.exports = router;