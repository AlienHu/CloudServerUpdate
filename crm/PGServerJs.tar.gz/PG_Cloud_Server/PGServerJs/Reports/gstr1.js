'use strict';

let gstr1 = function() {
    require('dotenv-safe').load({
        path: __dirname + '/../.env',
        sample: __dirname + '/../env.example'
    });

    const couchDBUtils = require('../controllers/common/CouchDBUtils');
    const configState = require('../common/configState');
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const moment = require('moment');

    const taxesInfo = {
        igst: {
            gstFactor: 1,
            stateType: 'inter'
        },
        cgst: {
            gstFactor: 2,
            stateType: 'intra'
        },
        sgst: {
            gstFactor: 2,
            stateType: 'intra'
        },
        cess: {
            gstFactor: 0,
            stateType: ''
        }
    };

    const HEADER_12_LABELS = {
        1: "HSN",
        2: "Description",
        3: "UQC",
        4: "Total Quantity",
        5: "Total Value",
        6: "Total Taxable Value",
        7: "IGST",
        8: "CGST",
        9: "SGST",
        10: "Cess"
    };
    const HEADER_7A_LABELS = {
        1: "Rate of Tax",
        2: "Taxable Value",
        3: "IGST",
        4: "CGST",
        5: "SGST",
        6: "Cess"
    };

    function initHead12Json(hsnLabel, head_12, item) {
        head_12[hsnLabel] = {};
        head_12[hsnLabel].hsn = item.hsn ? item.hsn : 'N.A.';
        head_12[hsnLabel].description = item.description;
        head_12[hsnLabel].uqc = item.unit;
        head_12[hsnLabel].quantity = 0;
        head_12[hsnLabel].totalValue = 0;
        head_12[hsnLabel].totalTaxableValue = 0;
        for (let taxName in taxesInfo) {
            head_12[hsnLabel][taxName] = 0;
        }
    }

    this.head_12 = async function(data) {
        // TODO: header for all
        // TODO: heading 9, 10, 11
        let _month = data.month;
        let _year = data.year;
        let startTime;
        let endTime;
        if (data.start_date && data.end_date) {
            startTime = parseInt(moment(data.start_date).startOf('day').format('x'));
            endTime = parseInt(moment(data.end_date).endOf('day').format('x'));
        } else {
            if (_month === undefined) {
                //current month
                _month = parseInt(moment().format('MM')) - 1;
            }

            if (_year === undefined) {
                //current year
                _year = parseInt(moment().year());
            }
            startTime = parseInt(moment().month(_month).year(_year).startOf('month').format('x'));
            endTime = parseInt(moment().month(_month).year(_year).endOf('month').format('x'));

        }

        try {
            let params = {
                startkey: startTime,
                endkey: endTime,
                include_docs: false
            };
            let resp = await couchDBUtils.getTransView('all_sales_info', 'all_sale_time', params, mainDBInstance, 'sale');
            let gstr1 = {};
            gstr1.head_4 = [];
            gstr1.head_5 = [];
            gstr1.head_8 = [];
            gstr1.head_7a = [HEADER_7A_LABELS];
            gstr1.head_7b = [];
            let head_12 = {};
            head_12.headerLabels = HEADER_12_LABELS;

            let head_common = {};

            for (let i = 0; i < resp.length; i++) {
                let invoiceValue = resp[i].sales_info.total;
                let _id = resp[i].sales_info._id;
                let doc = resp[i];
                if (doc.bRejected) {
                    continue;
                }

                // skip next loop if sale_items is undefind
                // Credit Document, Room Reservation
                if (!doc.sale_items) continue;

                let customerGSTIN = "";
                let customerType = 'b2b';
                customerGSTIN = doc.sales_info.GSTIN;
                if (customerGSTIN == "" || !customerGSTIN) {
                    customerType = 'b2c';
                }

                let invoiceDate = new Date(doc.sales_info.sale_time).toLocaleString('en-IN');
                let applicationSettings = configState.getApplicationSettings();
                let invoiceNo = doc.sales_info.num ? (doc.sales_info.invoicePrefix ? doc.sales_info.invoicePrefix : applicationSettings.invoiceDefaultCheckpoint.prefix) + "_" + doc.sales_info.num : doc.sales_info.sale_id;
                let supplyState = doc.sales_info.state_name;

                let stateType = '';
                let totalTaxableValue = 0;

                for (let j = 0; j < doc.sale_items.length; j++) {
                    let hsn = doc.sale_items[j].hsn ? doc.sale_items[j].hsn : 'N.A.';
                    let hsnLabel = ('hsn_' + hsn);

                    let cal = this.calculatePriceHandler(doc.sale_items[j]);

                    if (!head_12[hsnLabel]) {
                        initHead12Json(hsnLabel, head_12, doc.sale_items[j]);
                    }
                    head_12[hsnLabel].quantity += doc.sale_items[j].quantity_purchased;
                    head_12[hsnLabel].totalValue += cal.totalValue;
                    head_12[hsnLabel].totalTaxableValue += cal.totalNoTax;

                    let taxRate = 0;
                    for (let z = 0; z < cal.itemTaxList.length; z++) {
                        let taxName = cal.itemTaxList[z].name.toLowerCase();
                        // let taxAmt = cal.itemTaxList[z].amount;
                        if (taxesInfo[taxName] && taxesInfo[taxName].gstFactor) {
                            taxRate = cal.itemTaxList[z].percent * taxesInfo[taxName].gstFactor;
                            stateType = taxesInfo[taxName].stateType;
                            break;
                        }
                    }

                    let taxLabel = (_id + '_tax_' + taxRate);
                    if (!head_common[taxLabel]) {
                        head_common[taxLabel] = {};
                        head_common[taxLabel].customerGSTIN = customerGSTIN;
                        head_common[taxLabel].invoiceNo = invoiceNo;
                        head_common[taxLabel].invoiceDate = invoiceDate;
                        head_common[taxLabel].taxRate = taxRate;
                        head_common[taxLabel].customerType = customerType;
                        head_common[taxLabel].supplyState = supplyState;
                        head_common[taxLabel].invoiceValue = 0;
                        head_common[taxLabel].totalTaxableValue = 0;
                        head_common[taxLabel].stateType = stateType;
                        head_common[taxLabel].saleId = _id;
                        head_common[taxLabel].totalValue = 0;
                        for (let taxName in taxesInfo) {
                            head_common[taxLabel][taxName] = 0;
                        }
                    }

                    for (let z = 0; z < cal.itemTaxList.length; z++) {
                        let taxName = cal.itemTaxList[z].name.toLowerCase();
                        let taxAmt = cal.itemTaxList[z].amount;
                        if (head_12[hsnLabel].hasOwnProperty(taxName)) {
                            head_12[hsnLabel][taxName] += taxAmt;
                        }
                        if (head_common[taxLabel].hasOwnProperty(taxName)) {
                            head_common[taxLabel][taxName] += taxAmt;
                        }
                    }

                    head_common[taxLabel].totalValue += cal.totalValue;
                    head_common[taxLabel].totalTaxableValue += cal.totalNoTax;
                    head_common[taxLabel].invoiceValue = invoiceValue;
                    head_common[taxLabel].bZeroTax = doc.sales_info.taxes.Total ? false : true;
                }

            }

            let keys = Object.keys(head_common);
            for (let i = 0; i < keys.length; i++) {
                let tmpRow = head_common[keys[i]];
                delete(tmpRow.__proto__);
                const bZeroTax = tmpRow.bZeroTax;
                delete(tmpRow.bZeroTax);
                if (tmpRow.cgst == 0 && tmpRow.sgst == 0 && tmpRow.igst == 0 && bZeroTax) { // if all taxes are 0
                    delete(tmpRow.customerGSTIN);
                    gstr1.head_8.push(tmpRow);
                } else if (tmpRow.customerType == 'b2b') {
                    delete(tmpRow.customerType);
                    delete(tmpRow.stateType);
                    delete(tmpRow.saleId);
                    delete(tmpRow.totalValue);
                    gstr1.head_4.push(tmpRow);
                } else if (tmpRow.customerType == 'b2c' && tmpRow.stateType == 'intra') {
                    delete(tmpRow.customerGSTIN);
                    delete(tmpRow.customerType);
                    delete(tmpRow.invoiceDate);
                    delete(tmpRow.invoiceNo);
                    delete(tmpRow.invoiceValue);
                    delete(tmpRow.stateType);
                    delete(tmpRow.supplyState);
                    delete(tmpRow.saleId);
                    delete(tmpRow.totalValue);
                    gstr1.head_7a.push(tmpRow);
                } else if (tmpRow.customerType == 'b2c' && tmpRow.stateType == 'inter' && tmpRow.invoiceValue <= 250000) {
                    delete(tmpRow.customerGSTIN);
                    delete(tmpRow.customerType);
                    delete(tmpRow.invoiceDate);
                    delete(tmpRow.invoiceNo);
                    delete(tmpRow.invoiceValue);
                    delete(tmpRow.stateType);
                    delete(tmpRow.supplyState);
                    delete(tmpRow.saleId);
                    delete(tmpRow.totalValue);
                    gstr1.head_7b.push(tmpRow);
                } else if (tmpRow.customerType == 'b2c' && tmpRow.stateType == 'inter' && tmpRow.invoiceValue > 250000) {
                    delete(tmpRow.customerGSTIN);
                    delete(tmpRow.customerType);
                    delete(tmpRow.stateType);
                    delete(tmpRow.saleId);
                    delete(tmpRow.totalValue);
                    delete(tmpRow.cgst);
                    delete(tmpRow.sgst);
                    gstr1.head_5.push(tmpRow);
                }
            }

            gstr1.head_12 = Object.values(head_12);

            return gstr1;
        } catch (err) {
            throw err;
        }
    }

    /**
     * taxList - name, per, amt
     * totalValue
     * totalTaxableValue
     */
    this.calculatePrice = function(item) {
        if (!item.itemTaxList) {
            item.itemTaxList = [];
        }
        if (!item.chargesTaxList) {
            item.chargesTaxList = [];
        }
        if (!item.chargesList) {
            item.chargesList = [];
        }

        item.quantity = item.quantity_purchased;
        item.uqc = item.unit;
        item.gDiscountPercent = item.gDiscountPercent ? item.gDiscountPercent : 0;
        let discount = (item.discount_percent + item.gDiscountPercent) * 0.01
        let totalNoChargesNoTax = item.sellingPrice * item.quantity * (1 - discount);

        let totalChargesPercent = 0;
        for (let i = 0; i < item.chargesList.length; i++) {
            totalChargesPercent = item.chargesList[i].percent
        }
        let totalChargeAmount = totalNoChargesNoTax * totalChargesPercent * 0.01;
        let totalNoTax = totalNoChargesNoTax + totalChargeAmount;

        let taxesObj = {};
        let totalTaxAmount = 0;
        for (let i = 0; i < item.itemTaxList.length; i++) {
            let taxAmt = (totalNoChargesNoTax * item.itemTaxList[i].percent) * 0.01;

            let taxObjKey = item.itemTaxList[i].name + '-' + item.itemTaxList[i].percent;
            if (!taxesObj[taxObjKey]) {
                taxesObj[taxObjKey] = {
                    name: item.itemTaxList[i].name,
                    percent: item.itemTaxList[i].percent,
                    amount: 0
                };
            }
            totalTaxAmount += taxAmt;
            taxesObj[taxObjKey].amount += taxAmt;
        }

        for (let i = 0; i < item.chargesTaxList.length; i++) {
            let taxAmt = (totalChargeAmount * item.chargesTaxList[i].percent) * 0.01;

            let taxObjKey = item.chargesTaxList[i].name + '-' + item.chargesTaxList[i].percent;
            if (!taxesObj[taxObjKey]) {
                taxesObj[taxObjKey] = {
                    name: item.chargesTaxList[i].name,
                    percent: item.chargesTaxList[i].percent,
                    amount: 0
                };
            }
            totalTaxAmount += taxAmt;
            taxesObj[taxObjKey].amount += taxAmt;
        }

        let totalValue = totalNoTax + totalTaxAmount;

        let result = {};
        result.itemTaxList = Object.values(taxesObj);
        result.totalValue = totalValue;
        result.totalNoTax = totalNoTax;

        return result;
    };

    this.calculatePriceHandler = function(item) {
        if (item.bSPTaxInclusive == false)
            return this.calculatePrice(item);
        else {
            let totalTaxPercent = 0;
            for (let i = 0; i < item.itemTaxList.length; i++) {
                totalTaxPercent += item.itemTaxList[i].percent;
            }

            let sellingPriceExTax = ((item.sellingPrice) / (1 + (0.01 * totalTaxPercent)));
            item.sellingPrice = sellingPriceExTax;
            return this.calculatePrice(item);
        }
    };

};

module.exports = new gstr1();