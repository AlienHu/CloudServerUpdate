   'use strict';
   require('dotenv-safe').load({
       path: __dirname + '/../.env',
       sample: __dirname + '/../env.example'
   });

   const chai = require("chai");
   const chaiAsPromised = require("chai-as-promised");

   const faker = require('faker');

   chai.use(chaiAsPromised);
   chai.should();
   const expect = chai.expect;

   const couchDbManager = require('../dbManagers/couchDbManager');
   const couchDBUtils = require('../controllers/common/CouchDBUtils');
   const mainDBInstance = couchDBUtils.getMainCouchDB();

   let testUtils;

   describe('Elements UTs', function() {

       this.timeout(500000);

       before(async function() {
           await couchDbManager.initCouchDb(false);
           testUtils = require('./gstr1.js');
       });
       it('hsn 4', async function() {
           var resp = await testUtils.head_4();
           console.log(resp);
           expect(1).to.equal(1);
       });
       it('hsn 12', async function() {
           var resp = await testUtils.head_12();
           //    console.log(resp);
           var keys = Object.keys(resp);
           for (var i = 0; i < keys.length; i++) {
               var row = resp[keys[i]];
               expect(row).to.have.property('uqc').not.equals('');
               expect(row).to.have.property('hsn').gt(0);
               expect(row).to.have.property('quantity').gt(0);
               expect(row).to.have.property('cgst').gt(0);
               expect(row).to.have.property('sgst').gt(0);
               expect(row).to.have.property('totalValue').gt(0);
               expect(row).to.have.property('totalTaxableValue').gt(0);
               //    expect(row).to.have.property('igst');
           }

       });
       it('calculatePriceHandler', async function() {
           var doc = {
               sellingPrice: 1000,
               discount_percent: 4,
               bSPTaxInclusive: false,
               quantity_purchased: 5,
               itemTaxList: [{
                       name: 'CGST',
                       percent: 20
                   },
                   {
                       name: 'SGST',
                       percent: 12
                   }
               ],
               chargesList: [{
                   name: 'Service',
                   percent: 11.6
               }],
               chargesTaxList: [{
                   name: 'VAT',
                   percent: 10
               }]

           }
           doc.quantity = doc.quantity_purchased;
           var discount = 0.01 * doc.discount_percent;
           var resp = await testUtils.calculatePriceHandler(doc);
           //    console.log(resp);

           //    if (doc.bSPTaxInclusive == false) {
           var taxSum = 0;
           for (var i = 0; i < doc.itemTaxList.length; i++) {
               taxSum += doc.itemTaxList[i].percent;
           }

           var chargesSum = 0;
           for (var i = 0; i < doc.chargesList.length; i++) {
               chargesSum += doc.chargesList[i].percent;
           }

           var chargesTaxSum = 0;
           for (var i = 0; i < doc.chargesTaxList.length; i++) {
               chargesTaxSum += doc.chargesTaxList[i].percent;
           }

           var tax = 0.01 * taxSum;
           var charges = 0.01 * chargesSum;
           var chargesTax = 0.01 * chargesTaxSum;

           var totalValue = doc.sellingPrice * doc.quantity * (1 - discount) * (1 + tax) + doc.sellingPrice * doc.quantity * (1 - discount) * charges * (1 + chargesTax);
           var totalNoDiscountNoChargesNoTax = doc.sellingPrice * doc.quantity;
           var totalNoChargesNoTax = doc.sellingPrice * doc.quantity * (1 - discount);
           var totalNoTax = doc.sellingPrice * doc.quantity * (1 - discount) * (1 + charges);
           var totalDiscount = doc.sellingPrice * doc.quantity * discount;
           var totalCharges = doc.sellingPrice * doc.quantity * (1 - discount) * (charges);
           var totalTax = doc.sellingPrice * doc.quantity * (1 - discount) * (tax) + doc.sellingPrice * doc.quantity * (1 - discount) * (charges) * chargesTax;
           var totalChargesTaxPercent = doc.sellingPrice * doc.quantity * (1 - discount) * (charges) * chargesTax;

           expect(resp).to.have.property('totalValue').equals(totalValue);
           expect(resp).to.have.property('totalNoChargesNoTax').equals(totalNoChargesNoTax);
           expect(resp).to.have.property('totalNoDiscountNoChargesNoTax').equals(totalNoDiscountNoChargesNoTax);
           expect(resp).to.have.property('totalNoTax').equals(totalNoTax);
           expect(resp).to.have.property('totalDiscount').equals(totalDiscount);
           expect(resp).to.have.property('totalCharges').equals(totalCharges);
           expect(resp).to.have.property('totalTax').equals(totalTax);
           expect(resp).to.have.property('totalChargesTaxPercent').equals(totalChargesTaxPercent);

       });

       it.only('gstr report', async function() {
           let resp = await testUtils.head_12({
               month: 7
           });
           console.log(resp);
       });

   });