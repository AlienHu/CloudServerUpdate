/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function (params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const mainDBInstance = couchDBUtils.getMainCouchDB();

        let migrationName = path.basename(__filename, '.js');
        try {
            let allTableDocs = await couchDBUtils.getAllDocsByType('table', mainDBInstance);
            var newDocs = [];
            for (let i = 0; i < allTableDocs.length; i++) {
                let tableDoc = allTableDocs[i].doc;
                if (typeof (tableDoc.table_no) === "number") {
                    tableDoc.table_no = tableDoc.table_no.toString();
                    newDocs.push(tableDoc);
                }
            }
            if (newDocs.length) {
                await couchDBUtils.bulkInsert(mainDBInstance, newDocs);
            }

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    },

    down: async function (params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');

        let migrationName = path.basename(__filename, '.js');
        throw migrationName + ' Down migration not allowed,  migration failed';

    }
};









