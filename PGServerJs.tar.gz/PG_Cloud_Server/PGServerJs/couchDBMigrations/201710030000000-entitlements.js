/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;
        try {

            var params = {};
            await couchDBUtils2.createCouchDbAndViews(nanoUsers, '_users');
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);

            var allUsersDoc = [];
            for (var i = 0; i < allUsers.length; i++) {
                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);

                delete allUsers[i].value.roles[0].globalConfigs;

                delete allUsers[i].value.roles[0].orderCounter;
                delete allUsers[i].value.roles[0].paymentCounter;
                delete allUsers[i].value.roles[0].tableReservations;
                delete allUsers[i].value.roles[0].tallyIntegration;
                var json = {
                    desc: "Category, Taxes, Discounts, ...",
                    allowNone: false,
                    allowAll: false,
                    viewOnMenu: false,
                    add: {
                        apis: ["createCategory", "createTax", "createDiscount", "createUnit", "createCharge", "createSlab", "createProfile", "createBrand", "createVariant"],
                        allowed: false,
                        desc: "Allows to Create :: Category, Discounts, Taxes, Discounts, .."
                    },
                    view: {
                        apis: [],
                        allowed: false,
                        desc: "Allowes to View :: Category, Discounts, Taxes, Discounts, .."
                    },
                    delete: {
                        apis: ["deleteCategory", "deleteTax", "deleteDiscount", "deleteUnit", "deleteCharge", "deleteSlab", "deleteProfile", "deleteBrand", "deleteVariant"],
                        allowed: false,
                        desc: "Allowes to Delete :: Category, Discounts, Taxes, Discounts, .."
                    },
                    update: {
                        apis: ["updateCategory", "updateTax", "updateDiscount", "updateUnit", "updateCharge", "updateSlab", "updateProfile", "updateBrand", "updateVariant"],
                        allowed: false,
                        desc: "Allowes to Update :: Category, Discounts, Taxes, Discounts, .."
                    }
                };

                var seetingsJson = {
                    desc: "Allows to Change or View the Application Settings",
                    apis: ["ConfigSettings4customersLoyalityRestApi", "saveConfigRestAPI", "saveLocaleConfigRestAPI", "saveBarcodeRestApi", "saveLocationsRestAPI", "savePrinterSettingsRestApi", "BackupDBRestApi"],
                    installUpdate: {},
                    viewBackup: {},
                    takeBackup: {},
                    restoreBackup: {},
                    checkApplicationUpdates: {}
                };

                seetingsJson.view = allUsers[i].value.roles[0].applicationSettings.view;
                seetingsJson.update = allUsers[i].value.roles[0].applicationSettings.update;
                seetingsJson.viewOnMenu = allUsers[i].value.roles[0].applicationSettings.viewOnMenu;
                seetingsJson.allowNone = allUsers[i].value.roles[0].applicationSettings.allowNone;
                seetingsJson.allowAll = allUsers[i].value.roles[0].applicationSettings.allowAll;
                // seetingsJson.checkApplicationUpdates = allUsers[i].value.roles[0].profitGuruUpdate.view;

                if (allUsers[i].value.roles[0].profitGuruUpdate && allUsers[i].value.roles[0].profitGuruUpdate) {
                    seetingsJson.installUpdate = Object.assign({}, allUsers[i].value.roles[0].profitGuruUpdate.installUpdate);
                    seetingsJson.viewBackup = Object.assign({}, allUsers[i].value.roles[0].backUpAndRestore.view);
                    seetingsJson.takeBackup = Object.assign({}, allUsers[i].value.roles[0].backUpAndRestore.backup);
                    seetingsJson.restoreBackup = Object.assign({}, allUsers[i].value.roles[0].backUpAndRestore.restore);
                    seetingsJson.checkApplicationUpdates = Object.assign({}, allUsers[i].value.roles[0].profitGuruUpdate.view);
                    delete allUsers[i].value.roles[0].backUpAndRestore;
                    delete allUsers[i].value.roles[0].profitGuruUpdate;
                }
                // delete allUsers[i].value.roles[0].applicationSettings;
                // delete allUsers[i].value.roles[0].applicationSettings.Delete;
                allUsers[i].value.roles[0].applicationSettings = seetingsJson;
                if (allUsers[i].value.roles[1] === 'admin') {
                    json.allowAll = true;
                    json.viewOnMenu = true;
                    json.add.allowed = true;
                    json.view.allowed = true;
                    json.delete.allowed = true;
                    json.update.allowed = true;

                }
                allUsers[i].value.roles[0].itemManagement = json;
                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                allUsersDoc.push(allUsers[i].value);
            }

            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);
            let allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', nanoCore);
            // allowedFeatures.itemManagement = {};
            let coreDocs = [];

            // allowedFeatures.itemManagement = allowedFeatures.globalConfigs;
            allowedFeatures.itemManagement = Object.assign({
                "enabled": true,
                "desc": ""
            }, allowedFeatures.globalConfigs);
            delete allowedFeatures.globalConfigs;

            coreDocs.push(allowedFeatures);

            await couchDBUtils.bulkInsert(nanoCore, coreDocs);
        } catch (error) {
            logger.error(error);
            throw migrationName + ' migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            /**
             * ignoring revertion of profitGuruUpdate and backupandRestore entitlements from applicationsettings to outside as for now 
             * because of assumption that will not break old functionality 
             * also , in this migration we are not moving back tallyIntegration , counterorder and counter payment from inProgress to restaurant app specific json
             */
            var params = {};
            let allUsersDoc = [];
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            for (var i = 0; i < allUsers.length; i++) {
                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);

                if (allUsers[i].value.roles[0].hasOwnProperty('itemManagement')) {
                    allUsers[i].value.roles[0].globalConfigs = {};
                    allUsers[i].value.roles[0].globalConfigs = Object.assign({}, allUsers[i].value.roles[0].itemManagement);
                    delete allUsers[i].value.roles[0].itemManagement;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('itemManagement property not found');
                }

                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                allUsersDoc.push(allUsers[i].value);
            }

            await couchDBUtils.bulkInsert(nanoUsers, allUsersDoc);

            let allowedFeatures = await couchDBUtils.getDoc('profitGuruAllowedFeatures_', nanoCore);
            let coreDocs = [];
            allowedFeatures.globalConfigs = Object.assign({}, allowedFeatures.itemManagement);
            delete allowedFeatures.itemManagement;

            coreDocs.push(allowedFeatures);

            await couchDBUtils.bulkInsert(nanoCore, coreDocs);
        } catch (error) {
            logger.error(error);
            logger.error('application settings update failed');
            throw error;
        }
    }
};