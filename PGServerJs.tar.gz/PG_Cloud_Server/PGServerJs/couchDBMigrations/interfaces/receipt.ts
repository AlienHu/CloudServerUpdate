export namespace Receipt {

    export interface Item {
        item_id: number;
        ItemType: string;
        name: string;
        description: string;
        is_serialized?: boolean;
        imeiCount?: number;
        hasBatchNumber: boolean;
        bOTG: boolean;
        hsn: number;
        hasExpiryDate: boolean;
        bSPTaxInclusive: boolean;
        bPPTaxInclusive: boolean;
        baseUnitId: string;

        //as is details from stock
        stockKey: string;
        batchId: string;
        expiry: string;

        //static details
        item_location: number;
        stock_name: string;

        //others
        line: number;
        //Selected fields
        //selected imei and serial numbers .. if it is there then quanity should be 1
        imeiNumbers: ImeiNumbers;
        serialnumber: Serialnumber;
        unit: string;
        unitId: string;

        //edited input fields
        quantity: number;
        discount: number;
        price: number;
        mrp: number;
        purchasePrice: number;

        //computed fields
        gDiscountPercent: number;
        gDiscountAmt: number;
        total: number;
        discounted_total: number;
        discounted_price: number;
        totalAfterDisAndCharges: number;
        totalWithTax: number;

        //taxes and charges
        chargesList: TaxEx[];
        chargesTaxList: TaxEx[];
        itemTaxList: TaxEx[];
    }

    export interface Doc {
        cart: Item[];

        discount: number;
        addedRoundOffValue: number;

        //tax computations
        bLocalTax: boolean;
        taxesWithPercents: TaxesWithPercentItrObj;
        taxDetailed: TaxDetailedItrObj;
        taxNames: TaxNamesItrObj;
        hsnTaxes: HsnTaxesItrObj;
        taxes: TaxesByNameItrObj;

        //total quantity
        totalQuantity: number;

        //totals
        total: number;
        subtotal: number;
        discounted_subtotal: number;
        totalWithoutTax: number;
        tax_exclusive_subtotal: number;
        comments: string;
        amount_change: number;

        globalDiscountInfo: GlobalDiscountInfo;

        //payments
        payments: Payment[];
        saleOnCreditAmt: number;
        amount_due: number;

        //sale params
        sale_id: string;
        transaction_time: string;
        transaction_date: string;

        //UI fields
        print_after_sale: boolean;

        //employee
        employee: string;
        //company
        company_address: string;
        company_phone: string;
        company_name: string;
        company_account: string;

        //customer fields
        customer_compnay_name: string;
        customer: string;
        customer_address: string;
        customer_location: string;
        customer_id: string;
        account_number: string;
        phone_number: string;
        _id?: string;
        orderStatus?: string;
        num?: string;
        bSendSMS?: boolean;
    }
}

export interface UniqueDetailInfo {
    serialnumber: string;
    imeiNumbers: ImeiNumbers;
}

export interface UniqueDetail {
    info: UniqueDetailInfo;
    sold?: boolean;
    itemAvailable?: boolean;
}

export interface UniqueDetails {
    [uniqueDetailKey: string]: UniqueDetail;
}

export type ImeiNumbers = string[];
export type Serialnumber = string;

export interface Tax {
    name: string;
    percent: number;
}

export interface TaxInfo extends Tax {
    _id: string;
    _rev: string;
    id: any;
}

export interface TaxEx extends Tax {
    Amt: number;
}

export interface TaxesWithPercentItrObj {
    [taxNamePlusPercent: string]: number;
}

export interface GlobalDiscountInfo {
    readonly amt: number;
    readonly percent: number;
    readonly discountMethod: string;
}

export interface Payment {
    payment_type: string;
    payment_amount: number;
    refNo?: string;
}

export interface HsnTaxesItrObj {
    [hsn: number]: taxItrObj1;
}
export interface TaxNamesItrObj {
    [taxName: string]: boolean;
}

export interface TaxDetailedItrObj {
    [taxPercent: number]: TaxAmtByPercentItrObj
}

export interface TaxAmtByPercentItrObj {
    taxable: number;
    [taxName: string]: number;
}
export interface taxItrObj1 {
    // taxable: number; //--> not a proper interface
    [taxName: string]: TaxPercentAmtItrObj;
}

export interface TaxPercentAmtItrObj {
    [taxPercent: number]: number;
}

export interface TaxesByNameItrObj {
    [taxName: string]: number;
}