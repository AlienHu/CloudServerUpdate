/**
 */
'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require('fs');
var path = require('path');
exports.up = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const batchProcess = require(appRootPath + 'controllers/libraries/batchProcessUtil').batchProcess;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        let usersdb = nanoClients._users;
        try {
            const taxLib = require('./libraries/taxDetailsCommon');
            const getTaxesByPercentageDetailed = taxLib.getTaxesByPercentageDetailed;
            function getTotalPercent(taxArray, itemId) {
                try {
                    var totalTaxPercent = 0;
                    if (!taxArray)
                        return totalTaxPercent;
                    for (var j = 0; j < taxArray.length; j++) {
                        var itemTax = taxArray[j];
                        if (!itemTax.item_id || itemTax.item_id === itemId) {
                            totalTaxPercent += parseFloat(itemTax.percent);
                        }
                    }
                    return totalTaxPercent;
                }
                catch (ex) {
                    console.log("ex");
                    console.log(ex);
                    return totalTaxPercent;
                }
            }
            function getPriceTaxEx(price, bTaxInclusive, totalTaxPercent) {
                var priceExcludingTax = price;
                if (bTaxInclusive) {
                    priceExcludingTax = calculatePriceExcludingTax(price, totalTaxPercent);
                }
                ;
                return priceExcludingTax;
            }
            ;
            function calculatePriceExcludingTax(price, taxPercent) {
                var factor = 1 + (taxPercent * 0.01);
                var priceExTax = price / factor;
                return priceExTax;
            }
            function computepxax0dot01(p, a) {
                return (p * a * 0.01);
            }
            ;
            function add(a, b) {
                return (a + b);
            }
            ;
            function multiply(a, b) {
                return (a * b);
            }
            function subtract(a, b) {
                return (a - b);
            }
            ;
            function computeTaxAmounts(taxArray, totalWithoutCharges, itemId) {
                var taxAmounts = {
                    CGST: 0,
                    SGST: 0,
                    IGST: 0,
                    CESS: 0,
                    Total: 0
                };
                for (var j = 0; j < taxArray.length; j++) {
                    var itemTax = taxArray[j];
                    if (!itemTax.item_id || itemTax.item_id === itemId) {
                        taxAmounts[itemTax.name] = computepxax0dot01(itemTax.percent, totalWithoutCharges);
                    }
                    taxAmounts.Total += taxAmounts[itemTax.name];
                }
                return taxAmounts;
            }
            function getTaxAmt(taxArray) {
                let taxAmt = 0;
                for (let tax in taxArray) {
                    taxAmt += taxArray[tax];
                }
                return taxAmt;
            }
            function computePurItem(itemInfo, globalDiscountInfo) {
                globalDiscountInfo = globalDiscountInfo ? globalDiscountInfo : {};
                var info = {};
                info.quantity = parseFloat(itemInfo.quantity_purchased);
                info.itemId = itemInfo.item_id;
                info.purchasePrice = parseFloat(itemInfo.unitsInfo[itemInfo.unitId].purchasePrice);
                var itemTaxes = itemInfo.itemTaxList;
                if (!itemTaxes) {
                    itemTaxes = [];
                }
                var taxPercent = getTotalPercent(itemTaxes, itemInfo.item_id);
                var priceTaxEx = getPriceTaxEx(info.purchasePrice, itemInfo.bPPTaxInclusive, taxPercent);
                info.discount = itemInfo.discount ? itemInfo.discount : 0;
                itemInfo.discount_percent = info.discount;
                info.discountPercent = itemInfo.discount_percent ? parseFloat(itemInfo.discount_percent) : 0;
                // info.discountPercent += globalDiscountInfo && globalDiscountInfo.percent ? globalDiscountInfo.percent : 0;
                info.priceWithoutDiscount = multiply(info.quantity, priceTaxEx);
                info.discountAmt = computepxax0dot01(info.priceWithoutDiscount, info.discountPercent);
                info.subTotal = subtract(info.priceWithoutDiscount, info.discountAmt);
                info.subTotalWithoutGD = info.subTotal;
                info.taxes = computeTaxAmounts(itemTaxes, info.subTotal, itemInfo.item_id);
                itemInfo.taxes = info.taxes;
                info.tax = computepxax0dot01(taxPercent, info.subTotal);
                info.total = add(info.subTotal, info.tax);
                if (globalDiscountInfo) {
                    if (globalDiscountInfo.method == 'onTaxable') {
                        info.subTotal = info.priceWithoutDiscount * (1 - (globalDiscountInfo.percent + info.discountPercent) * 0.01);
                        info.taxes = computeTaxAmounts(itemTaxes, info.subTotal, itemInfo.item_id);
                        info.tax = computepxax0dot01(taxPercent, info.subTotal);
                        info.total = add(info.subTotal, info.tax);
                        // computeTaxAmountsByPercentFilter(info, itemTaxes, info.subTotal, calculations);
                    }
                    else if (globalDiscountInfo.method == 'onTotal') {
                        info.total = info.total * (1 - (globalDiscountInfo.percent) * 0.01);
                        info.subTotal = info.total / ((1 + taxPercent * 0.01));
                        info.taxes = computeTaxAmounts(itemTaxes, info.subTotal, itemInfo.item_id);
                        info.tax = computepxax0dot01(taxPercent, info.subTotal);
                        // computeTaxAmountsByPercentFilter(info, itemTaxes, info.subTotal, calculations);
                    }
                }
                itemInfo.subTotal = info.subTotal;
                itemInfo.quantity = info.quantity;
                itemInfo.total = info.total;
                info.totalTaxPercent = taxPercent;
                return info;
            }
            ;
            function getPaymentsTotal(payments) {
                var total = 0;
                for (var i = 0; i < payments.length; i++) {
                    total += payments[i].payment_amount;
                }
                return total;
            }
            function processPuchaseDocs(allPurchaseDocs) {
                return __awaiter(this, void 0, void 0, function* () {
                    let docsToPush = [];
                    for (var j = 0; j < allPurchaseDocs.length; j++) {
                        //computeItem
                        if (typeof allPurchaseDocs[j].doc.receivings_info === 'string') {
                            continue;
                        }
                        if (allPurchaseDocs[j].doc.receivings_info.type === 3) {
                            continue;
                        }
                        let subtotal = 0;
                        let quantity = 0;
                        var taxes = {};
                        for (var q = 0; q < allPurchaseDocs[j].doc.receiving_items.length; q++) {
                            let itemCalculations = computePurItem(allPurchaseDocs[j].doc.receiving_items[q], allPurchaseDocs[j].doc.receivings_info.discount);
                            subtotal += itemCalculations.subTotal;
                            quantity += itemCalculations.quantity;
                            for (var t in itemCalculations.taxes) {
                                var taxAmt = itemCalculations.taxes[t];
                                if (!taxes[t]) {
                                    taxes[t] = taxAmt;
                                }
                                else {
                                    taxes[t] += taxAmt;
                                }
                            }
                            allPurchaseDocs[j].doc.receiving_items[q].subTotal = itemCalculations.subTotal;
                            allPurchaseDocs[j].doc.receiving_items[q].total = itemCalculations.total;
                        }
                        allPurchaseDocs[j].doc.receivings_info.taxDetailed = {};
                        allPurchaseDocs[j].doc.receivings_info.taxNames = {};
                        allPurchaseDocs[j].doc.receivings_info.hsnTaxes = {};
                        getTaxesByPercentageDetailed(allPurchaseDocs[j].doc.receiving_items, allPurchaseDocs[j].doc.receivings_info.taxDetailed, allPurchaseDocs[j].doc.receivings_info.taxNames, allPurchaseDocs[j].doc.receivings_info.hsnTaxes);
                        allPurchaseDocs[j].doc.receivings_info.subtotal = subtotal;
                        allPurchaseDocs[j].doc.receivings_info.quantity = quantity;
                        allPurchaseDocs[j].doc.receivings_info.taxes = taxes;
                        var paymentTotal = getPaymentsTotal(allPurchaseDocs[j].doc.payments);
                        var changeDue = subtract(paymentTotal, allPurchaseDocs[j].doc.receivings_info.total);
                        for (var p = 0; p < allPurchaseDocs[j].doc.payments.length; p++) {
                            if (allPurchaseDocs[j].doc.payments[p].payment_type === 'Cash') {
                                allPurchaseDocs[j].doc.payments[p].returnAmt = changeDue;
                            }
                        }
                        if (allPurchaseDocs[j].doc.receivings_info.supplier_id) {
                            var supInfo = yield couchDBUtils.getDoc('supplier_' + allPurchaseDocs[j].doc.receivings_info.supplier_id, maindb);
                            var checkCompanyName = supInfo.company_name ? supInfo.company_name : '';
                            var checkLastName = supInfo.last_name ? supInfo.last_name : '';
                            allPurchaseDocs[j].doc.receivings_info.supplier = checkCompanyName + ' ' + supInfo.first_name + ' ' + checkLastName;
                        }
                        if (allPurchaseDocs[j].doc.receivings_info.employee_id) {
                            var empInfo = yield couchDBUtils.getDoc('org.couchdb.user:' + allPurchaseDocs[j].doc.receivings_info.employee_id, usersdb);
                            allPurchaseDocs[j].doc.receivings_info.employee = empInfo.first_name ? empInfo.first_name + ' ' + empInfo.last_name : allPurchaseDocs[j].doc.receivings_info.employee_id;
                        }
                        allPurchaseDocs[j].doc = yield encodeTransDoc(allPurchaseDocs[j].doc, 'purchase', maindb, usersdb, couchDBUtils);
                        docsToPush.push(allPurchaseDocs[j].doc);
                    }
                    yield couchDBUtils.bulkInsert(maindb, docsToPush);
                });
            }
            /**sales Multiple units */
            // let allPurchaseDocs = await couchDBUtils.getAllDocsByType('receiving', maindb);
            yield batchProcess(1000, 'receiving', processPuchaseDocs, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            //sales return 
            // let allPurchaseRetunDocs = await couchDBUtils.getAllDocsByType('receivingReturn', maindb);
            yield batchProcess(1000, 'receivingReturn', processPuchaseReturnDocs, {
                dbInstance: maindb,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
            function processPuchaseReturnDocs(allPurchaseRetunDocs) {
                return __awaiter(this, void 0, void 0, function* () {
                    let docsToPush = [];
                    for (var k = 0; k < allPurchaseRetunDocs.length; k++) {
                        //computePurItem
                        if (typeof allPurchaseRetunDocs[k].doc.info === 'string') {
                            continue;
                        }
                        if (allPurchaseRetunDocs[k].doc.info.type === 3) {
                            continue;
                        }
                        let subtotal = 0;
                        let cost = 0;
                        let profit = 0;
                        let quantity = 0;
                        var taxes = {};
                        for (var l = 0; l < allPurchaseRetunDocs[k].doc.items.length; l++) {
                            let calculations = computePurItem(allPurchaseRetunDocs[k].doc.items[l], undefined);
                            subtotal += calculations.subTotal;
                            quantity += calculations.quantity;
                            for (var t in calculations.taxes) {
                                var taxAmt = calculations.taxes[t];
                                if (!taxes[t]) {
                                    taxes[t] = taxAmt;
                                }
                                else {
                                    taxes[t] += taxAmt;
                                }
                            }
                            allPurchaseRetunDocs[k].doc.items[l].subTotal = calculations.subTotal;
                            allPurchaseRetunDocs[k].doc.items[l].total = calculations.total;
                        }
                        allPurchaseRetunDocs[k].doc.info.taxDetailed = {};
                        allPurchaseRetunDocs[k].doc.info.taxNames = {};
                        allPurchaseRetunDocs[k].doc.info.hsnTaxes = {};
                        getTaxesByPercentageDetailed(allPurchaseRetunDocs[k].doc.items, allPurchaseRetunDocs[k].doc.info.taxDetailed, allPurchaseRetunDocs[k].doc.info.taxNames, allPurchaseRetunDocs[k].doc.info.hsnTaxes);
                        allPurchaseRetunDocs[k].doc.info.subtotal = subtotal;
                        allPurchaseRetunDocs[k].doc.info.quantity = quantity;
                        allPurchaseRetunDocs[k].doc.info.taxes = taxes;
                        // allPurchaseRetunDocs[k].doc.info.taxes.Total = commonLib.getTaxAmt(allPurchaseRetunDocs[k].doc.info.taxes);
                        var totalPaid = getPaymentsTotal(allPurchaseRetunDocs[k].doc.payments);
                        var changeAmt = subtract(totalPaid, allPurchaseRetunDocs[k].doc.info.total);
                        for (var p = 0; p < allPurchaseRetunDocs[k].doc.payments.length; p++) {
                            if (allPurchaseRetunDocs[k].doc.payments[p].payment_type === 'Cash') {
                                allPurchaseRetunDocs[k].doc.payments[p].returnAmt = changeAmt;
                            }
                        }
                        if (allPurchaseRetunDocs[k].doc.info.supplier_id) {
                            var supInfo = yield couchDBUtils.getDoc('supplier_' + allPurchaseRetunDocs[k].doc.info.supplier_id, maindb);
                            var checkCompanyName = supInfo.company_name ? supInfo.company_name : '';
                            var checkLastName = supInfo.last_name ? supInfo.last_name : '';
                            allPurchaseRetunDocs[k].doc.info.supplier = checkCompanyName + ' ' + supInfo.first_name + ' ' + checkLastName;
                        }
                        if (allPurchaseRetunDocs[k].doc.info.employee_id) {
                            var empInfo = yield couchDBUtils.getDoc('org.couchdb.user:' + allPurchaseRetunDocs[k].doc.info.employee_id, usersdb);
                            allPurchaseRetunDocs[k].doc.info.employee = empInfo.first_name ? empInfo.first_name + ' ' + empInfo.last_name : allPurchaseRetunDocs[k].doc.info.employee_id;
                        }
                        allPurchaseRetunDocs[k].doc = yield encodeTransDoc(allPurchaseRetunDocs[k].doc, 'purchaseReturn', maindb, usersdb, couchDBUtils);
                        docsToPush.push(allPurchaseRetunDocs[k].doc);
                    }
                    yield couchDBUtils.bulkInsert(maindb, docsToPush);
                });
            }
        }
        catch (err) {
            logger.error(err);
            throw migrationName + ' up migration failed';
        }
    });
};
exports.down = function (params) {
    return __awaiter(this, void 0, void 0, function* () {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        try {
            //as if now down migration is not required
            //todo write code if down is rquired
            function transformSaleDoc(resp) {
                var doc = resp[j].doc ? resp[j].doc : JSON.parse(resp[j].value);
                var id = JSON.parse(doc[0]);
                var jsonValue = {
                    payments: doc[3]
                };
                var type = 'purchase';
                if (id.receiving_id) {
                    jsonValue.receiving_id = id.receiving_id;
                    jsonValue.receiving_items = JSON.parse(doc[2]);
                    jsonValue.receivings_info = doc[1];
                }
                else {
                    jsonValue.id = id.id;
                    jsonValue.items = JSON.parse(doc[2]);
                    jsonValue.info = doc[1];
                    type = 'purchaseReturn';
                }
                if (doc[4]) {
                    jsonValue.bReturned = true;
                }
                else {
                    jsonValue.bReturned = false;
                }
                if (doc[5]) {
                    jsonValue.bRejected = true;
                }
                else {
                    jsonValue.bRejected = false;
                }
                doc = jsonValue;
                doc = transformSaleOrPurchaseDoc(doc, type);
                return doc;
            }
            let docsToPush = [];
            let allPurchaseDocs = yield couchDBUtils.getAllDocsByType('receiving', maindb);
            for (var j = 0; j < allPurchaseDocs.length; j++) {
                var doc = transformSaleDoc(allPurchaseDocs[j].doc);
                docsToPush.push(doc);
            }
            yield couchDBUtils.bulkInsert(maindb, docsToPush);
            docsToPush = [];
            let allPurchaseRetunDocs = yield couchDBUtils.getAllDocsByType('receivingReturn', maindb);
            for (var k = 0; k < allPurchaseRetunDocs.length; k++) {
                var retDoc = transformSaleDoc(allPurchaseRetunDocs[k].doc);
                docsToPush.push(retDoc);
            }
            yield couchDBUtils.bulkInsert(maindb, docsToPush);
        }
        catch (err) {
            logger.error(err);
            throw migrationName + ' down migration failed';
        }
    });
};
function encodeTransDoc(doc, type, maindb, usersdb, couchDBUtils) {
    return __awaiter(this, void 0, void 0, function* () {
        var infoKey = 'sales_info';
        var itemsKey = 'sale_items';
        /**
         * whene you change the fields array or encodeTransDoc or transformSalesDoc change in the following places as well
         * 1.commolib (currentfile)
         * 2. maindbViews (2 places ) : update_customer view and delta_pending_amount
         * 3. computeUtils in profitGuruCore/Services/Reports/
         */
        let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts', 'discount', 't_no'];
        let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
        if (type === 'saleReturn') {
            infoKey = 'info';
            itemsKey = 'items';
            infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts', 'discount', 't_no'];
        }
        else if (type === 'purchaseReturn') {
            infoKey = 'info';
            itemsKey = 'items';
            infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
            itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
        }
        else if (type === 'purchase') {
            infoKey = 'receivings_info';
            itemsKey = 'receiving_items';
            infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
            itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
        }
        if (doc[infoKey].customer_id) {
            var customerInfo = yield couchDBUtils.getDoc('customer_' + doc[infoKey].customer_id, maindb);
            var checkCompanyName = customerInfo.company_name ? customerInfo.company_name : '';
            var checkLastName = customerInfo.last_name ? customerInfo.last_name : '';
            doc[infoKey].customer = checkCompanyName + ' ' + customerInfo.first_name + ' ' + checkLastName;
        }
        if (doc[infoKey].employee_id) {
            var empInfo = yield couchDBUtils.getDoc('org.couchdb.user:' + doc[infoKey].employee_id, usersdb);
            doc[infoKey].employee = empInfo.first_name ? empInfo.first_name + ' ' + empInfo.last_name : doc[infoKey].employee_id;
        }
        if (doc[infoKey].supplier_id) {
            var supInfo = yield couchDBUtils.getDoc('supplier_' + doc[infoKey].supplier_id, maindb);
            var checkCompanyName = supInfo.company_name ? supInfo.company_name : '';
            var checkLastName = supInfo.last_name ? supInfo.last_name : '';
            doc[infoKey].supplier = checkCompanyName + ' ' + supInfo.first_name + ' ' + checkLastName;
        }
        let info = doc[infoKey];
        if (type === 'saleReturn') {
            info.num = doc.id;
        }
        let items = doc[itemsKey];
        let transInfo = doc._id + ';';
        for (let i = 0; i < infoFields.length; i++) {
            let val = getValString(info[infoFields[i]]);
            transInfo += val + ';';
        }
        let itemsList = [];
        for (var j = 0; j < items.length; j++) {
            if (!items[j].category) {
                let itemInfo = yield couchDBUtils.getDoc('item_' + items[j].item_id, maindb);
                let categoryInfo = yield couchDBUtils.getDoc('category_' + itemInfo.info.categoryId, maindb);
                items[j].category = categoryInfo.name;
            }
            let itemString = "";
            for (let k = 0; k < itemFields.length; k++) {
                let fieldVal = getValString(items[j][itemFields[k]]);
                itemString += fieldVal + ';';
            }
            itemsList.push(itemString);
        }
        let payments = JSON.stringify(doc.payments);
        doc.payments = payments;
        doc[infoKey] = transInfo;
        doc[itemsKey] = itemsList;
        return doc;
    });
}
function transformSaleOrPurchaseDoc(doc, type) {
    var infoKey = 'sales_info';
    var itemsKey = 'sale_items';
    var idKey = 'sale_id';
    let infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'sale_time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'loyaltyEarned', 'rmPnts', 'discount', 't_no'];
    let itemFields = ['name', 'category', 'hsn', 'item_id', 'uniqueItemCode', 'ItemType', 'stockKey', 'batchId', 'skuName', 'unit', 'unitId', 'baseUnitId', 'unitsInfo', 'line', 'quantity_purchased', 'discount_percent', 'gDiscountPercent', 'purchasePrice', 'sellingPrice', 'mrp', 'item_location', 'bSPTaxInclusive', 'bPPTaxInclusive', 'taxes', 'itemTaxList', 'slab', 'expiry', 'stock_name', 'chargesList', 'chargesTaxList', 'warranty', 'warrantyTerms', 'total', 'subTotal', 'cost', 'profit', 'imeiNumbers', 'serialnumber'];
    if (type === 'saleReturn') {
        idKey = 'id';
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['num', 'invoicePrefix', 'invoiceCheckpoint', 'time', 'refBookingId', 'checkNo', 'wcInfo', 'customer_id', 'employee_id', 'customer', 'employee', 'comment', 'vehicle_phNo', 'vehicleNo', 'total', 'subtotal', 'taxes', 'taxDetailed', 'cost', 'profit', 'quantity', 'deliveryCharge', 'deliveryBoy', 'bHomeDelivery', 'pending_amount', 'type', 'state_name', 'GSTIN', 'round_off_method', 'shippingDetails', 'globalDiscountInfo', 'tableNo', 'pProfileId', 'order_no', 'parentId', 'rmPnts', 'discount', 't_no'];
    }
    else if (type === 'purchaseReturn') {
        idKey = 'id';
        infoKey = 'info';
        itemsKey = 'items';
        infoFields = ['time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState', 'parentId'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    }
    else if (type === 'purchase') {
        idKey = 'receiving_id';
        infoKey = 'receivings_info';
        itemsKey = 'receiving_items';
        infoFields = ['receiving_time', 'checkNo', 'supplier_id', 'employee_id', 'supplier', 'employee', 'comment', 'invoice_number', 'payment_type', 'pending_amount', 'total', 'subtotal', 'taxes', 'taxDetailed', 'quantity', 'receiving_id', 'type', 'round_off_method', 'amount_tendered', 'GSTIN', 'state_name', 'discount', 'interState'];
        itemFields = ['name', 'hsn', 'item_id', 'batchId', 'stockKey', 'skuName', 'line', 'description', 'quantity_purchased', 'taxes', 'total', 'subTotal', 'expiry', 'unitId', 'baseUnitId', 'unitsInfo', 'bPPTaxInclusive', 'item_location', 'itemTaxList', 'slab', 'unit', 'hasExpiryDate', 'is_serialized', 'hasBatchNumber', 'imeiCount', 'hasVariants', 'discount', 'uniqueDetails'];
    }
    var items = doc[itemsKey];
    var info = doc[infoKey];
    var itemsArray = [];
    for (var q = 0; q < items.length; q++) {
        var itemVals = items[q].split(';');
        var itemInfo = {};
        for (var iF = 0; iF < itemFields.length; iF++) {
            var val = converValue(itemVals[iF], itemFields[iF]);
            itemInfo[itemFields[iF]] = val;
        }
        itemsArray.push(itemInfo);
    }
    items = itemsArray;
    var salesInfoVals = info.split(';');
    var salesInfo = {};
    salesInfo._id = salesInfoVals[0];
    for (var s = 0; s < infoFields.length; s++) {
        var infoVal = converValue(salesInfoVals[s + 1], infoFields[s]);
        salesInfo[infoFields[s]] = infoVal;
    }
    info = salesInfo;
    info[idKey] = doc[idKey];
    doc[infoKey] = info;
    doc[itemsKey] = items;
    doc.payments = JSON.parse(doc.payments);
    return doc;
}
var commonFields = ['discount'];
var intFields = ['item_id', 'line', 'imeiCount', 'categoryId', 'num', 'invoiceCheckpoint', 'sale_time', 'receiving_time', 'time', 'supplier_id', 'customer_id', 'tableNo', 'pProfileId', 'parentId'];
var floatFields = ['price', 'baseUnitPrice', 'sellingPriceExcludingTax', 'totalTaxPercent', 'totalPurchaseTaxPercent', 'purchasePrice', 'mrp', 'reorder_level', 'total', 'subTotal', 'subtotal', 'cost', 'profit', 'quantity', 'deliveryCharge', 'pending_amount', 'discount', 'discount_percent', 'quantity_purchased', 'sellingPrice', 'gDiscountPercent', 'loyaltyEarned', 'rmPnts'];
var objFields = ['wcInfo', 'slab', 'taxes', 'taxDetailed', 'shippingDetails', 'globalDiscountInfo', 'imeiNumbers', 'unitDocs', 'chargesList', 'chargesTaxList', 'unitsInfo', 'itemTaxList', 'uniqueDetails'];
var boolFields = ['isNew', 'interState', 'is_serialized', 'hasBatchNumber', 'bOTG', 'hasExpiryDate', 'bSPTaxInclusive', 'bPPTaxInclusive', 'isWarranty'];
function converValue(val, key) {
    // var val = itemVals[iF];
    if (commonFields.indexOf(key) !== -1 && bStringifiedJSON(val)) {
        val = JSON.parse(val);
    }
    else if (intFields.indexOf(key) !== -1) {
        val = val ? parseInt(val) : 0;
    }
    else if (floatFields.indexOf(key) !== -1) {
        val = val ? parseFloat(val) : 0;
    }
    else if (objFields.indexOf(key) !== -1) {
        val = val ? JSON.parse(val) : (key === 'wcInfo' ? undefined : {});
    }
    else if (boolFields.indexOf(key) !== -1) {
        if (val && (val.toLowerCase() === 'yes' || val.toLowerCase() === 'true')) {
            val = true;
        }
        else {
            val = false;
        }
    }
    return val;
}
function bStringifiedJSON(value) {
    if (!value) {
        return false;
    }
    if (value.indexOf('{') > -1 &&
        value.indexOf('}') > -1 &&
        value.indexOf('":"') > -1 &&
        Object.keys(JSON.parse(value)).length) {
        return true;
    }
    return false;
}
function getValString(val) {
    if (val === undefined || val === null) {
        val = "";
    }
    else if (typeof val === "object") {
        val = JSON.stringify(val);
    }
    if (typeof val === 'string' && val.indexOf(';') > -1) {
        val = val.replace(';', '');
    }
    return val;
}
//# sourceMappingURL=201807020000000-transformPurchaseDocs.js.map