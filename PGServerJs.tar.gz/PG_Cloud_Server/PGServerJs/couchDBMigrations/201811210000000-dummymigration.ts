/**
 */

'use strict';

import * as path from 'path';

export const up = async () => {
    return
};

export const down = async () => {
    //nothing required
    return;
};