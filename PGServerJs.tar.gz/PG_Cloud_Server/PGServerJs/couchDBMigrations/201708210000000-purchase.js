/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

async function batchProcess(batchSize, docType, processFun, params) {
    let skip = 0;
    let itemDocsObj = {};
    while (true) {
        params.logger.info('Current Count <' + skip + ' >');
        let allDocs = await params.couchDBUtils.getAllDocsByType(docType, params.dbInstance, {
            limit: batchSize,
            skip: skip
        });
        skip += allDocs.length;

        await processFun(allDocs, params);

        if (allDocs.length !== batchSize) {
            params.logger.info('Total Process Count<' + skip + '>');
            break;
        }
    }
}

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const configState = require(appRootPath + 'common/configState');
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;

        let mainDBInstance = params.nanoClients.maindb;
        try {
            await batchProcess(10, 'receiving', processReceivings, {
                itemDocsObj: {},
                dbInstance: mainDBInstance,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
        } catch (error) {
            logger.error(error);
            throw migrationName + 'up migration failed';
        }

        let config = await configState.getAppConfig();
        let dbUrl = couchDBUtils2.getCouchUrl(config.localCouch);
        let statecodesDBName = couchDBUtils2.getDBName('pg_collection', process.env.APP_TYPE, 'statecodesdb', false);
        let uqcDBName = couchDBUtils2.getDBName('pg_collection', process.env.APP_TYPE, 'uqcdb', false);

        try {
            await couchDBUtils2.deleteDb(dbUrl, statecodesDBName);
            await couchDBUtils2.deleteDb(dbUrl, uqcDBName);
        } catch (error) {
            logger.error(error);
            logger.error('Benefit of doubt, db would not have been created');
        }

        async function processReceivings(allReceivingDocs, params) {
            let itemDocsObj = params.itemDocsObj;
            let itemDocIds = [];
            for (let i = 0; i < allReceivingDocs.length; i++) {
                if (!allReceivingDocs[i].doc.receiving_items) {
                    continue;
                }
                for (let j = 0; j < allReceivingDocs[i].doc.receiving_items.length; j++) {
                    let item_id = allReceivingDocs[i].doc.receiving_items[j].item_id;
                    if (!itemDocsObj.hasOwnProperty(item_id.toString())) {
                        itemDocIds.push('item_' + item_id);
                    }
                }
            }

            if (itemDocIds.length) {
                let itemDocs = await couchDBUtils.getAllDocs(itemDocIds, mainDBInstance);
                for (let i = 0; i < itemDocs.length; i++) {
                    if (itemDocs[i].error) {
                        throw itemDocs[i].error;
                    }

                    itemDocsObj[itemDocs[i].doc.item_id] = itemDocs[i].doc;
                }
            }

            let docs2Update = [];
            for (let i = 0; i < allReceivingDocs.length; i++) {
                if (!allReceivingDocs[i].doc.receiving_items) {
                    continue;
                }
                for (let j = 0; j < allReceivingDocs[i].doc.receiving_items.length; j++) {
                    let item_id = allReceivingDocs[i].doc.receiving_items[j].item_id.toString();
                    allReceivingDocs[i].doc.receiving_items[j].name = itemDocsObj[item_id].info.name;
                    allReceivingDocs[i].doc.receiving_items[j].hsn = itemDocsObj[item_id].info.hsn;
                }
                docs2Update.push(allReceivingDocs[i].doc);
            }

            if (docs2Update) {
                await couchDBUtils.bulkInsert(mainDBInstance, docs2Update);
            }
        }

    },

    down: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;

        let mainDBInstance = params.nanoClients.maindb;
        try {
            await batchProcess(10, 'receiving', processReceivings, {
                itemDocsObj: {},
                dbInstance: mainDBInstance,
                couchDBUtils: couchDBUtils,
                logger: logger
            });
        } catch (error) {
            logger.error(error);
            throw migrationName + 'down migration failed';
        }

        async function processReceivings(allReceivingDocs, params) {

            let docs2Update = [];
            for (let i = 0; i < allReceivingDocs.length; i++) {
                if (!allReceivingDocs[i].doc.receiving_items) {
                    continue;
                }
                for (let j = 0; j < allReceivingDocs[i].doc.receiving_items.length; j++) {
                    delete allReceivingDocs[i].doc.receiving_items[j].name;
                    delete allReceivingDocs[i].doc.receiving_items[j].hsn;
                }
                docs2Update.push(allReceivingDocs[i].doc);
            }

            if (docs2Update) {
                await couchDBUtils.bulkInsert(mainDBInstance, docs2Update);
            }
        }
    }
};