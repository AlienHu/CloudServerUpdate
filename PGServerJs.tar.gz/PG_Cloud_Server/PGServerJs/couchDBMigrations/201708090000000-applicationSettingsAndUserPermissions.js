/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;
        try {

            var params = {};
            await couchDBUtils2.createCouchDbAndViews(nanoUsers, '_users');
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            var docsToUpdate = [];
            for (var i = 0; i < allUsers.length; i++) {
                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                if (allUsers[i].value.roles[1] === 'admin') {

                    allUsers[i].value.roles[0].reports.gstreports = {
                        "apis": ["gstr1_12"],
                        "allowed": true,
                        "desc": "Allows to view the GST Reports"

                    };
                    allUsers[i].value.roles[0].payments.sendSms = {
                        "apis": ["/common/sendSMS"],
                        "common": true,
                        "allowed": true,
                        "desc": "Allows to Send the Order SMS to the Supplier"
                    };
                    allUsers[i].value.roles[0].payments.sendEmail = {
                        "apis": ["/common/sendEmailApi"],
                        "common": true,
                        "allowed": true,
                        "desc": "Allows to Send the Order Email to the Supplier"
                    };
                } else {
                    allUsers[i].value.roles[0].reports.gstreports = {
                        "apis": ["gstr1_12"],
                        "allowed": false,
                        "desc": "Allows to view the GST Reports"

                    };
                    allUsers[i].value.roles[0].payments.sendSms = {
                        "apis": ["/common/sendSMS"],
                        "common": true,
                        "allowed": false,
                        "desc": "Allows to Send the Order SMS to the Supplier"
                    };
                    allUsers[i].value.roles[0].payments.sendEmail = {
                        "apis": ["/common/sendEmailApi"],
                        "common": true,
                        "allowed": false,
                        "desc": "Allows to Send the Order Email to the Supplier"
                    };

                }
                if (allUsers[i].value.roles[0].customers.sendSms.hasOwnProperty('apis'))
                    allUsers[i].value.roles[0].customers.sendSms.apis.push("/common/sendSMS");
                else
                    allUsers[i].value.roles[0].customers.sendSms.apis = ["/common/sendSMS"];
                allUsers[i].value.roles[0].customers.sendSms.common = true;

                if (allUsers[i].value.roles[0].employees.sendSms.hasOwnProperty('apis'))
                    allUsers[i].value.roles[0].employees.sendSms.apis.push("/common/sendSMS");
                else
                    allUsers[i].value.roles[0].employees.sendSms.apis = ["/common/sendSMS"];
                allUsers[i].value.roles[0].employees.sendSms.common = true;

                if (allUsers[i].value.roles[0].suppliers.sendSms.hasOwnProperty('apis'))
                    allUsers[i].value.roles[0].suppliers.sendSms.apis.push("/common/sendSMS");
                else
                    allUsers[i].value.roles[0].suppliers.sendSms.apis = ["/common/sendSMS"];
                allUsers[i].value.roles[0].suppliers.sendSms.common = true;
                if (allUsers[i].value.roles[0].inProgress) {
                    if (allUsers[i].value.roles[0].inProgress.placeorderToSuppliers.sendSms.hasOwnProperty('apis'))
                        allUsers[i].value.roles[0].inProgress.placeorderToSuppliers.sendSms.apis.push("/common/sendSMS");
                    else
                        allUsers[i].value.roles[0].inProgress.placeorderToSuppliers.sendSms.apis = ["/common/sendSMS"];
                    allUsers[i].value.roles[0].inProgress.placeorderToSuppliers.sendSms.common = true;
                }
                // console.log(allUsers[i].value.roles[0].reports.gstreports);

                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);

                // console.log(allUsers[i].value.roles[0].reports.gstreports);

                docsToUpdate.push(allUsers[i].value);
            }
            await couchDBUtils.bulkInsert(nanoUsers, docsToUpdate);

            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            applicationSettings.taxProfile = {
                id: ''
            };
            applicationSettings.enableSMS.afterSale = false;
            applicationSettings.enableSMS.afterPurchase = false;
            applicationSettings.enableSMS.toOwner = false;
            applicationSettings.enableSMS.toCustomer = false;
            applicationSettings.enableSMS.counter = 0;
            applicationSettings.enableSMS.quota = 0;
            // docsToUpdate.push(applicationSettings);
            var appSettingsDoc = [applicationSettings];
            await couchDBUtils.bulkInsert(nanoCore, appSettingsDoc);

        } catch (error) {
            logger.error(error);
            throw migrationName + 'up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let nanoCore = nanoClients.coredb;
        let nanoUsers = nanoClients._users;

        try {

            var params = {};
            let docsToUpdate = [];
            let allUsers = await couchDBUtils.getView('employees', 'all', params, nanoUsers);
            for (var i = 0; i < allUsers.length; i++) {
                allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
                let apiIndex;
                if (allUsers[i].value.roles[0].customers.sendSms.hasOwnProperty('common')) {
                    delete allUsers[i].value.roles[0].customers.sendSms.common;
                    delete allUsers[i].value.roles[0].customers.sendSms.apis;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('sendSMS.common property not found');
                }
                if (allUsers[i].value.roles[0].employees.sendSms.hasOwnProperty('common')) {
                    delete allUsers[i].value.roles[0].employees.sendSms.common;
                    delete allUsers[i].value.roles[0].employees.sendSms.apis;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('employee.sendSMS.common property not found');
                }
                if (allUsers[i].value.roles[0].suppliers.sendSms.hasOwnProperty('common')) {
                    delete allUsers[i].value.roles[0].suppliers.sendSms.common;
                    delete allUsers[i].value.roles[0].suppliers.sendSms.apis;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('suppliers.sendSMS.common property not found');
                }
                if (allUsers[i].value.roles[0].inProgress && allUsers[i].value.roles[0].inProgress.placeorderToSuppliers.sendSms.hasOwnProperty('common')) {
                    delete allUsers[i].value.roles[0].inProgress.placeorderToSuppliers.sendSms.common;
                    delete allUsers[i].value.roles[0].inProgress.placeorderToSuppliers.sendSms.apis;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('placeorderToSuppliers.sendSMS.common property not found');
                }
                if (allUsers[i].value.roles[0].reports.hasOwnProperty('gstreports')) {
                    delete allUsers[i].value.roles[0].reports.gstreports;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('gstreports property not found');
                }
                if (allUsers[i].value.roles[0].payments.hasOwnProperty('sendSms')) {
                    delete allUsers[i].value.roles[0].payments.sendSms;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('sendSms property not found');
                }
                if (allUsers[i].value.roles[0].payments.hasOwnProperty('sendEmail')) {
                    delete allUsers[i].value.roles[0].payments.sendEmail;
                } else {
                    logger.error('Not expected to come here');
                    logger.error('sendEmail property not found');
                }

                allUsers[i].value.roles[0] = JSON.stringify(allUsers[i].value.roles[0]);
                docsToUpdate.push(allUsers[i].value);

            }
            await couchDBUtils.bulkInsert(nanoUsers, docsToUpdate);
            let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', nanoCore);
            if (applicationSettings.hasOwnProperty('taxProfile')) {
                delete applicationSettings.taxProfile;
            } else {
                logger.error('Not expected to come here');
                logger.error('ftaxprofile property not found');
            }
            if (applicationSettings.enableSMS.hasOwnProperty('afterSale')) {
                delete applicationSettings.enableSMS.afterSale;
            } else {
                logger.error('Not expected to come here');
                logger.error('afterSale property not found');
            }
            if (applicationSettings.enableSMS.hasOwnProperty('afterPurchase')) {
                delete applicationSettings.enableSMS.afterPurchase;
            } else {
                logger.error('Not expected to come here');
                logger.error('afterPurchase property not found');
            }
            if (applicationSettings.enableSMS.hasOwnProperty('toOwner')) {
                delete applicationSettings.enableSMS.toOwner;
            } else {
                logger.error('Not expected to come here');
                logger.error('toOwner property not found');
            }
            if (applicationSettings.enableSMS.hasOwnProperty('toCustomer')) {
                delete applicationSettings.enableSMS.toCustomer;
            } else {
                logger.error('Not expected to come here');
                logger.error('toCustomer property not found');
            }
            if (applicationSettings.enableSMS.hasOwnProperty('counter')) {
                delete applicationSettings.enableSMS.counter;
            } else {
                logger.error('Not expected to come here');
                logger.error('counter property not found');
            }
            if (applicationSettings.enableSMS.hasOwnProperty('quota')) {
                delete applicationSettings.enableSMS.counter;
            } else {
                logger.error('Not expected to come here');
                logger.error('quota property not found');
            }
            // docsToUpdate.push(applicationSettings);
            var appSettingsDoc = [applicationSettings];
            await couchDBUtils.bulkInsert(nanoCore, appSettingsDoc);
        } catch (error) {
            logger.error(error);
            logger.error('application settings update failed');
            throw error;
        }
    }
};