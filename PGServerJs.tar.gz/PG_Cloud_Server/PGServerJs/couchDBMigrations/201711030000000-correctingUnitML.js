/**
 */

'use strict';

var fs = require('fs');
var path = require('path');

module.exports = {
    up: async function(params) {
        let logger = params.logger;
        let migrationsBasePath = params.migrationsBasePath;

        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        const httpUtils = require('../common/httpUtils');

        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;
        let databasePath = JSON.stringify(true);
        try {
            let url = 'http://' + process.env.COUCHDB_USERNAME + ':' + process.env.COUCHDB_PASSWORD + '@127.0.0.1:' + process.env.COUCH_PORT + '/_config/couchdb/delayed_commits';
            await httpUtils.httpPut(url, databasePath);
        } catch (error) {
            console.log(error);
            throw 'updateDatabaseDir failed';
        }
        try {
            var params = {};
            let allUnits = await couchDBUtils.getAllDocsByType('unit', maindb);
            for (var i = 0; i < allUnits.length; i++) {

                if (allUnits[i].doc.name === 'ml') {
                    allUnits[i].doc.shortName = 'ml';
                }
                await couchDBUtils.update(allUnits[i].doc, maindb, 3, "Error updating unit doc");
            }

            let allItems = await couchDBUtils.getAllDocsByType('item', maindb);
            let docsToUpdate = [];
            for (var i = 0; i < allItems.length; i++) {

                if (allItems[i].doc.info.hasVariants === false) {
                    allItems[i].doc.info.attributes = [];
                    docsToUpdate.push(allItems[i].doc);
                }

            }
            await couchDBUtils.bulkInsert(maindb, docsToUpdate);

        } catch (error) {
            logger.error(error);
            throw migrationName + ' up migration failed';
        }
    },

    down: async function(params) {
        let logger = params.logger;
        let migrationName = path.basename(__filename, '.js');
        params.migrationName = migrationName;
        let migrationsBasePath = params.migrationsBasePath;
        const appRootPath = migrationsBasePath + '/../';
        const couchDBUtils = require(appRootPath + 'controllers/common/CouchDBUtils');
        const couchDBUtils2 = require('../couchDb/couchDBUtils2');
        let nanoClients = params.nanoClients;
        let maindb = nanoClients.maindb;

        try {

            var params = {};
            let allUnits = await couchDBUtils.getAllDocsByType('unit', maindb);
            for (var i = 0; i < allUnits.length; i++) {

                if (allUnits[i].doc.name === 'ml') {
                    allUnits[i].doc.shortName = 'mgs';
                }
                await couchDBUtils.update(allUnits[i].doc, maindb, 3, "Error updating unit doc");
            }

        } catch (error) {
            logger.error(error);
            logger.error(migrationName + ' down migration failed');
            throw error;
        }
    }
};