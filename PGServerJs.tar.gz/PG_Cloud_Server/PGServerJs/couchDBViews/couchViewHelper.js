'use strict';

const logger = require('../common/Logger');

var couchView = function() {
    function getDesignDocStr(item, rev) {
        var ddoc = {
            _id: '_design/' + item.name,
            version: item.version,
            views: {}
        };
        if (rev) {
            ddoc._rev = rev;
        }
        ddoc.views[item.name] = {
            map: item.function.toString()
        };

        if (item.filters) {
            ddoc.filters = {};
            for (var i = 0; i < item.filters.length; i++) {
                ddoc.filters[item.filters[i].name] = item.filters[i].function;
            }
        }

        if (item.sort) {
            ddoc.lists = {
                sort: item.sort
            };
        }
        return ddoc;
    }

    function getDesignDocStr2(item, rev) {
        var ddoc = {
            _id: '_design/' + item.name,
            version: item.version,
            views: {},
            filters: {}
        };
        if (rev) {
            ddoc._rev = rev;
        }

        for (var i = 0; i < item.views.length; i++) {
            ddoc.views[item.views[i].viewName] = {
                map: item.views[i].function.toString()
            };

            var reduceFunction = item.views[i].reduceFunction;
            if (reduceFunction) {
                ddoc.views[item.views[i].viewName].reduce = reduceFunction.toString();
            }
        }

        if (item.filters) {
            for (var i = 0; i < item.filters.length; i++) {
                ddoc.filters[item.filters[i].name] = item.filters[i].function;
            }
        }

        return ddoc;
    }

    function getUpdateDesignDocStr(item, rev) {
        var ddoc = {
            _id: '_design/' + item.name,
            version: item.version,
            updates: {}
        };
        if (rev) {
            ddoc._rev = rev;
        }

        for (var i = 0; i < item.updates.length; i++) {
            ddoc.updates[item.updates[i].update_name] = item.updates[i].function.toString();
        }

        return ddoc;
    }

    /*
        function generateSortFunction(sortFunction, includeCompareDate, filterFunction) {
            var generatedFunction = 'function(head, req) {' +
                'function keysEqual(keyA, keyB) {' +
                'for (var i= 0; i < keyA.length; i++) {' +
                'if (keyA[i] !== keyB[i]) {' +
                'return false;' +
                '}' +
                '}' +
                'return true;' +
                '}';
            if (includeCompareDate) {
                generatedFunction += 'function getCompareDate(dateString) {' +
                    'if (!dateString || dateString === "") {' +
                    'return 0;' +
                    '}' +
                    'return new Date(dateString).getTime();' +
                    '}';
            }
            generatedFunction += 'function compareStrings(aString, bString) {' +
                'if (!aString) {' +
                'aString = "";' +
                '}' +
                'if (!bString) {' +
                'bString = "";' +
                '}' +
                'if (aString < bString) {' +
                'return -1;' +
                '} else if (aString > bString) {' +
                'return 1;' +
                '} else {' +
                'return 0;' +
                '}' +
                '}' +
                'var row,' +
                'rows=[],' +
                'startingPosition = 0;' +
                'while(row = getRow()) {' +
                'rows.push(row);' +
                '}';
            if (filterFunction) {
                generatedFunction += 'rows = rows.filter(' + filterFunction + ');';
            }
            generatedFunction += 'rows.sort(' + sortFunction + ');' +
                'if (req.query.sortStartKey) {' +
                'var startKey = JSON.parse(req.query.sortStartKey);' +
                'for (var i=0; i<rows.length; i++) {' +
                'if (keysEqual(startKey, rows[i].key)) {' +
                'startingPosition = i;' +
                'break;' +
                '}' +
                '}' +
                '}' +
                'if (req.query.sortDesc) {' +
                'rows = rows.reverse();' +
                '}' +
                'if (req.query.sortLimit) {' +
                'rows = rows.slice(startingPosition, parseInt(req.query.sortLimit)+startingPosition);' +
                '} else if (startingPosition > 0) {' +
                'rows = rows.slice(startingPosition);' +
                '}' +
                'send(JSON.stringify({"rows" : rows}));' +
                '}';
            return generatedFunction;
        }*/

    this.generateView = function(viewDocType, viewBody) {
        return 'function(doc) {' +
            'var doctype,' +
            'uidx;' +
            'if (doc._id && (uidx = doc._id.indexOf("_")) > 0) {' +
            'doctype = doc._id.substring(0, uidx);' +
            'if(doctype === "' + viewDocType + '") {' +
            viewBody +
            '}' +
            '}' +
            '}';
    };

    function updateDesignDoc(item, db, rev) {
        logger.info('Creating design doc: ', item.name);
        return new Promise(function(resolve, reject) {
            var designDoc = {};
            if ('updates' in item) {
                designDoc = getUpdateDesignDocStr(item, rev);
            } else if ('views' in item) {
                designDoc = getDesignDocStr2(item, rev);
            } else {
                designDoc = getDesignDocStr(item, rev);
            }

            db.insert(designDoc).then(function(resp) {
                resolve(resp);
            }).catch(function(reason) {
                logger.error('ERR updateDesignDoc:', reason);
                reject(reason);
            });

        });
    }

    // function generateDateForView(date1) {
    //     return 'var ' + date1 + ' = doc.data.' + date1 + ';' +
    //         'if (' + date1 + ' && ' + date1 + ' !== "") {' +
    //         date1 + ' = new Date(' + date1 + ');' +
    //         'if (' + date1 + '.getTime) {' +
    //         date1 + ' = ' + date1 + '.getTime();' +
    //         '}' +
    //         '}';

    // }

    function createDesignDoc(item, db) {
        return new Promise(function(resolve, reject) {
            db.get('_design/' + item.name).then(function(doc) {
                doc = doc[0];
                if (doc.version !== item.version) {
                    updateDesignDoc(item, db, doc._rev).then(function(response) {
                        resolve(response);
                    }).catch(function(reason) {
                        reject(reason);
                    });
                } else {
                    logger.info('View Exists with Same Version(Skip Update)');
                    resolve();
                }

            }).catch(function(reason) {
                updateDesignDoc(item, db).then(function(response) {
                    resolve(response);
                }).catch(function(reason) {
                    reject(reason);
                });
            });
        });
    }

    async function oldCreateViews(db, designDocs, updatesDesignDocs) {

        await cleanUpDesignDocs(db, designDocs, updatesDesignDocs);

        var createViewsPromiseArray = [];
        if (designDocs && designDocs.length) {
            designDocs.forEach(function(item) {
                createViewsPromiseArray.push(createDesignDoc(item, db));
            });
        }

        if (updatesDesignDocs && updatesDesignDocs.length) {
            updatesDesignDocs.forEach(function(item) {
                createViewsPromiseArray.push(createDesignDoc(item, db));
            });
        }

        return Promise.all(createViewsPromiseArray).then(function(response) {
            return response;
        }).catch(function(reason) {
            return Promise.reject(reason);
        });
    }

    this.createViews = async function(db, designDocs, updatesDesignDocs, newDDocs) {
        if (designDocs) {
            await oldCreateViews(db, designDocs, updatesDesignDocs);
        }
        if (newDDocs) {
            for (let i = 0; i < newDDocs.length; i++) {
                await updateDesignDocument(newDDocs[i], db);
            }
        }
    };

    async function cleanUpDesignDocs(db, designDocs, updatesDesignDocs) {

        function isAlien(designDocName) {
            if (!designDocs && !updatesDesignDocs) {
                return false;
            }

            let bAlien = true;
            if (designDocs && ((designDocs.findIndex(j => '_design/' + j.name === designDocName) >= 0))) {
                bAlien = false
            }

            if (updatesDesignDocs && ((updatesDesignDocs.findIndex(j => '_design/' + j.name === designDocName) >= 0))) {
                bAlien = false;
            }
            return bAlien;
        }

        const couchDBUtils = require('../controllers/common/CouchDBUtils');
        let queryResp = (await db.fetch({}, {
            startkey: '_design',
            endkey: '_design0',
            include_docs: false
        }))[0].rows;
        let errors = [];
        for (let i = 0; i < queryResp.length; i++) {
            if (isAlien(queryResp[i].id)) {
                try {
                    await couchDBUtils.delete({
                        _id: queryResp[i].id
                    }, db, 1);
                } catch (error) {
                    errors.push(error);
                }
            }
        }

        if (errors.length) {
            throw errors;
        }
    };

    let couchDBUtils;
    async function updateDesignDocument(ddoc, db) {
        if (!couchDBUtils) {
            couchDBUtils = require('../controllers/common/CouchDBUtils');
        }
        try {
            let resp = await couchDBUtils.getDoc(ddoc._id, db);

            if (ddoc.version != resp.version) {
                //update
                ddoc._rev = resp._rev;
                return couchDBUtils.createOrUpdate(ddoc, db);

            } else {
                return resp;
            }
        } catch (error) {
            //create new document //=
            return couchDBUtils.createOrUpdate(ddoc, db);
            // return {};
        }
    };

}

module.exports = new couchView();