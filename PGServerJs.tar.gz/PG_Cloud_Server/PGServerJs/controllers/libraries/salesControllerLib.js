/*jshint sub:true*/
var itemsController = require('../Items.js');
const globalConfigurations = require('../GlobalConfigurations');
var validator = require('validator');
var BPromise = require("bluebird");
var math = require('mathjs');
var logger = require('../../common/Logger');
var utils = require('../common/Utils');
var status = require('../../common/StatusCode');
var couchDBUtils = require('../common/CouchDBUtils');
var computeUtils = require('../common/computeUtils');
var mainDBInstance = couchDBUtils.getMainCouchDB();
const licenceHelper = require('../../licencer/licenceHelper');
var moment = require('moment');
const itemsLib = require('./itemsControllerLib');
const ITEM_TYPE = itemsLib.ITEM_TYPE;
const salesLib2 = require('./salesControllerLib2');
const commonLib = require('./commonLib');
const ARRAY_LENGTH = utils.getArrayLength;
const IS_EMPTY_OBJECT = utils.isEmptyObject;
const ASSING_IFNOT_UNDEFINED = utils.assignifNotUndefined;
const CLONE = utils.clone;
const commonLibEx = require('../../TSControllers/libraries/commonLibEx');
const detTaxCommonLib = require('../../TSControllers/libraries/taxDetailsCommon');
const getSaleOnCreditAmt = commonLibEx.getSaleOnCreditAmt;
const getDetailedTaxByPerc = detTaxCommonLib.getDetailedTaxByPerc;
const get_taxes = commonLibEx.get_taxes;
const saleEx = require('../../TSControllers/SalesEx');

module.exports = function(requestSession, applicationSettings) {
    return salesControllerLib(requestSession, applicationSettings);
};

function salesControllerLib(session, applicationSettings) {

    let foo = {};
    var _self = foo;
    if (!session.salesTempInfo) {
        session.salesTempInfo = {}
    }

    if (!session.cart) {
        session.cart = [];
    }

    if (!session.settings) {
        session.settings = {
            sales: {
                profile: {},
                bLocalTax: true
            }
        };
    }

    if (!session.settings.sales) {
        session.settings.sales = {
            profile: {},
            bLocalTax: true
        };
    }
    let itemLocation = 1;
    let saleSettings = session.settings.sales;
    saleSettings.profileId = applicationSettings.salesConfig.pProfileId;
    saleSettings.pProfileSettings = applicationSettings.salesConfig.pProfileSettings;
    let roundOfSettings = applicationSettings.numberFormat;

    let bDirtyPriceFlag = false;
    let bWaitForMe = false;
    if (!saleSettings.pProfile || saleSettings.pProfile.id !== applicationSettings.salesConfig.pProfileId) {
        bDirtyPriceFlag = true;
        bWaitForMe = true;
    }

    function getPProfileDoc(id) {
        return couchDBUtils.getDoc('pProfile_' + id, mainDBInstance, 'no doc');
    }

    if (bDirtyPriceFlag) {
        getPProfileDoc(applicationSettings.salesConfig.pProfileId).then(function(resp) {
            saleSettings.pProfile = resp;
            bWaitForMe = false;
        }).catch(function(error) {
            throw 'pProfile get exception not expected to come here';
        });
    }

    let bComputeTax = false;

    function formatProfileGSTTaxes() {
        if (IS_EMPTY_OBJECT(saleSettings.profile)) {
            return;
        }

        let taxes = saleSettings.profile.preparedTaxes;
        let formattedTaxes = [];
        for (let i = 0; i < taxes.length; i++) {
            formattedTaxes.push(taxes[i]);
        }

        computeUtils.formatGSTTaxes(formattedTaxes, saleSettings.bLocalTax);
        saleSettings.profile.formattedPreparedTaxes = formattedTaxes;
    }

    /**
     * profileId is optional
     * updating everytime getsales is called, as there may be change in taxes
     * It will get all the taxes, slab, charges from the db
     * This function is used in UT
     */
    foo.updateSalesProfileSettings = async function(profileId) {

        saleSettings.profileId = profileId;
        if (!profileId) {
            saleSettings.profile = {};
        }

        try {
            if (profileId) {
                saleSettings.profile = await globalConfigurations.getProfileInfo(profileId);
                formatProfileGSTTaxes();
            }

        } catch (error) {
            saleSettings.profile = {};
            logger.error(error);
            throw error;
        }
    };

    foo.setLocalTax = async function(bLocalTax) {
        saleSettings.bLocalTax = bLocalTax;
        formatProfileGSTTaxes();
        bComputeTax = true;
    };

    foo.setPrintBillInvoiceNo = function(orderData) {
        session.sale_id = orderData ? orderData.prefix + orderData.invoice_no : undefined;
    };

    foo.getPrintBillInvoiceNo = function() {
        return session.sale_id;
    };

    foo.setDeliveryCharge = function(dCharge) {
        session.delveryCharge = dCharge;
    };

    foo.setTableNo = function(tableNo) {
        session.tableNo = tableNo;
    };

    foo.getTableNo = function() {
        return session.tableNo;
    };
    foo.getDeliveryCharge = function() {
        return session.delveryCharge ? session.delveryCharge : 0;
    };

    foo.setOrderFromHD = function(bool) {
        session.bHomeDelivery = bool;
    };

    foo.getOrderFromHD = function() {
        return session.bHomeDelivery;
    };

    foo.setDeliveryBoy = function(dBoy) {
        session.delveryBoy = dBoy;
    };

    foo.getDeliveryBoy = function(dBoy) {
        return session.delveryBoy;
    }

    foo.setHDIdRev = function(doc) {
        if (!doc) {
            session.hdOrder = {};
            return;
        }
        session.hdOrder = doc;
    };

    foo.getHDIdRev = function() {
        if (!session.hdOrder) {
            session.hdOrder = {};
        }
        return session.hdOrder;
    };

    foo.setSOIdRev = function(doc) {
        if (!doc) {
            session.soOrder = {};
            return;
        }
        session.soOrder = doc;
    };

    foo.getSOIdRev = function() {
        if (!session.soOrder) {
            session.soOrder = {};
        }
        return session.soOrder;
    };

    foo.setSQIdRev = function(doc) {
        if (!doc) {
            session.sqOrder = {};
            return;
        }
        session.sqOrder = doc;
    };

    foo.getSQIdRev = function() {
        if (!session.sqOrder) {
            session.sqOrder = {};
        }
        return session.sqOrder;
    };

    foo.setShippingAddress = function(shippingAddress) {
        session.sipAddrs = shippingAddress;
    };

    foo.setSOOrderDate = function(date) {
        session.soOrderDate = date;
    }

    foo.setBSalesOrder = function(bool) {
        session.bSalesOrder = bool;
    }

    foo.getShippingAddress = function() {
        return session.sipAddrs;
    };

    foo.getSOOrderDate = function() {
        return session.soOrderDate;
    }

    foo.getBSalesOrder = function() {
        return session.bSalesOrder;
    }

    foo.setSQDate = function(date) {
        session.SQOrderDate = date;
    }

    foo.getSQDate = function() {
        return session.SQOrderDate;
    }

    foo.setSQorder = function(bool) {
        session.bSalesQuotation = bool;
    }

    foo.getSQorder = function() {
        return session.bSalesQuotation;
    }

    foo.setCartCustomerDetails = function(customer_id) {
        var response = {
            status: status.ERR_UNDEFINED
        };

        if (!utils.isUndefinedOrNull(customer_id)) {
            return couchDBUtils.getDoc('customer_' + customer_id, mainDBInstance).then(function(customer4Cart) {
                if (customer4Cart) {
                    session.customerDetails = customer4Cart;
                    response.status = status.SUCCESS;
                    return response;
                }
                return response;
            }).catch(function(err) {
                logger.error(err);
                return response;
            });
        } else {
            session.customerDetails = {
                person_id: null
            };
            return Promise.resolve(response);
        }
    };

    foo.getCartCustomerDetails = function() {
        if (utils.isUndefinedOrNull(session.customerDetails)) {
            session.customerDetails = {
                person_id: null
            };
        }
        return session.customerDetails;
    };

    foo.resetCartEmployee = function() {
        session.salesEmployeeInfo = session.user;
    }

    foo.setCartEmployeeDetails = async function(empId) {
        var response = {
            status: status.ERR_UNDEFINED
        };
        let errMsg = "User does't exist";
        if (!utils.isUndefinedOrNull(empId)) {
            try {
                session.salesEmployeeInfo = await couchDBUtils.getDoc('org.couchdb.user:' + empId, couchDBUtils.getUserCouchDB(), errMsg);
                response.status = status.SUCCESS;
            } catch (ex) {
                throw errMsg;
            }
        } else {
            session.salesEmployeeInfo = null;
        }
        return response;

    };

    foo.getCartEmployeeDetails = function() {
        return session.salesEmployeeInfo ? session.salesEmployeeInfo : session.user;
    };

    foo.getProfileId = function() {
        return saleSettings.profileId;
    };

    foo.get_mode = function() {

        if (!session.sale_mode) {
            session.sale_mode = 'sale';
        }
        return session.sale_mode;
    };

    foo.get_cart = function() {

        if (!session.cart) {
            session.cart = [];
        }
        return session.cart;
    };

    foo.set_cart = function(salesCartData) {
        session.cart = salesCartData;
    };
    foo.set_mode = function(mode) {
        session.sale_mode = mode;
    };

    foo.get_sale_location = function() {
        return itemLocation;
    };

    foo.getSaleIdFromReceiptOrInvoiceNumber = function(receiptNumberOrInvoiceNumber) {

        var parts = receiptNumberOrInvoiceNumber.split(' ');
        if (parts.length === 2 && parts[0].toLowerCase() === 'pos') {
            var saleId = parts[1];
            return salesModel.isSaleExists(saleId);
        } else {

            return salesModel.getSaleIdFromInvoiceNumber(receiptNumberOrInvoiceNumber);
        }

    };

    foo.setAlienDoc = function(paramObj, requestData) {
        if (requestData.bServerPush && requestData.alienId) {
            paramObj.customerApp = {
                alienId: requestData.alienId,
                bSyncStatus: false,
                shopId: licenceHelper.getServerSerialNumber(),
                shopName: applicationSettings.ownersInfo.company
            }
        }
    }

    foo.isValidItemKit = function(itemKitId) {

        //TODO find out why we need here split
        //itemKitId = itemKitId.split(' ', itemKitId)[1];
        return ItemKitsModel.findById(itemKitId);

    };

    foo.emptyCart = function() {
        session.cart = [];
    };

    /**
     *      Todo
     *          This calculation should include discount also, addItem2Cart calls with discount argument
     *          refer receivingsLib similar funciton           
     * 
     */
    function getItemTotal(quantity, price) {

        return math.multiply(quantity, price);
    }

    foo.get_subtotal = function(bIncludeDiscount, bIncludeCharges) {
        var subtotal = 0;
        var thisSalesCart = _self.get_cart();
        for (var index in thisSalesCart) {
            var item = thisSalesCart[index];
            if (bIncludeCharges) {
                // Price - Discount + Charges    
                subtotal += item.totalAfterDisAndCharges;
            } else if (bIncludeDiscount) {
                //No Charges
                subtotal += item.discounted_total;
            } else {
                //No Charges, No Discount
                subtotal += item.total;
            }

        }

        return subtotal;
    };

    foo.get_GDPercent = function() {
        let subTotal = _self.get_subtotal();
        let gDiscountValue = session.gDiscountValue ? session.gDiscountValue : 0;
        let bGDiscountPercent = session.bGDiscountPercent ? session.bGDiscountPercent : false;
        let gdP = gDiscountValue;
        if (!bGDiscountPercent) {
            gdP = gDiscountValue / (subTotal) * 100;
        }
        return gdP;

    }
    /**compuets the total cost of the sale */
    foo.get_cost = function(cartData) {
        let cost = 0;
        for (let i = 0; i < cartData.length; i++) {
            cost += (parseFloat(cartData[i].purchasePrice)) * parseFloat(cartData[i].quantity);
        }

        return cost;

    }

    foo.get_quantity = function(cartData) {
        let qty = 0;
        for (let i = 0; i < cartData.length; i++) {
            qty += parseFloat(cartData[i].quantity);
        }

        return qty;

    }

    /**computes the total profit of sale */
    foo.get_profit = function(subTotal, cost) {
        return math.subtract(subTotal, cost);
    }

    foo.getTaxAmt = function(taxArray) {
        let taxAmt = 0;
        for (let tax in taxArray) {
            taxAmt += taxArray[tax];
        }
        return taxAmt;
    }
    foo.getAllCharges = function(thisSalesCart) {
        let allCharges = {};

        for (let index in thisSalesCart) {
            let item = thisSalesCart[index];
            for (let i = 0; i < ARRAY_LENGTH(item.chargesList); i++) {
                let chargeInfo = item.chargesList[i];
                let key = chargeInfo.name + ' @' + chargeInfo.percent;
                if (!allCharges.hasOwnProperty(key)) {
                    allCharges[key] = 0;
                }
                allCharges[key] += chargeInfo.Amt;
            }
        }

        return allCharges;
    };

    foo.removeCustomer = function() {
        delete session.customer;
        delete session.customerDetails;
        var message = "successfully removed customer from cart";
        return message;
    };

    foo.removeSalesEmployee = function() {
        delete session.salesEmployeeInfo;
        var message = "successfully removed sales employee from cart";
        return message;
    };

    foo.setRefBookingId = function(id) {
        session.refBookingId = id;
    };

    foo.getRefBookingId = function(id) {
        return session.refBookingId;
    };

    foo.set_customer = function(customer_id) {
        session.customer = null;
        return foo.setCartCustomerDetails(customer_id).then(function(resp) {
            if (session.customerDetails !== undefined) {
                session.customer = session.customerDetails.person_id;
            }

            return resp;
        }).catch(function(err) {
            if (session.customerDetails !== undefined) {
                session.customer = session.customerDetails.person_id;
            }
            return Promise.reject(err);
        });
    };

    foo.get_customer = function() {
        if (!session.customer) {
            session.customer = null;
        }
        return session.customer;
    };

    function findIndexOfItemByItemId(itemId, cart) {
        var index = -1;
        for (var index in cart) {
            if (cart[index].item_id === itemId /*&& cartItem.item_location == itemLocation*/ ) {
                index = index;
                break;
            }
        }

        return index;
    }

    function findIndexOfItemByLine(line, cart) {
        var index = -1;
        for (var index in cart) {
            if (cart[index].line === line) {
                index = index;
                break;
            }
        }

        return index;
    }

    /**      
     * @param {*json having all the information on taxes} profile 
     * @param {*Ingredient Should Not come here} itemType 
     */
    function getProfileTaxesByItemType(profile, itemType) {
        if (!ITEM_TYPE.hasOwnProperty(itemType)) {
            logger.error('Unknown Item Type<' + itemType + '>');
            throw 'Internal Error';
        }

        let key = itemType.toLowerCase() + 'Taxes';
        return profile[key];
    }

    /**
     * 
     * @param {* Array salesTaxes 3rd priority} taxes 
     * @param {* Object salesSlab 1st priority} slab 
     * @param {* float depending on the price, tax rate for slab is decided} price 
     * @param {* Array output taxes} formattedTaxes      
     * This function is used in UTs other than in this file
     */
    foo.getTaxesForItem = function(taxes, slab, baseUnitPrice, formattedTaxes, formattedChargesTaxes, bSPTaxInclusive, itemType) {

        let totalTaxPercent = 0;
        formattedTaxes.length = 0;
        formattedChargesTaxes.length = 0;
        /**
         * profile is stored in session. Every call to getSalesRestApi, the profile gets refreshed
         * This is not fool proof but okay
         */
        let profile = saleSettings.profile;
        let profileTaxes = [];
        if (profile) {
            if (IS_EMPTY_OBJECT(slab) && !IS_EMPTY_OBJECT(profile.slab)) {
                slab = profile.slab;
            }

            let taxes = getProfileTaxesByItemType(profile, itemType);
            if (ARRAY_LENGTH(taxes)) {
                profileTaxes = taxes;
            }
            taxes = profile.formattedPreparedTaxes;
            if (ARRAY_LENGTH(taxes)) {
                for (let i = 0; i < taxes.length; i++) {
                    formattedChargesTaxes.push({
                        name: taxes[i].name,
                        percent: taxes[i].percent
                    });
                }
            }
        }
        if (!IS_EMPTY_OBJECT(slab) && bSPTaxInclusive) {
            logger.error('tax slab and tax inclusive is not implemented');
            throw 'Internal Error';
        }

        let formattedTaxesCount = {};
        if (!IS_EMPTY_OBJECT(slab)) {
            let taxFromSlab = computeUtils.getTaxFromSlab(slab, baseUnitPrice);

            if (taxFromSlab.percent !== -1) {
                formattedTaxes.push(taxFromSlab);
                formattedTaxesCount[taxFromSlab.name] = 1;
                totalTaxPercent += taxFromSlab.percent;
            }
        }

        for (let taxIdx in taxes) {
            let tax = taxes[taxIdx].taxInfo;
            if (!formattedTaxesCount[tax.name]) {
                let itemTaxInfo = {};
                itemTaxInfo.name = tax.name;
                itemTaxInfo.percent = tax.percent;
                totalTaxPercent += tax.percent;
                formattedTaxes.push(itemTaxInfo);
                formattedTaxesCount[tax.name] = 1;
            }
        }

        for (let i = 0; i < profileTaxes.length; i++) {
            let tax = profileTaxes[i];
            if (!formattedTaxesCount[tax.name]) {
                formattedTaxes.push(tax);
                formattedTaxesCount[tax.name] = 1;
                totalTaxPercent += tax.percent;
            }
        }

        computeUtils.formatGSTTaxes(formattedTaxes, saleSettings.bLocalTax);
        return totalTaxPercent;
    }

    function convertPProfileData(data, pProfile) {
        let cloneData = CLONE(data);
        if (pProfile.delta) {
            cloneData.sellingPrice += pProfile.delta;
        } else if (pProfile.deltaPercent) {
            cloneData.sellingPrice *= (1 + pProfile.deltaPercent * 0.01);
        }

        return cloneData;
    }

    /**
     * curPProfile is passed in UT
     * we can improve by recursive dependency.. it is very easy..
     */
    foo.getPProfileData = async function(pProfilesData, curPProfile) {
        if (!curPProfile) {
            curPProfile = saleSettings.pProfile;
        }

        if (pProfilesData[curPProfile.id]) {
            return pProfilesData[curPProfile.id];
        }

        // get all profileIds for that Unit
        let pProfileIds = Object.keys(pProfilesData);
        let refId = curPProfile.refId;
        if (refId) {
            refId = refId.toString();
        }
        let index = pProfileIds.indexOf(refId);
        if (index > -1) {
            return convertPProfileData(pProfilesData[refId], curPProfile);
        } else if (refId) {
            let tempPProfile = await getPProfileDoc(refId);
            let data = await _self.getPProfileData(pProfilesData, tempPProfile);
            return convertPProfileData(data, curPProfile);
            //todomultipleunits
            //we could use settings to configure and throw exception saying .. for this item.. this profile is not set
        } else {
            //pProfileIds length should be atleast 1..
            if (saleSettings.pProfileSettings.orphanAction === "selectDefaultProfile") {
                return pProfilesData[pProfileIds[0]];
            } else if (saleSettings.pProfileSettings.orphanAction === "throwError") {
                throw "Profile Not exists";
            } else if (saleSettings.pProfileSettings.orphanAction === "checkOtherUnitsForProfile") {
                //todomultipleunits
                throw 'Not Implemented';
            }
        }
    }

    function validateUnitsInfoForSaleEdit(prevUnitsInfo, curUntisInfo) {

    }

    /**
     * BMTodo check proper usage of arguments. 
     * These may come from suspend sales or returns in which case these values only should be used instead from the item/batch table
     * pItemTaxList,pBSPTaxInclusive -- this is used when editing sale to use taxes from the sale document
     */
    async function addItem2CartHelper(params) {
        var itemQueryParams = {
            item_id: params.itemId,
            stockKey: params.stockKey
        };

        try {
            let itemInfo = await itemsLib.getThisItemInfo(itemQueryParams);
            let categoryInfo = await couchDBUtils.getDoc('category_' + itemInfo.categoryId, mainDBInstance);
            if (!itemInfo) {
                return Promise.reject('Item Not Found ' + params.itemId);
            }

            if (itemInfo.batches.length === 0) {
                return Promise.reject('Out of Stock ' + itemInfo.name + ' stockKey ' + params.stockKey);
            }

            var batchInfo = itemInfo.batches[0];

            if (!params.unitId) {
                params.unitId = itemInfo.defaultSellingUnitId;
            }

            let unitsInfo = params.unitsInfo;
            if (!unitsInfo) {
                unitsInfo = batchInfo.unitsInfo;
            } else if (params.baseUnitId != itemInfo.baseUnitId) {
                throw 'Base Unit Changed';
            }

            let bomIngredient_info;
            let bomFactor;
            if (itemInfo.bomData) {
                bomIngredient_info = itemInfo.bomData.ingredient_info;
                bomFactor = itemInfo.bomData.factor;
            }

            let priceInfo = unitsInfo[params.unitId];
            let curPProfileData = await _self.getPProfileData(priceInfo.pProfilesData);
            //overwriting with discount from db
            if (params.discount !== undefined) {
                //This is from Sale Edit .. don't do anything
            } else if (curPProfileData.discount) {
                params.discount = curPProfileData.discount.discount;
            } else if (params.discount === undefined) {
                //use default discount from application settings
                params.discount = applicationSettings.discount.defaultSalesDiscount;
            } else if (params.discount === undefined) {
                params.discount = 0;
            }

            if (!params.price) {
                params.price = curPProfileData.sellingPrice;
            };

            //Adding Item taxes                        
            var taxList = [];
            let chargesTaxList = [];
            var taxes = params.pItemTaxList;
            let slab = itemInfo.salesSlab;
            if (!params.pItemTaxList) {
                taxes = itemInfo.salesTaxes;
            } else {
                //for sale edit we are overwriting values
                taxes = [];
                for (let i = 0; i < params.pItemTaxList.length; i++) {
                    taxes.push({
                        taxInfo: params.pItemTaxList[i]
                    });
                }
                itemInfo.bSPTaxInclusive = params.pBSPTaxInclusive;
                slab = params.pSlab;
            }
            let baseUnitPrice = commonLib.getBaseUnitPrice(params.price, params.unitId, itemInfo.baseUnitId, unitsInfo);
            let SPrice = baseUnitPrice;
            if (!itemInfo.bSPTaxInclusive) {
                if (params.discountBy === 'value' && params.discount) {
                    SPrice = baseUnitPrice - params.discount;
                } else {
                    SPrice = baseUnitPrice * (1 - params.discount * 0.01);
                }
            }

            var totalTaxPercent = _self.getTaxesForItem(taxes, slab, SPrice, taxList, chargesTaxList, itemInfo.bSPTaxInclusive, itemInfo.ItemType);
            var sellingPriceExcludingTax = computeUtils.getPriceTaxEx(params.price, itemInfo.bSPTaxInclusive, totalTaxPercent);
            if (params.discountBy === 'value' && params.discount) {
                let dP = params.discount;
                dP = params.discount / sellingPriceExcludingTax * 100;
                params.discount = dP;

            }
            if (!IS_EMPTY_OBJECT(itemInfo.salesSlab) && itemInfo.bSPTaxInclusive) {
                logger.error('Not Implemented. Inclusive Tax and slab');
                return Promise.reject('Internal Error');
            }
            var itemPurTaxList = [];
            //purchase slabTax is not required for computation because inclusive tax no slab, for exclusive tax doesn't matter
            var purchasePrice = commonLib.getPPFromUInfo(unitsInfo, params.unitId);
            let baseUnitPriceForP = commonLib.getBaseUnitPrice(purchasePrice, params.unitId, itemInfo.baseUnitId, unitsInfo);
            let totalPurchaseTaxPercent = commonLib.getTaxesForItem(false, itemInfo.purchaseTaxes, itemInfo.purchaseSlab, itemPurTaxList, baseUnitPriceForP, itemInfo.bPPTaxInclusive); // computeUtils.getTotalTaxPercent(itemInfo.purchaseTaxes);

            var purchasePriceExTax = purchasePrice;
            if (itemInfo.bPPTaxInclusive) {
                purchasePriceExTax = computeUtils.calculatePriceExcludingTax(purchasePrice, totalPurchaseTaxPercent);
            }
            var cartItem = {
                'item_id': params.itemId,
                'batchId': batchInfo.batchId,
                'ItemType': itemInfo.ItemType,
                'stockKey': params.stockKey,
                'item_location': itemLocation,
                'stock_name': batchInfo.stockLocation.location_name,
                'line': params.insertkey,
                'name': itemInfo.name,
                'item_number': itemInfo.item_number,
                'uniqueItemCode': itemInfo.uniqueItemCode,
                'description': itemInfo.description,
                'serialnumber': params.serialnumber !== null ? params.serialnumber : '',
                'imeiNumbers': params.imeiNumbers ? params.imeiNumbers : [],
                'isNew': params.isNew,
                'is_serialized': itemInfo.is_serialized,
                'hasBatchNumber': itemInfo.hasBatchNumber,
                'bOTG': itemInfo.bOTG,
                'hsn': itemInfo.hsn,
                'hasExpiryDate': itemInfo.hasExpiryDate,
                'bSPTaxInclusive': itemInfo.bSPTaxInclusive,
                'bPPTaxInclusive': itemInfo.bPPTaxInclusive,
                'expiry': batchInfo.expiry,
                'unit': commonLib.getUnitName(itemInfo.unitDocs, params.unitId),
                'unitDocs': itemInfo.unitDocs,
                'unitId': params.unitId,
                'baseUnitId': itemInfo.baseUnitId,
                'quantity': params.quantity,
                'discount': params.discount,
                'discountBy': params.discountBy,
                'price': params.price,
                'baseUnitPrice': baseUnitPrice,
                'sellingPriceExcludingTax': sellingPriceExcludingTax,
                'totalTaxPercent': totalTaxPercent,
                'totalPurchaseTaxPercent': totalPurchaseTaxPercent,
                // 'loyaltyPerc': batchInfo.Discounts.loyaltyPerc,
                'purchasePrice': purchasePriceExTax, //This is added for reports purpose                
                'mrp': priceInfo.mrp,
                'reorder_level': itemInfo.reorderLevel,
                'imeiCount': itemInfo.imeiCount,
                'chargesList': [],
                'chargesTaxList': chargesTaxList,
                'isWarranty': itemInfo.isWarranty,
                'warranty': itemInfo.warranty,
                'warrantyTerms': itemInfo.warrantyTerms,
                'unitsInfo': unitsInfo,
                'categoryId': itemInfo.categoryId,
                'category': categoryInfo.name,
                'bomIngredient_info': bomIngredient_info,
                'bomFactor': bomFactor
            };

            if (batchInfo.attributeInfo) {
                cartItem.attributeInfo = batchInfo.attributeInfo;
                cartItem.skuName = batchInfo.skuName;
            }

            cartItem.itemTaxList = taxList;
            cartItem.origTaxes = taxes;
            cartItem.slab = slab;
            var salesCart = _self.get_cart();
            salesCart.push(cartItem);

            return salesCart.length - 1;
        } catch (err) {
            throw err;
        };
    }

    //Any computation for an item in cart
    function computeItemCart(cartItem, iAddDiscount) {

        cartItem.purchaseTax = computeUtils.computepxax0dot01(cartItem.totalPurchaseTaxPercent, cartItem.purchasePrice);
        var quantity = cartItem.quantity;
        var priceExcludingTax = cartItem.sellingPriceExcludingTax;
        cartItem.cost = cartItem.purchasePrice * quantity;

        var total = getItemTotal(quantity, priceExcludingTax);

        cartItem.gDiscountPercent = 0;
        if (cartItem.gDiscountValue) {
            cartItem.gDiscountPercent = cartItem.gDiscountValue;
            if (!cartItem.bGDiscountPercent) {
                cartItem.gDiscountPercent = 100 * cartItem.gDiscountValue / priceExcludingTax;
            }
        }
        cartItem.discount = cartItem.discount ? cartItem.discount : 0;
        var discountPercent = (cartItem.discount + cartItem.gDiscountPercent) * iAddDiscount;
        var discountedPrice = getDiscountedPrice(total, discountPercent);
        var discountedTotal = getPriceAfterDiscount(total, discountedPrice);
        cartItem.gDiscountAmt = getDiscountedPrice(total, cartItem.gDiscountPercent);
        cartItem.total = total;
        cartItem.discounted_total = discountedTotal;
        cartItem.discounted_price = discountedPrice;

        let charges = saleSettings.profile.charges;
        cartItem.chargesList = [];
        if (ARRAY_LENGTH(charges)) {

            for (let i = 0; i < charges.length; i++) {
                cartItem.chargesList.push({
                    name: charges[i].name,
                    percent: charges[i].percent
                });
            }
        }

        let totalChargesAmt = 0;
        for (let i = 0; i < ARRAY_LENGTH(cartItem.chargesList); i++) {
            let chargesAmt = computeTax(discountedTotal, cartItem.chargesList[i].percent);
            cartItem.chargesList[i].Amt = chargesAmt;
            totalChargesAmt += chargesAmt;
        }
        //subTotal
        cartItem.totalAfterDisAndCharges = discountedTotal + totalChargesAmt;
        cartItem.totalWithTax = cartItem.totalAfterDisAndCharges;

        cartItem.itemTaxList.forEach(function(itemTaxInfo) {
            let taxAmt = computeTax(discountedTotal, itemTaxInfo.percent);
            itemTaxInfo.Amt = taxAmt;
            cartItem.totalWithTax += taxAmt;
        });

        for (let i = 0; i < cartItem.chargesTaxList.length; i++) {
            let tax = cartItem.chargesTaxList[i];
            tax.Amt = computeTax(totalChargesAmt, tax.percent);
            cartItem.totalWithTax += tax.Amt;
        }
        cartItem.profit = cartItem.totalAfterDisAndCharges - cartItem.cost;
        //total cartItem.totalWithTax
    }

    //Any computation for all items in cart
    foo.computeCart = async function(iAddDiscount, iAddGlobalDiscount) {
        iAddDiscount = ASSING_IFNOT_UNDEFINED(iAddDiscount, 1);
        iAddGlobalDiscount = ASSING_IFNOT_UNDEFINED(iAddGlobalDiscount, 1);

        if (applicationSettings.taxProfile && saleSettings.profileId !== applicationSettings.taxProfile.id) {
            //if any change in tax profile we are updating here again 
            await foo.updateSalesProfileSettings(applicationSettings.taxProfile.id);
            bComputeTax = true;
        }

        let gDiscountValue = session.gDiscountValue ? session.gDiscountValue : 0;
        let bGDiscountPercent = session.bGDiscountPercent ? session.bGDiscountPercent : false;
        if (!bGDiscountPercent) {
            //#july05 -- handle in UI only
            //**SPOT**
            //changes
            gDiscountValue = _self.get_GDPercent();
            bGDiscountPercent = true;
            //old: bad code
            // let itemCount = getTotalItemCount();
            // if (itemCount !== 0) {
            //     gDiscountValue = gDiscountValue / itemCount;
            // }
        }
        gDiscountValue *= iAddGlobalDiscount;

        var salesCart = foo.get_cart();
        for (var i = 0; i < salesCart.length; i++) {
            var cartItem = salesCart[i];
            cartItem.gDiscountValue = gDiscountValue;
            cartItem.bGDiscountPercent = bGDiscountPercent;

            if (bDirtyPriceFlag) {
                while (bWaitForMe) {
                    await utils.pgTimeOut(25);
                    logger.info('I am waiting<' + bWaitForMe + '>');
                }
                await updateCartItemParams(cartItem);
                bComputeTax = false;
            }
            // session.gInputDiscountValue = data.value;
            // session.gInputDiscountPercent = data.bPercent;
            // var price = cartItem.baseUnitPrice;
            // var totDiscountPercent = cartItem.discount;
            // var gdValue = session.gInputDiscountValue ? session.gInputDiscountValue : 0;
            // if (applicationSettings.salesConfig.discountMethod !== 'onTotal') {
            //     if (!session.gInputDiscountPercent) {
            //         totDiscountPercent += (gdValue * 100) / price;
            //         // totDiscountPercent += cartItem.discount;
            //     } else {
            //         totDiscountPercent += gdValue;
            //     }
            // }
            // if (!cartItem.bSPTaxInclusive) {
            //     price = price * (1 - totDiscountPercent * 0.01);
            // }
            if (bComputeTax) {
                computeTotalTaxPercent(cartItem);
                // cartItem.totalTaxPercent = _self.getTaxesForItem(cartItem.origTaxes, cartItem.slab, price, cartItem.itemTaxList, cartItem.chargesTaxList, cartItem.bSPTaxInclusive, cartItem.ItemType);
            }
            cartItem.bReadyForCheckout = isReadyForCheckout(cartItem);
            computeItemCart(cartItem, iAddDiscount);
        }
        bDirtyPriceFlag = false;
    }

    function computeTotalTaxPercent(cartItem) {
        var price = cartItem.baseUnitPrice;
        var totDiscountPercent = cartItem.discount;
        var gdValue = session.gInputDiscountValue ? session.gInputDiscountValue : 0;
        if (applicationSettings.salesConfig.discountMethod !== 'onTotal') {
            if (!session.gInputDiscountPercent) {
                totDiscountPercent += (gdValue * 100) / price;
                // totDiscountPercent += cartItem.discount;
            } else {
                totDiscountPercent += gdValue;
            }
        }
        if (!cartItem.bSPTaxInclusive) {
            price = price * (1 - totDiscountPercent * 0.01);
        }
        cartItem.totalTaxPercent = _self.getTaxesForItem(cartItem.origTaxes, cartItem.slab, price, cartItem.itemTaxList, cartItem.chargesTaxList, cartItem.bSPTaxInclusive, cartItem.ItemType);

    }

    function getDiscountedPrice(price, discountPercent) {
        return price * discountPercent * 0.01;
    }

    function getPriceAfterDiscount(price, discountedPrice) {
        return price - discountedPrice;
    }

    function computeTax(price, taxPercent) {
        return taxPercent * 0.01 * price;
    }

    foo.isCartReadyForCheckout = function() {
        var cart = foo.get_cart();
        var bReadyForCheckout = true;
        for (var i = 0; i < cart.length; i++) {
            var cartItem = cart[i];
            if (!isReadyForCheckout(cartItem)) {
                bReadyForCheckout = false;
            }
        }

        return bReadyForCheckout;
    };

    function isReadyForCheckout(cartItem) {
        var bReadyForCheckout = true;
        if ((cartItem.is_serialized && !cartItem.serialnumber) || (cartItem.imeiCount !== 0 && (!cartItem.imeiNumbers || cartItem.imeiNumbers.length !== cartItem.imeiCount))) {
            bReadyForCheckout = false;
        }

        return bReadyForCheckout;
    }

    /**
     * params.unitId is which unit --> multiple units
     */
    foo.addItem2Cart = async function(params) {
        //TODO check whats really their in the old code and then modify
        //BMTodo all the arguments are for suspendsales 
        params.quantity = params.quantity || 1;
        params.price = params.price || null;
        params.serialnumber = params.serialnumber || null;
        params.imeiNumbers = params.imeiNumbers || [];

        if (!params.stockKey) {
            logger.error('stockKey is mandatory');
            return Promise.reject('Internal Error');
        }

        var salesCart = foo.get_cart();
        var maxkey = 0;

        var itemIndex = -1;
        var itemalreadyinsale = false;
        //We did not find the item yet.
        var insertkey = 0;
        var bItemIsSerialized = false;
        //Key to use for new entry.                    

        for (var index in salesCart) {

            var cartItem = salesCart[index];
            //We primed the loop so maxkey is 0 the first time.
            //Also, we have stored the key in the element itself so we can compare.
            if (maxkey <= cartItem.line) {
                maxkey = cartItem.line;
            }

            if (cartItem.item_id === params.itemId && cartItem.stockKey === params.stockKey && cartItem.item_location === itemLocation) {
                itemalreadyinsale = true;
                itemIndex = index;
                if (!cartItem.is_serialized && cartItem.imeiCount === 0) {
                    params.quantity = (parseFloat(params.quantity) + parseFloat(cartItem.quantity));
                    break;
                } else {
                    bItemIsSerialized = true;
                }
            }
        }

        insertkey = maxkey + 1;

        try {
            //Item already exists and is not serialized, add to quantity            
            if (!itemalreadyinsale || bItemIsSerialized) {
                params.insertkey = insertkey;
                itemIndex = await addItem2CartHelper(params);
            }

            let index = itemIndex;
            var cartItem = salesCart[index];
            if (params.quantity <= 0) {
                _self.deleteItemByLine(cartItem.line);
                salesCart = foo.get_cart(); //reloading cart, as in the previous operation, the array changed
            } else {
                if (params.discountBy === 'value' && params.discount) {
                    let dP = params.discount;
                    dP = params.discount / cartItem.sellingPriceExcludingTax * 100;
                    cartItem.discount = dP / params.quantity;

                }
                cartItem.discountBy = params.discountBy;
                cartItem.quantity = params.quantity;
                if (params.description) {
                    cartItem.description = params.description;
                }

                cartItem.bReadyForCheckout = isReadyForCheckout(cartItem);
            }

            foo.set_cart(salesCart);

            return cartItem;
        } catch (err) {
            logger.error(err);
            return Promise.reject(err);
        };

    };

    async function updateCartItemParams(cartItem) {
        //Unit Changes 
        //AC-NonAc or some other profile changes

        let priceInfo = cartItem.unitsInfo[cartItem.unitId];

        let curPProfileData = await _self.getPProfileData(priceInfo.pProfilesData);
        cartItem.price = curPProfileData.sellingPrice;
        cartItem.mrp = priceInfo.mrp;
        cartItem.discount = 0;
        if (curPProfileData.discount) {
            cartItem.discount = curPProfileData.discount.discount;
        };

        cartItem.baseUnitPrice = commonLib.getBaseUnitPrice(cartItem.price, cartItem.unitId, cartItem.baseUnitId, cartItem.unitsInfo);
        var price = cartItem.baseUnitPrice;
        if (!cartItem.bSPTaxInclusive) {
            price = price * (1 - cartItem.discount * 0.01);
        }
        cartItem.totalTaxPercent = _self.getTaxesForItem(cartItem.origTaxes, cartItem.slab, price, cartItem.itemTaxList, cartItem.chargesTaxList, cartItem.bSPTaxInclusive, cartItem.ItemType);
        cartItem.sellingPriceExcludingTax = computeUtils.getPriceTaxEx(cartItem.price, cartItem.bSPTaxInclusive, cartItem.totalTaxPercent);

        //purchase slabTax is not required for computation because inclusive tax no slab, for exclusive tax doesn't matter
        let purchasePrice = priceInfo.purchasePrice;
        let purchasePriceExTax = computeUtils.getPriceTaxEx(purchasePrice, cartItem.bPPTaxInclusive, cartItem.totalPurchaseTaxPercent);
        cartItem.purchasePrice = purchasePriceExTax;
    }

    foo.updateUnit = async function(data) {
        let cartItem = _self.get_cart().filter(function(cartItem) {
            return cartItem.line === data.line;
        });
        if (cartItem.length <= 0) {
            throw new Error('No item Found in cart with line Number', data.line);
        }
        cartItem = cartItem[0];

        cartItem.unitId = data.unitId;
        cartItem.unit = commonLib.getUnitName(cartItem.unitDocs, cartItem.unitId);
        await updateCartItemParams(cartItem);
    }

    foo.edit_item = function(line, description, serialnumber, imeiNumbers, quantity, discount, discountMethod, price, name) {
        discount = discount || 0;
        discount = parseFloat(discount);

        var thisCartItem = _self.get_cart().filter(function(cartItem) {
            return cartItem.line === line;
        });
        if (thisCartItem.length <= 0) {
            throw new Error('No item Found in cart with line Number', line);
        } else {
            thisCartItem = thisCartItem[0];
            thisCartItem.discountBy = discountMethod;
            thisCartItem.name = name;
            thisCartItem.description = description;
            thisCartItem.serialnumber = serialnumber;
            thisCartItem.imeiNumbers = imeiNumbers;
            if (!thisCartItem.is_serialized && thisCartItem.imeiCount === 0) {
                thisCartItem.quantity = parseFloat(quantity);
            }

            if (!thisCartItem.bSPTaxInclusive) {
                computeDiscount(thisCartItem, discountMethod, price, discount);
            }
            //#July5 Cyclic dependency - review with sai

            if (thisCartItem.price !== price) {
                if (!IS_EMPTY_OBJECT(thisCartItem.slab)) {
                    //if tax slab exist, then it is taxexclusive
                    thisCartItem.baseUnitPrice = commonLib.getBaseUnitPrice(price, thisCartItem.unitId, thisCartItem.baseUnitId, thisCartItem.unitsInfo);
                    var dprice = thisCartItem.baseUnitPrice; //#July5
                    if (!thisCartItem.bSPTaxInclusive) {
                        dprice = dprice * (1 - thisCartItem.discount * 0.01);
                    }
                    //#July5 not including global discount here
                    // thisCartItem.totalTaxPercent = _self.getTaxesForItem(thisCartItem.origTaxes, thisCartItem.slab, price, thisCartItem.itemTaxList, thisCartItem.chargesTaxList, thisCartItem.bSPTaxInclusive, thisCartItem.ItemType);
                    computeTotalTaxPercent(thisCartItem);
                }
                var sellingPriceExcludingTax = computeUtils.getPriceTaxEx(price, thisCartItem.bSPTaxInclusive, thisCartItem.totalTaxPercent);
                thisCartItem.price = price;
                thisCartItem.sellingPriceExcludingTax = sellingPriceExcludingTax;
            }
            if (thisCartItem.bSPTaxInclusive) {
                computeDiscount(thisCartItem, discountMethod, thisCartItem.sellingPriceExcludingTax, discount)
            }
            //inclusive calculate discount here
            thisCartItem.bReadyForCheckout = isReadyForCheckout(thisCartItem);
        }

    };

    function computeDiscount(thisCartItem, discountMethod, priceExTax, discount) {
        let dP = discount;
        if (discountMethod === 'value') {
            dP = discount / priceExTax * 100
        }
        discount = dP;
        thisCartItem.discount = discount;
    }

    foo.deleteItemByLine = function(line) {
        var cart = foo.get_cart();
        var index = findIndexOfItemByLine(line, cart);
        if (index > -1) {
            cart.splice(index, 1);
            return true;
        } else {
            return false;
        }
    };

    foo.get_quantity_already_added = function(item_id, stockKey, item_location) {

        var quanity_already_added = 0;
        var thisSalesCart = _self.get_cart();

        for (var index in thisSalesCart) {
            var item = thisSalesCart[index];
            if (item.item_id === item_id && item.item_location === item_location && item.stockKey === stockKey) {
                quanity_already_added += item.quantity;
            }
        }
        return quanity_already_added;
    };

    foo.out_of_stock = function(itemId, stockKey) {
        //TODO as of now going ahead with single Item location
        //RelaxTodo get item quantities
        var stockStatus = "";
        return itemsLib.getQuantity({

            item_id: itemId,
            stockKey: stockKey
        }).then(function(quantityInfo) {
            let totalQuantity = quantityInfo.totalQuantity;
            let thisStockQuantity = quantityInfo.stockQuantity;
            let itemInfo = quantityInfo.info;

            var stockStatus = false;
            var quantity_added = _self.get_quantity_already_added(itemId, stockKey);
            if ((thisStockQuantity - quantity_added < 0) && !itemInfo.isprepared) {
                var n1 = parseFloat(thisStockQuantity.toFixed(applicationSettings.numberFormat.qtyDecimalDigits));
                stockStatus = 'Item stock level is less than zero, Current Stock is ' + n1 + '. Do you want to proceed with this sale?';
                if (totalQuantity > quantity_added) {
                    stockStatus = 'Consider selling stock from different batch as item stock level in this batch is less than zero, Current Stock is ' + thisStockQuantity + '. Do you want to proceed with this sale?';
                }
            } else if (((totalQuantity - quantity_added) < itemInfo.reorderLevel) && !itemInfo.isprepared) {
                stockStatus = 'Item stock level less than reorder level, Current Stock is ' + thisStockQuantity + ' Do you want to proceed with this sale?';
            }
            return stockStatus;
        }) //If Error it is directly propagated to parent ;

    };

    foo.get_discount = function() {
        var discount = 0;
        var thisSalesCart = _self.get_cart();
        for (var index in thisSalesCart) {
            var item = thisSalesCart[index];
            discount += item.discounted_price;
        }

        return discount;
    };

    foo.get_total = function(obj) {
        var allCartTaxes = get_taxes(_self.get_cart());

        var total = _self.get_subtotal(true, true);
        for (var index in allCartTaxes) {
            var tax = allCartTaxes[index];
            total = math.add(total, tax);
        }

        let totalAfterRoundOff = +utils.roundOffNumber(total, applicationSettings);
        if (obj) {
            obj.addedRoundOffValue = totalAfterRoundOff - total;
        }

        return totalAfterRoundOff;
    };

    foo.get_comment = function() {
        // avoid returning a null that results in a 0 in the comment if nothing is set/available

        return !session.comment ? '' : session.comment;
    };

    foo.get_email_receipt = function() {
        return session.email_receipt;
    };

    foo.get_payments_total = function() {

        var subtotal = 0;
        var payments = foo.get_payments();
        for (var index in payments) {
            var payment = payments[index];
            subtotal = math.add(payment.payment_amount, subtotal);
        }
        //TODO
        //return to_currency_no_money(subtotal);

        return subtotal;
    };

    foo.get_payments = function() {
        if (!session.payments) {
            session.payments = [];
        }
        return session.payments;
    };

    foo.set_payments = function(payments_data) {
        session.payments = payments_data;
    };

    foo.get_amount_due = function() {

        var sales_total = foo.get_total();
        var deliveryCharge = foo.getDeliveryCharge();
        if (deliveryCharge > 0) {
            sales_total += deliveryCharge;
        };
        var amount_due = 0;
        var payment_total = foo.get_payments_total();
        amount_due = math.subtract(sales_total, payment_total);
        return amount_due;
    };

    //Called only by edit
    foo.setCusB4Edit = function(cusId) {
        session.oldCusId = cusId;
    }
    foo.getCusB4Edit = function() {
        return session.oldCusId;
    }

    foo.setCreditBalance = function(creditBalance) {
        session.creditBalance = creditBalance;
    }

    foo.getCreditBalance = function() {
        return session.creditBalance;
    }

    foo.setLoyaltyEarned = function(loyaltyPnts) {
        session.loyaltyEarned = loyaltyPnts;
    }
    foo.getLoyaltyEarned = function() {
        return session.loyaltyEarned;
    }

    foo.setLoyaltyRedeemed = function(loyaltyPnts) {
        session.loyaltyRedeemed = loyaltyPnts;
    }
    foo.getLoyaltyRedeemed = function() {
        return session.loyaltyRedeemed;
    }
    //end 
    foo.setRedeemMoney = function(amount) {
        session.redeemMoney = amount;
    }
    foo.getRedeemMoney = function() {
        return session.redeemMoney;
    }
    foo.is_print_after_sale = function() {
        return session.sales_print_after_sale === true || session.sales_print_after_sale === '1';
    };

    foo.set_print_after_sale = function(print_after_sale) {
        session.sales_print_after_sale = print_after_sale;
    };

    foo.is_invoice_number_enabled = function() {
        return session.sales_invoice_number_enabled === true || session.sales_invoice_number_enabled === '1';
    };

    foo.clear_all = function() {
        foo.clear_mode();
        foo.emptyCart();
        foo.clear_comment();
        foo.clear_email_receipt();
        foo.clear_invoice_number();
        foo.empty_payments();
        foo.removeCustomer();
        foo.setLocalTax(true);
        foo.clearTempDetails();
        foo.setWCInfo();
        foo.setDeliveryCharge();
        foo.setTableNo();
        foo.setOrderFromHD();
        foo.setDeliveryBoy();
        foo.setLoyaltyEarned(0);
        foo.setLoyaltyRedeemed(0);
        foo.setRedeemMoney(0);
        foo.setCusB4Edit();
        foo.setGlobalDiscount({
            value: 0,
            bPercent: true
        });
        foo.setPrintBillInvoiceNo();
        foo.setBSalesOrder();
        foo.setSOOrderDate();
        foo.setSQorder();
        foo.setSQDate();
        foo.setShippingAddress();
        foo.setSQDate();
        foo.setSQorder();
        foo.clearTempDetails();
        foo.setHDIdRev();
        foo.setSOIdRev();
        foo.setSQIdRev();
        foo.setCreditBalance(0);

        if (foo.refBookingId) {
            delete foo.refBookingId;
        }
        // foo.resetCartEmployee();
    };

    foo.set_comment = function(comment) {
        session.comment = comment;
    };
    foo.clear_comment = function() {
        session.comment = null;
    };
    foo.set_email_receipt = function(email_receipt) {
        session.email_receipt = email_receipt;
    };
    foo.clear_email_receipt = function() {
        session.email_receipt = null;
    };

    foo.get_invoice_number = function() {
        return session.sales_invoice_number;
    };

    foo.set_invoice_number = function(invoice_number, keep_custom) {
        keep_custom = keep_custom || false;
        var current_invoice_number = session.sales_invoice_number;

        if (!keep_custom || validator.isEmpty(current_invoice_number)) {
            session.sales_invoice_number = invoice_number;
        }
    };

    foo.clear_invoice_number = function() {
        session.sales_invoice_number = null;
    };

    foo.set_invoice_number_enabled = function(invoice_number_enabled) {
        session.sales_invoice_number_enabled = invoice_number_enabled;
    };

    function getTotalItemCount() {
        let itemCount = 0;

        let cart = _self.get_cart();
        for (let i = 0; i < cart.length; i++) {
            itemCount += cart[i].quantity;
        }

        return itemCount;
    }

    /**
     * Todo: Compute all the totals everytime
     */
    foo.setGlobalDiscount = async function(data) {
        session.discountMethod = data.discountMethod;
        session.gInputDiscountValue = data.value;
        session.gInputDiscountPercent = data.bPercent;
        session.bGDiscountPercent = data.bPercent;
        if (data.discountMethod == 'onTaxable') {
            session.gDiscountValue = data.value;
        } else {
            await computeGlobalDiscountPercent(data);
        }
    };

    /**
     * prevTotal -> total without spot discount
     * noDiscountTotal -> total no item discount no spot discount
     * finalTotal -> total with item discount with spot
     * 
     */
    async function computeGlobalDiscountPercent(data) {
        if (data.value === 0) {
            session.gDiscountValue = 0;
            return;
        }

        await _self.computeCart(1, 0);
        let prevTotal = _self.get_total();
        await _self.computeCart(0, 0);
        let noDiscountTotal = _self.get_total();
        let finalTotal;
        //using previous total .. get final total
        if (data.bPercent) {
            finalTotal = prevTotal * (1 - (data.value * 0.01));
        } else {
            finalTotal = prevTotal - data.value;
        }

        if (noDiscountTotal !== 0) {
            session.gDiscountValue = 100 * (prevTotal - finalTotal) / noDiscountTotal;
        } else {
            session.gDiscountValue = 0;
        }

        session.bGDiscountPercent = true;
    }

    //This has to be modified according to new/old way
    foo.getGlobalDiscountInfo = async function() {
        //get total without discount, without charges
        let subtotal = _self.get_subtotal();
        let gDiscountInfo = {
            amt: 0,
            percent: 0
        };

        if (!session.gDiscountValue) {
            return gDiscountInfo;
        }

        if (session.discountMethod == 'onTaxable') {
            let cart = _self.get_cart();
            for (let i = 0; i < cart.length; i++) {
                gDiscountInfo.amt += cart[i].gDiscountAmt;
            }
            gDiscountInfo.percent = 100 * gDiscountInfo.amt / subtotal;
        } else {
            let finalTotal = _self.get_total();
            await _self.computeCart(1, 0);
            let prevTotal = _self.get_total();
            if (prevTotal !== 0) {
                gDiscountInfo.amt = prevTotal - finalTotal;
                gDiscountInfo.percent = 100 * gDiscountInfo.amt / prevTotal;
            }
            //recomputing so that whoever is using the cart should not be impacted
            await _self.computeCart();
        }
        gDiscountInfo.amt = +gDiscountInfo.amt.toFixed(2);
        gDiscountInfo.percent = +gDiscountInfo.percent.toFixed(2);

        //To resolve rounding issue
        if (session.gInputDiscountPercent) {
            gDiscountInfo.percent = session.gInputDiscountValue;
        } else {
            gDiscountInfo.amt = session.gInputDiscountValue;
        }

        return gDiscountInfo;
    };

    foo.add_payment = function(paymentType, paymentAmount, paymentRefNo) {
        var payments = foo.get_payments();
        var thisPayment = payments.filter(function(payment) {
            return payment.payment_type === paymentType;
        });

        if (thisPayment.length > 0) {
            //payment_method already exists, add to payment_amount            
            thisPayment = thisPayment[0];
            thisPayment.payment_amount = +(thisPayment.payment_amount + paymentAmount).toFixed(roundOfSettings.decimalDigits);
        } else {
            //add to existing array
            var payment = {
                'payment_type': paymentType,
                'payment_amount': +paymentAmount.toFixed(roundOfSettings.decimalDigits),
                'ref_no': paymentRefNo
            };

            payments.push(payment);
        }
        // foo.set_payments(payments);
        return true;
    };
    foo.edit_payment = function(paymentType, paymentAmount) {
        var payments = foo.get_payments();

        var thisPayment = payments.filter(function(payment) {
            return payment.payment_type === paymentType;
        });

        // var payments = foo.get_payments();
        if (thisPayment.length > 0) {
            thisPayment = thisPayment[0];
            if (thisPayment[paymentType]) {
                thisPayment.payment_type = paymentType;
                thisPayment.payment_amount = paymentAmount;
                //foo.set_payments(payments);
            } else {
                throw new Error('Payment with paymentId=' + paymentType + ' Does not exists');
            }
        } else {
            throw new Error('Payment with paymentId=' + paymentType + ' Does not exists');
        }

    };

    foo.delete_payment = function(paymentType) {
        var payments = foo.get_payments();

        payments = payments.filter(function(aPayment) {
            return aPayment.payment_type !== paymentType;
        });
        if (paymentType === 'Redeem') {
            _self.setRedeemMoney(0);
        }
        foo.set_payments(payments);
    };

    foo.empty_payments = function() {
        session.payments = [];
    };

    foo.get_item_id = function(line_to_get) {

        var cartItems = foo.get_cart();
        for (var index in cartItems) {
            if (cartItems[index].line == line_to_get) {
                return cartItems[index].item_id;
            }
        }
        return -1;
    };

    foo.getStockKey = function(line_to_get) {

        var cartItems = foo.get_cart();
        for (var index in cartItems) {
            if (cartItems[index].line == line_to_get) {
                return cartItems[index].stockKey;
            }
        }
        return -1;
    };

    foo.commitSale = async function(params) {
        params.refBookingId = foo.getRefBookingId();
        params.pProfileId = saleSettings.pProfile.id;
        return await salesLib2.commitSale(params);
    };

    /**
     * 
     * IMEITodo : no unique details table for suspsended sale
     */
    foo.addSuspendedItem2Cart = function(itemInfo) {
        let requiredFields = ['item_id', 'stockKey', 'unitId', 'quantity_purchased', 'discount_percent', 'sellingPrice', 'serialnumber', 'imeiNumbers', 'description'];
        let mappedFields = ['itemId', 'stockKey', 'unitId', 'quantity', 'discount', 'price', 'serialnumber', 'imeiNumbers', 'description'];

        let params = {};
        for (let i = 0; i < requiredFields.length; i++) {
            params[mappedFields[i]] = itemInfo[requiredFields[i]];
        }
        return _self.addItem2Cart(params);
    }

    //RelaxTodo Form all the documents in 1 common placce
    foo.copy_entire_suspended_sale = async function(saleId, bOnlyItems) {

        if (utils.isUndefinedOrNull(bOnlyItems)) {
            bOnlyItems = false;
        }

        try {
            let suspendedSaleDoc = await couchDBUtils.getDoc('suspendedSale_' + saleId, mainDBInstance, 'Suspended Sale Not Found.');

            for (let i = 0; i < suspendedSaleDoc.sales_items.length; i++) {
                await _self.addSuspendedItem2Cart(suspendedSaleDoc.sales_items[i]);
            }
            if (!bOnlyItems) {
                for (var i = 0; i < ARRAY_LENGTH(suspendedSaleDoc.payments); i++) {
                    var suspendedPayment = suspendedSaleDoc.payments[i];
                    //Todo: If customersLoyalty is the payment type we have to check it's validity now. This is not handled in phpCode as well
                    _self.add_payment(suspendedPayment.payment_type, suspendedPayment.payment_amount);
                }
                var suspendedInfo = suspendedSaleDoc.sales_info;
                if (!utils.isUndefinedOrNull(suspendedInfo)) {
                    _self.set_customer(suspendedInfo.customer_id);
                    _self.set_comment(suspendedInfo.comment);
                    _self.set_invoice_number(suspendedInfo.invoice_number);
                }
            }

            return true;
        } catch (error) {
            logger.error(error);
            throw error
        }
    };

    var addSuspendedCustomer = async function(saleId) {
        try {
            let salesDoc = await couchDBUtils.getDoc("suspendedSale_" + saleId, mainDBInstance);
            if (salesDoc.sales_info.customer_id !== null) {
                await _self.set_customer(salesDoc.sales_info.customer_id);
            }

            return status.SUCCESS;
        } catch (err) {
            logger.error(err);
            throw err;
        }
    }

    foo.addSuspendedSalesToCart = async function(saleIdArray) {
        try {

            var response = {
                status: status.ERR_UNDEFINED
            };
            if (saleIdArray.length === 0) {
                response.status = status.SUCCESS;
                return Promise.resolve(response);
            }

            let suspendedItemsArray = [];
            for (let i = 0; i < saleIdArray.length; i++) {
                let SuspendedSalesDoc = await couchDBUtils.getDoc("suspendedSale_" + saleIdArray[i], mainDBInstance);
                for (let j = 0; j < SuspendedSalesDoc.sales_items.length; j++) {
                    suspendedItemsArray.push(SuspendedSalesDoc.sales_items[j]);
                }
            }

            var promisesArray = [];
            promisesArray.push(addSuspendedCustomer(saleIdArray[0]));
            promisesArray.push(BPromise.each(suspendedItemsArray, _self.addSuspendedItem2Cart));
            await Promise.all(promisesArray);
            response.status = status.SUCCESS;
            return response;
        } catch (err) {
            logger.error(err);
            throw response;
        }
    };

    foo.clear_mode = function() {
        session.sale_mode = null;
    };

    /**
     *      Currently search by id is only supported  
     *      Started writing this function for returns
     */
    foo.loadSaleHelper = function(params) {
        session.saleDetails = {
            sale_id: params.saleId
        };

        return salesModel.getSaleDetails(params).then(function(resp) {
            resp.sale_id = params.saleId;
            session.saleDetails = resp;

            return session.saleDetails;
        }).catch(function(err) {
            logger.error(err);
            response.err = err;
            return Promise.reject(response);
        });
    };

    foo.setWCInfo = function(wcInfo) {
        session.wcInfo = wcInfo;
    }

    foo.getWCInfo = function(wcInfo) {
        return session.wcInfo;
    }

    foo.getJsonForPrint = function(params) {

        function ROUNDOFFNUMBER(number) {
            var result = +utils.roundOffNumber(number, applicationSettings);
            return result;
        }
        //todo :comment and employee name to be fixed in reprint
        function addInfoForPrint(saleDetails, data, customerInfo, employeeInfo) {
            let invoicePrefix;

            if (saleDetails.sales_info) {
                invoicePrefix = saleDetails.sales_info.invoicePrefix ? saleDetails.sales_info.invoicePrefix : "POS ";
                data.shippingDetails = saleDetails.sales_info.shippingDetails;
                data.state_name = saleDetails.sales_info.state_name;
            }

            if (saleDetails.info) {
                invoicePrefix = saleDetails.info.invoicePrefix ? saleDetails.info.invoicePrefix : "POSR";
            }

            var saleTime;
            if (saleDetails.sales_info) {
                let saleInfo = saleDetails.sales_info;
                data.sale_id = invoicePrefix + saleInfo.sale_id;
                data.order_no = saleInfo.order_no;
                data.comments = saleInfo.comment;
                saleTime = saleInfo.sale_time;
                data.vehicle_phNo = saleInfo.vehicle_phNo;
                data.vehicleNo = saleInfo.vehicleNo;
                data.t_no = saleInfo.t_no;
            } else {
                data.sale_id = invoicePrefix + saleDetails.info.id;
                data.order_no = '';
                data.comments = saleDetails.info.comment;
                saleTime = saleDetails.info.time;
                data.t_no = saleDetails.info.t_no;
            }

            data.transaction_time = moment(saleTime).format(applicationSettings.dateTime.dateformat +
                ' ' + applicationSettings.dateTime.timeformat);

            data.transaction_date = moment(saleTime).format(applicationSettings.dateTime.dateformat);
            data.receipt_title = saleDetails.sales_info ? 'Sales Receipt' : 'Sales Returns Receipt';
            if (saleDetails.sales_info) {
                data.deliveryBoy = saleDetails.sales_info.deliveryBoy;
            }
            if (customerInfo) {
                var lastName = customerInfo.last_name ? customerInfo.last_name : '';

                data.customer = customerInfo.first_name + ' ' + lastName;
                if (customerInfo.company_name) {
                    data.customer_compnay_name = customerInfo.company_name;
                }
                data.customer_id = customerInfo.person_id;
                data.customer_address = customerInfo.address_1;
                data.customer_location = customerInfo.zip + ' ' + customerInfo.city_name;
                data.account_number = customerInfo.account_number;
                data.customerGSTIN = customerInfo.gstin_number;
                data.phone_number = customerInfo.phone_number;
                data.city = customerInfo.city_name;
                data.pincode = customerInfo.pin_code;
                data.customer_email = customerInfo.email;
                data.credit_balance = customerInfo.credit_balance >= 1 ? customerInfo.credit_balance : 0;
                let subtractThisSaleCreditFromCreditBalance = true; // to correct credit balance total by excluding current sale credit in report
                if (subtractThisSaleCreditFromCreditBalance && data.credit_balance > 0) { // for report and credit payment report
                    data.credit_balance -= commonLib.getCreditPayment(data.payments);
                }
                data.CustomInput = customerInfo.CustomInput;

                if (info.wcInfo && info.bHomeDelivery) {
                    if (info.wcInfo.invoiceCustomerName) {
                        data.customer = info.wcInfo.invoiceCustomerName ? info.wcInfo.invoiceCustomerName : data.customer;
                        data.phone_number = info.wcInfo.invoiceCustomerNumber;
                    }
                    data.customer_address = info.wcInfo.invoiceCustomerAddress ? info.wcInfo.invoiceCustomerAddress : customerInfo.address_1;
                    data.city = info.wcInfo.invoiceCustomerCity ? info.wcInfo.invoiceCustomerCity : customerInfo.city_name;
                    data.pincode = info.wcInfo.invoiceCustomerPincode ? info.wcInfo.invoiceCustomerPincode : customerInfo.pin_code;
                };

                data.customer_info = {
                    0: data.customer,
                    1: customerInfo.address_1,
                    2: customerInfo.zip + ' ' + customerInfo.city_name,
                    3: customerInfo.account_number,
                    4: customerInfo.gstin_number,
                    5: customerInfo.phone_number,
                    6: data.city,
                    7: data.pincode,
                    8: data.customer_email
                };
            } else if (info && info.wcInfo) {
                data.customer = info.wcInfo.name;
                data.phone_number = info.wcInfo.phone_number;
            } else {
                data.customer = '';
            }

            data.employee = employeeInfo.first_name + ' ' + employeeInfo.last_name;
            data.company_info = {
                0: applicationSettings.ownersInfo.address,
                1: applicationSettings.ownersInfo.phone,
                2: applicationSettings.ownersInfo.account_number,
                3: applicationSettings.ownersInfo.company
            };
            data.tableNo = (info && info.tableNo) ? info.tableNo : undefined;
            data.company_address = applicationSettings.ownersInfo.address;
            data.company_phone = applicationSettings.ownersInfo.phone;
            data.company_account = applicationSettings.ownersInfo.account_number;
            data.company_name = applicationSettings.ownersInfo.company;
        }

        function getEmptyDataJson() {
            return {
                sale_id: 0,
                totalChargesAmt: 0,
                totalQuantity: 0,
                total: 0,
                subtotal: 0,
                discount: 0,
                discounted_subtotal: 0,
                totalTax: 0,
                amount_due: 0,
                amount_change: 0,
                receipt_title: 'Sales Receipt',
                transaction_time: '',
                transaction_date: '',
                comments: '',
                cart: [],
                taxes: {},
                taxesWithPercents: {},
                charges: {},
                payments: [],
                taxDetailed: {},
                taxNames: {},
                hsnTaxes: {},
                tableNo: 0,
                description: ""
            };
        }

        function computeReprintCart(items, data, iAddGlobalDiscount) {
            iAddGlobalDiscount = ASSING_IFNOT_UNDEFINED(iAddGlobalDiscount, 1);
            if (!data) {
                data = getEmptyDataJson();
            }
            let taxes = data.taxes;
            let taxesWithPercents = data.taxesWithPercents;
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                item.totalTaxPercent = 0;
                for (var j = 0; j < item.itemTaxList.length; j++) {
                    var tax = item.itemTaxList[j];
                    // totalTaxPercent += tax.percent;
                    item.totalTaxPercent += tax.percent;
                }
                var price = computeUtils.getPriceTaxEx(item.sellingPrice, item.bSPTaxInclusive, item.totalTaxPercent);
                item.price = item.sellingPrice;
                item.quantity = item.quantity_purchased;
                data.totalQuantity += item.quantity;
                item.total = price * item.quantity_purchased;
                item.gDiscountPercent = item.gDiscountPercent ? item.gDiscountPercent : 0;
                item.discount_percent = (item.discount_percent ? item.discount_percent : 0) + (item.gDiscountPercent * iAddGlobalDiscount);
                item.discount = item.discount_percent;
                item.discounted_price = item.discount_percent * 0.01 * item.total;
                item.discounted_total = item.total - item.discounted_price;
                let totalChargesAmt = 0;
                for (let i = 0; i < ARRAY_LENGTH(item.chargesList); i++) {
                    let chargesAmt = computeTax(item.discounted_total, item.chargesList[i].percent);
                    item.chargesList[i].Amt = chargesAmt;
                    totalChargesAmt += chargesAmt;
                }
                item.totalAfterDisAndCharges = item.discounted_total + totalChargesAmt;
                item.totalTax = 0;
                for (var j = 0; j < item.itemTaxList.length; j++) {
                    var thisTax = item.itemTaxList[j];
                    var taxName = thisTax.name;
                    if (!taxes.hasOwnProperty(taxName)) {
                        taxes[taxName] = 0;

                    }
                    if (!taxesWithPercents.hasOwnProperty(taxName + ' @' + thisTax.percent + '%')) {
                        taxesWithPercents[taxName + ' @' + thisTax.percent + '%'] = 0;
                    }
                    let amt = thisTax.percent * 0.01 * item.discounted_total;
                    thisTax.Amt = amt;
                    taxes[taxName] += amt;
                    taxesWithPercents[taxName + ' @' + thisTax.percent + '%'] += amt;
                    item.totalTax += amt;
                }
                getDetailedTaxByPerc(item, data.taxDetailed, data.taxNames, data.hsnTaxes);
                for (var j = 0; j < item.chargesTaxList.length; j++) {
                    var thisTax = item.chargesTaxList[j];
                    var taxName = thisTax.name;
                    if (!taxes.hasOwnProperty(taxName)) {
                        taxes[taxName] = 0;
                    }
                    if (!taxesWithPercents.hasOwnProperty(taxName + ' @' + thisTax.percent + '%')) {
                        taxesWithPercents[taxName + ' @' + thisTax.percent + '%'] = 0;
                    }
                    let amt = thisTax.percent * 0.01 * totalChargesAmt;
                    thisTax.Amt = amt;
                    taxes[taxName] += amt;
                    taxesWithPercents[taxName + ' @' + thisTax.percent + '%'] += amt;
                    item.totalTax += amt;
                }

                item.totalWithTax = item.totalAfterDisAndCharges + item.totalTax;
                data.tableNo = (data.table_no) ? data.table_no : undefined;
                data.subtotal += item.total;
                data.discount += item.discounted_price;
                data.totalChargesAmt += totalChargesAmt;
                data.totalTax += item.totalTax;
            }

            for (var taxName in taxes) {
                taxes[taxName] = +taxes[taxName].toFixed(2);
            }
            data.charges = _self.getAllCharges(items);
            data.saleOnCreditAmt = getSaleOnCreditAmt(data.payments)
            data.totalWithoutTax = data.subtotal;

            data.discounted_subtotal = data.subtotal - data.discount;
            data.subtotal = data.subtotal - data.discount;
            data.tax_exclusive_subtotal = data.subtotal; //redundant variable tax_exclusive_subtotal
            data.total = data.discounted_subtotal + data.totalChargesAmt + data.totalTax;
            var totalBeforeRoundOff = data.total;
            var total = ROUNDOFFNUMBER(totalBeforeRoundOff);
            data.addedRoundOffValue = total - totalBeforeRoundOff;

            var totalPaid = commonLib.getTotalPaidForReprint(data.payments, true);

            if (data.deliveryCharge > 0) {
                data.total += data.deliveryCharge;
            }

            data.amount_due = ROUNDOFFNUMBER(data.total) - totalPaid;
            data.amount_change = -1 * data.amount_due;
            data.total = ROUNDOFFNUMBER(data.total);
            data.discount = +data.discount.toFixed(2);

            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                item.discounted_total = item.discounted_total;
                item.discounted_price = +item.discounted_price.toFixed(2);
            }
            return data;
        }

        //BMTodo Danger Danger decisions and caluclations are done second time. Use the functions written while sale         
        function compute(data) {
            let cloneCart = CLONE(data.cart);
            //The order of the call is important don't change it
            //it was done for spot discount .. in cart computation we should not add global discount and in total summary we have to add it
            computeReprintCart(cloneCart, data);
            let tempData = computeReprintCart(data.cart, undefined, 0);
            //total without spot discount
            data.totalNoSpotDiscount = tempData.total;
            if (data.globalDiscountInfo && data.globalDiscountInfo.discountMethod === 'onTotal') {
                data.discount = tempData.discount + (data.totalNoSpotDiscount - data.total) + data.deliveryCharge;
            }
        }

        var data = getEmptyDataJson();

        var itemTaxes = [];
        var saleDetails = {};
        var info = {};

        return couchDBUtils.getTransDoc(params.saleId, mainDBInstance).then(function(resp) {

            if (!resp || resp.statusCode === -1) {
                var msg = {};
                msg.message = 'Sale Id Not Found';
                logger.error('Sale Id Not Found');
                return Promise.reject(msg);
            }
            saleDetails = resp;
            info = saleDetails.sales_info ? saleDetails.sales_info : saleDetails.info;

            var props = {};
            var customerId = resp.sales_info ? resp.sales_info.customer_id : resp.info.customer_id;
            if (customerId) {
                props.customerInfo = couchDBUtils.getDoc('customer_' + customerId, mainDBInstance);
            }
            if (info && info.num) {
                data.num = info.invoicePrefix + info.num;
            }

            if (resp.sales_info) {
                props.bHomeDelivery = resp.sales_info.bHomeDelivery;
                props.deliveryCharge = resp.sales_info.deliveryCharge ? resp.sales_info.deliveryCharge : 0;
                if (props.bHomeDelivery) {
                    props.deliveryBoy = props.deliveryBoy;
                }
            };

            var empId = info.employee_id;
            props.employeeInfo = couchDBUtils.getDoc('org.couchdb.user:' + empId, couchDBUtils.getUserCouchDB());

            return BPromise.props(props);
        }).then(function(resp) {
            data.cart = saleDetails.sale_items ? saleDetails.sale_items : saleDetails.items;
            data.payments = saleDetails.payments;
            data.deliveryCharge = resp.deliveryCharge;

            var mrpTotal = 0;
            for (var k in data.cart) {
                mrpTotal += data.cart[k].mrp * data.cart[k].quantity_purchased;
            }
            data.mrpTotal = mrpTotal;
            if (resp.bHomeDelivery) {
                data.deliveryBoy = resp.deliveryBoy;
                data.bHomeDelivery = resp.bHomeDelivery;
            }

            if (saleDetails.sales_info) {
                data.globalDiscountInfo = saleDetails.sales_info.globalDiscountInfo;
            }
            if (saleDetails.sales_info && saleDetails.sales_info.checkNo) {
                data.cheQueNo = saleDetails.sales_info.checkNo;
            }
            if (saleDetails.sales_info && saleDetails.sales_info.vehicle_phNo) {
                data.vehicle_phNo = saleDetails.sales_info.vehicle_phNo;
            }
            if (saleDetails.sales_info && saleDetails.sales_info.vehicleNo) {
                data.vehicleNo = saleDetails.sales_info.vehicleNo;
            }
            compute(data);
            addInfoForPrint(saleDetails, data, resp.customerInfo, resp.employeeInfo); //employee customer shop details

            data.payment_options = {};
            for (let i = 0; i < applicationSettings.paymentTerms.value.length; i++) {
                data.payment_options[applicationSettings.paymentTerms.value[i]] = applicationSettings.paymentTerms.value[i];
            }
            data.payment_options['Purchase On Credit'] = 'Purchase On Credit';

            return data;
        }).catch(function(err) {
            logger.error(err);
            return Promise.reject(err);
        });

    };

    foo.setTempDetails = function(params) {
        for (var key in params) {
            session.salesTempInfo[key] = params[key];
        }
    };

    foo.getTempDetails = function(output) {
        for (var key in session.salesTempInfo) {
            output[key] = session.salesTempInfo[key];
        }

        if (output.sale_time) {
            output.sale_time = moment(output.sale_time).local().format(); //moment(tempDetails.sale_time).format('DD/MM/YYYY,hh:mm:ss');
        }
    }

    foo.clearTempDetails = function() {
        for (var key in session.salesTempInfo) {
            session.salesTempInfo[key] = null;
        }
    };

    foo.calculateQuantity = function(cart) {
        var quantity = 0;
        for (var i = 0; i < cart.length; i++) {
            quantity = quantity + (cart[i].quantity);
        }
        return quantity;
    }
    foo.redeemLoyalty = function(payment_type, amount) {
        let cus = _self.getCartCustomerDetails();
        if (!cus.person_id) {
            throw "No customer seleted!";
        }
        if (!cus.loyaltyPnts) {
            throw "No loyalty points"
        } else {
            let loyaltyPnts = cus.loyaltyPnts;
            let oldRedeemed = _self.getLoyaltyRedeemed();
            if (oldRedeemed) {
                loyaltyPnts += oldRedeemed;
            }
            let oldEarned = _self.getLoyaltyEarned();
            if (oldEarned) {
                loyaltyPnts -= oldEarned;
            }
            logger.info("*** Redeeming sale amount " + amount + " customer pnt is " + loyaltyPnts);
            let redeemMoney = saleEx.getLoyaltyAmt(loyaltyPnts);
            if (redeemMoney >= amount) {
                _self.add_payment(payment_type, amount);
            } else {
                logger.error("Redeeming sale amount " + amount + " customer " + cus.loyaltyPnts + " oldrm " + oldRedeemed + " oldearned " + oldEarned);
                throw "Insufficient loyalty";
            }
        }
        let oldRedeemedMoney = _self.getRedeemMoney();
        if (oldRedeemedMoney) {
            amount += oldRedeemedMoney;
            logger.info("The total money redeemed is " + amount);
        }
        _self.setRedeemMoney(amount);
    }
    foo.compareCustomer = function() {
        let customer = _self.get_customer();
        let oldCusId = _self.getCusB4Edit();
        return customer === oldCusId;
    }

    return foo;
};