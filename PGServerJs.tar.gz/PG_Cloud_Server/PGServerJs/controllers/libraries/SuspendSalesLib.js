var BPromise = require("bluebird");
const moment = require('moment');
var logger = require('../../common/Logger');
var status = require('../../common/StatusCode');

const couchDBUtils = require('../common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();

var SuspendSalesLib = function() {

    var _self = this;

    this.getCartItems = function(cart) {
        let saleItems = [];
        for (let i = 0; i < cart.length; i++) {
            let item = cart[i];
            saleItems.push({
                item_id: item.item_id,
                batchId: item.batchId,
                stockKey: item.stockKey,
                name: item.name,
                line: item.line,
                description: item.description,
                serialnumber: item.serialnumber,
                imeiNumbers: item.imeiNumbers,
                isNew: item.isNew,
                quantity_purchased: item.quantity,
                discount_percent: item.discount,
                sellingPrice: item.price,
                purchasePrice: item.purchasePrice,
                mrp: item.mrp,
                item_location: item.item_location,
                discounted_total: item.discounted_total,
                totalWithTax: item.totalWithTax
            });
        }

        return saleItems;
    };

    this.saveSuspendSaleExt = async function(cart, customerId, customer, employee, employeeId, comment, invoiceNo, payments, saleTime, isKOT) {
        let timeStamp = saleTime ? moment(saleTime).format('x') : moment().format('x');

        function getInfo() {
            return {
                sale_time: timeStamp,
                customer_id: customerId,
                customer: customer,
                employee_id: employeeId,
                employee: employee,
                comment: comment,
                sale_id: timeStamp,
                isKOT: isKOT
            };
        }

        if (cart.length === 0) {
            return -1;
        }

        if (customerId === -1) {
            customerId = null;
            customer = '';
        }

        let doc = {
            _id: 'suspendedSale_' + timeStamp
        };
        doc.sales_info = getInfo();
        doc.payments = payments;
        doc.sales_items = _self.getCartItems(cart);

        try {
            await couchDBUtils.create(doc, mainDBInstance, 'Suspend Sale Failed. Try Again');
            return {
                sale_id: timeStamp
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }

    };

    /**
     *      Todo: otg_price missing
     */
    this.getJson4Couch = function(saleTime, customerId, cart) {
        var kotInfo = {
            sale_time: saleTime,
            customer_id: customerId,
            kot_items: [],
            KOT_bill: 0,
            tax_k_bill:0
        };

        for (var i = 0; i < cart.length; i++) {
            var item = cart[i];
            var itemData = {
                'item_id': item.item_id,
                'name': item.name,
                'skuName': item.skuName,
                'quantity_purchased': item.quantity,
                'item_unit_price': item.price,
                'item_total': item.totalWithTax, //for get order bill
                'description': item.description,
                'categoryId': item.categoryId,
                'purchasePrice': item.purchasePrice,
                'unit': item.unit
            };
            kotInfo.KOT_bill += item.totalWithTax;
            kotInfo.tax_k_bill += item.total;
            kotInfo.kot_items.push(itemData);
        }

        return kotInfo;
    };

    this.deleteExt = async function(saleId) {
        try {
            await couchDBUtils.delete({
                _id: 'suspendedSale_' + saleId
            }, mainDBInstance, 3, 'Failed to remove Suspeded Sale');
        } catch (error) {
            logger.error(error);
            throw error;
        }
    };

    this.getAll = async function() {
        try {
            let queryResponse = await couchDBUtils.getAllDocsByType('suspendedSale', mainDBInstance);
            let allSuspendedSales = [];
            for (let i = 0; i < queryResponse.length; i++) {
                if (!queryResponse[i].doc.sales_info.isKOT)
                    allSuspendedSales.push(queryResponse[i].doc.sales_info);
            }

            return allSuspendedSales;
        } catch (error) {
            logger.error(error);
            throw error;
        }
    };

    /**
     *      saleId takes integer or array of integers: 4 or [5. 9, 7, 3]
     */

    this.getItems = async function(saleIdArray) {
        let response = {};
        let promisesArray = [];
        let tempSaleIdArray = [];
        for (let i = 0; i < saleIdArray.length; i++) {
            tempSaleIdArray.push("suspendedSale_" + saleIdArray[i]);
        }
        try {
            let resp = await couchDBUtils.getAllDocs(tempSaleIdArray, mainDBInstance);
            for (let i = 0; i < saleIdArray.length; i++) {
                if (resp[i].error === 'not found') {
                    logger.error(resp[i]);
                    throw 'Internal Error';
                }

                response[saleIdArray[i]] = resp[i];
            }
            return response;
        } catch (error) {
            logger(error);
            throw error;
        }
    }

    this.setCustomer = async function(saleIdArray, customerId) {
        try {
            let response = {
                status: status.ERR_UNDEFINED
            }
            customerId = customerId === undefined ? null : customerId;
            let data = {
                customer_id: customerId
            };

            let promisesArray = [];
            for (let i = 0; i < saleIdArray.length; i++) {
                let resp = promisesArray.push(couchDBUtils.updateHandler('suspendedSale_' + saleIdArray[i], data, mainDBInstance, 'update_customer', "failed to update customer id "));
            }
            await Promise.all(promisesArray);
            logger.silly("customer id  successfully updated for sales ID: " + data.customer_id);
            response.status = status.SUCCESS;
            return response;
        } catch (error) {
            logger.error(error);
            return response;
        }
    }

};

module.exports = new SuspendSalesLib();