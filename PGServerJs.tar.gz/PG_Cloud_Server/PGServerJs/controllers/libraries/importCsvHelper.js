let importHelpCtrl = function() {

    this.checkBooleanType = function(data) {

        console.log("inside checkBooleanType method");
        if (data.toLowerCase() === "true" || data.toLowerCase() === "false" ||
            data.toLowerCase() === "no" || data.toLowerCase() === "yes") {
            return true;
        }
        return false;
    };

    this.checkNumberType = function(data) {

        data = parseInt(data);
        console.log("inside checkNumberType method");
        if (isNaN(data)) {
            return false;
        }
        return true;
    };

    this.checkBlankOrHypen = function(data) {

        console.log("checkBlankOrHypen");
        if (data === '-' || data === '' || data === ' ') {
            return true;
        }
        return false;
    }
    this.checkErrorType = function(data) {

        if (this.checkBlankOrHypen(data)) {
            return "is empty string or hypen";
        } else if (this.checkBooleanType(data)) {
            return "is type of boolean";
        }

    };

    this.priceCondition = function(item) {

        let pp = parseInt(item["Purchase Price"]);
        let sp = parseInt(item["Selling Price"]);
        let mrp = parseInt(item["MRP"]);
        if (pp > sp) {
            return false;
        } else if (mrp < sp) {
            return false;
        }
        return true;

    }

    this.inclusivePriceAndSlabCondition = function(item) {

        if (item["PP Tax Inclusive"].toLowerCase() == "yes" && item["SP Tax Inclusive"].toLowerCase() == "yes") {

            if (!this.checkBlankOrHypen(item["Slab"])) {
                return false;
            }
        }
        return true;
    }

    this.gstAndSlabCondition = function(item) {
        if (!this.checkBlankOrHypen(item["GST Purchase Taxes%"]) && !this.checkBlankOrHypen(item["GST Sales Taxes%"])) {

            if (!this.checkBlankOrHypen(item["Slab"])) {
                return false;
            }
        }
        return true;
    }

    this.setDefaultFields = function(pgItem) {
        //is_serialized
        pgItem.is_serialized = pgItem.is_serialized ? pgItem.is_serialized : false;

        //receiving_quantity 
        pgItem.receiving_quantity = pgItem.receiving_quantity ? pgItem.receiving_quantity : 0;

        //reorder_level 
        pgItem.reorder_level = pgItem.reorder_level ? pgItem.reorder_level : 0;

        //expiry_date
        pgItem.expiry_date = pgItem.expiry_date ? pgItem.expiry_date : "";

        // allow_alt_description
        pgItem.allow_alt_description = "0";

        //ItemType
        pgItem.ItemType = pgItem.ItemType ? pgItem.ItemType : "";

        //purchasePrice 
        pgItem.purchasePrice = pgItem.purchasePrice ? pgItem.purchasePrice : "";

        //sellingPrice
        pgItem.sellingPrice = pgItem.sellingPrice ? pgItem.sellingPrice : "";

        //mrp
        pgItem.mrp = pgItem.mrp ? pgItem.mrp : "",

            // isNewBatch 
            pgItem.isNewBatch = false;

        //hasMeasurementUnit 
        pgItem.hasMeasurementUnit = false;

        //imeiCount 
        pgItem.imeiCount = pgItem.imeiCount ? pgItem.imeiCount : 0;

        //imeNumbers 
        pgItem.imeNumbers = [];

        // density
        pgItem.density = 0;

        // pricingProfiles 
        pgItem.pricingProfiles = false;

        // multipleUnits
        pgItem.multipleUnits = false;

        // itemNprice 
        pgItem.itemNprice = 0;

        // purchaseUnitId 
        pgItem.purchaseUnitId = 0;

        // sellingUnitId 
        pgItem.sellingUnitId = 0;

        // isprepared 
        pgItem.isprepared = false;

        // issellable 
        pgItem.issellable = false;

        // isbought 
        pgItem.isbought = false;

        // is_deleted
        pgItem.is_deleted = "";

        // discount_expiry 
        pgItem.discount_expiry = null;

        // employeeId 
        pgItem.employeeId = "admin";
    }
};

module.exports = new importHelpCtrl();