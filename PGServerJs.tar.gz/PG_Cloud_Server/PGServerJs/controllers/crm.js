"use strict";
/**
 * import/export -> variable/function/interface/class
 *
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const couchDBUtils = require("./common/CouchDBUtils");
const schedular = require("./libraries/scheduler");
const couchMain = require("../couchDb/couchDBMain.js");
const follow = require("follow");
const moment = require("moment");
const logger = require("../common/Logger");
const scheduleCampaignHelper_1 = require("./libraries/scheduleCampaignHelper");
const mainDBInstance = couchDBUtils.getMainCouchDB();
const licenceDBInstance = couchDBUtils.getLicenceDB();
const salesEx = require("../TSControllers/SalesEx");
const Utils_1 = require("../common/Utils");
const Utils_2 = require("../controllers/common/Utils");
exports.COMPLETED = 'completed';
exports.PENDING = 'pending';
exports.FAILED = 'failed';
exports.WISHER = 'wisher';
exports.AUTOREPORTER = 'autoreporter';
const VISIT_PREFIX = 'visit';
const CRM_TEMPLATE_PREFIX = 'ct';
exports.createCampaign = function (data) {
    let ts = moment().format('x');
    data._id = 'cmp_' + ts;
    if (!data.eventDateTime) {
        throw 'EventDateTime is Mandatory.';
    }
    data.eventDateTime = moment(data.eventDateTime).format('x');
    return exports.create(data);
};
exports.create = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        let response = {};
        //console.log(JSON.stringify(data, null, 2));
        try {
            let dataArray = [];
            let { templateType, template, bUpdate } = prepareTemplateDoc(data);
            //to create/update document
            if (bUpdate) {
                data.templateType = templateType;
                data.template = template;
                dataArray.push(data.templateType);
            }
            dataArray.push(data);
            yield couchDBUtils.bulkDocs(dataArray, mainDBInstance);
            schedular.startJob();
        }
        catch (error) {
            logger.error(error);
            response.error = 'campaign create failed';
            throw response;
        }
        response.msg = 'campaign create success';
        return response;
    });
};
exports.updateCampaign = function (data) {
    if (!data.eventDateTime) {
        throw 'EventDateTime is Mandatory.';
    }
    data.eventDateTime = moment(data.eventDateTime).format('x');
    return exports.update(data);
};
//campaign update
//todo allow to create/update templates from update campaign also
exports.update = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        let response = {};
        try {
            let { templateType, template, bUpdate } = prepareTemplateDoc(data);
            data.templateType = templateType;
            data.template = template;
            let dataArray = [];
            if (bUpdate) {
                //to create/update document
                dataArray.push(data.templateType);
            }
            dataArray.push(data);
            yield couchDBUtils.bulkDocs(dataArray, mainDBInstance);
        }
        catch (error) {
            logger.error(error);
            response.error = 'campaign update failed';
            throw response;
        }
        return response;
    });
};
exports.deleteCampaign = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        let response = {};
        try {
            yield couchDBUtils.delete(data, mainDBInstance);
        }
        catch (error) {
            response.error = 'campaign delete failed';
            throw response;
        }
        return response;
    });
};
function prepareTemplateDoc(data) {
    let ts = moment().format('x');
    let template = {
        "message": data.message,
        "bApproved": false,
        "modifiedTs": moment().format('x')
    };
    let templateType;
    let bUpdate = false;
    if (data.templateTypeName && data.isTemplate) { // add the new template
        templateType = {
            "name": data.templateTypeName,
            "templates": [template],
            "_id": CRM_TEMPLATE_PREFIX + '_' + ts,
            "iPendingCount": 1
        };
        bUpdate = true;
    }
    else if (data.templateType && data.isTemplate) { // update the template
        templateType = data.templateType;
        templateType.templates.push(template);
        bUpdate = true;
    }
    else {
        //no create/update is required
    }
    if (bUpdate) {
        logger.error('call sai. update not expected.');
        throw 'call sai';
    }
    return { templateType: templateType, template: template, bUpdate: bUpdate };
}
//Transaction has to be implemented. two different writes are happening 
exports.updateTemplateType = function (inputTemplateType) {
    return __awaiter(this, void 0, void 0, function* () {
        if (inputTemplateType._rev) {
            inputTemplateType.isUpdate = true;
        }
        else {
            let ts = moment().format('x');
            inputTemplateType._id = CRM_TEMPLATE_PREFIX + '_' + ts;
        }
        delete inputTemplateType.iPendingCount; //cheating variable use in UI to control edit of pending templates
        let clonedData = Utils_2.clone(inputTemplateType);
        getOnlyApprovedTemplates(clonedData);
        const iPendingCount = clonedData.iPendingCount;
        //The below is required. Because we are adding only approved templates in maindb
        let dataArr = [inputTemplateType, clonedData];
        let dbInstanceArr = [licenceDBInstance, mainDBInstance];
        let response = {};
        for (let i = 0; i < dbInstanceArr.length; i++) {
            let data = dataArr[i];
            if (data._rev) {
                delete data._rev; //we will fetch it
            }
            ;
            let db = dbInstanceArr[i];
            let bDocExist = false;
            if (data.isUpdate) {
                try {
                    let oldTemplate = yield couchDBUtils.getDocEx(data._id, db);
                    let errorsArr = [];
                    const bEqual = Utils_1.compareObject(data, oldTemplate, 0, ['_rev'], errorsArr, '');
                    if (bEqual) {
                        //already upto date
                        continue;
                    }
                    data._rev = oldTemplate._rev;
                    bDocExist = true;
                }
                catch (e) {
                    // Template doesn't exists in db 
                }
            }
            if (!bDocExist && data._deleted) {
                //doc doesnt exist so no need to delete
                continue;
            }
            if (i === 0 && !data._deleted && iPendingCount === 0) {
                //licencedb, no pending approvals. So better delete it from licencedb
                data._deleted = true;
            }
            try {
                yield couchDBUtils.createOrUpdate(data, db);
                response.msg = 'Template Type Updated Successfully.';
            }
            catch (error) {
                logger.error(error);
                response.error = 'Template Type Update failed';
                throw response;
            }
        }
        return response;
    });
};
function getOnlyApprovedTemplates(data) {
    let templates = [];
    data.iPendingCount = 0;
    for (let i = 0; i < data.templates.length; i++) {
        if (data.templates[i].bApproved) {
            templates.push(data.templates[i]);
        }
        else {
            data.iPendingCount++;
        }
    }
    data.templates = templates;
}
function getUpdatedTransactions(data) {
    return __awaiter(this, void 0, void 0, function* () {
        let custKeys = [];
        data.customers.forEach(c => {
            custKeys.push(c._id);
        });
        let allCustomers = yield couchDBUtils.getAllDocs(custKeys, mainDBInstance);
        let customerDocs = [];
        let lytVisitPnts = salesEx.getVisitPnts();
        for (let i = 0; i < allCustomers.length; i++) {
            if (!allCustomers[i].doc || allCustomers[i].error) {
                throw allCustomers[i].error;
            }
            let ts = moment(data.date).format('x');
            let doc = allCustomers[i].doc;
            let date = new Date(parseInt(ts));
            let year = date.getFullYear();
            let month = date.getMonth();
            let key = year + '-' + month;
            if (!doc.stats) {
                doc.stats = {};
            }
            if (!doc.stats[key]) {
                doc.stats[key] = 0;
            }
            if (!doc.visitCount) {
                doc.visitCount = 0;
            }
            if (!doc.loyaltyPnts) {
                doc.loyaltyPnts = 0;
            }
            if (lytVisitPnts && !data._rev) {
                doc.loyaltyPnts += lytVisitPnts;
            }
            if (data.deleted === "1" && doc.loyaltyPnts > lytVisitPnts) {
                doc.loyaltyPnts -= lytVisitPnts;
            }
            if (data.redeem) { // Loyalty redeemed
                if (doc.loyaltyPnts >= data.redeem) {
                    doc.loyaltyPnts -= data.redeem;
                }
                else {
                    doc.loyaltyPnts = 0;
                }
            }
            doc.stats[key]++;
            doc.visitCount++;
            doc.lastTS = ts;
            doc.total += data.total;
            customerDocs.push(doc);
        }
        return customerDocs;
    });
}
exports.visit = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        // console.log("*** crm.visit" + JSON.stringify(data));
        let bUpdate = false;
        let response = {};
        if (data._rev) {
            bUpdate = true;
        }
        let ts = moment().format('x');
        if (!bUpdate) {
            data._id = VISIT_PREFIX + '_' + ts;
        }
        let dataArray = [];
        dataArray.push(data);
        let customerDocs = [];
        customerDocs = yield getUpdatedTransactions(data);
        if (!customerDocs.length) {
            console.log("*** No customers found");
            throw "No customers found";
        }
        dataArray = dataArray.concat(customerDocs);
        try {
            yield couchDBUtils.bulkDocs(dataArray, mainDBInstance);
            response.msg = 'Visit added successfully';
        }
        catch (error) {
            logger.error(error);
            response.error = 'Visit update failed';
            throw response;
        }
        return response;
    });
};
exports.createSchedule = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        let ts = moment().format('x');
        data._id = 'schedule_' + ts;
        if (!data.timeOfDayArr.length) {
            throw 'Time is Mandatory.';
        }
        scheduleCampaignHelper_1.generateSchedules(data);
        return exports.create(data);
    });
};
exports.updateSchedule = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!data.timeOfDayArr) {
            throw 'Time is Mandatory.';
        }
        return exports.update(data);
    });
};
exports.saveWisher = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        let ts = moment().format('x');
        if (!data.timeOfDayArr.length) {
            throw 'Time is Mandatory.';
        }
        if (!data._rev) {
            data._id = exports.WISHER + '_' + ts;
            return exports.create(data);
        }
        return exports.update(data);
    });
};
// export let updateDNDArr = async function (data: DNDArr): Promise<apiResponse> {
//     let response: apiResponse = {} as apiResponse;
//     try {
//         let res = await couchDBUtils.createOrUpdate(data, mainDBInstance);
//         console.log(res);
//         response.msg = 'DND list updated successfully';
//         response.data = res;
//     } catch (e) {
//         logger.error(e);
//         response.error = 'DND list updated failed';
//         throw response;
//     }
//     return response;
// }
let checkTemplate = function (template) {
    return __awaiter(this, void 0, void 0, function* () {
        logger.silly("Got template for approve" + JSON.stringify(template));
        // create the same document in mainDb and delete the apply doc  
        let clonedData = Utils_2.clone(template);
        //because we are adding only approved templates in maindb
        getOnlyApprovedTemplates(clonedData);
        try {
            let oldTemplate = yield couchDBUtils.getDoc(clonedData._id, mainDBInstance, 'propagate'); //this doesn't throw error!
            let errorsArr = [];
            const bEqual = Utils_1.compareObject(clonedData, oldTemplate, 0, ['_rev'], errorsArr, '');
            if (bEqual) {
                //already upto date
                return;
            }
            clonedData._rev = oldTemplate._rev;
            //update in the existing template
        }
        catch (error) {
        }
        try {
            yield couchDBUtils.createOrUpdate(clonedData, mainDBInstance);
        }
        catch (e) {
            logger.error(e);
            logger.error("Template update failed in maindb. ");
            return;
        }
        let bApproved = true;
        for (let i = 0; i < template.templates.length; i++) {
            if (!template.templates[i].bApproved) {
                bApproved = false;
            }
        }
        if (!bApproved) {
            //no need to delete yet because pending templates are still available
            return;
        }
        try {
            yield couchDBUtils.delete(template, licenceDBInstance);
        }
        catch (error) {
            logger.error(error);
            logger.error('Template update in licencedb failed.');
        }
    });
};
function listenToChanges() {
    return __awaiter(this, void 0, void 0, function* () {
        logger.info("listenToChanges.crm.ts");
        let count = 0;
        follow({
            db: couchMain.getLicencedbUrl(),
            include_docs: true,
            filter: function (doc, req) {
                var doctype, uidx;
                if (doc._id && (uidx = doc._id.indexOf('_')) > 0) {
                    doctype = doc._id.substring(0, uidx);
                    if (doctype === 'ct') {
                        return true;
                    }
                }
                return false;
            },
            since: 'now'
        }, function (error, change) {
            if (!error) {
                count++;
                setTimeout(function () {
                    count--;
                    if (count === 0) {
                        //handle delete
                        if (change.deleted) {
                            //deleted do nothing
                        }
                        else {
                            checkTemplate(change.doc);
                        }
                    }
                }, 1000);
            }
        });
    });
}
listenToChanges();
//# sourceMappingURL=crm.js.map