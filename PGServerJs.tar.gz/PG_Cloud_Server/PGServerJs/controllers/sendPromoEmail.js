//To Do: Add email-template and nodemailer in package.json

var EmailTemplate = require('email-templates').EmailTemplate;
var nodemailer = require('nodemailer');
var path = require('path');
const moment = require('moment');
var templateDir = path.resolve(__dirname, '../templates');
var template = new EmailTemplate(path.join(templateDir, 'promoEmailTemplate'));
var configState = require('../common/configState');

//function to send email to customer
var sendMailToCustomer = function(requestData, response) {
    let appSettings = configState.getApplicationSettings();
    return new Promise(function(resolve, reject) {
        //3. sender's credentials -- This should also come from app config file
        var credentials = {
            service: 'gmail',
            auth: {
                user: appSettings.ownersInfo.email, // 'profitguruhelpdesk@gmail.com',
                pass: appSettings.ownersInfo.emailPassword // 'wearethebest'
            }
        };

        //define nodemailer transporter with the credentials
        var transporter = nodemailer.createTransport(credentials);

        //variable to store emailId
        var custEmailId = requestData.email;

        // ToDo:
        // This data will come in requestData argument. Need to read data and populate it template.
        // Template needs to be finalized.
        var locals = {
            message: requestData.message,
            date: moment()
        };
        setTimeout(() => {
            console.log('1 seconds Timer expired!!!');
            resolve();
        }, 1000);
        template.render(locals, function(err, results) {
            if (err) {
                console.log(err);
                reject(err);
            }
            // ToDo : This mail options needs to be read from app config file
            var mailOptions = {
                from: '"ProfitGuru POS" <' + appSettings.ownersInfo.email + '>', // sender address
                to: custEmailId, // list of receivers
                subject: requestData.subject,
                html: results.html,
                text: results.text,
            };

            transporter.sendMail(mailOptions, function(err, responseStatus) {
                if (err) {
                    console.error(err);
                    reject(err);
                };
                console.log(responseStatus);
                resolve(responseStatus);
            });
        });
    });
}

module.exports = function(requestData, resposne) {
    return sendMailToCustomer(requestData, resposne);
};