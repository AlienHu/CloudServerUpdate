"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const couchDBUtils = require("./common/CouchDBUtils");
const mainDBInstance = couchDBUtils.getMainCouchDB();
const logger = require("../common/Logger");
const LOYALTY_ID = 'loyalty';
const moment = require("moment");
let loyalty;
exports.save = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        logger.info("*** loyalty.save " + JSON.stringify(data, null, 2));
        let response = {};
        if (!data._rev) {
            data._id = LOYALTY_ID;
        }
        if (data.startDate) {
            data.startDate = moment(data.startDate).startOf('day').format('x');
        }
        if (data.endDate) {
            data.endDate = moment(data.endDate).endOf('day').format('x');
        }
        if (data.redeemRule) {
            data.redeemRule.point = 1;
        }
        try {
            yield couchDBUtils.createOrUpdate(data, mainDBInstance);
            exports.setLoyalty(data);
            // loyalty = data;
        }
        catch (error) {
            logger.error(error);
            response.error = 'Loyalty save failed';
            throw response;
        }
        response.msg = 'Loyalty save success';
        return response;
    });
};
exports.get = function () {
    return __awaiter(this, void 0, void 0, function* () {
        logger.info("*** loyalty.get ");
        let doc;
        let response = {};
        try {
            doc = yield couchDBUtils.getDocEx(LOYALTY_ID, mainDBInstance);
            // loyalty = doc;
            exports.setLoyalty(doc);
        }
        catch (error) {
            response.error = 'Loyalty get failed';
            throw response;
        }
        return doc;
    });
};
exports.deleteLyty = function (data) {
    return __awaiter(this, void 0, void 0, function* () {
        logger.info("*** loyalty.deleteLyty " + JSON.stringify(data, null, 2));
        let response = {};
        try {
            yield couchDBUtils.delete(data, mainDBInstance);
        }
        catch (error) {
            response.error = 'Loyalty delete failed';
            throw response;
        }
        return response;
    });
};
exports.setLoyalty = function (data) {
    loyalty = data;
};
exports.getLoyalty = function () {
    return loyalty;
};
exports.get().then(function () {
    logger.info("Loyalty get success");
}).catch(function (error) {
    logger.info("Loyalty get failed!");
});
//# sourceMappingURL=loyalty.js.map