//var request = require('request');
var request = require('superagent');
require('superagent-as-promised')(request);
var _self;

var Licence = function() {
    _self = this;
    var licenceHelper = require('../licencer/licenceHelper.js');
    var commonUtils = require('../licencer/licenceCommon.js');

    this.getAllClientsList = function(req, res) {
        res.send(licenceHelper.getAllClientsList());
        res.end();
    };

    this.provisionClientAccess = function(req, res) {

        try {
            if (typeof req.body.clientId != "undefined" && typeof req.body.validity != "undefined") {
                var appType = req.body.appType === undefined ? process.env.APP_TYPE : req.body.appType;
                var response = {};
                var isLocalHostClient = commonUtils.isLocalHostClient(req);
                licenceHelper.provisionLicence(appType, req.body.clientId, req.body.validity, isLocalHostClient).then(function(provisnResp) {
                    if (provisnResp.hasAlreadyProvisioned) {
                        response.success = 'Licence Already provisioned ';
                    } else if (provisnResp.isProvisioned) {
                        licenceHelper.prepareAuthorizedClientMap(appType);
                        response.success = 'Licence succesfully provisioned';

                    } else {
                        response.error = 'Could not provision the licence';
                    }
                    res.json(response);
                    res.end();

                });
            } else {
                res.json('{res:Client has not yet applied for Licence}');
                res.end();
            }

        } catch (e) {
            res.json('{res:error}');
            res.end();
        }

    };

    this.grantClientAccess = function(req, res) {
        try {
            var message = req.body.grantAccess ? 'grant' : 'revoke';
            if (typeof req.body.clientId != "undefined" || typeof req.body.validity != "undefined") {
                var appType = req.body.appType === undefined ? process.env.APP_TYPE : req.body.appType;
                var response = {};
                licenceHelper.allowAccess2client(appType, req.body.clientId, req.body.validity, req.body.grantAccess).then(function(grantResp) {
                    if (grantResp.isAccessAllowed && req.body.grantAccess) {
                        licenceHelper.prepareAuthorizedClientMap(appType);
                        response.success = 'Access Granted Successfully ';
                        res.json(response);
                    } else if (!grantResp.isAccessAllowed && !req.body.grantAccess) {
                        licenceHelper.prepareAuthorizedClientMap(appType);
                        response.success = 'Access Revoked Successfully ';
                        res.json(response);
                    } else {

                        res.send(new Error('Failed to' + message + 'Access'));
                    }
                    res.end();

                });
            } else {
                res.send(new Error("Invalid request data"));
                res.end();
            }

        } catch (e) {
            res.send(new Error("Failed to " + message + " Access"));
            res.end();
        }

    };

    this.apply4Licence = function(req, res) {
        var deviceJson = {};
        var resResult = {
            error: 'Unknown app type'
        };
        try {
            var licenceSeed = req.body.params;
            var appType = licenceSeed.appType;
            //var clientType = licenceSeed.clientType;
            var clientType = req.clientType;

            if (commonUtils.isValidClientAppName(appType)) {

                if (clientType == "MobileApp") {
                    deviceJson = licenceSeed.device;
                } else if (clientType == "DeskTopApp") {
                    deviceJson = licenceSeed;
                } else {
                    res.json(resResult);
                    res.end();
                }

                var isLocalHostClient = commonUtils.isLocalHostClient(req);
                commonUtils.getClientMacAddress(req, clientType).then(function(clientMac) {
                    licenceHelper.apply4Licence(clientMac, appType, deviceJson, clientType, isLocalHostClient, licenceSeed.isTrial).then(function(applyResult) {
                        if (applyResult.isApplied) {
                            licenceHelper.prepareAppliedClientMap(appType);
                            res.json(applyResult);
                        } else {
                            res.json(applyResult);
                        }
                        res.end();
                    }).catch(function(reason) {
                        resResult.error = reason;
                        res.json(resResult);
                        res.end();
                    });
                });
            } else {
                res.send({
                    error: "Invalid clientType/AppName"
                });
                res.end();
            }

        } catch (e) {
            resResult.error = JSON.stringify(e);
            res.json(resResult);
            res.end();
        }

    };

    //TODO BK 
    //Only distributors or profitGuru team should be able to access this api

    this.signAndPermitProfitGuruLicense = function(req, res) {
        var appType = req.query.appType === undefined ? process.env.APP_TYPE : req.query.appType;
        var profitGuruLicenceParams = {
            clientId: req.query.clientId,
            validity: req.query.validity,
            appType: appType
        };

        var thisServerUrl = 'http://localhost:' + req.app.get('port');
        return request.post(thisServerUrl + '/licence/provisionClientAccess').send(profitGuruLicenceParams).then(function() {
            res.json('Signed  ProfitGuru Licence');
            res.end();
        }).catch(function(reason) {
            console.log(reason);
            throw new Error(reason);
        });
    };

    var bonjourService = require('../common/bonjourServer.js');

    this.pingtestApi = function(req, res) {
        if (req.query.restart) {
            res.send({
                'message': 'success'
            });
            res.end();

            process.exit(0);
        }

        try {
            var appType = process.env.APP_TYPE;
            console.log("pingtestApi request from host:" + req.headers.host);
            if (commonUtils.isValidClientAppName(appType)) {
                res.send(bonjourService.getBonjourServiceDetails());
                res.end();

            } else {
                res.send(false);
                res.end();
            }
        } catch (ex) {
            console.log("pingtestApi exception:" + ex)
        }
    };

    this.amILicenced = function(req, res) {

        var appType = process.env.APP_TYPE;

        if (commonUtils.isValidClientAppName(appType)) {
            commonUtils.getClientMacAddress(req).then(function(macAddress) {
                var licenceStatus = licenceHelper.amIAuthorized2Connect(process.env.APP_TYPE, macAddress);
                res.json(licenceStatus);
                res.end();
            }).catch(function(reason) {
                res.send(new Error(reason));
                res.end();
            });
        } else {
            res.send(new Error('Not a valid  appType' + appType));
            res.end();
        }

    };

    this.requestTrialLicence = function(req, res) {

        //TODO, Verify whether the client has had alreay applied?
        //a) Is to verify in applied documents and should not be given trial access again
        //b) Need to double check this with some extrenal means like verifying the 
        // registary etc on windows , and similar logic for linux's too 

        var clientDetails = req.body;
        clientDetails.clientType = req.clientType;

        var initResult = {
            hasApplied: false,
            isAuthorized: false,
            daysLeft4LicenceExpiry: -1

        };

        //Allowing all access on alienhu.com
        if (licenceHelper.isPrivateProfitGuruPosNodeSvc()) {

            if (commonUtils.isValidClientAppName(clientDetails.appType)) {
                commonUtils.getClientMacAddress(req).then(function(macAddress) {
                    var licenceStatus = licenceHelper.amIAuthorized2Connect(clientDetails.appType, clientDetails.clientId, macAddress, clientDetails.clientType);
                    if (!licenceStatus.hasApplied && commonUtils.isLocalHostClient(req, clientDetails.clientType)) {
                        var serverPort = req.app.get('port');

                        licenceHelper.genAndProvideTrialLicence(clientDetails.appType, serverPort).then(function(hasAppliedAndGivenTrial) {
                            if (hasAppliedAndGivenTrial) {
                                res.json({
                                    hasApplied: true,
                                    isAuthorized: true,
                                    daysLeft4LicenceExpiry: 15,
                                    isTrial: true,
                                    applicationSettings: req.app.locals.applicationSettings
                                });
                                res.end();
                            } else {
                                res.send(new Error('Could not provide Trial Licence ' + JSON.stringify(initResult)));
                                res.end();
                            }

                        }).catch(function(err) {
                            res.send(new Error(err + 'Could not provide Trial Licence ' + JSON.stringify(initResult)));
                            res.end();
                        });
                    } else {
                        licenceStatus.applicationSettings = req.app.locals.applicationSettings;
                        res.json(licenceStatus);
                        res.end();
                    }
                    // });
                }).catch(function(reason) {
                    res.send({
                        error: "Could not fetch Mac address:" + reason
                    });
                    res.end();
                });
            } else {
                res.send({
                    error: "Invalid clientType/AppName"
                });
                res.end();
            }
        } else {
            initResult.info = 'Not a PrivateProfitGuruPosNodeSvc';
            res.json(initResult);
            res.end();
        }
    };

    // username: only admin, admin_retail, admin_restaurant
    // put relevant settings in appsettingsjson
    async function checkIfUserIsDistributor(username) {
        if (!username || (username !== 'admin' && username !== 'admin_retail' && username !== 'admin_restaurant' && username !== 'admin_lodging' && username !== 'admin_petrolbunk' && username !== 'admin_pharmacy' && username !== 'admin_crm')) {
            return false;
        }
        const couchDBUtils = require('./common/CouchDBUtils');
        const userdb = couchDBUtils.getUserCouchDB();
        let user = await couchDBUtils.getDoc('org.couchdb.user:' + username, userdb, 'Failed to fetch the user document');
        if (user.isDistributor) {
            return true;
        }
        return false;
    }

    //TODO BK delete amIAuthorized2Connect / it should replaced by requestTrialLicence
    this.amIAuthorized2Connect = async function(req, res) {

        var appType = process.env.APP_TYPE;
        var m_allowAccess = false;
        var initResult = {
            hasApplied: false,
            isAuthorized: false,
            daysLeft4LicenceExpiry: -1,
            allowAccess: m_allowAccess

        };
        var bDistributor = await checkIfUserIsDistributor(req.query.username);
        //Allowing all access on alienhu.com
        if (licenceHelper.isPrivateProfitGuruPosNodeSvc()) {

            //  if (commonUtils.isValidClientAppName(appType)) {
            commonUtils.getClientMacAddress(req).then(function(macAddress) {
                var licenceStatus = licenceHelper.amIAuthorized2Connect(appType, macAddress);
                if (!licenceStatus.hasApplied && commonUtils.isLocalHostClient(req)) {
                    var serverPort = req.app.get('port');

                    licenceHelper.genAndProvideTrialLicence(appType, serverPort, bDistributor).then(function(hasAppliedAndGivenTrial) {
                        var allowAccess = false;
                        if (hasAppliedAndGivenTrial) {
                            if (commonUtils.isLocalHostClient(req)) {
                                m_allowAccess = true;
                            }
                            res.json({
                                hasApplied: true,
                                isAuthorized: true,
                                daysLeft4LicenceExpiry: bDistributor ? 15 : 7,
                                isTrial: true,
                                allowAccess: m_allowAccess,
                                applicationSettings: req.app.locals.applicationSettings
                            });
                            res.end();
                        } else {
                            res.send(new Error('Could not provide Trial Licence ' + JSON.stringify(initResult)));
                            res.end();
                        }

                    }).catch(function(err) {
                        res.send(new Error(err + 'Could not provide Trial Licence ' + JSON.stringify(initResult)));
                        res.end();
                    });
                } else {
                    licenceStatus.applicationSettings = req.app.locals.applicationSettings;
                    res.json(licenceStatus);
                    res.end();
                }
                // });
            }).catch(function(reason) {
                res.send({
                    error: "Could not fetch Mac address:" + reason
                });
                res.end();
            });
        } else {
            initResult.info = 'Not a PrivateProfitGuruPosNodeSvc';
            res.json(initResult);
            res.end();
        }
    }

    this.activationRequest = function(clientId) {
        var error = {};
        var appType = process.env.APP_TYPE; {
            try {
                var message = '';
                if (typeof clientId != "undefined") {

                    var response = {};
                    return licenceHelper.requestLicenceActivation(appType, clientId).then(function(grantResp) {

                        response.success = 'Licence activation requested successfully ';
                        return response;

                    });
                } else {

                    error.errResponse = new Error("Invalid request data");
                    return error;
                }

            } catch (e) {

                error.errResponse = new Error("Licence activation request failed");
                return error;
            }

        };
    }
}

module.exports = new Licence();