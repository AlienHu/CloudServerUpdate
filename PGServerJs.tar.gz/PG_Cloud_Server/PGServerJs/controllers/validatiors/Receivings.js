var Receivings = function() {
    var validator = require('validator');

    this.editItem = function(data) {
        let errMsg = '';
        var bIsValid = true;

        if (data.discountId) {
            if (validator.isNumeric(data.discountId + '')) {
                if (data.discountId === '0') {
                    delete data.discountId;
                }
            } else {
                errMsg += 'discount id should be numeric ';
                bIsValid = false;
            }
        }

        if (data.quantity === undefined || null) {
            errMsg += ' quantity is not defined';
            bIsValid = false;
        } else if (!validator.isFloat(data.quantity + '')) {
            errMsg += ' quantity should be numeric';
            bIsValid = false;
        }

        //previously sellingprice mrp purchaseprice validation was there.. it can be clientside only

        return {
            bIsValid: bIsValid,
            errMsg: errMsg
        };
    };

};

module.exports = new Receivings();