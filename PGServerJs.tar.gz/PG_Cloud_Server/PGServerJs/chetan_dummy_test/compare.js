"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const items_1 = require("./items");
const pouchItem_1 = require("./pouchItem");
let targetKeys = Object.keys(items_1.default);
let sourceKeys = Object.keys(pouchItem_1.default);
let directMatches = [];
let missingMatches = [];
for (let i = 0; i < targetKeys.length; i++) {
    let key = targetKeys[i];
    if (sourceKeys.indexOf(key) > -1) {
        directMatches.push(key);
    }
    else {
        missingMatches.push(key);
        console.log('You die <' + key + '>');
    }
}
const jsonfile = require("jsonfile");
jsonfile.writeFileSync('./directMatches.json', directMatches);
jsonfile.writeFileSync('./missingMatches.json', missingMatches);
console.log('Total Keys<' + targetKeys.length + '> Matched Keys<' + directMatches.length + '> Missed<' + missingMatches.length + '>');
//# sourceMappingURL=compare.js.map