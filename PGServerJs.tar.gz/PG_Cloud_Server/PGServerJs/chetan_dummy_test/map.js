let direct = [
    "item_id",
    "ItemType",
    "name",
    "item_number",
    "is_serialized",
    "hasBatchNumber",
    "bOTG",
    "hsn",
    "hasExpiryDate",
    "bSPTaxInclusive",
    "bPPTaxInclusive",
    "purchasePrice",
    "mrp",
    "imeiCount"
];
let directMap = [{
        price: "sellingPrice"
    }];
let defaults = {
    "description": "",
    "serialnumber": "",
    "imeiNumbers": [],
    "item_location": 1,
    "stock_name": "India"
};
let computations = function (ref, out) {
};
//# sourceMappingURL=map.js.map