var faker = require('faker');
faker.locale = 'en_IND';

const profitGuruFakerExt = require('./profitGuruFakerExt');

var foo = function() {
    var _self = this;

    /**
     * It can have taxes (GST, Cess), charges (Service Charge)
     * 
     * {
     *      name: 'AC Charges'
     *      description: 'Taxes and Charges for AC',
     *      taxes: [122323, 32311, 323323],
     *      slab: 1231312,
     *      charges: [123111]
     * }
     */
    this.getFakerProfile = async function() {

        let allTaxes = await profitGuruFakerExt.getConfigsFromDB('tax', true);
        let allSlabs = await profitGuruFakerExt.getConfigsFromDB('slab');
        let allCharges = await profitGuruFakerExt.getConfigsFromDB('charge');

        if (allTaxes.length < 2) {
            throw 'Create 2 Tax First';
        }

        if (allSlabs.length < 1) {
            throw 'Create 1 tax slab first';
        }

        if (allCharges.length < 1) {
            throw 'Create 1 charge first';
        }

        let noOfTaxes = faker.random.number({
            min: 1,
            max: allTaxes.length > 2 ? 2 : allTaxes.length
        });

        let profile = {
            name: faker.random.word(),
            description: faker.random.word(),
            normalTaxes: [],
            preparedTaxes: [],
            liquorTaxes: [],
            slab: faker.random.arrayElement(allSlabs),
            charges: []
        };

        for (let i = 0; i < noOfTaxes; i++) {
            profile.liquorTaxes.push(allTaxes[i]); //VAT, Cess
        }

        profile.preparedTaxes.push(allTaxes[0]); //GST 12/18
        profile.normalTaxes.push(allTaxes[1]); //GST 12

        profile.charges.push(faker.random.arrayElement(allCharges));

        return profile;
    };

    this.getFakerTaxSlab = function() {
        return {
            name: faker.random.word(),
            taxName: 'GST',
            rates: [{
                    min: 0,
                    max: 1000,
                    percent: faker.random.number({
                        min: 2.5,
                        max: 30
                    })
                },
                {
                    min: 1000,
                    max: 2000,
                    percent: faker.random.number({
                        min: 2.5,
                        max: 30
                    })
                },
                {
                    min: 2000,
                    max: 9999999,
                    percent: faker.random.number({
                        min: 2.5,
                        max: 30
                    })
                }
            ]
        };
    };

    this.getFakerCharge = function() {
        return {
            name: 'Service Charge',
            percent: faker.random.number({
                min: 2,
                max: 20
            })
        };
    };

};

module.exports = new foo();