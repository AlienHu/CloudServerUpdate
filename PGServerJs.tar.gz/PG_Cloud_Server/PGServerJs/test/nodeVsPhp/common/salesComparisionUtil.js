require('dotenv-safe').load();
var commonNodeVsPhp = require('./commonUtilNodeVsPhp.js');
var chaiAsPromised = require("chai-as-promised");
var chai = require("chai");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;

var salesComparisionUtils = function() {
    var itemList;
    this.setDbItemList = function(allItem) {
        itemList = allItem;
    };

    this.nodeCancelSaleOrClearCart = function() {

        return commonNodeVsPhp.nodeAuthenticatedRequest().then(function(nodeAuthenticatedRequest) {
            return nodeAuthenticatedRequest
                .post('/sales/cancel_saleRestApi')
                .expect(200).then(function(resp) {
                    return Promise.resolve(resp.body);
                });
        });
    };

    this.phpCancelSaleOrClearCart = function() {
        return commonNodeVsPhp.phpAuthenticatedRequest().then(function(phpAuthenticatedRequest) {
            return phpAuthenticatedRequest
                .get('/profitGuruRestSvc_retail/index.php/sales/cancel_saleRestApi')
                .expect(200).then(function(resp) {
                    var result = JSON.parse(resp.text);
                    return Promise.resolve(result.data);

                });
        });
    }

    this.nodeAddItem2Cart = function(item2Add) {
        // var defaultItem = {
        //     item: itemList[0].dataValues.item_id
        // };
        // item2Add = item2Add || defaultItem;

        return commonNodeVsPhp.nodeAuthenticatedRequest().then(function(nodeAuthenticatedRequest) {
            return nodeAuthenticatedRequest
                .post('/sales/cancel_saleRestApi')
                .expect(200).then(function() {
                    return nodeAuthenticatedRequest
                        .post('/sales/additemRestApi')
                        .send(item2Add)
                        .expect(200).then(function(resp) {
                            expect(resp.body.cart.length).to.equal(1);
                            return Promise.resolve(resp.body);
                        });
                });
        });
    };

    this.phpAddItem2Cart = function(item2Add) {
        // var defaultItem = {
        //     item: itemList[0].dataValues.item_id
        // };
        // item2Add = item2Add || defaultItem;

        return commonNodeVsPhp.phpAuthenticatedRequest().then(function(phpAuthenticatedRequest) {
            return phpAuthenticatedRequest
                .get('/profitGuruRestSvc_retail/index.php/sales/cancel_saleRestApi')
                .expect(200).then(function() {
                    //console.log('1', resp);
                    return phpAuthenticatedRequest
                        .get('/profitGuruRestSvc_retail/index.php/sales/additemRestApi')
                        .query(item2Add)
                        .expect(200).then(function(resp) {
                            //console.log('2', resp);
                            var result = JSON.parse(resp.text);
                            expect(result.data.cart.hasOwnProperty('1')).to.equal(true);
                            return Promise.resolve(result.data);
                        });
                });
        });
    };

    this.nodeAddItem2CartAndMakeSalesPayment = function(item2Add, paymentParams) {
        return commonNodeVsPhp.nodeAuthenticatedRequest().then(function(nodeAuthenticatedRequest) {
            return nodeAuthenticatedRequest
                .post('/sales/cancel_saleRestApi')
                .expect(200).then(function() {
                    return nodeAuthenticatedRequest
                        .post('/sales/additemRestApi')
                        .send(item2Add)
                        .expect(200).then(function(resp) {
                            expect(resp.body.cart.length).to.equal(1);
                            return nodeAuthenticatedRequest
                                .post('/sales/add_paymentRestApi')
                                .send(paymentParams)
                                .expect(200).then(function(resp) {
                                    return Promise.resolve(resp.body);
                                });
                        });
                });

        });

    };

    this.phpAddItem2CartAndMakeSalesPayment = function(item2Add, paymentParams) {

        return commonNodeVsPhp.phpAuthenticatedRequest().then(function(phpAuthenticatedRequest) {
            return phpAuthenticatedRequest
                .get('/profitGuruRestSvc_retail/index.php/sales/cancel_saleRestApi')
                .expect(200).then(function() {

                    return phpAuthenticatedRequest
                        .get('/profitGuruRestSvc_retail/index.php/sales/additemRestApi')
                        .query(item2Add)
                        .expect(200).then(function(resp) {

                            var result = JSON.parse(resp.text);
                            expect(result.data.cart.hasOwnProperty('1')).to.equal(true);
                            return phpAuthenticatedRequest
                                .get('/profitGuruRestSvc_retail/index.php/sales/add_paymentRestApi')
                                .query(paymentParams)
                                .expect(200).then(function(resp) {
                                    var result = JSON.parse(resp.text);
                                    return Promise.resolve(result.data);
                                });

                        });
                });
        });

    };

    this.nodePrepareCartAndCompleteSale = function(item2Add, paymentParams) {
        return commonNodeVsPhp.nodeAuthenticatedRequest().then(function(nodeAuthenticatedRequest) {
            return nodeAuthenticatedRequest
                .post('/sales/cancel_saleRestApi')
                .expect(200).then(function() {
                    return nodeAuthenticatedRequest
                        .post('/sales/additemRestApi')
                        .send(item2Add)
                        .expect(200).then(function(resp) {
                            expect(resp.body.cart.length).to.equal(1);
                            paymentParams.amount_tendered = resp.body.total;

                            return nodeAuthenticatedRequest
                                .post('/sales/add_paymentRestApi')
                                .send(paymentParams)
                                .expect(200).then(function(resp) {
                                    return nodeAuthenticatedRequest
                                        .post('/sales/completeSaleRestApi')
                                        .send(paymentParams)
                                        .expect(200).then(function(resp) {
                                            return Promise.resolve(resp.body);
                                        });

                                });
                        });
                });

        });

    };
    this.phpPrepareCartAndCompleteSale = function(item2Add, paymentParams) {

        return commonNodeVsPhp.phpAuthenticatedRequest().then(function(phpAuthenticatedRequest) {
            return phpAuthenticatedRequest
                .get('/profitGuruRestSvc_retail/index.php/sales/cancel_saleRestApi')
                .expect(200).then(function() {

                    return phpAuthenticatedRequest
                        .get('/profitGuruRestSvc_retail/index.php/sales/additemRestApi')
                        .query(item2Add)
                        .expect(200).then(function(resp) {

                            var result = JSON.parse(resp.text);
                            expect(result.data.cart.hasOwnProperty('1')).to.equal(true);
                            paymentParams.amount_tendered = result.data.total;

                            return phpAuthenticatedRequest
                                .get('/profitGuruRestSvc_retail/index.php/sales/add_paymentRestApi')
                                .query(paymentParams)
                                .expect(200).then(function(resp) {
                                    return phpAuthenticatedRequest
                                        .get('/profitGuruRestSvc_retail/index.php/sales/completeSaleRestApi')
                                        .query(paymentParams)
                                        .expect(200).then(function(resp) {
                                            var result = JSON.parse(resp.text);
                                            return Promise.resolve(result.data);
                                        });
                                })

                        });
                });
        });

    };

};
module.exports = new salesComparisionUtils();