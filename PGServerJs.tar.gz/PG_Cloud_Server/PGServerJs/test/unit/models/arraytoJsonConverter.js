   'use strict';

   var chai = require('chai');
   var expect = chai.expect;
   const moment = require('moment');

   describe('Locks Test UT ', function() {
       this.timeout(100000);

       const jsonfile = require('jsonfile');

       it.only('state codes to json', function() {
           let timeStamp = parseInt(moment().format('x'));
           let stateCodePath = __dirname + '/stateCodes_.json';
           let stateCodesObjPath = __dirname + '/../../../config/profitguruCoreConfig/stateCodes_' + timeStamp + '.json';

           let stateCodes = jsonfile.readFileSync(stateCodePath);
           let stateCodesObj = {};

           for (let i = 0; i < stateCodes.length; i++) {
               stateCodesObj[stateCodes[i].number] = stateCodes[i];
           }

           stateCodesObj.timeStamp = timeStamp;

           jsonfile.writeFileSync(stateCodesObjPath, stateCodesObj);
       });

       it('hsn codes to json', function() {
           let timeStamp = parseInt(moment().format('x'));
           let hsnPath = __dirname + '/hsn_.json';
           let hsnObjPath = __dirname + '/../../../config/profitguruCoreConfig/hsn_' + timeStamp + '.json';

           let hsnArray = jsonfile.readFileSync(hsnPath);
           console.log(hsnArray.length);

           let hsnObj = [];
           let maxLength = 0;
           for (let i = 0; i < hsnArray.length; i++) {
               let obj = hsnArray[i];
               let description = obj.description;
               obj._id = description;
               delete obj.description;
               delete obj.doctype;
               delete obj.docstatus;

               if (maxLength < description.length) {
                   maxLength = description.length;
               }
           }

           hsnArray.push({
               _id: "timeStamp",
               timeStamp: timeStamp
           });

           console.log(maxLength);
           jsonfile.writeFileSync(hsnObjPath, hsnArray);
       });

       it('get filename from format', function() {
           let hsnObjPath = __dirname + '/../../../config/profitguruCoreConfig/hsn__*';
           const shelljs = require('shelljs');
           let resp = shelljs.ls(hsnObjPath);
           console.log(resp.stdout);
           resp.stdout = '';
           let outArray = resp.stdout.split('\n');
           console.log(outArray.length);
           console.log(resp.stdout.length);
       });

       it('uqc codes to json', function() {
           let timeStamp = parseInt(moment().format('x'));
           let uqcPath = __dirname + '/uqc_.json';
           let uqcObjPath = __dirname + '/../../../config/profitguruCoreConfig/uqc_' + timeStamp + '.json';

           let uqc = jsonfile.readFileSync(uqcPath);
           let uqcObj = {};
           for (let i = 0; i < uqc.length; i++) {
               uqcObj[uqc[i]] = {};
               let names = uqc[i].split('-');
               uqcObj[uqc[i]].shortName = names[0];
               uqcObj[uqc[i]].name = names[1];
           }

           uqcObj.timeStamp = timeStamp;

           jsonfile.writeFileSync(uqcObjPath, uqcObj);
       });

   });