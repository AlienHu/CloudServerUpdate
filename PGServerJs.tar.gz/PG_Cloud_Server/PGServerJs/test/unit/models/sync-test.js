const nanoInstance = require('nano-blue')("http://couchadmin:test@127.0.0.1:5984").use('pg_collection_restaurant_maindb');
const nanoInstance2 = require('nano-blue')("http://couchadmin:test@127.0.0.1:5984").use('pg_collection_restaurant_maindb_new2');

async function sync() {
    let params = {
        include_docs: true,
        limit: 1000,
        skip: 0
    };
    let totalCount = 0;
    while (true) {
        let rows = (await nanoInstance.fetch({}, params))[0].rows;
        if (rows.length === 0) {
            break;
        }
        params.skip += rows.length;
        console.log('rows.length' + rows.length);
        totalCount += rows.length;
        let docsArray = [];
        for (let i = 0; i < rows.length; i++) {
            delete rows[i].doc._rev;
            docsArray.push(rows[i].doc);

        }
        await write(docsArray);
    }
    console.log("totalCount" + totalCount);
}

async function write(docsArray) {
    await nanoInstance2.bulk({
        docs: docsArray
    }).catch(function() {
        throw 'Db doest exist?? Dont come here'
    });
}

sync();