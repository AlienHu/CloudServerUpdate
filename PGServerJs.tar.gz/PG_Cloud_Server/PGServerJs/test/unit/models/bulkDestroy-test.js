   'use strict';
   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");

   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;

   var models = require('../../../models');

   describe('Bulk Destroy UTS', function() {
       this.timeout(50000);
       before(function() {
           return models.sqlLiteDbUtils.syncDatabase(false);
       });

       it('bulk destory test ', function() {
           var query = {
               where: {
                   item_id: 1,
                   batchId: 'k',
                   serialnumber: '7d384c5f-52d9-4e3c-8253-d6484daebc2e'
               }
           };

           return models.profitGuru_item_unique_details.destroy(query).then(function(response) {
               console.log(response);
           }).catch(function(error) {
               console.log(error);
           });
       });

       xit('bulk destory test ', function() {
           var query = {
               where: {
                   id: [2, 3, 4]
               }
           };

           return models.profitGuru_units.destroy(query).then(function(response) {
               console.log(response);
           }).catch(function(error) {
               console.log(error);
           });
       });

   });