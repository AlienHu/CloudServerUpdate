'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var log = console.log;
var q = require('q');
var fs = require('fs');

var profitGuruFaker = require('../../common/profitGuruFaker.js');
var profitGuruFakerExt = require('../../common/profitGuruFakerExt.js');
var faker = require('faker');
var moment = require('moment');
var utils = require('../../../controllers/common/Utils.js');
var commonTestUtils = require('../../common/commonUtils.js');

const couchDbManager = require('../../../dbManagers/couchDbManager');
var itemController;
let itemControllerLib;
var globalConfigController = require('../../../controllers/GlobalConfigurations');

var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
var mainDBInstance = couchDBUtils.getMainCouchDB();

const jsonfile = require('jsonfile');

var BPromise = require('bluebird');

describe('Item Controller UTS', function() {
    var curItemData = {};
    var curBatch = {};
    var curItemDoc = {};
    var curInvDoc = {};

    this.timeout(200000);
    this.slow(0);

    before(function() {
        return couchDbManager.initCouchDb(false).then(function(resp) {
            itemControllerLib = require('../../../controllers/libraries/itemsControllerLib');
            itemController = require('../../../controllers/Items');
            return Promise.all([commonTestUtils.createGlobalConfigs(5), commonTestUtils.getPeople(5, 'supplier')]);
        });
    });

    it('create item mandatory', async function() {

        var fakerParams = {
            bFillAll: false,
            bRandom: false,
            bHasBatchNumber: false
        };
        curItemData = await profitGuruFakerExt.getFakerItem(fakerParams);

        return itemController.createItem(curItemData).then(function(resp) {
            console.log('successfully added item' + resp.item_id);
            curItemData.item_id = resp.item_id;
        }).catch(function(err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        });
    });

    it('create item with expiry but no expiry provided. Error message should be proper', async function() {

        var fakerParams = {
            bFillAll: false,
            bHasBatchNumber: false,
            bHasExpiryDate: true,
            bHasInitialStock: true
        };

        curItemData = await profitGuruFakerExt.getFakerItem(fakerParams);

        if (curItemData.initialStock[0].expiry) {
            delete curItemData.initialStock[0].expiry;
        }
        if (curItemData.expiry) {
            delete curItemData.expiry;
        }

        try {
            await itemController.createItem(curItemData);
            expect(0).to.equal(1);
        } catch (err) {
            console.log(err);
            //error should not be empty
        }
    });

    it('create item', async function() {
        var fakerParams = {
            bFillAll: true,
            bHasBatchNumber: false,
            iAttributeCount: 0,
            itemType: itemControllerLib.ITEM_TYPE.Normal
        };

        curItemData = await profitGuruFakerExt.getFakerItem(fakerParams);
        return itemController.createItem(curItemData).then(function(resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function(resp) {
            curItemDoc = resp;
            expect(curItemDoc.info.ItemType).to.equal(itemControllerLib.ITEM_TYPE.Normal);
            curBatch = curItemDoc.batches[Object.keys(curItemDoc.batches)[0]];
            curBatch.item_id = curItemDoc.item_id;
        }).catch(function(err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        });
    });

    it('delete dependents', async function() {
        let params;
        let resp = {};
        var bException = false;
        try {
            params = {
                id: curItemData.categoryId
            };
            resp = await globalConfigController.deleteCategory(params);
            var bException = true;
            expect(0).to.equal(1);
        } catch (error) {
            if (bException === true) {
                expect(0).to.equal(1);
            }
        }
        try {
            params = {
                id: curItemData.sellingUnitId
            };
            resp = await globalConfigController.deleteUnit(params);
            var bException = true;
            expect(0).to.equal(1);
        } catch (error) {
            if (bException === true) {
                expect(0).to.equal(1);
            }
        }

        try {
            params = {
                id: curItemData.purchaseUnitId
            };
            resp = await globalConfigController.deleteUnit(params);
            var bException = true;
            expect(0).to.equal(1);
        } catch (error) {
            if (bException === true) {
                expect(0).to.equal(1);
            }
        }

        try {
            params = {
                id: curItemData.salesTaxes[0]
            };
            resp = await globalConfigController.deleteTax(params);
            var bException = true;
            expect(0).to.equal(1);
        } catch (error) {
            if (bException === true) {
                expect(0).to.equal(1);
            }
        }

        try {
            params.id = curItemData.initialStock[0].discountId;
            resp = await globalConfigController.deleteDiscount(params);
            var bException = true;
            expect(0).to.equal(1);
        } catch (error) {
            if (bException === true) {
                expect(0).to.equal(1);
            }
        }
    });

    it('update item', function() {
        curItemData.description = faker.random.word();
        curItemData.sellingPrice = 400;
        if (!curItemData.hasBatchNumber && !curItemData.attributes.length) {
            curItemData.stockKey = curBatch.stockKey;
            if (curItemData.hasExpiryDate) {
                curItemData.expiry = curBatch.expiry;
            }
        }
        return itemController.updateItem(curItemData).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
            console.log('error in item update');
            expect(1).to.equal(0);
        });
    });

    it('update batch', async function() {
        curBatch.sellingPrice = 500;
        try {
            let resp = await itemController.updateBatch(curBatch);
            console.log(resp);
        } catch (err) {
            console.log(err);
            expect(1).to.equal(0);
        };
    });

    it('stock update', function() {
        var params = {
            item_id: curItemData.item_id,
            batchId: curBatch.batchId,
            stockKey: curBatch.stockKey,
            newQuantity: -10,
            comment: 'Sale',
            employeeId: 'admin',
            locationId: curBatch.locationId,
        };

        return itemController.updateStock(params).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
            expect(1).to.equal(0);
        });
    });

    it('getThisItemInfo', function() {
        var params = {
            item_id: curItemData.item_id,
            stockKey: curBatch.stockKey,
            taxType: itemControllerLib.enSalesTax
        };
        return itemControllerLib.getThisItemInfo(params).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
            expect(1).to.equal(0);
        });
    });

    function deleteItem(itemId) {
        var params = {
            item_id: itemId
        };

        return itemController.deleteItem(params).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
            expect(1).to.equal(0);
        });
    }

    it('delete item', function() {
        return deleteItem(curItemData.item_id);
    });

    it('create item', async function() {
        var fakerParams = {
            bFillAll: true,
            bRandom: false,
            bHasBatchNumber: false,
            itemType: itemControllerLib.ITEM_TYPE.Normal
        };

        curItemData = await profitGuruFakerExt.getFakerItem(fakerParams);
        return itemController.createItem(curItemData).then(function(resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function(resp) {
            var curItemDoc = resp;
            //Don't use this in actual code it may be slower
            expect(curItemDoc.info.ItemType).to.equal(itemControllerLib.ITEM_TYPE.Normal);
            curBatch = curItemDoc.batches[Object.keys(curItemDoc.batches)[0]];
            curBatch.item_id = curItemDoc.item_id;
        }).catch(function(err) {
            console.log(err);
            console.log('error in item creation');
            expect(1).to.equal(0);
        });
    });

    it('update item', function() {
        curItemData.description = faker.random.word();
        curItemData.stockKey = curBatch.stockKey;
        curItemData.expiry = curBatch.expiry;

        return itemController.updateItem(curItemData).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
            console.log('error in item update');
            expect(1).to.equal(0);
        });
    });

    it('update batch', function() {
        curBatch.sellingPrice = 500;
        return itemController.updateBatch(curBatch).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
            expect(1).to.equal(0);
        });
    });

    it('stock update', function() {
        var params = {
            item_id: curItemData.item_id,
            batchId: curBatch.batchId,
            stockKey: curBatch.stockKey,
            newQuantity: -10,
            comment: 'Sale',
            employeeId: 'admin',
            locationId: curBatch.locationId,
        };

        return itemController.updateStock(params).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
            expect(1).to.equal(0);
        });
    });

    it('create item with serial number without batch', async function() {
        var t_itemType = itemControllerLib.ITEM_TYPE.Ingredient;
        var fakerParams = {
            bFillAll: true,
            bHasBatchNumber: false,
            itemType: t_itemType
        };

        curItemData = await profitGuruFakerExt.getFakerItem(fakerParams);
        return itemController.createItem(curItemData).then(function(resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function(resp) {
            curItemDoc = resp;
            expect(curItemDoc.info.ItemType).to.equal(itemControllerLib.ITEM_TYPE.Ingredient);
            curBatch = curItemDoc.batches[Object.keys(curItemDoc.batches)[0]];
        });
    });

    //All the below has batches unless mentioned
    it('create item with serial number no initial stock', async function() {

        var t_itemType = itemControllerLib.ITEM_TYPE.Prepared;
        var fakerParams = {
            bFillAll: true,
            bHasInitialStock: false,
            itemType: t_itemType
        };

        curItemData = await profitGuruFakerExt.getFakerItem(fakerParams);
        return itemController.createItem(curItemData).then(function(resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function(resp) {
            expect(resp.info.ItemType).to.equal(t_itemType);
            curItemDoc = resp;

        });
    });

    function compareItemInfo(inputData, itemDoc) {
        let exclucdeFields = ["employeeId", "initialStock", "discountId", "expiry", "item_id"];
        for (var field in inputData) {
            if (0 > exclucdeFields.indexOf(field)) {
                expect(inputData[field], itemDoc[field]);
            }
        }
    }

    it('create item with serial number and initial stock', async function() {
        var fakerParams = {
            bFillAll: true
        };

        curItemData = await profitGuruFakerExt.getFakerItem(fakerParams);
        try {
            let createItemresp = await itemController.createItem(curItemData)
            curItemData.item_id = createItemresp.item_id;
            let resp = await couchDBUtils.getAllDocs([itemControllerLib.formatItemDocId(curItemData.item_id), itemControllerLib.formatInvDocId(curItemData.item_id)], mainDBInstance);
            curItemDoc = resp[0].doc;
            expect(true).to.equal(curItemDoc.info.hasOwnProperty('ItemType')); //if item type is not specified default is normal
            expect(true).to.equal(itemControllerLib.ITEM_TYPE.hasOwnProperty(curItemDoc.info.ItemType));
            curInvDoc = resp[1].doc;
            curBatch = curItemDoc.batches[Object.keys(curItemDoc.batches)[0]];
            curBatch.item_id = curItemDoc.item_id;
            let inputUniqueDetails = curItemData.initialStock[0].uniqueDetails;
            for (let x = 0; x < inputUniqueDetails.length; x++) {
                let stockKey = Object.keys(curInvDoc.stock)[0];
                expect(true).to.equal(curInvDoc.stock[stockKey].uniqueDetails.hasOwnProperty(inputUniqueDetails[x].serialnumber));
                expect(inputUniqueDetails[x].serialnumber).to.equal(curInvDoc.stock[stockKey].uniqueDetails[inputUniqueDetails[x].serialnumber].info.serialnumber);
                for (let y = 0; y < inputUniqueDetails[x].imeiNumbers.length; y++) {
                    expect(inputUniqueDetails[x].imeiNumbers[y]).to.equal(curInvDoc.stock[stockKey].uniqueDetails[inputUniqueDetails[x].serialnumber].info.imeiNumbers[y]);
                }
            }
            compareItemInfo(curItemData, curItemDoc.info);
        } catch (error) {
            console.log(error);
            expect(0).to.equal(1);
        };
    });
    it('update batch details', function() {
        curBatch.sellingPrice = 500;
        var batchClone = utils.clone(curBatch);
        delete batchClone.uniqueDetails;
        return itemController.updateBatch(batchClone).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
            expect(1).to.equal(0);
        });
    });

    it('update batch quantity', async function() {
        try {
            let params = {
                item_id: curItemData.item_id,
                batchId: curBatch.batchId,
                stockKey: curBatch.stockKey,
                newQuantity: -10,
                comment: 'Sale',
                employeeId: 'admin',
                locationId: curBatch.locationId,
            };

            let stockKey = params.stockKey;
            let uniqueDetails = Object.values(curInvDoc.stock[stockKey].uniqueDetails);

            params.uniqueDetails = [];

            let quantity = Math.abs(params.newQuantity);
            for (var i = 0; i < quantity; i++) {
                params.uniqueDetails.push(uniqueDetails[i].info);
            }

            let resp = await itemController.updateStock(params)
            let respDoc = await couchDBUtils.getAllDocs([itemControllerLib.formatItemDocId(curItemData.item_id), itemControllerLib.formatInvDocId(curItemData.item_id)], mainDBInstance);
            let respDocUniqueDetails = respDoc[1].doc.stock[stockKey].uniqueDetails;
            let inputUniqueDetails = params.uniqueDetails;
            for (let i = 0; i < inputUniqueDetails.length; i++) {
                expect(true).to.equal(respDocUniqueDetails.hasOwnProperty(inputUniqueDetails[i].serialnumber));
                expect(false).to.equal(respDocUniqueDetails[inputUniqueDetails[i].serialnumber].itemAvailable);
            }
        } catch (err) {
            console.log(err);
            expect(1).to.equal(0);
        };
    });

    it('update batch quantity increment', function() {
        var params = {
            item_id: curItemData.item_id,
            batchId: curBatch.batchId,
            stockKey: curBatch.stockKey,
            newQuantity: 5,
            comment: 'Adding New Stock',
            employeeId: 'admin',
            locationId: curBatch.locationId,
        };

        params.uniqueDetails = [];

        var quantity = Math.abs(params.newQuantity);
        for (var i = 0; i < quantity; i++) {
            //It is a requirement that the entire uniqueDetails is passed as is 
            //Reason : Tough to write a query for sql . CouchDB doesn't mind
            params.uniqueDetails.push(profitGuruFakerExt.getFakeUniqueDetails(curItemData.imeiCount, curItemData.is_serialized));
        }

        return itemController.updateStock(params).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
            expect(1).to.equal(0);
        });
    });

    it('delete item', function() {
        return deleteItem(curItemData.item_id);
    });

    it('create all possible combination of items', function() {
        //No Batch No SerialNumber
    });

    it('create item only imeiNumber and initial stock', async function() {
        var fakerParams = {
            bFillAll: true,
            bSerialized: false
        };

        curItemData = await profitGuruFakerExt.getFakerItem(fakerParams);
        return itemController.createItem(curItemData).then(function(resp) {
            console.log(resp);
            curItemData.item_id = resp.item_id;
            return couchDBUtils.getDoc(itemControllerLib.formatItemDocId(curItemData.item_id), mainDBInstance);
        }).then(function(resp) {
            curItemDoc = resp;

            curBatch = curItemDoc.batches[Object.keys(curItemDoc.batches)[0]];
            curBatch.item_id = curItemDoc.item_id;
        });
    });

    it('update batch quantity increment', function() {
        var params = {
            item_id: curItemData.item_id,
            batchId: curBatch.batchId,
            stockKey: curBatch.stockKey,
            newQuantity: 5,
            comment: 'Adding New Stock',
            employeeId: 'admin',
            locationId: curBatch.locationId,
        };

        params.uniqueDetails = [];

        var quantity = Math.abs(params.newQuantity);
        for (var i = 0; i < quantity; i++) {
            //It is a requirement that the entire uniqueDetails is passed as is 
            //Reason : Tough to write a query for sql . CouchDB doesn't mind
            params.uniqueDetails.push(profitGuruFakerExt.getFakeUniqueDetails(curItemData.imeiCount, curItemData.is_serialized));
        }

        return itemController.updateStock(params).then(function(resp) {
            console.log(resp);
        }).catch(function(err) {
            console.log(err);
            expect(1).to.equal(0);
        });
    });

    async function deleteAllItems(itemsInfoArray) {
        if (itemsInfoArray === undefined || (itemsInfoArray && itemsInfoArray.length === 0)) {
            //RelaxTodo .. This gives deleted docs also
            let resp = await couchDBUtils.getAllDocsByType('item', mainDBInstance);
            let allItems = [];
            for (let i = 0; i < resp.length; i++) {
                if (!resp[i].doc.deleted) {
                    allItems.push(resp[i].doc);
                }
            }
            if (allItems.length === 0) {
                return;
            } else {
                return deleteAllItems(allItems);
            }
        } else {
            for (let i = 0; i < itemsInfoArray.length; i++) {
                var param = {
                    item_id: itemsInfoArray[i].item_id
                };
                await itemController.deleteItem(param);
            }

        }
    }

    //Test can be improved to query and check all the values
    //Todo: This test can fail because of zipcode. 
    xit('import items', async function() {
        //delete all customers
        return deleteAllItems().then(async function() {
            //creating customers data to write to a file
            var allItems = [];
            var fakerParams = {
                bFillAll: true
            };
            var fakerParams2 = {
                bFillAll: false
            };
            for (var i = 0; i < 5; i++) {

                var fakerItem = await profitGuruFakerExt.getFakerReadableItem(fakerParams);
                // var fakerPerson = profitGuruFaker.getFakerPerson();
                // var fakerItemConfig = profitGuruFaker.getFakerCustomerConfig();
                allItems.push(fakerItem);
            }
            for (var i = 0; i < 5; i++) {

                var fakerItem2 = await profitGuruFakerExt.getFakerReadableItem(fakerParams2);
                // var fakerPerson = profitGuruFaker.getFakerPerson();
                // var fakerItemConfig = profitGuruFaker.getFakerCustomerConfig();
                allItems.push(fakerItem2);
            }

            //writing to a file
            var fileName = 'ExportedItems_ref.csv';
            var json2csv = require('json2csv');
            var csv = json2csv({
                data: allItems
            });

            var defered = q.defer();
            fs.writeFile(fileName, csv, function(err) {
                if (err) {
                    expect(1).to.equal(0);
                }

                var params = {};
                params.file = fileName;
                itemController.importItems(allItems, "admin").then(function(resp) {
                    console.log(resp);
                    defered.resolve(resp);
                }).catch(function(err) {
                    console.log('i camer  here inside ut catch block');
                    defered.reject(false);
                });
            });

            return defered.promise;
        });
    });

    let serialnumbers = [];
    let imeiNumbers = [];

    function fillUniqueDetails(curItemData, quantity, bSerialized, bIMEINumber) {
        curItemData.initialStock[0].quantity = quantity;
        curItemData.initialStock[0].uniqueDetails.length = 0;

        for (let i = 0; i < quantity; i++) {
            if (!serialnumbers.length) {
                serialnumbers = ['a', 'b', 'c'];
            }
            if (!imeiNumbers.length) {
                imeiNumbers = ['111111111111111', '111111111111112', '111111111111113'];
            }
            curItemData.initialStock[0].uniqueDetails.push({
                imeiNumbers: [],
                serialnumber: ''
            });

            if (bSerialized) {
                curItemData.initialStock[0].uniqueDetails[i].serialnumber = serialnumbers.shift();
            }
            if (bIMEINumber) {
                curItemData.initialStock[0].uniqueDetails[i].imeiNumbers = [imeiNumbers.shift()];
            }
            if (!serialnumbers.length) {
                serialnumbers = ['a', 'b', 'c'];
            }
            if (!imeiNumbers.length) {
                imeiNumbers = ['111111111111111', '111111111111112', '111111111111113'];
            }
        }
    }

    it('create unique items test', async function() {
        let params = {
            bHasBatchNumber: false,
            bSerialized: true,
            bIMEINumber: false,
            bHasExpiryDate: false,
            iAttributeCount: 0,
            bHasInitialStock: true
        };

        let config = [{
            bSerialized: true,
            bIMEINumber: false
        }, {
            bSerialized: false,
            bIMEINumber: true
        }, {
            bSerialized: true,
            bIMEINumber: true
        }];

        for (let i = 2; i < 3; i++) {
            let bSerialized = config[i].bSerialized;
            let bIMEINumber = config[i].bIMEINumber;

            curItemData = await profitGuruFakerExt.getFakerItem(params);
            fillUniqueDetails(curItemData, 3, bSerialized, bIMEINumber);
            if (bSerialized) {
                curItemData.initialStock[0].uniqueDetails[2].serialnumber = serialnumbers.shift();
            }
            if (bIMEINumber) {
                curItemData.initialStock[0].uniqueDetails[2].imeiNumbers.push(imeiNumbers.shift());
            }

            try {
                await itemController.createItem(curItemData);
                throw 1;
            } catch (error) {
                expect(error).to.not.equal(1);
                console.log('voila');
                console.log(error);
            }

            fillUniqueDetails(curItemData, 2, bSerialized, bIMEINumber);
            await itemController.createItem(curItemData);

            curItemData = await profitGuruFakerExt.getFakerItem(params);
            fillUniqueDetails(curItemData, 3, bSerialized, bIMEINumber);
            try {
                await itemController.createItem(curItemData);
                throw 1;
            } catch (error) {
                expect(error).to.not.equal(1);
                console.log('voila');
                console.log(error);
            }
        }

    });

    it('faker test mu-pu', async function() {
        let mupu1 = await profitGuruFakerExt.getFakerItem({
            bFillAll: true,
            bMultipleUnits: false,
            bPProfiles: false,
            bSerialized: false,
            bIMEINumber: false,
            conversionFactor: 3,
            iAttributeCount: 3
        });
        jsonfile.writeFileSync('item1.json', mupu1);
        let mupu2 = await profitGuruFakerExt.getFakerItem({
            bFillAll: true,
            bMultipleUnits: false,
            bPProfiles: true,
            conversionFactor: 3
        });
        jsonfile.writeFileSync('item2.json', mupu2);
        let mupu3 = await profitGuruFakerExt.getFakerItem({
            bFillAll: true,
            bMultipleUnits: true,
            bPProfiles: false,
            conversionFactor: 3
        });
        jsonfile.writeFileSync('item3.json', mupu3);
        let mupu4 = await profitGuruFakerExt.getFakerItem({
            bFillAll: true,
            bMultipleUnits: true,
            bPProfiles: true,
            conversionFactor: 3
        });
        jsonfile.writeFileSync('item4.json', mupu4);

        if (true) {
            await itemController.createItem(mupu1);
            await itemController.createItem(mupu2);
            await itemController.createItem(mupu3);
            await itemController.createItem(mupu4);
        }
    });

    it.only('autoreport', async () => {
        var sendReport = require('../../../controllers/libraries/sendReport');
        let repData = await sendReport.sendReport('sale', ['ganumogare18@gmail.com'], {}, [1, 2]);
        console.log(repData);
    });
});