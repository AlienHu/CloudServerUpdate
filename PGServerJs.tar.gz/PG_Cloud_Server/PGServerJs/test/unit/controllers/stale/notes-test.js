(function() {
    'use strict';
    require('dotenv-safe').load({
        path: __dirname + '/../../../.env',
        sample: __dirname + '/../../../env.example'
    });

    var chai = require('chai');
    var chaiAsPromised = require('chai-as-promised');
    chai.use(chaiAsPromised);
    chai.should();
    var expect = chai.expect;
    const couchDbManager = require('../../../dbManagers/couchDbManager');
    describe('Notes Controller UTs  ', function() {
        this.timeout(100000);

        var controller = require('../../../controllers/Notes');
        var faker = require('faker');
        var randomNote = faker.lorem.word() + ' ' + faker.lorem.word() + ' ' + faker.lorem.word();

        before(function() {

            return couchDbManager.initCouchDb(true);
        });

        beforeEach(function() {});

        it('create and get', function() {
            var param = {
                notes: randomNote
            };
            return controller.saveNotes(param).then(function(resp) {
                expect(resp.status).to.equal('success');
                return controller.getNotes();
            }).then(function(resp) {
                expect(resp.data.notes).to.equal(randomNote);
            }).catch(function(err) {
                console.log(err);
                expect(1).to.equal(0);
            });
        });

        it('update and get', function() {
            randomNote = randomNote + ' ' + faker.lorem.word() + ' ' + faker.lorem.word() + ' ' + faker.lorem.word();
            var param = {
                notes: randomNote
            };
            return controller.saveNotes(param).then(function(resp) {
                expect(resp.status).to.equal('success');
                return controller.getNotes();
            }).then(function(resp) {
                expect(resp.data.notes).to.equal(randomNote);
            }).catch(function(err) {
                console.log(err);
                expect(1).to.equal(0);
            });
        });

    });

})();