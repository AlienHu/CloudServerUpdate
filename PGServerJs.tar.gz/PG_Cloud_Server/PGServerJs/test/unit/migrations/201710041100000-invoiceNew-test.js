   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   const coreDBInstancce = couchDBUtils.getCoreCouchDB();
   const usersDBInstance = couchDBUtils.getUserCouchDB();
   const couchDbManager = require('../../../dbManagers/couchDbManager');
   const migrationHandler = require('../../../couchDb/migrationHandler');

   describe('Migration Tests', function() {
       this.timeout(200000);

       before(function() {
           return couchDbManager.initCouchDb(false);
       });

       it('down', async function() {
           await migrationHandler.migrate('201709090000000-customerCompany.js');
           let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('salesPrinter')).to.equal(false);
           expect(Object.keys(applicationSettings.invoiceSettings).length).to.equals(9);
       });

       it('up', async function() {
           //userentitlements
           //users
           await migrationHandler.migrate('201710041100000-invoiceNew.js');

           let applicationSettings = await couchDBUtils.getDoc('profitGuruApplicationSettings_', coreDBInstancce);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('declarationNote')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('additionalNote')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('subNote')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('returnPolicy')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('title')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('showCustomerSign')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('companyTIN')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('logoFloat')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('salesPrinter')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('kotPrinter')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('receiptCopy')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('kotCopy')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('showMRP')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('showSNum')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('showIMEI')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('showVariants')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('showLoyalityInfo')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('showSerialNum')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('showTaxBreakings')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('showHSN')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('showGSTAmt')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('printReceiptByDefault')).to.equal(true);
           expect(applicationSettings.invoiceSettings.hasOwnProperty('printInvoice')).to.equal(true);
           expect(Object.keys(applicationSettings.invoiceSettings).length).to.equals(114);

       });

   });