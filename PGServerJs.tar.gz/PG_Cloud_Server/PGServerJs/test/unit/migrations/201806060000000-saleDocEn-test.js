'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var assert = chai.assert;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const coreDBInstancce = couchDBUtils.getCoreCouchDB();
const usersDBInstance = couchDBUtils.getUserCouchDB();
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');
const mainDBInstance = couchDBUtils.getMainCouchDB();

describe('Migration Tests', function() {
    this.timeout(200000);

    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    it('up', async function() {
        await migrationHandler.migrate('201806060000000-saleDocEn.js');

        let allSaleDocs = await couchDBUtils.getAllDocsByType('sale', mainDBInstance);
        for (var i = 0; i < allSaleDocs.length; i++) {
            let saleDoc = allSaleDocs[i].doc;
            // expect(typeof(saleDoc.sales_info.taxes) === "string").to.equal(true);
            expect(saleDoc.sales_info.hasOwnProperty('taxes')).to.equal(true);
            expect(saleDoc.sales_info.hasOwnProperty('subtotal')).to.equal(true);
            expect(saleDoc.sales_info.hasOwnProperty('profit')).to.equal(true);
            expect(saleDoc.sales_info.hasOwnProperty('cost')).to.equal(true);
            expect(saleDoc.sales_info.hasOwnProperty('quantity')).to.equal(true);
        }

        let allSaleReturnDocs = await couchDBUtils.getAllDocsByType('saleReturn', mainDBInstance);
        for (var i = 0; i < allSaleReturnDocs.length; i++) {
            let saleReturnDoc = allSaleReturnDocs[i].doc;
            // expect(typeof(saleDoc.sales_info.taxes) === "string").to.equal(true);
            expect(saleReturnDoc.info.hasOwnProperty('taxes')).to.equal(true);
            expect(saleReturnDoc.info.hasOwnProperty('subtotal')).to.equal(true);
            expect(saleReturnDoc.info.hasOwnProperty('profit')).to.equal(true);
            expect(saleReturnDoc.info.hasOwnProperty('cost')).to.equal(true);
            expect(saleReturnDoc.info.hasOwnProperty('quantity')).to.equal(true);
        }
    });

});