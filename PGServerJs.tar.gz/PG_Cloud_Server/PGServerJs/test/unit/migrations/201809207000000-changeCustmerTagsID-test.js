'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');
const mainDBInstance = couchDBUtils.getMainCouchDB();

const NEW_TAGS_ID = "customers_tags";
const OLD_TAGS_ID = "customer_tags";

describe('Migration Tests', function() {
    this.timeout(200000);

    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    it('down', async function() {
        await migrationHandler.migrate('201806210000000-addingChangeDueInPayments.js');
        let tags;
        try {
            tags = await couchDBUtils.getDocEx(OLD_TAGS_ID, mainDBInstance);
        } catch (e) {
            if (e.reason === 'missing') {
                return;
            }
        }
        expect(tags.hasOwnProperty('tags')).to.equal(true);
    });

    it('up', async function() {

        await migrationHandler.migrate('201809207000000-changeCustmerTagsID.js');
        try {
            await couchDBUtils.getDocEx(OLD_TAGS_ID, mainDBInstance);
        } catch (err) {
            if (err.reason === 'missing') { // miggration will not run if missing.
                return;
            }
            expect(err.reason).to.equal('deleted');
        }
        let tags = await couchDBUtils.getDoc(NEW_TAGS_ID, mainDBInstance);
        expect(tags.hasOwnProperty('tags')).to.equal(true);
    });

});