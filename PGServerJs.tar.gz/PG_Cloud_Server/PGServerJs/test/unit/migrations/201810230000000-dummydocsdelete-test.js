'use strict';

require('dotenv-safe').load({
    path: __dirname + '/../../../.env',
    sample: __dirname + '/../../../env.example'
});

//Debug node-debug _mocha -R spec UT_items.js
//var expect = require('expect.js');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
chai.should();
var expect = chai.expect;
var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
const couchDbManager = require('../../../dbManagers/couchDbManager');
const migrationHandler = require('../../../couchDb/migrationHandler');
const mainDBInstance = couchDBUtils.getMainCouchDB();

describe('Migration Tests', function() {
    this.timeout(200000);

    before(function() {
        return couchDbManager.initCouchDb(false);
    });

    it('down', async function() {
        await migrationHandler.migrate('201809250000000-purhaseOnCreditNullErrorFix.js');

    });

    it.only('up', async function() {

        await migrationHandler.migrate('201810230000000-dummydocsdelete.js');
        let skip = 0;
        try {

            while (true) {
                let resp = (await mainDBInstance.fetch({}, {
                    include_docs: true,
                    limit: 10000,
                    skip: skip
                }))[0];

                if (resp.rows.length === 0) {
                    break;
                }

                let docs2DeleteArr = [];
                for (let i = 0; i < resp.rows.length; i++) {
                    skip += resp.rows.length;
                    if (Object.keys(resp.rows[i].doc).length !== 2) {
                        continue;
                    }
                    docs2DeleteArr.push(i);
                    console.log('empty docs still exists!!!!!!!! ' + (i));

                }
                console.log(JSON.stringify(docs2DeleteArr));
                expect(docs2DeleteArr.length).to.equal(0);
            }
        } catch (e) {
            console.log(e);
            expect(0).to.equal(1);
        }
    });

});