   'use strict';

   require('dotenv-safe').load({
       path: __dirname + '/../../../.env',
       sample: __dirname + '/../../../env.example'
   });

   //Debug node-debug _mocha -R spec UT_items.js
   //var expect = require('expect.js');
   var chai = require("chai");
   var chaiAsPromised = require("chai-as-promised");
   chai.use(chaiAsPromised);
   chai.should();
   var expect = chai.expect;
   var assert = chai.assert;
   var couchDBUtils = require('../../../controllers/common/CouchDBUtils');
   const coreDBInstancce = couchDBUtils.getCoreCouchDB();
   const usersDBInstance = couchDBUtils.getUserCouchDB();
   const couchDbManager = require('../../../dbManagers/couchDbManager');
   const migrationHandler = require('../../../couchDb/migrationHandler');

   describe('Migration Tests', function() {
       this.timeout(200000);

       before(function() {
           return couchDbManager.initCouchDb(false);
       });

       it.only('down', async function() {
           await migrationHandler.migrate('201710130000000-receivingsDBDocumnets.js');
           var params = {};
           let allUsersDoc = [];
           let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
           for (var i = 0; i < allUsers.length; i++) {
               allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
               if (allUsers[i].value.roles[0].itemManagement) {
                   expect(allUsers[i].value.roles[0].itemManagement.hasOwnProperty('add ')).to.equal(true);
                   expect(allUsers[i].value.roles[0].itemManagement.hasOwnProperty('add')).to.equal(false);

                   if (allUsers[i].value.roles[1] === 'inventoryManager') {
                       expect(allUsers[i].value.roles[0].itemManagement.allowAll).to.equal(false);
                       expect(allUsers[i].value.roles[0].itemManagement.viewOnMenu).to.equal(false);
                       expect(allUsers[i].value.roles[0].itemManagement["add "].allowed).to.equal(false);
                       expect(allUsers[i].value.roles[0].itemManagement.view.allowed).to.equal(false);
                       expect(allUsers[i].value.roles[0].itemManagement.delete.allowed).to.equal(false);
                       expect(allUsers[i].value.roles[0].itemManagement.update.allowed).to.equal(false);
                   }
               }
           }

       });

       it('up', async function() {
           //userentitlements
           //users
           await migrationHandler.migrate('201710160000000-itemManagement4InventoryManager.js');

           var params = {};
           let allUsersDoc = [];
           let allUsers = await couchDBUtils.getView('employees', 'all', params, usersDBInstance);
           for (var i = 0; i < allUsers.length; i++) {
               allUsers[i].value.roles[0] = JSON.parse(allUsers[i].value.roles[0]);
               if (allUsers[i].value.roles[0].itemManagement) {
                   expect(allUsers[i].value.roles[0].itemManagement.hasOwnProperty('add ')).to.equal(false);
                   expect(allUsers[i].value.roles[0].itemManagement.hasOwnProperty('add')).to.equal(true);
               }
               if (allUsers[i].value.roles[1] === 'inventoryManager') {
                   expect(allUsers[i].value.roles[0].itemManagement.allowAll).to.equal(true);
                   expect(allUsers[i].value.roles[0].itemManagement.viewOnMenu).to.equal(true);
                   expect(allUsers[i].value.roles[0].itemManagement.add.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].itemManagement.view.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].itemManagement.delete.allowed).to.equal(true);
                   expect(allUsers[i].value.roles[0].itemManagement.update.allowed).to.equal(true);
               }
           }

       });

   });