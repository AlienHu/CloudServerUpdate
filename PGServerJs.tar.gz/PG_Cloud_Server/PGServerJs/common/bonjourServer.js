/* Copyright (C) AliennHu Pvt Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Ganesh Mogare, July 2015
 */
let createSingleton = require('create-singleton');
let ip = require("ip");
//let EventEmitter = require('events').EventEmitter;
//let network = new EventEmitter();
let profitGuruStatusEvents = require('./profitGuruStatusEvents.js');
let logger = require('./Logger');
let validator = require('validator');
let _self;
//let profitGuruEvents = profitGuruStatusEvents.getNetWorkStatusEventer();
let BonjourServerSingleton = createSingleton(function BonjourServer() {

    _self = this;
    let bTriggerBonjour = false;
    let bonjourService;
    let bonjourServicePulish;
    let bonjourWatcher;
    let connectedToLAN;
    let serverSerilaNumber = 0;
    let locationName;
    let serviceName = 'profitGuruServer_' + process.env.APP_TYPE + require('os').hostname();

    this.stopBonjourServiceInstance = function() {
        return new Promise(function(resolve, reject) {
            let bReturned = false;
            clearBonjourWatcher();
            if (isBonjourStarted()) {
                logger.info('bonjour service status before stopping server = ' + bonjourServicePulish.published);
                bonjourServicePulish.stop(function() {
                    logger.info('stopped bonjour<' + bonjourServicePulish.published + '>');
                    if (!bReturned) {
                        resolve(true);
                        bReturned = true;
                        return;
                    }
                });
            } else {
                logger.info('bonjour not started');
                resolve(true);
                bReturned = true;
                return;
            }

            setTimeout(function() {
                logger.info('bonjour not started');
                if (!bReturned) {
                    logger.error('Timeout. Could not stop bonjour service.');
                    reject(false);
                    bReturned = true;
                }
            }, 10000);

        });
    };

    this.getBonjourServiceDetails = function() {
        return {
            name: serviceName,
            port: process.env.PROFITGURU_SERVER_PORT,
            serverId: serverSerilaNumber,
            appType: process.env.APP_TYPE,
            locationName: locationName,
            serverIp: ip.address(),
            txt: { //bonjour sends the keys as small letters
                serverid: serverSerilaNumber,
                apptype: process.env.APP_TYPE,
                locationname: locationName,
                serverip: ip.address() //First Address is returned
            }
        };
    };

    this.setLocationNameAndStartBonjourServer = function(locName) {
        if (validator.isEmpty(locName)) {
            locationName = require('os').hostname() + ' ' + process.env.APP_TYPE;
        } else {
            locationName = locName;
            serviceName = 'profitGuruServer_' + process.env.APP_TYPE + locationName;
        }

        bTriggerBonjour = true;
        if (serverSerilaNumber && connectedToLAN) {
            startBonjourServer();
        } else {
            logger.error('Bonjour Server could not be started serverserilaNumber<' + serverSerilaNumber + '> connectedToLAN<' + connectedToLAN + '>');
        }

    };

    function startBonjourServer(bRestartWatcher) {
        if (bRestartWatcher === undefined) {
            bRestartWatcher = true;
        }

        try {

            if (bTriggerBonjour) {
                bTriggerBonjour = false;
                if (bRestartWatcher) {
                    clearBonjourWatcher();
                }

                setTimeout(function() {

                    try {
                        bonjourService = require('bonjour')();
                    } catch (err) {
                        logger.error(err);
                        logger.error('require bonjour try catch');
                    }
                    let bonjourParams = {
                        name: serviceName,
                        type: 'http',
                        port: process.env.PROFITGURU_SERVER_PORT,
                        txt: {
                            serverId: serverSerilaNumber,
                            appType: process.env.APP_TYPE,
                            locationName: locationName,
                            serverIp: ip.address() //First Address is returned
                        }
                    };

                    if (bonjourServicePulish) {
                        logger.info('bonjour service status before starting = ' + bonjourServicePulish.published);
                    }

                    logger.info('Started publishing Bonjour Service :', JSON.stringify(bonjourParams));
                    try {
                        bonjourServicePulish = bonjourService.publish(bonjourParams);
                        if (bRestartWatcher) {
                            watchForBonjour();
                        }
                        bonjourServicePulish.on('error', function(err) {
                            logger.error(err);
                            logger.error('error while publishing');
                        });
                        bonjourServicePulish.on('up', function(msg) {
                            logger.info(msg);
                            logger.info('bonjour up <' + bonjourServicePulish.published + '>');
                        });
                    } catch (err) {
                        logger.error('publish error');
                        logger.error(err);
                    }
                }, 1000);
            } else {
                logger.info('Bonjour Already Started');
            }
        } catch (e) {

            logger.error('Internet disconncted', e);

        }
    }

    function watchForBonjour() {

        clearBonjourWatcher();

        bonjourWatcher = setInterval(function() {
            if (serverSerilaNumber && connectedToLAN && (!isBonjourStarted() || bTriggerBonjour)) {
                bTriggerBonjour = true;
                logger.info('triggering again');
                startBonjourServer(false);
            }
        }, 15000);
    }

    function clearBonjourWatcher() {
        if (bonjourWatcher) {
            clearInterval(bonjourWatcher);
        }
    }

    function isBonjourStarted() {
        if (bonjourServicePulish && bonjourServicePulish.published) {
            return true;
        }

        return false;
    }

    /**
     * notConnected2LAN just make the flag false
     * connected2lan make the flag true
     * if bonjour already started.. stop it
     * if serveruid available start bonjour
     */
    profitGuruStatusEvents.on('connected2LAN', function() {
        logger.info('connected2LAN!');

        // Case when network connection changes      
        bTriggerBonjour = true;
        if (bonjourServicePulish) {
            logger.info('bonjour service status connected2LAN = ' + bonjourServicePulish.published);
        }

        if (isBonjourStarted()) {
            logger.info('Stopiing Bonjour Service!');
            try {
                bonjourServicePulish.stop(function() {
                    logger.info('bonjour service status after stopping = ' + bonjourServicePulish.published);
                    startBonjourServer();
                });
            } catch (err) {
                logger.error(err);
                logger.error('stop error connected2LAN');
            }
        } else if (serverSerilaNumber) {
            startBonjourServer();
        }
        connectedToLAN = true;
    }).on('notConnected2LAN', function() {
        logger.info('notConnected2LAN!');
        connectedToLAN = false;
    });

    profitGuruStatusEvents.on('ServerUUID_Available', function(serverSerilaNumberParam) {
        serverSerilaNumber = serverSerilaNumberParam;
        logger.info('ServerUUID_Available!');
    });

});

module.exports = new BonjourServerSingleton();