    let validator = function() {

        const utils = require('../controllers/common/Utils');
        const IS_UNDEFINED_OR_NULL = utils.isUndefinedOrNull2;
        const logger = require('../common/Logger');

        this._validateApiRequest = function(apiData, apiFormat) {
            let errMsg = '';
            let tempResponse = {};

            for (let dataKey in apiData) {
                if (apiFormat.hasOwnProperty(dataKey)) {
                    //Key Found in Schema
                    if (apiFormat[dataKey].allowNULL) {
                        //field can be null

                    } else if (IS_UNDEFINED_OR_NULL(apiData[dataKey])) {
                        //Mandatory Field is missing
                        if (IS_UNDEFINED_OR_NULL(apiFormat[dataKey]._default)) {
                            //No Default Value Provided. Client should provide this field
                            errMsg = 'Missing Mandatory Field <' + dataKey + '>';
                        } else {
                            //Default value provided. Assigning default value
                            apiData[dataKey] = apiFormat[dataKey]._default;
                        }
                    }

                    if (IS_UNDEFINED_OR_NULL(apiData[dataKey])) {
                        logger.error('Input data missing ' + dataKey);
                        errMsg += "Incomplete data"
                    } else {
                        //Check Type
                    }

                } else {
                    //Unwanted Field Deleting
                    delete apiData[dataKey];
                }
            }
            return errMsg;

        };

        this.validateApiRequest = function(apiData, apiFormat) {
            let response = {
                message: '',
                data: {}
            };
            let tempResponse = {};
            for (let key in apiFormat) {
                if (apiData.hasOwnProperty(key)) {
                    if (typeof apiData[key] === apiFormat[key].type) {
                        tempResponse[key] = apiData[key];
                    } else {
                        if (apiFormat[key].type === 'number' && typeof parseInt(apiData[key]) === 'number') {
                            tempResponse[key] = parseInt(apiData[key]);
                        } else {
                            logger.error('Invalid input type ' + key + " : " + typeof apiData[key] + " Expected: " + apiFormat[key].type);
                            response.message += " Invalid data " + apiData[key];
                        }
                    }
                } else {
                    if (!IS_UNDEFINED_OR_NULL(apiFormat[key]._default)) {
                        tempResponse[key] = apiFormat[key]._default;
                    } else if (!apiFormat[key].allowNULL) {
                        //No Default Value Provided. Client should provide this field
                        response.message = ' Missing Mandatory Field <' + key + '>';
                    }
                }
            }

            if (response.message) {
                return response;
            }
            response.data = tempResponse;
            return response;
        }

    }
    module.exports = new validator();