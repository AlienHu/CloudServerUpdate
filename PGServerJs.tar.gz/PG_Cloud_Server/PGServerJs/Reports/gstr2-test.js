'use strict';
require('dotenv-safe').load({
    path: __dirname + '/../.env',
    sample: __dirname + '/../env.example'
});

const chai = require("chai");
const chaiAsPromised = require("chai-as-promised");

const faker = require('faker');

chai.use(chaiAsPromised);
chai.should();
const expect = chai.expect;

const couchDbManager = require('../dbManagers/couchDbManager');
const couchDBUtils = require('../controllers/common/CouchDBUtils');
const mainDBInstance = couchDBUtils.getMainCouchDB();

let testUtils;

describe('Elements UTs', function() {

    this.timeout(500000);
    var resp = [];
    before(async function() {
        await couchDbManager.initCouchDb(false);
        testUtils = require('./gstr2.js');
        resp = await testUtils.getAllHeads({
            // month: 7 // get for specific month
        });
        // ONLY 3, 13 is done....rest is incorrect
        var keys = Object.keys(resp);
        console.log(resp);
    });
    it('b2b 3', async function() {
        let head3 = resp['head_3'];
        for (var i = 1; i < head3.length; i++) {
            var row = head3[i];
            expect(row).to.have.property('customerGSTIN').not.equals('');
            expect(row).to.have.property('invoiceNo').not.equals('');
            expect(row).to.have.property('invoiceDate').not.equals('');
            expect(row).to.have.property('totalValue').gt(0);
            expect(row).to.have.property('cess').gte(0);
            expect(row).to.have.property('cgst').gte(0);
            expect(row).to.have.property('sgst').gte(0);
            expect(row).to.have.property('igst').gte(0);
            expect(row).to.have.property('taxRate').gte(0);
            expect(row).to.have.property('totalTaxableValue').gt(0);
        }
    });
    it('hsn 13', async function() {
        let head13 = resp['head_13'];
        expect(head13).length.to.be.gt(0);
        for (var i = 1; i < head13.length; i++) { // 0 has headings
            var row = head13[i];
            expect(row).to.have.property('uqc').not.equals('');
            expect(row).to.have.property('hsn').not.equals('');
            expect(row).to.have.property('quantity').gt(0);
            expect(row).to.have.property('cgst').gte(0);
            expect(row).to.have.property('sgst').gte(0);
            expect(row).to.have.property('totalValue').gt(0);
            expect(row).to.have.property('totalTaxableValue').gt(0);
            expect(row).to.have.property('igst').gte(0);
        }

    });

    it('6a amendments', async function() {
        // 6: modifications made in head in head 3, 4, 5 (3 only done as of now --> 6a )
        let testUtils2 = require('./gstr2.js');
        resp = await testUtils2.getHead6({
            // month: 7 // get for specific month
        });
        var keys = Object.keys(resp);
        console.log(resp);
        let head6a = resp['head_6a'];
        for (var i = 1; i < head6a.length; i++) {
            var row = head6a[i];
            expect(row).to.have.property('oldCustomerGSTIN').not.equals('');
            expect(row).to.have.property('oldInvoiceNo').not.equals('');
            expect(row).to.have.property('oldInvoiceDate').not.equals('');
            // expect(row).to.have.property('oldInvoiceValue').gt(0);
            expect(row).to.have.property('taxRate').gte(0);
            expect(row).to.have.property('totalTaxableValue').gt(0);
            expect(row).to.have.property('customerGSTIN').not.equals('');
            expect(row).to.have.property('invoiceNo').not.equals('');
            expect(row).to.have.property('invoiceDate').not.equals('');
            expect(row).to.have.property('totalValue').gt(0);
            expect(row).to.have.property('cess').gte(0);
            expect(row).to.have.property('cgst').gte(0);
            expect(row).to.have.property('sgst').gte(0);
            expect(row).to.have.property('igst').gte(0);
        }

    });
    it('calculatePriceHandler', async function() {
        var doc = {
            purchasePrice: 1000,
            discount_percent: 4,
            bPPTaxInclusive: true,
            quantity_purchased: 5,
            itemTaxList: [{
                    name: 'CGST',
                    percent: 20
                },
                {
                    name: 'SGST',
                    percent: 12
                }
            ],
            chargesList: [{
                name: 'Service',
                percent: 11.6
            }],
            chargesTaxList: [{
                name: 'VAT',
                percent: 10
            }]

        }
        doc.quantity = doc.quantity_purchased;
        var discount = 0.01 * doc.discount_percent;
        var resp = await testUtils.calculatePriceHandler(doc);
        console.log(resp);

        //    if (doc.bSPTaxInclusive == false) {
        var taxSum = 0;
        for (var i = 0; i < doc.itemTaxList.length; i++) {
            taxSum += doc.itemTaxList[i].percent;
        }

        var chargesSum = 0;
        for (var i = 0; i < doc.chargesList.length; i++) {
            chargesSum += doc.chargesList[i].percent;
        }

        var chargesTaxSum = 0;
        for (var i = 0; i < doc.chargesTaxList.length; i++) {
            chargesTaxSum += doc.chargesTaxList[i].percent;
        }

        var tax = 0.01 * taxSum;
        var charges = 0.01 * chargesSum;
        var chargesTax = 0.01 * chargesTaxSum;

        var totalValue = doc.purchasePrice * doc.quantity * (1 - discount) * (1 + tax) + doc.purchasePrice * doc.quantity * (1 - discount) * charges * (1 + chargesTax);
        var totalNoDiscountNoChargesNoTax = doc.purchasePrice * doc.quantity;
        var totalNoChargesNoTax = doc.purchasePrice * doc.quantity * (1 - discount);
        var totalNoTax = doc.purchasePrice * doc.quantity * (1 - discount) * (1 + charges);
        var totalDiscount = doc.purchasePrice * doc.quantity * discount;
        var totalCharges = doc.purchasePrice * doc.quantity * (1 - discount) * (charges);
        var totalTax = doc.purchasePrice * doc.quantity * (1 - discount) * (tax) + doc.purchasePrice * doc.quantity * (1 - discount) * (charges) * chargesTax;
        var totalChargesTaxPercent = doc.purchasePrice * doc.quantity * (1 - discount) * (charges) * chargesTax;

        expect(Math.abs(resp.totalValue - totalValue)).to.lessThan(0.00001);
        // expect(Math.abs(resp.totalNoChargesNoTax - totalNoChargesNoTax)).to.lessThan(0.00001);
        // expect(Math.abs(resp.totalNoDiscountNoChargesNoTax - totalNoDiscountNoChargesNoTax)).to.lessThan(0.00001);
        expect(Math.abs(resp.totalNoTax - totalNoTax)).to.lessThan(0.00001);
        // expect(Math.abs(resp.totalDiscount - totalDiscount)).to.lessThan(0.00001);
        // expect(Math.abs(resp.totalCharges - totalCharges)).to.lessThan(0.00001);
        // expect(Math.abs(resp.totalTax - totalTax)).to.lessThan(0.00001);
        // expect(Math.abs(resp.totalChargesTaxPercent - totalChargesTaxPercent)).to.lessThan(0.00001);
        // expect(resp).to.have.property('totalValue').equals(totalValue);
        // expect(resp).to.have.property('totalNoChargesNoTax').equals(totalNoChargesNoTax);
        // expect(resp).to.have.property('totalNoDiscountNoChargesNoTax').equals(totalNoDiscountNoChargesNoTax);
        // expect(resp).to.have.property('totalNoTax').equals(totalNoTax);
        // expect(resp).to.have.property('totalDiscount').equals(totalDiscount);
        // expect(resp).to.have.property('totalCharges').equals(totalCharges);
        // expect(resp).to.have.property('totalTax').equals(totalTax);
        // expect(resp).to.have.property('totalChargesTaxPercent').equals(totalChargesTaxPercent);

    });

    xit('gstr report', async function() {
        let resp = await testUtils.getAllHeads({
            // month: 7
        });
        console.log(resp);
    });

    it('get whole', async function() {
        let resp = await testUtils.getReports({

        });
        console.log(resp);
        expect(1).to.equals(1);
    });

});