'use strict';

let gstr2 = function() {
    require('dotenv-safe').load({
        path: __dirname + '/../.env',
        sample: __dirname + '/../env.example'
    });

    const couchDbManager = require('../dbManagers/couchDbManager');
    const couchDBUtils = require('../controllers/common/CouchDBUtils');
    const commonLib = require('../controllers/libraries/commonLib');
    const mainDBInstance = couchDBUtils.getMainCouchDB();
    const moment = require('moment');

    let homeState = '';

    let _self = this;
    const taxesInfo = {
        igst: {
            gstFactor: 1,
            stateType: 'inter'
        },
        cgst: {
            gstFactor: 2,
            stateType: 'intra'
        },
        sgst: {
            gstFactor: 2,
            stateType: 'intra'
        },
        cess: {
            gstFactor: 0,
            stateType: ''
        }
    };

    const HEADER_13_LABELS = {
        1: "HSN",
        2: "Description",
        3: "UQC",
        4: "Total Quantity",
        5: "Total Value",
        6: "Total Taxable Value",
        7: "IGST",
        8: "CGST",
        9: "SGST",
        10: "Cess"
    };

    const HEADER_6A_LABELS = {
        oldCustomerGSTIN: "GSTIN Old",
        oldInvoiceNo: "Invoice Old",
        oldInvoiceDate: "Date Old",
        customerGSTIN: "GSTIN",
        invoiceNo: "Invoice",
        invoiceDate: "Date",
        totalValue: "Value",
        taxRate: "Rate",
        totalTaxableValue: "Taxable",
        igst: "IGST",
        cgst: "CGST",
        sgst: "SGST",
        cess: "CESS",
        supplyState: "POS",
        itc: "ITC",
        itcIGST: "ITC IGST",
        itcCGST: "ITC CGST",
        itcSGST: "ITC SGST",
        itcCESS: "ITC CESS"
    };
    const HEADER_3_LABELS = {
        customerGSTIN: "GSTIN",
        invoiceNo: "Invoice",
        invoiceDate: "Date",
        totalValue: "Taxable Value",
        taxRate: "Rate",
        totalTaxableValue: "Total",
        igst: "IGST",
        cgst: "CGST",
        sgst: "SGST",
        cess: "CESS",
        supplyState: "Supply State",
        itc: "ITC",
        itcIGST: "ITC IGST",
        itcCGST: "ITC CGST",
        itcSGST: "ITC SGST",
        itcCESS: "ITC CESS"
    };

    function initHead13Json(hsnLabel, head_13, item) {
        head_13[hsnLabel] = {};
        head_13[hsnLabel].hsn = item.hsn ? item.hsn : 'N.A.';
        head_13[hsnLabel].description = item.description;
        head_13[hsnLabel].uqc = item.unit;
        head_13[hsnLabel].quantity = 0;
        head_13[hsnLabel].totalValue = 0;
        head_13[hsnLabel].totalTaxableValue = 0;
        for (let taxName in taxesInfo) {
            head_13[hsnLabel][taxName] = 0;
        }
    }

    this.getAllHeads = async function(data) {
        // TODO: header for all
        // TODO: not done headings
        let _month = data.month;
        let _year = data.year;
        let startTime;
        let endTime;
        if (data.start_date && data.end_date) {
            startTime = parseInt(moment(data.start_date).startOf('day').format('x'));
            endTime = parseInt(moment(data.end_date).endOf('day').format('x'));
        } else {
            if (_month === undefined) {
                //current month
                _month = parseInt(moment().format('MM')) - 1;
            }

            if (_year === undefined) {
                //current year
                _year = parseInt(moment().year());
            }
            startTime = parseInt(moment().month(_month).year(_year).startOf('month').format('x'));
            endTime = parseInt(moment().month(_month).year(_year).endOf('month').format('x'));

        }

        try {
            let params = {
                startkey: startTime,
                endkey: endTime,
                include_docs: false
            };
            let resp = await couchDBUtils.getTransView('all_receivings_info', 'all_recv_time', params, mainDBInstance, 'purchase');
            let gstr2 = {};
            gstr2.head_3 = [HEADER_3_LABELS];
            gstr2.head_4 = [];
            gstr2.head_5 = [];
            gstr2.head_8 = [];
            gstr2.head_7 = [];
            gstr2.head_7a = [];
            gstr2.head_7b = [];
            let head_13 = {};
            head_13.headerLabels = HEADER_13_LABELS;

            let head_common = {};
            for (let i = 0; i < resp.length; i++) {
                let invoiceValue = 0;
                let _id = resp[i].receivings_info._id;
                let doc = resp[i];
                if (doc.bRejected) {
                    continue;
                }

                // skip next loop if receiving_items is undefind
                // Credit Document, Room Reservation
                if (!doc.receiving_items) continue;

                let customerGSTIN = "";
                let customerType = 'b2b';
                customerGSTIN = doc.receivings_info.GSTIN;
                if (customerGSTIN == "" || !customerGSTIN) {
                    customerType = 'b2c';
                }

                let invoiceDate = removeComma(new Date(doc.receivings_info.receiving_time).toLocaleString('en-IN'));
                let invoiceNo = doc.receivings_info.receiving_id;
                let supplyState = doc.receivings_info.state_name;

                let stateType = '';
                let totalTaxableValue = 0;

                for (let j = 0; j < doc.receiving_items.length; j++) {
                    let hsn = doc.receiving_items[j].hsn ? doc.receiving_items[j].hsn : "N.A.";
                    let hsnLabel = ('hsn_' + hsn);

                    let cal = this.calculatePriceHandler(doc.receiving_items[j]);
                    invoiceValue += cal.totalValue;
                    if (!head_13[hsnLabel]) {
                        initHead13Json(hsnLabel, head_13, doc.receiving_items[j]);
                    }
                    head_13[hsnLabel].quantity += doc.receiving_items[j].quantity_purchased;
                    head_13[hsnLabel].totalValue += cal.totalValue;
                    head_13[hsnLabel].totalTaxableValue += cal.totalNoTax;

                    let taxRate = 0;
                    for (let z = 0; z < cal.itemTaxList.length; z++) {
                        let taxName = cal.itemTaxList[z].name.toLowerCase();
                        let taxAmt = cal.itemTaxList[z].amount;
                        if (taxesInfo[taxName] && taxesInfo[taxName].gstFactor) {
                            taxRate = cal.itemTaxList[z].percent * taxesInfo[taxName].gstFactor;
                            stateType = getStateType(taxesInfo[taxName].stateType);
                            break;
                        }
                    }

                    let taxLabel = (_id + '_tax_' + taxRate);
                    if (!head_common[taxLabel]) {
                        head_common[taxLabel] = {};
                        head_common[taxLabel].customerGSTIN = customerGSTIN;
                        head_common[taxLabel].invoiceNo = invoiceNo;
                        head_common[taxLabel].invoiceDate = invoiceDate;
                        head_common[taxLabel].totalValue = 0;
                        head_common[taxLabel].taxRate = taxRate;
                        head_common[taxLabel].totalTaxableValue = 0;
                        for (let taxName in taxesInfo) {
                            head_common[taxLabel][taxName] = 0;
                        }
                        head_common[taxLabel].supplyState = supplyState;
                        head_common[taxLabel].itc = ' ';
                        head_common[taxLabel].itcIGST = ' ';
                        head_common[taxLabel].itcSGST = ' ';
                        head_common[taxLabel].itcCGST = ' ';
                        head_common[taxLabel].itcCESS = ' ';
                        head_common[taxLabel].customerType = customerType;
                        head_common[taxLabel].stateType = stateType;
                        head_common[taxLabel].receivingId = _id;

                        head_common[taxLabel].invoiceValue = invoiceValue;

                    }

                    for (let z = 0; z < cal.itemTaxList.length; z++) {
                        let taxName = cal.itemTaxList[z].name.toLowerCase();
                        let taxAmt = cal.itemTaxList[z].amount;
                        if (head_13[hsnLabel].hasOwnProperty(taxName)) {
                            head_13[hsnLabel][taxName] += taxAmt;
                        }
                        if (head_common[taxLabel].hasOwnProperty(taxName)) {
                            head_common[taxLabel][taxName] += taxAmt;
                        }
                    }

                    head_common[taxLabel].totalValue += cal.totalValue;
                    head_common[taxLabel].totalTaxableValue += cal.totalNoTax;
                    head_common[taxLabel].invoiceValue = invoiceValue;
                }

            }

            let keys = Object.keys(head_common);
            for (let i = 0; i < keys.length; i++) {
                let tmpRow = head_common[keys[i]];
                delete(tmpRow.__proto__);
                let impKeys = Object.keys(HEADER_3_LABELS);
                if (tmpRow.customerType == 'b2b') {
                    // delete(tmpRow.customerType);
                    // delete(tmpRow.stateType);
                    // delete(tmpRow.receivingId);
                    // delete(tmpRow.totalValue);
                    let tmpKeys = Object.keys(tmpRow);
                    tmpKeys.forEach(element => {
                        if (impKeys.indexOf(element) < 0) delete tmpRow[element];
                    });
                    gstr2.head_3.push(tmpRow);
                }
                // else if (tmpRow.customerType == 'b2c' && tmpRow.stateType == 'intra') {
                //     delete(tmpRow.customerGSTIN);
                //     delete(tmpRow.customerType);
                //     delete(tmpRow.invoiceDate);
                //     delete(tmpRow.invoiceNo);
                //     delete(tmpRow.invoiceValue);
                //     delete(tmpRow.stateType);
                //     delete(tmpRow.supplyState);
                //     delete(tmpRow.receivingId);
                //     delete(tmpRow.totalValue);
                //     gstr2.head_7a.push(tmpRow);
                // } else if (tmpRow.customerType == 'b2c' && tmpRow.stateType == 'inter' && tmpRow.invoiceValue <= 250000) {
                //     delete(tmpRow.customerGSTIN);
                //     delete(tmpRow.customerType);
                //     delete(tmpRow.invoiceDate);
                //     delete(tmpRow.invoiceNo);
                //     delete(tmpRow.invoiceValue);
                //     delete(tmpRow.stateType);
                //     delete(tmpRow.supplyState);
                //     delete(tmpRow.receivingId);
                //     delete(tmpRow.totalValue);
                //     gstr2.head_7b.push(tmpRow);
                // } else if (tmpRow.customerType == 'b2c' && tmpRow.stateType == 'inter' && tmpRow.invoiceValue > 250000) {
                //     delete(tmpRow.customerGSTIN);
                //     delete(tmpRow.customerType);
                //     delete(tmpRow.stateType);
                //     delete(tmpRow.receivingId);
                //     delete(tmpRow.totalValue);
                //     delete(tmpRow.cgst);
                //     delete(tmpRow.sgst);
                //     gstr2.head_5.push(tmpRow);
                // } else if (tmpRow.cgst == 0 && tmpRow.sgst == 0 && tmpRow.igst == 0) {
                //     // TODO Count of docs should be sent
                //     gstr2.head_8.push(tmpRow);
                // }
            }

            gstr2.head_13 = Object.values(head_13);

            return gstr2;
        } catch (err) {
            throw err;
        }
    }

    this.getHead6 = async function(data) {
        // TODO: header for all
        // TODO: not done headings
        let _month = data.month;
        let _year = data.year;
        let startTime;
        let endTime;
        if (data.start_date && data.end_date) {
            startTime = parseInt(moment(data.start_date).startOf('day').format('x'));
            endTime = parseInt(moment(data.end_date).endOf('day').format('x'));
        } else {
            if (_month === undefined) {
                //current month
                _month = parseInt(moment().format('MM')) - 1;
            }

            if (_year === undefined) {
                //current year
                _year = parseInt(moment().year());
            }
            startTime = parseInt(moment().month(_month).year(_year).startOf('month').format('x'));
            endTime = parseInt(moment().month(_month).year(_year).endOf('month').format('x'));

        }

        try {
            let params = {
                startkey: startTime,
                endkey: endTime,
                include_docs: false
            };
            let resp = await couchDBUtils.getTransView('all_receivings_info', 'all_recv_return_time', params, mainDBInstance, 'purchase');
            let gstr2 = {};
            gstr2.head_6a = [HEADER_6A_LABELS];

            let head_common = {};
            for (let i = 0; i < resp.length; i++) {
                let invoiceValue = 0;
                let _id = resp[i].info._id;
                let doc = resp[i];
                if (doc.bRejected) {
                    continue;
                }

                // skip next loop if receiving_items is undefind
                // Credit Document, Room Reservation
                if (!doc.items) continue;

                let customerGSTIN = "";
                let customerType = 'b2b';
                customerGSTIN = doc.info.GSTIN; // not there in return doc
                if (customerGSTIN == "" || !customerGSTIN) {
                    customerType = 'b2c';
                }

                let invoiceDate = removeComma(new Date(doc.info.time).toLocaleString('en-IN'));
                let invoiceNo = doc.info.id;
                let supplyState = doc.info.state_name;

                let oldPurchaseId = doc.info.parentId;
                let oldCustomerGSTIN = '';
                let oldInvoiceNo = '';
                let oldInvoiceDate = '';
                let oldInvoiceValue = '';
                try {
                    let oldDoc = await couchDBUtils.getTransDoc('receiving_' + oldPurchaseId, mainDBInstance, 'failed to get old purchase doc');
                    oldCustomerGSTIN = oldDoc.receivings_info.GSTIN;
                    if (!oldCustomerGSTIN) continue; // dont include unregistered 
                    oldInvoiceNo = oldDoc.receiving_id;
                    oldInvoiceDate = removeComma(new Date(oldDoc.receivings_info.receiving_time).toLocaleString('en-IN'));
                } catch (err) {
                    continue; // SKIP this doc.....should we throw from here
                }

                let stateType = '';
                let totalTaxableValue = 0;

                for (let j = 0; j < doc.items.length; j++) {
                    let cal = this.calculatePriceHandler(doc.items[j]);
                    invoiceValue += cal.totalValue;

                    let taxRate = 0;
                    for (let z = 0; z < cal.itemTaxList.length; z++) {
                        let taxName = cal.itemTaxList[z].name.toLowerCase();
                        let taxAmt = cal.itemTaxList[z].amount;
                        if (taxesInfo[taxName] && taxesInfo[taxName].gstFactor) {
                            taxRate = cal.itemTaxList[z].percent * taxesInfo[taxName].gstFactor;
                            stateType = getStateType(taxesInfo[taxName].stateType);
                            break;
                        }
                    }

                    let taxLabel = (_id + '_tax_' + taxRate);
                    if (!head_common[taxLabel]) {
                        head_common[taxLabel] = {};
                        // head_common[taxLabel].customerGSTIN = customerGSTIN;
                        head_common[taxLabel].oldCustomerGSTIN = oldCustomerGSTIN;
                        head_common[taxLabel].oldInvoiceNo = oldInvoiceNo;
                        head_common[taxLabel].oldInvoiceDate = oldInvoiceDate;

                        head_common[taxLabel].customerGSTIN = oldCustomerGSTIN;
                        head_common[taxLabel].invoiceNo = invoiceNo;
                        head_common[taxLabel].invoiceDate = invoiceDate;
                        head_common[taxLabel].totalValue = 0;

                        head_common[taxLabel].taxRate = taxRate;
                        head_common[taxLabel].totalTaxableValue = 0;

                        for (let taxName in taxesInfo) {
                            head_common[taxLabel][taxName] = 0;
                        }
                        head_common[taxLabel].supplyState = supplyState;
                        head_common[taxLabel].itc = ' ';
                        head_common[taxLabel].itcIGST = ' ';
                        head_common[taxLabel].itcCGST = ' ';
                        head_common[taxLabel].itcSGST = ' ';
                        head_common[taxLabel].itcCESS = ' ';
                        head_common[taxLabel].invoiceValue = 0;
                        head_common[taxLabel].customerType = customerType;
                        head_common[taxLabel].stateType = stateType;
                        head_common[taxLabel].receivingId = _id;
                        head_common[taxLabel].oldInvoiceValue = invoiceValue;
                    }

                    for (let z = 0; z < cal.itemTaxList.length; z++) {
                        let taxName = cal.itemTaxList[z].name.toLowerCase();
                        let taxAmt = cal.itemTaxList[z].amount;
                        if (head_common[taxLabel].hasOwnProperty(taxName)) {
                            head_common[taxLabel][taxName] += taxAmt;
                        }
                    }

                    head_common[taxLabel].totalValue += cal.totalValue;
                    head_common[taxLabel].totalTaxableValue += cal.totalNoTax;
                    head_common[taxLabel].invoiceValue = invoiceValue;
                    head_common[taxLabel].oldInvoiceValue = invoiceValue; // same because only return is happening
                }

            }

            let keys = Object.keys(head_common);
            let impKeys = Object.keys(HEADER_6A_LABELS);
            for (let i = 0; i < keys.length; i++) {
                let tmpRow = head_common[keys[i]];
                let tmpKeys = Object.keys(tmpRow);
                tmpKeys.forEach(element => {
                    if (impKeys.indexOf(element) < 0) delete tmpRow[element];
                });
                delete(tmpRow.__proto__);
                gstr2.head_6a.push(tmpRow);
            }

            // gstr2.head_6a = Object.values(head_6a);

            return gstr2;
        } catch (err) {
            throw err;
        }
    }

    /**
     * taxList - name, per, amt
     * totalValue
     * totalTaxableValue
     */
    this.calculatePrice = function(item) {
        if (!item.itemTaxList) {
            item.itemTaxList = [];
        }
        if (!item.chargesTaxList) {
            item.chargesTaxList = [];
        }
        if (!item.chargesList) {
            item.chargesList = [];
        }

        item.quantity = item.quantity_purchased;
        item.uqc = item.unit;
        item.gDiscountPercent = item.gDiscountPercent ? item.gDiscountPercent : 0;
        item.discount = item.discount_percent ? item.discount_percent : item.discount_percent;
        if (!item.discount) item.discount = 0;
        let discount = (item.discount + item.gDiscountPercent) * 0.01;
        item.purchasePrice = item.purchasePrice ? item.purchasePrice : getPurchasePrice(item.unitId, item.unitsInfo);
        let totalNoChargesNoTax = item.purchasePrice * item.quantity * (1 - discount);

        let totalChargesPercent = 0;
        for (let i = 0; i < item.chargesList.length; i++) {
            totalChargesPercent = item.chargesList[i].percent
        }
        let totalChargeAmount = totalNoChargesNoTax * totalChargesPercent * 0.01;
        let totalNoTax = totalNoChargesNoTax + totalChargeAmount;

        let taxesObj = {};
        let totalTaxAmount = 0;
        for (let i = 0; i < item.itemTaxList.length; i++) {
            let taxAmt = (totalNoChargesNoTax * item.itemTaxList[i].percent) * 0.01;

            let taxObjKey = item.itemTaxList[i].name + '-' + item.itemTaxList[i].percent;
            if (!taxesObj[taxObjKey]) {
                taxesObj[taxObjKey] = {
                    name: item.itemTaxList[i].name,
                    percent: item.itemTaxList[i].percent,
                    amount: 0
                };
            }
            totalTaxAmount += taxAmt;
            taxesObj[taxObjKey].amount += taxAmt;
        }

        for (let i = 0; i < item.chargesTaxList.length; i++) {
            let taxAmt = (totalChargeAmount * item.chargesTaxList[i].percent) * 0.01;

            let taxObjKey = item.chargesTaxList[i].name + '-' + item.chargesTaxList[i].percent;
            if (!taxesObj[taxObjKey]) {
                taxesObj[taxObjKey] = {
                    name: item.chargesTaxList[i].name,
                    percent: item.chargesTaxList[i].percent,
                    amount: 0
                };
            }
            totalTaxAmount += taxAmt;
            taxesObj[taxObjKey].amount += taxAmt;
        }

        let totalValue = totalNoTax + totalTaxAmount;

        let result = {};
        result.itemTaxList = Object.values(taxesObj);
        result.totalValue = totalValue;
        result.totalNoTax = totalNoTax;

        return result;
    };

    this.calculatePriceHandler = function(item) {
        if (item.bPPTaxInclusive == false)
            return this.calculatePrice(item);
        else {
            let totalTaxPercent = 0;
            for (let i = 0; i < item.itemTaxList.length; i++) {
                totalTaxPercent += item.itemTaxList[i].percent;
            }
            item.purchasePrice = getPurchasePrice(item.unitId, item.unitsInfo);
            let purchasePriceExTax = ((item.purchasePrice) / (1 + (0.01 * totalTaxPercent)));
            item.purchasePrice = purchasePriceExTax;
            return this.calculatePrice(item);
        }
    };

    this.getReports = async function(data) {
        let mainData = await _self.getAllHeads(data);
        let returnData = await _self.getHead6(data);
        mainData['head_6a'] = returnData['head_6a'];
        return mainData;
    }

    function getPurchasePrice(unitId, unitsInfo) {
        return unitsInfo[unitId].purchasePriceWithGDiscount;
    }

    function getStateType(bInterState) {
        let stateType = bInterState ? 'inter' : 'intra';
        return stateType;
    }

    function removeComma(data) {
        return data.replace(/,/gi, " ");
    }

};

module.exports = new gstr2();