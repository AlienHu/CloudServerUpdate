require('errors');

var bodyParser = require('body-parser');
var router = require('express').Router();
var path = require('path');
var profitGuruMAPP = path.resolve(__dirname + '/../profitGuruMAPP');

router.use(bodyParser.urlencoded({
    extended: true
}));
router.use(bodyParser.json());
router.get("/", function(req, res) {

    res.sendFile(profitGuruMAPP + "/index.html");

});

module.exports = router;