module.exports = function(app, passport) {

    app.get('/', function(req, res) {

        res.send({
            message: 'Login success'
        });
    });

    app.get('/sessionUser', function(req, res) {

        res.send({
            message: 'User:' + JSON.stringify(req.user)
        });
    });

    app.get('/sessionAll', function(req, res) {

        res.send({
            message: 'User:' + JSON.stringify(req.session)
        });
    });

    // app.get('/add2SessionCount', function(req, res) {

    //     req.user.someValue = req.user + ' 123';
    //     if (!req.session[req.user.name]) {
    //         req.session[req.user.name] = {};
    //     }
    //     if (req.session[req.user.name].count === undefined) {
    //         req.session[req.user.name].count = 0;
    //     } else {
    //         req.session[req.user.name].count++;
    //     }
    //     //req.session.addedValue = {req.user:}
    //     res.send({
    //         message: 'User:se session' + JSON.stringify(req.session)
    //     });
    // });
    // app.get('/account', function(req, res) {
    //     res.render('account.ejs', {
    //         user: req.user
    //     });
    // });

    app.get('/logout', function(req, res) {
        req.logout();
        res.send({
            message: 'logout success'
        });
    });

    app.get('/loginError', function(req, res) {

        res.send(new Error('loginError'));
        res.end();

    });

    app.post('/login', passport.authenticate('local-login', {
        successRedirect: '/',
        failureRedirect: '/loginError', // redirect back to the signup page if there is an error
        failureFlash: true // allow flash messages
    }));

    app.get('/signupSuccess', function(req, res) {

        // render the page and pass in any flash data if it exists
        res.send({
            message: 'success'
        });
    });
    app.get('/signupError', function(req, res) {

        // render the page and pass in any flash data if it exists
        // res.send({
        //     message: 'Error'
        // });
        res.send(new Error('signupError'));
        res.end();
    });

    app.get('/profile', isLoggedIn, function(req, res) {
        res.send({
            'profile': req.user
        });
    });

    app.post('/signup', passport.authenticate('local-signup', {
        successRedirect: '/signupSuccess', // redirect to the secure profile section
        failureRedirect: '/signupError', // redirect back to the signup page if there is an error
        session: false
    }));

    app.delete('/delete', function(req, res) {

        passport.deleteUser(req.body.user).then(function(resp) {
            console.log('Successfully updated Item', resp);
            res.send(resp);
            res.end();
        }).catch(function(reason) {
            //res.sendStatus(300);
            res.send(new Error(reason));
            res.end();
        });
    });
};

// route middleware to ensure user is logged in
function isLoggedIn(req, res, next) {
    if (req.isAuthenticated())
        return next();

    res.redirect('/');
}