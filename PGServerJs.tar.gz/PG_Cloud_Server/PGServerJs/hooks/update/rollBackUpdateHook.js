console.log('Started:rollback Update Hook');
//NOTE: CWD while running this hook is Previous Live Installer only, i.e. currently running

const config = require(__dirname + "/../../updater/updateConfig.js")();
const shelljs = require('shelljs');
const path = require('path');

const updaterBackUpDir = path.resolve(config.UpdaterDir, 'updaterBackUp');

//Copy the new files
if (shelljs.test('-d', updaterBackUpDir) && shelljs.ls(updaterBackUpDir).length) {
    shelljs.cp('-r', updaterBackUpDir + '/*', config.UpdaterDir);
}
console.log('End:rollback Update Hook');

process.exit(0);