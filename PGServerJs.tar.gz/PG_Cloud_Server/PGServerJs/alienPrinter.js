const fs = require('fs');
const Printer = require('ipp-printer');
const shelljs = require('shelljs');
const moment = require('moment');
const logger = require('./common/Logger');
const utils = require('./controllers/common/Utils');

function alienPrinter(appSettings) {
    // if (process.env.APP_TYPE.toLowerCase() !== "crm") {
    //     console.log("Not Connect App. Alien Printer wont run");
    //     return;
    // }

    const appType = process.env.APP_TYPE.toLowerCase();

    if (!appSettings.customerApp.bEnableAlienInvoices) {
        console.log('alien printer not enabled');
        return;
    }
    //http://localhost:7777/printers/Alien-Printer

    var config = appSettings.customerApp.oAlienPrinter;
    var printerPort = config.oPrinterPort[appType];
    var printer = new Printer({
        name: config.sPrinterName,
        port: printerPort
    });
    console.log(config.sPrinterName + ' is running on ' + printerPort);

    const PATH = appSettings.customerApp.sAlienInvoiceSyncPath;
    const createFolderIfNotExists = function(folderName) {
        if (!fs.existsSync(folderName)) {
            fs.mkdirSync(folderName);
        }
    }
    const appFolder = PATH.ROOT + process.env.APP_TYPE.toUpperCase();
    const createFolder = function() {
        const foldersToCreate = PATH.ROOT.split('/');
        var path = '';
        for (var i = 0; i < foldersToCreate.length; i++) { // create root folder
            const thisFolder = foldersToCreate[i];
            if (thisFolder.trim()) // avoid last extra splitted element bcoz of / in last
                createFolderIfNotExists(path + thisFolder);
            path += thisFolder + '/';
        }
        createFolderIfNotExists(appFolder);
        for (var folder in PATH) {
            if (folder !== "ROOT") {
                createFolderIfNotExists(appFolder + "/" + folder);
            }
        }
    }
    createFolder();

    printer.on('job', function(job) {
        console.log('new print received');
        var filename = appFolder + "/" + PATH["NOT REGISTERED"] + moment().format('x') + '.pdf';
        var file = fs.createWriteStream(filename);
        // normalize / in path 
        filename = normalizePath(filename);
        config.sPrinterPath = normalizePath(config.sPrinterPath);

        job.pipe(file); //it will write it to the file

        job.on('end', function() {
            console.log('job end');
            setTimeout(function() {
                const thisPdf = appFolder + "/" + PATH.INFO + 'new.pdf'; // putting in info intentionally
                fs.copyFileSync(filename, thisPdf); // copying to avoid delete issue the same file which should print
                // var serverAddress = licencer.getServerSerialNumber(); // APPCONFIG.serverSerialNumber
                utils.sendSocketEvent('registerAlienSale'); // not sending any data, bcoz terminal reads last pdf automatically by time
                console.log('socket event sent');
                const printCommand = '"' + config.sPrinterPath + '" "' + normalizePath(thisPdf) + '" "' + config.sTargetPrinter + '"'
                console.log(printCommand);
                shelljs.exec(printCommand, {
                    async: true,
                    silent: true
                }); //filename should be absolute path
                console.log('triggered physical print');

                // launch app from here and go to mapping screen 
                // shelljs.exec(getAppPath());
            }, 1000); //Timeout just to make sure that pdf is saved. Experiement with the timeout and see what happends if we remove it
        });

        job.on('error', function(err) {
            logger.error(job);
            console.error(err);
            logger.error(err);
        });

        function normalizePath(slashedPath) {
            const newPath = slashedPath.split('/').join('\\');
            return newPath;
        }

        // function getAppPath() {
        //     let path = 'C:/ProfitGuru/Retail/Terminal/profitGuruClient/ProfitGuru.exe';
        //     return normalizePath(path);
        // }

    });
}

module.exports = function(appSettings) {
    return alienPrinter(appSettings);
};