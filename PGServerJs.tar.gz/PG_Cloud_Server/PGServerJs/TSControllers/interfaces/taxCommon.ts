export interface Slab {
    _id: string;
    _rev: string;
    name: string;
    taxName: string;
    rates: Rate[];
    id: number;
}

interface Rate {
    min: number;
    max: number;
    percent: number;
}

export interface Tax {
    name: string;
    percent: number;
}

export interface TaxInfo extends Tax {
    _id: string;
    _rev: string;
    id: any;
}

export interface TaxEx extends Tax {
    Amt: number;
}
