import { ImeiNumbers, Serialnumber, UniqueDetailInfo } from './uniqueDetails';
import { AttributeInfo } from './variants';
import { UnitsInfo } from './unitsInfo';
import { TransStatus } from './inventoryTransStatus';
import { Tax, TaxInfo, Slab } from './taxCommon';
import { GlobalDiscountInfo } from './globalDiscountInfo';
import { Payment } from './payments';
import { DBSale } from './dbSaleDoc';
import dbSaleDoc = DBSale.SaleDoc;
import dbSaleItem = DBSale.SaleItem;
import dbSalesInfo = DBSale.SalesInfo;
import { TaxProfileEx } from './TaxProfile';
import { People } from './people';
import { ApplicationSettings } from './applicationSettings';

export namespace InventoryTrans {
    /**
     * This is what is output of additemrestapi
     */
    export interface SaleItem {
        item_id: number;
        batchId: string;
        stockKey: string;
        quantity: number;
        item_location: number;
        skuName: string; //variants Blue/M/Formal
        unitId: string;
        baseUnitId: string;
        unitsInfo: UnitsInfo;
        uniqueDetails?: UniqueDetailInfo[];
    }

}

export namespace ComputeSale {

    export interface SalesInfo extends dbSalesInfo {

    }

    /**
     * This inside Sales Doc
     * This is used for homedelivery apis
     */
    export interface SaleItem extends dbSaleItem {
        //from imtem
        readonly hasBatchNumber: boolean;
        readonly bOTG: boolean;
        readonly hasExpiryDate: boolean;
        //Original Taxes #nodatabase
        readonly origTaxesList: TaxInfo[];
        readonly purchaseTaxes: TaxInfo[];
        readonly purchaseSlab: Slab;
        readonly is_serialized: boolean;
        readonly imeiCount: number;

        //computation summary fields
        computation: Computation;
        readonly purchasePrice: number;
    }

    export interface Temp {
        bLocalTax: boolean;
        chargesTaxList: Tax[];
    }

    export interface SaleUIOptions {
        print_after_sale: boolean;
        maxLine: number;
        allSerialnumbers: string[];
        allIMEINumbers: string[];
    }

    export interface SaleFullInfo {
        readonly employeeFullName: string;
        readonly profile?: TaxProfileEx;
        readonly customer?: People;
        readonly applicationSettings: ApplicationSettings;
    }

    export interface SaleDoc extends dbSaleDoc {
        sale_items: SaleItem[];
        sales_info: SalesInfo;
        computation: GComputation;
        ui: SaleUIOptions;
        fullInfo: SaleFullInfo;
        temp: Temp;
        bSuccess: boolean;
        message: string;
    }

    interface BaseComputation {
        totalExDiscount: number;
        totalItemDiscountAmt: number;
        gDiscountPercent: number; //Duplicate it is there in item also
        totalGDiscountAmt: number;
        totalDiscountAmt: number;
        totalInDiscount: number;
        totalCharges: number;
        taxableValue: number;
        totalChargesTaxAmt: number;
        totalItemTaxAmt: number;
        totalTaxAmt: number;
        total: number;
    }

    export interface GComputation extends BaseComputation {
        addedRoundOffValue: number;
        totalQuantity: number;
    }

    export interface Computation extends BaseComputation {
        totalDiscountPercent: number; // How to get this?
        totalTaxPercent: number; //There is nothing called totalTaxPercent .. because for charges and withoutcharges the percent is different
    }

}