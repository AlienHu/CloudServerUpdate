"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dbConfig = {
    "host": "127.0.0.1",
    "port": 5984,
    "dbPrefix": "pg",
    "username": '',
    "password": '',
    "onRegistrationId": {
        "_replicator": {
            "name": "_replicator",
            "bAddPrefix": false,
            "bAddCompanyStoreIDSufix": false,
            "bAddRegistrationIDSufix": false,
            "bCreateViews": false,
            "bSync2Client": false,
            "minInitDocs": 0
        },
        "sessions": {
            "name": "sessions",
            "bAddPrefix": true,
            "bAddCompanyStoreIDSufix": false,
            "bAddRegistrationIDSufix": false,
            "bCreateViews": false,
            "bSync2Client": false,
            "minInitDocs": 0
        },
        "_users": {
            "name": "_users",
            "bAddPrefix": false,
            "bAddCompanyStoreIDSufix": false,
            "bAddRegistrationIDSufix": false,
            "bCreateViews": true,
            "bSync2Client": true,
            "minInitDocs": 20
        },
        "licencedb": {
            "name": "licencedb",
            "bAddPrefix": true,
            "bAddCompanyStoreIDSufix": false,
            "bAddRegistrationIDSufix": true,
            "bCreateViews": true,
            "bSync2Client": true,
            "minInitDocs": 20
        }
    },
    "onStoreSelect": {
        "maindb": {
            "name": "maindb",
            "bAddPrefix": true,
            "bAddCompanyStoreIDSufix": true,
            "bAddRegistrationIDSufix": true,
            "bCreateViews": true,
            "bSync2Client": true,
            "minInitDocs": 50
        },
        "coredb": {
            "name": "coredb",
            "bAddPrefix": true,
            "bAddCompanyStoreIDSufix": true,
            "bAddRegistrationIDSufix": true,
            "bCreateViews": true,
            "bSync2Client": true,
            "minInitDocs": 20
        }
    }
};
//# sourceMappingURL=dbConfig.js.map