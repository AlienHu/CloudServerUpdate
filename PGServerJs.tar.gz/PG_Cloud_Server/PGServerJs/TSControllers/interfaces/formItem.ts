import { Id } from "./common";
import { UnitsInfo } from "./unitsInfo";
import { AttributeInfo } from "./variants";

export namespace Form {
    export interface Item {
        readonly _id: string;
        readonly name: string;
        readonly hsn: number;
        readonly item_id: number;
        readonly ItemType: string;
        readonly baseUnitId: Id;
        readonly defaultSellingUnitId: Id;
        readonly defaultPurchaseUnitId: Id;
        readonly description: string;
        readonly bSPTaxInclusive: boolean;
        readonly bPPTaxInclusive: boolean;
        readonly salesSlab: Id;
        readonly salesTaxes: Id[];
        readonly purchaseSlab: Id;
        readonly purchaseTaxes: Id[];
        readonly hasBatchNumber: boolean;
        readonly hasVariants: boolean;
        readonly bOTG: boolean;
        readonly hasExpiryDate: boolean;
        readonly is_serialized: boolean;
        readonly imeiCount: number;
        readonly reorderLevel: number;
        readonly quantity: number;
    }

    export interface StockInfo {
        readonly stockKey: string;
        readonly batchId: string;
        readonly unitsInfo: UnitsInfo;
        readonly attributeInfo: AttributeInfo;
        readonly skuName: string;
        readonly expiry: string;
    }
}