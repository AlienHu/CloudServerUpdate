export interface UniqueDetailInfo {
    serialnumber: string;
    imeiNumbers: ImeiNumbers;
}

export interface UniqueDetail {
    info: UniqueDetailInfo;
    sold?: boolean;
    itemAvailable?: boolean;
}

export interface UniqueDetails {
    [uniqueDetailKey: string]: UniqueDetail;
}

export type ImeiNumbers = string[];
export type Serialnumber = string;