export interface AttributeInfo {
    [attributeId: number]: number;
}