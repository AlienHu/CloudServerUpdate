import { UnitsInfo } from "../../TSControllers/interfaces/unitsInfo";

export = commonLib;

/*~ Write your module's methods and properties in this class */
declare class commonLib {
    constructor();

    getBaseUnitPrice(price: number, unitId: string, baseUnitId: string, unitsInfo: UnitsInfo): number;
}